# CharmTorque
Latest, unedited CharmTorque development.

CharmTorque is a web and hybrid development platform ("Hybrid" as in web/desktop hybrid application).  It unifies other projects via a Qt based cross-platform desktop application for managing tasks like connecting local to remote deployed versions of web sites, building site maps and tools related to Search Engine Optimization, generating PDF files, managing Docker containers, and managing APIs.  

CharmTorque "out of the box" certainly is less sophisticated than full-fledged web IDEs, but it can be easily extended.  Most functionality is accessed via scripts in the R/Z language, so editing scripts and creating new ones allows CharmTorque to be tweaked and modified as needed.

Compared with other Web Development frameworks, CharmTorque puts an emphasis on "hybrid" development, designing web applications that support native-front ends, APIs, and related strategies for mixing web and desktop development styles.


