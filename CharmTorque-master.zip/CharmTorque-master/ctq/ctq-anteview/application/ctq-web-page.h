
#ifndef CTQ_WEB_PAGE__H
#define CTQ_WEB_PAGE__H


#include <QString>
#include <QMainWindow>

#include <QTextEdit>

//?
//#include <QtWebView>
//#include <QtWebPage>

#include <QWebEnginePage>
#include <QWebEngineView>

//?#include <QWebEngineFrame>

#include <QLabel>
#include <QPushButton>

#include "accessors.h"

#include "flags.h"

#include "rzns.h"

#include <QMap>

class QPushButton;
class QTextEdit;
class QTabWidget;
class QCheckBox;

//CTQNS(LSI)
namespace RZ{ namespace CLG{


class CTQ_Web_Page : public QWebEnginePage
{
 Q_OBJECT


 QWidget* parent_;

 QMap<QString, QObject*> inner_controls_;

public:

 //CTQ_METHODIC(LSI_DB_Main_Editor* ,main_editor)


 CTQ_Web_Page(QWidget* parent);

 template<typename T>
 T* get_inner_control(QString name)
 {
  if(inner_controls_.contains(name))
   return static_cast<T*>(inner_controls_[name]);
  return nullptr;
 }

 void set_main_contents(QString contents);
 void set_check_box_value(QString name, bool b = true);

 bool get_check_box_value(QString name);

 //?bool handle_main_submit(LSI_DB_Main_Editor* main_editor);


 //?bool acceptNavigationRequest(QWebFrame* frame, const QNetworkRequest &request, NavigationType type);

 QObject* createPlugin(const QString& classid, const QUrl& url,
  const QStringList& paramNames, const QStringList& paramValues);

Q_SIGNALS:
 //void main_submit(LSI_DB_Web_Page*, LSI_DB_Main_Editor* main_editor);

//public Q_SLOTS:

};

} } //END_CTQNS(LSI)

#endif
