/****************************************************************************
**
** Copyright (C) 2008 Nokia Corporation and/or its subsidiary(-ies).
** Contact: Qt Software Information (qt-info@nokia.com)
**
** This file is part of the documentation of Qt. It was originally
** published as part of Qt Quarterly.
**
** Commercial Usage
** Licensees holding valid Qt Commercial licenses may use this file in
** accordance with the Qt Commercial License Agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and Nokia.
**
**
** GNU General Public License Usage
** Alternatively, this file may be used under the terms of the GNU
** General Public License versions 2.0 or 3.0 as published by the Free
** Software Foundation and appearing in the file LICENSE.GPL included in
** the packaging of this file.  Please review the following information
** to ensure GNU General Public Licensing requirements will be met:
** http://www.fsf.org/licensing/licenses/info/GPLv2.html and
** http://www.gnu.org/copyleft/gpl.html.  In addition, as a special
** exception, Nokia gives you certain additional rights. These rights
** are described in the Nokia Qt GPL Exception version 1.3, included in
** the file GPL_EXCEPTION.txt in this package.
**
** Qt for Windows(R) Licensees
** As a special exception, Nokia, as the sole copyright holder for Qt
** Designer, grants users of the Qt/Eclipse Integration plug-in the
** right for the Qt/Eclipse Integration to link to functionality
** provided by Qt Designer and its related libraries.
**
** If you are unsure which license is appropriate for your use, please
** contact the sales department at qt-sales@nokia.com.
**
****************************************************************************/

#ifndef PDF_DOCUMENT_WIDGET__H
#define PDF_DOCUMENT_WIDGET__H

#include <QLabel>
#include <QRectF>
#include <poppler-qt5.h>
#include <QMenu>
#include <QAction>

#include "accessors.h"

class QRubberBand;
class QScrollArea;

class PDF_Document_Widget : public QLabel
{
 Q_OBJECT

public:
 enum class Word_Context_Actions {
  N_A, Search, Edit_Artist, Edit_Author, View_Calendar
 };

private:

 QScrollArea* surrounding_scroll_area_;
 QMenu* word_context_menu_;
 QAction* search_action_;
 QAction* edit_artist_action_;
 QAction* edit_author_action_;
 QAction* view_calendar_action_;
 QAction* api_search_action_;

 QString highlight_word_;



public:
    PDF_Document_Widget(QWidget *parent = 0);
    ~PDF_Document_Widget();

    ACCESSORS(QScrollArea* ,surrounding_scroll_area)

    Poppler::Document *document();
    QMatrix matrix() const;
    qreal scale() const;

public slots:
    QRectF searchBackwards(const QString &text);
    QRectF searchForwards(const QString &text);
    bool setDocument(const QString &filePath);
    void setPage(int page = -1);
    void setScale(qreal scale);

    void word_context_menu_triggered(QAction*);

protected:
    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);

signals:
    void pageChanged(int currentPage);
    void textSelected(const QString &text);

    void api_search_action_triggered(QString search_text);
    void search_action_triggered(QString search_text);
    void word_context_action_requested(PDF_Document_Widget::Word_Context_Actions, QString);

private:


    QList<QUrl> url_list_;

    QString get_selected_text(const QRectF &rect);

    void selectedText(const QRectF &rect);
    void showPage(int page = -1);

    void raise_context_menu(QString text, QPoint p);

    Poppler::Document *doc;
    int currentPage;
    QPoint dragPosition;
    QRubberBand *rubberBand;
    QRectF searchLocation;
    qreal scaleFactor;
};

#endif
