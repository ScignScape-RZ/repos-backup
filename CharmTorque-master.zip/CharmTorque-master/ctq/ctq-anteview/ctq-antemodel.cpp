
#include "ctq-antemodel.h"


#include "data/ctq-data-manager.h"
#include "data/ctq-application-state.h"

#include "rz-gui-library/rz-send-email-dialog/rz-email-message.h"

#include "rzns.h"

USING_RZNS(CTQ)

CTQ_Antemodel::CTQ_Antemodel(CTQ_Data_Manager* data_manager)
 : data_manager_(data_manager)
{
#ifdef HIDE
 //?  compile_rz("/home/nlevisrael/rz-lisp/rz/t1.rz", result);


  // qRegisterMetaType<PTN_Recommendation_Clasp_Interface>();
  // qRegisterMetaType<PTN_Recommendation_Clasp_Interface*>();
  // qRegisterMetaType<PTN_Recommendation_Clasp_Interface>();
  // qRegisterMetaType<PTN_Recommendation_Clasp_Interface*>();


//?
//   qRegisterMetaType<PTN_Site_Manager_Bridge>();
//   qRegisterMetaType<PTN_Site_Manager_Bridge*>();

//   qRegisterMetaType<PTN_Site_Manager_Date_Time>();
//   qRegisterMetaType<PTN_Site_Manager_Date_Time*>();

//   qRegisterMetaType<PTN_Site_Manager_Folder_Bridge>();
//   qRegisterMetaType<PTN_Site_Manager_Folder_Bridge*>();

//   qRegisterMetaType<PTN_Site_Manager_File_Bridge>();
//   qRegisterMetaType<PTN_Site_Manager_File_Bridge*>();

//   qRegisterMetaType<PTN_Site_Manager_Event_Loop>();
//   qRegisterMetaType<PTN_Site_Manager_Event_Loop*>();

 // qRegisterMetaType<PTN_Recommendation_Clasp_Interface>();
 // qRegisterMetaType<PTN_Recommendation_Clasp_Interface*>();

  std::map<std::string, int> dummy_map;
  dummy_map["x"] = 1;
  dummy_map["y"] = 2;

  clasp_eval_ = new RZ_QClasp_Eval;


  char argc_ = 3;

  char* argv_[argc_];
  //?QDir::setCurrent(
  QString current_dir =  "/run/media/nlevisrael/DualBootShared/CLASPQ/branches/new-testing/clasp/build/boehmdc";

  qDebug() << current_dir;

  argv_[0] = "cclasp-boehmdc";
 // ////
 // argv_[1] = "-l";
 // argv_[2] = "/home/nlevisrael/rz-dev/cl/exit.lisp";

  argv_[1] = "-I";
  argv_[2] = "-n";

  //argv_[3] = "-I";
  //argv_[3] = "-n";


  //?clasp_eval->start_iclasp(argc, argv);

  clasp_eval_->start_clasp_from_dir(argc_, argv_, current_dir);
  clasp_bridge_ = new RZ_QClasp_Bridge(*clasp_eval);

  //?QString qs1 = "(core::q-callback :invoke   (core::q-create  :|PTN_Recommendation_Clasp_Interface|) :|value_from_qcmap|     \"a\"     \"b\"      \"aaa\"      \"xxx\" ) ";
  //?qDebug() << "\n\nQS1 --- \n" << qs1 << "\n\n===\n";



//  clasp_bridge->eval_file("/home/nlevisrael/rz-lisp/rz/t1.rz.cl");

 // clasp_bridge->eval_rz_file("/home/nlevisrael/rz-dev/cl/t4.rz");

  //?clasp_bridge->eval_string("(core::q-callback :invoke   (core::q-create  :|PTN_Recommendation_Clasp_Interface|) :|value_from_qcmap|     \"a\"     \"b\"      \"aaa\"      \"xxx\")");


 }
 //#endif
#endif

}


void CTQ_Antemodel::load_project_list(QList<CTQ_Project_Record*>& projects)
{
 data_manager_->load_project_list(projects);
}


void CTQ_Antemodel::check_reset_rz_source()
{
 if(!current_rz_source_.isEmpty())
 {
  current_substituted_rz_source_ = current_rz_source_;
  QMapIterator<QString, QString> it(substitutions_);
  while(it.hasNext())
  {
   it.next();
   QString str = QString("[[%1]]").arg(it.key());
   current_substituted_rz_source_.replace(str, it.value());
  }
 }
}

void CTQ_Antemodel::save_last_email(RZ_Email_Message* rem)
{
 data_manager_->save_last_email(*rem);
}

void CTQ_Antemodel::load_last_email(RZ_Email_Message* rem)
{
 data_manager_->load_last_email(*rem);
}
