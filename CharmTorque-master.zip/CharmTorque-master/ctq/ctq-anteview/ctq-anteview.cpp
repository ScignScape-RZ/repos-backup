
#include "ctq-anteview.h"

#include <QUrlQuery>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>

//#include <QXmlQuery>
//#include <QXmlFormatter>
//#include <QXmlResultItems>
//#include <QtPrintSupport/QPrinter>

#include "application/pdf-document-widget.h"

#include "paraviews/new-project-dialog.h"
#include "paraviews/view-web-page-dialog.h"
#include "paraviews/view-rz-dialog.h"
#include "paraviews/view-rz-run-output-dialog.h"

#include "silotypes/ctq-project/ctq-project-initial.h"
#include "silotypes/ctq-project/ctq-project-record.h"
#include "silotypes/ctq-project/ctq-project-silo.h"
#include "silotypes/ctq-project/ctq-project.h"

#include "rz-gui-library/rz-send-email-dialog/rz-send-email-dialog.h"
#include "rz-gui-library/rz-send-email-dialog/rz-email-message.h"
#include "rz-gui-library/rz-send-email-dialog/rz-email-message-handler.h"

#include "rz-gui-library/rz-screenshot-dialog/rz-screenshot-dialog.h"

USING_RZNS(GUI)


#include "ctq-application.h"

#include "ctq-main-editor.h"

#include "data/ctq-data-manager.h"

#include <QDebug>
#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QMenuBar>
#include <QStringList>
#include <QMessageBox>

#include <QGroupBox>
//#include <QNetworkAccessManager>

#include <QScrollArea>
#include <QFileDialog>

#include <QDesktopServices>

#include <QBuffer>

#include <QRegularExpression>
#include <QRegularExpressionMatch>

//#include <QNetworkAccessManager>
//#include <QNetworkRequest>
//#include <QNetworkReply>

#include <QComboBox>
#include <QSpinBox>

#include <QJsonValue>

#include <QSharedPointer>

//#include "xml/json-to-xml.h"
//#include "paraviews/edit-event-dialog.h"
//#include "paraviews/edit-artist-dialog.h"
//#include "paraviews/show-artist-list-dialog.h"
//#include "paraviews/show-author-list-dialog.h"

//#include "paraviews/show-preferences-dialog.h"
//#include "paraviews/show-transactions-dialog.h"

//#include "paraviews/rz-chat-dialog.h"


//#include "application/pdf-document-widget.h"

#include "ctq-antemodel.h"


//#include "rz-gui-library/rz-send-email-dialog/rz-send-email-dialog.h"
//#include "rz-gui-library/rz-send-email-dialog/rz-email-message.h"
//#include "rz-gui-library/rz-send-email-dialog/rz-email-message-handler.h"

//#include "rz-gui-library/rz-screenshot-dialog/rz-screenshot-dialog.h"

//?USING_RZNS(GUI)

//?#include <QWebFrame>

//?#include <QwwRichTextButton>


//#define SIGNAL(X) SIGNAL(X)
//#define SLOT(X) SLOT(X)

USING_RZNS(CTQ)

CTQ_Anteview::CTQ_Anteview(CTQ_Application* app, QWidget* parent)
 : QMainWindow(parent), app_(app), model_(nullptr),
   current_project_(nullptr), potential_current_project_record_(nullptr),
   data_manager_(app->data_manager()) //, qnam_(nullptr)
    //current_document_info_(nullptr)
{

//  qRegisterMetaType<RZ::CLG::CLG_NYT_Article*>();
//  qRegisterMetaType<RZ::CLG::CLG_NYT_Article>();

//  qRegisterMetaType<RZ::CLG::CLG_NYT_Concept*>();
//  qRegisterMetaType<RZ::CLG::CLG_NYT_Concept>();
}

void CTQ_Anteview::init()
{
 rz_print_results_text_edit_ = nullptr;

 app_->set_print_callback([this](QString str)
 {
  if(rz_print_results_text_edit_)
  {
   QString rt = rz_print_results_text_edit_->document()->toPlainText();
   rt += str;
   rz_print_results_text_edit_->document()->setPlainText(rt);
  }
 });

 model_ = new CTQ_Antemodel(data_manager_);

 menubar_ = new QMenuBar(this);

 menubar_->addAction("File");

 menubar_->addSeparator();

 QMenu* projects_menu =  menubar_->addMenu("Projects");

 QAction* new_project = projects_menu->addAction("New");

 connect(new_project, SIGNAL(triggered()),
   this, SLOT(new_project_requested()));

 QAction* edit_current_project = projects_menu->addAction("Edit Current Project");

 connect(edit_current_project, SIGNAL(triggered()),
   this, SLOT(edit_current_project_requested()));

 QAction* load_existing_project = projects_menu->addAction("Open Project");

 connect(load_existing_project, SIGNAL(triggered()),
   this, SLOT(load_existing_project_requested()));

 QMenu* rz_menu =  menubar_->addMenu("R/Z");

 QAction* open_rz = rz_menu->addAction("Open");

 connect(open_rz, SIGNAL(triggered()),
   this, SLOT(handle_open_rz()));

 QAction* view_rz_substitutions = rz_menu->addAction("View Substitutions");

 connect(view_rz_substitutions, SIGNAL(triggered()),
   this, SLOT(handle_view_rz_substitutions()));


 QMenu* web_menu =  menubar_->addMenu("Web");

 QAction* load_page_in_window = web_menu->addAction("Load Page in Window");

 connect(load_page_in_window, SIGNAL(triggered()),
   this, SLOT(view_web_page_dialog_requested()));


 QAction* screenshot = web_menu->addAction("Screenshot");

 connect(screenshot, SIGNAL(triggered()),
   this, SLOT(screenshot_dialog_requested()));

 menubar_->addSeparator();
 menubar_->addAction("About");
 menubar_->addAction("Help");
 menubar_->addAction("Views...");

 setMenuBar(menubar_);

 centerview_ = new CTQ_Centerview(this);
//? centerview_->init(last_saved_string);
 centerview_->init("");



 controls_dock_widget_ = new QDockWidget(this);
 controls_dock_widget_->setObjectName(QString::fromUtf8("controlsDockWidget"));
 controls_dock_widget_->setEnabled(true);
 controls_dock_widget_->setFloating(false);
 controls_dock_widget_->setFeatures(QDockWidget::AllDockWidgetFeatures);
 controls_dock_widget_->setAllowedAreas(Qt::BottomDockWidgetArea|Qt::TopDockWidgetArea);
 QWidget* dockWidgetContents = new QWidget();
 dockWidgetContents->setObjectName(QString::fromUtf8("dockWidgetContents"));

 QVBoxLayout* vboxLayout = new QVBoxLayout(dockWidgetContents);

 top_layout_ = new QHBoxLayout;

 top_layout_->setContentsMargins(0, 0, 0, 0);

  //?add_new_webview_tab(general_welcome_, "Welcome");


 //add_new_webview_tab(comment_summary_, "Comments...");

//? document_info_tabview_ = new Document_Info_Tabview(this);

  QFrame* top_frame = new QFrame(this);
  top_frame->setLayout(top_layout_);

  QString style_sheet =
    "QFrame {padding:0px;margin0px}"
    ;

  top_frame->setStyleSheet(style_sheet);

  top_frame->setContentsMargins(3, 0, 3, 0);

  top_frame->setFrameStyle(QFrame::Box | QFrame::Sunken);

  top_frame->setBackgroundRole(QPalette::ToolTipText);
  top_frame->setAutoFillBackground(true);
  top_frame->setLineWidth(1);
  top_frame->setMidLineWidth(8);


 vboxLayout->addWidget(top_frame);

 QHBoxLayout* hboxLayout = new QHBoxLayout(); // dockWidgetContents);
 hboxLayout->setObjectName(QString::fromUtf8("hboxLayout"));
 hboxLayout->setContentsMargins(4, 0, 4, 0);
 QSpacerItem* horizontalSpacer = new QSpacerItem(20, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

 hboxLayout->addItem(horizontalSpacer);

 QHBoxLayout* _2 = new QHBoxLayout();
 _2->setObjectName(QString::fromUtf8("_2"));

 page_label_ = new QLabel(dockWidgetContents);
 page_label_->setObjectName(QString::fromUtf8("page_label_"));

 _2->addWidget(page_label_);

 page_spin_box_ = new QSpinBox(dockWidgetContents);
 page_spin_box_->setObjectName(QString::fromUtf8("page_spin_box_"));
 page_spin_box_->setEnabled(false);

 _2->addWidget(page_spin_box_);


 hboxLayout->addLayout(_2);

 QSpacerItem* horizontalSpacer_2 = new QSpacerItem(20, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

 hboxLayout->addItem(horizontalSpacer_2);

 QHBoxLayout* _3 = new QHBoxLayout();
 _3->setObjectName(QString::fromUtf8("_3"));

 search_label_ = new QLabel(dockWidgetContents);
 search_label_->setObjectName(QString::fromUtf8("search_label_"));
 search_label_->setTextFormat(Qt::AutoText);

 _3->addWidget(search_label_);

 search_line_edit_ = new QLineEdit(dockWidgetContents);
 search_line_edit_->setObjectName(QString::fromUtf8("search_line_edit_"));
 search_line_edit_->setEnabled(false);

 _3->addWidget(search_line_edit_);

 search_combo_box_ = new QComboBox(dockWidgetContents);
 search_combo_box_->setObjectName(QString::fromUtf8("search_combo_box_"));
 search_combo_box_->setEnabled(false);

 _3->addWidget(search_combo_box_);

 find_button_ = new QPushButton(dockWidgetContents);
 find_button_->setObjectName(QString::fromUtf8("find_button_"));
 find_button_->setEnabled(false);

 _3->addWidget(find_button_);

 clear_button_ = new QPushButton(dockWidgetContents);
 clear_button_->setObjectName(QString::fromUtf8("clear_button_"));
 clear_button_->setEnabled(false);

 _3->addWidget(clear_button_);


 hboxLayout->addLayout(_3);

 QSpacerItem* spacerItem = new QSpacerItem(20, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

 hboxLayout->addItem(spacerItem);

 scale_label_ = new QLabel(dockWidgetContents);
 scale_label_->setObjectName(QString::fromUtf8("label"));

 hboxLayout->addWidget(scale_label_);

 scale_combo_box_ = new QComboBox(dockWidgetContents);
 scale_combo_box_->setObjectName(QString::fromUtf8("scale_combo_box_"));
 scale_combo_box_->setEnabled(true);

 hboxLayout->addWidget(scale_combo_box_);

 QSpacerItem* horizontalSpacer_3 = new QSpacerItem(20, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

 hboxLayout->addItem(horizontalSpacer_3);

 vboxLayout->addLayout(hboxLayout);

 dockWidgetContents->setLayout(vboxLayout);

 controls_dock_widget_->setWidget(dockWidgetContents);
 this->addDockWidget(static_cast<Qt::DockWidgetArea>(4), controls_dock_widget_);



 connect(page_spin_box_, SIGNAL(valueChanged(int)),
         centerview_->pdf_document(), SLOT(setPage(int)));

 connect(centerview_->pdf_document(), SIGNAL(pageChanged(int)),
         page_spin_box_, SLOT(setValue(int)));

 connect(scale_combo_box_, SIGNAL(currentIndexChanged(int)),
         centerview_, SLOT(scale_document(int)));


 connect(centerview_, SIGNAL(activate_screenshot()),
         this, SLOT(activate_screenshot_requested()));


// connect(documentWidget, SIGNAL(textSelected(const QString &)),
//         this, SLOT(showSelectedText(const QString &)));

//?
// connect(search_line_edit_, SIGNAL(returnPressed()), this, SLOT(searchDocument()));
// connect(find_button_, SIGNAL(clicked()), this, SLOT(searchDocument()));

 connect(clear_button_, SIGNAL(clicked()), centerview_->pdf_document(), SLOT(setPage()));

 connect(centerview_->pdf_document(), SIGNAL(search_action_triggered(QString)),
         this, SLOT( activate_topic_search(QString) //activate_api_search(QString)
                     )

         );

 connect(centerview_->pdf_document(), SIGNAL(api_search_action_triggered(QString)),
         this, SLOT( activate_api_search(QString)
                     )

         );

 QObject::connect(clear_button_, SIGNAL(clicked()), search_line_edit_, SLOT(clear()));


 connect(centerview_, SIGNAL(button_open_pdf_requested()),
  this, SLOT(handle_open_pdf()));

 connect(centerview_, SIGNAL(button_open_rz_requested()),
  this, SLOT(handle_open_rz()));

 connect(centerview_, SIGNAL(button_run_rz_requested()),
  this, SLOT(handle_run_rz()));


 connect(centerview_, SIGNAL(button_open_html_requested()),
  this, SLOT(handle_open_html()));


 connect(centerview_, SIGNAL(button_open_ngml_requested()),
  this, SLOT(handle_open_ngml()));

 connect(centerview_, SIGNAL(button_convert_ngml_requested()),
  this, SLOT(handle_convert_ngml()));


 connect(centerview_, SIGNAL(button_open_project_requested()),
  this, SLOT(handle_open_project()));

 connect(centerview_, SIGNAL(button_preview_project_requested()),
  this, SLOT(handle_preview_project()));


 connect(centerview_, SIGNAL(button_save_all_requested()),
  this, SLOT(handle_save_all()));


 scale_combo_box_->setCurrentIndex(3);

 retranslate_ui(this);

 setCentralWidget(centerview_);

 init_line_buttons();
}

void CTQ_Anteview::delete_dialog(QDialog* dlg)
{
 dlg->close();
 dlg->deleteLater();
}

void CTQ_Anteview::screenshot_dialog_requested()
{
 RZ_Screenshot_Dialog* dlg = new RZ_Screenshot_Dialog(this);

 connect(dlg, SIGNAL(canceled(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));

 //?SIGNAL(send_email_requested(RZ_Screenshot_Dialog*, const QPixmap&)),

 connect(dlg, &RZ_Screenshot_Dialog::send_email_requested,
   [this](RZ_Screenshot_Dialog* dlg, const QPixmap& pm)
   {
    send_email_dialog_requested(&pm);
   }
  );

}

void CTQ_Anteview::activate_screenshot_requested()
{
 QTimer::singleShot(1000, this, [this]
 {
    QScreen *screen = QGuiApplication::primaryScreen();
    if (const QWindow *window = windowHandle())
        screen = window->screen();
    if (!screen)
    {
     return;
    }

    QPixmap screenshot_pixmap = screen->grabWindow(this->winId());
    send_email_dialog_requested(&screenshot_pixmap);
  });
}

void CTQ_Anteview::send_email_dialog_requested(const QPixmap* const pixmap)
{
 RZ_Email_Message rem;

 model_->load_last_email(&rem);

 RZ_Send_Email_Dialog* dlg = new RZ_Send_Email_Dialog(this, rem, pixmap);

 connect(dlg, SIGNAL(canceled(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));

 connect(dlg, &RZ_Send_Email_Dialog::send_requested,  //?SIGNAL(send_requested(RZ_Send_Email_Dialog*, RZ_Email_Message*)),
  [this](RZ_Send_Email_Dialog* dlg, RZ_Email_Message* rem)
 {
  RZ_Email_Message_Handler remh(rem);

  QString s = remh.to_string();
  QMessageBox::information(this, "?", s);

  remh.do_send([this, dlg](RZ_Email_Message_Handler::Send_Result sr)
   {
    dlg->convey_send_result(sr);
   });

  model_->save_last_email(rem);


  //?QString s = remh.to_string();
  //?QMessageBox::information(this, "?", s);
 });

 dlg->exec();
}


void CTQ_Anteview::handle_view_rz_substitutions()
{
 QString src = centerview_->main_rz_source_text_edit()->document()->toPlainText();

 View_RZ_Dialog* dlg = new View_RZ_Dialog(this, model_, src);
 connect(dlg, SIGNAL(canceled(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));

 dlg->exec();



}


void CTQ_Anteview::view_web_page_dialog_requested()
{
 View_Web_Page_Dialog* dlg = new View_Web_Page_Dialog(this, nullptr);
 connect(dlg, SIGNAL(canceled(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));

 dlg->exec();


}

//void CTQ_Anteview::edit_current_project_requested()
//{
// New_Project_Dialog* dlg = new New_Project_Dialog(
//    New_Project_Dialog::Editing_Mode::Create_New, this, nullptr //model_
//                                                  );

// connect(dlg, SIGNAL(proceed_requested(QDialog*, QMap<QString,QString>)),
//   this, SLOT(handle_dialog_proceed_requested(QDialog*, QMap<QString,QString>)));

// connect(dlg, SIGNAL(canceled(QDialog*)),
//   this, SLOT(delete_dialog(QDialog*)));


// connect(this, SIGNAL(new_project_confirmed(QDialog*,  CTQ_Project&)),
//   dlg, SLOT(handle_new_project_confirmed(QDialog*,  CTQ_Project&)));

// connect(this, SIGNAL(project_already_exists(QDialog*,  CTQ_Project_Initial&)),
//   dlg, SLOT(handle_project_already_exists(QDialog*,  CTQ_Project_Initial&)));


// dlg->exec();
//}

void CTQ_Anteview::confirm_switch_to_existing_project(QDialog* dlg)
{
//?
// if(New_Project_Dialog* ndlg = qobject_cast<New_Project_Dialog*>(dlg) )
// {
//  if(ndlg->edits().isEmpty())
//  {
//   dlg->close();
//   return;
//  }
// }
 if(current_project_)
 {
  // anything to do here?"
 }
 current_project_ = new CTQ_Project(data_manager_);
 current_project_->absorb_record(*potential_current_project_record_);
   //?Q_EMIT(project_record_updated(current_project_, record) ...
 confirm_current_project_model_substitutions();
 dlg->close();
}

void CTQ_Anteview::confirm_current_project_model_substitutions()
{
 model_->substitutions()["PROJECT_LOCAL_FOLDER"] = current_project_->local_folder();
 model_->substitutions()["PROJECT_NAME"] = current_project_->name();
 model_->substitutions()["PROJECT_LOCAL_PORT"] = QString::number(current_project_->local_port());
 model_->substitutions()["PROJECT_DOCKER_PORT"] = QString::number(current_project_->docker_port());
 model_->check_reset_rz_source();
}

void CTQ_Anteview::potential_switch_to_existing_project(CTQ_Project_Record* record)
{
 potential_current_project_record_ = record;
}


void CTQ_Anteview::load_existing_project_requested()
{
 New_Project_Dialog* dlg = new New_Project_Dialog(
    New_Project_Dialog::Editing_Mode::Select_Existing, this, model_
                                                  );


 connect(dlg, SIGNAL(selected_project_changed(CTQ_Project_Record*)),
   this, SLOT(potential_switch_to_existing_project(CTQ_Project_Record*)));

 connect(dlg, SIGNAL(proceed_requested(QDialog*, CTQ_Project_Record*, QMap<QString,QString>)),
   this, SLOT(handle_dialog_proceed_requested(QDialog*, CTQ_Project_Record*, QMap<QString,QString>)));

 connect(dlg, SIGNAL(canceled(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));

 connect(dlg, SIGNAL(accepted(QDialog*)),
   this, SLOT(confirm_switch_to_existing_project(QDialog*)));

 dlg->exec();
}


void CTQ_Anteview::new_project_requested()
{

 New_Project_Dialog* dlg = new New_Project_Dialog(
    New_Project_Dialog::Editing_Mode::Create_New, this, nullptr //model_
                                                  );

 connect(dlg, SIGNAL(proceed_requested(QDialog*, CTQ_Project_Record*, QMap<QString,QString>)),
   this, SLOT(handle_dialog_proceed_requested(QDialog*, CTQ_Project_Record*, QMap<QString,QString>)));

 connect(dlg, SIGNAL(canceled(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));

 //?
 connect(dlg, SIGNAL(accepted(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));

 connect(this, SIGNAL(new_project_confirmed(QDialog*,  CTQ_Project&)),
   dlg, SLOT(handle_new_project_confirmed(QDialog*,  CTQ_Project&)));

 connect(this, SIGNAL(project_already_exists(QDialog*,  CTQ_Project_Initial&)),
   dlg, SLOT(handle_project_already_exists(QDialog*,  CTQ_Project_Initial&)));


 dlg->exec();
}

void CTQ_Anteview::edit_current_project_requested()
{

 if(!current_project_)
 {
  QMessageBox::information(this, "No Project Selected", "Please create or select a project to edit");
  return;
 }

 New_Project_Dialog* dlg = new New_Project_Dialog(
    New_Project_Dialog::Editing_Mode::Edit_Existing, this, model_, current_project_
                                                  );

 connect(dlg, SIGNAL(proceed_requested(QDialog*, CTQ_Project_Record*, QMap<QString,QString>)),
   this, SLOT(handle_project_edit_dialog_proceed_requested(QDialog*, CTQ_Project_Record*, QMap<QString,QString>)));

 connect(dlg, SIGNAL(canceled(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));


 //?
 connect(dlg, SIGNAL(accepted(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));


 connect(this, SIGNAL(save_project_confirmed(QDialog*,  CTQ_Project&)),
   dlg, SLOT(handle_save_project_confirmed(QDialog*,  CTQ_Project&)));

 connect(this, SIGNAL(save_project_failed(QDialog*,  CTQ_Project&)),
   dlg, SLOT(handle_save_project_failed(QDialog*,  CTQ_Project&)));

 dlg->exec();
}

void CTQ_Anteview::handle_project_edit_dialog_proceed_requested(QDialog* dlg,
  CTQ_Project_Record* project_record_, QMap<QString,QString> params)
{
 if(!current_project_)
 {
  // init new current project?
 }
 current_project_->absorb_record(*project_record_);
 bool ok = data_manager_->save_project(*current_project_);

 if(ok)
 {
  confirm_current_project_model_substitutions();
  Q_EMIT(save_project_confirmed(dlg, *current_project_));

 }
 else
 {
  Q_EMIT(save_project_failed(dlg, *current_project_));
 }

}

void CTQ_Anteview::handle_dialog_proceed_requested(QDialog* dlg,
  CTQ_Project_Record* project_record_, QMap<QString,QString> params)
{
 if(project_record_)
 {

  // editing an existing? ...
 }
 QSharedPointer<CTQ_Project_Initial> proi{ new CTQ_Project_Initial(data_manager_) };

 proi->absorb_string_map(params);

 QString code = data_manager_->check_project_code(*proi->record());

 if(code.isEmpty())
 {
  CTQ_Project_Silo* silo = data_manager_->ctq_project_silo();
  int record_uid = silo->new_uid();
  CTQ_Project* project = silo->confirm_joinee_from_record(*proi->record(), record_uid);
  if(project)
  {
   int call_result_1 = data_manager_->check_save_silo_record_count(*silo);
   if(call_result_1 == QUnQLite_Callback_Parser::All_Ok
      || call_result_1 == QUnQLite_Callback_Parser::All_Up_To_Date)
   {
    int call_result_2 = data_manager_->save_new_silo_joinee(*silo, *project);
    if(call_result_2 == QUnQLite_Callback_Parser::All_Ok)
    {
     data_manager_->save_project_code(*project);
     Q_EMIT(new_project_confirmed(dlg, *project));
    }
    //     data_manager_->save_project(*project);
    //     data_manager_->save_project_code(*project);
   }
  }


  //code = data_manager_->new_project_code(*proi);
  //CTQ_Project* pro = data_manag

  // { "name", name_line_edit_->text() },er_->
 }
 else
 {
  Q_EMIT(project_already_exists(dlg, *proi));
 }
// { "local-folder", local_folder_line_edit_->text() },
// { "remote-address", remote_address_line_edit_->text() },
// { "description", description_ },
// { "secondary-addresses", local_folder_line_edit_->text() }

}


QString CTQ_Anteview::read_file(QString path)
{
 QString result;
 QFile file(path);
 if(file.open(QIODevice::ReadOnly | QIODevice::Text))
 {
  QTextStream in_stream(&file);
  result = in_stream.readAll();
 }
 return result;
}


void CTQ_Anteview::handle_open_rz()
{
 QString file = QFileDialog::getOpenFileName(this, "Open R/Z File",
   DEFAULT_RZ_DIR, "R/Z Files (*.rz)");

 if(!file.isEmpty())
 {
  bool ok = centerview_->read_file(file, centerview_->main_rz_source_text_edit());
  if(ok)
  {
   centerview_->set_current_main_tab(centerview_->main_rz_source_text_edit());
   model_->set_current_rz_source(centerview_->main_rz_source_text_edit()->document()->toPlainText());
   model_->check_reset_rz_source();
  }
 }
}

void CTQ_Anteview::handle_run_rz()
{
 QString src = model_->current_substituted_rz_source();

 View_RZ_Run_Output_Dialog* dlg = new View_RZ_Run_Output_Dialog(this, src);

 rz_print_results_text_edit_ = dlg->main_text();

 connect(dlg, SIGNAL(canceled(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));

 connect(dlg, SIGNAL(accepted(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));

 QString clasp = app_->run_rz(src);
 dlg->reset_clasp_code(clasp);

}

void CTQ_Anteview::handle_open_html()
{
 QString file = QFileDialog::getOpenFileName(this, "Open HTML File",
   "/home/nlevisrael", "HTML Files (*.rz, *.htm, *.html)");

 if(!file.isEmpty())
 {
  centerview_->browse_file(file);
//  bool ok = centerview_->read_file(file, centerview_->main_rz_source_text_edit());
//  if(ok)
//  {
//   centerview_->set_current_main_tab(centerview_->main_rz_source_text_edit());
//  }
 }

}


void CTQ_Anteview::handle_open_ngml()
{

}
void CTQ_Anteview::handle_convert_ngml()
{

}


void CTQ_Anteview::handle_open_project()
{
 load_existing_project_requested();
}

void CTQ_Anteview::handle_preview_project()
{

}

void CTQ_Anteview::handle_save_all()
{

}


void CTQ_Anteview::handle_open_pdf()
{
 QString file = QFileDialog::getOpenFileName(this, "Open PDF File",
   "/home/nlevisrael", "PDF Files (*.pdf)");

 if(!file.isEmpty())
 {
  centerview_->load_pdf_file(file);

  search_line_edit_->setEnabled(true);
  search_combo_box_->setEnabled(true);
  find_button_->setEnabled(true);
  clear_button_->setEnabled(true);
  scale_combo_box_->setEnabled(true);
  page_spin_box_->setEnabled(true);
  page_spin_box_->setMinimum(1);
  page_spin_box_->setMaximum(centerview_->pdf_document()->document()->numPages());
  page_spin_box_->setValue(1);

 }
}


#define QUUTF8


void CTQ_Anteview::retranslate_ui(QMainWindow* MainWindow)
{
//    MainWindow->setWindowTitle(QApplication::translate("MainWindow", "PDF Viewer", 0 QUUTF8));
//    openAction->setText(QApplication::translate("MainWindow", "&Open...", 0 QUUTF8));
//    openAction->setShortcut(QApplication::translate("MainWindow", "Ctrl+O", 0 QUUTF8));
//    exitAction->setText(QApplication::translate("MainWindow", "E&xit", 0 QUUTF8));
//    exitAction->setShortcut(QApplication::translate("MainWindow", "Ctrl+Q", 0 QUUTF8));
//    increaseScaleAction->setText(QApplication::translate("MainWindow", "&Increase Scale", 0 QUUTF8));
//    increaseScaleAction->setShortcut(QApplication::translate("MainWindow", "Ctrl++", 0 QUUTF8));
//    decreaseScaleAction->setText(QApplication::translate("MainWindow", "&Decrease Scale", 0 QUUTF8));
//    decreaseScaleAction->setShortcut(QApplication::translate("MainWindow", "Ctrl+-", 0 QUUTF8));
//    documentControlsAction->setText(QApplication::translate("MainWindow", "&Document Controls", 0 QUUTF8));
//    selectedTextAction->setText(QApplication::translate("MainWindow", "&Selected Text", 0 QUUTF8));
//    menu_File->setTitle(QApplication::translate("MainWindow", "&File", 0 QUUTF8));
//    menu_Windows->setTitle(QApplication::translate("MainWindow", "&Windows", 0 QUUTF8));
//    controlsDockWidget->setWindowTitle(QApplication::translate("MainWindow", "Document Controls", 0 QUUTF8));
    page_label_->setText(QApplication::translate("CLG_DB_Anteview", "Page:", 0 QUUTF8));
    search_label_->setText(QApplication::translate("MainWindow", "Search for:", 0 QUUTF8));
    search_combo_box_->clear();
    search_combo_box_->insertItems(0, QStringList()
     << QApplication::translate("MainWindow", "Forwards", 0 QUUTF8)
     << QApplication::translate("MainWindow", "Backwards", 0 QUUTF8)
    );
    find_button_->setText(QApplication::translate("MainWindow", "Find", 0 QUUTF8));
    clear_button_->setText(QApplication::translate("MainWindow", "Clear", 0 QUUTF8));
    scale_label_->setText(QApplication::translate("MainWindow", "Scale PDF Document:", 0 QUUTF8));
    scale_combo_box_->clear();
    scale_combo_box_->insertItems(0, QStringList()
     << QApplication::translate("MainWindow", "25%", 0 QUUTF8)
     << QApplication::translate("MainWindow", "50%", 0 QUUTF8)
     << QApplication::translate("MainWindow", "75%", 0 QUUTF8)
     << QApplication::translate("MainWindow", "100%", 0 QUUTF8)
     << QApplication::translate("MainWindow", "125%", 0 QUUTF8)
     << QApplication::translate("MainWindow", "150%", 0 QUUTF8)
     << QApplication::translate("MainWindow", "200%", 0 QUUTF8)
     << QApplication::translate("MainWindow", "300%", 0 QUUTF8)
     << QApplication::translate("MainWindow", "400%", 0 QUUTF8)
    );
    scale_combo_box_->setCurrentIndex(3);

     //selectionDockWidget->setWindowTitle(QApplication::translate("MainWindow", "Selected Text", 0 QUUTF8));
} // retranslateUi



void CTQ_Anteview::init_line_buttons()
{
 centerview_->init_line_buttons();

// this->setStyleSheet("QGroupBox::title {subcontrol-position: top; top:20px;}");
// QGroupBox* box1 = new QGroupBox("PDF", this);
// QHBoxLayout* boxl1 = new QHBoxLayout;
// boxl1->addWidget(centerview_->button_open_pdf());
// box1->setLayout(boxl1);
// top_layout_->addWidget(box1);
 top_layout_->addWidget(centerview_->button_open_pdf());

 top_layout_->addStretch();

// QGroupBox* box2 = new QGroupBox("R/Z", this);
// QHBoxLayout* boxl2 = new QHBoxLayout;
// boxl2->setContentsMargins(0,0,0,0);
// boxl2->addWidget(centerview_->button_open_rz());
// boxl2->addWidget(centerview_->button_run_rz());
// box2->setLayout(boxl2);
// top_layout_->addWidget(box2);
 top_layout_->addWidget(centerview_->button_open_rz());
 top_layout_->addWidget(centerview_->button_run_rz());

 top_layout_->addStretch();

// QGroupBox* box3 = new QGroupBox("HTML", this);
// QHBoxLayout* boxl3 = new QHBoxLayout;
// boxl3->addWidget(centerview_->button_open_html());
// box3->setLayout(boxl3);
// top_layout_->addWidget(box3);
 top_layout_->addWidget(centerview_->button_open_html());

 top_layout_->addStretch();

// QGroupBox* box4 = new QGroupBox("NGML", this);
// QHBoxLayout* boxl4 = new QHBoxLayout;
// boxl4->addWidget(centerview_->button_open_ngml());
// boxl4->addWidget(centerview_->button_convert_ngml());
// box4->setLayout(boxl4);
// top_layout_->addWidget(box4);
 top_layout_->addWidget(centerview_->button_open_ngml());
 top_layout_->addWidget(centerview_->button_convert_ngml());

 top_layout_->addStretch();

// QGroupBox* box5 = new QGroupBox("Project", this);
// QHBoxLayout* boxl5 = new QHBoxLayout;
// boxl5->addWidget(centerview_->button_open_project());
// boxl5->addWidget(centerview_->button_preview_project());
// box5->setLayout(boxl5);
// top_layout_->addWidget(box5);
 top_layout_->addWidget(centerview_->button_open_project());
 top_layout_->addWidget(centerview_->button_preview_project());
 top_layout_->addWidget(centerview_->button_export_project());

 top_layout_->addStretch();

// QGroupBox* box6 = new QGroupBox("Application", this);
// QHBoxLayout* boxl6 = new QHBoxLayout;
// boxl6->addWidget(centerview_->button_save_all());
// boxl6->addWidget(centerview_->button_close());
// box6->setLayout(boxl6);
// top_layout_->addWidget(box6);
 top_layout_->addWidget(centerview_->button_save_all());

 top_layout_->addWidget(centerview_->button_close());


 //?
 connect(centerview_->button_close(), SIGNAL(clicked()),
  this, SLOT(close()));


}

