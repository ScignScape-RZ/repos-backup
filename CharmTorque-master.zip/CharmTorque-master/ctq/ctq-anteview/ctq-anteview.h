
#ifndef CTQ_ANTEVIEW__H
#define CTQ_ANTEVIEW__H


#include <QString>
#include <QMainWindow>

#include <QTextEdit>
//?#include <QWebView>
#include <QLabel>
#include <QPushButton>

#include <QHBoxLayout>

#include <QTimer>
#include <QWindow>
#include <QScreen>



#include <QDockWidget>


#include <QDate>
#include <QSpinBox>
#include <QComboBox>

//#include "paraviews/load-url-dialog.h"

#include "ctq-centerview.h"

#include "accessors.h"

#include "flags.h"

#include "rzns.h"

//RZNS_(CTQ)
namespace RZ{ namespace CTQ{

class CTQ_Application;
class CTQ_Antemodel;
class CTQ_Resource;
class CTQ_Centerview;
//?
class Dialog_Properties_Dialog;
class CTQ_Data_Manager;
//?
//class CTQ_Data_HTML;
//class CTQ_Web_Page;
//class CTQ_User;
//class User_Register_Dialog;
//class Personal_Template_Dialog_Box;
//class Load_Url_Dialog;
//class Store_Url_Dialog;
//class Run_XQuery_Dialog;
//class Configure_XQuery_Dialog;
//class Load_XML_Dialog;
//class HTML_Visuals_Dialog;
//class Review_Stored_Web_Pages_Dialog;
//class XML_Perspectives_Dialog;
//class NYT_API_Dialog;
//class Enigma_Api_Dialog;
//class Vaers_API_Dialog;

class CTQ_Project_Record;

class Shopping_Cart_Demo_Dialog;


class CLG_Named_Entity_Map;
class CLG_Document_Info;

class CTQ_Project;
class CTQ_Project_Initial;

class Edit_Event_Dialog;


class CTQ_Anteview : public QMainWindow
{
 Q_OBJECT

 enum Wait_State {
  Not_Waiting, Waiting_On_Login_For_Personal_Template
 };

 enum class Http_Content_Types {
  N_A, JSON, XML
 };

 Http_Content_Types parse_content_type_from_string(QString str)
 {
  static QMap<QString, Http_Content_Types> static_map {{
   {"application/json", Http_Content_Types::JSON},
   {"application/xml", Http_Content_Types::XML},

  }};

  return static_map.value(str, Http_Content_Types::N_A);
 }

 CTQ_Application* app_;

 CTQ_Antemodel* model_;
 CTQ_Data_Manager* data_manager_;
// CTQ_Data_HTML* data_html_;

 QMenuBar* menubar_;
 QMenu* lisp_menu_;
 QMenu* html_menu_;

 CTQ_Centerview* centerview_;

 QDockWidget* controls_dock_widget_;

 QSpinBox* page_spin_box_;
 QLineEdit* search_line_edit_;
 QLabel* search_label_;
 QLabel* page_label_;
 QLabel* scale_label_;
 QComboBox* scale_combo_box_;
 QComboBox* search_combo_box_;
 QPushButton* find_button_;
 QPushButton* clear_button_;

 QHBoxLayout* top_layout_;

 QString read_file(QString path);

 CTQ_Project* current_project_;
 CTQ_Project_Record* potential_current_project_record_;

 QTextEdit* rz_print_results_text_edit_;

 void confirm_current_project_model_substitutions();


public:

 CTQ_Anteview(CTQ_Application* app, QWidget* parent = nullptr);

 void init();

 void retranslate_ui(QMainWindow* MainWindow);


 void init_line_buttons();

Q_SIGNALS:

 void new_project_confirmed(QDialog*,  CTQ_Project&);
 void project_already_exists(QDialog*,  CTQ_Project_Initial&);
 void save_project_confirmed(QDialog*,  CTQ_Project&);
 void save_project_failed(QDialog*,  CTQ_Project&);

public Q_SLOTS:

 void handle_open_pdf();
 void handle_open_rz();
 void handle_run_rz();
 void handle_view_rz_substitutions();

 void handle_open_html();
 void handle_open_ngml();
 void handle_convert_ngml();
 void handle_open_project();
 void handle_preview_project();
 void handle_save_all();
 void view_web_page_dialog_requested();

 void screenshot_dialog_requested();
 void activate_screenshot_requested();

 void new_project_requested();

 void edit_current_project_requested();
 void load_existing_project_requested();

 void send_email_dialog_requested(const QPixmap* const pixmap = nullptr);

 void handle_dialog_proceed_requested(QDialog* dlg,
   CTQ_Project_Record* project_record_, QMap<QString,QString> params);

 void handle_project_edit_dialog_proceed_requested(QDialog* dlg,
   CTQ_Project_Record* project_record_, QMap<QString,QString> params);


 void potential_switch_to_existing_project(CTQ_Project_Record*);
 void confirm_switch_to_existing_project(QDialog* dlg);
 void delete_dialog(QDialog* dlg);


};

} } //_RZNS(CTQ)

#endif
