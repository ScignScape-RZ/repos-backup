
#include "ctq-application.h"
#include "ctq-anteview.h"

#include "data/ctq-data-manager.h"

#include "qunqlite-callback-parser.h"

#include <QApplication>
#include <QRegularExpression>

#include <QMessageBox>


USING_RZNS(CTQ)

CTQ_Application::CTQ_Application(int argc, char* argv[])
 : qapp_(new QApplication(argc, argv)) //?, socket_listener_(this), hub_check_message_box_(nullptr)
{
 //?
 //?socket_listener_.listen(9999);
}

QString CTQ_Application::run_rz(QString src)
{
 QString result;
 if(rz_callback_)
 {
  result = rz_callback_(src);
 }

 if(clasp_callback_)
 {
  clasp_callback_(result);
 }
 return result;
}

void CTQ_Application::allobase_init(QString default_data_directory,
  QString database_name, allobase_callback_type& act,
  index_callback_type& ict, error_callback_type& ect)
{
 set_default_data_directory(default_data_directory);
 data_manager_ = new CTQ_Data_Manager();
 data_manager_->set_allobase_callback(act);
 data_manager_->set_index_callback(ict);
 data_manager_->set_error_callback(ect);

 int init_db_result = data_manager_->init_db(default_data_directory_, database_name);

 //?std::cout.flush();

 if(init_db_result == QUnQLite_Callback_Parser::All_Ok)
 {
  //? std::cout << std::endl << "DB Open ...";
  qDebug() << "DB Open ...";

  QString ec = data_manager_->get_last_error_code();
  QString dp = data_manager_->get_db_path_value();
  QString lo = data_manager_->get_db_last_open_value();

  qDebug() << "EC: " << ec;
  qDebug() << "DP: " << dp;
  qDebug() << "LO: " << lo;
 }
 else
 {
  qDebug() << "DB was not opened...";

  QString ec = data_manager_->get_last_error_code();
  QString dp = data_manager_->get_db_path_value();
  QString lo = data_manager_->get_db_last_open_value();

  qDebug() << "EC: " << ec;
  qDebug() << "DP: " << dp;
  qDebug() << "LO: " << lo;
 }

 data_manager_->init_silos();

}

#define tr(x) x

#ifdef HIDE
void CTQ_Application::received_socket_message(QString message)
{
 if(!hub_check_message_box_)
 {
  hub_check_message_box_ = new QMessageBox;
  hub_check_message_box_->setText("Do you want to launch this site's application on the QNH Hub?.");
  hub_check_message_box_->setInformativeText("Click \"Enter Once\", or \"Enter Always\" to launch this "
                           "application automatically from this web site. \n\n"
                           "Or, choose \"Disable Always\" if you never want to visit this application."

                           );

  QPushButton* disable_always_button = hub_check_message_box_->addButton(tr("Disable Always"), QMessageBox::NoRole);


  QPushButton* enter_once_button = hub_check_message_box_->addButton(tr("Enter Once"), QMessageBox::AcceptRole);
  QPushButton* enter_always_button = hub_check_message_box_->addButton(tr("Enter Always"), QMessageBox::YesRole);

  QPushButton* cancel_button = hub_check_message_box_->addButton(tr("Cancel"), QMessageBox::RejectRole);

  hub_check_message_box_->exec();

  if(hub_check_message_box_->clickedButton() == enter_once_button)
  {
   //?start_application(clga);
   anteview_->init_line_buttons();
  }
  else if(hub_check_message_box_->clickedButton() == enter_always_button)
  {
  //?start_application(clga);
   anteview_->init_line_buttons();
  }
  else if(hub_check_message_box_->clickedButton() == disable_always_button)
  {

  }
  else if(hub_check_message_box_->clickedButton() == cancel_button)
  {

  }
 }

 QRegularExpression rx("(\\S+)\\s+");
 QRegularExpressionMatch rxm = rx.match(message);
 if(rxm.hasMatch())
 {
  QString kind = rxm.captured(1);
  message = message.mid(rxm.capturedEnd());
  if(kind == "qtweb")
  {
   received_message_from_browser(message);
  }
 }
//? anteview_->setWindowState(Qt::WindowMaximized);

//?
//
 anteview_->setWindowState((anteview_->windowState() & ~Qt::WindowMinimized)
                           | Qt::WindowActive);


}
#endif

#ifdef HIDE
void CTQ_Application::recede()
{
 anteview_->setWindowState(Qt::WindowMinimized);
}

void CTQ_Application::received_message_from_browser(QString url)
{
 //?anteview_->setWindowFlags(anteview_->windowFlags() | Qt::WindowStaysOnTopHint);

// anteview_->setWindowState((anteview_->windowState() & ~Qt::WindowMinimized)
//                           | Qt::WindowActive);

 //? anteview_->load_web_page(url);
 anteview_->raise();
 anteview_->activateWindow();

//?
// anteview_->setWindowState((anteview_->windowState() & ~Qt::WindowMinimized)
//                           | Qt::WindowActive);

 anteview_->setWindowState(Qt::WindowMaximized);

 //?anteview_->setWindowState(Qt::WindowMaximized);

//    (anteview_->windowState() & ~Qt::WindowMinimized)
//                           | Qt::WindowActive);

 //anteview_->
}

#endif

void CTQ_Application::prepare_anteview(QString window_title)
{
 anteview_ = new CTQ_Anteview(this);
 anteview_->setWindowTitle(window_title);

 anteview_->setMinimumWidth(1000);

 anteview_->init();

}

void CTQ_Application::launch()
{
// anteview_->setMinimumWidth(900);

   //?
 anteview_->show();


 //?
 //recede();

 qapp_->exec();
}
