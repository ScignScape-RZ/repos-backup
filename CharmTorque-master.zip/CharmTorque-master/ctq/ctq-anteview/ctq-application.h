
#ifndef CTQ_APPLICATION__H
#define CTQ_APPLICATION__H


#include <QString>

#include <functional>

#include <QMessageBox>

#include "accessors.h"

#include "flags.h"

#include "rzns.h"

//#include "sockets/ctq-socket-listener.h"

class QApplication;

RZNS_(CTQ)
//namespace RZ{ namespace CTQ{

class CTQ_Anteview;
class CTQ_Data_Manager;


class CTQ_Application
{
 QApplication* qapp_;

 CTQ_Anteview* anteview_;

 CTQ_Data_Manager* data_manager_;

 QString default_open_directory_;
 QString default_data_directory_;

// QMessageBox* hub_check_message_box_;

 typedef std::function<int(QString message, int arglength, void* data)> allobase_callback_type;
 typedef std::function<int(QString message, QString key, QString value, QString* ref)> index_callback_type;
 typedef std::function<QString()> error_callback_type;
 typedef std::function<QString(QString)> rz_callback_type;

 typedef std::function<void*(QString)> clasp_callback_type;

 typedef std::function<void(QString)> print_callback_type;

 clasp_callback_type clasp_callback_;
 rz_callback_type rz_callback_;
 print_callback_type print_callback_;
// allobase_callback_type allobase_callback_;


// CTQ_Socket_Listener socket_listener_;

public:

 CTQ_Application(int argc, char* argv[]);

 ACCESSORS(QString ,default_open_directory)
 ACCESSORS(QString ,default_data_directory)
 ACCESSORS(clasp_callback_type ,clasp_callback)
 ACCESSORS(rz_callback_type ,rz_callback)
 ACCESSORS(print_callback_type ,print_callback)

 ACCESSORS(CTQ_Data_Manager* ,data_manager)

 QString run_rz(QString src);

 void prepare_anteview(QString window_title);
 void launch();
 void allobase_init(QString default_data_directory,
  QString default_database_name,
  allobase_callback_type& act, index_callback_type& ict,
  error_callback_type& ect);

// void received_socket_message(QString message);
// void received_message_from_browser(QString message);
// void recede();


};

} } //_RZNS(CTQ)

#endif
