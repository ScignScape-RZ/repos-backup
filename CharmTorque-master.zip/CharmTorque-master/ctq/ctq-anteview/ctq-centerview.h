
#ifndef CTQ_CENTERVIEW__H
#define CTQ_CENTERVIEW__H


#include <QString>
#include <QMainWindow>

#include <QTextEdit>
#include <QTextBrowser>
#include <QPlainTextEdit>
//#include <QWebView>
#include <QLabel>
#include <QPushButton>
#include <QLineEdit>
#include <QScrollArea>

#include <QWebEngineView>

//#include "C:/Qt5_4/5.4/mingw491_32/include/QtWebKitWidgets/qwebview.h"

#include "accessors.h"

#include "flags.h"

#include "rzns.h"

class QPushButton;
class QTextEdit;
class QTabWidget;

class PDF_Document_Widget;

#include <QMap>

//RZNS_(CTQ)
namespace RZ{ namespace CTQ{

class CTQ_Application;
class CTQ_Antemodel;
class CTQ_Resource;
class CTQ_Main_Editor;
class CTQ_Web_Page;
class CTQ_Comment;
class CTQ_User;
class CTQ_Counterpoint_Template;
class CLG_Document_Container;

class CLG_Named_Entity_Map;

class CLG_XML_Content;

class Document_Info_Tabview;

class CTQ_Centerview : public QWidget
{
 Q_OBJECT

// QPushButton* button_convert_xml_;
// QPushButton* button_load_xml_;
// QPushButton* button_run_xquery_;
// QPushButton* button_xml_visualize_;


 QPushButton* button_open_pdf_;

 QPushButton* button_open_rz_;
 QPushButton* button_run_rz_;

 QPushButton* button_open_html_;

 QPushButton* button_open_ngml_;
 QPushButton* button_convert_ngml_;

 QPushButton* button_open_project_;
 QPushButton* button_preview_project_;
 QPushButton* button_export_project_;

 QPushButton* button_save_all_;

 QPushButton* button_close_;

 //CLG_Document_Container* current_document_container_;

 QPlainTextEdit* xml_text_edit_;
 QPlainTextEdit* main_html_source_text_edit_;
 QPlainTextEdit* main_rz_source_text_edit_;
 QPlainTextEdit* main_ngml_source_text_edit_;
 QPlainTextEdit* main_latex_source_text_edit_;
 QPlainTextEdit* main_khif_source_text_edit_;

 QTextBrowser* main_html_text_browser_;
 QWebEngineView* history_web_view_;


//?
 PDF_Document_Widget* pdf_document_;

// QTextBrowser* document_container_text_edit_;
// QTextBrowser* named_entities_text_edit_;

 Document_Info_Tabview* document_info_tabview_;

 //?QTextEdit* word_count_text_edit_;
 //?QTextBrowser* hrefs_text_edit_;
 QTextBrowser* xquery_results_text_edit_;

 QString current_loaded_url_;


 QTabWidget* main_notebook_;


 QScrollArea* central_web_view_scroll_area_;

 QMap<QString, QString> info_strings_;

 QString load_file(QString path);

 QString hrefs_;


 QWebEngineView* central_web_view_;


public:

 void save_to_local_file_path(QString xml_path);
 void load_word_count_and_stream(QString base_path);

//? ACCESSORS(QWebView* ,central_web_view)

 ACCESSORS(QPushButton* ,button_open_pdf)
 ACCESSORS(QPushButton* ,button_open_rz)
 ACCESSORS(QPushButton* ,button_run_rz)
 ACCESSORS(QPushButton* ,button_open_html)
 ACCESSORS(QPushButton* ,button_open_ngml)
 ACCESSORS(QPushButton* ,button_convert_ngml)
 ACCESSORS(QPushButton* ,button_open_project)
 ACCESSORS(QPushButton* ,button_export_project)
 ACCESSORS(QPushButton* ,button_preview_project)
 ACCESSORS(QPushButton* ,button_save_all)
 ACCESSORS(QPushButton* ,button_close)

 ACCESSORS(QPlainTextEdit* ,main_html_source_text_edit)
 ACCESSORS(QPlainTextEdit* ,main_rz_source_text_edit)
 ACCESSORS(QPlainTextEdit* ,main_ngml_source_text_edit)
 ACCESSORS(QPlainTextEdit* ,main_latex_source_text_edit)
 ACCESSORS(QPlainTextEdit* ,main_khif_source_text_edit)



 ACCESSORS(PDF_Document_Widget* ,pdf_document)


 ACCESSORS__GET(QString ,current_loaded_url)


 enum notepage_Titles {
  General_Welcome,
  Comments_Summary,
  Comment_Edit,
  Comment_Preview
 };


 CTQ_Centerview(QWidget* parent = nullptr);


 void init(QString info);

 void init_line_buttons();


 void open_xml_tab();
 void set_current_url(QString url);


 //?void add_new_webview_tab(QWebView*& qwv, QString tab_text);
 void add_new_text_edit_tab(QTextEdit*& qte, QString tab_text);
 void add_new_text_edit_tab(QPlainTextEdit*& qte, QString tab_text);
 void add_new_text_browser_tab(QTextBrowser*& qte, QString tab_text);

 void load_blookster_site();

 void set_xquery_results(QString results);

 bool read_file(QString path, QPlainTextEdit* qpte);
 void read_file(QString path, QPlainTextEdit* qpte, QString& result);
 QString read_file(QString path);

 void save_file(QString path, QString contents);
 void save_binary_file(QString path, const QByteArray& contents);

 void show_saved_xml(QString xml);

 //?void load_web_page(QUrl url);


 QString get_xquery_results();

 QMap<QString, QStringList> music_info_;
 QMap<QString, QString> music_context_menu_labels_;

//?
// QMap<QString, QStringList> item_info_;
// QMap<QString, QString> item_context_menu_labels_;

 void browse_html(QUrl url);
 void browse_file(QString file);

 void set_main_xml(QString xml);
 void set_main_html(QString html);

 void set_central_web_view_url_label(QString url);

 void set_current_main_tab(QWidget* qw);

 void central_web_view_scroll(int amount);

 void load_pdf_file(QString file_name);

//?
// QString html_contents();
// QString raw_html_contents();

Q_SIGNALS:

// void named_entity_changes_requested(QString details);

// void activate_screenshot();

// void edit_event_requested();
// void edit_artist_requested();
// void edit_author_requested();

// void view_item_requested(int index);

// void run_properties();
// void run_load_url();
// void run_store_url();
// void run_xquery();
// void load_xml_requested();

 void button_open_pdf_requested();

 void button_open_rz_requested();
 void button_run_rz_requested();

 void button_open_html_requested();
 void button_export_html_requested();

 void button_open_ngml_requested();
 void button_convert_ngml_requested();

 void button_open_project_requested();
 void button_preview_project_requested();

 void button_save_all_requested();



public Q_SLOTS:


// void run_load_url_clicked();
// void run_store_url_clicked();
// void run_xquery_clicked();

// void notebook_tab_selected(int tab_index);

////? void run_load_finished(bool ok);
// void button_xml_visualize_clicked();

// void button_load_xml_clicked();
// void button_load_visuals_clicked();

// void button_edit_event_clicked();
// void button_edit_artist_clicked();
// void button_edit_author_clicked();


 void button_open_pdf_clicked();

 void button_open_rz_clicked();
 void button_run_rz_clicked();

 void button_open_html_clicked();

 void button_open_ngml_clicked();
 void button_convert_ngml_clicked();

 void button_open_project_clicked();
 void button_preview_project_clicked();

 void button_save_all_clicked();



// void run_load_started(QString url);

 void scale_document(int scale);

// void central_web_view_context_menu(QPoint);
 //?void http_finished(QNetworkReply*);


};

} } //_RZNS(CTQ)

#endif
