
#ifndef CTQ_APPLICATION_STATE__H
#define CTQ_APPLICATION_STATE__H


#include <QString>

#include <QMap>


#include "accessors.h"

#include "flags.h"

#include "rzns.h"

class QDateTime;

RZNS_(CTQ)
//namespace RZ{ namespace CLG{


class CTQ_Comment;
class CTQ_Antemodel;

class CTQ_Document_Web_Page;


class CTQ_Application_State
{
 CTQ_Antemodel* ante_model_;

 QDateTime* when_last_saved_;


// int number_of_users_;

 QMap<QString, QString> saved_xml_by_url_;

 typedef QMap<QString, QString> saved_xml_by_url_type;

public:


 ACCESSORS__CGET(CTQ_Antemodel* ,ante_model)
 ACCESSORS__RGET(saved_xml_by_url_type ,saved_xml_by_url)

 CTQ_Application_State(CTQ_Antemodel* ante_model);

 void absorb_data(QByteArray& qba);
 void supply_data(QByteArray& qba);

 void declare_saved_now();
 void init_when_last_saved(QDateTime qdt);

 QString get_last_saved_string();


 void add_saved_xml(QString url, QString xml);
 QString get_saved_xml(QString url);

 //?
 void add_saved_web_page(QString url, CTQ_Document_Web_Page* wp);

};

_RZNS(CTQ)
//} } //_RZNS(CLG)

#endif
