
#include "ctq-data-manager.h"

#include "ctq-data-object-bridge.h"

#include "ctq-application-state.h"

#include "silotypes/ctq-event.h"

#include "silotypes/ctq-project/ctq-project-initial.h"
#include "silotypes/ctq-project/ctq-project-silo.h"
#include "silotypes/ctq-project/ctq-project-record.h"
#include "silotypes/ctq-project/ctq-project.h"

//?
#include "qunqlite-callback-parser.h"

//?
#include "rz-gui-library/rz-send-email-dialog/rz-email-message.h"

#include <QFileInfo>

#include <QRegularExpression>

#include <QDebug>


USING_RZNS(CTQ)

CTQ_Data_Manager::CTQ_Data_Manager()
 : data_object_bridge_(new CTQ_Data_Object_Bridge), current_type_id_count_(0)
{

}

int CTQ_Data_Manager::init_db(QString database_directory, QString database_file_name)
{
 QString* args[2] {&database_directory, &database_file_name};
 return callback("DB_Create_Or_Open", 2, args);

// current_dialog_db_ = new CTQ__Dialog_db(this, data_root, file_name);
// current_comment_db_ = new CTQ__Comment_db(current_dialog_db_);
// current_user_db_ = new CTQ__User_db(current_dialog_db_);
}

QString CTQ_Data_Manager::get_last_error_code()
{
 return error_callback_();
}

QString CTQ_Data_Manager::get_db_string_value(QString key)
{
 QString string_result;
 int call_result = callback("Retrieve_Str_Str", key, QString(), &string_result);
 return string_result;
}

QString CTQ_Data_Manager::get_db_path_value()
{
 QString result = get_db_string_value("DBPath");
 if(result.isEmpty())
 {
  return QString("<ERROR: %1>").arg(get_last_error_code());
 }
 return result;
}

QString CTQ_Data_Manager::get_db_last_open_value()
{
 QString result = get_db_string_value("LastOpen");
 if(result.isEmpty())
 {
  return QString("<ERROR: %1>").arg(get_last_error_code());
 }
 return result;
}

void CTQ_Data_Manager::load_project_list(QList<CTQ_Project_Record*>& projects)
{
 int max = ctq_project_silo_->record_count();
 for(int i = 0; i < max; ++i)
 {
  CTQ_Project_Record* pror = load_project(i + 1);
  projects.push_back(pror);
 }
}


//?
void CTQ_Data_Manager::save_last_email(RZ_Email_Message& rem)
{
 QSharedPointer<QByteArray> qba(new QByteArray);
 rem.supply_data(*qba);

 QString key = "LastEmail";

 void* args[2] = {&key, &qba};
 callback("DB_Save_Last_Email", 2, args);

 //?callback_commit();

}


void CTQ_Data_Manager::callback_commit()
{
 callback("DB_Commit", 0, nullptr);
}

//?
void CTQ_Data_Manager::load_last_email(RZ_Email_Message& rem)
{
 QString key = "LastEmail";
 QSharedPointer<QByteArray> qba;

 void* args[2] = {&key, &qba};
 callback("DB_Load_Last_Email", 2, args);
 if(qba)
 {
  rem.absorb_data(*qba);
 }
}



void CTQ_Data_Manager::init_dialog_db(QString data_root, QString file_name)
{
// current_dialog_db_ = new CTQ__Dialog_db(this, data_root, file_name);
// current_comment_db_ = new CTQ__Comment_db(current_dialog_db_);
// current_user_db_ = new CTQ__User_db(current_dialog_db_);
}


CTQ_Event* CTQ_Data_Manager::load_event_by_date(QDate date)
{
 QString code = date.toString(Qt::ISODate);
 return load_event(code);
}


int CTQ_Data_Manager::load_all_events(QList<CTQ_Event*>& events)
{
 QStringList keys;
 QRegularExpression rx("\\d{4}-\\d{2}-\\d{2}");

 void* args[2] = {&rx, &keys};

 callback("Regex_Key_Cursor", 2, args);

 for(QString k : keys)
 {
  CTQ_Event* pdc = load_event(k);
  events.push_back(pdc);
 }
 return 0;
}

int CTQ_Data_Manager::save_event(QString code, CTQ_Event* event)
{
 QSharedPointer<QByteArray> qba(new QByteArray);
 QString key = code;

 event->supply_data(*qba);
 void* args[2] = {&key, &qba};
 int result = callback("DB_Save_Event", 2, args);
 return result;

}

CTQ_Event* CTQ_Data_Manager::load_event(QString code)
{
 QSharedPointer<QByteArray> qba(new QByteArray);

 QString key = code;

 void* args[2] = {&key, &qba};
 callback("DB_Load_Event", 2, args);

 CTQ_Event* result;
 if(qba->length() > 0)
 {
  result = new CTQ_Event(this);
  result->absorb_data(*qba);
 }
 else
 {
  result = nullptr;
 }
 return result;
}


CTQ_Project* CTQ_Data_Manager::load_project(QString code)
{
 return nullptr;

}


CTQ_Project_Record* CTQ_Data_Manager::load_project(int uid)
{
 QString key = QString("%1-%2").arg(ctq_project_silo_->type_id()).arg(uid);

 QSharedPointer<QByteArray> qba(new QByteArray);

 void* args[2] = {&key, &qba};
 callback("DB_Load_Project", 2, args);

 CTQ_Project_Record* result;
 if(qba->length() > 0)
 {
  result = new CTQ_Project_Record(this);
  result->absorb_data(*qba);
 }
 else
 {
  result = nullptr;
 }
 return result;
}

QString CTQ_Data_Manager::check_project_code(CTQ_Project_Record& pror)
{
 return get_project_code(pror.name(), pror.local_folder());
}

void CTQ_Data_Manager::save_project_code(CTQ_Project_Record& pror)
{
 save_project_code(pror.name(), pror.local_folder(),
   ctq_project_silo_->type_id(), pror.uid());
}

int CTQ_Data_Manager::init_type_id_count()
{
 QString key = "Global:Type_Id_Count";
 QString string_result;
 int call_result = callback("Retrieve_Str_Str", key, QString(), &string_result);
 if(call_result == QUnQLite_Callback_Parser::All_Ok)
 {
  current_type_id_count_ = string_result.toInt();
 }
 else if(call_result == QUnQLite_Callback_Parser::Retrieve_Problem)
 {
  current_type_id_count_ = 0;
 }
 return call_result;
}

int CTQ_Data_Manager::save_type_id_count()
{
 QString key = "Global:Type_Id_Count";
 QString value = QString::number(current_type_id_count_);
 int call_result = callback("Save_Str_Str", key, value);
 return call_result;
}

int CTQ_Data_Manager::get_silo_record_count(QString type_name)
{
 int result = 0;
 QString key = QString("Silo_Record_Count:%1").arg(type_name);

 QString string_result;
 int call_result = callback("Retrieve_Str_Str", key, QString(), &string_result);
 if(call_result == QUnQLite_Callback_Parser::All_Ok)
 {
  result = string_result.toInt();
 }
 else if(call_result == QUnQLite_Callback_Parser::Retrieve_Problem)
 {
  result = 0;
 }
 else
 {
  //?
 }
 return result;
}


int CTQ_Data_Manager::save_silo_record_count(QString type_name, int value)
{
 QString key = QString("Silo_Record_Count:%1").arg(type_name);
 int result = callback("Save_Str_Str", key, QString::number(value));
 return result;
}



int CTQ_Data_Manager::get_type_id(QString type_name)
{
 int result = 0;
 QString key = QString("Type_Id:%1").arg(type_name);

 QString string_result;
 int call_result = callback("Retrieve_Str_Str", key, QString(), &string_result);
 if(call_result == QUnQLite_Callback_Parser::All_Ok)
 {
  result = string_result.toInt();
 }
 else if(call_result == QUnQLite_Callback_Parser::Retrieve_Problem)
 {
  result = ++current_type_id_count_;
  save_type_id_count();
  save_type_id(type_name, result);
 }
 else
 {
  //?
 }
 return result;
}


int CTQ_Data_Manager::save_type_id(QString type_name, int value)
{
 QString key = QString("Type_Id:%1").arg(type_name);
 int result = callback("Save_Str_Str", key, QString::number(value));
 return result;
}



void CTQ_Data_Manager::init_silos()
{
 ctq_project_silo_ = new CTQ_Project_Silo
   (get_silo_record_count("CTQ_Project_Silo"),
    get_type_id("CTQ_Project_Silo"), "CTQ_Project_Silo" );

}

bool CTQ_Data_Manager::save_project(const CTQ_Project& project)
{
 QString key = QString("%1-%2").arg(ctq_project_silo_->type_id()).arg(project.uid());

 QSharedPointer<QByteArray> qba(new QByteArray);

 project.supply_data(*qba);
 void* args[2] = {&key, &qba};
 int result = callback("DB_Save_Project", 2, args);
 return result == QUnQLite_Callback_Parser::All_Ok;
 //?return result;
}

void CTQ_Data_Manager::save_project_code(QString name, QString local_folder,
  int type_id, int uid)
{
 QPair<QString, QString> key = {name, local_folder};

 QString value = QString("?%1-%2").arg(type_id).arg(uid);

 void* args[2] = {&key, &value};

 int result = callback("DB_Save_Project_Code", 2, args);

 //?return result;

}

QString CTQ_Data_Manager::get_project_code(QString name, QString local_folder)
{
 //?int result = 0;
 //QSharedPointer<QByteArray> qba(new QByteArray);

 QString result;

 QPair<QString, QString> key = {name, local_folder};

 void* args[2] = {&key, &result};

 callback("DB_Get_Project_Code", 2, args);

//?
// if(qba->length() > 0)
// {
//  result = QString::fromLatin1(*qba);
// }

 return result;
}


int CTQ_Data_Manager::callback(QString message, int arglength, void* data)
{
 return allobase_callback_(message, arglength, data);
}

int CTQ_Data_Manager::callback(QString message, QString key, QString value)
{
 return index_callback_(message, key, value, nullptr);
}

int CTQ_Data_Manager::callback(QString message, QString key, QString value, QString* ref)
{
 return index_callback_(message, key, value, ref);
}
