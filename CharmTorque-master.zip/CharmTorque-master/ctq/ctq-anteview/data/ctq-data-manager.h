
#ifndef CTQ_DATA_MANAGER__H
#define CTQ_DATA_MANAGER__H


#include <QString>
#include <QMainWindow>
#include <QUrl>

#include <functional>

#include "accessors.h"

#include "flags.h"

#include "qunqlite-callback-parser.h"

#include "rzns.h"

RZNS_(GUI)

 class RZ_Email_Message;

_RZNS(GUI)

USING_RZNS(GUI)


RZNS_(CTQ)
//namespace RZ{ namespace CTQ{

class CTQ_Data_Object_Bridge;
class CTQ_Resource;
class CTQ_Dialog;
class CTQ_Comment;
class CTQ__Comment_db;
class CTQ__Comment_data;
class CTQ__User_db;
class CTQ__User_data;
class CTQ_Application_State;

class CTQ_Stored_Web_State;

class CTQ_Application_Comment_State;
class CTQ_Antemodel;
class CTQ_User;

class CTQ_Document_Web_Page;

class CTQ_Document_XML;
class CTQ_Document_Container;


class CTQ_Data_Object_Bridge;

class CTQ_Event;
class CTQ_Project;
class CTQ_Project_Initial;
class CTQ_Project_Silo;
class CTQ_Project_Record;

class CTQ_Data_Manager  //?: CTQ_Data_Callback_Manager
{
 CTQ_Data_Object_Bridge* data_object_bridge_;

 typedef std::function<int(QString message, int arglength, void* data)> allobase_callback_type;
 typedef std::function<int(QString message, QString key, QString value, QString* ref)> index_callback_type;
 typedef std::function<QString()> error_callback_type;

 allobase_callback_type allobase_callback_;
 index_callback_type index_callback_;
 error_callback_type error_callback_;

 int current_type_id_count_;

 CTQ_Project_Silo* ctq_project_silo_;

 void check_current_comment_data();
 void check_current_user_data();



public:

 ACCESSORS(allobase_callback_type ,allobase_callback)
 ACCESSORS(index_callback_type ,index_callback)
 ACCESSORS(error_callback_type ,error_callback)

 ACCESSORS(CTQ_Project_Silo* ,ctq_project_silo)


 CTQ_Data_Manager();


 template<typename Silo_type, typename Record_type>
 int save_new_silo_joinee(Silo_type& st, Record_type& rt)
 {
  QSharedPointer<QByteArray> qba(new QByteArray);
  rt.supply_data(*qba);
  QString key = QString("%1-%2").arg(st.type_id()).arg(rt.uid());
  void* args[2] = {&key, &qba};
  return callback("DB_Save_Generic_Data", 2, args);
 }

 template<typename Silo_type, typename Record_type>
 int load_silo_joinee(Silo_type& st, Record_type& rt)
 {
  QSharedPointer<QByteArray> qba(new QByteArray);
  QString key = QString("%1-%2").arg(st.type_id()).arg(rt.uid());
  void* args[2] = {&key, &qba};
  int call_result = callback("DB_Load_Generic_Data", 2, args);
  if(call_result == QUnQLite_Callback_Parser::All_Ok)
  {
   rt.absorb_data(*qba);
  }
  return call_result;
 }


 void init_dialog_db(QString data_root, QString file_name);
 void load_global_dialog_data();
 void save_current_dialog();

 int load_all_events(QList<CTQ_Event*>& events);
 CTQ_Event* load_event_by_date(QDate date);
 int save_event(QString code, CTQ_Event* event);
 CTQ_Event* load_event(QString code);

 CTQ_Project* load_project(QString code);
 QString get_project_code(QString name, QString local_folder);

 void save_project_code(QString name, QString local_folder,
   int type_id, int uid);

 bool save_project(const CTQ_Project& project);

 void save_project_code(CTQ_Project_Record& pror);

 QString check_project_code(CTQ_Project_Record& pror);

 template<typename Silo_type>
 int check_save_silo_record_count(Silo_type& st)
 {
  if(int new_record_count = st.check_save_record_count() )
  {
   return save_silo_record_count(st.type_name(), new_record_count);
  }
  else
  {
   return QUnQLite_Callback_Parser::All_Up_To_Date;
  }
 }

 void save_last_email(RZ_Email_Message& rem);
 void load_last_email(RZ_Email_Message& rem);
 void load_project_list(QList<CTQ_Project_Record*>& projects);
 CTQ_Project_Record* load_project(int uid);

 void callback_commit();


// void save_stored_web_page(QString indicator, CTQ_Document_Web_Page*);
// void save_stored_web_page(CTQ_Document_Web_Page* wp);
// CTQ_User* load_user(CTQ_User* user);
// void save_user(CTQ_User* user, CTQ_Application_State& qda);
// CTQ_Document_Web_Page* load_stored_web_page(QString indicator);

 int init_db(QString data_root, QString file_name);

 void init_silos();
 int init_type_id_count();
 int save_type_id_count();
 int get_silo_record_count(QString type_name);
 int save_silo_record_count(QString type_name, int value);
 int get_type_id(QString type_name);
 int save_type_id(QString type_name, int value);


 void load_application_state(CTQ_Application_State& qda);
 void save_application_state(CTQ_Application_State& qda);

 void save_document_container_state(CTQ_Document_Container& qdc);
 void load_document_container_state(CTQ_Document_Container& qdc);

 QString get_last_error_code();
 QString get_db_path_value();
 QString get_db_last_open_value();
 QString get_db_string_value(QString key);


 int callback(QString message, int arglength, void* data);

 int callback(QString message, QString key, QString value);

 int callback(QString message, QString key, QString value, QString* ref);

 // int callback(QString message, void* data);
// int callback(QString message);


};

_RZNS(CTQ)
//} } //_RZNS(CTQ)

#endif
