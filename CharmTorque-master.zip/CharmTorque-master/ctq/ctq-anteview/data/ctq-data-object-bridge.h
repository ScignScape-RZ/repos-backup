
#ifndef CTQ_DATA_OBJECT_BRIDGE__H
#define CTQ_DATA_OBJECT_BRIDGE__H


#include <QString>
#include <QMainWindow>
#include <QUrl>

#include <functional>

#include "accessors.h"

#include "flags.h"


#include "rzns.h"

RZNS_(CTQ)
//namespace RZ{ namespace CLG{


class CTQ_Data_Object_Bridge
{
public:

 CTQ_Data_Object_Bridge();

 template<typename OBJECT_Type, typename DATA_Type>
 void init_object(OBJECT_Type& obj, DATA_Type& data);

 template<typename OBJECT_Type>
 void init_paleo_object(OBJECT_Type& obj);

 template<typename OBJECT_Type, typename DATA_Type>
 void init_data(OBJECT_Type& obj, DATA_Type& data);

};

_RZNS(CTQ)
//} } //_RZNS(CLG)

#endif
