
#include "new-project-dialog.h"

#include "ctq-antemodel.h";

#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>

#include <QPlainTextEdit>
#include <QTextStream>

#include <QTableWidget>

#include <QMessageBox>

#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrlQuery>

#include <QHeaderView>

#include <QListWidget>

#include "silotypes/ctq-project/ctq-project.h"
#include "silotypes/ctq-project/ctq-project-initial.h"
#include "silotypes/ctq-project/ctq-project-editor.h"

USING_RZNS(CTQ)

New_Project_Dialog::New_Project_Dialog(Editing_Mode editing_mode, QWidget* parent,
  CTQ_Antemodel* antemodel, CTQ_Project* current_project)//, QString url, QWN_XMLDB_Configuration* config)
 : QDialog(parent), editing_mode_(editing_mode),
   antemodel_(antemodel), current_project_record_(nullptr)//, config_(config)
{
 if(current_project)
 {
  current_project_record_ = current_project;
 }

 // //  These might not be needed
 choose_project_combo_box_ = nullptr;
 choose_project_label_ = nullptr;
 choose_project_layout_ = nullptr;

 button_box_ = new QDialogButtonBox(this);

 //?url_label_ = new QLabel(this);
  //?url_label_->setText(url);

// name_qle_ = new QLineEdit(this);

 button_ok_ = new QPushButton("OK");
 button_proceed_ = new QPushButton("Proceed");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

 button_proceed_->setDefault(false);
 button_proceed_->setAutoDefault(false);

 button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);


 connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));

 main_layout_ = new QVBoxLayout();

 top_layout_ = new QFormLayout();

 name_label_  = new QLabel("Project Name", this);
 name_line_edit_ = new QLineEdit(this);

 remote_address_label_ = new QLabel("Remote Address", this);
 remote_address_line_edit_ = new QLineEdit(this);

// location_combo_box_ = new QComboBox(this);
// location_combo_box_->addItem("", "N/A");
// location_combo_box_->setEditable(true);

 top_layout_->addRow(name_label_, name_line_edit_);

 top_layout_->addRow(remote_address_label_, remote_address_line_edit_);

 local_folder_label_  = new QLabel("Local Folder", this);
 local_folder_line_edit_ = new QLineEdit(this);

 local_port_label_ = new QLabel("Local Port", this);
 local_port_line_edit_ = new QLineEdit(this);

 docker_port_label_ = new QLabel("Docker Port", this);
 docker_port_line_edit_ = new QLineEdit(this);

 QString colorful_button_style_sheet =
  "QPushButton:hover {background:rgb(240,190,150);"
  " border-left: 4px groove rgb(240,190,150); "
  " border-right: 4px ridge rgb(240,190,150); "
  "}\n"
  "QPushButton{ padding:1px;  border: 2px solid rgb(240,190,150); "
  "  border-bottom: 1px solid #CEF51D; "
  " border-radius: 6px; "
  " background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, "
  "  stop: 0 white, stop: 0.1 #C0C0C0, stop: 0.6 #CC"
  "C6BC, stop: 0.8 #ECCFA0, stop: 0.9 darkred,  stop: 1 brown"
  "); min-width: 80px; }";



 QString colorful_button_style_sheet_down =
  "QPushButton {background:rgb(190,190,230);padding-left:20;padding-right:20;padding-top:0;padding-bottom:0;"
  " border-left: 4px groove rgb(240,190,150); "
  " border-right: 4px ridge rgb(240,190,150); "
  "}\n";


 QFrame* line01 = new QFrame(this);
     line01->setGeometry(QRect(320, 150, 118, 3));
     line01->setFrameShape(QFrame::HLine);
     line01->setFrameShadow(QFrame::Raised);
 QFrame* line02 = new QFrame(this);
         line02->setGeometry(QRect(320, 150, 118, 1));
         line02->setFrameShape(QFrame::HLine);
         line02->setFrameShadow(QFrame::Sunken);

 line01->setStyleSheet("QFrame{background:rgba(255,200,200,0.7)}");
 line02->setStyleSheet("QFrame{background:rgba(255,200,200,0.7)}");


 local_folder_frame_ = new QFrame(this);
 local_folder_layout_ = new QHBoxLayout;
 button_local_folder_select_ = new QPushButton("Select", this);
 button_local_folder_select_->setStyleSheet(colorful_button_style_sheet);

 connect(button_local_folder_select_, SIGNAL(clicked()),
   this, SLOT(button_local_folder_select_clicked()));


 local_folder_layout_->addStretch();
 local_folder_layout_->addWidget(button_local_folder_select_);
 local_folder_layout_->addStretch();

 local_folder_frame_->setLayout(local_folder_layout_);

 top_layout_->insertRow(-1, line01);

 top_layout_->addRow(local_folder_label_, local_folder_line_edit_);

 top_layout_->insertRow(-1, local_folder_frame_);
 top_layout_->insertRow(-1, line02);

 top_layout_->addRow(local_port_label_, local_port_line_edit_);
 top_layout_->addRow(docker_port_label_, docker_port_line_edit_);

// top_layout_->addRow(state_label_, state_combo_box_);


// name_of_primary_care_provider_label_ = new QLabel("Name of Primary Care Provider", this);
// name_of_primary_care_provider_line_edit_ = new QLineEdit(this);
// top_layout_->addRow(name_of_primary_care_provider_label_, name_of_primary_care_provider_line_edit_);

// most_recent_visit_label_ = new QLabel("Last Visit to PCP", this);
// most_recent_visit_layout_ = new QHBoxLayout;
// most_recent_visit_line_edit_ = new QLineEdit(this);
// most_recent_visit_button_ = new QPushButton("Calendar");

// most_recent_visit_button_->setStyleSheet(colorful_button_style_sheet);
// most_recent_visit_layout_->addWidget(most_recent_visit_line_edit_);
// most_recent_visit_layout_->addWidget(most_recent_visit_button_);
// top_layout_->addRow(most_recent_visit_label_, most_recent_visit_layout_);



// symptoms_label_ = new QLabel("Describe your Symptoms", this);

// symptoms_buttons_ = new QHBoxLayout;
// symptoms_pictures_button_ = new QPushButton("Pictures", this);
// symptoms_activities_button_ = new QPushButton("Activities", this);
////? symptoms_list_button_ = new QPushButton("Check List", this);

// symptoms_pictures_button_->setStyleSheet(colorful_button_style_sheet);
// symptoms_activities_button_->setStyleSheet(colorful_button_style_sheet);
// //? symptoms_list_button_->setStyleSheet(colorful_button_style_sheet);

// symptoms_buttons_->addStretch();
// symptoms_buttons_->addWidget(symptoms_pictures_button_);
// symptoms_buttons_->addStretch();
// symptoms_buttons_->addWidget(symptoms_activities_button_);
// symptoms_buttons_->addStretch();
// // symptoms_buttons_->addWidget(symptoms_list_button_);
// // symptoms_buttons_->addStretch();

// symptoms_text_ = new QHBoxLayout;


 description_text_label_ = new QLabel("Describe the project (opens a text entry area):", this);
 description_text_button_ = new QPushButton("Describe", this);
 description_text_button_->setStyleSheet(colorful_button_style_sheet);

 QFont font = description_text_button_->font();
 font.setPointSize(9);
 description_text_button_->setFont(font);

 description_text_layout_ = new QHBoxLayout;

 //?
 description_text_layout_->addStretch();
 description_text_layout_->addWidget(description_text_label_);
 //?symptoms_text_->addStretch();
 description_text_layout_->addWidget(description_text_button_);
////? symptoms_text_->addStretch();


 QFrame* line1 = new QFrame(this);
     line1->setGeometry(QRect(320, 150, 118, 3));
     line1->setFrameShape(QFrame::HLine);
     line1->setFrameShadow(QFrame::Raised);
 QFrame* line2 = new QFrame(this);
         line2->setGeometry(QRect(320, 150, 118, 1));
         line2->setFrameShape(QFrame::HLine);
         line2->setFrameShadow(QFrame::Sunken);
 //line2->setB
 line1->setStyleSheet("QFrame{background:rgba(255,200,200,0.7)}");
 line2->setStyleSheet("QFrame{background:rgba(255,200,200,0.7)}");

 top_layout_->insertRow(-1, line1);
 //top_layout_->addRow(description_label_, symptoms_buttons_);
 top_layout_->insertRow(-1, description_text_layout_);
 top_layout_->insertRow(-1, line2);


 mid_layout_ = new QFormLayout;

//? mid_layout_->addRow(most_recent_visit_label_, most_recent_visit_layout_);


//? symptoms_list_box_ = new QListWidget(this);
//? top_layout_->insertRow(-1, symptoms_list_box_);


 secondary_addresses_table_widget_ = new QTableWidget(this);
 secondary_addresses_table_widget_->setColumnCount(3);
 secondary_addresses_table_widget_->setRowCount(0);

 secondary_addresses_table_widget_->verticalHeader()->setVisible(false);
 secondary_addresses_table_widget_->horizontalHeader()->setVisible(false);

 secondary_addresses_table_widget_->horizontalHeader()->setStretchLastSection(true);

 //?secondary_addresses_frame_ = new QFrame(this);
 secondary_addresses_group_ = new QGroupBox("Secondary Addresses ...", this);
 secondary_addresses_scroll_area_ = new QScrollArea(this);

 secondary_addresses_group_layout_ = new QVBoxLayout;

 //secondary_addresses_group_layout_->addLayout(secondary_addresses_layout_);
 secondary_addresses_group_layout_->addWidget(secondary_addresses_table_widget_);

 //secondary_addresses_group_->setMinimumHeight(200);

// connect(secondary_addresses_table_widget_, SIGNAL(cellDoubleClicked(int,int)),
//   this, SLOT(secondary_addresses_table_widget_cell_double_clicked(int,int)));

 connect(secondary_addresses_table_widget_, SIGNAL(cellClicked(int,int)),
   this, SLOT(secondary_addresses_table_widget_cell_clicked(int,int)));

 secondary_addresses_table_widget_->setContextMenuPolicy(Qt::ActionsContextMenu);

 //connect(artist_clear_fields_action, SIGNAL(triggered()), this, SLOT(artist_clear_fields_action_triggered()));
 //?DEFAULT_CONNECT_(artist_clear_fields_action ,triggered)


 secondary_addresses_table_widget_->horizontalHeader()->setSectionResizeMode(1, QHeaderView::Stretch);
 //?secondary_addresses_table_widget_->horizontalHeader()->setSectionResizeMode(2, QHeaderView::Fixed);

 //secondary_addresses_table_widget_->horizontalHeader()->setStretchLastSection(false);

 secondary_addresses_table_widget_->verticalHeader()->setStretchLastSection(false);
 secondary_addresses_table_widget_->resizeRowsToContents();
 //secondary_addresses_table_widget_->verticalHeader()->setStretchLastSection(true);
 secondary_addresses_table_widget_->setSizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);

 button_more_secondary_addresses_ = new QPushButton("Add Row...", this);

 button_more_secondary_addresses_->setStyleSheet(colorful_button_style_sheet);

 secondary_addresses_table_widget_->setRowHeight(0, 30);
 secondary_addresses_table_widget_->setMaximumHeight(30);

 //secondary_addresses_table_widget_->setColumnWidth(2, 20);

 connect(button_more_secondary_addresses_, SIGNAL(clicked()),
   this, SLOT(button_more_secondary_addresses_clicked()));

//? DEFAULT_CONNECT(button_more_secondary_addresses_ ,clicked)


 button_more_secondary_addresses_layout_ = new QHBoxLayout;

 button_more_secondary_addresses_layout_->addStretch();

 button_more_secondary_addresses_layout_->addWidget(button_more_secondary_addresses_);
 button_more_secondary_addresses_layout_->addStretch();

 secondary_addresses_group_layout_->addLayout(button_more_secondary_addresses_layout_);

 secondary_addresses_group_->setLayout(secondary_addresses_group_layout_);

 secondary_addresses_scroll_area_->setWidget(secondary_addresses_group_);

 secondary_addresses_scroll_area_->setWidgetResizable(true);

 // //  set from 150 to 180 for a screen shot ...
 secondary_addresses_scroll_area_->setMinimumHeight(180);

 secondary_addresses_scroll_area_->setFrameShape(QFrame::Panel);

 secondary_addresses_scroll_area_->setFrameShadow(QFrame::Raised);

 //secondary_addresses_scroll_area_->setStyleSheet("border-color:solid cyan 1px;");

 mid_layout_->insertRow(-1, secondary_addresses_scroll_area_);

//? main_layout_->addWidget(secondary_addresses_scroll_area_);


// query_file_label_ = new QLabel("Query File: ");
// query_file_line_edit_ = new QLineEdit();
// top_layout_->addRow(query_file_label_, query_file_line_edit_);


 main_layout_->addLayout(top_layout_);
 main_layout_->addStretch();
 main_layout_->addLayout(mid_layout_);
 main_layout_->addStretch();

 main_layout_->addWidget(button_box_);

 setLayout(main_layout_);

 add_secondary_address_row();
// // connect(api_choice_combo_box_, SIGNAL(currentIndexChanged(int)),
//  this, SLOT(set_query_file_from_api_choice(int)));

 if(editing_mode_ == Editing_Mode::Select_Existing)
 {
  init_project_list();
 }
 else if(editing_mode_ == Editing_Mode::Edit_Existing)
 {
  init_form_from_current_project_record();
 }

 show();
}


void New_Project_Dialog::handle_project_combo_box_index_changed(int index)
{
 if(index == 0)
 {
  current_project_record_ = nullptr;
  // nothing to do here
  return;
 }
 --index;
 CTQ_Project_Record* record = projects_[index];
 if(record != current_project_record_)
 {
  current_project_record_ = record;
  init_form_from_current_project_record();
  Q_EMIT(selected_project_changed(current_project_record_));
 }
 button_ok_->setEnabled(true);
}

void New_Project_Dialog::init_form_from_current_project_record()
{
 name_line_edit_->setText(current_project_record_->name());
 remote_address_line_edit_->setText(current_project_record_->remote_address());
 local_folder_line_edit_->setText(current_project_record_->local_folder());
 local_port_line_edit_->setText(QString::number(current_project_record_->local_port()));
 docker_port_line_edit_->setText(QString::number(current_project_record_->docker_port()));

 QStringList qsl = current_project_record_->secondary_addresses();

 QStringListIterator it(qsl);
 int i = 0;
 while(it.hasNext())
 {
  QString s = it.next();
  set_secondary_address(s, i);
  if(it.hasNext())
  {
   add_secondary_address_row();
  }
  ++i;
 }

 secondary_addresses_table_widget_->setMaximumHeight(
   secondary_addresses_table_widget_->maximumHeight() + i*secondary_addresses_table_widget_->rowHeight(0));

 secondary_addresses_table_widget_->setMinimumHeight(
   secondary_addresses_table_widget_->maximumHeight() + 2);

}


void New_Project_Dialog::init_project_list()
{
 antemodel_->load_project_list(projects_);

 if(projects_.isEmpty())
 {
  QMessageBox::information(this, "No projects found!",
    "No projects are saved.  Please create a new one");
  return;
 }
 if(!choose_project_label_)
 {
  choose_project_label_ = new QLabel("Choose Project", this);
 }
 if(!choose_project_combo_box_)
 {
  choose_project_combo_box_ = new QComboBox(this);
  connect(choose_project_combo_box_, SIGNAL(currentIndexChanged(int)),
    this, SLOT(handle_project_combo_box_index_changed(int)));
 }
 if(!choose_project_layout_)
 {
  choose_project_layout_ = new QHBoxLayout;
 }
 choose_project_layout_->addWidget(choose_project_label_);
 choose_project_layout_->addWidget(choose_project_combo_box_);
 main_layout_->insertLayout(0, choose_project_layout_);
 choose_project_combo_box_->addItem("<no project>", 0);
 int i = 0;
 for(CTQ_Project_Record* pror : projects_)
 {
  ++i;
  QString item_label = QString("%1 (%2)").arg(pror->name()).arg(pror->local_folder());
  choose_project_combo_box_->addItem(item_label, i);
 }
}



void New_Project_Dialog::button_local_folder_select_clicked()
{
 QString dir = QFileDialog::getExistingDirectory (this, "Select Folder");
 if(!dir.isEmpty())
 {
  local_folder_line_edit_->setText(dir);
 }
}

void New_Project_Dialog::activate_search(QString text)
{
// named_entity_line_edit_->setText(text);
// QString ch = api_choice_combo_box_->currentData().toString();
// current_request_url_ = antemodel_->get_request_url_from_api_name(ch, text);
// url_text_edit_->setText(current_request_url_);
}

void New_Project_Dialog::read_file(QString path, QPlainTextEdit* qpte)
{
 QFile file(path);
 if(file.open(QIODevice::ReadOnly | QIODevice::Text))
 {
  QTextStream in_stream(&file);
  QString result = in_stream.readAll();
  qpte->setPlainText(result);
 }
}

Secondary_Address_Row::Secondary_Address_Row(QWidget* parent)
  :
   secondary_address_index(new QTableWidgetItem),
   secondary_address_description(new QTableWidgetItem),
   secondary_address_options(new QTableWidgetItem),
   index(new QLabel(parent)),
   description(new QLineEdit(parent)),
   options_frame(new QFrame(parent)),

//?   options(new QLabel("Options...", options_frame)),
   options(new QLabel("...", options_frame)),
   cut(new QPushButton(QChar(0xD7), options_frame)),
   options_layout(new QVBoxLayout),
   options_label_layout(new QHBoxLayout),
   options_cut_layout(new QHBoxLayout)
{
 options_cut_layout->addStretch();
 options_cut_layout->addWidget(cut);
 options_label_layout->addStretch();
 options_label_layout->addWidget(options);
 options_label_layout->addStretch();

 options_cut_layout->setSpacing(0);
 options_cut_layout->setMargin(0);

 options_layout->setSpacing(0);
 options_layout->setMargin(0);
 options_label_layout->setSpacing(0);
 options_label_layout->setMargin(0);


 options_layout->addLayout(options_cut_layout);
 options_layout->addLayout(options_label_layout);


 options_label_layout->setContentsMargins(0, 0, 0, 0);

 options_layout->setContentsMargins(0, 0, 0, 0);
 options_cut_layout->setContentsMargins(0, 0, 0, 0);

 options_frame->setLayout(options_layout);

 //options_frame->setStyleSheet("border:solid red 3px;");


 QString ss = //"QFrame{background: red; margin:0px;padding:0px}"
   "QPushButton{margin:0px;padding:0px;border:none;"
   "background-color:qlineargradient(x1:0,y1:0,x2:0,y2:1,"
                                          "stop:0#eaebfe,stop:1#76878a);"
   //"background-color:pink;"
   "}"
   "QPushButton:hover{background: white; margin:0px;padding:0px;border:none}"
   "QFrame{background: lavender; margin:0px;padding:0px;}"
   "QLabel:hover{background: pink; margin:0px;padding:0px}"
   ;
 options_frame->setStyleSheet(ss);

 //?options_frame->setMaximumWidth(20);

// twi_code->setFlags(Qt::ItemIsEditable | Qt::ItemIsEnabled);
// twi_name->setFlags(Qt::ItemIsEditable | Qt::ItemIsEnabled);
 //artists_table_widget_->setEditTriggers(QAbstractItemView::AllEditTriggers);


}

void New_Project_Dialog::set_secondary_address(QString url, int row)
{
 QWidget* qw = secondary_addresses_table_widget_->cellWidget(row, 1);
 QLineEdit* le = qobject_cast<QLineEdit*>(qw);
 le->setText(url);
}

QString New_Project_Dialog::get_secondary_address(int row)
{
 QWidget* qw = secondary_addresses_table_widget_->cellWidget(row, 1);
 QLineEdit* le = qobject_cast<QLineEdit*>(qw);
 return le->text();
}

void New_Project_Dialog::get_secondary_addresses(QStringList& qsl)
{
 int row_count = secondary_addresses_table_widget_->rowCount();
 for(int i = 0; i < row_count; ++i)
 {
  qsl.push_back(get_secondary_address(i));
 }
}


void New_Project_Dialog::button_more_secondary_addresses_clicked()
{
// if(current_artist_entry_row_ != -1)
// {
//  QMessageBox::information(this, "Add one artist at a time",
//    "Use the current empty fields to provide artist information");
//  return;
// }
 add_secondary_address_row(); //nullptr);

 secondary_addresses_table_widget_->setMaximumHeight(
   secondary_addresses_table_widget_->maximumHeight() + secondary_addresses_table_widget_->rowHeight(0));

 secondary_addresses_table_widget_->setMinimumHeight(
   secondary_addresses_table_widget_->maximumHeight() + 2);

}


void New_Project_Dialog::add_secondary_address_row()
{
 Secondary_Address_Row* row = new Secondary_Address_Row(this);

 int row_count = secondary_addresses_table_widget_->rowCount();

 row->index->setText(QString::number(row_count + 1));
 //?row->index->setMaximumWidth(7);

 //?
 row->index->setStyleSheet("QLabel{font-weight:600;"
                           "font-family: Tahoma;font-style: normal;"
                           "}"
                           ); //ont-size:11pt;font-face:tahoma}");

 row->secondary_address_index->setBackgroundColor(QColor::fromRgb(240,220,240));
// row->index->setBackgroundRole(QPalette::AlternateBase);

 secondary_addresses_table_widget_->setRowCount(row_count + 1);

 //?current_artist_entry_row_ = row_count;
 //?row->cut->setMaximumWidth(50);

 connect(row->cut, &QPushButton::clicked,
         [this, row, row_count]
 {
//  if(row_count == 0 && tda_by_row_.size() <= 1)
//  {
//   //?artist_clear_fields(0);
//   return;
//  }
  secondary_addresses_table_widget_->setMaximumHeight
    (secondary_addresses_table_widget_->maximumHeight() - secondary_addresses_table_widget_->rowHeight(row_count));

  current_secondary_address_row_ = -1;
  secondary_addresses_table_widget_->setMinimumHeight
    (secondary_addresses_table_widget_->maximumHeight());

  secondary_addresses_table_widget_->removeRow(row_count);
//  if(row->artist)
//  {
////?   tda_by_row_.removeOne(row->artist);
//  }
 });

 secondary_addresses_table_widget_->setItem(row_count, 0, row->secondary_address_index);
 secondary_addresses_table_widget_->setItem(row_count, 1, row->secondary_address_description);
 secondary_addresses_table_widget_->setItem(row_count, 2, row->secondary_address_options);
// secondary_addresses_table_widget_->setItem(row_count, 1, row->year);
// secondary_addresses_table_widget_->setItem(row_count, 2, row->description);
// secondary_addresses_table_widget_->setItem(row_count, 3, row->twi_options);


 secondary_addresses_table_widget_->setCellWidget(row_count, 0, row->index);
 secondary_addresses_table_widget_->setCellWidget(row_count, 1, row->description);

 secondary_addresses_table_widget_->setCellWidget(row_count, 2, row->options_frame);

 //secondary_addresses_table_widget_->setColumnWidth(2, 40);

 //secondary_addresses_table_widget_->horizontalHeader()->resizeSection(2, 40);
 //secondary_addresses_table_widget_->setColumnWidth(2, 40);

 secondary_addresses_table_widget_->horizontalHeader()->setStretchLastSection(false);
 //secondary_addresses_table_widget_->setSectionResizeMode(1, QHeaderView::Stretch);
 //secondary_addresses_table_widget_->setColumnWidth(0, 20);

 secondary_addresses_table_widget_->setColumnWidth(2, row->options_frame->width() + 3);

 secondary_addresses_table_widget_->setColumnWidth(0, row->index->width() + 3);


 //row->options_frame->setMaximumWidth(30);

 //?secondary_addresses_table_widget_->horizontalHeader()->setFixedWidth(20);

//?
 if(row_count == 0)
 {
  row->description->setPlaceholderText("Name");
 }

// if(tda)
// {
//  QString c = tda->code();
//  QString n = tda->name();
//  row->code->setText(c);
//  row->name->setText(n);
//  row->artist = tda;
// }

 //?secondary_addresses_layout_->addRow(new_artist_code, new_artist_name);

 //secondary_addresses_group_->update();

 //update();

}




New_Project_Dialog::~New_Project_Dialog()
{
 delete button_ok_;
 delete button_proceed_;
 delete button_cancel_;

// delete url_label_;
// delete name_qle_;
}


void New_Project_Dialog::proceed_with_edits()
{
 button_ok_->setEnabled(true);
  //button_cancel_->setEnabled(false);
 button_proceed_->setEnabled(false);

 QStringList sas;
 get_secondary_addresses(sas);

 //QString sas_str = sas.join("\n");

 QMap<QString, QString> params{{
   { "name", name_line_edit_->text() },
   { "local-folder", local_folder_line_edit_->text() },
   { "#local-port", local_port_line_edit_->text() },
   { "#docker-port", docker_port_line_edit_->text() },
   { "remote-address", remote_address_line_edit_->text() },
   { "description", description_ },
   { "secondary-addresses", sas.join('\n') }
 }};

 CTQ_Project_Editor proe(current_project_record_);

 proe.absorb_string_map(params);

 Q_EMIT(proceed_requested(this, current_project_record_, params));


}


void New_Project_Dialog::proceed()
{
 if(editing_mode_ == New_Project_Dialog::Editing_Mode::Edit_Existing)
 {
  proceed_with_edits();
  return;
 }

 button_ok_->setEnabled(true);
  //button_cancel_->setEnabled(false);
 button_proceed_->setEnabled(false);

 QStringList sas;
 get_secondary_addresses(sas);

 QMap<QString, QString> params {{
   { "name", name_line_edit_->text() },
   { "local-folder", local_folder_line_edit_->text() },
   { "#local-port", local_port_line_edit_->text() },
   { "#docker-port", docker_port_line_edit_->text() },
   { "remote-address", remote_address_line_edit_->text() },
   { "description", description_ },
   { "secondary-addresses", sas.join('\n') }
    }};

 Q_EMIT(proceed_requested(this, current_project_record_, params));


}

void New_Project_Dialog::handle_project_already_exists(QDialog* dlg, CTQ_Project_Initial& proi)
{
 if(this != dlg)
 {
  // // in case two dialogs are both open ...
 }
 QMessageBox msgBox;
 msgBox.setText("Project already exists");
 msgBox.setInformativeText(QString("The project %1 with local folder %2 already exists.")
   .arg(proi.name()).arg(proi.local_folder()));
 msgBox.setStandardButtons(QMessageBox::Ok);
 msgBox.setDefaultButton(QMessageBox::Ok);
 int ret = msgBox.exec();
}

void New_Project_Dialog::handle_save_project_confirmed(QDialog* dlg, CTQ_Project& project)
{
 if(this != dlg)
 {
  // // in case two dialogs are both open ...
 }
 QMessageBox msgBox;
 msgBox.setText("Confirmation");
 msgBox.setInformativeText(QString("The project %1 has been saved.").arg(project.name()));
 msgBox.setStandardButtons(QMessageBox::Ok);
 msgBox.setDefaultButton(QMessageBox::Ok);
 int ret = msgBox.exec();

 button_ok_->setEnabled(true);
 button_cancel_->setEnabled(false);

}

void New_Project_Dialog::handle_save_project_failed(QDialog* dlg, CTQ_Project& project)
{
 if(this != dlg)
 {
  // // in case two dialogs are both open ...
 }
 QMessageBox msgBox;
 msgBox.setText("Error");
 msgBox.setInformativeText(QString("The project %1 could not be saved.").arg(project.name()));
 msgBox.setStandardButtons(QMessageBox::Ok);
 msgBox.setDefaultButton(QMessageBox::Ok);
 int ret = msgBox.exec();

}

void New_Project_Dialog::handle_new_project_confirmed(QDialog* dlg, CTQ_Project& project)
{
 if(this != dlg)
 {
  // // in case two dialogs are both open ...
 }
 QMessageBox msgBox;
 msgBox.setText("Confirmation");
 msgBox.setInformativeText(QString("The new project %1 has been created.").arg(project.name()));
 msgBox.setStandardButtons(QMessageBox::Ok);
 msgBox.setDefaultButton(QMessageBox::Ok);
 int ret = msgBox.exec();

 button_ok_->setEnabled(true);
}

void New_Project_Dialog::select_query_template_file_clicked()
{

}

void New_Project_Dialog::cancel()
{
 Q_EMIT(canceled(this));
// close();
}

void New_Project_Dialog::accept()
{
 Q_EMIT(accepted(this));
// close();
}
