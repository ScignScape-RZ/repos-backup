
#ifndef NEW_PROJECT_DIALOG__H
#define NEW_PROJECT_DIALOG__H


#include <QString>
#include <QMainWindow>

#include <QTextEdit>
//?#include <QWebView>
#include <QLabel>
#include <QPushButton>

#include <QDialog>

#include <QComboBox>

#include "accessors.h"

#include "flags.h"

#include "rzns.h"

//#include "incident-form-dialog.h"

class QPushButton;
class QTextEdit;
class QPlainTextEdit;
class QLineEdit;
class QTabWidget;
class QDialogButtonBox;
class QVBoxLayout;
class QHBoxLayout;
class QCheckBox;
class QFormLayout;
class QSplitter;
class QGridLayout;
class QListWidget;
class QTableWidget;
class QScrollArea;
class QGroupBox;
class QTableWidgetItem;

//RZNS_(QWN)
namespace RZ{ namespace CTQ{

class CTQ_Project_Record;

class CTQ_Antemodel;
class CTQ_Project;
class CTQ_Project_Initial;

struct Secondary_Address_Row
{
 QTableWidgetItem* secondary_address_index;
 //?QTableWidgetItem* secondary_address_year;
 QTableWidgetItem* secondary_address_description;
 QTableWidgetItem* secondary_address_options;

 QLabel* index;
 //?QLineEdit* year;
 QLineEdit* description;

 QFrame* options_frame;
 QVBoxLayout* options_layout;
 QHBoxLayout* options_cut_layout;
 QHBoxLayout* options_label_layout;

 QLabel* options;
 QPushButton* cut;

// CLG_DB_Artist* artist;
// CLG_DB_Author* author;

 //QPushButton* cut_button = new QPushButton(QChar(0xD7), cut_frame);

 Secondary_Address_Row(QWidget* parent = nullptr);

};



class New_Project_Dialog : public QDialog
{
 Q_OBJECT

public:

 enum class Editing_Mode {
  N_A, Create_New, Edit_Existing, Select_Existing, Edit_After_Create
 };

private:

 Editing_Mode editing_mode_;

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QPushButton* button_proceed_;

// QLabel* api_choice_label_;
// QComboBox* api_choice_combo_box_;

 QLabel* name_label_;
 QLineEdit* name_line_edit_;

// QLabel* gender_label_;
// QComboBox* gender_combo_box_;

 QLabel* choose_project_label_;
 QComboBox* choose_project_combo_box_;
 QHBoxLayout* choose_project_layout_;


 QList<CTQ_Project_Record*> projects_;

// QLabel* symptoms_label_;

// QHBoxLayout* symptoms_buttons_;
// QPushButton* symptoms_pictures_button_;
// QPushButton* symptoms_activities_button_;
// // QPushButton* symptoms_list_button_;


 QHBoxLayout* description_text_layout_;
 QLabel* description_text_label_;
 QPushButton* description_text_button_;

// QLabel* name_of_primary_care_provider_label_;
// QLineEdit* name_of_primary_care_provider_line_edit_;

// QLabel* most_recent_visit_label_;
// QHBoxLayout* most_recent_visit_layout_;
// QLineEdit* most_recent_visit_line_edit_;
// QPushButton* most_recent_visit_button_;


//? QListWidget* symptoms_list_box_;

// QComboBox* symptoms_combo_box_;

 QLabel* remote_address_label_;
 QLineEdit* remote_address_line_edit_;
// QComboBox* location_combo_box_;

 QLabel* local_folder_label_;
 QLineEdit* local_folder_line_edit_;

 QLabel* local_port_label_;
 QLineEdit* local_port_line_edit_;

 QLabel* docker_port_label_;
 QLineEdit* docker_port_line_edit_;

 QFrame* local_folder_frame_;
 QHBoxLayout* local_folder_layout_;
 QPushButton* button_local_folder_select_;

 QTableWidget* secondary_addresses_table_widget_;

 QVBoxLayout* secondary_addresses_group_layout_;
 QScrollArea* secondary_addresses_scroll_area_;
 QGroupBox* secondary_addresses_group_;

 QPushButton* button_more_secondary_addresses_;
 QHBoxLayout* button_more_secondary_addresses_layout_;

 int current_secondary_address_row_;

 QString get_secondary_address(int row);
 void get_secondary_addresses(QStringList& qsl);
 void set_secondary_address(QString url, int row);

//? QFrame* secondary_addresses_frame_;

// QLabel* manufacturer_label_;
// QComboBox* manufacturer_combo_box_;

// QLabel* serious_label_;
// QCheckBox* serious_check_box_;

// QLabel* recovered_label_;
// QCheckBox* recovered_check_box_;

 QFormLayout* top_layout_;
 QFormLayout* mid_layout_;

 CTQ_Project_Record* current_project_record_;

// QLabel* url_label_;
// QTextEdit* url_text_edit_;

// QLabel* query_file_label_;
// QLineEdit* query_file_line_edit_;

// QPlainTextEdit* query_template_text_;
// QPushButton* select_query_template_file_;

 QVBoxLayout* main_layout_;
 QHBoxLayout* query_file_layout_;

 QString current_query_file_path_;
 QString current_request_url_;

 QString description_;

 CTQ_Antemodel* antemodel_;


 QMap<QString, QString> edits_;

 typedef QMap<QString, QString> edits_type;

 //?QWN_XMLDB_Configuration* config_;

 void read_file(QString path, QPlainTextEdit* qpte);

 void add_secondary_address_row();


// QFormLayout* checkbox_layout_;
// QCheckBox* convert_mhix_ckb_;
// QCheckBox* convert_xml_ckb_;
// QCheckBox* save_file_ckb_;
// QCheckBox* auto_save_file_ckb_;
// QCheckBox* save_bookmark_ckb_;

// void init_checkboxes(QFormLayout& qfl);

 void init_project_list();

public:

 New_Project_Dialog(Editing_Mode editing_mode, QWidget* parent,
   CTQ_Antemodel* antemodel, CTQ_Project* current_project = nullptr);//, QString url, QWN_XMLDB_Configuration* config);
 ~New_Project_Dialog();

 ACCESSORS__RGET(edits_type ,edits)

 void activate_search(QString text);

 void init_form_from_current_project_record();

 void proceed_with_edits();

Q_SIGNALS:
 void accepted(QDialog*);
 void canceled(QDialog*);
 void proceed_requested(QDialog*, CTQ_Project_Record*, QMap<QString, QString>);
 void selected_project_changed(CTQ_Project_Record*);

public Q_SLOTS:
 void accept();
 void cancel();
 void proceed();

 void handle_save_project_confirmed(QDialog*, CTQ_Project&);
 void handle_save_project_failed(QDialog*, CTQ_Project&);
 void handle_new_project_confirmed(QDialog*, CTQ_Project&);
 void handle_project_already_exists(QDialog*, CTQ_Project_Initial&);

 void handle_project_combo_box_index_changed(int index);
 void button_more_secondary_addresses_clicked();
 void button_local_folder_select_clicked();

 void select_query_template_file_clicked();

};

} } //_RZNS(CTQ)


#endif
