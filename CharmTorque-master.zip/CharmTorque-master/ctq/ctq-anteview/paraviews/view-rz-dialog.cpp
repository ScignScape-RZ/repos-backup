
#include "view-rz-dialog.h"

//#include "clg-db-antemodel.h";

#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>

#include <QPlainTextEdit>
#include <QTextStream>

#include <QTableWidget>

#include <QMessageBox>

#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrlQuery>

#include <QHeaderView>

#include <QListWidget>

#include "silotypes/ctq-project/ctq-project.h"
#include "silotypes/ctq-project/ctq-project-initial.h"

#include "ctq-antemodel.h"


USING_RZNS(CTQ)

View_RZ_Dialog::View_RZ_Dialog(QWidget* parent,
  CTQ_Antemodel* antemodel, QString src)//, QString url, QWN_XMLDB_Configuration* config)
 : QDialog(parent), antemodel_(antemodel)//, config_(config)
{

 button_box_ = new QDialogButtonBox(this);

 button_ok_ = new QPushButton("OK");
 button_proceed_ = new QPushButton("Proceed");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

 button_proceed_->setDefault(false);
 button_proceed_->setAutoDefault(false);

 button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);


 connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));

 main_layout_ = new QVBoxLayout();

 rz_source_ = new QTextEdit(this);
 rz_source_->setPlainText(src);

// url_label_  = new QLabel("URL", this);
// url_line_edit_ = new QLineEdit(this);

 substitutions_layout_ = new QFormLayout;

 QMap<QString, QString>& substitutions = antemodel_->substitutions();

 QMapIterator<QString, QString> it(substitutions);
 while(it.hasNext())
 {
  it.next();
  QLineEdit* le = new QLineEdit(it.value(), this);
  substitutions_layout_->addRow(it.key(), le);
 }

// url_layout_->addWidget(url_label_);
// url_layout_->addWidget(url_line_edit_);

 main_layout_->addLayout(substitutions_layout_);
 main_layout_->addWidget(rz_source_);

 QString colorful_button_style_sheet =
  "QPushButton:hover {background:rgb(240,190,150);"
  " border-left: 4px groove rgb(240,190,150); "
  " border-right: 4px ridge rgb(240,190,150); "
  "}\n"
  "QPushButton{ padding:1px;  border: 2px solid rgb(240,190,150); "
  "  border-bottom: 1px solid #CEF51D; "
  " border-radius: 6px; "
  " background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, "
  "  stop: 0 white, stop: 0.1 #C0C0C0, stop: 0.6 #CC"
  "C6BC, stop: 0.8 #ECCFA0, stop: 0.9 darkred,  stop: 1 brown"
  "); min-width: 80px; }";



 QString colorful_button_style_sheet_down =
  "QPushButton {background:rgb(190,190,230);padding-left:20;padding-right:20;padding-top:0;padding-bottom:0;"
  " border-left: 4px groove rgb(240,190,150); "
  " border-right: 4px ridge rgb(240,190,150); "
  "}\n";


 show_button_ = new QPushButton("Show Substituted Source", this);

 show_button_->setCheckable(true);

 //?show_button_->setStyleSheet(colorful_button_style_sheet);

 show_button_layout_ = new QHBoxLayout;

 show_button_layout_->addStretch();
 show_button_layout_->addWidget(show_button_);
 show_button_layout_->addStretch();

 main_layout_->addLayout(show_button_layout_);

 connect(show_button_, SIGNAL(toggled(bool)), this,
         SLOT(show_button_toggled(bool)));


 main_layout_->addWidget(button_box_);

 setLayout(main_layout_);

 show();
}

void View_RZ_Dialog::show_button_toggled(bool active)
{
 QString src;
 if(active)
 {
  src = antemodel_->current_substituted_rz_source();
 }
 else
 {
  src = antemodel_->current_rz_source();
 }
 rz_source_->setPlainText(src);

// QString url = url_line_edit_->text();
// web_engine_view_->load(QUrl(url));
}



View_RZ_Dialog::~View_RZ_Dialog()
{
 delete button_ok_;
 delete button_proceed_;
 delete button_cancel_;

// delete url_label_;
// delete name_qle_;
}



void View_RZ_Dialog::cancel()
{
 Q_EMIT(canceled(this));
// close();
}

void View_RZ_Dialog::accept()
{
 Q_EMIT(accepted(this));
// close();
}
