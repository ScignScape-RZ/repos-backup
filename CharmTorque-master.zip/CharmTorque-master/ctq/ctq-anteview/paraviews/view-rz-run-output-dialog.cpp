
#include "view-rz-run-output-dialog.h"

//#include "clg-db-antemodel.h";

#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>

#include <QPlainTextEdit>
#include <QTextStream>

#include <QTableWidget>

#include <QMessageBox>

#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrlQuery>

#include <QHeaderView>

#include <QListWidget>

#include "silotypes/ctq-project/ctq-project.h"
#include "silotypes/ctq-project/ctq-project-initial.h"

USING_RZNS(CTQ)

View_RZ_Run_Output_Dialog::View_RZ_Run_Output_Dialog(QWidget* parent
  , QString rz, QString cl)//, QString url, QWN_XMLDB_Configuration* config)
 : QDialog(parent)//?, antemodel_(antemodel)//, config_(config)
{

 button_box_ = new QDialogButtonBox(this);

 button_ok_ = new QPushButton("OK");
 button_proceed_ = new QPushButton("Proceed");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

 button_proceed_->setDefault(false);
 button_proceed_->setAutoDefault(false);

 button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);


 connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));

 main_layout_ = new QVBoxLayout();

 main_notebook_ = new QTabWidget(this);
 main_text_ = new QTextEdit();
 rz_source_ = new QTextEdit();
 clasp_source_ = new QTextEdit();
 rz_source_->document()->setPlainText(rz);
 clasp_source_->document()->setPlainText(cl);
 clasp_source_ = new QTextEdit(this);

 main_notebook_->addTab(main_text_, "Output");
 main_notebook_->addTab(rz_source_, "R/Z");
 main_notebook_->addTab(clasp_source_, "CL");

 main_layout_->addWidget(main_notebook_);
 //?main_layout_->addLayout(url_layout_);

 QString colorful_button_style_sheet =
  "QPushButton:hover {background:rgb(240,190,150);"
  " border-left: 4px groove rgb(240,190,150); "
  " border-right: 4px ridge rgb(240,190,150); "
  "}\n"
  "QPushButton{ padding:1px;  border: 2px solid rgb(240,190,150); "
  "  border-bottom: 1px solid #CEF51D; "
  " border-radius: 6px; "
  " background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, "
  "  stop: 0 white, stop: 0.1 #C0C0C0, stop: 0.6 #CC"
  "C6BC, stop: 0.8 #ECCFA0, stop: 0.9 darkred,  stop: 1 brown"
  "); min-width: 80px; }";



 QString colorful_button_style_sheet_down =
  "QPushButton {background:rgb(190,190,230);padding-left:20;padding-right:20;padding-top:0;padding-bottom:0;"
  " border-left: 4px groove rgb(240,190,150); "
  " border-right: 4px ridge rgb(240,190,150); "
  "}\n";


 clear_button_ = new QPushButton("Clear", this);

 clear_button_->setStyleSheet(colorful_button_style_sheet);


 clear_button_layout_ = new QHBoxLayout;
 clear_button_layout_->addStretch();
 clear_button_layout_->addWidget(clear_button_);
 clear_button_layout_->addStretch();

 main_layout_->addLayout(clear_button_layout_);



 main_layout_->addWidget(button_box_);

 setLayout(main_layout_);

 show();
}

void View_RZ_Run_Output_Dialog::reset_clasp_code(QString src)
{
 qDebug() << "XXXXX" << src;
 clasp_source_->document()->setPlainText(src);
 //?clasp_source_->repaint();
 clasp_source_->update();

}


void View_RZ_Run_Output_Dialog::clear_button_clicked()
{
 main_text_->clear();
}



View_RZ_Run_Output_Dialog::~View_RZ_Run_Output_Dialog()
{
 delete button_ok_;
 delete button_proceed_;
 delete button_cancel_;

// delete url_label_;
// delete name_qle_;
}



void View_RZ_Run_Output_Dialog::cancel()
{
 Q_EMIT(canceled(this));
// close();
}

void View_RZ_Run_Output_Dialog::accept()
{
 Q_EMIT(accepted(this));
// close();
}
