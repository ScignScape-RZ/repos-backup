
#ifndef VIEW_RZ_RUN_OUTPUT_DIALOG__H
#define VIEW_RZ_RUN_OUTPUT_DIALOG__H


#include <QString>
#include <QMainWindow>

#include <QTextEdit>
//?#include <QWebView>

#include <QWebEngineView>
#include <QLabel>
#include <QPushButton>

#include <QDialog>

#include <QComboBox>

#include "accessors.h"

#include "flags.h"

#include "rzns.h"

//#include "incident-form-dialog.h"

class QPushButton;
class QTextEdit;
class QPlainTextEdit;
class QLineEdit;
class QTabWidget;
class QDialogButtonBox;
class QVBoxLayout;
class QHBoxLayout;
class QCheckBox;
class QFormLayout;
class QSplitter;
class QGridLayout;
class QListWidget;
class QTableWidget;
class QScrollArea;
class QGroupBox;
class QTableWidgetItem;

//RZNS_(QWN)
namespace RZ{ namespace CTQ{


class CTQ_Antemodel;
class CTQ_Project;
class CTQ_Project_Initial;


class View_RZ_Run_Output_Dialog : public QDialog
{
 Q_OBJECT

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QPushButton* button_proceed_;

 QLabel* url_label_;
 QLineEdit* url_line_edit_;

 QTabWidget* main_notebook_;
 QTextEdit* main_text_;
 QTextEdit* clasp_source_;
 QTextEdit* rz_source_;

 QVBoxLayout* main_layout_;
//? CTQ_Antemodel* antemodel_;


 QHBoxLayout* clear_button_layout_;
 QPushButton* clear_button_;

 void read_file(QString path, QPlainTextEdit* qpte);

public:

 View_RZ_Run_Output_Dialog(QWidget* parent, QString rz, QString cl = QString()); //?, CTQ_Antemodel* antemodel);
 ~View_RZ_Run_Output_Dialog();

 void reset_clasp_code(QString src);



 ACCESSORS(QTextEdit* ,main_text)


Q_SIGNALS:
 void canceled(QDialog*);
 void accepted(QDialog*);

public Q_SLOTS:
 void accept();
 void cancel();
 //?void proceed();

 void clear_button_clicked();

};

} } //_RZNS(CTQ)


#endif
