
#include "ctq-event.h"

#include "ctq-application.h"

#include "data/ctq-data-manager.h"


USING_RZNS(CTQ)

CTQ_Event::CTQ_Event(CTQ_Data_Manager* mgr, QDate date, QString description)
  : mgr_(mgr), date_(date),
  description_(description)
{

}

CTQ_Event::CTQ_Event(CTQ_Data_Manager* mgr)
 : mgr_(mgr)
{

}


QString CTQ_Event::key_from_date()
{
 return date_.toString(Qt::DateFormat::ISODate);
}

void CTQ_Event::absorb_data(QByteArray& qba)
{
 QDataStream qds(&qba, QIODevice::ReadOnly);
 qds >> date_;

// QStringList artist_codes;
// qds >> artist_codes;
 qds >> description_;

// for(QString code : artist_codes)
// {
//  CTQ_Artist* pda = mgr_->get_artist_by_code(code);
//  artists_.push_back(pda);
// }
}

QString CTQ_Event::to_xml()
{
 QString result = "<event>";
// result += "\n<artists>";
// for(CTQ_Artist* a : artists_)
// {
//  result += "\n" + a->to_xml();
// }
// result += "\n</artists>";
 result += "\n<date>" + date_.toString() + "</date>";
 result += "\n<description>\n" + description_ + "\n</description>";
 return result;
}


void CTQ_Event::supply_data(QByteArray& qba)
{
 QDataStream qds(&qba, QIODevice::WriteOnly);

// QStringList artist_codes;

// for(CTQ_Artist* pda : artists_)
// {
//  artist_codes.push_back(pda->code());
// }

 qds << date_;
// qds << artist_codes;
 qds << description_;
}




