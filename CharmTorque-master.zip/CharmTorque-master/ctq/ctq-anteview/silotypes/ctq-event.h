
#ifndef CTQ_EVENT__H
#define CTQ_EVENT__H


#include <QString>
#include <QMainWindow>
#include <QUrl>

#include <functional>

#include <QList>

#include <QDate>

#include "accessors.h"

#include "flags.h"


#include "rzns.h"

RZNS_(CTQ)
//namespace RZ{ namespace CLG{


class CTQ_Data_Manager;

class CTQ_Event
{
 CTQ_Data_Manager* mgr_;

 QDate date_;
 QString description_;

public:

 CTQ_Event(CTQ_Data_Manager* mgr, QDate date, QString description);

 CTQ_Event(CTQ_Data_Manager* mgr);

 ACCESSORS(QDate ,date)
 ACCESSORS(QString ,description)


 QString key_from_date();

 void absorb_data(QByteArray& qba);
 void supply_data(QByteArray& qba);

 QString to_xml();

};

_RZNS(CTQ)

#endif
