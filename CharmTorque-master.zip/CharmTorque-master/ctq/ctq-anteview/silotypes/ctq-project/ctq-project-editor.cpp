
#include "ctq-project-editor.h"

#include "ctq-application.h"

#include "data/ctq-data-manager.h"


USING_RZNS(CTQ)

//CTQ_Project::CTQ_Project(CTQ_Data_Manager* mgr, QDate date, QString description)
//  : mgr_(mgr), date_(date),
//  description_(description)
//{

//}

CTQ_Project_Editor::CTQ_Project_Editor(CTQ_Project_Record* pror)
 : CTQ_Project_Record_Holder(pror)
{

}


void CTQ_Project_Editor::absorb_string_map(QMap<QString, QString>& params)
{
 QMap<QString, QString> old_params{{
   { "name", record_->name() },
   { "local-folder", record_->local_folder() },
   { "#local-port", QString::number(record_->local_port()) },
   { "#docker-port", QString::number(record_->docker_port()) },
   { "remote-address", record_->remote_address() },
   { "description", record_->description() },
   { "secondary-addresses", record_->secondary_addresses().join('\n') }
 }};
 this->CTQ_Project_Record_Holder::absorb_string_map(params, &old_params);
}
