
#ifndef CTQ_PROJECT_EDITOR__H
#define CTQ_PROJECT_EDITOR__H


#include <QString>
#include <QMainWindow>
#include <QUrl>

#include <functional>

#include <QList>

#include <QDate>

#include <QMap>

#include "ctq-project-record.h"
#include "ctq-project-record-holder.h"

#include "accessors.h"

#include "flags.h"


#include "rzns.h"

RZNS_(CTQ)
//namespace RZ{ namespace CLG{


class CTQ_Data_Manager;

class CTQ_Project_Editor : public CTQ_Project_Record_Holder
{

public:

 CTQ_Project_Editor(CTQ_Project_Record* pror);

 void absorb_string_map(QMap<QString, QString>& params);


};

_RZNS(CTQ)

#endif
