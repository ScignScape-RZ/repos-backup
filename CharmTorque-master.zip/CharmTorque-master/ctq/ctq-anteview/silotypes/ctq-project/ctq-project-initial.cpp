
#include "ctq-project-initial.h"

#include "ctq-application.h"

#include "data/ctq-data-manager.h"


USING_RZNS(CTQ)

//CTQ_Project::CTQ_Project(CTQ_Data_Manager* mgr, QDate date, QString description)
//  : mgr_(mgr), date_(date),
//  description_(description)
//{

//}

CTQ_Project_Initial::CTQ_Project_Initial(CTQ_Data_Manager* mgr)
 : CTQ_Project_Record_Holder(mgr)
{

}

//void CTQ_Project_Initial::absorb_string_map(QMap<QString, QString>& params)
//{

//}
