
#ifndef CTQ_PROJECT_INITIAL__H
#define CTQ_PROJECT_INITIAL__H


#include <QString>
#include <QMainWindow>
#include <QUrl>

#include <functional>

#include <QList>

#include <QDate>

#include <QMap>

#include "ctq-project-record.h"
#include "ctq-project-record-holder.h"

#include "accessors.h"

#include "flags.h"


#include "rzns.h"

RZNS_(CTQ)
//namespace RZ{ namespace CLG{


class CTQ_Data_Manager;

class CTQ_Project_Initial : public CTQ_Project_Record_Holder
{

public:

 CTQ_Project_Initial(CTQ_Data_Manager* mgr);


};

_RZNS(CTQ)

#endif
