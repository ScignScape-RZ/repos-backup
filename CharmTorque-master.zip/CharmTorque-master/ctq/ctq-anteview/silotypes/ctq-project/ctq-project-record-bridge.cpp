
#include "ctq-project-record-bridge.h"

#include "ctq-application.h"

#include "data/ctq-data-manager.h"


USING_RZNS(CTQ)


CTQ_Project_Record_Bridge::CTQ_Project_Record_Bridge(CTQ_Project_Record* record)
 : CTQ_Project_Record_Holder(record)
{

}

void CTQ_Project_Record_Bridge::set_secondary_addresses(QString qs)
{
 QStringList qsl = qs.split("\n");
 record_->secondary_addresses() = qsl;
}
