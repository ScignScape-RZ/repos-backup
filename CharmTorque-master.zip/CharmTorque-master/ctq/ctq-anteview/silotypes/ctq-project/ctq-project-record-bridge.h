
#ifndef CTQ_PROJECT_RECORD_BRIDGE__H
#define CTQ_PROJECT_RECORD_BRIDGE__H


#include <QString>
#include <QMainWindow>
#include <QUrl>

#include <functional>

#include <QList>

#include <QDate>

#include <QMap>

#include "ctq-project-record.h"
#include "ctq-project-record-holder.h"

#include "accessors.h"

#include "flags.h"


#include "rzns.h"

//RZNS_(CTQ)
namespace RZ{ namespace CTQ{


class CTQ_Data_Manager;

class CTQ_Project_Record_Bridge : public QObject, public CTQ_Project_Record_Holder
{
 Q_OBJECT

public:

 CTQ_Project_Record_Bridge(CTQ_Project_Record* record);

 ACCESSORS__QINV__RECORD(QDate ,date_created)
 ACCESSORS__QINV__RECORD(QString ,description)
 ACCESSORS__QINV__RECORD(QString ,name)
 ACCESSORS__QINV__RECORD(QString ,local_folder)
 ACCESSORS__QINV__RECORD(int ,local_port)
 ACCESSORS__QINV__RECORD(int ,docker_port)
 ACCESSORS__QINV__RECORD(QString ,remote_address)
 ACCESSORS__QINV__RECORD__RGET(QStringList ,secondary_addresses)

 Q_INVOKABLE void set_secondary_addresses(QString qs);

 //void absorb_string_map(QMap<QString, QString>& params);


};

_RZNS(CTQ)

#endif
