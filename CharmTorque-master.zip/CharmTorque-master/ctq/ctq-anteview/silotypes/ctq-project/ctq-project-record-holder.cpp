
#include "ctq-project-record-holder.h"

#include "ctq-application.h"

#include "data/ctq-data-manager.h"

#include "ctq-project-record-bridge.h"


USING_RZNS(CTQ)


CTQ_Project_Record_Holder::CTQ_Project_Record_Holder(CTQ_Data_Manager* mgr)
 : record_(new CTQ_Project_Record(mgr))
{

}

CTQ_Project_Record_Holder::CTQ_Project_Record_Holder(CTQ_Project_Record* record)
 : record_(record)
{

}


void CTQ_Project_Record_Holder::absorb_string_map(QMap<QString, QString>& params,
  QMap<QString, QString>* old_params)
{
 CTQ_Project_Record_Bridge prb(record_);
 QMapIterator<QString, QString> it(params);
 while(it.hasNext())
 {
  it.next();
  QString param = it.key();
  QString value = it.value();
  if(old_params)
  {
   if(old_params->value(param) == value)
   {
    continue;
   }
  }
  param.replace('-', '_');
  if(param.startsWith('#'))
  {
   QString setter = QString("set_%1").arg(param.mid(1));
   int v = value.toInt();
   const QMetaObject* qmo = prb.metaObject();
   qmo->invokeMethod(&prb, setter.toLatin1(), Q_ARG(int ,v));
  }
  else if(param.startsWith('%'))
  {
   QString setter = QString("set_%1").arg(param.mid(1));
   double v = value.toDouble();
   const QMetaObject* qmo = prb.metaObject();
   qmo->invokeMethod(&prb, setter.toLatin1(), Q_ARG(double ,v));
  }
  else
  {
   QString setter = QString("set_%1").arg(param);
   const QMetaObject* qmo = prb.metaObject();
   qmo->invokeMethod(&prb, setter.toLatin1(), Q_ARG(QString ,value));
  }
 }
}
