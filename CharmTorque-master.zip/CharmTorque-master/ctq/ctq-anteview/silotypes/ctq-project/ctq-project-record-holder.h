
#ifndef CTQ_PROJECT_RECORD_HOLDER__H
#define CTQ_PROJECT_RECORD_HOLDER__H


#include <QString>
#include <QMainWindow>
#include <QUrl>

#include <functional>

#include <QList>

#include <QDate>

#include <QMap>

#include "ctq-project-record.h"

#include "accessors.h"

#include "flags.h"


#include "rzns.h"

RZNS_(CTQ)
//namespace RZ{ namespace CLG{


class CTQ_Data_Manager;

class CTQ_Project_Record_Holder
{
protected:

 CTQ_Project_Record* record_;

public:

 CTQ_Project_Record_Holder(CTQ_Project_Record* record);

 CTQ_Project_Record_Holder(CTQ_Data_Manager* mgr);

 ACCESSORS(CTQ_Project_Record* ,record)

 ACCESSORS__RECORD(QDate ,date_created)
 ACCESSORS__RECORD(QString ,description)
 ACCESSORS__RECORD(QString ,name)
 ACCESSORS__RECORD(QString ,local_folder)
 ACCESSORS__RECORD(int ,local_port)
 ACCESSORS__RECORD(int ,docker_port)
 ACCESSORS__RECORD(QString ,remote_address)
 ACCESSORS__RECORD__RGET(QStringList ,secondary_addresses)

 void absorb_string_map(QMap<QString, QString>& params,
   QMap<QString, QString>* old_params = nullptr);


};

_RZNS(CTQ)

#endif
