
#include "ctq-project.h"

#include "ctq-application.h"

#include "data/ctq-data-manager.h"


USING_RZNS(CTQ)

//CTQ_Project::CTQ_Project(CTQ_Data_Manager* mgr, QDate date, QString description)
//  : mgr_(mgr), date_(date),
//  description_(description)
//{

//}

CTQ_Project_Record::CTQ_Project_Record(CTQ_Data_Manager* mgr)
 : mgr_(mgr), uid_(0), local_port_(0), docker_port_(0)
{

}

CTQ_Project_Record& CTQ_Project_Record::operator=(const CTQ_Project_Record& rhs)
{
 date_created_ = rhs.date_created_;
 name_ = rhs.name_;
 local_folder_ = rhs.local_folder_;
 local_port_ = rhs.local_port_;
 docker_port_ = rhs.docker_port_;
 remote_address_ = rhs.remote_address_;
 secondary_addresses_ = rhs.secondary_addresses_;
 if(!mgr_)
 {
  mgr_ = rhs.mgr_;
 }
 if(!uid_)
 {
  uid_ = rhs.uid_;
 }
 return *this;
}

void CTQ_Project_Record::absorb_data(QByteArray& qba)
{
 QDataStream qds(&qba, QIODevice::ReadOnly);
 qds >> uid_;

 qds >> date_created_;
 qds >> description_;
 qds >> name_;
 qds >> local_folder_;
 qds >> local_port_;
 qds >> docker_port_;
 qds >> remote_address_;
 qds >> secondary_addresses_;

}

void CTQ_Project_Record::supply_data(QByteArray& qba) const
{
 QDataStream qds(&qba, QIODevice::WriteOnly);
 qds << uid_;

 qds << date_created_;
 qds << description_;
 qds << name_;
 qds << local_folder_;
 qds << local_port_;
 qds << docker_port_;
 qds << remote_address_;
 qds << secondary_addresses_;

}
