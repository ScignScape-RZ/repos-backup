
#ifndef CTQ_PROJECT_RECORD__H
#define CTQ_PROJECT_RECORD__H


#include <QString>
#include <QMainWindow>
#include <QUrl>

#include <functional>

#include <QList>

#include <QDate>

#include "accessors.h"

#include "flags.h"


#include "rzns.h"

RZNS_(CTQ)
//namespace RZ{ namespace CLG{


class CTQ_Data_Manager;

class CTQ_Project_Record
{
protected:

 CTQ_Data_Manager* mgr_;

 int uid_;

 QDate date_created_;
 QString description_;
 QString name_;
 QString local_folder_;
 QString remote_address_;
 QStringList secondary_addresses_;
 int local_port_;
 int docker_port_;

public:

 CTQ_Project_Record(CTQ_Data_Manager* mgr);

 CTQ_Project_Record& operator=(const CTQ_Project_Record& rhs);

 ACCESSORS(int ,uid)

 ACCESSORS(QDate ,date_created)
 ACCESSORS(QString ,description)
 ACCESSORS(QString ,name)
 ACCESSORS(QString ,local_folder)
 ACCESSORS(QString ,remote_address)
 ACCESSORS__RGET(QStringList ,secondary_addresses)
 ACCESSORS(int ,local_port)
 ACCESSORS(int ,docker_port)


 QString key_from_date();

 void absorb_data(QByteArray& qba);
 void supply_data(QByteArray& qba) const;

 QString to_xml();

};

_RZNS(CTQ)

#endif
