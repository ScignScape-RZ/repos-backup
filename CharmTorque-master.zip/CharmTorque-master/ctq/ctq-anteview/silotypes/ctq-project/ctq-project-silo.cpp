
#include "ctq-project-silo.h"
#include "ctq-project-record.h"
#include "ctq-project.h"

#include <QRegExp>

#include "rzns.h"

USING_RZNS(CTQ)


CTQ_Project_Silo::CTQ_Project_Silo(int record_count, int type_id, QString type_name)
 : record_count_(record_count),
   last_saved_record_count_(record_count), type_id_(type_id), type_name_(type_name)
{

}

QString CTQ_Project_Silo::make_ukey(QString referrer_email, QString potential_contact_name)
{
 QString result = referrer_email.replace(QRegExp("\\s+"), "");
 result += "@@" + potential_contact_name.replace(QRegExp("\\s+"), "");
 return result;
}

int CTQ_Project_Silo::new_uid()
{
 return ++record_count_;
}


int CTQ_Project_Silo::check_save_record_count()
{
 if(last_saved_record_count_ != record_count_)
 {
  last_saved_record_count_ = record_count_;
  return record_count_;
 }
 else
 {
  return 0;
 }

}


CTQ_Project* CTQ_Project_Silo::confirm_joinee_from_record
 (CTQ_Project_Record& record, int uid)
{
 record.set_uid(uid);

 CTQ_Project* result = new CTQ_Project;
 result->absorb_record(record);

 return result;
// if(record_count_ != last_saved_record_count_)
// {
//  save_record_count();
// }

}

