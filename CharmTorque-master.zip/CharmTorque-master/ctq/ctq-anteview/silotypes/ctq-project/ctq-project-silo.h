

#ifndef CTQ_PROJECT_SILO__H
#define CTQ_PROJECT_SILO__H

#include <QString>

#include "accessors.h"
#include "rzns.h"

RZNS_(CTQ)

class CTQ_Project_Record;
class CTQ_Project;
//?class PCV_Data_Manager;

class CTQ_Project_Silo
{
 int record_count_;
 int type_id_;
 int last_saved_record_count_;

 QString type_name_;

public:

 ACCESSORS(int ,record_count)
 ACCESSORS(QString ,type_name)
 ACCESSORS(int ,type_id)

 typedef CTQ_Project cotype;

 CTQ_Project_Silo(int record_count, int type_id, QString type_name);

 int new_uid();


 static QString make_ukey(QString referrer_email, QString potential_contact_name);

 CTQ_Project* confirm_joinee_from_record
  (CTQ_Project_Record& record, int uid);

 int check_save_record_count();

};

_RZNS(CTQ)


#endif
