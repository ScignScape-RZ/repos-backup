
#include "ctq-project.h"

#include "ctq-application.h"

#include "data/ctq-data-manager.h"


USING_RZNS(CTQ)

//CTQ_Project::CTQ_Project(CTQ_Data_Manager* mgr, QDate date, QString description)
//  : mgr_(mgr), date_(date),
//  description_(description)
//{

//}

CTQ_Project::CTQ_Project(CTQ_Data_Manager* mgr)
 : CTQ_Project_Record(mgr)
{

}

void CTQ_Project::absorb_record(const CTQ_Project_Record& rhs)
{
 this->CTQ_Project_Record::operator =(rhs);
}

