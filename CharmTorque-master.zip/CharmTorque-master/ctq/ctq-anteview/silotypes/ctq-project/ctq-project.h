
#ifndef CTQ_PROJECT__H
#define CTQ_PROJECT__H


#include <QString>
#include <QMainWindow>
#include <QUrl>

#include <functional>

#include <QList>

#include <QDate>

#include "ctq-project-record.h"

#include "accessors.h"

#include "flags.h"


#include "rzns.h"

RZNS_(CTQ)
//namespace RZ{ namespace CLG{


class CTQ_Data_Manager;

class CTQ_Project : public CTQ_Project_Record
{

public:

 CTQ_Project(CTQ_Data_Manager* mgr = nullptr);

 void absorb_record(const CTQ_Project_Record& rhs);

};

_RZNS(CTQ)

#endif
