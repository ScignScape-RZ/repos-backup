
#include <QDebug>

#include <QCoreApplication>

#include <QMap>
#include <map>

#include <QDir>

#include "ctq-anteview/ctq-anteview.h"
#include "ctq-anteview/ctq-application.h"

#include "qunqlite-callback-parser.h"

USING_RZNS(CTQ)

void start_application(CTQ_Application* ctqa)
{
 QUnQLite_Callback_Parser callback_parser;

 std::function<int(QString message, int arglength, void* data)>
  allobase_callback = [&callback_parser](QString message, int arglength, void* data) -> int
 {
  return callback_parser.run_query(message, arglength, data);
 };

 std::function<int(QString message, QString key, QString value, QString* ref)>
  index_callback = [&callback_parser](QString message, QString key, QString value, QString* ref = nullptr) -> int
 {
  if(ref)
  {
   void* data[2] = {&key, ref};
   return callback_parser.run_query(message, 2, data);
  }
  else
  {
   void* data[2] = {&key, &value};
   return callback_parser.run_query(message, 2, data);
  }
 };

 std::function<QString()>
   error_callback = [&callback_parser]() -> QString
 {
   return callback_parser.last_error_code();
 };

 //ctqa->set_default_open_directory(DEFAULT_HTML_DIRECTORY);
 ctqa->allobase_init(DEFAULT_DATA_DIRECTORY, "all-ctq",
   allobase_callback, index_callback, error_callback);

 ctqa->launch("Charm\u03beTorque  --  Hybrid Web/Native Development Platform");
}

int main(int argc, char* argv[])
{
 CTQ_Application* ctqa = new CTQ_Application(argc, argv);
 start_application(ctqa);
 //
}



#ifdef HIDE

void compile_rz(QString file, QString& result)
{
 RZ_QClasp_Generator::compile_rz(file, result);
}

int main2(int argc, char *argv[])
{
//? QApplication qapp(argc, argv);

  QCoreApplication qapp(argc, argv);

  QString result;

  compile_rz("/home/nlevisrael/rz-lisp/rz/t1.rz", result);

  qDebug() << result;
}

//#ifdef HIDE
int main(int argc, char *argv[])
{
//? QApplication qapp(argc, argv);

  QCoreApplication qapp(argc, argv);

  QString result;

  compile_rz("/home/nlevisrael/rz-lisp/rz/t1.rz", result);


 // qRegisterMetaType<PTN_Recommendation_Clasp_Interface>();
 // qRegisterMetaType<PTN_Recommendation_Clasp_Interface*>();
 // qRegisterMetaType<PTN_Recommendation_Clasp_Interface>();
 // qRegisterMetaType<PTN_Recommendation_Clasp_Interface*>();

  qRegisterMetaType<PTN_Site_Manager_Bridge>();
  qRegisterMetaType<PTN_Site_Manager_Bridge*>();

  qRegisterMetaType<PTN_Site_Manager_Date_Time>();
  qRegisterMetaType<PTN_Site_Manager_Date_Time*>();

  qRegisterMetaType<PTN_Site_Manager_Folder_Bridge>();
  qRegisterMetaType<PTN_Site_Manager_Folder_Bridge*>();

  qRegisterMetaType<PTN_Site_Manager_File_Bridge>();
  qRegisterMetaType<PTN_Site_Manager_File_Bridge*>();

  qRegisterMetaType<PTN_Site_Manager_Event_Loop>();
  qRegisterMetaType<PTN_Site_Manager_Event_Loop*>();

// qRegisterMetaType<PTN_Recommendation_Clasp_Interface>();
// qRegisterMetaType<PTN_Recommendation_Clasp_Interface*>();

 std::map<std::string, int> dummy_map;
 dummy_map["x"] = 1;
 dummy_map["y"] = 2;

 RZ_QClasp_Eval* clasp_eval = new RZ_QClasp_Eval;


 char argc_ = 3;

 char* argv_[argc_];
 //?QDir::setCurrent(
 QString current_dir =  "/run/media/nlevisrael/DualBootShared/CLASPQ/branches/new-testing/clasp/build/boehmdc";

 qDebug() << current_dir;

 argv_[0] = "cclasp-boehmdc";
// ////
// argv_[1] = "-l";
// argv_[2] = "/home/nlevisrael/rz-dev/cl/exit.lisp";

 argv_[1] = "-I";
 argv_[2] = "-n";

 //argv_[3] = "-I";
 //argv_[3] = "-n";


 //?clasp_eval->start_iclasp(argc, argv);

 clasp_eval->start_clasp_from_dir(argc_, argv_, current_dir);
 RZ_QClasp_Bridge* clasp_bridge = new RZ_QClasp_Bridge(*clasp_eval);

 //?QString qs1 = "(core::q-callback :invoke   (core::q-create  :|PTN_Recommendation_Clasp_Interface|) :|value_from_qcmap|     \"a\"     \"b\"      \"aaa\"      \"xxx\" ) ";
 //?qDebug() << "\n\nQS1 --- \n" << qs1 << "\n\n===\n";



 clasp_bridge->eval_file("/home/nlevisrael/rz-lisp/rz/t1.rz.cl");

// clasp_bridge->eval_rz_file("/home/nlevisrael/rz-dev/cl/t4.rz");

 //?clasp_bridge->eval_string("(core::q-callback :invoke   (core::q-create  :|PTN_Recommendation_Clasp_Interface|) :|value_from_qcmap|     \"a\"     \"b\"      \"aaa\"      \"xxx\")");


}
//#endif

#endif //HIDE
