
#ifndef QUNQLITE_CALLBACK_PARSER__H
#define QUNQLITE_CALLBACK_PARSER__H


#include "unqlite/qunqlite.h"
#include "unqlite/qunqlitecursor.h"

#include <QMap>


class QUnQLite_Callback_Parser
{
 QUnQLite qunqlite_;
 QString data_root_path_;
 QString database_file_name_;

public:
 enum Result_Codes {
  All_Ok = 0,
  All_Up_To_Date,
  Not_Implemented,
  Commit_Problem,
  Retrieve_Problem,
  Store_Problem,
  Database_Create_Problem,
  Database_Open_Problem,
  Database_Close_Problem,
  Malformed_Arguments_Problem

 };

private:

 enum Queries {
  Query_Not_Recognized,
  #define TEMP_MACRO(name) name,
  #include "qunqlite-callback-parser.queries.h"
  #undef TEMP_MACRO
 };

 static Queries parse_query(QString q)
 {
#ifdef LINUX_LOCAL
  static QMap<QString, Queries> static_map
  {{
   #define TEMP_MACRO(name){#name, name},
   #include "qunqlite-callback-parser.queries.h"
   #undef TEMP_MACRO
  }};
#else
  static QMap<QString, Queries> static_map;
  if(static_map.isEmpty())
  {
   #define TEMP_MACRO(name) static_map.insert(#name, name);
   #include "qunqlite-callback-parser.queries.h"
   #undef TEMP_MACRO
  }
#endif

  return static_map.value(q, Query_Not_Recognized);
 }

 int load_generic_data(void* data);
 int save_generic_data(void* data);


public:

 QUnQLite_Callback_Parser();

 QString last_error_code();

 int run_query(QString message, int arglength, void* data);

 #define TEMP_MACRO(name) \
  int run_##name(QString message, int arglength, void* data);
 #include "qunqlite-callback-parser.queries.h"
 #undef TEMP_MACRO


};


#endif
