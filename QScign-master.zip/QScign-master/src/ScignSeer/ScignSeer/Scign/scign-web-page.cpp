
#include "scign-web-page.h"

//#include "pdf-document-widget.h"


#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QCheckBox>

#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDebug>
#include <QNetworkRequest>
#include <QTextStream>

#include <QMouseEvent>

USING_RZNS(MoND_UI)

Scign_Web_Page::Scign_Web_Page(QWidget* parent)
 : QWebEnginePage(parent), parent_(parent) //, main_editor_(nullptr)
{}

void Scign_Web_Page::mousePressEvent(QMouseEvent *event)
{
 QPoint dragPosition = event->pos();
 qDebug() << "DP1: " << dragPosition;
}

void Scign_Web_Page::mouseReleaseEvent(QMouseEvent *event)
{
 QPoint dragPosition = event->pos();
 qDebug() << "DP2: " << dragPosition;
}

#ifdef HIDE
QObject* TECS_Web_Page::createPlugin(const QString& classid, const QUrl& url,
 const QStringList& paramNames, const QStringList& paramValues)
{
 QObject* result = nullptr;
 QString name;
 QObject* prestored = nullptr;
 int pos = paramNames.indexOf("name");
 if(pos != -1)
  name = paramValues.at(pos);
 bool store_control = !name.isEmpty();
 if(store_control)
 {
  if(inner_controls_.contains(name))
  {
   prestored = inner_controls_[name];
  }
 }

// if(classid == "LSI_DB_Main_Editor")
// {
//  if(prestored)
//  {
//   main_editor_ =
//    new LSI_DB_Main_Editor(parent_, main_editor_);

//   result = main_editor_;
//  }
//  else
//  {
//   main_editor_ = new LSI_DB_Main_Editor(parent_);
//   result = main_editor_;
//  }
// }
 if(classid == "PDF_Document_Widget")
 {
  PDF_Document_Widget* pre = nullptr;
  if(prestored)
   pre = static_cast<PDF_Document_Widget*>(prestored);
  result = new PDF_Document_Widget(parent_);
 }
 else if(classid == "QCheckBox")
 {
  QCheckBox* pre = nullptr;
  if(prestored)
   pre = static_cast<QCheckBox*>(prestored);

  QString label;
  QString label_spec;

  int pos = paramNames.indexOf("label");
  if(pos != -1)
   label = paramValues.at(pos);

  pos = paramNames.indexOf("label-spec");
  if(pos != -1)
   label_spec = paramValues.at(pos);

  if(!label_spec.isEmpty())
  {
   if(label == "A")
    label = QString(QChar(9670));
   else if(label == "M")
    label = QString(QChar(12323));
  }

  QCheckBox*
    result_cb = new QCheckBox(label, parent_);
  if(pre)
   result_cb->setChecked(pre->checkState());

  result = result_cb;
 }
 if(store_control)
  inner_controls_[name] = result;
 return result;
}

#endif
//void LSI_DB_Web_Page::check_box_state_changed(int)
//{
//// QCheckBox* qcb =
//}

