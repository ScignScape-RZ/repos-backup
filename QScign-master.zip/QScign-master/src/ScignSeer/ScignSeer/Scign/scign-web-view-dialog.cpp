
#include "scign-web-view-dialog.h"

#include "scign-web-page.h"

//#include "clg-db-antemodel.h";

#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>

#include <QGraphicsRectItem>
#include <QRubberBand>

#include <QPlainTextEdit>
#include <QTextStream>

#include <QTableWidget>

#include <QMessageBox>

#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrlQuery>

#include <QMenu>

#include <QHeaderView>

#include <QListWidget>
#include <QPrinter>

//#include "silotypes/ndp-project/ndp-project.h"
//#include "silotypes/ndp-project/ndp-project-initial.h"

#include "styles.h"



USING_RZNS(MoND_UI)



QString Scign_Web_View_Dialog::load_file(QString path)
{
 QString result;
 QFile file(path);
 if(file.open(QFile::ReadOnly | QIODevice::Text))
 {
  result = file.readAll();
 }
 return result;
}


void Custom_Web_Engine_View::mouseMoveEvent(QMouseEvent* event)
{
 parent_dialog_->page_mouse_move_event(event);
}

void Custom_Web_Engine_View::mousePressEvent(QMouseEvent* event)
{
 parent_dialog_->page_mouse_press_event(event);
}

void Custom_Web_Engine_View::mouseReleaseEvent(QMouseEvent* event)
{
 parent_dialog_->page_mouse_release_event(event);
}

bool Scign_Web_View_Dialog::page_mouse_press_event(QMouseEvent* event)
{
 QPoint p = event->pos();


 if (!rubber_band_)
  rubber_band_ = new QRubberBand(QRubberBand::Rectangle, this);

 rubber_band_origin_ = p + web_engine_view_->pos();
 rubber_band_page_origin_ = p;

 rubber_band_->setGeometry(
   QRect( rubber_band_origin_, QSize(2, 2) ) );

 rubber_band_->show();
 return true;
}

bool Scign_Web_View_Dialog::page_mouse_release_event(QMouseEvent* event)
{
 QWebEnginePage* page = web_engine_view_->page();
 QString jscode = load_file(
   "/extension/medInria/medInria-public-master/mmui/cpp/src/mmui/medinria-mmui/paraviews/test.js"
   );

 rubber_band_page_end_ = event->pos();

 QPoint p = rubber_band_page_end_;// + web_engine_view_->pos();

// QPoint p1 = rubber_band_->rect().topLeft();
// QPoint p2 = rubber_band_->rect().bottomRight();

 int x1, x2, y1, y2;

 if(rubber_band_page_origin_.x() < rubber_band_page_end_.x())
 {
  x1 = rubber_band_page_origin_.x();
  x2 = rubber_band_page_end_.x();
 }
 else
 {
  x1 = rubber_band_page_end_.x();
  x2 = rubber_band_page_origin_.x();
 }

 if(rubber_band_page_origin_.y() < rubber_band_page_end_.y())
 {
  y1 = rubber_band_page_origin_.y();
  y2 = rubber_band_page_end_.y();
 }
 else
 {
  y1 = rubber_band_page_end_.y();
  y2 = rubber_band_page_origin_.y();
 }


 QString jscode0 = jscode + QString("elt = document.elementFromPoint(%1, %2); getWordAtPoint(elt, %1, %2, %3, %4)")
   .arg(x1)
   .arg(y1)
   .arg(x2)
   .arg(y2);

   //.arg(x1_).arg(y1_).arg(x1_).arg(y1_);

 QString w1;
 QString w2;

 page->runJavaScript(jscode0 + ";", [this, p] (const QVariant& v)
 {
  qDebug() << "P!: " << p;
  QString atr = v.toString();
  qDebug() << "W0: " << atr;
  if(!atr.isEmpty())
  {
   show_selection_menu(p, atr);
  }
  //qDebug() << "W0: " << atr;
 });

 rubber_band_->hide();


 return true;
}

bool Scign_Web_View_Dialog::page_mouse_move_event(QMouseEvent* event)
{
 QPoint p = event->pos();


 QPoint pp = p + web_engine_view_->pos();
 if(rubber_band_)
  rubber_band_->setGeometry(QRect(rubber_band_origin_, pp).normalized());
 return true;
}


void Scign_Web_View_Dialog::show_selection_menu(QPoint p, QString search_term)
{
 //qDebug() << "ST: " << search_term;
 QMenu menu;
 menu.addAction(QString("Search (SNOMED): %1").arg(search_term),
   [this, search_term]
 {
  restart_search(search_term, "SNOMED");
 });
 menu.addAction(QString("Search (ICD-10-CM): %1").arg(search_term),
   [this, search_term]
 {
  restart_search(search_term, "ICD-10-CM");
 });
 menu.addAction(QString("Search (ICD-9-CM): %1").arg(search_term),
   [this, search_term]
 {
  restart_search(search_term, "ICD-9-CM");
 });


 //?menu.addAction("Cancel");
 //?
 menu.exec(mapToGlobal(p));
 //?menu.exec(p);
}


void Scign_Web_View_Dialog::restart_search(QString search_term, QString where)
{
 QString addr = QString(
    "https://apps.nlm.nih.gov/medlineplus/services/mpconnect.cfm");

 QUrl url(addr);

 QNetworkRequest req;

 QUrlQuery urlq;

 if(where == "SNOMED")
 {
  urlq.addQueryItem("mainSearchCriteria.v.cs", "2.16.840.1.113883.6.96");
 }
 else if(where == "ICD-10-CM")
 {
  urlq.addQueryItem("mainSearchCriteria.v.cs", "2.16.840.1.113883.6.96");
 }
 else if(where == "ICD-9-CM")
 {
  urlq.addQueryItem("mainSearchCriteria.v.cs", "2.16.840.1.113883.6.103");
 }

 // SNOMED
  //urlq.addQueryItem("mainSearchCriteria.v.cs", "2.16.840.1.113883.6.96");

 // ICD-10-CM
  // urlq.addQueryItem("mainSearchCriteria.v.cs", "2.16.840.1.113883.6.90");
 // ICD-9-CM
 //urlq.addQueryItem("mainSearchCriteria.v.cs", "2.16.840.1.113883.6.103");



 //  drug ...
 //For RXCUI use:
 //    mainSearchCriteria.v.cs=2.16.840.1.113883.6.88

 //For NDC use:
 //    mainSearchCriteria.v.cs=2.16.840.1.113883.6.69

 //Identify the actual code you are trying to look up. (Preferred for English, Required for Spanish)
 //mainSearchCriteria.v.c=637188
 //Identify the name of the drug with a text string. (Optional for English, Not used for Spanish)
 //mainSearchCriteria.v.dn=Chantix 0.5 MG Oral Tablet


// LAB
// For LOINC use:
 //    mainSearchCriteria.v.cs=2.16.840.1.113883.6.1

// MedlinePlus Connect will also accept:
 //    mainSearchCriteria.v.cs=2.16.840.1.113883.11.79

// Identify the actual code you are trying to look up.
// mainSearchCriteria.v.c=3187-2

 //?Identify the name/title of the lab test. However, this information does not impact the response. mainSearchCriteria.v.dn=Factor IX assay


 //?urlq.addQueryItem("mainSearchCriteria.v.c", "250.33");
 //?urlq.addQueryItem("mainSearchCriteria.v.dn", "Diabetes mellitus with other, type uncontrolled");

 urlq.addQueryItem("mainSearchCriteria.v.dn", search_term);

 urlq.addQueryItem("informationRecipient.languageCode.c", "en");

 url.setQuery(urlq);

 //req.setUrl(url);

 load_new_url(url, url.toString());


 //qDebug() << "ST: " << search_term;
}


//void Scign_Web_View_Dialog::mousePressEvent(QMouseEvent* event)
//{
// QPoint dragPosition = event->pos();
// if (!rubber_band_)
//     rubber_band_ = new QRubberBand(QRubberBand::Rectangle, this);
// rubber_band_->setGeometry(QRect(dragPosition, QSize()));
// rubber_band_->show();

//}

//void Scign_Web_View_Dialog::mouseReleaseEvent(QMouseEvent* event)
//{
// if(event->button() == Qt::RightButton)
// {
//  QPoint qp = event->pos();
//  QRectF rect = QRectF(rubber_band_->pos(), rubber_band_->size());

//  qDebug() << "RECT: " << rect;
// }
//}


Scign_Web_View_Dialog::Scign_Web_View_Dialog(QString url,
  QWidget* parent, NDP_Antemodel* antemodel)//, QString url, QWN_XMLDB_Configuration* config)
 : QDialog(parent), antemodel_(antemodel),
   context_menu_rubber_band_(nullptr), rubber_band_(nullptr),
   rubber_band_progression_(0),

   x1_(0), x2_(0), y1_(0), y2_(0)

   //, config_(config)
{

 button_box_ = new QDialogButtonBox(this);

 button_ok_ = new QPushButton("OK");
 button_proceed_ = new QPushButton("Proceed");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

 button_proceed_->setDefault(false);
 button_proceed_->setAutoDefault(false);

 button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);


 connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));

 main_layout_ = new QVBoxLayout();

 web_engine_view_ = new Custom_Web_Engine_View(this);
 //?web_engine_view_ = new QWebEngineView(this);

 url_label_  = new QLabel("URL", this);
 url_line_edit_ = new QLineEdit(this);

 connect(web_engine_view_, &QWebEngineView::urlChanged,
  [this](const QUrl& url)
 {
  url_line_edit_->setText(url.toString());
  url_line_edit_->setCursorPosition(0);
 });

 url_layout_ = new QHBoxLayout;
 url_layout_->addWidget(url_label_);
 url_layout_->addWidget(url_line_edit_);

 main_layout_->addWidget(web_engine_view_);
 main_layout_->addLayout(url_layout_);

 QString colorful_button_style_sheet = colorful_button_style_sheet_();
 QString colorful_button_style_sheet_down = colorful_button_style_sheet_down_();

 go_button_ = new QPushButton("Go", this);
 close_button_ = new QPushButton("Close", this);

 go_button_->setStyleSheet(colorful_button_style_sheet);
 close_button_->setStyleSheet(colorful_button_style_sheet);

 go_button_layout_ = new QHBoxLayout;
 go_button_layout_->addStretch();
 go_button_layout_->addWidget(go_button_);
 go_button_layout_->addStretch();

 main_layout_->addLayout(go_button_layout_);

 close_button_layout_ = new QHBoxLayout;
 close_button_layout_->addStretch();
 close_button_layout_->addWidget(close_button_);
 close_button_layout_->addStretch();

 main_layout_->addLayout(close_button_layout_);

 connect(go_button_, SIGNAL(clicked()), this,
         SLOT(go_button_clicked()));

 connect(close_button_, SIGNAL(clicked()), this,
         SLOT(close_button_clicked()));

//? web_engine_view_->setContextMenuPolicy(Qt::CustomContextMenu);


//?
#ifdef HIDE
 web_engine_view_->setContextMenuPolicy(Qt::CustomContextMenu);
 connect(web_engine_view_, &QWebEngineView::customContextMenuRequested,
   [this](QPoint p)
 {
  //QPoint dragPosition = p + web_engine_view_->pos(); //mapToGlobal(p); //event->pos();
  switch(rubber_band_progression_)
  {
  case 0:

//   x1_ = dragPosition.x();
//   y1_ = dragPosition.y();

   if(!rubber_band_)
    rubber_band_ = new QRubberBand(QRubberBand::Rectangle, this);

   rubber_band_origin_ = p + web_engine_view_->pos();
   rubber_band_page_origin_ = p;

   rubber_band_->setGeometry(
     QRect( rubber_band_origin_, QSize(5, 5) ) );

   rubber_band_->show();
   ++rubber_band_progression_;
   break;
  case 1:
   {
    rubber_band_page_end_ = p;

//    int x1 = rubber_band_->pos().x();
//    int y1 = rubber_band_->pos().y();

//    int x2 = dragPosition.x();
//    int y2 = dragPosition.y();

//    x2_ = dragPosition.x();
//    y2_ = dragPosition.y();


//    rubber_band_->setGeometry(
//      QRect(x1, y1, x2-x1, y2-y1
//           ));

   QPoint qp = p + web_engine_view_->pos();

    rubber_band_->setGeometry(
      QRect( rubber_band_origin_, qp ));


    qDebug() << "X1: " << x1_ << "Y1: " << y1_
      << "X2: " << x2_ << "Y2: " << y2_;

//    rubber_band_->setGeometry(
//      QRect(0, 0, 15, 15
//      ));


    rubber_band_->show();
    ++rubber_band_progression_;
   }
   break;
  case 2:
   {
    QWebEnginePage* page = web_engine_view_->page();
    QString jscode = load_file(
      "/extension/medInria/medInria-public-master/mmui/cpp/src/mmui/medinria-mmui/paraviews/test.js"
      );

    QPoint p1 = rubber_band_->rect().topLeft();
    QPoint p2 = rubber_band_->rect().bottomRight();

//    QString jscode1 = jscode + QString("elt = document.elementFromPoint(%1, %2); getWordAtPoint(elt, %1, %2)").arg(p1.x()).arg(p1.y());
//    QString jscode2 = jscode + QString("elt = document.elementFromPoint(%1, %2); getWordAtPoint(elt, %1, %2)").arg(p2.x()).arg(p2.y());

//    QString jscode0 = jscode + QString("elt = document.elementFromPoint(%1, %2); getWordAtPoint(elt, %1, %2, %3, %4)")
//      .arg(p1.x()).arg(p1.y()).arg(p2.x()).arg(p2.y());

//    QString jscode0 = jscode + QString("elt = document.elementFromPoint(%1, %2); getWordAtPoint(elt, %1, %2, %3, %4)")
//      .arg(p1.x()).arg(p1.y()).arg(p1.x()).arg(p1.y());

    QString jscode0 = jscode + QString("elt = document.elementFromPoint(%1, %2); getWordAtPoint(elt, %1, %2, %3, %4)")
      .arg(rubber_band_page_origin_.x())
      .arg(rubber_band_page_origin_.y())
      .arg(rubber_band_page_end_.x())
      .arg(rubber_band_page_end_.y());

      //.arg(x1_).arg(y1_).arg(x1_).arg(y1_);

    QString w1;
    QString w2;

    page->runJavaScript(jscode0 + ";", [this] (const QVariant& v)
    {
     QString atr = v.toString();
     qDebug() << "W0: " << atr;
    });

    rubber_band_progression_ = 0;
    rubber_band_->hide();
//    page->runJavaScript(jscode1 + ";", [this, &w1] (const QVariant& v)
//    {
//     w1 = v.toString();
//    });

//    page->runJavaScript(jscode2 + ";", [this, &w2] (const QVariant& v)
//    {
//     w2 = v.toString();
//    });


//    qDebug() << "W0 W1 W2:" << w0 << w1 << w2;

   }
  }
 });
//?
#endif

//?
#ifdef HIDE
 connect(web_engine_view_, &QWebEngineView::customContextMenuRequested,
   [this](QPoint p)
 {
  qDebug() << "Point: " << p;

  QWebEnginePage* page = web_engine_view_->page();


  QString jscode = load_file(
    "/extension/medInria/medInria-public-master/mmui/cpp/src/mmui/medinria-mmui/paraviews/test.js"
     );

  jscode += QString("elt = document.elementFromPoint(%1, %2); getWordAtPoint(elt, %1, %2)").arg(p.x()).arg(p.y());




  page->runJavaScript(jscode + ";", [this, p] (const QVariant& v)
   {
    QString atr = v.toString();
    qDebug() << "ATR: " << atr;
   });

//?
//  QWebEnginePage* page = web_engine_view_->page();
//  //QString st = page->selectedText();

//  //?QPrinter pdf_printer(QPrinter::HighResolution);

//  page->printToPdf([this](const QByteArray& qba)
//   {
//    if(!qba.isEmpty())
//    {
//     Q_EMIT(view_pdf_requested(qba));
//    }
//   });

  //?qDebug() << "ST: " << st;
 });
//?
#endif

 main_layout_->addWidget(button_box_);

 setLayout(main_layout_);

 if(!url.isEmpty())
 {
  load_url(url);
  url_line_edit_->setText(url);
 }

 show();
}


void Scign_Web_View_Dialog::load_url(QString url)
{
 Scign_Web_Page* mwp = new Scign_Web_Page(this);
 web_engine_view_->setPage(mwp);
 web_engine_view_->load(QUrl(url));
}

void Scign_Web_View_Dialog::load_new_url(QUrl url, QString url_text)
{
 url_line_edit_->setText(url_text);
 url_line_edit_->setCursorPosition(0);
 web_engine_view_->load(url);
}


void Scign_Web_View_Dialog::load_local_file(QString path)
{
 QString url = QString("file://%1").arg(path);
 url_line_edit_->setText(url);
 load_url(url);
}


void Scign_Web_View_Dialog::go_button_clicked()
{
 QString url = url_line_edit_->text();
 web_engine_view_->load(QUrl(url));
}

void Scign_Web_View_Dialog::close_button_clicked()
{
 Q_EMIT(canceled(this));Q_EMIT(rejected());close();
}


//Scign_Web_View_Dialog::Scign_Web_View_Dialog()
// // : parent_(nullptr), antemodel_(nullptr)
//{

//}
//Scign_Web_View_Dialog::Scign_Web_View_Dialog(const Scign_Web_View_Dialog& rhs)
// // : setP(rhs.parent_), antemodel_(rhs.antemodel_)
//{

//}

Scign_Web_View_Dialog::~Scign_Web_View_Dialog()
{
 delete button_ok_;
 delete button_proceed_;
 delete button_cancel_;

// delete url_label_;
// delete name_qle_;
}



void Scign_Web_View_Dialog::cancel()
{
 Q_EMIT(canceled(this));Q_EMIT(rejected());close();
// close();
}

void Scign_Web_View_Dialog::accept()
{
 Q_EMIT(accepted(this));
// close();
}

