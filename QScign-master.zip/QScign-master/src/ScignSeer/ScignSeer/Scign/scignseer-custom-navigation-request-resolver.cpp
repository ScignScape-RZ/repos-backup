
#include "scignseer-custom-navigation-request-resolver.h"


USING_QSNS(MoND_UI)


ScignSeer_Custom_Navigation_Request_Resolver::ScignSeer_Custom_Navigation_Request_Resolver()
  : navigation_recipient_(nullptr)
{

}

bool ScignSeer_Custom_Navigation_Request_Resolver::check_navigation(const QUrl& url)
{
 if(url == origin_url_)
 {
  return true;
 }
 if(navigation_recipient_)
 {
  Q_EMIT(navigation_requested(url, navigation_recipient_));
  return false;
 }
 else
 {
  return true;
 }

}
