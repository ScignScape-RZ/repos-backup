
#ifndef SCIGNSEER_CUSTOM_NAVIGATION_REQUEST_RESOLVER__H
#define SCIGNSEER_CUSTOM_NAVIGATION_REQUEST_RESOLVER__H

#include <QObject>

#include <QString>

#include "qsns.h"

#include "accessors.h"

#include <QUrl>


namespace QScign{ namespace MoND_UI{


class ScignSeer_Custom_Navigation_Request_Resolver : public QObject
{
 Q_OBJECT

 QObject* navigation_recipient_;

 QUrl origin_url_;

public:

 ScignSeer_Custom_Navigation_Request_Resolver();

 ACCESSORS(QObject* ,navigation_recipient)
 ACCESSORS(QUrl ,origin_url)


 bool check_navigation(const QUrl& url);

Q_SIGNALS:

 void navigation_requested(const QUrl&, QObject*);



};


} }

#endif
