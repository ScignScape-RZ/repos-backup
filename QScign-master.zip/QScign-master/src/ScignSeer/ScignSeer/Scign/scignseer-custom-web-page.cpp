
#include "scignseer-custom-web-page.h"

//#include "pdf-document-widget.h"


#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QCheckBox>

#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDebug>
#include <QNetworkRequest>
#include <QTextStream>

#include <QMouseEvent>

#include "scignseer-custom-navigation-request-resolver.h"

USING_QSNS(MoND_UI)

ScignSeer_Custom_Web_Page::ScignSeer_Custom_Web_Page(QWidget* parent, QWebEngineProfile* profile)
 : QWebEnginePage(profile, parent), parent_(parent),
   navigation_request_resolver_(nullptr)//, main_editor_(nullptr)
{

}

bool ScignSeer_Custom_Web_Page::acceptNavigationRequest(const QUrl& url,
  QWebEnginePage::NavigationType type, bool)
{
 qDebug() << "URL: " << url;


 if(navigation_request_resolver_)
 {
  return navigation_request_resolver_->check_navigation(url);
 }
 else
 {
  return true;
 }
}


void ScignSeer_Custom_Web_Page::mousePressEvent(QMouseEvent *event)
{
 QPoint dragPosition = event->pos();
 qDebug() << "DP1: " << dragPosition;
}

void ScignSeer_Custom_Web_Page::mouseReleaseEvent(QMouseEvent *event)
{
 QPoint dragPosition = event->pos();
 qDebug() << "DP2: " << dragPosition;
}

