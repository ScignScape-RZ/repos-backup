
#ifndef ScignSeer_Custom_WEB_PAGE__H
#define ScignSeer_Custom_WEB_PAGE__H


#include <QString>
#include <QMainWindow>

#include <QTextEdit>

//?
//#include <QtWebView>
//#include <QtWebPage>

#include <QWebEnginePage>
#include <QWebEngineView>

//?#include <QWebEngineFrame>

#include <QLabel>
#include <QPushButton>

#include "accessors.h"

#include "flags.h"

#include "qsns.h"

#include <QMap>

class QPushButton;
class QTextEdit;
class QTabWidget;
class QCheckBox;

namespace QScign{ namespace MoND_UI{

class ScignSeer_Custom_Navigation_Request_Resolver;

class ScignSeer_Custom_Web_Page : public QWebEnginePage
{
 Q_OBJECT


 QWidget* parent_;

 QMap<QString, QObject*> inner_controls_;

 ScignSeer_Custom_Navigation_Request_Resolver* navigation_request_resolver_;

public:

 void mousePressEvent(QMouseEvent *event);
 void mouseReleaseEvent(QMouseEvent *event);


 ScignSeer_Custom_Web_Page(QWidget* parent, QWebEngineProfile* profile = nullptr);

 ACCESSORS(ScignSeer_Custom_Navigation_Request_Resolver* ,navigation_request_resolver)


 bool acceptNavigationRequest(const QUrl& url,
   QWebEnginePage::NavigationType type, bool);

// template<typename T>
// T* get_inner_control(QString name)
// {
//  if(inner_controls_.contains(name))
//   return static_cast<T*>(inner_controls_[name]);
//  return nullptr;
// }

// void set_main_contents(QString contents);
// void set_check_box_value(QString name, bool b = true);

// bool get_check_box_value(QString name);

// //?bool handle_main_submit(LSI_DB_Main_Editor* main_editor);


// //?bool acceptNavigationRequest(QWebFrame* frame, const QNetworkRequest &request, NavigationType type);

// QObject* createPlugin(const QString& classid, const QUrl& url,
//  const QStringList& paramNames, const QStringList& paramValues);

//Q_SIGNALS:
// //void main_submit(LSI_DB_Web_Page*, LSI_DB_Main_Editor* main_editor);

////public Q_SLOTS:

};

} } //_QSNS(MoND_UI)

#endif
