
#include "scignseer-custom-web-view-dialog.h"

//#include "scignseer-custom-web-page.h"

//?#include "scign-web-page.h"

//#include "clg-db-antemodel.h";

#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>

#include <QGraphicsRectItem>
#include <QRubberBand>

#include <QPlainTextEdit>
#include <QTextStream>

#include <QTableWidget>

#include <QMessageBox>

#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrlQuery>

#include <QMenu>

#include <QHeaderView>

#include <QListWidget>
#include <QPrinter>

//#include "silotypes/ndp-project/ndp-project.h"
//#include "silotypes/ndp-project/ndp-project-initial.h"

#include "styles.h"

#include "scignseer-custom-web-view.h"

#include "scignseer-custom-navigation-request-resolver.h"

#include "scignseer-custom-web-view-frame.h"



USING_QSNS(MoND_UI)



ScignSeer_Custom_Web_View_Dialog::ScignSeer_Custom_Web_View_Dialog(QString url, QWidget* parent)//, QString url, QWN_XMLDB_Configuration* config)
 : QDialog(parent)
{
 button_box_ = new QDialogButtonBox(this);

 button_ok_ = new QPushButton("OK");
 button_proceed_ = new QPushButton("Proceed");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

 button_proceed_->setDefault(false);
 button_proceed_->setAutoDefault(false);
 //?button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);


// QString colorful_button_style_sheet = colorful_button_style_sheet_();
// QString colorful_toggle_button_style_sheet = colorful_button_quiet_style_sheet_(); //colorful_toggle_button_style_sheet_();
// QString colorful_button_style_sheet_down = colorful_button_style_sheet_down_();
// QString colorful_button_quiet_style_sheet = colorful_button_quiet_style_sheet_();
// QString tab_style_sheet = tab_style_sheet_();
// QString basic_button_style_sheet = basic_button_style_sheet_();




 button_ok_->setStyleSheet(basic_button_style_sheet_());
 button_proceed_->setStyleSheet(basic_button_style_sheet_());
 button_cancel_->setStyleSheet(basic_button_style_sheet_());

// button_ok_->setStyleSheet(button_close_light_style_sheet_());
// button_proceed_->setStyleSheet(button_close_light_style_sheet_());
// button_cancel_->setStyleSheet(button_close_light_style_sheet_());


 connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));


 main_layout_ = new QVBoxLayout;

 main_frame_ = new ScignSeer_Custom_Web_View_Frame(url, this);

 main_layout_->addWidget(main_frame_);

 main_layout_->addWidget(button_box_);

 setLayout(main_layout_);

}

void ScignSeer_Custom_Web_View_Dialog::register_navigation_request_resolver(ScignSeer_Custom_Navigation_Request_Resolver* scnrr)
{
 main_frame_->register_navigation_request_resolver(scnrr);
}

void ScignSeer_Custom_Web_View_Dialog::load_url(const QUrl& url)
{
 main_frame_->load_url(url);
}

void ScignSeer_Custom_Web_View_Dialog::load_url(QString url)
{
 main_frame_->load_url(url);
}

void ScignSeer_Custom_Web_View_Dialog::load_new_url(QUrl url, QString url_text)
{
 main_frame_->load_new_url(url, url_text);
}


void ScignSeer_Custom_Web_View_Dialog::load_local_file(QString path)
{
 main_frame_->load_local_file(path);
}


void ScignSeer_Custom_Web_View_Dialog::close_button_clicked()
{

}

ScignSeer_Custom_Web_View_Dialog::~ScignSeer_Custom_Web_View_Dialog()
{
}


void ScignSeer_Custom_Web_View_Dialog::cancel()
{
 Q_EMIT(rejected());
 Q_EMIT(canceled(this));
 Q_EMIT(rejected());
// close();
//
 close();
}

void ScignSeer_Custom_Web_View_Dialog::proceed()
{
 //?Q_EMIT(proceed_requested(this));
}


void ScignSeer_Custom_Web_View_Dialog::accept()
{
 Q_EMIT(accepted(this));
// close();
}
