
#ifndef SCIGNSEER_WEB_VIEW_DIALOG__H
#define SCIGNSEER_WEB_VIEW_DIALOG__H


#include <QString>
#include <QMainWindow>

#include <QTextEdit>
//?#include <QWebView>

#include <QWebEngineView>
#include <QLabel>
#include <QPushButton>

#include <QDialog>

#include <QApplication>

#include <QComboBox>

#include "accessors.h"

#include "flags.h"

#include "qsns.h"

#include <QEvent>
#include <QMouseEvent>

#include <QFrame>

//#include "incident-form-dialog.h"

class QPushButton;
class QTextEdit;
class QPlainTextEdit;
class QLineEdit;
class QTabWidget;
class QDialogButtonBox;
class QVBoxLayout;
class QHBoxLayout;
class QCheckBox;
class QFormLayout;
class QSplitter;
class QGridLayout;
class QListWidget;
class QTableWidget;
class QScrollArea;
class QGroupBox;
class QTableWidgetItem;
class QGraphicsRectItem;
class QRubberBand;

//qsns_(QWN)
namespace QScign{ namespace MoND_UI{


class NDP_Antemodel;
class NDP_Project;
class NDP_Project_Initial;

class ScignSeer_Custom_Web_View_Frame;
class ScignSeer_Custom_Navigation_Request_Resolver;

class ScignSeer_Custom_Web_View_Dialog : public QDialog
{
 Q_OBJECT

 ScignSeer_Custom_Web_View_Frame* main_frame_;

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QPushButton* button_proceed_;


 QVBoxLayout* main_layout_;



public:

 ScignSeer_Custom_Web_View_Dialog(QString url = QString(), QWidget* parent = nullptr);


 ~ScignSeer_Custom_Web_View_Dialog();


 void register_navigation_request_resolver(ScignSeer_Custom_Navigation_Request_Resolver* scnrr);

 void load_url(const QUrl& url);
 void load_url(QString url);
 void load_new_url(QUrl url, QString url_text);
 void load_local_file(QString path);
 void close_button_clicked();

Q_SIGNALS:
 void canceled(QDialog*);
 void accepted(QDialog*);


public Q_SLOTS:
 void accept();
 void cancel();

 void proceed();


};

} } //_qsns(MMUI)



#endif

