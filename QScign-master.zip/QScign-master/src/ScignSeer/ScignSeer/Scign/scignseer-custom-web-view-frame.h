
#ifndef SCIGNSEER_CUSTOM_WEB_VIEW_FRAME__H
#define SCIGNSEER_CUSTOM_WEB_VIEW_FRAME__H


#include <QString>
#include <QMainWindow>

#include <QTextEdit>
//?#include <QWebView>

#include <QWebEngineView>
#include <QLabel>
#include <QPushButton>

#include <QDialog>

#include <QApplication>

#include <QComboBox>

#include "accessors.h"

#include "flags.h"

#include "qsns.h"

#include <QEvent>
#include <QMouseEvent>

#include <QFrame>

//#include "incident-form-dialog.h"

class QPushButton;
class QTextEdit;
class QPlainTextEdit;
class QLineEdit;
class QTabWidget;
class QDialogButtonBox;
class QVBoxLayout;
class QHBoxLayout;
class QCheckBox;
class QFormLayout;
class QSplitter;
class QGridLayout;
class QListWidget;
class QTableWidget;
class QScrollArea;
class QGroupBox;
class QTableWidgetItem;
class QGraphicsRectItem;
class QRubberBand;

//qsns_(QWN)
namespace QScign{ namespace MoND_UI{


class NDP_Antemodel;
class NDP_Project;
class NDP_Project_Initial;

class ScignSeer_Custom_Web_View;
class ScignSeer_Custom_Navigation_Request_Resolver;


class ScignSeer_Custom_Web_View_Frame : public QFrame
{
 Q_OBJECT


 QLabel* url_label_;
 QLineEdit* url_line_edit_;

 ScignSeer_Custom_Web_View* custom_web_view_;


 QHBoxLayout* url_layout_;
 QVBoxLayout* main_layout_;
 NDP_Antemodel* antemodel_;

 QHBoxLayout* go_button_layout_;
 QPushButton* go_button_;

 QHBoxLayout* close_button_layout_;
 QPushButton* close_button_;

 QRubberBand* rubber_band_;
 QGraphicsRectItem* context_menu_rubber_band_;

 int rubber_band_progression_;

 void read_file(QString path, QPlainTextEdit* qpte);

 QPoint rubber_band_origin_;
 QPoint rubber_band_page_origin_;
 QPoint rubber_band_page_end_;

 int x1_;
 int x2_;

 int y1_;
 int y2_;

 QWebEngineProfile* default_profile_;

 ScignSeer_Custom_Navigation_Request_Resolver* current_navigation_request_resolver_;

public:

 ScignSeer_Custom_Web_View_Frame(QString url = QString(),
   QWidget* parent = nullptr);

 ACCESSORS(ScignSeer_Custom_Navigation_Request_Resolver* ,current_navigation_request_resolver)

 ~ScignSeer_Custom_Web_View_Frame();

 void activate_search(QString text);

 void register_navigation_request_resolver(ScignSeer_Custom_Navigation_Request_Resolver* scnrr);

 QString current_url();

 void load_url(QString url);

 void load_url(const QUrl& url);

 void load_local_file(QString path);

 void load_new_url(QUrl url, QString url_text);

 QString load_file(QString path);

 bool page_mouse_press_event(QMouseEvent* event);
 bool page_mouse_release_event(QMouseEvent* event);
 bool page_mouse_move_event(QMouseEvent* event);

 void show_selection_menu(QPoint p, QString search_term);
 void show_href_context_menu(QPoint p, QString href);


 void restart_search(QString search_term, QString where);


Q_SIGNALS:

 void view_pdf_requested(const QByteArray& qba);
 void page_download_finished(QString mime_type, QString path);

 void bookmark_link_requested(QString origin, QString href);
 void email_link_requested(QString origin, QString href);
 void share_link_requested(QString origin, QString href);

//protected:


public Q_SLOTS:

 void go_button_clicked();
 void close_button_clicked();
 void handle_page_download_requested(QWebEngineDownloadItem*);
 void handle_page_download_finished();


};

} } //_qsns(MMUI)



#endif

