
#include "scignseer-custom-web-view.h"

#include "qsns.h"

#include "scign-web-page.h"

//#include "clg-db-antemodel.h";

#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>

#include <QGraphicsRectItem>
#include <QRubberBand>

#include <QPlainTextEdit>
#include <QTextStream>

#include <QTableWidget>

#include <QMessageBox>

#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrlQuery>

#include <QMenu>

#include <QHeaderView>

#include <QListWidget>

//?#include <QPrinter>

//#include "silotypes/ndp-project/ndp-project.h"
//#include "silotypes/ndp-project/ndp-project-initial.h"

#include "styles.h"

#include "scignseer-custom-web-view-frame.h"



USING_QSNS(MoND_UI)


void ScignSeer_Custom_Web_View::mouseMoveEvent(QMouseEvent* event)
{
 parent_frame_->page_mouse_move_event(event);
}

void ScignSeer_Custom_Web_View::mousePressEvent(QMouseEvent* event)
{
 parent_frame_->page_mouse_press_event(event);
}

void ScignSeer_Custom_Web_View::mouseReleaseEvent(QMouseEvent* event)
{
 parent_frame_->page_mouse_release_event(event);
}

