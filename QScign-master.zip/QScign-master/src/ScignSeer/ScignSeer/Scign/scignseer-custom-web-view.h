
#ifndef SCIGNSEER_CUSTOM_WEB_VIEW__H
#define SCIGNSEER_CUSTOM_WEB_VIEW__H


#include <QString>
#include <QMainWindow>

#include <QTextEdit>
//?#include <QWebView>

#include <QWebEngineView>
#include <QLabel>
#include <QPushButton>

#include <QDialog>

#include <QApplication>

#include <QComboBox>

#include "accessors.h"

#include "flags.h"

#include "qsns.h"

#include <QEvent>
#include <QMouseEvent>

//#include "incident-form-dialog.h"

class QPushButton;
class QTextEdit;
class QPlainTextEdit;
class QLineEdit;
class QTabWidget;
class QDialogButtonBox;
class QVBoxLayout;
class QHBoxLayout;
class QCheckBox;
class QFormLayout;
class QSplitter;
class QGridLayout;
class QListWidget;
class QTableWidget;
class QScrollArea;
class QGroupBox;
class QTableWidgetItem;
class QGraphicsRectItem;
class QRubberBand;

//KANS_(MoND_UI)
namespace QScign{ namespace MoND_UI{


class NDP_Antemodel;
class NDP_Project;
class NDP_Project_Initial;

class ScignSeer_Custom_Web_View_Frame;

class ScignSeer_Custom_Web_View : public QWebEngineView
{
 ScignSeer_Custom_Web_View_Frame* parent_frame_;

public:
    explicit ScignSeer_Custom_Web_View(QWidget *parent = nullptr):
      QWebEngineView(parent),
      parent_frame_(reinterpret_cast<ScignSeer_Custom_Web_View_Frame*>(parent))
//?      parent_dialog_(reinterpret_cast<QDialog*>(parent)) //reinterpret_cast<Sonic_Web_View_Dialog*>(parent))
   {
        QApplication::instance()->installEventFilter(this);
        setMouseTracking(true);
    }

protected:
    bool eventFilter(QObject *object, QEvent *event)
    {
     QMouseEvent* qme = static_cast<QMouseEvent*>(event);
     Qt::KeyboardModifiers mods = qme->modifiers();

     if(mods != Qt::ShiftModifier)
     {
      return false;
     }

     if (object->parent() == this)
     {
      if(event->type() == QEvent::MouseButtonPress)
      {
//       QMouseEvent* qme = static_cast<QMouseEvent*>(event);
       mousePressEvent(qme);
       return true;
      }
      else if(event->type() == QEvent::MouseButtonRelease)
      {
       mouseReleaseEvent(qme);
       return true;
      }
      else if(event->type() == QEvent::MouseMove)
      {
       if(qme->buttons() == Qt::NoButton)
        return false;
       mouseMoveEvent(qme);
       return true;
      }
     }
     //
     return false;
    }

    void mouseMoveEvent(QMouseEvent* event);
    void mousePressEvent(QMouseEvent* event);
    void mouseReleaseEvent(QMouseEvent* event);


};


} } //_KANS(MoND_UI)



#endif

