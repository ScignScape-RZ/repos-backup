
#include "scignseer-html-annotation-dialog.h"

#include "styles.h"

ScignSeer_HTML_Annotation_Dialog::ScignSeer_HTML_Annotation_Dialog(QString annotation_code, QWidget* parent)
 :  QDialog(parent), annotation_code_(annotation_code)
{
 setWindowTitle("ScignSeer: Annotations");

 writer_line_edit_ = new QLineEdit(this);
 annotation_code_line_edit_ = new QLineEdit(annotation_code_, this);
 main_text_edit_ = new QPlainTextEdit(this);
 css_text_edit_ = new QPlainTextEdit(this);

 central_layout_ = new QFormLayout;

 main_tab_widget_ = new QTabWidget(this);
 main_preview_ = new QWebEngineView(this);

 main_frame_ = new QFrame(this);

 main_layout_ = new QVBoxLayout;

 central_layout_->addRow("Writer:", writer_line_edit_);
 central_layout_->addRow("Code:", annotation_code_line_edit_);
 central_layout_->addRow("Text:", main_text_edit_);

 main_frame_->setLayout(central_layout_);
 main_tab_widget_->addTab(main_frame_, "Text");
 main_tab_widget_->addTab(main_preview_, "Preview");
 main_tab_widget_->addTab(css_text_edit_, "CSS");

 main_layout_->addWidget(main_tab_widget_);

 button_box_ = new QDialogButtonBox(this);

 button_ok_ = new QPushButton("OK");
 button_proceed_ = new QPushButton("Proceed");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

 button_proceed_->setDefault(false);
 button_proceed_->setAutoDefault(false);
 //?button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);


 button_ok_->setStyleSheet(basic_button_style_sheet_());
 button_proceed_->setStyleSheet(basic_button_style_sheet_());
 button_cancel_->setStyleSheet(basic_button_style_sheet_());


 connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));

 main_layout_->addWidget(button_box_);

 setLayout(main_layout_);


}

ScignSeer_HTML_Annotation_Dialog::~ScignSeer_HTML_Annotation_Dialog()
{

}

void ScignSeer_HTML_Annotation_Dialog::cancel()
{
 Q_EMIT(rejected());
 Q_EMIT(canceled(this));
 Q_EMIT(rejected());
// close();
//
 close();
}

void ScignSeer_HTML_Annotation_Dialog::proceed()
{
 //?Q_EMIT(proceed_requested(this));
}


void ScignSeer_HTML_Annotation_Dialog::accept()
{
 Q_EMIT(accepted(this));
// close();
}

