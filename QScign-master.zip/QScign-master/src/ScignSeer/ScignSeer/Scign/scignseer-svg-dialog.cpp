
#include "scignseer-svg-dialog.h"

#include "scign-web-page.h"

//#include "clg-db-antemodel.h";

#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>

#include <QGraphicsRectItem>
#include <QRubberBand>

#include <QPlainTextEdit>
#include <QTextStream>

#include <QTableWidget>

#include <QMessageBox>

#include <QDial>

#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrlQuery>

#include <QGraphicsSvgItem>

#include <QMenu>

#include <QHeaderView>

#include <QListWidget>
#include <QPrinter>

//#include "silotypes/ndp-project/ndp-project.h"
//#include "silotypes/ndp-project/ndp-project-initial.h"

#include "styles.h"



USING_QSNS(MoND_UI)


ScignSeer_SVG_Dialog::ScignSeer_SVG_Dialog(QWidget* parent) : QDialog(parent)
{
 setWindowTitle("ScignSeer SVG Viewer");

 button_box_ = new QDialogButtonBox(this);

 button_ok_ = new QPushButton("OK");
 button_proceed_ = new QPushButton("Proceed");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

 button_proceed_->setDefault(false);
 button_proceed_->setAutoDefault(false);

 button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);


 connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));

 main_layout_ = new QVBoxLayout;

 graphics_scene_ = new QGraphicsScene;

 graphics_view_ = new QGraphicsView(this);

 graphics_view_->setScene(graphics_scene_);

 QGraphicsSvgItem* qgsi1 = new QGraphicsSvgItem(
   "/ext_root/kauv/svg/test1.svg");

 qgsi1->setOpacity(0.6);

 QGraphicsSvgItem* qgsi2 = new QGraphicsSvgItem(
   "/ext_root/kauv/svg/test2.svg");

 qgsi2->setOpacity(0.4);

 graphics_scene_->addItem(qgsi1);
 graphics_scene_->addItem(qgsi2);

 //media_player_->setVideoOutput(video_item_);
 //graphics_scene_->show();
 //media_player_->setMedia(QUrl(url));

 url_label_  = new QLabel("File", this);
 url_line_edit_ = new QLineEdit(this);

// if(!url.isEmpty())
// {
//  url_line_edit_->setText(url);
// }

 url_layout_ = new QHBoxLayout;
 url_layout_->addWidget(url_label_);
 url_layout_->addWidget(url_line_edit_);

 central_layout_ = new QHBoxLayout;
 central_layout_->addWidget(graphics_view_);

 QGroupBox* vgb = new QGroupBox("Separation", this);
 //QSlider* vslider = new QSlider(Qt::Vertical, this);
 QDial* vdial = new QDial(this);

 vdial->setNotchesVisible(true);
 //?vdial->setNotchSize(3);

 QVBoxLayout* vvbl = new QVBoxLayout;
 vvbl->addWidget(vdial);
 //vvbl->addWidget(vslider);
 vgb->setLayout(vvbl);

 central_layout_->addWidget(vgb);

 QHBoxLayout* hb = new QHBoxLayout;

 QLabel* lbl = new QLabel("Display Tala Types:", this);

 QComboBox* qcb = new QComboBox(this);
 qcb->addItem("Jhoomra/Dhamar (14 beats)");


 hb->addWidget(lbl);
 hb->addWidget(qcb);
 hb->addStretch();

 main_layout_->addLayout(hb);

 main_layout_->addLayout(central_layout_);

 QGroupBox* hgb = new QGroupBox("Patterns", this);
 QSlider* hslider = new QSlider(Qt::Horizontal, this);

 QHBoxLayout* hhbl = new QHBoxLayout;

 QLabel* p1l = new QLabel("Pattern 1 (3-4-3-4)", this);
 QLabel* p2l = new QLabel("Pattern 2 (5-2-3-4)", this);

 hhbl->addWidget(p1l);
 hhbl->addWidget(hslider);
 hhbl->addWidget(p2l);

 hgb->setLayout(hhbl);
 main_layout_->addWidget(hgb);



// navigation_rewind_button_ = new QPushButton("Restart", this);
// navigation_rewind_button_->setIcon(QIcon("/ext_root/kauv/png/seek-back.svg"));


// navigation_pause_button_ = new QPushButton("Pause", this);
// navigation_pause_button_->setIcon(QIcon("/ext_root/kauv/png/pause2.jpeg"));

// navigation_forward_button_ = new QPushButton("Play", this);
// navigation_forward_button_->setIcon(QIcon("/ext_root/kauv/png/seek-play.png"));

//// navigation_rewind_button_->setStyleSheet(colorful_button_style_sheet_());
//// navigation_pause_button_->setStyleSheet(colorful_button_style_sheet_());
//// navigation_forward_button_->setStyleSheet(colorful_button_style_sheet_());

// navigation_layout_ = new QHBoxLayout;
// navigation_layout_->addStretch();
// navigation_layout_->addWidget(navigation_rewind_button_);
// navigation_layout_->addWidget(navigation_pause_button_);
// navigation_layout_->addWidget(navigation_forward_button_);
// navigation_layout_->addStretch();

// main_layout_->addLayout(navigation_layout_);

 main_layout_->addLayout(url_layout_);

 button_ok_->setStyleSheet(basic_button_style_sheet_()); //button_close_style_sheet);
 button_proceed_->setStyleSheet(basic_button_style_sheet_());
 button_cancel_->setStyleSheet(basic_button_style_sheet_());

 main_layout_->addWidget(button_box_);

 setLayout(main_layout_);

 //?media_player_->play();

 show();
}

ScignSeer_SVG_Dialog::~ScignSeer_SVG_Dialog()
{
 delete button_ok_;
 delete button_proceed_;
 delete button_cancel_;

// delete url_label_;
// delete name_qle_;
}



void ScignSeer_SVG_Dialog::cancel()
{
 Q_EMIT(canceled(this));Q_EMIT(rejected());close();
// close();
}

void ScignSeer_SVG_Dialog::accept()
{
 Q_EMIT(accepted(this));
// close();
}

