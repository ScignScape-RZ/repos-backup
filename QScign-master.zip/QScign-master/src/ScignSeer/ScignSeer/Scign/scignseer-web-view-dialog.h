
#ifndef SONIC_WEB_VIEW_DIALOG__H
#define SONIC_WEB_VIEW_DIALOG__H


#include <QString>
#include <QMainWindow>

#include <QTextEdit>
//?#include <QWebView>

#include <QWebEngineView>
#include <QLabel>
#include <QPushButton>

#include <QDialog>

#include <QApplication>

#include <QComboBox>

#include "accessors.h"

#include "flags.h"

#include "rzns.h"

#include <QEvent>
#include <QMouseEvent>

//#include "incident-form-dialog.h"

class QPushButton;
class QTextEdit;
class QPlainTextEdit;
class QLineEdit;
class QTabWidget;
class QDialogButtonBox;
class QVBoxLayout;
class QHBoxLayout;
class QCheckBox;
class QFormLayout;
class QSplitter;
class QGridLayout;
class QListWidget;
class QTableWidget;
class QScrollArea;
class QGroupBox;
class QTableWidgetItem;
class QGraphicsRectItem;
class QRubberBand;

//RZNS_(QWN)
namespace KA{ namespace MoND_UI{


class NDP_Antemodel;
class NDP_Project;
class NDP_Project_Initial;

class Sonic_Web_View_Dialog;

class Custom_Web_Engine_View : public QWebEngineView
{
 Sonic_Web_View_Dialog* parent_dialog_;
public:
    explicit Custom_Web_Engine_View(QWidget *parent = nullptr):
      QWebEngineView(parent), parent_dialog_(reinterpret_cast<Sonic_Web_View_Dialog*>(parent))
   {
        QApplication::instance()->installEventFilter(this);
        setMouseTracking(true);
    }

protected:
    bool eventFilter(QObject *object, QEvent *event)
    {
     QMouseEvent* qme = static_cast<QMouseEvent*>(event);
     Qt::KeyboardModifiers mods = qme->modifiers();

     if(mods != Qt::ShiftModifier)
     {
      return false;
     }

     if (object->parent() == this)
     {
      if(event->type() == QEvent::MouseButtonPress)
      {
//       QMouseEvent* qme = static_cast<QMouseEvent*>(event);
       mousePressEvent(qme);
       return true;
      }
      else if(event->type() == QEvent::MouseButtonRelease)
      {
       mouseReleaseEvent(qme);
       return true;
      }
      else if(event->type() == QEvent::MouseMove)
      {
       if(qme->buttons() == Qt::NoButton)
        return false;
       mouseMoveEvent(qme);
       return true;
      }
     }
     //
     return false;
    }

    void mouseMoveEvent(QMouseEvent* event);
    void mousePressEvent(QMouseEvent* event);
    void mouseReleaseEvent(QMouseEvent* event);


};

//class Sonic_Web_Engine_Page : public QWebEnginePage
//{
// void mousePressEvent(QMouseEvent *event);
// void mouseReleaseEvent(QMouseEvent *event);
//};


class Sonic_Web_View_Dialog : public QDialog
{
 Q_OBJECT

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QPushButton* button_proceed_;

 QLabel* url_label_;
 QLineEdit* url_line_edit_;

 //QWebEngineView* web_engine_view_;
 Custom_Web_Engine_View* web_engine_view_;


 QHBoxLayout* url_layout_;
 QVBoxLayout* main_layout_;
 NDP_Antemodel* antemodel_;

 QHBoxLayout* go_button_layout_;
 QPushButton* go_button_;

 QHBoxLayout* close_button_layout_;
 QPushButton* close_button_;

 QRubberBand* rubber_band_;
 QGraphicsRectItem* context_menu_rubber_band_;

 int rubber_band_progression_;

 void read_file(QString path, QPlainTextEdit* qpte);

 QPoint rubber_band_origin_;
 QPoint rubber_band_page_origin_;
 QPoint rubber_band_page_end_;

 int x1_;
 int x2_;

 int y1_;
 int y2_;

public:

 Sonic_Web_View_Dialog(QString url = QString(),
   QWidget* parent = nullptr,
   NDP_Antemodel* antemodel = nullptr);

// Sonic_Web_View_Dialog();
// Sonic_Web_View_Dialog(const Sonic_Web_View_Dialog& rhs);

 ~Sonic_Web_View_Dialog();

 void activate_search(QString text);
 void load_url(QString url);
 void load_local_file(QString path);

 void load_new_url(QUrl url, QString url_text);

 QString load_file(QString path);

 bool page_mouse_press_event(QMouseEvent* event);
 bool page_mouse_release_event(QMouseEvent* event);
 bool page_mouse_move_event(QMouseEvent* event);

 void show_selection_menu(QPoint p, QString search_term);

 void restart_search(QString search_term, QString where);


Q_SIGNALS:
 void canceled(QDialog*);
 void accepted(QDialog*);

 void view_pdf_requested(const QByteArray& qba);

//protected:


public Q_SLOTS:
 void accept();
 void cancel();
 //?void proceed();

 void go_button_clicked();
 void close_button_clicked();


};

} } //_RZNS(MMUI)



#endif

