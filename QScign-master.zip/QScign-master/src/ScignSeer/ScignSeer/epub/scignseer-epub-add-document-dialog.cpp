
#include "scignseer-epub-add-document-dialog.h"


//?
#include "styles.h"


#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QButtonGroup>
#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>
#include <QComboBox>

#include <QTimer>
#include <QScreen>

#include <QDateEdit>

#include <QLineEdit>
#include <QTextStream>

#include <QPainter>
#include <QPushButton>
#include <QLabel>

#include <QPlainTextEdit>

#include <QTableWidget>
#include <QGraphicsPixmapItem>

#include <QMessageBox>
#include <QDebug>

#include <QGraphicsView>


#include <QHeaderView>

#include <QMenu>
#include <QAction>

#include <QListWidget>
#include <QDateEdit>


#include <QXmlStreamReader>
#include <QXmlStreamEntityResolver>

//?#include "scignseer-xml-to-ecl-converter.h"


KA_EPub_Add_Document_Dialog::KA_EPub_Add_Document_Dialog(QString file, QWidget* parent)
 : QDialog(parent)
{

 epub_file_path_ = file;

 //?QString path = file;

 epub_folder_path_ = file.replace('.', '_');

// Q_EMIT(metadata_file_ready(x2e.metadata_ecl_path()));
// Q_EMIT(document_file_ready(x2e.document_ecl_path()));
// Q_EMIT(proceed_requested(this));

 //parse_file(file);

 button_box_ = new QDialogButtonBox(this);

 button_ok_ = new QPushButton("OK");
 button_proceed_ = new QPushButton("Proceed");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

 button_proceed_->setDefault(false);
 button_proceed_->setAutoDefault(false);
 //?button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);


 QString colorful_button_style_sheet = colorful_button_style_sheet_();
   //?    QString colorful_toggle_button_style_sheet = colorful_button_quiet_style_sheet_(); //colorful_toggle_button_style_sheet_();
 //?QString colorful_button_style_sheet_down = colorful_button_style_sheet_down_();
 //?QString colorful_button_quiet_style_sheet = colorful_button_quiet_style_sheet_();
 //?QString tab_style_sheet = tab_style_sheet_();
 //?QString basic_button_style_sheet = basic_button_style_sheet_();





 button_ok_->setStyleSheet(basic_button_style_sheet_());
 button_proceed_->setStyleSheet(basic_button_style_sheet_());
 button_cancel_->setStyleSheet(basic_button_style_sheet_());


 connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));


 main_layout_ = new QVBoxLayout;

 path_info_layout_ = new QFormLayout;

 epub_file_path_line_edit_ = new QLineEdit(epub_file_path_, this);
 epub_folder_path_line_edit_ = new QLineEdit(epub_folder_path_, this);

 path_info_layout_->addRow("EPub File:", epub_file_path_line_edit_);
 path_info_layout_->addRow("Unzip to Folder:", epub_folder_path_line_edit_);

 main_layout_->addLayout(path_info_layout_);

 unzip_button_ = new QPushButton("Unzip...", this);

 unzip_button_->setStyleSheet(colorful_button_style_sheet);

 connect(unzip_button_, SIGNAL(clicked()),
   this, SIGNAL(unzip_requested()));

 unzip_layout_ = new QHBoxLayout;

 unzip_layout_->addStretch();
 unzip_layout_->addWidget(unzip_button_);
 unzip_layout_->addStretch();


 main_layout_->addLayout(unzip_layout_);

 main_layout_->addStretch();

 main_layout_->addWidget(button_box_);

 //?main_layout_->addLayout(clear_button_layout_);

 setLayout(main_layout_);

 show();
}



KA_EPub_Add_Document_Dialog::~KA_EPub_Add_Document_Dialog()
{
 delete button_ok_;
 delete button_proceed_;
 delete button_cancel_;

// delete url_label_;
// delete name_ qLe_;
}



void KA_EPub_Add_Document_Dialog::cancel()
{
 Q_EMIT(rejected());
 Q_EMIT(canceled(this));
 Q_EMIT(rejected());
 close();
//
 close();
}

void KA_EPub_Add_Document_Dialog::proceed()
{
 //?Q_EMIT(proceed_requested(this));
}


void KA_EPub_Add_Document_Dialog::accept()
{
 Q_EMIT(accepted(this));
// close();
}



