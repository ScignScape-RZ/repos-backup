
#ifndef SCIGNSEER_EPUB_BOOK_INFO_DIALOG__H
#define SCIGNSEER_EPUB_BOOK_INFO_DIALOG__H


#include <QString>
#include <QMainWindow>

#include <QTextEdit>
//?#include <QWebView>

#include <QWebEngineView>
#include <QLabel>
#include <QPushButton>

#include <QDialog>

#include <QApplication>

#include <QComboBox>

#include "accessors.h"

#include "flags.h"

#include "qsns.h"

#include <QEvent>
#include <QMouseEvent>

//#include "incident-form-dialog.h"

class QPushButton;
class QTextEdit;
class QPlainTextEdit;
class QLineEdit;
class QTabWidget;
class QDialogButtonBox;
class QVBoxLayout;
class QHBoxLayout;
class QCheckBox;
class QFormLayout;
class QSplitter;
class QGridLayout;
class QListWidget;
class QTableWidget;
class QScrollArea;
class QGroupBox;
class QTableWidgetItem;
class QGraphicsRectItem;
class QRubberBand;

class ScignSeer_EPub_Document;

class ScignSeer_EPub_Book_Info_Dialog : public QDialog
{
 Q_OBJECT

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QPushButton* button_proceed_;

 QVBoxLayout* main_layout_;

 QFormLayout* main_info_layout_;

// QString author_;
// QString title_;
// QString language_;
// QString date_;

 QLineEdit* author_line_edit_;
 QLineEdit* title_line_edit_;
 QLineEdit* language_line_edit_;
 QLineEdit* date_line_edit_;


 ScignSeer_EPub_Document* main_document_;

public:

 ScignSeer_EPub_Book_Info_Dialog(ScignSeer_EPub_Document* main_document, QWidget* parent = nullptr);

 ~ScignSeer_EPub_Book_Info_Dialog();


Q_SIGNALS:
 void canceled(QDialog*);
 void accepted(QDialog*);


public Q_SLOTS:
 void accept();
 void cancel();
 //?void proceed();


};

//?} } //_qsns(MMUI)



#endif

