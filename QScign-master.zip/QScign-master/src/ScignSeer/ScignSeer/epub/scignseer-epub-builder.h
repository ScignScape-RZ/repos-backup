

#ifndef SCIGNSEER_EPUB_BUILDER__H
#define SCIGNSEER_EPUB_BUILDER__H

#include <QObject>

#include <QMetaType>

#include <QMap>

#include "accessors.h"

#include "scignseer-epub-document.h"

#include "scignseer-epub-metadata-content.h"
#include "scignseer-epub-spine-item.h"


class KA_EPub_builder : public QObject
{
 Q_OBJECT


 enum class Read_State {

  N_A, Initial, Metadata, Manifest, Spine

 };

 Read_State read_state_;

 KA_EPub_Metadata_Content metadata_content_;
 KA_EPub_Spine_Item spine_item_;



 ScignSeer_EPub_Document* epub_document_;

public:


 KA_EPub_builder();

 KA_EPub_builder(const KA_EPub_builder& rhs);

 ~KA_EPub_builder();


 ACCESSORS(ScignSeer_EPub_Document* ,epub_document)

 Q_INVOKABLE void check_construction();

 Q_INVOKABLE void absorb_attr(QString attr, QString value);

 Q_INVOKABLE void Tag__metadata();

 Q_INVOKABLE void Tag_title(QString ns, QString str);

 Q_INVOKABLE void Tag_date(QString ns, QString str);

//? Q_INVOKABLE void Tag_title_info(QString str);
 Q_INVOKABLE void Tag_description(QString str);
 Q_INVOKABLE void Tag_creator(QString ns, QString str);
 Q_INVOKABLE void Tag_last_name(QString str);
//? Q_INVOKABLE void Tag_book_title(QString str);
 Q_INVOKABLE void Tag_language(QString ns, QString str);

 typedef QMap<QString,QString> QStringMap_type;

 Q_INVOKABLE void Tag_identifier(QString ns, const QStringMap_type&);
 Q_INVOKABLE void Tag_meta(const QStringMap_type&);
 Q_INVOKABLE void Tag_item(const QStringMap_type&);

// content.opf

// metadata dc:language
// author (dc:creator role=aut)
// dc:title

// spine-item
//  href
//  id
//  media-type

// spine
//  itemref idref=

// <spine toc="ncx">
//     <itemref idref

// ris  enw  bib
// <manifest>
//     <item href="muirjohn3254032540-8.jpg" id="added" media-type


// ncx/head/meta/  dtb:depth   dtb:totalPageCount  dtb:maxPageNumber

// ncx/docTitle/text

// xmlns="http://www.daisy.org/z3986/2005/ncx/" version="2005-1" xml:lang="en">
//   /head>
//     <meta content="urn:uuid:17b24c10-99fc-498d-bec5-659f113bd03d"
// name="dtb:uid"/>
//     <meta content="1" name="dtb:depth"/>
//     <meta content="calibre (0.6.13)" name="dtb:generator"/>
//     <meta content="0" name="dtb:totalPageCount"/>
//     <meta content="0" name



};


Q_DECLARE_METATYPE(KA_EPub_builder*)
Q_DECLARE_METATYPE(KA_EPub_builder)

#endif  // ScignSeer_FB2_DIALOG__H

