
#include "scignseer-epub-document.h"

#include <QDebug>

ScignSeer_EPub_Document::ScignSeer_EPub_Document()
{

}

void ScignSeer_EPub_Document::add_spine_item(QString id, QString href, QString media_type)
{
 KA_EPub_Spine_Item si;
 si.set_id(id);
 si.set_href(href);
 si.set_media_type(media_type);
 spine_items_.push_back(si);
}

const KA_EPub_Spine_Item* ScignSeer_EPub_Document::get_first_html_page()
{
 for(const KA_EPub_Spine_Item& si : spine_items_)
 {
  if(si.media_type().contains("xhtml"))
  {
   if(si.id() == "nav")
   {
    continue;
   }
   return &si;
  }
 }
 return nullptr;
}

const KA_EPub_Spine_Item* ScignSeer_EPub_Document::get_nav_page()
{
 for(const KA_EPub_Spine_Item& si : spine_items_)
 {
  if(si.media_type().contains("xhtml"))
  {
   if(si.id() == "nav")
   {
    return &si;
   }
  }
 }
 return nullptr;
}
