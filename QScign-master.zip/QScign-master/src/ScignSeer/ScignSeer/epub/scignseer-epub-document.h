

#ifndef SCIGNSEER_EPUB_DOCUMENT__H
#define SCIGNSEER_EPUB_DOCUMENT__H

#include <QObject>

#include <QMetaType>

#include "accessors.h"

#include "scignseer-epub-metadata-content.h"
#include "scignseer-epub-spine-item.h"


class ScignSeer_EPub_Document
{

 KA_EPub_Metadata_Content metadata_;

 QList<KA_EPub_Spine_Item> spine_items_;

 //KA_EPub_Metadata_Content metadata_;

// QString description_;
// QString author_;
// QString last_name_;
// QString book_title_;
// QString lang_;

public:


 ACCESSORS__RGET(KA_EPub_Metadata_Content ,metadata)
 ACCESSORS__RGET(QList<KA_EPub_Spine_Item> ,spine_items)

 ScignSeer_EPub_Document();

 const KA_EPub_Spine_Item* get_first_html_page();

 const KA_EPub_Spine_Item* get_nav_page();

 void add_spine_item(QString id, QString href, QString media_type);

};

#endif  // ScignSeer_FB2_DOCUMENT__H

