
#ifndef SCIGNSEER_EPUB_METADATA_CONTENT__H
#define SCIGNSEER_EPUB_METADATA_CONTENT__H

#include <QObject>

#include <QString>

#include "accessors.h"

//#include "scignseer-epub-document.h"


class KA_EPub_Metadata_Content
{
 QString author_;
 QString title_;
 QString language_;
 QString date_;

 //  id
 //  media-type

public:

 ACCESSORS(QString ,author)
 ACCESSORS(QString ,title)
 ACCESSORS(QString ,language)
 ACCESSORS(QString ,date)

 KA_EPub_Metadata_Content();


};

#endif

