
#ifndef SCIGNSEER_EPUB_SPINE_ITEM__H
#define SCIGNSEER_EPUB_SPINE_ITEM__H

#include <QObject>

#include <QString>

#include "accessors.h"

//#include "scignseer-epub-document.h"


class KA_EPub_Spine_Item
{
 QString href_;
 QString id_;
 QString media_type_;

 //  id
 //  media-type

public:

 ACCESSORS(QString ,href)
 ACCESSORS(QString ,id)
 ACCESSORS(QString ,media_type)

 KA_EPub_Spine_Item();


};

#endif
