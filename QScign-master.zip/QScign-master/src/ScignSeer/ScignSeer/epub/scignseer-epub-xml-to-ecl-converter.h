
#ifndef SCIGNSEER_EPUB_XML_TO_ECL_CONVERTER__H
#define SCIGNSEER_EPUB_XML_TO_ECL_CONVERTER__H

#include "accessors.h"

#include <QString>
#include <QMap>

#include <QXmlStreamReader>
#include <QXmlStreamEntityResolver>

#include "sexpresso.hpp"

#include "sexp/value.hpp"


//class XSER : public QXmlStreamEntityResolver
//{
// QString resolveUndeclaredEntity(const QString& ent) override;

//};

//QString XSER::resolveUndeclaredEntity(const QString& ent)
//{
// qDebug()  << "Ent: " << ent;
// return "QString()";

//}

class QXmlStreamAttributes;

class ScignSeer_EPub_XML_To_ECL_Converter
{
 struct Entity_Resolver : public QXmlStreamEntityResolver
 {
  QString resolveUndeclaredEntity(const QString& ent) override;
 };

 enum class Output_Stage {
   N_A, Prelim, Metadata, Body, After_Body
 };

 Output_Stage output_stage_;


 Entity_Resolver entity_resolver_;

 QString content_opf_path_;
 QString data_ecl_path_;
 QString document_ecl_path_;

 QString document_html_path_;

 QString root_tag_name_;
 QString document_tag_name_;
 QString metadata_function_name_;

 QString data_text_;
 QString document_text_;
 QString prelim_text_;

 QString document_html_;

 QString* current_string_;

 QString unzip_path_;

 void write_tag_start(QString tag_name, QXmlStreamAttributes& attrs);
 void write_tag_end(QString tag_name);
 void write_text(QString text);

 void write_xml_style_attributes_string(QString& result, const QXmlStreamAttributes& attrs);
 void write_ecl_style_attributes_map(QString& result, const QXmlStreamAttributes& attrs);

 QMap<QString, QString> object_tags_;

 QString held_tag_name_;

 QString held_attributes_string_;

public:


 ACCESSORS(QString ,data_ecl_path)
 ACCESSORS(QString ,document_ecl_path)

 ACCESSORS(QString ,content_opf_path)

 ACCESSORS(QString ,document_html_path)

 ACCESSORS(QString ,root_tag_name)
 ACCESSORS(QString ,document_tag_name)
 ACCESSORS(QString ,metadata_function_name)

 ACCESSORS(QString ,unzip_path)

 ScignSeer_EPub_XML_To_ECL_Converter(QString unzip_path = QString());

 void add_object_tag(QString tag, QString class_name = QString());

 void run_conversion();

 void run_content_opf_conversion();

 void write_sexp_to_file(sexp::Value& sv, QString path);
 void write_raw_sexp_to_file(QString text, QString path);



};


#endif

