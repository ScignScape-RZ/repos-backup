
#include "view-parse-dialog.h"

//#include "scign-web-page.h"

//#include "clg-db-antemodel.h";

#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>

#include <QGraphicsRectItem>
#include <QRubberBand>

#include <QPlainTextEdit>
#include <QTextStream>

#include <QTableWidget>

#include <QMessageBox>

#include <QDial>

#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrlQuery>

#include <QGraphicsSvgItem>

#include <QMenu>

#include <QHeaderView>

#include <QListWidget>
#include <QPrinter>

//#include "silotypes/ndp-project/ndp-project.h"
//#include "silotypes/ndp-project/ndp-project-initial.h"

#include <QRegularExpression>

#include "styles.h"



USING_QSNS(MoND_UI)


void View_Parse_Dialog::parse_sentence(QString sentence,
  QList<QGraphicsTextItem*>& items,
  QMap<QString, QGraphicsTextItem*>& items_map, QStringList& word_list)
{
 QRegularExpression rx = QRegularExpression("(\\(|\\)|[\\w']+|\\s+)");
 int pos = 0;

 QMap<QString, int> counts;

 while(pos < sentence.length())
 {
  QRegularExpressionMatch rxm = rx.match(sentence, pos);
  if(!rxm.hasMatch())
   break;
  QString qs = rxm.captured();
  pos += qs.length();
  qs = qs.trimmed();
  if(!qs.isEmpty())
  {
   bool is_word;
   if(qs == '(' || qs == ')')
   {
    is_word = false;
   }
   else
   {
    is_word = true;
    word_list.push_back(qs);
   }
   QGraphicsTextItem* qgti = new QGraphicsTextItem(qs);
   int count = ++counts[qs];
   items_map.insert(QString("%1#%2").arg(qs).arg(count), qgti);
   items.push_back(qgti);
  }

 }
}


void View_Parse_Dialog::add_link_marking(QString left, QString right,
  qreal left_offset, qreal right_offset, QString label, QPen& qpen,
  qreal height, QMap<QString, QGraphicsTextItem*>& items_map)
{
 QGraphicsTextItem* li = items_map.value(left);
 QGraphicsTextItem* ri = items_map.value(right);

 if(!(li && ri))
 {
  return;
 }


 qreal lx = li->pos().x() + li->boundingRect().center().x() + left_offset;
 qreal lbottom = li->boundingRect().top();
 qreal ltop = lbottom - height;

 graphics_scene_->addLine(lx, ltop, lx, lbottom, qpen);

 qreal rx = ri->pos().x() + ri->boundingRect().center().x() + right_offset;
 qreal rbottom = ri->boundingRect().top();
 qreal rtop = rbottom - height;

 qreal center_x = (lx + rx) / 2;
 qreal center_y = (ltop + rtop) / 2;

 graphics_scene_->addLine(rx, rtop, rx, rbottom, qpen);

 QGraphicsTextItem* label_item = graphics_scene_->addText(label);

 qreal w = label_item->boundingRect().width();
 qreal h = label_item->boundingRect().height();

 qreal label_left_x = center_x - w/2;
 qreal label_left_y = center_y - h/2;

 qreal label_right_x = center_x + w/2;

 label_item->setX(label_left_x);
 label_item->setY(label_left_y);

 qreal line_offset = 3;


 graphics_scene_->addLine(lx, center_y,
   label_left_x - line_offset, center_y, qpen);

 graphics_scene_->addLine(label_right_x + line_offset, center_y,
   rx, center_y, qpen);




}


void View_Parse_Dialog::parse_types(QString lex, QStringList& types)
{
 QStringList qsl = lex.split('\n');

 for(QString qs : qsl)
 {
  if(!qs.trimmed().isEmpty())
  {
   types.push_back(qs);
  }
 }
}


View_Parse_Dialog::View_Parse_Dialog(QWidget* parent) : QDialog(parent)
{
 setWindowTitle("ScignSeer Parse Viewer");

 button_box_ = new QDialogButtonBox(this);

 button_ok_ = new QPushButton("OK");
 button_proceed_ = new QPushButton("Proceed");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

 button_proceed_->setDefault(false);
 button_proceed_->setAutoDefault(false);

 button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);


 connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));

 main_layout_ = new QVBoxLayout;

 graphics_scene_ = new QGraphicsScene;

 graphics_view_ = new QGraphicsView(this);

 graphics_view_->setScene(graphics_scene_);

 QList<QGraphicsTextItem*> items;

 QMap<QString, QGraphicsTextItem*> items_map;

 QStringList word_list;

// parse_sentence("(loves (everyone's father)(her mother))", items, items_map, word_list);

 parse_sentence("(received (every ((no with) money) passenger)(a (warning note)))", items, items_map, word_list);

 qreal left = 0;
 qreal char_width = 6;

 for(QGraphicsTextItem* qgti : items)
 {
  qgti->setFlag(QGraphicsItem::ItemIsMovable);
  qgti->setX(left * char_width);
  left += qgti->toPlainText().size() + 1;
  graphics_scene_->addItem(qgti);
 }

 qreal height = 10;

 QColor qc1(150,25,25,180);
 QColor qc2(25,150,25,180);
 QColor qc3(25,25,150,180);

 QBrush qbr1(qc1);
 QBrush qbr2(qc2);
 QBrush qbr3(qc3);


 QPen qpen1(qbr1, 3);
 QPen qpen2(qbr2, 3);
 QPen qpen3(qbr3, 3);

 add_link_marking("every#1", "a#1", 0, -1, "Scope-Blend", qpen1,
   height * 1.2, items_map);

// add_link_marking("loves#1", "her#1", -1, -1, "VDO", qpen2,
//   height * 2.5, items_map);

// add_link_marking("everyone's#1", "her#1", 1, 1, "Scope?", qpen3,
//   height * 4, items_map);


 url_label_  = new QLabel("File", this);
 url_line_edit_ = new QLineEdit("/extension/ScignSeer/pdf/Chung-Chieh-Shan.pdf", this);

// if(!url.isEmpty())
// {
//  url_line_edit_->setText(url);
// }

 url_layout_ = new QHBoxLayout;
 url_layout_->addWidget(url_label_);
 url_layout_->addWidget(url_line_edit_);

 central_layout_ = new QHBoxLayout;
 central_layout_->addWidget(graphics_view_);


 main_layout_->addLayout(central_layout_);

 QFormLayout* lexical_info_layout = new QFormLayout;

 int i = 0;

 QStringList types;

// QString lex = R"__(
//    N .-> N ..-> P
//    N ..-> N
//    N
//    N ..-> N
//    N
//   )__";
//(received (every ((no with) money) passenger)(a (warning note)))

  QString lex = R"__(
     N .-> N ..-> P
     J .-> N ..-> N
     J ..-> J
     J
     N
     N
     N ..-> N
     N ..-> N
     Nd
    )__";

 parse_types(lex, types);

 for(QString word : word_list)
 {
  QString lex_type = types.value(i);
  ++i;
  lexical_info_layout->addRow(word, new QLineEdit(lex_type, this));
 }

 main_layout_->addLayout(lexical_info_layout);

 main_layout_->addStretch();



// navigation_rewind_button_ = new QPushButton("Restart", this);
// navigation_rewind_button_->setIcon(QIcon("/ext_root/kauv/png/seek-back.svg"));


// navigation_pause_button_ = new QPushButton("Pause", this);
// navigation_pause_button_->setIcon(QIcon("/ext_root/kauv/png/pause2.jpeg"));

// navigation_forward_button_ = new QPushButton("Play", this);
// navigation_forward_button_->setIcon(QIcon("/ext_root/kauv/png/seek-play.png"));

//// navigation_rewind_button_->setStyleSheet(colorful_button_style_sheet_());
//// navigation_pause_button_->setStyleSheet(colorful_button_style_sheet_());
//// navigation_forward_button_->setStyleSheet(colorful_button_style_sheet_());

// navigation_layout_ = new QHBoxLayout;
// navigation_layout_->addStretch();
// navigation_layout_->addWidget(navigation_rewind_button_);
// navigation_layout_->addWidget(navigation_pause_button_);
// navigation_layout_->addWidget(navigation_forward_button_);
// navigation_layout_->addStretch();

// main_layout_->addLayout(navigation_layout_);

 main_layout_->addLayout(url_layout_);

 button_ok_->setStyleSheet(basic_button_style_sheet_()); //button_close_style_sheet);
 button_proceed_->setStyleSheet(basic_button_style_sheet_());
 button_cancel_->setStyleSheet(basic_button_style_sheet_());

 main_layout_->addWidget(button_box_);

 setLayout(main_layout_);

 //?media_player_->play();

 show();
}

View_Parse_Dialog::~View_Parse_Dialog()
{
 delete button_ok_;
 delete button_proceed_;
 delete button_cancel_;

// delete url_label_;
// delete name_qle_;
}



void View_Parse_Dialog::cancel()
{
 Q_EMIT(canceled(this));Q_EMIT(rejected());close();
// close();
}

void View_Parse_Dialog::accept()
{
 Q_EMIT(accepted(this));
// close();
}

