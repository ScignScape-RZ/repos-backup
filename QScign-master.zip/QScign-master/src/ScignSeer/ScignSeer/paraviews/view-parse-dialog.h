
#ifndef View_Parse_Dialog__H
#define View_Parse_Dialog__H


#include <QString>
#include <QMainWindow>

#include <QTextEdit>
//?#include <QWebView>

#include <QWebEngineView>
#include <QLabel>
#include <QPushButton>

#include <QDialog>

#include <QApplication>

#include <QComboBox>

#include "accessors.h"

#include "flags.h"

#include "qsns.h"

#include <QEvent>
#include <QMouseEvent>

//#include "incident-form-dialog.h"

class QPushButton;
class QTextEdit;
class QPlainTextEdit;
class QLineEdit;
class QTabWidget;
class QDialogButtonBox;
class QVBoxLayout;
class QHBoxLayout;
class QCheckBox;
class QFormLayout;
class QSplitter;
class QGridLayout;
class QListWidget;
class QTableWidget;
class QScrollArea;
class QGroupBox;
class QTableWidgetItem;
class QGraphicsRectItem;
class QRubberBand;

#include <QtMultimedia>
#include <QtMultimediaWidgets>



//qsns_(QWN)
namespace QScign{ namespace MoND_UI{


class NDP_Antemodel;
class NDP_Project;
class NDP_Project_Initial;

class Sonic_Web_View_Dialog;


class View_Parse_Dialog : public QDialog
{
 Q_OBJECT

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QPushButton* button_proceed_;

 QLabel* url_label_;
 QLineEdit* url_line_edit_;


// QMediaPlayer* media_player_;
// QGraphicsVideoItem* video_item_;

 QGraphicsScene* graphics_scene_;
 QGraphicsView* graphics_view_;

 QHBoxLayout* central_layout_;


// graphicsView->scene()->addItem(item);
// graphicsView->show();

// player->setMedia(QUrl("http://example.com/myclip4.ogv"));
// player->play();

// QHBoxLayout* navigation_layout_;
// QPushButton* navigation_rewind_button_;
// QPushButton* navigation_pause_button_;
// QPushButton* navigation_forward_button_;

 QHBoxLayout* url_layout_;
 QVBoxLayout* main_layout_;

 void parse_sentence(QString sentence, QList<QGraphicsTextItem*>& items,
   QMap<QString, QGraphicsTextItem*>& items_map, QStringList& word_list);


 void add_link_marking(QString left, QString right,
   qreal left_offset, qreal right_offset,
   QString label, QPen& qpen,
   qreal height,
   QMap<QString, QGraphicsTextItem*>& items_map);


 void parse_types(QString lex, QStringList& types);

public:

 View_Parse_Dialog(QWidget* parent = nullptr);


 ~View_Parse_Dialog();


Q_SIGNALS:

 void canceled(QDialog*);
 void accepted(QDialog*);


public Q_SLOTS:
 void accept();
 void cancel();
 //?void proceed();

// void go_button_clicked();
// void close_button_clicked();


};

} } //_qsns(MMUI)



#endif

