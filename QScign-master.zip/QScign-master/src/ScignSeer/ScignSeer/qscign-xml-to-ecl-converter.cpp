
#include "qscign-xml-to-ecl-converter.h"

#include <QFile>
#include <QTextStream>
#include <QDebug>


#include "sexpresso.hpp"
#include "sexp/parser.hpp"

#include "textio.h"


QScign_XML_To_ECL_Converter::QScign_XML_To_ECL_Converter()
 :  current_string_(nullptr), output_stage_(Output_Stage::N_A)
 //  QString xml_file_path,
 //  QString metadata_ecl_path, QString document_ecl_path)
{
 output_stage_ = Output_Stage::Prelim;
 current_string_ = &prelim_text_;
}


void QScign_XML_To_ECL_Converter::add_object_tag(QString tag)
{
 object_tags_.insert(tag, tag);

}


QString QScign_XML_To_ECL_Converter::Entity_Resolver::resolveUndeclaredEntity(const QString& ent)
{
 qDebug()  << "Ent: " << ent;
 return "QString()";
}

void QScign_XML_To_ECL_Converter::write_raw_sexp_to_file(QString text, QString path)
{
 QFile outfile(path);
 if(outfile.open(QIODevice::WriteOnly | QIODevice::Text))
 {
  QTextStream outstr(&outfile);
  outstr << text;
  outfile.close();
 }
}

void QScign_XML_To_ECL_Converter::write_sexp_to_file(sexp::Value& sv, QString path)
{
 QFile outfile(path);

 if(outfile.open(QIODevice::WriteOnly | QIODevice::Text))
 {
  QTextStream outstr(&outfile);

  QString vstr = QString::fromStdString(sv.str_with_indent(0));
  outstr << vstr;
  outfile.close();
 }
}

void QScign_XML_To_ECL_Converter::run_conversion()
{
 QFile file(xml_file_path_);

 if(file.open(QIODevice::ReadOnly))
 {
  QXmlStreamReader xmlReader;
  xmlReader.setDevice(&file);

  xmlReader.setEntityResolver(&entity_resolver_);

  //QString exp_end;

  xmlReader.readNext();
  bool end_ok = false;

  while (!xmlReader.atEnd())
  {
   if(xmlReader.isEndDocument())
   {
    qDebug() << "ignore...";
    break;
   }
   if(xmlReader.isStartElement())
   {
    QString name = xmlReader.name().toString();
    if(name == root_tag_name_)
    {
     current_string_ = &metadata_text_;
     output_stage_ = Output_Stage::Metadata;
    }
    else if(name == document_tag_name_)
    {
     current_string_ = &document_text_;
     output_stage_ = Output_Stage::Body;
    }
    write_tag_start(name);
   }
   else if (xmlReader.isEndElement())
   {
    QString name = xmlReader.name().toString();
    write_tag_end(name);
    if(name == root_tag_name_)
    {
     end_ok = true;
    }
    else if(name == document_tag_name_)
    {
     current_string_ = &metadata_text_;
     output_stage_ = Output_Stage::After_Body;
    }
    //?xmlReader.readNext();
   }
   else if (xmlReader.isEntityReference())
   {
    qDebug() << "xmlReader.entityResolver()->";
   }
   else
   {
    QStringRef textr = xmlReader.text();
    QString text = textr.toString().simplified();
    if(!text.isEmpty())
    {
     write_text(text);
    }
   }
   xmlReader.readNext();

   if(xmlReader.isEndDocument())
   {
    qDebug() << "ED:";
    end_ok = true;
   }

   //   if(xmlReader.atEnd())
   //   {
   //    qDebug() << "AE:";
   //    break;
   //   }


  }
  if (xmlReader.hasError())
  {
  //? if(!end_ok)
    qDebug() << "XML error: " << xmlReader.errorString();
  }


  metadata_text_.prepend("\n(progn\n\n");
  metadata_text_.append("\n);progn\n\n");

  document_text_.prepend("\n(progn\n\n");
  document_text_.append("\n);progn\n\n");

  QScign::TextIO::save_file(document_html_path_, document_html_);

  write_raw_sexp_to_file(metadata_text_, metadata_ecl_path_ + ".rawt");
  write_raw_sexp_to_file(document_text_, document_ecl_path_ + ".rawt");


  //?   sexp::Value value_m = sexp::Parser::from_string(mt.toStdString());

  //?
  sexp::Value value_m = sexp::Parser::from_string(metadata_text_.toStdString());
  sexp::Value value_d = sexp::Parser::from_string(document_text_.toStdString());

  write_sexp_to_file(value_m, metadata_ecl_path_);

  //?
  write_sexp_to_file(value_d, document_ecl_path_);
 }
}

void QScign_XML_To_ECL_Converter::write_tag_start(QString tag_name)
{
 if(output_stage_ == Output_Stage::Body)
 {
  document_html_.append(QString("\n <%1> ").arg(tag_name));
 }
 if(object_tags_.contains(tag_name))
 {
  tag_name = QString("@%1_").arg(object_tags_[tag_name]);
  current_string_->append(QString("(qtag '|%1|)").arg(tag_name));
 }
 else
 {
  current_string_->append(QString("(qtag '|%1| ").arg(tag_name));
 }
}

void QScign_XML_To_ECL_Converter::write_tag_end(QString tag_name)
{
 if(output_stage_ == Output_Stage::Body)
 {
  document_html_.append(QString(" </%1> ").arg(tag_name));
 }
 if(object_tags_.contains(tag_name))
 {
  tag_name = QString("@_%1").arg(object_tags_[tag_name]);
  current_string_->append(QString("(qtag '|%1|)").arg(tag_name));
  //current_string_->append(QString("\n);%1\n").arg(tag_name)); //')');
 }
 else
 {
  current_string_->append(QString("\n);%1\n").arg(tag_name)); //')');
 }
}

void QScign_XML_To_ECL_Converter::write_text(QString text)
{
 if(output_stage_ == Output_Stage::Body)
 {
  document_html_.append(text);
 }
 text.replace('"', "%qq%");
 current_string_->append(QString(" \"%1\" ").arg(text));
}



//void ScignSeer_FB2_Dialog::parse_file(QString path)
//{
// XSER* xser = new XSER();

// QFile file(path);

// if(file.open(QIODevice::ReadOnly))
// {
//  QXmlStreamReader xmlReader;
//  xmlReader.setDevice(&file);

//  xmlReader.setEntityResolver(xser);

//  QString exp_end;

//  //?QList<Student> students;
//  xmlReader.readNext();
//  //Reading from the file
//   //?
//   //?

//  //?

//  bool end_ok = false;

//  //?while (!xmlReader.isEndDocument())
//   //?
//  //?
//   //
//   //?
//  while (!xmlReader.atEnd())
//  {

//   if(xmlReader.isEndDocument())
//   {
//    qDebug() << "ignore...";
//    break;
//   }
//   if (xmlReader.isStartElement())
//   {
//    QString name = xmlReader.name().toString();

//    if(exp_end.isEmpty())
//    {
//     exp_end = name;
//    }


//    qDebug() << "Name: " << name;

//    if(name == "p")
//    {
//     qDebug() << "!p";
//    }

////?    xmlReader.readNext();
//   }
//   else if (xmlReader.isEndElement())
//   {
//    if(exp_end == xmlReader.name())
//    {
//     qDebug() << "End Found";
//     end_ok = true;
//    }

//    xmlReader.readNext();
//   }
//   else if (xmlReader.isEntityReference())
//   {
//    qDebug() << "xmlReader.entityResolver()->";
//   }
//   else
//   {
//    QStringRef txt = xmlReader.text();

//    qDebug() << "TXT: " << txt;

////?    xmlReader.readNext();
//   }
//   xmlReader.readNext();

//   if(xmlReader.isEndDocument())
//   {
//    qDebug() << "ED:";
//    end_ok = true;
//   }

////   if(xmlReader.atEnd())
////   {
////    qDebug() << "AE:";
////    break;
////   }


//  }
//  if (xmlReader.hasError())
//  {
//   if(!end_ok)
//     qDebug() << "XML error: " << xmlReader.errorString();
//  }
// }
//}








