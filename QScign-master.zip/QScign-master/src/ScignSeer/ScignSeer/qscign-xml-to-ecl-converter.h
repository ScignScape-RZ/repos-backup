
#ifndef QSCIGN_XML_TO_ECL_CONVERTER__H
#define QSCIGN_XML_TO_ECL_CONVERTER__H

#include "accessors.h"

#include <QString>
#include <QMap>

#include <QXmlStreamReader>
#include <QXmlStreamEntityResolver>

#include "sexpresso.hpp"

#include "sexp/value.hpp"


//class XSER : public QXmlStreamEntityResolver
//{
// QString resolveUndeclaredEntity(const QString& ent) override;

//};

//QString XSER::resolveUndeclaredEntity(const QString& ent)
//{
// qDebug()  << "Ent: " << ent;
// return "QString()";

//}


class QScign_XML_To_ECL_Converter
{
 struct Entity_Resolver : public QXmlStreamEntityResolver
 {
  QString resolveUndeclaredEntity(const QString& ent) override;
 };

 enum class Output_Stage {
   N_A, Prelim, Metadata, Body, After_Body
 };

 Output_Stage output_stage_;


 Entity_Resolver entity_resolver_;

 QString xml_file_path_;
 QString metadata_ecl_path_;
 QString document_ecl_path_;

 QString document_html_path_;

 QString root_tag_name_;
 QString document_tag_name_;
 QString metadata_function_name_;

 QString metadata_text_;
 QString document_text_;
 QString prelim_text_;

 QString document_html_;

 QString* current_string_;

 void write_tag_start(QString tag_name);
 void write_tag_end(QString tag_name);
 void write_text(QString text);

 QMap<QString, QString> object_tags_;

public:


 ACCESSORS(QString ,metadata_ecl_path)
 ACCESSORS(QString ,document_ecl_path)
 ACCESSORS(QString ,xml_file_path)

 ACCESSORS(QString ,document_html_path)

 ACCESSORS(QString ,root_tag_name)
 ACCESSORS(QString ,document_tag_name)
 ACCESSORS(QString ,metadata_function_name)

 QScign_XML_To_ECL_Converter();

 void add_object_tag(QString tag);

 void run_conversion();

 void write_sexp_to_file(sexp::Value& sv, QString path);
 void write_raw_sexp_to_file(QString text, QString path);



};


#endif

