

#ifndef SCIGNSEER_FB2_DIALOG__H
#define SCIGNSEER_FB2_DIALOG__H

#include <QObject>

#include <QMetaType>

#include <QList>
#include <QGraphicsScene>
#include <QPoint>

#include <QDialog>
#include <QToolBar>

#include "accessors.h"

#include "Scign/scignseer-custom-web-view-frame.h"

#include "qsns.h"

class QDialogButtonBox;
class QLabel;
class QLineEdit;
class QTabWidget;
class QPlainTextEdit;
class QTextEdit;
class QFrame;
class QHBoxLayout;
class QVBoxLayout;
class QSlider;
class QLineEdit;
class QBoxLayout;
class QButtonGroup;
class QGroupBox;
class QFormLayout;
class QComboBox;
class QDateEdit;

USING_QSNS(MoND_UI)


class ScignSeer_FB2_Dialog : public QDialog
{

 Q_OBJECT

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QPushButton* button_proceed_;


 QVBoxLayout* main_layout_;

 QTabWidget* main_tab_widget_;

 ScignSeer_Custom_Web_View_Frame* custom_web_view_frame_;

 QFrame* custom_pdf_view_frame_;
 QFrame* html_source_frame_;
 QFrame* css_frame_;
 QFrame* lisp_source_frame_;
 QFrame* xml_source_frame_;

 QToolBar* main_tool_bar_;

 QAction* add_book_action_;
 QAction* book_info_action_;

 QAction* show_preferences_action_;
 QAction* show_reading_action_;
 QAction* show_library_action_;

 //?QTabWidget* main_notebook_;


 void parse_file(QString path);

 void take_screenshot();

 QString metadata_ecl_path_;
 QString document_ecl_path_;

 QString document_html_path_;

public:

 ACCESSORS(QString ,metadata_ecl_path)
 ACCESSORS(QString ,document_ecl_path)
 ACCESSORS(QString ,document_html_path)


 ScignSeer_FB2_Dialog(QString file, QWidget* parent = nullptr);

 ~ScignSeer_FB2_Dialog();


Q_SIGNALS:
 void canceled(QDialog*);
 void accepted(QDialog*);

 void metadata_file_ready(QString);
 void document_file_ready(QString);

 void proceed_requested(ScignSeer_FB2_Dialog*);


public Q_SLOTS:
 void accept();
 void cancel();

 void proceed();

};


#endif  // ScignSeer_FB2_DIALOG__H

