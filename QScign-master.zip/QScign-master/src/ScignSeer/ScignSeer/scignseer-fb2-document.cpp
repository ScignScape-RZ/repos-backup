
#include "scignseer-fb2-document.h"

#include <QDebug>

ScignSeer_FB2_Document::ScignSeer_FB2_Document()
{

}
