

#ifndef SCIGNSEER_FB2_DOCUMENT__H
#define SCIGNSEER_FB2_DOCUMENT__H

#include <QObject>

#include <QMetaType>

#include "accessors.h"


class ScignSeer_FB2_Document
{

 QString description_;
 QString author_;
 QString last_name_;
 QString book_title_;
 QString lang_;

public:


 ACCESSORS(QString ,description)
 ACCESSORS(QString ,author)
 ACCESSORS(QString ,last_name)
 ACCESSORS(QString ,book_title)
 ACCESSORS(QString ,lang)


 ScignSeer_FB2_Document();

};

#endif  // ScignSeer_FB2_DOCUMENT__H

