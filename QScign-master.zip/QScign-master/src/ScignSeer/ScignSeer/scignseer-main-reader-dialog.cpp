
#include "scignseer-main-reader-dialog.h"

#include "Scign/scignseer-custom-web-view-dialog.h"

#include "Scign/scignseer-html-annotation-dialog.h"

#include "scignseer-ris-view-dialog.h"

//?
//#include "scignseer-send-email-dialog/scignseer-send-email-dialog.h"
//#include "scignseer-send-email-dialog/scignseer-email-message.h"

//?
#include "styles.h"


#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QButtonGroup>
#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>
#include <QComboBox>

#include <QTimer>
#include <QScreen>

#include <QDateEdit>

#include <QLineEdit>
#include <QTextStream>

#include <QPainter>
#include <QPushButton>
#include <QLabel>

#include <QPlainTextEdit>

#include <QTableWidget>
#include <QGraphicsPixmapItem>

#include <QMessageBox>
#include <QDebug>

#include <QGraphicsView>

#include <QFileDialog>

#include <QHeaderView>

#include <QMenu>
#include <QAction>

#include <QListWidget>
#include <QDateEdit>


#include <QXmlStreamReader>
#include <QXmlStreamEntityResolver>

#include <QtMultimedia>
#include <QtMultimediaWidgets>

#include "qscign-xml-to-ecl-converter.h"



#include "Scign/scignseer-video-dialog.h"
#include "Scign/scignseer-svg-dialog.h"
#include "paraviews/view-pdf-dialog.h"

#include "paraviews/view-parse-dialog.h"

#include "pleneviews/view-pdf-frame.h"

#include "JlCompress.h"



#include "epub/scignseer-epub-add-document-dialog.h"
//?#include "epub/scignseer-epub-xml-to-ecl-converter.h"

#include "epub/scignseer-epub-builder.h"
#include "epub/scignseer-epub-document.h"

#include "Scign/scignseer-custom-navigation-request-resolver.h"

#include "epub/scignseer-epub-book-info-dialog.h"

USING_QSNS(ScignSeer)


//?USING_QSNS(GUI)

#define Q_SLOT_(a) "1"#a

//?#include "Relae/relae-lisp-embed/relae-lisp-eval.h"

void ScignSeer_Main_Reader_Dialog::take_screenshot()
{
 QScreen* screen = QGuiApplication::primaryScreen();
  if (!screen)
      return;
 QApplication::beep();

 //medMainWindow* mainWindow = qobject_cast <medMainWindow *> (parent());


 int target_window_id  = this->winId();

 QTimer::singleShot(10000, [=]
 {
  QPixmap pixmap = screen->grabWindow(target_window_id);

  QString path = "/ext_root/fbreader/screenshots/sonic.png";

  qDebug() << "Saving to path: " << path;
  QFile file(path);
  if(file.open(QIODevice::WriteOnly))
  {
   pixmap.save(&file, "PNG");
  }
 });
}




ScignSeer_Main_Reader_Dialog::ScignSeer_Main_Reader_Dialog(QString file, QWidget* parent)
 : QDialog(parent)
{
 setWindowTitle("SONIC/ScignSeer");

 if(file.endsWith(".fb2"))
 {
 #ifdef HIDE
  KA_XML_To_ECL_Converter x2e;

  x2e.set_xml_file_path(file);

  x2e.set_document_ecl_path(file + ".doc.ecl");
  x2e.set_metadata_ecl_path(file + ".md.ecl");

  x2e.set_document_html_path(file + ".doc.html");

  x2e.set_root_tag_name("FictionBook");
  x2e.set_document_tag_name("body");
  x2e.add_object_tag("FictionBook");

  x2e.run_conversion();

  metadata_ecl_path_ = x2e.metadata_ecl_path();
  document_ecl_path_ = x2e.document_ecl_path();
  document_html_path_ = x2e.document_html_path();
#endif // def HIDE

 }


// Q_EMIT(metadata_file_ready(x2e.metadata_ecl_path()));
// Q_EMIT(document_file_ready(x2e.document_ecl_path()));
// Q_EMIT(proceed_requested(this));

 //parse_file(file);

 button_box_ = new QDialogButtonBox(this);

 button_ok_ = new QPushButton("OK");
 button_proceed_ = new QPushButton("Proceed");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

 button_proceed_->setDefault(false);
 button_proceed_->setAutoDefault(false);
 //?button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);


 QString colorful_button_style_sheet = colorful_button_style_sheet_();

 QString colorful_toggle_button_style_sheet = colorful_button_quiet_style_sheet_(); //colorful_toggle_button_style_sheet_();


 QString colorful_button_style_sheet_down = colorful_button_style_sheet_down_();
 QString colorful_button_quiet_style_sheet = colorful_button_quiet_style_sheet_();

 QString tab_style_sheet = tab_style_sheet_();

 QString button_close_style_sheet = //?button_close_style_sheet_();

  " QPushButton:hover {background:rgb(150,240,190);"
  "  border-left: 4px groove rgb(150,240,190); "
  "  border-right: 4px ridge rgb(150,240,190); "
  " }\n "

  " QPushButton { background:rgb(220,220,230); "
  "  border: 2px groove rgb(0,90,50); "
  "  font-family:\"Comic Sans MS\", cursive, sans-serif; "
  "  border-bottom: 2px groove rgb(240,190,150); "
  "  border-top: 2px groove rgb(240,90,150); "
  "  border-radius: 10px; font-weight:600; color:rgb(0, 90, 105); "
  "  padding-left:16px;padding-right:16px;padding-top:2px;padding-bottom:2px; "

//   " border-left: 4px groove rgb(0,190,150);   "
//   " border-right: 4px ridge rgb(240,190,150); "

  " }\n"

  " QPushButton[enabled=false] { color:grey; } "



  " QPushButton:pressed{ color:black; padding:1px; "
  "  border: 1px solid rgb(150,240,190); "
  "  border-bottom: 1px solid #CEF51D; "
  "  border-radius: 0px; "
  "  background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, "
  "   stop: 0 white, stop: 0.1 #C0C0C0, stop: 0.6 #C6CCBC "
  "   stop: 0.8 #A0ECCF, stop: 0.9 darkseagreen,  stop: 1 blue"
  "  ); min-width: 80px; } ";


 QString basic_button_style_sheet = basic_button_style_sheet_();





 button_ok_->setStyleSheet(basic_button_style_sheet_()); //button_close_style_sheet);
 button_proceed_->setStyleSheet(basic_button_style_sheet_());
 button_cancel_->setStyleSheet(basic_button_style_sheet_());


 connect(button_proceed_, SIGNAL(clicked()), this, Q_SLOT_(proceed()));
 connect(button_box_, SIGNAL(accepted()), this, Q_SLOT_(accept()));
 connect(button_box_, SIGNAL(rejected()), this, Q_SLOT_(cancel()));


 main_tool_bar_ = new QToolBar;


 QString icon_root = "/ext_root/fbreader/FBReader-master/fbreader/data/icons/toolbar/desktop/";

// QString ic = icon_root + "addBook.png";
// QPixmap icon(ic);
// show_preferences_action_ = new QAction(QPixmap(icon_root + "preferences.png"), "Preferences");
// show_reading_action_ = new QAction(QPixmap(icon_root + "showLibrary.png"), "Library");
// show_library_action_ = new QAction(QPixmap(icon_root + "showReading.png"), "Reading");


 add_book_action_ = main_tool_bar_->addAction(QPixmap(icon_root + "addBook.png"), "Open Book",
   this, Q_SLOT_(add_book()));


 book_info_action_ = main_tool_bar_->addAction(QPixmap(icon_root + "bookInfo.png"), "Book Info", []
 {

 });

 show_preferences_action_ = main_tool_bar_->addAction(QPixmap(icon_root + "preferences.png"), "Preferences", []
 {

 });

 show_library_action_ = main_tool_bar_->addAction(QPixmap(icon_root + "showLibrary.png"), "Library", []
 {

 });

 show_reading_action_ = main_tool_bar_->addAction(QPixmap(icon_root + "showReading.png"), "Reading", []
 {

 });

 show_reading_action_->setToolTip("Show Reading");

 main_tool_bar_->setIconSize(QSize(30, 50));
 main_tool_bar_->setToolButtonStyle( Qt::ToolButtonTextUnderIcon );

 main_tool_bar_->setContextMenuPolicy(Qt::CustomContextMenu);

 connect(main_tool_bar_, &QToolBar::customContextMenuRequested,
        [this](const QPoint& pos)
 {
  QMenu* menu = new QMenu(this);

  QAction* nav_action = menu->addAction("Show Navigation Dialog");

  connect(nav_action, &QAction::triggered,
    [this]
  {
   QString url = custom_web_view_nav_frame_->current_url();
   ScignSeer_Custom_Web_View_Dialog* dlg = new ScignSeer_Custom_Web_View_Dialog(url, this);
   dlg->register_navigation_request_resolver(custom_web_view_nav_frame_->current_navigation_request_resolver());

   dlg->show();

  });

  QAction* annotation_action = menu->addAction("Add Annotation");

  connect(annotation_action, &QAction::triggered,
    [this]
  {
   QString code = "p#32-10";
   ScignSeer_HTML_Annotation_Dialog* dlg = new ScignSeer_HTML_Annotation_Dialog(code, this);

   dlg->show();

  });


  QAction* send_email_action = menu->addAction("Send Email");

  connect(send_email_action, &QAction::triggered,
    [this]
  {
#ifdef HIDE
   KA_Email_Message kem;

   kem.set_subject("Article Reference");

   QString origin = "https://link.springer.com/article/10.1007/s10772-017-9436-y";
   QString dest = "https://link.springer.com/article/10.1007/s10772-017-9436-y#CR59";

   QString mb = QString("The article %1, linked from %2").arg(dest).arg(origin);

   kem.set_message_body(mb);

   KA_Send_Email_Dialog* dlg = new KA_Send_Email_Dialog(this, kem);

   connect(dlg, &KA_Send_Email_Dialog::send_requested,  //?SIGNAL(send_requested(RZ_Send_Email_Dialog*, RZ_Email_Message*)),
    [this](KA_Send_Email_Dialog* dlg, KA_Email_Message* rem)
   {
    KA_Email_Message_Handler remh(rem);

    QString s = remh.to_string();

    if(s.size() > 511)
    {
     QMessageBox::information(this, "?", s.left(511));
    }
    else
    {
     QMessageBox::information(this, "?", s);
    }

    remh.do_send([this, dlg](KA_Email_Message_Handler::Send_Result sr)
     {
      //?
      dlg->convey_send_result(sr);
     });

    //?QString s = remh.to_string();
    //?QMessageBox::information(this, "?", s);
   });
    // this, SLOT(handle_email_send_requested(RZ_Send_Email_Dialog*, RZ_Email_Message*)));





   dlg->setWindowTitle("SONIC Email");

   dlg->show();
#endif
  });


  if(epub_document_)
  {
   QAction* epub_book_info_action = menu->addAction("EPub Book Info");

   connect(epub_book_info_action, &QAction::triggered,
     [this]
   {
    ScignSeer_EPub_Book_Info_Dialog* dlg = new ScignSeer_EPub_Book_Info_Dialog(epub_document_, this);
    dlg->show();
   });
  }

  QAction* take_screenshot_action = menu->addAction("Take Screenshot");

  connect(take_screenshot_action, &QAction::triggered,
    [this]
  {
   take_screenshot();
   //Q_EMIT( view_item_requested(index) );
  });


  QAction* show_video_action = menu->addAction("Show Video");

  connect(show_video_action, &QAction::triggered,
    [this]
  {

   ScignSeer_Video_Dialog* dlg = new ScignSeer_Video_Dialog(
      "file:///ext_root/videos/a.mp4", this);
   dlg->show();

//   QMediaPlayer* player = new QMediaPlayer;

////   playlist = new QMediaPlaylist(player);
////   playlist->addMedia(QUrl("http://example.com/myclip1.mp4"));
////   playlist->addMedia(QUrl("http://example.com/myclip2.mp4"));

//   QVideoWidget* videoWidget = new QVideoWidget;
//   player->setVideoOutput(videoWidget);

//   videoWidget->setWindowTitle("ScignSeer Video Player");

//   videoWidget->show();
//   player->setMedia(QUrl("file:///ext_root/videos/a.mp4"));
//   player->play();
  });

  QAction* show_svg_action = menu->addAction("Show SVG");
  connect(show_svg_action, &QAction::triggered,
    [this]
  {

   ScignSeer_SVG_Dialog* dlg = new ScignSeer_SVG_Dialog(this);
   dlg->show();
  });

  QAction* open_pdf_action = menu->addAction("Open PDF");
  connect(open_pdf_action, &QAction::triggered,
    [this]
  {
   QString path = QFileDialog::getOpenFileName(this, "Select PDF File", "/ext_root/kauv");
   custom_pdf_view_frame_->load_file(path);
  });


  QAction* show_pdf_action = menu->addAction("Show PDF");
  connect(show_pdf_action, &QAction::triggered,
    [this]
  {

//   "3052-7505-1-PB.pdf"
//   "Lesson Plan 2 - The 1811 Plan.pdf"

   View_PDF_Dialog* dlg = new View_PDF_Dialog(this, "/ext_root/kauv/paper.pdf");
   dlg->show();
  });

  QAction* show_parse_action = menu->addAction("Show Parse");
  connect(show_parse_action, &QAction::triggered,
    [this]
  {

//   "3052-7505-1-PB.pdf"
//   "Lesson Plan 2 - The 1811 Plan.pdf"

   View_Parse_Dialog* dlg = new View_Parse_Dialog(this);
   dlg->show();
  });


  QPoint g = main_tool_bar_->mapToGlobal(pos);

  menu->popup(g);

  //qDebug() << "POS: " << pos;
  //QMenu qm
 } );

 main_layout_ = new QVBoxLayout();

 main_layout_->addWidget(main_tool_bar_);

 //QString paper_pdf = "/ext_root/kauv/paper.pdf";
 QString paper_pdf = "/ext_root/kauv/47-347-1-PB.pdf";


 custom_pdf_view_frame_ = new View_PDF_Frame(this, paper_pdf) ;//QFrame(this);

 custom_web_view_frame_ = new ScignSeer_Custom_Web_View_Frame("", this);
 custom_web_view_nav_frame_ = new ScignSeer_Custom_Web_View_Frame("", this);

 html_source_frame_ = new QFrame(this);
 css_frame_ = new QFrame(this);
 lisp_source_frame_ = new QFrame(this);
 xml_source_frame_ = new QFrame(this);


 main_tab_widget_ = new QTabWidget(this);

 main_tab_widget_->setStyleSheet(tab_style_sheet_());


 main_tab_widget_->addTab(custom_pdf_view_frame_, "PDF");
 main_tab_widget_->addTab(custom_web_view_frame_, "HTML");
 main_tab_widget_->addTab(custom_web_view_nav_frame_, "NAV");

 main_tab_widget_->addTab(html_source_frame_, "HTML Source");
 main_tab_widget_->addTab(lisp_source_frame_, "Lisp");
 main_tab_widget_->addTab(css_frame_, "CSS");
 main_tab_widget_->addTab(xml_source_frame_, "XML");

 main_layout_->addWidget(main_tab_widget_);


// if(document_html_path_.isEmpty())
// {
//  custom_web_view_frame_->load_local_file(file);
// }
// else
// {
//  custom_web_view_frame_->load_local_file(document_html_path_);
// }

// Weidman-2012-Anthropology_and_Humanism.pdf

//? custom_web_view_frame_->load_url("http://onlinelibrary.wiley.com/doi/10.1111/j.1548-1409.2012.01131.x/full");

 connect(custom_web_view_frame_, SIGNAL(page_download_finished(QString,QString)),
   this, Q_SLOT_(handle_page_download_finished(QString,QString)));

 connect(custom_web_view_frame_, SIGNAL(email_link_requested(QString,QString)),
   this, Q_SLOT_(handle_email_href(QString,QString)));


//? main_notebook_ = new QTabWidget(this);
//? main_notebook_->setStyleSheet(tab_style_sheet);
//? main_layout_->addWidget(main_notebook_);

 main_layout_->addWidget(button_box_);

 //?main_layout_->addLayout(clear_button_layout_);

 setLayout(main_layout_);

 show();
}

void ScignSeer_Main_Reader_Dialog::handle_page_download_finished(QString mime_type, QString path)
{
 if(mime_type == "application/x-research-info-systems")
 {
  ScignSeer_RIS_View_Dialog* dlg = new ScignSeer_RIS_View_Dialog(path, this);

  dlg->show();

 }
}

void ScignSeer_Main_Reader_Dialog::handle_email_href(QString origin, QString href)
{
#ifdef HIDE
 KA_Email_Message kem;

 kem.set_subject("Article Reference");

// QString origin = "https://link.springer.com/article/10.1007/s10772-017-9436-y";
// QString dest = "https://link.springer.com/article/10.1007/s10772-017-9436-y#CR59";

 QString mb = QString("The article %1, linked from %2").arg(href).arg(origin);

 kem.set_message_body(mb);

 KA_Send_Email_Dialog* dlg = new KA_Send_Email_Dialog(this, kem);

 dlg->setWindowTitle("SONIC Email");

 dlg->show();
#endif
}


void ScignSeer_Main_Reader_Dialog::add_book()
{
 QString path = QFileDialog::getOpenFileName(this, "Select Book File",
   "/ext_root/fbreader/books/");


 qDebug() << path;

 if(path.endsWith("epub"))
 {
  //?QString path1 = path;
  //?path1.replace('.', '_');
  KA_EPub_Add_Document_Dialog* dlg = new KA_EPub_Add_Document_Dialog(path);

  connect(dlg, SIGNAL(unzip_requested()),
    this, Q_SLOT_(handle_unzip_epub_document()));

  dlg->show();
 }

 //QString dest = "/ext_root/fbreader/books/test-temp/";

 //JlCompress::extractDir(path, path1);


}

void ScignSeer_Main_Reader_Dialog::handle_unzip_epub_document()
{
#ifdef HIDE
 KA_EPub_Add_Document_Dialog* dlg = qobject_cast<KA_EPub_Add_Document_Dialog*>(sender());

 QString path = dlg->epub_file_path();
 QString path1 = dlg->epub_folder_path();
 JlCompress::extractDir(path, path1);

 KA_EPub_XML_To_ECL_Converter x2e(path1);

 x2e.set_root_tag_name("package");

 x2e.set_data_ecl_path(path + ".data.ecl");

 x2e.add_object_tag("package", "KA_EPub");


 x2e.run_conversion();

 //QString mp = dlg->metadata_ecl_path();
 QString dp = x2e.data_ecl_path();

//   QString dhp = dlg->document_html_path();
//   QString dh = dlg->document_html();

 lisp_eval_->eval_raw_file_via_load(dp);

 QObject* qob = lisp_eval_->get_last_qobject();

 KA_EPub_builder* epb = qobject_cast<KA_EPub_builder*>(qob);

 epub_document_ = epb->epub_document();

 QList<KA_EPub_Spine_Item>& spine = epub_document_->spine_items();

 const KA_EPub_Spine_Item* nav_si = epub_document_->get_nav_page();

 QString navpath;

 if(nav_si)
 {
  QString hr = nav_si->href();
  QString id = nav_si->id();

  navpath = QString("%1/OPS/%2").arg(path1).arg(hr);

  custom_web_view_nav_frame_->load_local_file(navpath);

 }
 const KA_EPub_Spine_Item* si = epub_document_->get_first_html_page();
 if(si)
 {
  QString hr = si->href();
  QString id = si->id();

  QString hrpath = QString("%1/OPS/%2").arg(path1).arg(hr);

  custom_web_view_frame_->load_local_file(hrpath);

  main_tab_widget_->setCurrentWidget(custom_web_view_frame_);

 }
 else if(nav_si)
 {
  main_tab_widget_->setCurrentWidget(custom_web_view_nav_frame_);

 }

 if(nav_si)
 {
  ScignSeer_Custom_Navigation_Request_Resolver* scnrr = new ScignSeer_Custom_Navigation_Request_Resolver;

//?
  scnrr->set_navigation_recipient(custom_web_view_frame_);
  scnrr->set_origin_url(QUrl::fromLocalFile(navpath));

//?
  custom_web_view_nav_frame_->register_navigation_request_resolver(scnrr);

//?
  connect(scnrr,
          SIGNAL(navigation_requested(const QUrl&, QObject*)),
          this,
          Q_SLOT_(handle_navigation_requested(const QUrl&, QObject*)));

 }
#endif
}

void ScignSeer_Main_Reader_Dialog::handle_navigation_requested(const QUrl& url, QObject* obj)
{
// ScignSeer_Custom_Web_View_Frame* wvf = qobject_cast<ScignSeer_Custom_Web_View_Frame*>(obj);

// custom_web_view_frame_->load_url(url);

//? qDebug() << "URL: " << url.toString();

 //?custom_web_view_frame_->load_local_file("/ext_root/fbreader/books/9783110416831_epub/OPS/content/06_Preface.xhtml#Preface_1");

 custom_web_view_frame_->load_url(url);

 main_tab_widget_->setCurrentWidget(custom_web_view_frame_);

  //? file:///ext_root/fbreader/books/9783110416831_epub/OPS/content/06_Preface.xhtml#Preface_1

   //? wvf->load_url(url);
}


ScignSeer_Main_Reader_Dialog::~ScignSeer_Main_Reader_Dialog()
{
 delete button_ok_;
 delete button_proceed_;
 delete button_cancel_;

// delete url_label_;
// delete name_ qLe_;
}



void ScignSeer_Main_Reader_Dialog::cancel()
{
 Q_EMIT(rejected());
 Q_EMIT(canceled(this));
 Q_EMIT(rejected());
// close();
//
 close();
}

void ScignSeer_Main_Reader_Dialog::proceed()
{
 Q_EMIT(proceed_requested(this));
}


void ScignSeer_Main_Reader_Dialog::accept()
{
 Q_EMIT(accepted(this));
// close();
}



