
#ifndef SCIGNSEER_MAIN_READER_DIALOG__H
#define SCIGNSEER_MAIN_READER_DIALOG__H

#include <QObject>

#include <QMetaType>

#include <QList>
#include <QGraphicsScene>
#include <QPoint>

#include <QDialog>
#include <QToolBar>

#include "accessors.h"

#include "Scign/scignseer-custom-web-view-frame.h"


class QDialogButtonBox;
class QLabel;
class QLineEdit;
class QTabWidget;
class QPlainTextEdit;
class QTextEdit;
class QFrame;
class QHBoxLayout;
class QVBoxLayout;
class QSlider;
class QLineEdit;
class QBoxLayout;
class QButtonGroup;
class QGroupBox;
class QFormLayout;
class QComboBox;
class QDateEdit;

USING_QSNS(MoND_UI)

QSNS_(ScignSeer)
class View_PDF_Frame;
_QSNS(ScignSeer)

USING_QSNS(ScignSeer)


#ifdef HIDE
QSNS_(EmbL)
 class Relae_Lisp_Embed_Environment;
 class Relae_Lisp_Eval;
_QSNS(EmbL)
USING_QSNS(EmbL)
#endif // def HIDE


class ScignSeer_EPub_Document;

class ScignSeer_Main_Reader_Dialog : public QDialog
{

 Q_OBJECT

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QPushButton* button_proceed_;


 QVBoxLayout* main_layout_;

 QTabWidget* main_tab_widget_;

 ScignSeer_Custom_Web_View_Frame* custom_web_view_frame_;

 ScignSeer_Custom_Web_View_Frame* custom_web_view_nav_frame_;

 View_PDF_Frame* custom_pdf_view_frame_;

 QFrame* html_source_frame_;
 QFrame* nav_source_frame_;

 QFrame* css_frame_;
 QFrame* lisp_source_frame_;
 QFrame* xml_source_frame_;

 QToolBar* main_tool_bar_;

 QAction* add_book_action_;
 QAction* book_info_action_;

 QAction* show_preferences_action_;
 QAction* show_reading_action_;
 QAction* show_library_action_;

 //?QTabWidget* main_notebook_;


 void parse_file(QString path);

 void take_screenshot();

 QString metadata_ecl_path_;
 QString document_ecl_path_;

 QString document_html_path_;

//? Relae_Lisp_Embed_Environment* lisp_embed_environment_;
//? Relae_Lisp_Eval* lisp_eval_;

 ScignSeer_EPub_Document* epub_document_;

public:

 ACCESSORS(QString ,metadata_ecl_path)
 ACCESSORS(QString ,document_ecl_path)
 ACCESSORS(QString ,document_html_path)

//? ACCESSORS(Relae_Lisp_Embed_Environment* ,lisp_embed_environment)
//? ACCESSORS(Relae_Lisp_Eval* ,lisp_eval)


 ScignSeer_Main_Reader_Dialog(QString file, QWidget* parent = nullptr);

 ~ScignSeer_Main_Reader_Dialog();


Q_SIGNALS:
 void canceled(QDialog*);
 void accepted(QDialog*);

 void metadata_file_ready(QString);
 void document_file_ready(QString);

 void proceed_requested(ScignSeer_Main_Reader_Dialog*);


public Q_SLOTS:

 void add_book();

 void handle_navigation_requested(const QUrl&, QObject*);

 void handle_unzip_epub_document();

 void handle_email_href(QString origin, QString href);

 void handle_page_download_finished(QString mime_type, QString path);

 void accept();
 void cancel();

 void proceed();

};


#endif  // ScignSeer_Main_Reader_Dialog__H

