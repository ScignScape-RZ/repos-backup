
#include "scignseer-ris-view-dialog.h"


//?
#include "styles.h"


#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QButtonGroup>
#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>
#include <QComboBox>

#include <QTimer>
#include <QScreen>

#include <QDateEdit>

#include <QLineEdit>
#include <QTextStream>

#include <QPainter>
#include <QPushButton>
#include <QLabel>

#include <QPlainTextEdit>

#include <QTableWidget>
#include <QGraphicsPixmapItem>

#include <QMessageBox>
#include <QDebug>

#include <QGraphicsView>


#include <QHeaderView>

#include <QMenu>
#include <QAction>

#include <QListWidget>
#include <QDateEdit>


#include <QXmlStreamReader>
#include <QXmlStreamEntityResolver>

//?#include "scignseer-xml-to-ecl-converter.h"

#include "textio.h"

ScignSeer_RIS_View_Dialog::ScignSeer_RIS_View_Dialog(QString file, QWidget* parent)
 : QDialog(parent)
{
 setWindowTitle("CITATION");

 button_box_ = new QDialogButtonBox(this);

 button_ok_ = new QPushButton("OK");
 button_proceed_ = new QPushButton("Proceed");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

 button_proceed_->setDefault(false);
 button_proceed_->setAutoDefault(false);
 //?button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);


 QString colorful_button_style_sheet = colorful_button_style_sheet_();

 button_ok_->setStyleSheet(button_close_light_style_sheet_());
 button_proceed_->setStyleSheet(button_close_light_style_sheet_());
 button_cancel_->setStyleSheet(button_close_light_style_sheet_());


 connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));


 main_layout_ = new QVBoxLayout;

 main_text_edit_ = new QPlainTextEdit(this);

 QString text = QScign::TextIO::load_file(file);

 main_text_edit_->setPlainText(text);

 main_layout_->addWidget(main_text_edit_);

 main_layout_->addStretch();

 main_layout_->addWidget(button_box_);

 //?main_layout_->addLayout(clear_button_layout_);

 setLayout(main_layout_);

 show();
}



ScignSeer_RIS_View_Dialog::~ScignSeer_RIS_View_Dialog()
{
 delete button_ok_;
 delete button_proceed_;
 delete button_cancel_;

// delete url_label_;
// delete name_ qLe_;
}



void ScignSeer_RIS_View_Dialog::cancel()
{
 Q_EMIT(rejected());
 Q_EMIT(canceled(this));
 Q_EMIT(rejected());
 close();
//
 close();
}

void ScignSeer_RIS_View_Dialog::proceed()
{
 //?Q_EMIT(proceed_requested(this));
}


void ScignSeer_RIS_View_Dialog::accept()
{
 Q_EMIT(accepted(this));
// close();
}



