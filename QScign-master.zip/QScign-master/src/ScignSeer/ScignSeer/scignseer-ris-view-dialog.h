

#ifndef SCIGNSEER_RIS_VIEW_DIALOG__H
#define SCIGNSEER_RIS_VIEW_DIALOG__H

#include <QObject>

#include <QMetaType>

#include <QList>
#include <QGraphicsScene>
#include <QPoint>

#include <QDialog>
#include <QToolBar>

#include "accessors.h"

#include "textio.h"

//?#include "Scign/scignseer-custom-web-view-frame.h"


class QDialogButtonBox;
class QLabel;
class QLineEdit;
class QTabWidget;
class QPlainTextEdit;
class QTextEdit;
class QFrame;
class QHBoxLayout;
class QVBoxLayout;
class QSlider;
class QLineEdit;
class QBoxLayout;
class QButtonGroup;
class QGroupBox;
class QFormLayout;
class QComboBox;
class QDateEdit;

//?USING_QSNS(MoND_UI)


class ScignSeer_RIS_View_Dialog : public QDialog
{

Q_OBJECT

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QPushButton* button_proceed_;


 QVBoxLayout* main_layout_;

 QPlainTextEdit* main_text_edit_;

public:

 ScignSeer_RIS_View_Dialog(QString file, QWidget* parent = nullptr);

 ~ScignSeer_RIS_View_Dialog();


Q_SIGNALS:

 void canceled(QDialog*);
 void accepted(QDialog*);


public Q_SLOTS:

 //void extract_requested();
 void accept();
 void cancel();

 void proceed();

};


#endif  // KA_EPUB_ADD_DOCUMENT_DIALOG__H

