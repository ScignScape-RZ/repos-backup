
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)


#include <QApplication>
#include <QGraphicsView>

#include <QList>
#include <QDebug>

#include <QMessageBox>

#include <QMenu>

#include <QGraphicsItem>

#include <QScreen>
#include <QTimer>
#include <QTime>

#include <QImage>

#include <QApplication>
#include <QDesktopWidget>

#include <QFileDialog>

#include "ScignStage-ch/scignstage-ch-dialog.h"



USING_QSNS(ScignStage)

int main(int argc, char **argv)
{

 QApplication qapp(argc, argv);

 //?
 //ScignStage_G2D_Dialog dlg (DEFAULT_IMAGE);
 //?
 ScignStage_CH_Dialog dlg (DEFAULT_IMAGE);

#ifdef HIDE
 dlg.connect(&dlg, &ScignStage_WSI_Dialog::open_folder_requested,
   [&dlg]()
 {

  QString str = QFileDialog::getExistingDirectory(nullptr, "Select Image Folder",
    DEFAULT_FOLDER);

  dlg.open_folder(str);

 });
#endif // def HIDE


 dlg.connect(&dlg, &ScignStage_CH_Dialog::take_screenshot_requested,
   [&dlg]()
 {
//  qDebug() << "SS";

  QScreen* screen = QGuiApplication::primaryScreen();
//   if (const QWindow* window = windowHandle())
//       screen = window->screen();
   if (!screen)
       return;

   //if (delaySpinBox->value() != 0)
   QApplication::beep();

   int target_window_id  = dlg.winId();

   QTimer::singleShot(10000, [=]
   {
    QPixmap pixmap = screen->grabWindow(target_window_id );
    QString path = SCREENSHOTS_DIR "/ScignStage-ch.png";

    qDebug() << "Saving to path: " << path;

    QFile file(path);
    if(file.open(QIODevice::WriteOnly))
    {
     pixmap.save(&file, "PNG");
    }

   });


 });


 dlg.show();

 qapp.exec();

}
