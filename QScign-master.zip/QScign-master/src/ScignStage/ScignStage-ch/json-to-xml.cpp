
#include "json-to-xml.h"


#include <QFileInfo>
#include <QRegExp>

#include <QRegularExpression>
#include <QRegularExpressionMatch>

#include <QMessageBox>

#include <QDateTime>

#include <QJsonArray>
#include <QJsonObject>
#include <QJsonValue>

#include <QJsonDocument>

#include <QDebug>


USING_QSNS(ScignStage)


//void json_object_to_xml(QJsonDocument qjd, QDomDocument& qdd);

//void json_array_to_xml(QJsonArray qja, QDomDocument& qdd, QString node_name)
//{
//// for(auto it = qja.constBegin(); it != qja.constEnd(); ++it)
//// {
////  QJsonValue v = *it;
////  if(v.isArray())
////  {

////  }
////  else if(v.isObject())
////  {
////   QDomElement qde;
////   qde.setTagName();
////   qde.setNodeValue();
////  }
//// }
//}

//QDomNode json_array_to_xml_node(QJsonArray qja, QString node_name)
//{
// for(auto it = qja.constBegin(); it != qja.constEnd(); ++it)
// {
//  QJsonValue v = *it;
//  if(v.isArray())
//  {
//   QDomElement qde;
//   qde.setTagName(node_name);
//   qde.setNodeValue("array");
//   return qde;
//  }
//  else if(v.isObject())
//  {
//   QDomElement qde;
//   qde.setTagName(node_name);
//   qde.setNodeValue("object");
//   return qde;
//  }
////  QJsonObject qja = v.toObject();
////  QJsonDocument qjd = QJsonDocument(qja);

// }

//}


////void json_object_to_xml_node(QJsonObject qjo, QDomDocument& qdd, QDomNode& parent_node)//, QString node_name)
////{
//// for(auto it = qjo.constBegin(); it != qjo.constEnd(); ++it)
//// {
////  QString key = it.key();
////  QJsonValue v = it.value();
////  if(v.isArray())
////  {
////   QDomElement qde;
////   qde.setTagName(key);
////   QString inner_tag_name = key + "_s";
////   QDomDocument inner_qdd;
////   QJsonArray qja = v.toArray();
////   QDomNode qdn = json_array_to_xml_node(qja, inner_tag_name);
////   qde.appendChild(qdn);
////   parent_node.appendChild(qde);
////  }
////  else if(v.isObject())
////  {
////   QDomElement qde = qdd.createElement(key);
////   QJsonObject qjo = v.toObject();
////   json_object_to_xml_node(qjo, qdd, qde);
////   parent_node.appendChild(qde);
////  }
////  else
////  {
////   QString vs = v.toString();
////   QDomElement qde = qdd.createElement(key);
////   QDomText qdt = qdd.createTextNode(vs);
////   qde.appendChild(qdt);
////   parent_node.appendChild(qde);
////  }
//// }
////}


template<typename T>
QString json_object_get_key(typename T::const_iterator it, QString tag_names)
{
 return tag_names;
}

template<>
QString json_object_get_key<QJsonObject>(QJsonObject::ConstIterator it, QString tag_names)
{
 return it.key();
}


template<typename T>
QJsonValue json_object_get_value(typename T::const_iterator it)
{
 return *it;
}

template<>
QJsonValue json_object_get_value<QJsonObject>(QJsonObject::ConstIterator it)
{
 return it.value();
}


template<typename T>
void json_object_to_xml(T qjo, QDomDocument& qdd, QDomNode* parent_node, QString tag_names = QString())
{
 for(auto it = qjo.constBegin(); it != qjo.constEnd(); ++it)
 {
  QString key = json_object_get_key<T>(it, tag_names);
  QJsonValue v = json_object_get_value<T>(it);
  QJsonValue::Type vt = v.type();
  switch(vt)
  {
  case QJsonValue::Array:
   {
    QDomElement qde = qdd.createElement(key);
    QJsonArray qja = v.toArray();
    QString inner_tag_name = key + "_s";
    json_object_to_xml(qja, qdd, &qde, inner_tag_name);
    if(parent_node)
     parent_node->appendChild(qde);
    else
     qdd.appendChild(qde);
   }
   break;
  case QJsonValue::Object:
   {
    QDomElement qde = qdd.createElement(key);
    QJsonObject qjo = v.toObject();
    json_object_to_xml(qjo, qdd, &qde);
    if(parent_node)
     parent_node->appendChild(qde);
    else
     qdd.appendChild(qde);
   }
   break;
  case QJsonValue::String:
   {
    QDomElement qde = qdd.createElement(key);
    QString vs = v.toString();
    QDomText qdt = qdd.createTextNode(vs);
    qde.appendChild(qdt);
    if(parent_node)
     parent_node->appendChild(qde);
//    else
//     qdd.appendChild(qde);
   }
   break;
  case QJsonValue::Double:
   {
    QDomElement qde = qdd.createElement(key);
    QString vs = QString::number(v.toDouble());
    QDomText qdt = qdd.createTextNode(vs);
    qde.appendChild(qdt);
    if(parent_node)
     parent_node->appendChild(qde);
//    else
//     qdd.appendChild(qde);
   }
   break;
  case QJsonValue::Bool:
   {
    QDomElement qde = qdd.createElement(key);
    QString vs = v.toBool()? "true": "false";
    QDomText qdt = qdd.createTextNode(vs);
    qde.appendChild(qdt);
    if(parent_node)
     parent_node->appendChild(qde);
//    else
//     qdd.appendChild(qde);
   }
   break;
  }
 }

}

QDomDocument QScign::ScignStage::json_to_xml(QJsonDocument jsond)
{
 QDomDocument result;
 if(jsond.isObject())
 {
  QJsonObject qjo = jsond.object();
  json_object_to_xml(qjo, result, nullptr);
 }
 else if(jsond.isArray())
 {
  QJsonArray qja = jsond.array();
  json_object_to_xml(qja, result, nullptr);
 }
 return result;
}
//  QString s = qjd.toJson();
//  QMessageBox::information(this, "?", s);
//  QJsonObject qjo = qjd.object();
//  QJsonValue qjv = qjo.value("response");
//  QJsonObject qjod = qjv.toObject();
//  QJsonValue qjvd = qjod.value("docs");


//  QJsonArray qja = qjvd.toArray();

//  for(auto it = qja.constBegin(); it != qja.constEnd(); ++it)
//  {
//   QJsonValue v = *it;
//   QJsonObject qjo = v.toObject();
//   QJsonDocument qjd = QJsonDocument(qjo);
//   QString vs = qjd.toJson();
//   QMessageBox::information(this, "?", vs);
//  }



//}

