
#ifndef JSON_TO_XML__H
#define JSON_TO_XML__H


#include <QString>
#include <QMainWindow>

#include <QUrl>

#include <QDomDocument>

#include "accessors.h"

#include "flags.h"

#include "qsns.h"

QSNS_(ScignStage)

QDomDocument json_to_xml(QJsonDocument jsond);


_QSNS(CLG)

#endif
