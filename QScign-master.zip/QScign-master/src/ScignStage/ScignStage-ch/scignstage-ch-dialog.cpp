
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)


#include "scignstage-ch-dialog.h"

#include "ScignStage/subwindows/scignstage-image-tile.h"

#include "ScignStage/structures/multisize-image-tile-info.h"

#include "styles.h"


#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QButtonGroup>
#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>
#include <QBuffer>

#include <QEventLoop>

#include <QDirIterator>

#include <QPlainTextEdit>
#include <QTextStream>

#include <QPainter>
#include <QPushButton>
#include <QLabel>

#include <QDomDocument>

#include <QTableWidget>
#include <QGraphicsPixmapItem>

#include <QMessageBox>
#include <QDebug>

#include <QGraphicsView>
#include <QScrollArea>

#include <QUrl>
#include <QUrlQuery>
#include <QNetworkAccessManager>

#include <QNetworkReply>
#include <QJsonDocument>

#include <QHeaderView>

#include <QMenu>
#include <QAction>

#include <QListWidget>
#include <QXmlQuery>
#include <QXmlSerializer>


#include "ScignStage/subwindows/scignstage-clickable-label.h"

#include "ScignStage/paraviews/scignstage-navigation-protocol-dialog.h"

#include "ScignStage/paraviews/scignstage-png-dialog.h"

#include "json-to-xml.h"

#include "textio.h"

USING_QSNS(ScignStage)


ScignStage_CH_Dialog::ScignStage_CH_Dialog(
  QString initial_image_file,
  QWidget* parent)
  : QDialog(parent), qnam_(nullptr), qnam_images_(nullptr)
{
 button_box_ = new QDialogButtonBox(this);

 button_ok_ = new QPushButton("OK");
 button_proceed_ = new QPushButton("Proceed");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

 button_proceed_->setDefault(false);
 button_proceed_->setAutoDefault(false);

 button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);

 button_ok_->setStyleSheet(basic_button_style_sheet_());
 button_proceed_->setStyleSheet(basic_button_style_sheet_());
 button_cancel_->setStyleSheet(basic_button_style_sheet_());


 connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));

 main_layout_ = new QVBoxLayout;


 top_buttons_layout_ = new QHBoxLayout;

 //?updates_button_ = new QPushButton("Updates Dialog", this);

 api_button_ = new QPushButton("API", this);

 take_screenshot_button_ = new QPushButton("Screenshot", this);
 open_folder_button_ = new QPushButton("Open Folder", this);

 //?scignstage_button_ = new QPushButton("ScignStage", this);
 //?sonic_button_ = new QPushButton("SONIC", this);

 //?updates_button_->setStyleSheet(colorful_button_style_sheet_());
 //?open_image_button_->setStyleSheet(colorful_button_style_sheet_());

 api_button_->setStyleSheet(colorful_button_style_sheet_());

 take_screenshot_button_->setStyleSheet(colorful_button_style_sheet_());
 open_folder_button_->setStyleSheet(colorful_button_style_sheet_());
 //?scignstage_button_->setStyleSheet(colorful_button_style_sheet_());

 //?sonic_button_->setStyleSheet(colorful_button_style_sheet_());

//? connect(updates_button_, SIGNAL(clicked()),
//   this, SLOT(updates_dialog_requested()));


 connect(api_button_, SIGNAL(clicked()),
   this, SLOT(api_search_requested()));

 connect(take_screenshot_button_, SIGNAL(clicked()),
   this, SIGNAL(take_screenshot_requested()));

//? connect(open_image_button_, SIGNAL(clicked()),
//   this, SIGNAL(open_image_requested()));

 connect(open_folder_button_, SIGNAL(clicked()),
   this, SLOT(open_folder_requested()));

//? connect(scignstage_button_, SIGNAL(clicked()),
//   this, SLOT(open_scignstage_navigation_protocol_dialog()));


 top_buttons_layout_->addStretch();

 //?top_buttons_layout_->addWidget(updates_button_);

 top_buttons_layout_->addWidget(api_button_);

 //?top_buttons_layout_->addWidget(patient_info_button_);
 //?top_buttons_layout_->addWidget(diagnostic_report_button_);

 top_buttons_layout_->addWidget(open_folder_button_);
 //?top_buttons_layout_->addWidget(open_image_button_);
 top_buttons_layout_->addWidget(take_screenshot_button_);

 //?top_buttons_layout_->addWidget(scignstage_button_);

 //?top_buttons_layout_->addWidget(sonic_button_);

 // //////////////////////////////////////////////

 main_layout_->addLayout(top_buttons_layout_);

 middle_layout_ = new QHBoxLayout;

 // //   Series
 series_panel_ = new Series_Image_Multisize_Panel(this);

 series_scroll_area_ = new QScrollArea(this);
 series_scroll_area_->setWidget(series_panel_);

 series_scroll_area_->setMaximumWidth(80);

 series_scroll_area_->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);

 middle_layout_->addWidget(series_scroll_area_);

 connect(series_panel_, SIGNAL(open_file_requested(QString)),
   this, SLOT(handle_open_file_requested(QString)));

 //?middle_layout_->addStretch();

 // //   Foreground
 foreground_panel_ = new Fore_Image_Multisize_Panel(this);

 foreground_panel_->setMinimumHeight(300);

 foreground_panel_->setMinimumWidth(300);

 //middle_layout_->addWidget(foreground_panel_);

 // middle_layout_->addStretch();

 // //   Description

 description_scroll_area_ = new QScrollArea(this);
 description_panel_ = new Description_Panel(this);

 description_scroll_area_->setWidget(description_panel_);

 //?description_scroll_area_->setMaximumWidth(200);

 description_layout_ = new QVBoxLayout;
 description_layout_->addSpacing(10);
 description_layout_->addWidget(description_scroll_area_);

 foreground_and_description_splitter_ = new QSplitter(this);
 QFrame* description_frame = new QFrame(this);

 description_frame->setLayout(description_layout_);

 foreground_and_description_splitter_->addWidget(foreground_panel_);

 foreground_and_description_splitter_->addWidget(description_frame);

 // middle_layout_->addLayout(description_layout_);

 middle_layout_->addWidget(foreground_and_description_splitter_);

 main_layout_->addLayout(middle_layout_);

 nav_panel_ = new NAV_Image_Multisize_Panel(this);

 connect(series_panel_, SIGNAL(navigated_from_series(int,int)),
   nav_panel_, SLOT(set_row_and_column_text(int,int)));

 connect(nav_panel_, SIGNAL(zoom_in_requested()),
   foreground_panel_, SLOT(zoom_in()));

 connect(nav_panel_, SIGNAL(zoom_out_requested()),
   foreground_panel_, SLOT(zoom_out()));

 connect(nav_panel_, SIGNAL(scale_ratio_change_requested(qreal)),
   foreground_panel_, SLOT(change_scale_ratio(qreal)));


 connect(nav_panel_, SIGNAL(geometric_up_requested()),
   this, SLOT(handle_geometric_up()));
 connect(nav_panel_, SIGNAL(geometric_down_requested()),
   this, SLOT(handle_geometric_down()));
 connect(nav_panel_, SIGNAL(geometric_left_requested()),
   this, SLOT(handle_geometric_left()));
 connect(nav_panel_, SIGNAL(geometric_right_requested()),
   this, SLOT(handle_geometric_right()));
 connect(nav_panel_, SIGNAL(series_previous_requested()),
   this, SLOT(handle_series_previous()));
 connect(nav_panel_, SIGNAL(series_next_requested()),
   this, SLOT(handle_series_next()));

 main_layout_->addWidget(nav_panel_);



 main_layout_->addWidget(button_box_);

 setLayout(main_layout_);

// original_width_ = this->width();
// original_height_ = this->height();

 show();
}

void ScignStage_CH_Dialog::handle_open_file_requested(QString path)
{
 current_image_file_ = path;
 foreground_panel_->open_file(path);
}

void ScignStage_CH_Dialog::open_folder_requested()
{

 QString str = QFileDialog::getExistingDirectory(nullptr, "Select Image Folder",
   DEFAULT_ASSETS_FOLDER);

 if(!str.isEmpty())
 {
  open_folder(str);
 }
}

void ScignStage_CH_Dialog::api_search_requested()
{
 //QString key = "HyE94kOP2z3mtKswek5eTW5pnVZEAQ1p";

 QString api_url = "https://api.collection.cooperhewitt.org/rest/";

 QString token = "c2b480aa41022859dde0af8ca33f16e8";


 QUrl qurl;
 qurl.setUrl(api_url);

 QUrlQuery qry;
 qry.addQueryItem("method", "cooperhewitt.objects.getImages");
 qry.addQueryItem("access_token", token);
 qry.addQueryItem("object_id", "18210637");

 qurl.setQuery(qry);

 //?query_file_line_edit_->setText(qurl.toString());

 if(!qnam_)
 {
  qnam_ = new QNetworkAccessManager;
  QObject::connect(qnam_, SIGNAL(finished(QNetworkReply*)),
    this, SLOT(handle_api_reply(QNetworkReply*)));
 }
 QNetworkRequest req; //= new QNetworkRequest;

 req.setUrl(qurl);
 //req.setRawHeader("api_key", key.toLatin1()); // "HyE94kOP2z3mtKswek5eTW5pnVZEAQ1p");

 qnam_->get(req);

}


void ScignStage_CH_Dialog::handle_api_reply(QNetworkReply* reply)
{
 QString response = QString::fromLatin1(reply->readAll());
 qDebug() << response;

 QJsonDocument jsond = QJsonDocument::fromJson(response.toLatin1());

 QDomDocument qdd = json_to_xml(jsond);

 //qDebug() << qdd.toString();

 QScign::TextIO::save_file(DEFAULT_ASSETS_FOLDER "/tmp/api.xml", qdd.toString());


 QXmlQuery query;

 QByteArray xml_byte_array;
 QBuffer xml_device(&xml_byte_array);

 QString xml_contents = qdd.toString();

 xml_device.setData(xml_contents.toUtf8());
 xml_device.open(QIODevice::ReadOnly);
 query.bindVariable("xml-byte-array", &xml_device);

 QString query_string = R"__(
  for $n in (doc($xml-byte-array)/images/images_s/*)
    return ("!!!", ($n/name()), "!!!", ($n/url/string()) )
  )__";


 //?, ($n/string())


 query.setQuery(query_string);

 //query.setFocus(xml_contents);

 QByteArray qba;
 QBuffer buf(&qba);
 buf.open(QIODevice::WriteOnly);

 QXmlSerializer serializer(query, &buf);
 query.evaluateTo(&serializer);

 QScign::TextIO::save_file(DEFAULT_ASSETS_FOLDER "/tmp/api.xq", qba);

 QString results = QString::fromLatin1(qba);

 QStringList rs = results.split("!!!");

 QMap<QString, int> urls;

 QString code;

 QList<Multisize_Image_Tile_Info> infos;

 int count = 0;

 for(QString url : rs)
 {
  url = url.trimmed();
  if(!url.isEmpty())
  {
   if(code.isEmpty())
   {
    code = url;
   }
   else
   {
    urls[url] = (int) parse_image_size(code);

    QString ap;

    download_image_to_folder(url, DEFAULT_ASSETS_FOLDER "/tmp/api/images",
      count, ap);

    ++count;

    Multisize_Image_Tile_Info miti(code, ap);

    miti.set_group_number(0);
    miti.set_size_code((int) parse_image_size(code));

    infos.push_back(miti);

    code.clear();

   }
  }
 }

 // qDebug() << "URLS: " << urls;


 if(!infos.isEmpty())
 {
  series_panel_->display_tiles(infos);
 }


 //return QString::fromLatin1(qba);


}


void ScignStage_CH_Dialog::open_folder(QString path)
{
//? series_panel_->open_folder(path);

#ifdef HIDE
  QRegularExpression rx("r(\\d+)c(\\d+)");

  bool valid_images_folder = true; // check this ...?

  QDirIterator dirIt(path, QDirIterator::Subdirectories);

  QList<Geometic_Image_Tile_Info> infos;

  while (dirIt.hasNext())
  {
   dirIt.next();
   QFileInfo qfi = dirIt.filePath();

   if(qfi.isFile())
   {
    if(qfi.suffix() == "BMP" || qfi.suffix() == "jpg")
    {
     QString qfin = qfi.baseName();
     if(valid_images_folder)
     {
      QRegularExpressionMatch rxm = rx.match(qfin);
      if(rxm.hasMatch())
      {
       int r = rxm.captured(1).toInt();
       int c = rxm.captured(2).toInt();
       Geometic_Image_Tile_Info giti(qfin, path + "/" + qfin + ".jpg");
       giti.set_series_row(r);
       giti.set_series_column(c);

       infos.push_back(giti);
      }
     }
    }
   }
  }

  if(!infos.isEmpty())
  {
   series_panel_->display_tiles(infos);
  }
#endif // def HIDE

}

void ScignStage_CH_Dialog::download_image_to_folder(QString url,
  QString path, int count, QString& result)
{
 QUrl qurl;
 qurl.setUrl(url);

 //?query_file_line_edit_->setText(qurl.toString());

 QEventLoop qel;

// if(!qnam_images_)
// {
  qnam_images_ = new QNetworkAccessManager;
  QObject::connect(qnam_images_, &QNetworkAccessManager::finished,
    this, [&qel, &result, path, count](QNetworkReply* reply)
  {
   qel.exit();

   QByteArray qba = reply->readAll();

   QString file = QString("%1/img_%2").arg(path).arg(count);

   QScign::TextIO::save_file(file, qba);

   result = file;

   //result = "/api/images"; //"OK";

   //qDebug() << "REPLIED ...";
  });
// }
 QNetworkRequest req; //= new QNetworkRequest;

 req.setUrl(qurl);

 qnam_images_->get(req);

 qel.exec();

}



ScignStage_CH_Dialog::~ScignStage_CH_Dialog()
{
 // //  and so one ...
 delete button_ok_;
 delete button_proceed_;
 delete button_cancel_;
}

void ScignStage_CH_Dialog::check_tile_geometric_navigate(int r, int c)
{
 QString tile_file = QString("r%1c%2").arg(r).arg(c);

 ScignStage_Image_Tile* new_tile = series_panel_->find_tile_by_name(tile_file); //current_tile_map_->value(tile_file);

 if(new_tile)
 {
  if(QObject* qob = new_tile->associated_qobject())
  {
   ScignStage_Clickable_Label* cl = qobject_cast<ScignStage_Clickable_Label*>(qob);
   foreground_panel_->open_file(cl->path);
   series_panel_->set_current_clickable_label(cl);
   series_panel_->set_current_tile(new_tile);

   nav_panel_->set_row_text(r);
   nav_panel_->set_column_text(c);
  }
 }
}


void ScignStage_CH_Dialog::handle_geometric_up()
{
 ScignStage_Image_Tile* current_tile = series_panel_->current_tile();
 if(current_tile)
 {
  int r = current_tile->get_dimensional_annotation(0);
  if(r > 0)
  {
   --r;
   int c = current_tile->get_dimensional_annotation(1);
   check_tile_geometric_navigate(r, c);
  }
 }
}

void ScignStage_CH_Dialog::handle_geometric_down()
{
 ScignStage_Image_Tile* current_tile = series_panel_->current_tile();
 if(current_tile)
 {
  int r = current_tile->get_dimensional_annotation(0);
  ++r;
  int c = current_tile->get_dimensional_annotation(1);
  check_tile_geometric_navigate(r, c);
 }
}

void ScignStage_CH_Dialog::handle_geometric_left()
{
 ScignStage_Image_Tile* current_tile = series_panel_->current_tile();
 if(current_tile)
 {
  int c = current_tile->get_dimensional_annotation(1);
  if(c > 0)
  {
   --c;
   int r = current_tile->get_dimensional_annotation(0);
   check_tile_geometric_navigate(r, c);
  }
 }
}

void ScignStage_CH_Dialog::handle_geometric_right()
{
 ScignStage_Image_Tile* current_tile = series_panel_->current_tile();
 if(current_tile)
 {
  int c = current_tile->get_dimensional_annotation(1);
  ++c;
  int r = current_tile->get_dimensional_annotation(0);
  check_tile_geometric_navigate(r, c);
 }
}

void ScignStage_CH_Dialog::handle_series_previous()
{
 ScignStage_Image_Tile* current_tile = series_panel_->current_tile();
 if(current_tile)
 {
  if(ScignStage_Image_Tile* new_tile = current_tile->series_previous())
  {
   int r = new_tile->get_dimensional_annotation(0);
   int c = new_tile->get_dimensional_annotation(1);
   check_tile_geometric_navigate(r, c);
  }
 }
}

void ScignStage_CH_Dialog::handle_series_next()
{
 ScignStage_Image_Tile* current_tile = series_panel_->current_tile();
 if(current_tile)
 {
  if(ScignStage_Image_Tile* new_tile = current_tile->series_next())
  {
   int r = new_tile->get_dimensional_annotation(0);
   int c = new_tile->get_dimensional_annotation(1);
   check_tile_geometric_navigate(r, c);
  }
 }
}


void ScignStage_CH_Dialog::cancel()
{
 Q_EMIT(rejected());
 Q_EMIT(canceled(this));
 Q_EMIT(rejected());
 close();
}

void ScignStage_CH_Dialog::accept()
{
 Q_EMIT(accepted(this));
}



