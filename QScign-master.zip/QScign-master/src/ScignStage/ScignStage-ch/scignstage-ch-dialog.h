
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)


#ifndef SCIGNSTAGE_CH_DIALOG__H
#define SCIGNSTAGE_CH_DIALOG__H

#include <QObject>

#include <QMetaType>

#include <QList>
#include <QGraphicsScene>
#include <QPoint>

#include <QDialog>


#include "accessors.h"
#include "qsns.h"

#include "ScignStage/nav-protocols/image-multi-size/nav-image-multisize-panel.h"
#include "ScignStage/nav-protocols/image-multi-size/fore-image-multisize-panel.h"
#include "ScignStage/nav-protocols/image-multi-size/series-image-multisize-panel.h"

//?#include "ScignStage/annotations/annotation-symbols-panel.h"

#include "ScignStage/descriptions/description-panel.h"


class QDialogButtonBox;
class QLabel;
class QLineEdit;
class QTabWidget;
class QTextEdit;
class QFrame;
class QHBoxLayout;
class QVBoxLayout;
class QSlider;
class QPlainTextEdit;
class QBoxLayout;
class QButtonGroup;
class QGroupBox;
class QScrollArea;
class QGridLayout;
class QNetworkAccessManager;
class QNetworkReply;
class QSplitter;

class ScignStage_Image_Tile;
class ScignStage_Clickable_Label;


QSNS_(ScignStage)
//?namespace QScign { namespace ScignStage {



class ScignStage_CH_Dialog : public QDialog
{
 Q_OBJECT

 enum class Image_Sizes {
  B = 5, Z = 4, N = 3, D = 2, SQ = 1, N_A = 0

 };

 Image_Sizes parse_image_size(QString code)
 {
  static QMap<QString, Image_Sizes> static_map {{
    { "B", Image_Sizes::B },
    { "Z", Image_Sizes::Z },
    { "N", Image_Sizes::N },
    { "D", Image_Sizes::D },
    { "SQ", Image_Sizes::SQ },
  }};

  return static_map.value(code.toUpper(), Image_Sizes::N_A);
 }

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QPushButton* button_proceed_;


 QHBoxLayout* middle_layout_;
 QVBoxLayout* main_layout_;

 QString current_image_file_;

 // //  "Pseudo" Toolbar ...
 QHBoxLayout* top_buttons_layout_;
//? QPushButton* updates_button_;
 QPushButton* open_folder_button_;
 QPushButton* take_screenshot_button_;
//? QPushButton* sonic_button_;
 QPushButton* scignstage_button_;
 QPushButton* api_button_;


 // //
 QScrollArea* series_scroll_area_;

 Series_Image_Multisize_Panel* series_panel_;

 // //
 Fore_Image_Multisize_Panel* foreground_panel_;

 // //
 QVBoxLayout* description_layout_;

 QScrollArea* description_scroll_area_;
 Description_Panel* description_panel_;


 NAV_Image_Multisize_Panel* nav_panel_;

 QNetworkAccessManager* qnam_;

 QNetworkAccessManager* qnam_images_;

 QSplitter* foreground_and_description_splitter_;

 void check_tile_geometric_navigate(int r, int c);


public:



 ScignStage_CH_Dialog(QString initial_image_file, QWidget* parent = nullptr);

 ~ScignStage_CH_Dialog();


 void open_folder(QString path);

 void download_image_to_folder(QString url, QString path, int count, QString& result);

Q_SIGNALS:
 void canceled(QDialog*);
 void accepted(QDialog*);

 void take_screenshot_requested();

public Q_SLOTS:

 void accept();
 void cancel();

 void api_search_requested();

 void open_folder_requested();
 void handle_open_file_requested(QString);

 void handle_api_reply(QNetworkReply* reply);

 void handle_geometric_up();
 void handle_geometric_down();
 void handle_geometric_left();
 void handle_geometric_right();
 void handle_series_previous();
 void handle_series_next();

};

_QSNS(ScignStage)


#endif  // SCIGNSTAGE_CH_DIALOG__H


