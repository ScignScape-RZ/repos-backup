
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)


#include "scignstage-wsi-dialog.h"

#include "ScignStage/subwindows/scignstage-image-tile.h"

#include "styles.h"

#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QButtonGroup>
#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>

#include <QDirIterator>

#include <QPlainTextEdit>
#include <QTextStream>

#include <QPainter>
#include <QPushButton>
#include <QLabel>

#include <QTableWidget>
#include <QGraphicsPixmapItem>

#include <QMessageBox>
#include <QDebug>

#include <QGraphicsView>
#include <QScrollArea>


#include <QHeaderView>

#include <QMenu>
#include <QAction>

#include <QListWidget>

#include "ScignStage/subwindows/scignstage-clickable-label.h"

#include "ScignStage/paraviews/scignstage-navigation-protocol-dialog.h"

#include "ScignStage/paraviews/scignstage-png-dialog.h"


USING_QSNS(ScignStage)


ScignStage_WSI_Dialog::ScignStage_WSI_Dialog(
  QString initial_image_file,
  QWidget* parent)
  : QDialog(parent)
{
 button_box_ = new QDialogButtonBox(this);

 button_ok_ = new QPushButton("OK");
 button_proceed_ = new QPushButton("Proceed");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

 button_proceed_->setDefault(false);
 button_proceed_->setAutoDefault(false);

 button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);

 button_ok_->setStyleSheet(basic_button_style_sheet_());
 button_proceed_->setStyleSheet(basic_button_style_sheet_());
 button_cancel_->setStyleSheet(basic_button_style_sheet_());


 connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));

 main_layout_ = new QVBoxLayout;


 top_buttons_layout_ = new QHBoxLayout;

 //?updates_button_ = new QPushButton("Updates Dialog", this);

 take_screenshot_button_ = new QPushButton("Screenshot", this);
 open_folder_button_ = new QPushButton("Open Folder", this);
 //?scignstage_button_ = new QPushButton("ScignStage", this);
 //?sonic_button_ = new QPushButton("SONIC", this);

 //?updates_button_->setStyleSheet(colorful_button_style_sheet_());
 //?open_image_button_->setStyleSheet(colorful_button_style_sheet_());
 take_screenshot_button_->setStyleSheet(colorful_button_style_sheet_());
 open_folder_button_->setStyleSheet(colorful_button_style_sheet_());
 //?scignstage_button_->setStyleSheet(colorful_button_style_sheet_());

 //?sonic_button_->setStyleSheet(colorful_button_style_sheet_());

//? connect(updates_button_, SIGNAL(clicked()),
//   this, SLOT(updates_dialog_requested()));

 connect(take_screenshot_button_, SIGNAL(clicked()),
   this, SIGNAL(take_screenshot_requested()));

//? connect(open_image_button_, SIGNAL(clicked()),
//   this, SIGNAL(open_image_requested()));

 connect(open_folder_button_, SIGNAL(clicked()),
   this, SLOT(open_folder_requested()));

//? connect(scignstage_button_, SIGNAL(clicked()),
//   this, SLOT(open_scignstage_navigation_protocol_dialog()));


 top_buttons_layout_->addStretch();

 //?top_buttons_layout_->addWidget(updates_button_);
 //?top_buttons_layout_->addWidget(patient_info_button_);
 //?top_buttons_layout_->addWidget(diagnostic_report_button_);

 top_buttons_layout_->addWidget(open_folder_button_);
 //?top_buttons_layout_->addWidget(open_image_button_);
 top_buttons_layout_->addWidget(take_screenshot_button_);

 //?top_buttons_layout_->addWidget(scignstage_button_);

 //?top_buttons_layout_->addWidget(sonic_button_);

 // //////////////////////////////////////////////

 main_layout_->addLayout(top_buttons_layout_);

 middle_layout_ = new QHBoxLayout;

 // //   Series
 series_panel_ = new Series_Geometric2D_Panel(this);

 //series_panel_->setMaximumWidth(70);

 series_scroll_area_ = new QScrollArea(this);
 series_scroll_area_->setWidget(series_panel_);

 series_scroll_area_->setMaximumWidth(80);

 series_scroll_area_->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);

 middle_layout_->addWidget(series_scroll_area_);

 connect(series_panel_, SIGNAL(open_file_requested(QString)),
   this, SLOT(handle_open_file_requested(QString)));

 //?middle_layout_->addStretch();

 // //   Foreground
 foreground_panel_ = new Fore_Geometric2D_Panel(initial_image_file, this);

 foreground_panel_->setMinimumHeight(300);

 foreground_panel_->setMinimumWidth(300);

 middle_layout_->addWidget(foreground_panel_);

 // middle_layout_->addStretch();


 // //   Annotations

 annotation_symbols_scroll_area_ = new QScrollArea(this);
 annotation_symbols_panel_ = new Annotation_Symbols_Panel(this);

 annotation_symbols_scroll_area_->setWidget(annotation_symbols_panel_);

 annotation_symbols_scroll_area_->setMaximumWidth(80);

 annotation_layout_ = new QVBoxLayout;
 annotation_layout_->addSpacing(10);
 annotation_layout_->addWidget(annotation_symbols_scroll_area_);

 middle_layout_->addLayout(annotation_layout_);

 main_layout_->addLayout(middle_layout_);

 nav_panel_ = new NAV_Geometric2D_Panel(this);

 connect(series_panel_, SIGNAL(navigated_from_series(int,int)),
   nav_panel_, SLOT(set_row_and_column_text(int,int)));

 connect(nav_panel_, SIGNAL(zoom_in_requested()),
   foreground_panel_, SLOT(zoom_in()));

 connect(nav_panel_, SIGNAL(zoom_out_requested()),
   foreground_panel_, SLOT(zoom_out()));

 connect(nav_panel_, SIGNAL(scale_ratio_change_requested(qreal)),
   foreground_panel_, SLOT(change_scale_ratio(qreal)));


 connect(nav_panel_, SIGNAL(geometric_up_requested()),
   this, SLOT(handle_geometric_up()));
 connect(nav_panel_, SIGNAL(geometric_down_requested()),
   this, SLOT(handle_geometric_down()));
 connect(nav_panel_, SIGNAL(geometric_left_requested()),
   this, SLOT(handle_geometric_left()));
 connect(nav_panel_, SIGNAL(geometric_right_requested()),
   this, SLOT(handle_geometric_right()));
 connect(nav_panel_, SIGNAL(series_previous_requested()),
   this, SLOT(handle_series_previous()));
 connect(nav_panel_, SIGNAL(series_next_requested()),
   this, SLOT(handle_series_next()));

 //void zoom_slider_value_changed(int);


 main_layout_->addWidget(nav_panel_);



 main_layout_->addWidget(button_box_);

 setLayout(main_layout_);


 show();
}

void ScignStage_WSI_Dialog::handle_open_file_requested(QString path)
{
 current_image_file_ = path;
 foreground_panel_->open_file(path);
 // main_pixmap_item_->setPixmap(QPixmap::fromImage(QImage(path)));
}

void ScignStage_WSI_Dialog::open_folder_requested()
{

 QString str = QFileDialog::getExistingDirectory(nullptr, "Select Image Folder",
   DEFAULT_FOLDER);

 if(!str.isEmpty())
 {
  open_folder(str);
 }
}


void ScignStage_WSI_Dialog::open_folder(QString path)
{
//? series_panel_->open_folder(path);

  QRegularExpression rx("r(\\d+)c(\\d+)");

  bool valid_images_folder = true; // check for this ...?

  QDirIterator dirIt(path, QDirIterator::Subdirectories);

  QList<Geometic_Image_Tile_Info> infos;

  while (dirIt.hasNext())
  {
   dirIt.next();
   QFileInfo qfi = dirIt.filePath();

   if(qfi.isFile())
   {
    if(qfi.suffix() == "BMP" || qfi.suffix() == "jpg")
    {
     QString qfin = qfi.baseName();
     if(valid_images_folder)
     {
      //     tile = current_tile_map_->value(qfin);
      //     if(!tile)
      //     {
      QRegularExpressionMatch rxm = rx.match(qfin);
      if(rxm.hasMatch())
      {
       int r = rxm.captured(1).toInt();
       int c = rxm.captured(2).toInt();

       //?Geometic_Image_Tile_Info giti(qfin);
       Geometic_Image_Tile_Info giti(qfin, path + "/" + qfin + ".jpg");
       giti.set_series_row(r);
       giti.set_series_column(c);

       infos.push_back(giti);
      }
     }
    }
   }
  }

  if(!infos.isEmpty())
  {
   series_panel_->display_tiles(infos);
  }



}


ScignStage_WSI_Dialog::~ScignStage_WSI_Dialog()
{
 // //  and so on ...
 delete button_ok_;
 delete button_proceed_;
 delete button_cancel_;
}

void ScignStage_WSI_Dialog::check_tile_geometric_navigate(int r, int c)
{
 QString tile_file = QString("r%1c%2").arg(r).arg(c);

 ScignStage_Image_Tile* new_tile = series_panel_->find_tile_by_name(tile_file); //current_tile_map_->value(tile_file);

 if(new_tile)
 {
  if(QObject* qob = new_tile->associated_qobject())
  {
   ScignStage_Clickable_Label* cl = qobject_cast<ScignStage_Clickable_Label*>(qob);
   foreground_panel_->open_file(cl->path);
   series_panel_->set_current_clickable_label(cl);
   series_panel_->set_current_tile(new_tile);

   nav_panel_->set_row_text(r);
   nav_panel_->set_column_text(c);

  }
 }
}


void ScignStage_WSI_Dialog::handle_geometric_up()
{
 ScignStage_Image_Tile* current_tile = series_panel_->current_tile();
 if(current_tile)
 {
  int r = current_tile->get_dimensional_annotation(0);
  if(r > 0)
  {
   --r;
   int c = current_tile->get_dimensional_annotation(1);
   check_tile_geometric_navigate(r, c);
  }
 }
}

void ScignStage_WSI_Dialog::handle_geometric_down()
{
 ScignStage_Image_Tile* current_tile = series_panel_->current_tile();
 if(current_tile)
 {
  int r = current_tile->get_dimensional_annotation(0);
  ++r;
  int c = current_tile->get_dimensional_annotation(1);
  check_tile_geometric_navigate(r, c);
 }
}

void ScignStage_WSI_Dialog::handle_geometric_left()
{
 ScignStage_Image_Tile* current_tile = series_panel_->current_tile();
 if(current_tile)
 {
  int c = current_tile->get_dimensional_annotation(1);
  if(c > 0)
  {
   --c;
   int r = current_tile->get_dimensional_annotation(0);
   check_tile_geometric_navigate(r, c);
  }
 }
}

void ScignStage_WSI_Dialog::handle_geometric_right()
{
 ScignStage_Image_Tile* current_tile = series_panel_->current_tile();
 if(current_tile)
 {
  int c = current_tile->get_dimensional_annotation(1);
  ++c;
  int r = current_tile->get_dimensional_annotation(0);
  check_tile_geometric_navigate(r, c);
 }
}

void ScignStage_WSI_Dialog::handle_series_previous()
{
 ScignStage_Image_Tile* current_tile = series_panel_->current_tile();
 if(current_tile)
 {
  if(ScignStage_Image_Tile* new_tile = current_tile->series_previous())
  {
   int r = new_tile->get_dimensional_annotation(0);
   int c = new_tile->get_dimensional_annotation(1);
   check_tile_geometric_navigate(r, c);
  }
 }
}

void ScignStage_WSI_Dialog::handle_series_next()
{
 ScignStage_Image_Tile* current_tile = series_panel_->current_tile();
 if(current_tile)
 {
  if(ScignStage_Image_Tile* new_tile = current_tile->series_next())
  {
   int r = new_tile->get_dimensional_annotation(0);
   int c = new_tile->get_dimensional_annotation(1);
   check_tile_geometric_navigate(r, c);
  }
 }
}


void ScignStage_WSI_Dialog::cancel()
{
 Q_EMIT(rejected());
 Q_EMIT(canceled(this));
 Q_EMIT(rejected());
 close();
}

void ScignStage_WSI_Dialog::accept()
{
 Q_EMIT(accepted(this));
}



#ifdef HIDE
 if (ani_file.open(QFile::ReadOnly))
 {
  ani_data = ani_file.readAll();

  qDebug() << "ANI: " << ani_data;
  QStringList qsl = ani_data.split('\n');
  for(QString line : qsl)
  {
   QStringList fields = line.split(' ');
   if(fields.length() == 5)
   {
    QString tile_file = fields[0];

    if(!tile_file.isEmpty())
    {
     QRegularExpressionMatch rxm = rx.match(tile_file);
     if(rxm.hasMatch())
     {
      int r = rxm.captured(1).toInt();
      int c = rxm.captured(2).toInt();

      if(!current_tile_map_)
      {
       current_tile_map_ = new QMap<QString, ScignStage_Image_Tile*>();
      }
      ScignStage_Image_Tile* tile = current_tile_map_->value(tile_file);
      if(!tile)
      {
       tile = new ScignStage_Image_Tile(path + "/" + tile_file + ".jpg");//
       tile->set_dimensional_annotation(0, r);
       tile->set_dimensional_annotation(1, c);
       //, r, c);
       current_tile_map_->insert(tile_file, tile);
      }
      //?
      //      tile->add_tile_segment(fields[1].toInt(),
      //        fields[2].toInt(), fields[3].toInt(), fields[4].toInt());
     }
    }
   }
  }
 }

#endif






