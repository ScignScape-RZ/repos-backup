
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)


#ifndef SCIGNSTAGE_WSI_DIALOG__H
#define SCIGNSTAGE_WSI_DIALOG__H

#include <QObject>

#include <QMetaType>

#include <QList>
#include <QGraphicsScene>
#include <QPoint>

#include <QDialog>

#include "accessors.h"
#include "qsns.h"

#include "ScignStage/nav-protocols/geometric2d/nav-geometric-2d-panel.h"
#include "ScignStage/nav-protocols/geometric2d/fore-geometric-2d-panel.h"
#include "ScignStage/nav-protocols/geometric2d/series-geometric-2d-panel.h"
#include "ScignStage/annotations/annotation-symbols-panel.h"


class QDialogButtonBox;
class QLabel;
class QLineEdit;
class QTabWidget;
class QTextEdit;
class QFrame;
class QHBoxLayout;
class QVBoxLayout;
class QSlider;
class QPlainTextEdit;
class QBoxLayout;
class QButtonGroup;
class QGroupBox;
class QScrollArea;
class QGridLayout;

class ScignStage_Image_Tile;
class ScignStage_Clickable_Label;

//?QSNS_(ScignStage)

namespace QScign { namespace ScignStage {



class ScignStage_WSI_Dialog : public QDialog
{

 Q_OBJECT

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QPushButton* button_proceed_;


 QHBoxLayout* middle_layout_;
 QVBoxLayout* main_layout_;

 QString current_image_file_;

 // //  "Pseudo" Toolbar ...
 QHBoxLayout* top_buttons_layout_;
//? QPushButton* updates_button_;
 QPushButton* open_folder_button_;
 QPushButton* take_screenshot_button_;
//? QPushButton* sonic_button_;
 QPushButton* scignstage_button_;


 // //
 QScrollArea* series_scroll_area_;

 Series_Geometric2D_Panel* series_panel_;

 // //
 Fore_Geometric2D_Panel* foreground_panel_;

 // //
 QVBoxLayout* annotation_layout_;
 QScrollArea* annotation_symbols_scroll_area_;
 Annotation_Symbols_Panel* annotation_symbols_panel_;


 NAV_Geometric2D_Panel* nav_panel_;

 void check_tile_geometric_navigate(int r, int c);


public:



 ScignStage_WSI_Dialog(QString initial_image_file, QWidget* parent = nullptr);

 ~ScignStage_WSI_Dialog();


 void open_folder(QString path);

Q_SIGNALS:
 void canceled(QDialog*);
 void accepted(QDialog*);

public Q_SLOTS:

 void accept();
 void cancel();

 void open_folder_requested();
 void handle_open_file_requested(QString);

 void handle_geometric_up();
 void handle_geometric_down();
 void handle_geometric_left();
 void handle_geometric_right();
 void handle_series_previous();
 void handle_series_next();

};

_QSNS(ScignStage)


#endif  // SCIGNSTAGE_WSI_DIALOG__H


