
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)


#include "annotation-symbols-panel.h"

#include <QVBoxLayout>

#include <QPushButton>
#include <QPainter>
#include <QLabel>
#include <QGraphicsPixmapItem>
#include <QDebug>


USING_QSNS(ScignStage)


Annotation_Symbols_Panel::Annotation_Symbols_Panel(QWidget *parent)
  :  QFrame(parent)
{
 main_layout_ = new QVBoxLayout;

 scratch_scene_ = new QGraphicsScene(this);



 // //  draw the annotation symbols ...

 QPen qpen(QColor("yellow"));
 qpen.setWidth(2);
 QBrush qbr(QColor("red"));


 int center_x = 20;
 int center_y = 20;
 int scale_factor = 1;
 int radius = 15;
 int width = 10;

 {
  QPolygonF poly1;
  poly1
     << QPointF(center_x - scale_factor * radius, center_y)
     << QPointF(center_x, center_y - scale_factor * radius)
     << QPointF(center_x + scale_factor * radius, center_y)
     << QPointF(center_x, center_y + scale_factor * radius)
    ;

   QPolygonF spoly;
   spoly
     << QPointF(center_x - scale_factor * width, center_y - scale_factor * width)
     << QPointF(center_x + scale_factor * width, center_y - scale_factor * width)
     << QPointF(center_x + scale_factor * width, center_y + scale_factor * width)
     << QPointF(center_x - scale_factor * width, center_y + scale_factor * width)

        ;

   QPolygonF poly = poly1.united(spoly);

   //scratch_scene_->addPolygon(poly1, qpen, qbr);
   scratch_scene_->addPolygon(poly, qpen, qbr);

   star_button_ = new QPushButton(this);

   render_to_button(star_button_, poly);
   scratch_scene_->clear();

 }


 {
  scratch_scene_->addEllipse(2, 2, 35, 35, qpen, qbr);

  ellipse_button_ = new QPushButton(this);

  QPolygonF pf;

  render_to_button(ellipse_button_, pf);
  scratch_scene_->clear();
 }
 {


  QPolygonF dpoly;
  radius = 15;
  dpoly
   << QPointF(center_x - scale_factor * radius, center_y)
   << QPointF(center_x, center_y - scale_factor * radius)
   << QPointF(center_x + scale_factor * radius, center_y)
   << QPointF(center_x, center_y + scale_factor * radius);


  scratch_scene_->addPolygon(dpoly, qpen, qbr);

  diamond_button_ = new QPushButton(this);
  render_to_button(diamond_button_, dpoly);
  scratch_scene_->clear();
 }


 {
  QPolygonF ppoly;
  width = 8;
  float offset = 1;
  float scale_factor = 5;
  construct_plus(ppoly, center_x, center_y, scale_factor, offset, width);
  scratch_scene_->addPolygon(ppoly, qpen, qbr);

  plus_button_ = new QPushButton(this);

  render_to_button(plus_button_, ppoly);
  scratch_scene_->clear();
 }

 {
  float scale_factor = 5;
  float x_offset = 4;
  float y_offset = 4;
  float width = 8;

  QPolygonF opoly;
  construct_octagon(opoly, center_x, center_y, scale_factor, x_offset, y_offset, width);
  scratch_scene_->addPolygon(opoly, qpen, qbr);

  octagon_button_ = new QPushButton(this);
  octagon_button_->setObjectName("octagon_button_");

  render_to_button(octagon_button_, opoly);
  scratch_scene_->clear();
 }

 {
  float scale_factor = 4;
  float x_offset = 4;
  float y_offset = 8;
  float width = 2;

//  float x_offset = 6;
//  float y_offset = 8;

  QPolygonF vopoly;
  construct_octagon(vopoly, center_x, center_y, scale_factor, x_offset, y_offset, width);
  scratch_scene_->addPolygon(vopoly, qpen, qbr);

  vertical_octagon_button_ = new QPushButton(this);
  vertical_octagon_button_->setObjectName("vertical_octagon_button_");

  render_to_button(vertical_octagon_button_, vopoly);
  scratch_scene_->clear();
 }

 {
  float width = 8;
  float height = 4;
  float offset = 3;
  float scale_factor = 4;

  QPolygonF tdpoly;
  construct_triangle_down(tdpoly, center_x, center_y, scale_factor, width, height, offset);
  scratch_scene_->addPolygon(tdpoly, qpen, qbr);

  triangle_down_button_ = new QPushButton(this);
  triangle_down_button_->setObjectName("triangle_down_button_");

  render_to_button(triangle_down_button_, tdpoly);
  scratch_scene_->clear();
 }

 {
  float width = 8;
  float height = 4;
  float offset = 3;
  float scale_factor = 4;

  QPolygonF tupoly;
  construct_triangle_up(tupoly, center_x, center_y, scale_factor, width, height, offset);
  scratch_scene_->addPolygon(tupoly, qpen, qbr);

  triangle_up_button_ = new QPushButton(this);
  triangle_up_button_->setObjectName("triangle_up_button_");

  render_to_button(triangle_up_button_, tupoly);
  scratch_scene_->clear();
 }


 main_layout_->addWidget(triangle_up_button_);
 triangle_up_label_ = new QLabel("?", this);
 add_graphics_button_text_and_line(triangle_up_label_);
 //?
 triangle_up_button_->setEnabled(false);
 //?triangle_up_button_->setEnabled(true);

 connect(triangle_up_button_, SIGNAL(clicked()),
   this, SLOT(add_arrow_annotation()));


 main_layout_->addWidget(triangle_down_button_);
 triangle_down_label_ = new QLabel("?", this);
 add_graphics_button_text_and_line(triangle_down_label_);
 triangle_down_button_->setEnabled(false);

//?
// connect(triangle_down_button_, SIGNAL(clicked()),
//   this, SLOT(add_to_arrow_group()));


 main_layout_->addWidget(star_button_);
 star_label_ = new QLabel("?", this);
 add_graphics_button_text_and_line(star_label_);
 star_button_->setEnabled(false);

 main_layout_->addWidget(octagon_button_);
 octagon_label_ = new QLabel("?", this);
 add_graphics_button_text_and_line(octagon_label_);
 octagon_button_->setEnabled(false);

 main_layout_->addWidget(vertical_octagon_button_);
 vertical_octagon_label_ = new QLabel("?", this);
 add_graphics_button_text_and_line(vertical_octagon_label_);
 vertical_octagon_button_->setEnabled(false);

// graphics_buttons_layout_->addWidget(skewed_tight_plus_button_);
// burning_pain_label_ = new QLabel("Burning\nPain", this);
// add_graphics_button_text_and_line(burning_pain_label_);
// skewed_tight_plus_button_->setEnabled(false);

// graphics_buttons_layout_->addWidget(diamond_button_);


 main_layout_->addWidget(ellipse_button_);
 ellipse_label_ = new QLabel("?", this);
 add_graphics_button_text_and_line(ellipse_label_);
 ellipse_button_->setEnabled(false);


 main_layout_->addWidget(plus_button_);
 plus_label_ = new QLabel("?", this);
 add_graphics_button_text_and_line(plus_label_);
 plus_button_->setEnabled(false);

 main_layout_->addWidget(diamond_button_);
 diamond_label_ = new QLabel("?", this);
 add_graphics_button_text_and_line(diamond_label_);
 diamond_button_->setEnabled(false);

 main_layout_->addStretch();

 setLayout(main_layout_);
}


Annotation_Symbols_Panel::~Annotation_Symbols_Panel()
{

}



void Annotation_Symbols_Panel::render_to_button(QPushButton* btn, QPolygonF& poly)
{
 QRect rect(0, 0, 40, 40);
 QPixmap* qpm = new QPixmap(rect.size());
 qpm->fill(Qt::transparent);
 QPainter painter(qpm);
 scratch_scene_->render(&painter, QRectF(0, 0, 40, 40), QRectF(0, 0, 40, 40));
 btn->setIcon(QIcon(*qpm));
 btn->setMaximumWidth(40);
 btn->setMaximumHeight(40);
 polygons_[btn] = poly;
 connect(btn, SIGNAL(pressed()), this, SLOT(graphics_button_clicked()));
}

void Annotation_Symbols_Panel::render_to_button(QPushButton* btn,
  QGraphicsPixmapItem* item, QGraphicsPixmapItem* scratch_item,
  QBoxLayout* layout, qreal x_offset,
  qreal y_offset, qreal reenlage_factor,
  QString text, qreal rotate)
{
 //btn->setText(QString("\n%1").arg(text));
 QLabel* label = new QLabel(text, this);
 label->setMinimumWidth(40);
 label->setAlignment(Qt::AlignCenter);

 label->setStyleSheet("QLabel {margin-bottom:10px;}");


 QRectF rf = item->boundingRect();
 //QRect r = rf.toAlignedRect();

 qreal xsf = 40/rf.width();
 qreal ysf = 55/rf.height();


 QRect r = item->boundingRect().toAlignedRect();


//? item->setScale(0.05);

 int mult = 10;

 QGraphicsScene scratch_scene;

 //?scratch_scene_->setSceneRect(0, 0, 0, 0);

 //QRect rect(0, 0, 55 * mult, 40 * mult);

 QRect rect(scratch_item->boundingRect().toAlignedRect());

 //?qDebug() << "RECT: " << rect;

 if(rotate != 0)
 {
  qDebug() << "rotate ...";
  QTransform qtr;
  qtr.translate(rect.height()/2.0,
                rect.width()/2.0);
  qtr.rotate(rotate);

  if(rotate == 90 || rotate == -90)
   rect = rect.transposed();

  qtr.translate(-rect.height()/2.0 ,
                -rect.width()/2.0);
  //?
  scratch_item->setTransform(qtr);

 }


 QRect rect1(scratch_item->boundingRect().toAlignedRect());

 //?qDebug() << "RECT1: " << rect1;


 scratch_scene.addItem(scratch_item);

 QRectF srect = scratch_scene.sceneRect();// (scratch_item->boundingRect().toAlignedRect());

 //?qDebug() << srect;


//  QRect rect(0, 0, 455, 1024);

 //?qDebug() << rect;




// int x_adj = x_offset;
// int y_adj = y_offset;


 QRectF srect_adj;
//   = QRectF(x_adj, y_adj,
//   srect.width() - x_adj, srect.height() - y_adj);

// if(y_offset != 0)
// {
  //x_adj = 10;
  srect_adj = QRectF(x_offset, 0,
    srect.width() - (2 * x_offset), srect.height() - y_offset);
// }


// if(rotate > 0)
// {
//  srect_adj = QRectF(x_offset, 0,
//    srect.width() - (2 * x_offset), srect.height() - 100);
//  //rect = QRect(0, 0, 1024, 749);
// }


 QPixmap* qpm = new QPixmap(rect.size());
 qpm->fill(Qt::transparent);
 QPainter painter(qpm);

 scratch_scene.render(&painter, rect, srect_adj); //QRectF(0, 0, 40, 55)); //srect_adj); //QRectF(0, 0, 56, 5)); //srect); //, rect, rect); //, rect, rect) ; //QRectF(0, 0, 40 * mult, 55 * mult),

   //QRectF(x_offset, y_offset, 40 * mult, 55 * mult));
 btn->setIcon(QIcon(*qpm));
 //btn->setIconSize(qpm->size());

//? qDebug() << "W: " << qpm->width();
//? qDebug() << "H: " << qpm->height();

 btn->setStyleSheet("QPushButton{padding:0px;margin:0px;}");

// btn->setMinimumWidth(40);
// btn->setMinimumHeight(55);
// btn->setMaximumWidth(40);
// btn->setMaximumHeight(55);
 layout->addWidget(btn);

 layout->addWidget(label);
 layout->addStretch();

 //polygons_[btn] = poly;
 //connect(btn, SIGNAL(pressed()), this, SLOT(graphics_button_clicked()));

 //?  scratch_scene_->clear();


// QRect view_rect = QRect(-40, 0, 100, 100);
// item->renderer()->setViewBox(view_rect);

//         self.srenderer.setViewBox(seliRect)
//         self.seliSecond.setPos(self.centerx-10, self.centery-1)

 if(xsf < ysf)
 {
  item->setScale(reenlage_factor * xsf);
 }
 else
 {
  item->setScale(reenlage_factor * ysf);
 }


 //? seli_scene_->addItem(item);
 item->setVisible(false);

 labels_to_items_[item] = label;

#ifdef HIDE
 connect(btn, &QPushButton::pressed, [this, item, label]
 {
  if(current_seli_item_)
  {
   for(QGraphicsItem* item : current_seli_specific_items_[current_seli_item_])
   {
    item->setVisible(false);
   }
   current_seli_item_->setVisible(false);
  }
  else
  {
   enable_graphics_buttons();
  }
  if(current_seli_label_)
   current_seli_label_->setStyleSheet("QLabel { background-color : none; margin-bottom:10px;}");
  item->setVisible(true);
  label->setStyleSheet("QLabel { background-color : salmon; margin-bottom:10px;}");
  current_seli_item_ = item;
  for(QGraphicsItem* item : current_seli_specific_items_[current_seli_item_])
  {
   item->setVisible(true);
  }
  current_seli_label_ = label;
 });
#endif // HIDE

}






void Annotation_Symbols_Panel::construct_octagon(QPolygonF& poly, float center_x, float center_y,
  float scale_factor, float x_offset, float y_offset, float width)
{
 poly
   << QPointF(center_x - scale_factor * x_offset, center_y + width)
   << QPointF(center_x - scale_factor * x_offset, center_y - width)

   << QPointF(center_x - width, center_y - scale_factor * y_offset)
   << QPointF(center_x + width, center_y - scale_factor * y_offset)

   << QPointF(center_x + scale_factor * x_offset, center_y - width)
   << QPointF(center_x + scale_factor * x_offset, center_y + width)

   << QPointF(center_x + width, center_y + scale_factor * y_offset)
   << QPointF(center_x - width, center_y + scale_factor * y_offset)
      ;

}


void Annotation_Symbols_Panel::construct_deco_plus(QPolygonF& poly, float center_x, float center_y,
  float scale_factor, float offset, float width, float deco_offset)
{
 poly
   << QPointF(center_x - scale_factor * offset, center_y - scale_factor * width)
   << QPointF(center_x - scale_factor * deco_offset, center_y - scale_factor * width)
   << QPointF(center_x - scale_factor * width, center_y - scale_factor * deco_offset)

   << QPointF(center_x - scale_factor * width, center_y - scale_factor * offset)
   << QPointF(center_x + scale_factor * width, center_y - scale_factor * offset)

   << QPointF(center_x + scale_factor * width, center_y - scale_factor * deco_offset)
   << QPointF(center_x + scale_factor * deco_offset, center_y - scale_factor * width)
   << QPointF(center_x + scale_factor * offset, center_y - scale_factor * width)


   << QPointF(center_x + scale_factor * offset, center_y + scale_factor * width)
   << QPointF(center_x + scale_factor * deco_offset, center_y + scale_factor * width)
   << QPointF(center_x + scale_factor * width, center_y + scale_factor * deco_offset)


   << QPointF(center_x + scale_factor * width, center_y + scale_factor * width)
   << QPointF(center_x + scale_factor * width, center_y + scale_factor * offset)

   << QPointF(center_x - scale_factor * width, center_y + scale_factor * offset)
   << QPointF(center_x - scale_factor * width, center_y + scale_factor * deco_offset)
   << QPointF(center_x - scale_factor * deco_offset, center_y + scale_factor * width)

   << QPointF(center_x - scale_factor * offset, center_y + scale_factor * width)
   << QPointF(center_x - scale_factor * offset, center_y - scale_factor * width)
      ;

}


void Annotation_Symbols_Panel::construct_plus(QPolygonF& poly, float center_x, float center_y,
  float scale_factor, float offset, float width)
{
 poly
   << QPointF(center_x - scale_factor * offset, center_y - scale_factor * width)
   << QPointF(center_x - scale_factor * width, center_y - scale_factor * width)

   << QPointF(center_x - scale_factor * width, center_y - scale_factor * offset)
   << QPointF(center_x + scale_factor * width, center_y - scale_factor * offset)

   << QPointF(center_x + scale_factor * width, center_y - scale_factor * width)
   << QPointF(center_x + scale_factor * offset, center_y - scale_factor * width)

   << QPointF(center_x + scale_factor * offset, center_y + scale_factor * width)
   << QPointF(center_x + scale_factor * width, center_y + scale_factor * width)

   << QPointF(center_x + scale_factor * width, center_y + scale_factor * width)
   << QPointF(center_x + scale_factor * width, center_y + scale_factor * offset)

   << QPointF(center_x - scale_factor * width, center_y + scale_factor * offset)
   << QPointF(center_x - scale_factor * width, center_y + scale_factor * width)

   << QPointF(center_x - scale_factor * offset, center_y + scale_factor * width)
   << QPointF(center_x - scale_factor * offset, center_y - scale_factor * width)
      ;

}


void Annotation_Symbols_Panel::construct_triangle_up(QPolygonF& poly, float center_x, float center_y,
  float scale_factor, float width, float height, float y_offset)
{
 poly
   << QPointF(center_x - scale_factor * width/2, center_y + scale_factor * y_offset)
   << QPointF(center_x + scale_factor * width/2, center_y + scale_factor * y_offset)
   << QPointF(center_x, center_y - scale_factor * height);

}


void Annotation_Symbols_Panel::construct_triangle_down(QPolygonF& poly, float center_x, float center_y,
  float scale_factor, float width, float height, float y_offset)
{
 poly
   << QPointF(center_x - scale_factor * width/2, center_y - scale_factor * height)
   << QPointF(center_x + scale_factor * width/2, center_y - scale_factor * height)
   << QPointF(center_x, center_y + scale_factor * y_offset);

}



void Annotation_Symbols_Panel::add_graphics_button_text_and_line(QLabel* label)
{
 main_layout_->addWidget(label);
 QFrame* line = new QFrame(this);
 line->setGeometry(QRect(320, 150, 118, 3));
 line->setFrameShape(QFrame::HLine);
 line->setFrameShadow(QFrame::Raised);
 main_layout_->addWidget(line);
 line->setStyleSheet("QFrame{background:rgba(255,200,200,0.7);}");

 QFont f = label->font();
 f.setPointSize(10);
 label->setFont(f);
 label->setStyleSheet("QLabel{color:darkslateblue;font-weight:900}");

 main_layout_->addStretch();

}
