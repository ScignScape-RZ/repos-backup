

//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)


#ifndef ANNOTATION_SYMBOLS_PANEL__H
#define ANNOTATION_SYMBOLS_PANEL__H

#include <QObject>

#include <QMetaType>

#include <QList>
#include <QGraphicsScene>
#include <QPoint>

#include <QDialog>

#include <QFrame>


#include "accessors.h"
#include "qsns.h"


class QDialogButtonBox;
class QLabel;
class QLineEdit;
class QTabWidget;
class QTextEdit;
class QFrame;
class QHBoxLayout;
class QVBoxLayout;
class QSlider;
class QPlainTextEdit;
class QBoxLayout;
class QButtonGroup;
class QGroupBox;
class QScrollArea;
class QGridLayout;

class ScignStage_Image_Tile;

QSNS_(ScignStage)
//?namespace QScign { namespace ScignStage {


class ScignStage_Clickable_Label;


class Annotation_Symbols_Panel : public QFrame
{
 Q_OBJECT

 QVBoxLayout* main_layout_;

 QGraphicsScene* scratch_scene_;

 QMap<QGraphicsPixmapItem*, QLabel*> labels_to_items_;

 QMap<QPushButton*, QPolygonF> polygons_;


 QPushButton* star_button_;
 QPushButton* ellipse_button_;
 QPushButton* diamond_button_;
 QPushButton* plus_button_;
 QPushButton* octagon_button_;
 QPushButton* vertical_octagon_button_;
 QPushButton* triangle_down_button_;
 QPushButton* triangle_up_button_;

 QLabel* star_label_;
 QLabel* ellipse_label_;
 QLabel* diamond_label_;
 QLabel* plus_label_;
 QLabel* octagon_label_;
 QLabel* vertical_octagon_label_;
 QLabel* triangle_down_label_;
 QLabel* triangle_up_label_;


protected:

 void render_to_button(QPushButton* btn, QPolygonF& poly);

 void render_to_button(QPushButton* btn, QGraphicsPixmapItem* item,
   QGraphicsPixmapItem* scratch_item, QBoxLayout* layout, qreal x_offset, qreal y_offset,
   qreal reenlage_factor, QString text, qreal rotate = 0);

 static void construct_octagon(QPolygonF& poly, float center_x, float center_y,
   float scale_factor, float x_offset, float y_offset, float width);

 static void construct_plus(QPolygonF& poly, float center_x, float center_y,
   float scale_factor, float offset, float width);

 static void construct_deco_plus(QPolygonF& poly, float center_x, float center_y,
   float scale_factor, float offset, float width, float deco_offset);

 static void construct_triangle_down(QPolygonF& poly, float center_x, float center_y,
   float scale_factor, float width, float height, float y_offset);

 static void construct_triangle_up(QPolygonF& poly, float center_x, float center_y,
   float scale_factor, float width, float height, float y_offset);


 void horizontal_flip_transform(QGraphicsPixmapItem* item, int x_offset = 0);
 void horizontal_flip_transform_alt(QGraphicsPixmapItem* item, int x_offset = 0);
 void vertical_flip_transform_alt(QGraphicsPixmapItem* item, int y_offset = 0);

 void add_graphics_button_text_and_line(QLabel* label);



public:


 Annotation_Symbols_Panel(QWidget* parent = nullptr);

 ~Annotation_Symbols_Panel();



//?Q_SIGNALS:


//?public Q_SLOTS:


};

_QSNS(ScignStage)


#endif  // ANNOTATION_SYMBOLS_PANEL__H




