
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)


#include "description-panel.h"

#include <QVBoxLayout>

#include <QPushButton>
#include <QPainter>
#include <QLabel>
#include <QGraphicsPixmapItem>
#include <QDebug>
#include <QTabWidget>

#include <QWebEngineView>


USING_QSNS(ScignStage)


Description_Panel::Description_Panel(QWidget *parent)
  :  QFrame(parent)
{
 main_layout_ = new QVBoxLayout;

 main_notebook_ = new QTabWidget(this);

 description_view_ = new QWebEngineView;

 main_notebook_->addTab(description_view_, "Description");

 description_view_->load(QUrl("https://collection.cooperhewitt.org/objects/18210637/"));

 main_layout_->addWidget(main_notebook_);

 main_layout_->addStretch();

 setLayout(main_layout_);
}


Description_Panel::~Description_Panel()
{

}

