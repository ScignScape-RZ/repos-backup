
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)


#ifndef FORE_GEOMETRIC_2D_PANEL__H
#define FORE_GEOMETRIC_2D_PANEL__H

#include <QObject>

#include <QMetaType>

#include <QList>
#include <QGraphicsScene>
#include <QPoint>

#include <QDialog>

#include <QFrame>



#include "accessors.h"
#include "qsns.h"


class QDialogButtonBox;
class QLabel;
class QLineEdit;
class QTabWidget;
class QTextEdit;
class QFrame;
class QHBoxLayout;
class QVBoxLayout;
class QSlider;
class QPlainTextEdit;
class QBoxLayout;
class QButtonGroup;
class QGroupBox;
class QScrollArea;
class QGridLayout;
class QWebEngineView;


class ScignStage_Clickable_Label;
class ScignStage_Image_Tile;

QSNS_(ScignStage)
//?namespace QScign { namespace ScignStage {



class Fore_Geometric2D_Panel : public QFrame
{
 Q_OBJECT

 QVBoxLayout* main_layout_;

 QTabWidget* main_notebook_;

 QFrame* main_scene_frame_;

 QGraphicsPixmapItem* main_pixmap_item_;

 QGraphicsScene* main_scene_;
 QGraphicsView* main_view_;

 QWebEngineView* instructions_view_;

 QHBoxLayout* main_scene_layout_;

 QMap<QString, ScignStage_Image_Tile*>* current_tile_map_;


public:

 ACCESSORS(QTabWidget* ,main_notebook)


 Fore_Geometric2D_Panel(QString initial_image_file, QWidget* parent = nullptr);

 ~Fore_Geometric2D_Panel();

 void open_file(QString path);


//Q_SIGNALS:
// void canceled(QDialog*);
// void accepted(QDialog*);

public Q_SLOTS:

 void zoom_in();
 void zoom_out();
 void change_scale_ratio(qreal ratio);

};

_QSNS(ScignStage)


#endif  // FORE_GEOMETRIC_2D_PANEL__H


