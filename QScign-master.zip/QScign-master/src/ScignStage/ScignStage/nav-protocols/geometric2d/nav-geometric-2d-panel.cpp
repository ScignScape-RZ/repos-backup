
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)



#include "nav-geometric-2d-panel.h"

#include "styles.h"

#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QSlider>
#include <QButtonGroup>
#include <QGroupBox>

USING_QSNS(ScignStage)

NAV_Geometric2D_Panel::NAV_Geometric2D_Panel(QWidget* parent)
  :  QFrame(parent), old_zoom_slider_value_(1)
{
 main_layout_ = new QVBoxLayout;
 navigation_layout_ = new QHBoxLayout;

 zoom_row_column_layout_ = new QVBoxLayout;
 row_column_layout_ = new QHBoxLayout;

 row_label_ = new QLabel("Row:", this);
 row_line_edit_ = new QLineEdit(this);
 row_line_edit_->setPlaceholderText("?");
 row_line_edit_->setMaximumWidth(30);

 column_label_ = new QLabel("Column:", this);
 column_line_edit_ = new QLineEdit(this);
 column_line_edit_->setPlaceholderText("?");
 column_line_edit_->setMaximumWidth(30);

// //  to be moved to WSI ...
// abnormality_label_ = new QLabel("Abnormality:", this);
// abnormality_line_edit_ = new QLineEdit(this);
// abnormality_line_edit_->setPlaceholderText("?");
// abnormality_line_edit_->setMaximumWidth(30);

 row_column_layout_->addWidget(row_label_);
 row_column_layout_->addWidget(row_line_edit_);

 row_column_layout_->addWidget(column_label_);
 row_column_layout_->addWidget(column_line_edit_);

// row_column_layout_->addWidget(abnormality_label_);
// row_column_layout_->addWidget(abnormality_line_edit_);

 navigation_layout_ = new QHBoxLayout;
 sort_series_layout_ = new QVBoxLayout;

 zoom_row_column_layout_ = new QVBoxLayout;

 zoom_layout_ = new QHBoxLayout;

 zoom_row_column_layout_->addLayout(row_column_layout_);

// //  more WSI ...
// button_sort_series_label_ = new QLabel("Sort by: ", this);

// button_sort_series_geometric_ = new QPushButton("Geometric", this);
// button_sort_series_abnormal_ = new QPushButton("Abnormality", this);

// sort_series_button_group_ = new QButtonGroup(this);

// sort_series_button_group_->setExclusive(true);

// sort_series_button_group_->addButton(button_sort_series_geometric_);
// sort_series_button_group_->addButton(button_sort_series_abnormal_);

// button_sort_series_geometric_->setStyleSheet(toggle_button_style_sheet_());
// button_sort_series_abnormal_->setStyleSheet(toggle_button_style_sheet_());

// button_sort_series_geometric_->setCheckable(true);
// button_sort_series_geometric_->setChecked(true);

// button_sort_series_abnormal_->setCheckable(true);
// button_sort_series_abnormal_->setChecked(false);

// sort_series_layout_->addWidget(button_sort_series_label_);
// sort_series_layout_->addWidget(button_sort_series_geometric_);
// sort_series_layout_->addWidget(button_sort_series_abnormal_);

// navigation_layout_->addLayout(sort_series_layout_);

// navigation_layout_->addStretch();


 tile_up_button_ = new QPushButton(this);
 tile_down_button_ = new QPushButton(this);
 tile_left_button_ = new QPushButton(this);
 tile_right_button_ = new QPushButton(this);
 tile_previous_button_ = new QPushButton(this);
 tile_next_button_ = new QPushButton(this);


 tile_up_button_->setIcon(QIcon(DEFAULT_ICON_FOLDER "/Human-go-up.svg"));
 tile_down_button_->setIcon(QIcon(DEFAULT_ICON_FOLDER "/Human-go-down.svg"));

 tile_left_button_->setIcon(QIcon(DEFAULT_ICON_FOLDER "/Human-go-previous.svg"));
 tile_right_button_->setIcon(QIcon(DEFAULT_ICON_FOLDER "/Human-go-next.svg"));

 tile_previous_button_->setIcon(QIcon(DEFAULT_ICON_FOLDER "/Gtk-go-up.svg"));
 tile_next_button_->setIcon(QIcon(DEFAULT_ICON_FOLDER "/Gtk-go-down.svg"));

 connect(tile_up_button_, SIGNAL(clicked()),
   this, SIGNAL(geometric_up_requested()));

 connect(tile_down_button_, SIGNAL(clicked()),
   this, SIGNAL(geometric_down_requested()));

 connect(tile_left_button_, SIGNAL(clicked()),
   this, SIGNAL(geometric_left_requested()));

 connect(tile_right_button_, SIGNAL(clicked()),
   this, SIGNAL(geometric_right_requested()));

 connect(tile_previous_button_, SIGNAL(clicked()),
   this, SIGNAL(series_previous_requested()));

 connect(tile_next_button_, SIGNAL(clicked()),
   this, SIGNAL(series_next_requested()));


 navigation_buttons_previous_next_layout_ = new QVBoxLayout;

 navigation_buttons_previous_next_layout_->addWidget(tile_previous_button_);
 navigation_buttons_previous_next_layout_->addWidget(tile_next_button_);


 navigation_buttons_layout_ = new QGridLayout;

 navigation_buttons_layout_->addWidget(tile_up_button_, 0, 1);
 navigation_buttons_layout_->addWidget(tile_left_button_, 1, 0);
 navigation_buttons_layout_->addWidget(tile_right_button_, 1, 2);
 navigation_buttons_layout_->addWidget(tile_down_button_, 2, 1);

 navigation_layout_->addLayout(navigation_buttons_layout_);

 navigation_layout_->addStretch();

 navigation_layout_->addLayout(navigation_buttons_previous_next_layout_);

 navigation_layout_->addStretch();

 QLabel* zoom_label = new QLabel("Image Zoom:", this);

 zoom_layout_->addWidget(zoom_label);

 zoom_slider_ = new QSlider(Qt::Horizontal, this);


 connect(zoom_slider_, SIGNAL(valueChanged(int)), this,
   SLOT(zoom_slider_value_changed(int)));



 QString s1 = QString("%1").arg(QChar(5184));
 zoom_in_button_ = new QPushButton(s1, this);
 zoom_in_button_->setStyleSheet("QPushButton{font-size: 12pt;"
                                "font-weight: bold;"
                                "color: brown;}");
// zoom_in_button_->setFont(zif);
 zoom_in_button_->setMaximumWidth(25);
 zoom_in_button_->setMaximumHeight(15);


 QString s2 = QString("%1").arg(QChar(5189));
 zoom_out_button_ = new QPushButton(s2, this);
 zoom_out_button_->setStyleSheet("QPushButton{font-size: 12pt;"
                                "font-weight: bold; padding:0px; "
                                "color: brown;}");
 zoom_out_button_->setMaximumWidth(25);
 zoom_out_button_->setMaximumHeight(15);

 connect(zoom_in_button_, SIGNAL(pressed()), this, SIGNAL(zoom_in_requested()));
 connect(zoom_out_button_, SIGNAL(pressed()), this, SIGNAL(zoom_out_requested()));

 zoom_layout_->addStretch();

 zoom_layout_->addWidget(zoom_slider_);
 zoom_layout_->addItem(new QSpacerItem(15, 1));

 zoom_layout_->addWidget(zoom_out_button_);
 zoom_layout_->addItem(new QSpacerItem(5, 1));

 zoom_layout_->addWidget(zoom_in_button_);

 zoom_layout_->addItem(new QSpacerItem(16, 1));

 zoom_layout_->addStretch();

 zoom_row_column_layout_->addLayout(zoom_layout_);


 navigation_layout_->addLayout(zoom_row_column_layout_);

 navigation_layout_->addStretch();

 annotations_show_hide_button_group_ = new QButtonGroup(this);


 annotations_show_hide_layout_ = new QVBoxLayout;

 annotations_show_hide_label_ = new QLabel("Annotations...", this);

 annotations_show_button_ = new QPushButton("Show", this);
 annotations_hide_button_ = new QPushButton("Hide", this);

 annotations_show_button_->setStyleSheet(colorful_toggle_button_quiet_style_sheet_());
 annotations_hide_button_->setStyleSheet(colorful_toggle_button_quiet_style_sheet_());

 annotations_show_button_->setCheckable(true);
 annotations_show_button_->setChecked(true);

 annotations_hide_button_->setCheckable(true);
 annotations_hide_button_->setChecked(false);

 annotations_show_hide_button_group_->addButton(annotations_show_button_);
 annotations_show_hide_button_group_->addButton(annotations_hide_button_);
 annotations_show_hide_button_group_->setExclusive(true);

 annotations_show_hide_layout_->addWidget(annotations_show_hide_label_);
 annotations_show_hide_layout_->addWidget(annotations_show_button_);
 annotations_show_hide_layout_->addWidget(annotations_hide_button_);

 navigation_layout_->addLayout(annotations_show_hide_layout_);

 main_layout_->addLayout(navigation_layout_);

// QGroupBox* mode_group_box_;

// QHBoxLayout* combined_mode_button_layout_;
// QButtonGroup* mode_button_group_;
// QPushButton* mode_zoom_button_;
// QPushButton* mode_pan_button_;
// QPushButton* mode_slide_button_;

// QPushButton* current_mode_button_;

// QGroupBox* annotations_mode_group_box_;
// QButtonGroup* annotations_mode_button_group_;
// QHBoxLayout* annotations_mode_button_layout_;
// QPushButton* annotations_mode_pan_button_;
// QPushButton* annotations_mode_rotate_button_;
// QPushButton* annotations_mode_zoom_button_;



 combined_mode_button_layout_ = new QHBoxLayout;
 mode_button_layout_ = new QHBoxLayout;
 annotations_mode_button_layout_ = new QHBoxLayout;

 mode_group_box_ = new QGroupBox("Image and Group Transforms ...", this);
 mode_button_group_ = new QButtonGroup(this);
 mode_zoom_button_ = new QPushButton("Zoom", this);
 mode_zoom_button_->setCheckable(true);
 mode_pan_button_ = new QPushButton("Pan", this);
 mode_pan_button_->setCheckable(true);
 mode_slide_button_ = new QPushButton("Group Transform", this);
 mode_slide_button_->setCheckable(true);

 mode_zoom_button_->setChecked(true);
 current_mode_button_ = mode_zoom_button_;

 mode_button_group_->addButton(mode_zoom_button_);
 mode_button_group_->addButton(mode_pan_button_);
 mode_button_group_->addButton(mode_slide_button_);

 mode_button_layout_->addWidget(mode_pan_button_);
 mode_button_layout_->addWidget(mode_zoom_button_);
 mode_button_layout_->addWidget(mode_slide_button_);
 mode_group_box_->setLayout(mode_button_layout_);


 combined_mode_button_layout_->addWidget(mode_group_box_);

 annotations_mode_group_box_ = new QGroupBox("Single Annotation Transforms ...", this);
 annotations_mode_button_group_ = new QButtonGroup(this);

 annotations_mode_pan_button_ = new QPushButton("Pan", this);
 annotations_mode_pan_button_->setCheckable(true);
 annotations_mode_rotate_button_ = new QPushButton("Rotate", this);
 annotations_mode_rotate_button_->setCheckable(true);
 annotations_mode_zoom_button_ = new QPushButton("Zoom", this);
 annotations_mode_zoom_button_->setCheckable(true);

 annotations_mode_pan_button_->setChecked(true);

 annotations_mode_button_group_->addButton(annotations_mode_pan_button_);
 annotations_mode_button_group_->addButton(annotations_mode_rotate_button_);
 annotations_mode_button_group_->addButton(annotations_mode_zoom_button_);

 annotations_mode_button_layout_->addWidget(annotations_mode_pan_button_);
 annotations_mode_button_layout_->addWidget(annotations_mode_rotate_button_);
 annotations_mode_button_layout_->addWidget(annotations_mode_zoom_button_);
 annotations_mode_group_box_->setLayout(annotations_mode_button_layout_);

 mode_zoom_button_->setStyleSheet(colorful_toggle_button_style_sheet_());
 mode_pan_button_->setStyleSheet(colorful_toggle_button_style_sheet_());
 mode_slide_button_->setStyleSheet(colorful_toggle_button_style_sheet_());
 annotations_mode_zoom_button_->setStyleSheet(colorful_toggle_button_style_sheet_());
 annotations_mode_pan_button_->setStyleSheet(colorful_toggle_button_style_sheet_());
 annotations_mode_rotate_button_->setStyleSheet(colorful_toggle_button_style_sheet_());

 combined_mode_button_layout_->addWidget(annotations_mode_group_box_);


 main_layout_->addLayout(combined_mode_button_layout_);



 setLayout(main_layout_);


}

NAV_Geometric2D_Panel::~NAV_Geometric2D_Panel()
{

}

void NAV_Geometric2D_Panel::set_row_text(int r)
{
 row_line_edit_->setText(QString::number(r));
}

void NAV_Geometric2D_Panel::set_column_text(int c)
{
 column_line_edit_->setText(QString::number(c));
}

void NAV_Geometric2D_Panel::zoom_slider_value_changed(int val)
{
 int diff = val - old_zoom_slider_value_;
 old_zoom_slider_value_ = val;
 int max = zoom_slider_->maximum();
 //int current = val;

 qreal ratio = 1 + ((qreal)diff)/((qreal)max);

 //?
 //main_pixmap_item_->setScale(main_pixmap_item_->scale() * ratio);

 Q_EMIT(scale_ratio_change_requested(ratio));

}

void NAV_Geometric2D_Panel::set_row_and_column_text(int r, int c)
{
 set_row_text(r);
 set_column_text(c);
}


