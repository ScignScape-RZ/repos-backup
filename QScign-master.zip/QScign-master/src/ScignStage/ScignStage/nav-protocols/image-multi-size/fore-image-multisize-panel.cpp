
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)



#include "fore-image-multisize-panel.h"

#include <QTabWidget>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QGraphicsPixmapItem>
#include <QHBoxLayout>
#include <QWebEngineView>




USING_QSNS(ScignStage)


Fore_Image_Multisize_Panel::Fore_Image_Multisize_Panel(QWidget* parent)
  :  QFrame(parent)
{
 main_notebook_ = new QTabWidget(this);

 main_scene_ = new QGraphicsScene(this);
 main_view_ = new QGraphicsView(this);

 main_view_->setScene(main_scene_);

 main_view_->setContextMenuPolicy(Qt::CustomContextMenu);
 connect(main_view_, SIGNAL(customContextMenuRequested(const QPoint&)),
   this, SLOT(show_main_view_context_menu(const QPoint&)));


 main_pixmap_item_ = new QGraphicsPixmapItem(); //QPixmap::fromImage(QImage(initial_image_file)));

 main_scene_->addItem(main_pixmap_item_);

 main_pixmap_item_->setFlag(QGraphicsItem::ItemIsMovable);

 main_scene_layout_ = new QHBoxLayout;

 main_scene_layout_->addWidget(main_view_);


 main_scene_frame_ = new QFrame(this);
 main_scene_frame_->setLayout(main_scene_layout_);

 main_notebook_->addTab(main_scene_frame_, "View");

 instructions_view_ = new QWebEngineView(this);
 main_notebook_->addTab(instructions_view_, "Instructions");


}


Fore_Image_Multisize_Panel::~Fore_Image_Multisize_Panel()
{

}

void Fore_Image_Multisize_Panel::open_file(QString path)
{
 main_pixmap_item_->setPixmap(QPixmap::fromImage(QImage(path)));
}

void Fore_Image_Multisize_Panel::zoom_in()
{
 main_pixmap_item_->setScale(main_pixmap_item_->scale() + 0.125);
}

void Fore_Image_Multisize_Panel::zoom_out()
{
 main_pixmap_item_->setScale(main_pixmap_item_->scale() - 0.125);
}

void Fore_Image_Multisize_Panel::change_scale_ratio(qreal ratio)
{
 main_pixmap_item_->setScale(main_pixmap_item_->scale() * ratio);
}
