
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)



#include "series-image-multisize-panel.h"

#include "ScignStage/subwindows/scignstage-image-tile.h"
#include "ScignStage/subwindows/scignstage-clickable-label.h"

#include <QRegularExpression>
#include <QDebug>
#include <QRegularExpressionMatch>
#include <QDirIterator>
#include <QPainter>

#include <QVBoxLayout>

USING_QSNS(ScignStage)


Series_Image_Multisize_Panel::Series_Image_Multisize_Panel(QWidget *parent)
 :  QFrame(parent),
   current_clickable_label_(nullptr),
   current_tile_(nullptr),
   current_tile_map_(nullptr)
{
 main_layout_ = new QVBoxLayout;

 lbl_1_ = new ScignStage_Clickable_Label(this);
 lbl_2_ = new ScignStage_Clickable_Label(this);

 lbl_1_->setText("Image 1 \n...");
 lbl_2_->setText("Image 2 \n...");


 main_layout_->addWidget(lbl_1_);
 main_layout_->addWidget(lbl_2_);
 main_layout_->addStretch();

 main_layout_->setSizeConstraint(QLayout::SetMinimumSize);

 setLayout(main_layout_);
}


Series_Image_Multisize_Panel::~Series_Image_Multisize_Panel()
{

}

// //   Currently implemented only in the parent ...
void Series_Image_Multisize_Panel::open_folder(QString path)
{

}

void Series_Image_Multisize_Panel::display_tiles(QList<Multisize_Image_Tile_Info>& infos)
{
 lbl_1_->setVisible(false);
 lbl_2_->setVisible(false);

 ScignStage_Image_Tile* last_tile = nullptr;

 // //   Allows the previous map to be kept in memory, if appropriate.
  //     Otherwise it should certainly be deleted and cleaned up ...
 current_tile_map_ = new QMap<QString, ScignStage_Image_Tile*>();

 for(const Multisize_Image_Tile_Info miti : infos)
 {
  ScignStage_Image_Tile* tile = new ScignStage_Image_Tile(miti.name());

  tile->set_dimensional_annotation(0, miti.group_number());
  tile->set_dimensional_annotation(1, miti.size_code());

  current_tile_map_->insert(miti.name(), tile);

  if(last_tile)
  {
   last_tile->set_series_next(tile);
   tile->set_series_previous(last_tile);
  }
  last_tile = tile;


  QImage qim = QImage(miti.absolute_path());

  qim = qim.scaledToWidth(30);

  ScignStage_Clickable_Label* lbl = new ScignStage_Clickable_Label(this); //QLabel(qfi.fileName(), this);

  lbl->setUserData(1, reinterpret_cast<QObjectUserData*>(tile));
  tile->set_associated_qobject(lbl);

  QString absolute_path = miti.absolute_path();

  connect(lbl, &ScignStage_Clickable_Label::clicked,
          [absolute_path, lbl, tile, this]
  {
   if(current_clickable_label_)
   {
    QImage qim = QImage(absolute_path);
    qim = qim.scaledToWidth(30);
    current_clickable_label_->setPixmap(QPixmap::fromImage(qim));
   }

   current_clickable_label_ = lbl;

   if(lbl->userData(1))
   {
    current_tile_ = reinterpret_cast<ScignStage_Image_Tile*>(lbl->userData(1));

    int r = current_tile_->get_dimensional_annotation(0);
    int c = current_tile_->get_dimensional_annotation(1);
    if( (r >= 0) && (c >= 0) )
    {
     Q_EMIT(navigated_from_series(r, c));
    }

   }

   QPixmap px = *lbl->pixmap();


   QPainter p(&px);
   QPen pen = QPen(QColor::fromRgb(255, 0, 0, 100));
   pen.setWidth(6);
   p.setPen(pen);

   QBrush qbr = QBrush(QColor::fromRgb(255, 0, 0, 10));
   p.setBrush(qbr);

   p.drawRect(3, 3, px.width()-6, px.height()-6);
   p.end();
   lbl->setPixmap(px);

   QString path = lbl->path;


   Q_EMIT(open_file_requested(path));

  });

  lbl->path = absolute_path;
  lbl->setPixmap(QPixmap::fromImage(qim));
  //vb->addWidget(lbl);
  main_layout_->addWidget(lbl);
  //graphics_series_layout_->addWidget(lbl);
  //qDebug()<<dirIt.filePath();
 }

}

ScignStage_Image_Tile* Series_Image_Multisize_Panel::find_tile_by_name(QString name)
{
 if(current_tile_map_)
 {
  return current_tile_map_->value(name);
 }
 return nullptr;
}


