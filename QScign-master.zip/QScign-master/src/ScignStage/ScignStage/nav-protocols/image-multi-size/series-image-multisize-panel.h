
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)



#ifndef SERIES_IMAGE_MULTISIZE__H
#define SERIES_IMAGE_MULTISIZE__H

#include <QObject>

#include <QMetaType>

#include <QList>
#include <QGraphicsScene>
#include <QPoint>

#include <QDialog>

#include <QFrame>

#include "ScignStage/subwindows/scignstage-clickable-label.h"
#include "ScignStage/structures/geometric-image-tile-info.h"

#include "ScignStage/structures/multisize-image-tile-info.h"



#include "accessors.h"
#include "qsns.h"


class QDialogButtonBox;
class QLabel;
class QLineEdit;
class QTabWidget;
class QTextEdit;
class QFrame;
class QHBoxLayout;
class QVBoxLayout;
class QSlider;
class QPlainTextEdit;
class QBoxLayout;
class QButtonGroup;
class QGroupBox;
class QScrollArea;
class QGridLayout;



QSNS_(ScignStage)
//?namespace QScign { namespace ScignStage {


class ScignStage_Clickable_Label;
class ScignStage_Image_Tile;


class Series_Image_Multisize_Panel : public QFrame
{
 Q_OBJECT

//?
// QMap<QGraphicsPixmapItem*, QVector<QGraphicsItem*> > current_seli_specific_items_;
// QMap<QGraphicsPixmapItem*, QString> seli_names_;
// QMap<QString, QGraphicsPixmapItem*> inverse_seli_names_;

 //?QMap<QString, QPolygonF> polys_by_name_;

//? QLabel* current_seli_label_;
//? QMap<QGraphicsPixmapItem*, QLabel*> labels_to_items_;


 QVBoxLayout* main_layout_;

 ScignStage_Clickable_Label* lbl_1_;
 ScignStage_Clickable_Label* lbl_2_;

 QMap<QString, ScignStage_Image_Tile*>* current_tile_map_;

 ScignStage_Clickable_Label* current_clickable_label_;
 ScignStage_Image_Tile* current_tile_;

 //Series_Geometric2D_Panel*


public:


 Series_Image_Multisize_Panel(QWidget* parent = nullptr);

 ACCESSORS(ScignStage_Clickable_Label* ,current_clickable_label)
 ACCESSORS(ScignStage_Image_Tile* ,current_tile)


 ~Series_Image_Multisize_Panel();

 ScignStage_Image_Tile* find_tile_by_name(QString name);

 void open_folder(QString path);

 void display_tiles(QList<Multisize_Image_Tile_Info>& infos);


Q_SIGNALS:

 void open_file_requested(QString path);

 void navigated_from_series(int r, int c);

//?public Q_SLOTS:


};

_QSNS(ScignStage)


#endif  // SERIES_IMAGE_MULTISIZE__H



