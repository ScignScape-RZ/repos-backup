
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)



#ifndef SCIGNSTAGE_NAVIGATION_PROTOCOL_DIALOG__H
#define SCIGNSTAGE_NAVIGATION_PROTOCOL_DIALOG__H

#include <QObject>

#include <QMetaType>

#include <QList>
#include <QGraphicsScene>
#include <QPoint>

#include <QDialog>

//?#include "MoND-UI/controls/single-edit-combo-box.h"

#include "accessors.h"
#include "qsns.h"


class QDialogButtonBox;
class QLabel;
class QLineEdit;
class QTabWidget;
class QPlainTextEdit;
class QTextEdit;
class QFrame;
class QHBoxLayout;
class QVBoxLayout;
class QGridLayout;
class QSlider;
class QLineEdit;
class QBoxLayout;
class QButtonGroup;
class QGroupBox;
class QFormLayout;
class QComboBox;
class QDateEdit;
class QScrollArea;

QSNS_(ScignStage)
//?namespace QScign { namespace ScignStage {

class ScignStage_Navigation_Protocol_Dialog : public QDialog
{

 Q_OBJECT

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QPushButton* button_proceed_;


 QVBoxLayout* main_layout_;

 QTabWidget* main_tab_widget_;
 QFrame* main_frame_;
 QVBoxLayout* main_frame_layout_;

 QPlainTextEdit* xml_text_edit_;
 QPlainTextEdit* ss_text_edit_;
 QPlainTextEdit* cl_text_edit_;


 QFormLayout* info_form_layout_;

 QLineEdit* name_line_edit_;
 QLineEdit* xml_file_line_edit_;
 QLineEdit* ss_file_line_edit_;

 QGroupBox* concepts_group_box_;
 QFormLayout* concepts_form_layout_;


public:


 ScignStage_Navigation_Protocol_Dialog(QWidget* parent = nullptr);

 ~ScignStage_Navigation_Protocol_Dialog();


Q_SIGNALS:

 void canceled(QDialog*);
 void accepted(QDialog*);


public Q_SLOTS:

 void accept();
 void cancel();

};

_QSNS(ScignStage)


#endif  // SCIGNSTAGE_NAVIGATION_PROTOCOL_DIALOG__H
