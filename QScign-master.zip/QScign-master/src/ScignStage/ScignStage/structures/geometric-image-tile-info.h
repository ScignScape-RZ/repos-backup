
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)



#ifndef GEOMETRIC_IMAGE_TILE_INFO__H
#define GEOMETRIC_IMAGE_TILE_INFO__H


#include "accessors.h"

#include <QPen>
#include <QBrush>
#include <QString>

#include <QVector>

class QObject;


class Geometic_Image_Tile_Info
{
 QString name_;
 QString absolute_path_;

 int series_row_;
 int series_column_;


public:


 Geometic_Image_Tile_Info(QString name, QString absolute_path);

 ACCESSORS(QString ,name)
 ACCESSORS(QString ,absolute_path)

 ACCESSORS(int ,series_row)
 ACCESSORS(int ,series_column)


};

#endif  //  GEOMETRIC_IMAGE_TILE_INFO__H
