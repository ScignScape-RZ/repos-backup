
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)



#include "multisize-image-tile-info.h"


Multisize_Image_Tile_Info::Multisize_Image_Tile_Info(QString name, QString absolute_path)
  : name_(name), absolute_path_(absolute_path),
    group_number_(-1), size_code_(-1)
{

}

