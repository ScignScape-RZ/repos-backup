
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)



#ifndef MULTISIZE_IMAGE_TILE_INFO__H
#define MULTISIZE_IMAGE_TILE_INFO__H


#include "accessors.h"

#include <QPen>
#include <QBrush>
#include <QString>

#include <QVector>

class QObject;


class Multisize_Image_Tile_Info
{
 QString name_;
 QString absolute_path_;

 int group_number_;
 int size_code_;


public:


 Multisize_Image_Tile_Info(QString name, QString absolute_path);

 ACCESSORS(QString ,name)
 ACCESSORS(QString ,absolute_path)

 ACCESSORS(int ,group_number)
 ACCESSORS(int ,size_code)


};

#endif  //  GEOMETRIC_IMAGE_TILE_INFO__H
