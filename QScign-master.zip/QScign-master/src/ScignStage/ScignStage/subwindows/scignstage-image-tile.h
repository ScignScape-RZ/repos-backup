
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)


#ifndef SCIGNSTAGE_IMAGE_TILE__H
#define SCIGNSTAGE_IMAGE_TILE__H


#include "accessors.h"
#include "qsns.h"

#include <QPen>
#include <QBrush>
#include <QString>

#include <QVector>

class QObject;


QSNS_(ScignStage)


class ScignStage_Image_Tile
{
 QString local_path_;

 QObject* associated_qobject_;

 QVector<int> dimensional_annotations_;

 ScignStage_Image_Tile* series_previous_;
 ScignStage_Image_Tile* series_next_;

public:


 ScignStage_Image_Tile(QString local_path);

 ACCESSORS(QObject* ,associated_qobject)

 ACCESSORS(ScignStage_Image_Tile* ,series_previous)
 ACCESSORS(ScignStage_Image_Tile* ,series_next)

 void set_dimensional_annotation(int index, int value);
 int get_dimensional_annotation(int index);


};

_QSNS(ScignStage)



#endif  //  SCIGNSTAGE_IMAGE_TILE__H
