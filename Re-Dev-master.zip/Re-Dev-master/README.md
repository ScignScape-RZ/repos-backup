
###   This is an Out of Date project that has been superceded by others from the same Github account.  
 
   However, it may be useful as an example of the basic setup of a ScignScape project using RelaeGraph parsers, dominions, 
   and its recommended file structure 

###



R/E Development Files

Currently this repository contains a demo and "template" files for setting up an "R/Z" or "CharmTorque" project.  R/Z is being developed as the "default" implementation of R/E, which is a language for defining interfaces to data resources, and programming language classes and types, based on principles of "Capability Oriented" Semantics for cybersecurity.  R/E is influenced by the E language though with a different syntax and expanded semantics, prioritizing Semantic Web and "Web 3.0" applications.  R/E provides a layer to code written in a "host language"; currently there are two R/E frameworks under development, one which uses Ruby as a host language, and one (R/Z) using a mixture of Lisp and C++ (specifically, the new C++ Lisp implementation Clasp, developed by Christian Schafmeister).  The foundational data structure, query, and grammar/parsing framework for R/Z can be used for modeling Semantic Web data or any data where Semantic Web style structures (using Ontologies, RDF, Semantic Network Graphs, and so forth), and custom query and interface languages can be designed, either as extensions to R/E or with custom syntax and semantics.  "CharmTorque" refers to the general model for projects using "Relae" Dominions (perhaps based on the rz-relae library, for C++ projects); R/Z projects additionally use the R/Z environment as a host language, with R/E as a query, documentation, and/or scripting language.  

The R/E project also includes developing mathematical and theoretical foundations for language implementation, formal (especially context-sensitive) grammars, static analysis, and cybersecurity; formal semantics are developed to promote code analysis and security verification, using Category Theory and, more specifically, the "Perspector Algebra" approach developed by Michel Biezunski.  The current repository includes a basic template, comprising roughly 50 C++ files as part of a Qt project, for building data models based on Perspector Algebra; there is also an introductory paper which summarizes the basic concepts of Perspector Algebra and of the Category-Theoretic semantics and type system model used for R/E.  More papers will be provided soon as well.    

To build, it is necessary to use a recent (> 5.4) Qt release.  A Qt build system is assumed; the build is straightforward using Qt Creator.  The .pro and .pri files should automatically detect paths (if using "shadow build") -- see the QMake regular expression patterns -- and there are no library dependencies outside of Qt itself.  The foundational distribution includes three projects (rz-relae, rz-relae-template, and rz-relae-demo).  The first is header-only; rz-relae-template is a library; and rz-relae-demo a console application but also uses QFileDialog to select a file, so it does link against Qt widgets.  C++11 compiler support is needed.  The code was developed using Windows and 32-bit MinGW, but should be fully cross-platform (aside from setting the root path, by redefining the CTQ_PROJECT_ROOT__RE_DEV macro).

In addition to the basic "template", this repository will include projects built on top of this foundation, including R/Z as a whole as well as a markup language called NGML, with which the papers and documentation are developed.  Please check back for more information.

R/E is a project of OWASP (the Open Web Application Security Project), led by Nathaniel Christen.  My thanks to the project team members Amy Neustein and Michel Biezunski, and to Bev Corwin for recommending this as an OWASP project. 
