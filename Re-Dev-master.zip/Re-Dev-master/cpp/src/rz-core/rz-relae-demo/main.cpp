
// // // // // // // // // // // // // // // // // // // // // // // // // // // // // //
// PLEASE SEE THE LICENCE IN CTQ_PROJECT_ROOT__RE_DEV/CharmTorque/licence/licence.txt  //
// All files in this project, and CharmTorque, R/E, or R/Z projects linked to it, are  //
// released under the terms of this licence.  All these files are                      //
//  copyright 2015    Nathaniel Christen                                               //
// // // // // // // // // // // // // // // // // // // // // // // // // // // // // //


#define CTQ_PROJECT_NAME "RE_DEV"
#define CTQ_PROJECT_ROOT__RE_DEV "C:/re-dev"
// //  Hand-edit the above path or use this shortcut:
//#define CTQ_PROJECT_ROOT__RE_DEV __FILE__ "../../../../../.."
//     By convention, CharmTorque projects should have a name
//     and root directory; for "official" R/E or R/Z related
//     project distributions and any projects using the same
//     licence, include a CharmTorque directorry with the
//     licence/licence.txt file.


#include "rz-relae-template/kernel/document/rz-relae-template-document.h"
#include "rz-relae-template/output/rz-relae-template-output-p16.h"
#include "rz-relae-template/output/rz-relae-template-output-rtmp.h"

USING_RZNS(Relae_Template)


#define DEFAULT_DIRECTORY CTQ_PROJECT_ROOT__RE_DEV "/rtmp"

#include <QApplication>
#include <QFileDialog>
#include <QDebug>

int main(int argc, char* argv[])
{
 QString document_file;
 {
  QApplication qapp(argc, argv);
  document_file = QFileDialog::getOpenFileName(nullptr,
   "Open Document", DEFAULT_DIRECTORY, "RTMP Document (*.rtmp)");
 }

 if(document_file.isEmpty())
 {
  qDebug() << "No file selected.";
  return 0;
 }

 RTMP_Document doc;
 doc.load_and_parse(document_file);
 RTMP_Output_P16 op16(doc);
 op16.export_p16();
 RTMP_Output_Rtmp ortmp(doc);
 ortmp.export_rtmp();
}
