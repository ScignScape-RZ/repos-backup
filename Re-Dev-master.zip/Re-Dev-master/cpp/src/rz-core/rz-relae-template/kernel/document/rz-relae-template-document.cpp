
#include "rz-relae-template-document.h"

#include "rz-relae/relae-parser.templates.h"
#include "kernel/grammar/rz-relae-template-grammar.h"
#include "kernel/rz-relae-template-root.h"
#include "kernel/graph/rz-relae-template-node.h"
#include "kernel/graph/rz-relae-template-graph.h"
#include "kernel/grammar/rz-relae-template-parser.h"
#include "kernel/grammar/rz-relae-template-graph-build.h"


#include "rzns.h"
USING_RZNS(Relae_Template)


RTMP_Document::RTMP_Document()
 : graph_(nullptr), grammar_(nullptr)
{

}

void RTMP_Document::load_file(QString path)
{
 QFile file(path);
 if(file.open(QFile::ReadOnly | QIODevice::Text))
 {
  raw_text_ = file.readAll();
  local_path_ = path;
 }
}


void RTMP_Document::set_grammar(caon_ptr<RTMP_Grammar> grammar)
{
 if(grammar)
  grammar_ = grammar;
 else
  grammar_ = new RTMP_Grammar();
}

void RTMP_Document::parse()
{
 caon_ptr<RTMP_Root> root = new RTMP_Root();
 caon_ptr<RTMP_Node> node = new RTMP_Node(root);
 graph_ = new RTMP_Graph(node);
 parser_ = new RTMP_Parser(graph_);

 graph_build_ = new RTMP_Graph_Build(*graph_);
 graph_build_->init();

 grammar_->init(*parser_, *graph_, *graph_build_);
 grammar_->compile(*parser_, *graph_, raw_text_);
}

void RTMP_Document::load_and_parse(QString path, caon_ptr<RTMP_Grammar> grammar)
{
 load_file(path);
 set_grammar(grammar);
 parse();
}


RTMP_Document::~RTMP_Document()
{

}

