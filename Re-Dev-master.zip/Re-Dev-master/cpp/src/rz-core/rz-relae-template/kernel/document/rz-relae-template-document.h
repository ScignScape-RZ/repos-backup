
#ifndef RZ_RELAE_TEMPLATE_DOCUMENT__H
#define RZ_RELAE_TEMPLATE_DOCUMENT__H

#include "rz-relae/relae-node-ptr.h"
#include "kernel/rz-relae-template-dominion.h"
#include "kernel/query/rz-relae-template-query.h"
#include "accessors.h"

#include "rzns.h"

RZNS_(Relae_Template)

class RTMP_Parser;
class RTMP_Grammar;
class RTMP_Graph_Build;
class RTMP_Word_Entry_List;


class RTMP_Document
{
 caon_ptr<RTMP_Graph> graph_;
 caon_ptr<RTMP_Parser> parser_;
 caon_ptr<RTMP_Graph_Build> graph_build_;
 caon_ptr<RTMP_Grammar> grammar_;

 QString local_path_;
 QString raw_text_;

public:


 ACCESSORS(QString ,local_path)
 ACCESSORS(QString ,raw_text)
 ACCESSORS(caon_ptr<RTMP_Graph> ,graph)
 ACCESSORS__GET(caon_ptr<RTMP_Grammar> ,grammar)

 RTMP_Document();

 ~RTMP_Document();

 void load_and_parse(QString path, caon_ptr<RTMP_Grammar> grammar = nullptr);
 void load_file(QString path);
 void set_grammar(caon_ptr<RTMP_Grammar> grammar = nullptr);
 void parse();

};

_RZNS(Relae_Template)


#endif
