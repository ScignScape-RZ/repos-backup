

// //  This is a list of connectors (or relations)
//     and their labels.  The DOMINION_CONNECTOR
//     has different definitions depending on
//     where this file is included.

DOMINION_CONNECTOR(L4_Call_Entry, "Lambda-4 Call Entry")
DOMINION_CONNECTOR(L4_Call_Sequence, "Lambda-4 Call Sequence")
DOMINION_CONNECTOR(L4_Cross_Sequence, "Lambda-4 Cross Sequence")
DOMINION_CONNECTOR(L4_Call_Continue, "Lambda-4 Call Continue")
