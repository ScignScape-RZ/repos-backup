
// //  This is a list of relevant types.
//    The DOMINION_TYPE macro has different
//    definitions depending on where
//    this file is included.


#undef DOMINION_OUTER_NAMESPACE
#undef DOMINION_INNER_NAMESPACE

#define DOMINION_NODE_TYPE RTMP_Node

#include "rz-relae/dominion-macros.h"
DOMINION_TYPE(string, QString, String)

#define DOMINION_OUTER_NAMESPACE RZ
#define DOMINION_INNER_NAMESPACE Relae_Template
#include "rz-relae/dominion-macros.h"

DOMINION_TYPE(rtmp_root, RTMP_Root, RTMP_Root)
DOMINION_TYPE(rtmp_token, RTMP_Token, RTMP_Token)
