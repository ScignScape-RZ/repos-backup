
#include "rz-relae-template-frame.h"

#include "kernel/graph/rz-relae-template-node.h"

#include "rzns.h"


USING_RZNS(Relae_Template)

RTMP_Frame::RTMP_Frame()
 : node_frame<RTMP_Dominion>()
{


}

RTMP_Frame& RTMP_Frame::instance()
{
 static RTMP_Frame* the_instance = nullptr;
 if(!the_instance)
  the_instance = new RTMP_Frame;
 return *the_instance;
}
