
#ifndef RZ_RELAE_TEMPLATE_FRAME__H
#define RZ_RELAE_TEMPLATE_FRAME__H

#include "rz-relae/relae-node-ptr.h"
#include "kernel/rz-relae-template-dominion.h"

#include "rzns.h"

RZNS_(Relae_Template)


class RTMP_Frame : public node_frame<RTMP_Dominion>
{
 RTMP_Frame();

public:

 static RTMP_Frame& instance();

};

_RZNS(Relae_Template)

#endif
