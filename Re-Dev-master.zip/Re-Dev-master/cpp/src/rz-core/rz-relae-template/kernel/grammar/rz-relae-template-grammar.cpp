
#include "rz-relae-template-grammar.h"

#include "kernel/grammar/rz-relae-template-parse-context.h"
#include "kernel/grammar/rz-relae-template-graph-build.h"
#include "kernel/grammar/rz-relae-template-parser.h"
#include "rz-relae/relae-parser.templates.h"

#include "rzns.h"

USING_RZNS(Relae_Template)

RTMP_Grammar::RTMP_Grammar()
{
}

void RTMP_Grammar::init(RTMP_Parser& p, RTMP_Graph& g, RTMP_Graph_Build& graph_build)
{
 pre_rule( "script-word", "(?:[^{}()\\[\\]\\s`;,:]|(?:\\w::?\\w))+" );
 pre_rule( "space-to-end-of-line", "[__\\t]* \\n" );
 pre_rule( "end-of-line", "[__\\t\\S]* \\n" );
 pre_rule( "single-space", "[__\\t]" );

 Context l4_context = add_context("l4-context");

 track_context({&l4_context});

 activate(l4_context);

 RTMP_Parse_Context& parse_context = graph_build.parse_context();

 add_rule( flags_none_(parse_context ,inside_multiline_comment),
  l4_context, "l4-multiline-comment",
  " (?: (?<semis> ;; ;* ) (?<hyphens> -- -* ) )"
  ,[&]
 {
  QString semis = p.matched("semis");
  QString hyphens = p.matched("hyphens");
  graph_build.enter_multiline_comment(semis, hyphens);
 });

 add_rule( flags_all_(parse_context ,inside_multiline_comment),
  l4_context, "l4-multiline-comment-leave",
  " (?: (?<dashes> -- -* ) (?<semis> ;; ;* ) )"
  ,[&]
 {
  QString semis = p.matched("semis");
  QString hyphens = p.matched("hyphens");
  graph_build.check_leave_multiline_comment(semis, hyphens);
 });

 add_rule( flags_all_(parse_context ,inside_multiline_comment),
  l4_context, "l4-multiline-comment-characters",
  " [^-]+ | - "
  ,[&]
 {
 });

 add_rule( l4_context, "l4-comment",
  " (?: (?: ;; ) ;* -  ) .end-of-line. "
  ,[&]
 {
 });

 add_rule( flags_all_(parse_context ,inside_string_literal),
  l4_context, "string-literal-escaped-character",
  " (?: \\\\ [\"\\\\] ) "
  ,[&]
 {
  QString m = p.match_text();
  graph_build.string_literal_acc(m[1]);
 });

 add_rule( l4_context, "string-literal-delimiter",
  " \" "
  ,[&]
 {
  graph_build.check_string_literal_delimiter();
 });

 add_rule( flags_all_(parse_context ,inside_string_literal),
  l4_context, "string-literal-characters",
  " [^\"\\\\]+ | [\"\\\\] "
  ,[&]
 {
  QString m = p.match_text();
  graph_build.string_literal_acc(m);
 });

 add_rule( l4_context, "l4-call-entry",
  " \\( "
  ,[&]
 {
  graph_build.call_entry();
 });

 add_rule( l4_context, "l4-call-entry",
  " \\) "
  ,[&]
 {
  graph_build.call_leave();
 });

 add_rule( l4_context, "whitespace",
  " \\s+ "
  ,[&]
 {
  graph_build.check_add_token();
 });

 add_rule( l4_context, "token-acc",
  " . "
  ,[&]
 {
  graph_build.token_acc(p.match_text());
 });

}
