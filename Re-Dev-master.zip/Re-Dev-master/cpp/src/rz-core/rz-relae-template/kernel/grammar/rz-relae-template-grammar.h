
#ifndef RZ_RELAE_TEMPLATE_GRAMMAR__H
#define RZ_RELAE_TEMPLATE_GRAMMAR__H

#include "rz-relae/relae-grammar.h"

#include "rzns.h"

RZNS_(Relae_Template)

class RTMP_Graph;
class RTMP_Parser;
class RTMP_Graph_Build;

class RTMP_Grammar : public Relae_Grammar<RTMP_Graph, RTMP_Parser>
{
public:

 RTMP_Grammar();

 void init(RTMP_Parser& p, RTMP_Graph& g,
           RTMP_Graph_Build& graph_build);


};

_RZNS(Relae_Template)

#endif
