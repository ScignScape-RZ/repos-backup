
#include "rz-relae-template-graph-build.h"

#include <QDebug>

#include "token/rz-relae-template-token.h"
#include "kernel/graph/rz-relae-template-graph.h"

#include "rzns.h"

USING_RZNS(Relae_Template)

RTMP_Graph_Build::RTMP_Graph_Build(RTMP_Graph& g)
 : markup_position_(g.root_node()),
   qts_token_acc_(&token_acc_), qts_string_literal_acc_(&string_literal_acc_)
{

}


void RTMP_Graph_Build::init()
{

}


void RTMP_Graph_Build::enter_multiline_comment(QString semis, QString hyphens)
{
 markup_position_.enter_multiline_comment(cutmax(semis.length()), cutmax(hyphens.length()));
 parse_context_.flags.inside_multiline_comment = true;
}

void RTMP_Graph_Build::check_leave_multiline_comment(QString semis, QString hyphens)
{
 if(markup_position_.check_leave_multiline_comment(cutmax(semis.length()),
  cutmax(hyphens.length())));
 parse_context_.flags.inside_multiline_comment = false;
}

void RTMP_Graph_Build::token_acc(QString str)
{
 qts_token_acc_ << str;
}

void RTMP_Graph_Build::string_literal_acc(QChar c)
{
 qts_string_literal_acc_ << c;
}

void RTMP_Graph_Build::string_literal_acc(QString str)
{
 qts_string_literal_acc_ << str;
}

void RTMP_Graph_Build::check_string_literal_delimiter()
{
 if(parse_context_.flags.inside_string_literal)
 {
  parse_context_.flags.inside_string_literal = false;
  add_string_literal_token();
 }
 else
 {
  parse_context_.flags.inside_string_literal = true;
 }
}

void RTMP_Graph_Build::check_add_token()
{
 if(token_acc_.isEmpty())
 {
  return;
 }
 if(token_acc_.trimmed().isEmpty())
 {
  qts_token_acc_.reset();
  return;
 }
 add_token(token_acc_.trimmed());
 qts_token_acc_.reset();
 token_acc_.clear();
}


void RTMP_Graph_Build::call_entry()
{
 markup_position_.call_entry();
}

void RTMP_Graph_Build::call_leave()
{
 check_add_token();
 markup_position_.call_leave();
}

caon_ptr<RTMP_Token> RTMP_Graph_Build::add_token(QString token_str)
{
 caon_ptr<RTMP_Token> token = make_new_token(token_str);
 caon_ptr<tNode> node = make_new_node(token);
 markup_position_.add_token_node(node);
 return token;
}

void RTMP_Graph_Build::add_string_literal_token(QString str)
{
 caon_ptr<RTMP_Token> token = add_token(str);
 token->flags.is_string_literal = true;
}

void RTMP_Graph_Build::add_string_literal_token()
{
 if(!token_acc_.isEmpty())
 {
  // //  This will happen if a string literal is preceeded by a
  //     string without whitespace; that could be used to create
  //     special kinds of string literals.
  //     This could be a spot for a callback which takes the
  //     token_acc_ string before clearing it.
  token_acc_.clear();
  qts_token_acc_.reset();
 }
 add_string_literal_token(string_literal_acc_);
 string_literal_acc_.clear();
 qts_string_literal_acc_.reset();
}


caon_ptr<RTMP_Token> RTMP_Graph_Build::make_new_token(QString token)
{
 if(token.startsWith(':'))
 {
  token.remove(0, 1);
  caon_ptr<RTMP_Token> result = new RTMP_Token(token);
  result->flags.is_keyword = true;
  return result;
 }
 else
  return new RTMP_Token(token);
}

caon_ptr<RTMP_Graph_Build::tNode> RTMP_Graph_Build::make_new_node(caon_ptr<RTMP_Token> tok)
{
 CAON_PTR_DEBUG(RTMP_Token ,tok)
 caon_ptr<tNode> result = new tNode(tok);
 #ifdef RELAE_LABEL_NODES
 result->set_label(tok->thumbnail());
 #endif
 return result;
}

