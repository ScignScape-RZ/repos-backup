
#ifndef RZ_RELAE_TEMPLATE_GRAPH_BUILD__H
#define RZ_RELAE_TEMPLATE_GRAPH_BUILD__H


#include "kernel/graph/rz-relae-template-markup-position.h"
#include "kernel/grammar/rz-relae-template-parse-context.h"
#include "kernel/rz-relae-template-dominion.h"
#include "accessors.h"

#include "rzns.h"

RZNS_(Relae_Template)

class RTMP_Parser;


class RTMP_Graph_Build
{
 RTMP_Parse_Context parse_context_;
 RTMP_Markup_Position markup_position_;

 static inline int cutmax(int x)
 {
  if(x > 6)
   return 6;
  return x;
 }

 typedef RTMP_Node tNode;

 QString token_acc_;
 QTextStream qts_token_acc_;

 QString string_literal_acc_;
 QTextStream qts_string_literal_acc_;

 caon_ptr<RTMP_Token> add_token(QString token_str);
 void add_string_literal_token();
 caon_ptr<RTMP_Token> make_new_token(QString token);
 caon_ptr<tNode> make_new_node(caon_ptr<RTMP_Token> tok);

public:

 ACCESSORS__RGET(RTMP_Parse_Context ,parse_context)

 RTMP_Graph_Build(RTMP_Graph& g);

 void init();

 void add_string_literal_token(QString str);
 void enter_multiline_comment(QString semis, QString hyphens);
 void check_leave_multiline_comment(QString semis, QString hyphens);

 void call_entry();
 void call_leave();
 void token_acc(QString str);
 void check_add_token();
 void string_literal_acc(QChar c);
 void string_literal_acc(QString str);
 void check_string_literal_delimiter();

};

_RZNS(Relae_Template)

#endif
