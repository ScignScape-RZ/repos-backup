
#include "rz-relae-template-parse-context.h"

#include "rzns.h"

USING_RZNS(Relae_Template)


RTMP_Parse_Context::RTMP_Parse_Context(): Flags(0)
{

}
