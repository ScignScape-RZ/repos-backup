
#ifndef RZ_RELAE_TEMPLATE_PARSE_CONTEXT__H
#define RZ_RELAE_TEMPLATE_PARSE_CONTEXT__H

#include "rz-relae/relae-parser.h"

#include "flags.h"

#include "rzns.h"
RZNS_(Relae_Template)


class RTMP_Graph;
class RTMP_Node;


class RTMP_Parse_Context
{
 typedef RTMP_Node tNode;

public:
 flags_(1)
  flag_(1, inside_multiline_comment);
  flag_(2, inside_string_literal);
 _flags_

public:

 RTMP_Parse_Context();

};

_RZNS(Relae_Template)

#endif
