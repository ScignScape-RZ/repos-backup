
#include "rz-relae-template-parser.h"

USING_RZNS(Relae_Template)

RTMP_Parser::RTMP_Parser(caon_ptr<RTMP_Graph> g)
 : Relae_Parser<RTMP_Galaxy>(g)
{
}

