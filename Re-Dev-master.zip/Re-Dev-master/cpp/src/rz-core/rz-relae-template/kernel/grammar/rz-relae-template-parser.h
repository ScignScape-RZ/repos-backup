
#ifndef RZ_RELAE_TEMPLATE_PARSER__H
#define RZ_RELAE_TEMPLATE_PARSER__H

#include "rz-relae/relae-node-ptr.h"
#include "rz-relae/relae-parser.h"

#include "kernel/rz-relae-template-dominion.h"

#include "rzns.h"

RZNS_(Relae_Template)


class RTMP_Parser : public Relae_Parser<RTMP_Galaxy>
{
public:
 RTMP_Parser(caon_ptr<RTMP_Graph> g);
};

_RZNS(Relae_Template)

#endif
