
#include "rz-relae-template-graph.h"

#include "rz-relae-template-node.h"

#include "rzns.h"

USING_RZNS(Relae_Template)

RTMP_Graph::RTMP_Graph(caon_ptr<RTMP_Node> root_node)
 : node_graph<RTMP_Dominion>(root_node)
{

}
