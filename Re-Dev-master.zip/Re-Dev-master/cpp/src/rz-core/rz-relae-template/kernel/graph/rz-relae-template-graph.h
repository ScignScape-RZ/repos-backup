
#ifndef RZ_RELAE_TEMPLATE_GRAPH__H
#define RZ_RELAE_TEMPLATE_GRAPH__H

#include "rz-relae/relae-node-ptr.h"
#include "kernel/rz-relae-template-dominion.h"

#include "rzns.h"

RZNS_(Relae_Template)


class RTMP_Graph : public node_graph<RTMP_Dominion>
{
 public:
  RTMP_Graph(caon_ptr<RTMP_Node> root_node = nullptr);

};

_RZNS(Relae_Template)


#endif
