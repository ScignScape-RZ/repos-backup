
#include "rz-relae-template-markup-position.h"

#include "rzns.h"

USING_RZNS(Relae_Template)


RTMP_Markup_Position::RTMP_Markup_Position(caon_ptr<tNode> current_node)
 :  current_node_(current_node), comment_semis_(0), comment_hyphens_(0),
   fr_(RTMP_Frame::instance()), qry_(RTMP_Query::instance()),
   position_state_(Root)
{
}

void RTMP_Markup_Position::enter_multiline_comment(int semis, int hyphens)
{
 comment_semis_ = semis;
 comment_hyphens_ = hyphens;
}

bool RTMP_Markup_Position::check_leave_multiline_comment(int semis, int hyphens)
{
 if(comment_semis_ == semis && comment_hyphens_ == hyphens)
 {
  comment_semis_ = 0;
  comment_hyphens_ = 0;
  return true;
 }
 return false;
}

void RTMP_Markup_Position::call_entry()
{
 switch(position_state_)
 {
 case Root:
 case Call_Sequence:
  position_state_ = Call_Entry;
  break;
 case Continuation:
  position_state_ = Cross_Sequence;
  break;
 default:
  //  likely syntax error
  break;
 }

}

void RTMP_Markup_Position::call_leave()
{
 current_node_ = chiefs_.top();
 CAON_PTR_DEBUG(RTMP_Node ,current_node_)
 chiefs_.pop();
 position_state_ = Continuation;
}

void RTMP_Markup_Position::add_token_node(caon_ptr<RTMP_Node> node)
{
 CAON_PTR_DEBUG(RTMP_Node ,node)
 CAON_PTR_DEBUG(RTMP_Node ,current_node_)

 switch(position_state_)
 {
 case Root:
 case Call_Sequence:
  current_node_ << fr_/qry_.L4_Call_Sequence >> node;
  break;

 case Call_Entry:
  current_node_ << fr_/qry_.L4_Call_Entry >> node;
  chiefs_.push(node);
  break;

 case Continuation:
  current_node_ << fr_/qry_.L4_Call_Continue >> node;
  break;

 case Cross_Sequence:
  current_node_ << fr_/qry_.L4_Cross_Sequence >> node;
  chiefs_.push(node);
  break;

 }
 current_node_ = node;
 position_state_ = Call_Sequence;
}

