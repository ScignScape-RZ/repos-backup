
#ifndef RZ_RELAE_TEMPLATE_MARKUP_POSITION__H
#define RZ_RELAE_TEMPLATE_MARKUP_POSITION__H


#include <QList>
#include <QStack>
#include <QMap>
#include <QVector>

#include "kernel/graph/rz-relae-template-node.h"
#include "kernel/query/rz-relae-template-query.h"
#include "kernel/frame/rz-relae-template-frame.h"
#include "accessors.h"
#include "flags.h"

#include "rzns.h"

RZNS_(Relae_Template)

class RTMP_Node;

class RTMP_Markup_Position
{
 int comment_semis_;
 int comment_hyphens_;

 enum Position_States
 {
  Root, Call_Entry, Call_Sequence, Continuation, Cross_Sequence
 };

 Position_States position_state_;

 typedef RTMP_Node tNode;

 QStack<caon_ptr<tNode>> chiefs_;

 caon_ptr<tNode> current_node_;

 RTMP_Frame fr_;
 const RTMP_Query& qry_;

public:

 ACCESSORS(int ,comment_semis)
 ACCESSORS(int ,comment_hyphens)

 RTMP_Markup_Position(caon_ptr<tNode> current_node);

 void enter_multiline_comment(int semis, int hyphens);
 bool check_leave_multiline_comment(int semis, int hyphens);
 void add_token_node(caon_ptr<RTMP_Node> node);
 void call_entry();
 void call_leave();




};


_RZNS(Relae_Template)

#endif

