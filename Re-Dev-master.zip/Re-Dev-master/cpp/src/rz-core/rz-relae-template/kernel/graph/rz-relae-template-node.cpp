
#include "rz-relae-template-node.h"

#include "rzns.h"

USING_RZNS(Relae_Template)

QString RTMP_Node::debug_connectors()
{
 QString result;
 targets_iterator_type it(targets_);
 while(it.hasNext())
 {
  it.next();
  QString connector = it.key()->label();
  caon_ptr<RTMP_Node> target = it.value();
  CAON_PTR_DEBUG(RTMP_Node ,target)
  result += QString("\n <-|%1|-> %2").arg(connector).arg(target->label());
 }
 return result;
}
