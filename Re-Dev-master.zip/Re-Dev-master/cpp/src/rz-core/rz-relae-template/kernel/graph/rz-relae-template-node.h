
#ifndef RZ_RELAE_TEMPLATE_NODE__H
#define RZ_RELAE_TEMPLATE_NODE__H

#include "rz-relae/relae-node-ptr.h"
#include "kernel/rz-relae-template-dominion.h"
#include "kernel/frame/rz-relae-template-frame.h"

#include "rzns.h"

RZNS_(Relae_Template)


class RTMP_Node : public node_ptr<RTMP_Dominion>
{
public:
 #define DOMINION_TYPE DOMINION_NODE_CONSTRUCTOR
 #include "kernel/dominion/types.h"
 #undef DOMINION_TYPE


 QString debug_connectors();

};

_RZNS(Relae_Template)


#endif
