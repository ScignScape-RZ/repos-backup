
#ifndef RZ_RELAE_TEMPLATE_CONNECTION_DESCRIPTOR__H
#define RZ_RELAE_TEMPLATE_CONNECTION_DESCRIPTOR__H

#include <QString>


#include "rzns.h"


RZNS_(Relae_Template)

class RTMP_Connection_Descriptor
{
public:

  enum Descriptors {
   // //  For Lambda-4, these just replicate the connectors.
   //     But other dominions (e.g., NGML) are a little different.
   N_A, Call_Entry, Call_Sequence, Cross_Sequence, Call_Continue
  };

private:
  Descriptors descriptor_;

public:

 operator Descriptors() const
 {
  return descriptor_;
 }

 RTMP_Connection_Descriptor(Descriptors descriptor = N_A);
 QString to_string(QString left = QString(), QString right = QString());

};

_RZNS(Relae_Template)


#endif
