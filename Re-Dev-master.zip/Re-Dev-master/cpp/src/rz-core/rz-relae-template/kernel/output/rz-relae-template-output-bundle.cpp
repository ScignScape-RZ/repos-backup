
#include "rz-relae-template-output-bundle.h"

#include "rzns.h"

USING_RZNS(Relae_Template)

RTMP_Output_Bundle RTMP_Output_Bundle::with(QTextStream& new_qts) const
{
 return {new_qts, node, connection_descriptor};
}

RTMP_Output_Bundle RTMP_Output_Bundle::with(RTMP_Connection_Descriptor descriptor) const
{
 return {qts, node, descriptor};
}

RTMP_Output_Bundle RTMP_Output_Bundle::with(caon_ptr<tNode> n, RTMP_Connection_Descriptor descriptor) const
{
 return {qts, n, descriptor};
}



