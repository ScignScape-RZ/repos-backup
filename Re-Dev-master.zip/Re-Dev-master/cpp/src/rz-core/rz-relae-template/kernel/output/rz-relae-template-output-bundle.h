
#ifndef RZ_RELAE_TEMPLATE_OUTPUT_BUNDLE__H
#define RZ_RELAE_TEMPLATE_OUTPUT_BUNDLE__H

#include "rz-relae/relae-caon-ptr.h"
#include "rz-relae-template-connection-descriptor.h"

#include "rzns.h"

class QTextStream;


RZNS_(Relae_Template)

class RTMP_Node;
class RTMP_Connection_Descriptor;


struct RTMP_Output_Bundle
{
 typedef RTMP_Node tNode;

 QTextStream& qts;
 caon_ptr<tNode> node;
 RTMP_Connection_Descriptor connection_descriptor;

 RTMP_Output_Bundle with(QTextStream& new_qts) const;
 RTMP_Output_Bundle with(caon_ptr<tNode> n, RTMP_Connection_Descriptor descriptor) const;
 RTMP_Output_Bundle with(RTMP_Connection_Descriptor descriptor) const;
};

struct RTMP_Output_Partial_Bundle
{
 typedef RTMP_Node tNode;

 QTextStream& qts;
 caon_ptr<tNode> node;

 operator RTMP_Output_Bundle()
 {
  return {qts, node, RTMP_Connection_Descriptor()};
 }
};



_RZNS(Relae_Template)


#endif
