
#include "rz-relae-template-query.h"

#include "rzns.h"

USING_RZNS(Relae_Template)

RTMP_Query::RTMP_Query()
 : node_query<RTMP_Dominion>()
  #define DOMINION_CONNECTOR(name, label) \
    ,name(RTMP_Connectors(#label))
  #include "kernel/dominion/connectors.h"
  #undef DOMINION_CONNECTOR
{


}

const RTMP_Query& RTMP_Query::instance()
{
 static RTMP_Query* the_instance = nullptr;
 if(!the_instance)
  the_instance = new RTMP_Query;
 return *the_instance;
}
