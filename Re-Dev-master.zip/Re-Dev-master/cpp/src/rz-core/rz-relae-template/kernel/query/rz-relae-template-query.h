
#ifndef RZ_RELAE_TEMPLATE_QUERY__H
#define RZ_RELAE_TEMPLATE_QUERY__H

#include "kernel/rz-relae-template-dominion.h"
#include "rz-relae/relae-node-ptr.h"

#include "rzns.h"

RZNS_(Relae_Template)


class RTMP_Query : public node_query<RTMP_Dominion>
{
 RTMP_Query();

 public:
  #define DOMINION_CONNECTOR(name, label) \
   RTMP_Connectors name;
  #include "kernel/dominion/connectors.h"
  #undef DOMINION_CONNECTOR

 static const RTMP_Query& instance();
};

_RZNS(Relae_Template)

#endif
