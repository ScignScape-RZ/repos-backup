
#include "rz-relae-template-dominion.h"

#include "graph/rz-relae-template-node.h"

#define DOMINION_NODE_NAMESPACE RZ::Relae_Template
#define DOMINION_TYPE DOMINION_RETRIEVE_TYPE_CODE
#include "dominion/types.h"
#undef DOMINION_TYPE
#undef DOMINION_NODE_NAMESPACE
