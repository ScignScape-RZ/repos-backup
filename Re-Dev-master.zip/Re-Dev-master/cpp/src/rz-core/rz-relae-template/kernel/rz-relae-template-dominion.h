
#ifndef RZ_RELAE_TEMPLATE_DOMINION__H
#define RZ_RELAE_TEMPLATE_DOMINION__H


#include "rz-relae/relae-node-ptr.h"
#include "rz-relae/relae-caon-ptr.h"

#include "rzns.h"


#define DOMINION_TYPE DOMINION_TYPE_DECLARE
#include "dominion/types.h"
#undef DOMINION_TYPE

RZNS_(Relae_Template)

struct RTMP_Galaxy;
class RTMP_Node;
class RTMP_Connectors;
class RTMP_Frame;
class RTMP_Root;
class RTMP_Graph;
class RTMP_Document;


struct RTMP_Dominion
{
 typedef RTMP_Galaxy Galaxy_type;
 typedef RTMP_Node Node_type;
 typedef RTMP_Frame Frame_type;
 typedef RTMP_Connectors Connectors_type;
 typedef RTMP_Graph Graph_type;
 typedef RTMP_Document Document_type;
 typedef RTMP_Root Root_type;

 enum class Type_Codes {
  #define DOMINION_TYPE DOMINION_TYPE_ENUM
  #include "dominion/types.h"
  #undef DOMINION_TYPE
 };

 template<typename T>
 Type_Codes get_type_code()
 {
 }
};

struct RTMP_Galaxy : Node_Ptr_Default_Galaxy<RTMP_Dominion>
{
};

struct RTMP_Connectors : node_connectors<RTMP_Dominion> {
  RTMP_Connectors(QString label) : node_connectors<RTMP_Dominion>(label){}
};

_RZNS(Relae_Template)


#endif
