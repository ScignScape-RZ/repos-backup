
#ifndef RZ_RELAE_TEMPLATE_ROOT__H
#define RZ_RELAE_TEMPLATE_ROOT__H

#include "rzns.h"

RZNS_(Relae_Template)

class RTMP_Document;

class RTMP_Root
{
};

_RZNS(Relae_Template)


#endif
