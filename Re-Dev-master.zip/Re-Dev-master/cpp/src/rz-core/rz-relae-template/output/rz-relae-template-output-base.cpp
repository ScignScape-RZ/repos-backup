
#include "rz-relae-template-output-base.h"

#include <QFile>
#include <QFileInfo>


#include "kernel/document/rz-relae-template-document.h"

#include "rzns.h"

USING_RZNS(Relae_Template)


RTMP_Output_Base::RTMP_Output_Base(RTMP_Document& document)
 : document_(document), graph_(*document.graph()), qry_(RTMP_Query::instance())
{

}

