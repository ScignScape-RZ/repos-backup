
#ifndef RZ_RELAE_TEMPLATE_OUTPUT_BASE__H
#define RZ_RELAE_TEMPLATE_OUTPUT_BASE__H

#include <QString>
#include <QTextStream>


#include "rz-relae/relae-node-ptr.h"
#include "kernel/rz-relae-template-dominion.h"
#include "kernel/query/rz-relae-template-query.h"
#include "accessors.h"

#include "rzns.h"

RZNS_(Relae_Template)

class RTMP_Graph;
class RTMP_Document;


class RTMP_Output_Base
{
protected:

 RTMP_Graph& graph_;
 RTMP_Document& document_;

 const RTMP_Query& qry_;

public:


 RTMP_Output_Base(RTMP_Document& document);
 virtual void generate(QTextStream& qts) = 0;


};

_RZNS(Relae_Template)


#endif
