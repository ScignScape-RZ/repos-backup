
#include "rz-relae-template-output-event-generator.h"

#include <QDebug>


#include "rz-relae-template-output-event-handler.h"
#include "kernel/output/rz-relae-template-connection-descriptor.h"
#include "kernel/graph/rz-relae-template-graph.h"
#include "kernel/graph/rz-relae-template-node.h"
#include "kernel/output/rz-relae-template-output-bundle.h"

#include "rzns.h"

USING_RZNS(Relae_Template)


RTMP_Output_Event_Generator::RTMP_Output_Event_Generator
 (RTMP_Output_Base& output_base, RTMP_Output_Event_Handler& handler)
 : RTMP_Output_Base(output_base), handler_(handler)
{

}

void RTMP_Output_Event_Generator::generate(QTextStream& qts)
{
 caon_ptr<tNode> root_node = graph_.root_node();
 CAON_PTR_DEBUG(tNode ,root_node)
 root_node->debug_connectors();
 RTMP_Output_Bundle b {qts, root_node};
 if(caon_ptr<RTMP_Root> nr = root_node->rtmp_root())
 {
  CAON_PTR_DEBUG(RTMP_Root ,nr)
  handler_.generate_root(b, nr);
 }
 check_connectors_on_root(b);
}

void RTMP_Output_Event_Generator::check_generate_token(const RTMP_Output_Bundle& b)
{
 handler_.generate_token(b);
}

caon_ptr<RTMP_Output_Event_Generator::tNode>
 RTMP_Output_Event_Generator::check_call_entry_connectors(const RTMP_Output_Bundle& b)
{
 if(caon_ptr<tNode> target_node = qry_.L4_Call_Entry(b.node))
 {
  CAON_PTR_DEBUG(tNode ,target_node)
  generate_call_entry(b.with(target_node, RTMP_Connection_Descriptor::Call_Entry));
  return target_node;
 }
 return nullptr;
}

void RTMP_Output_Event_Generator::check_connectors_on_root(const RTMP_Output_Bundle& b)
{
 CAON_PTR_B_DEBUG(tNode ,node)

 // //  The root does not allow a |cs| to be followed by anything ...
 if(caon_ptr<tNode> target_node = check_call_entry_connectors(b))
 {
  CAON_PTR_DEBUG(tNode ,target_node)
 }
 else if(target_node = qry_.L4_Call_Sequence(b.node))
 {
  CAON_PTR_DEBUG(tNode ,target_node)
  // //  ... so here we just generate the token and assume the document done.
  check_generate_token(b.with(target_node, RTMP_Connection_Descriptor::Call_Sequence));
 }
}

void RTMP_Output_Event_Generator::check_cross_connectors(const RTMP_Output_Bundle& b)
{
 CAON_PTR_B_DEBUG(tNode ,node)

 if(caon_ptr<tNode> target_node = qry_.L4_Cross_Sequence(b.node))
 {
  CAON_PTR_DEBUG(tNode ,target_node)
  generate_call_entry(b.with(target_node, RTMP_Connection_Descriptor::Cross_Sequence));
 }
 else if(target_node = qry_.L4_Call_Continue(b.node))
 {
  CAON_PTR_DEBUG(tNode ,target_node)
  generate_call_sequence(b.with(target_node, RTMP_Connection_Descriptor::Call_Continue));
 }
}

void RTMP_Output_Event_Generator::check_call_connectors(const RTMP_Output_Bundle& b)
{
 CAON_PTR_B_DEBUG(tNode ,node)

 if(caon_ptr<tNode> target_node = check_call_entry_connectors(b))
 {
  CAON_PTR_DEBUG(tNode ,target_node)
 }
 else if(target_node = qry_.L4_Call_Sequence(b.node))
 {
  CAON_PTR_DEBUG(tNode ,target_node)
  generate_call_sequence(b.with(target_node, RTMP_Connection_Descriptor::Call_Continue));
 }
}

void RTMP_Output_Event_Generator::generate_call_entry(const RTMP_Output_Bundle& b)
{
 CAON_PTR_B_DEBUG(tNode ,node)
 // //  Creating a new QString/QTextStream pair could be
 //     inefficient, and in this case it simply deletes
 //     trailing whitespace.  But in other circumstances
 //     it is necessary to work on a temporary string which
 //     is then modified and added to the main output.
 QString temp;
 QTextStream qts_temp(&temp);
 RTMP_Output_Bundle btemp = b.with(qts_temp);
 handler_.generate_call_entry(btemp);
 check_generate_token(btemp);
 check_call_connectors(btemp);
 b.qts << temp.trimmed();
 handler_.generate_call_leave(b);
 check_cross_connectors(b);
}

void RTMP_Output_Event_Generator::generate_call_sequence(const RTMP_Output_Bundle& b)
{
 CAON_PTR_B_DEBUG(tNode ,node)
 check_generate_token(b);
 check_call_connectors(b);
}

