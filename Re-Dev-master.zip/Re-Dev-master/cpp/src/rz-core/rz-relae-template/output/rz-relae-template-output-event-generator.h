
#ifndef RZ_RELAE_TEMPLATE_OUTPUT_EVENT_GENERATOR__H
#define RZ_RELAE_TEMPLATE_OUTPUT_EVENT_GENERATOR__H

#include "rz-relae/relae-node-ptr.h"
#include "kernel/rz-relae-template-dominion.h"
#include "kernel/query/rz-relae-template-query.h"
#include "output/rz-relae-template-output-base.h"
#include "kernel/output/rz-relae-template-connection-descriptor.h"

#include "accessors.h"

#include "rzns.h"

RZNS_(Relae_Template)

class RTMP_Graph;
class RTMP_Document;
class RTMP_Node;
class RTMP_Token;
class RTMP_Root;
class RTMP_Output_Base;
class RTMP_Output_Event_Handler;
class RTMP_Output_Bundle;

class RTMP_Output_Event_Generator : RTMP_Output_Base
{
 RTMP_Output_Event_Handler& handler_;

protected:

 typedef RTMP_Node tNode;

public:

 RTMP_Output_Event_Generator(RTMP_Output_Base& base, RTMP_Output_Event_Handler& handler);

 void generate(QTextStream& qts);
 void generate_call_entry(const RTMP_Output_Bundle& b);
 void generate_call_sequence(const RTMP_Output_Bundle& b);

 void check_generate_token(const RTMP_Output_Bundle& b);

 caon_ptr<tNode> check_call_entry_connectors(const RTMP_Output_Bundle& b);
 void check_connectors_on_root(const RTMP_Output_Bundle& b);
 void check_cross_connectors(const RTMP_Output_Bundle& b);
 void check_call_connectors(const RTMP_Output_Bundle& b);

};

_RZNS(Relae_Template)


#endif
