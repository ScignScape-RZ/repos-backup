
#include "rz-relae-template-output-event-handler.h"

#include <QFile>
#include <QFileInfo>


#include "kernel/document/rz-relae-template-document.h"
#include "kernel/graph/rz-relae-template-node.h"
#include "token/rz-relae-template-token.h"
#include "kernel/output/rz-relae-template-output-bundle.h"

#include "rzns.h"

USING_RZNS(Relae_Template)


RTMP_Output_Event_Handler::RTMP_Output_Event_Handler()
{

}

void RTMP_Output_Event_Handler::generate_root(const RTMP_Output_Bundle& b, caon_ptr<RTMP_Root> nr)
{

}

void RTMP_Output_Event_Handler::generate_call_entry(const RTMP_Output_Bundle& b)
{
 b.qts << '(';
}

void RTMP_Output_Event_Handler::generate_call_leave(const RTMP_Output_Bundle& b)
{
 b.qts << ") ";
}

void RTMP_Output_Event_Handler::generate_token(const RTMP_Output_Bundle& b)
{
 CAON_PTR_B_DEBUG(tNode ,node)
 if(caon_ptr<RTMP_Token> token = b.node->rtmp_token())
 {
  CAON_PTR_DEBUG(RTMP_Token ,token)
  generate_token_connection_descriptor(b);
  generate_token(b, token);
  generate_space_following_token(b);
 }
}

void RTMP_Output_Event_Handler::generate_token_connection_descriptor(const RTMP_Output_Bundle& b)
{

}

void RTMP_Output_Event_Handler::generate_space_following_token(const RTMP_Output_Bundle& b)
{
 b.qts << ' ';
}

void RTMP_Output_Event_Handler::generate_token(const RTMP_Output_Bundle& b, caon_ptr<RTMP_Token> token)
{
 b.qts << token->to_string();
}

