
#ifndef RZ_RELAE_TEMPLATE_OUTPUT_EVENT_HANDLER__H
#define RZ_RELAE_TEMPLATE_OUTPUT_EVENT_HANDLER__H

#include <QTextStream>

#include "rz-relae/relae-node-ptr.h"
#include "kernel/rz-relae-template-dominion.h"
#include "kernel/query/rz-relae-template-query.h"
#include "kernel/output/rz-relae-template-connection-descriptor.h"
#include "accessors.h"

#include "rzns.h"

RZNS_(Relae_Template)

class RTMP_Graph;
class RTMP_Document;
class RTMP_Node;
class RTMP_Token;
class RTMP_Root;
class RTMP_Output_Bundle;


class RTMP_Output_Event_Handler
{
protected:

 typedef RTMP_Node tNode;

 RTMP_Output_Event_Handler();

public:

 virtual void generate_call_entry(const RTMP_Output_Bundle& b);
 virtual void generate_call_leave(const RTMP_Output_Bundle& b);

 virtual void generate_token(const RTMP_Output_Bundle& b);
 virtual void generate_token(const RTMP_Output_Bundle& b, caon_ptr<RTMP_Token> token);
 virtual void generate_token_connection_descriptor(const RTMP_Output_Bundle& b);
 virtual void generate_space_following_token(const RTMP_Output_Bundle& b);

 virtual void generate_root(const RTMP_Output_Bundle& b, caon_ptr<RTMP_Root> nr);



};

_RZNS(Relae_Template)


#endif
