
#include "rz-relae-template-output-p16.h"

#include <QFile>
#include <QFileInfo>


#include "rz-relae-template-output-event-generator.h"
#include "kernel/document/rz-relae-template-document.h"
#include "kernel/output/rz-relae-template-output-bundle.h"
#include "token/rz-relae-template-token.h"
#include "kernel/graph/rz-relae-template-node.h"

#include "rzns.h"

USING_RZNS(Relae_Template)


RTMP_Output_P16::RTMP_Output_P16(RTMP_Document& document)
 : RTMP_Output_Base(document), RTMP_Output_Event_Handler()
{

}

void RTMP_Output_P16::write_p16_output(QString& p16_output)
{
 QTextStream qts(&p16_output);
 generate(qts);
}

void RTMP_Output_P16::generate(QTextStream& qts)
{
 RTMP_Output_Event_Generator events(*this, *this);
 events.generate(qts);
}

void RTMP_Output_P16::export_p16(QString path)
{
 if(path.startsWith(".."))
 {
  path.remove(0, 1);
  path.prepend(document_.local_path());
 }
 else if(path.startsWith('.'))
 {
  QFileInfo qfi(document_.local_path());
  path.prepend(qfi.absolutePath() + '/' + qfi.completeBaseName());
 }
 QString p16_output;
 write_p16_output(p16_output);

 QFile outfile(path);
 if(outfile.open(QFile::WriteOnly | QIODevice::Text))
 {
  outfile.write(p16_output.toLatin1());
  outfile.close();
 }

}

void RTMP_Output_P16::generate_call_entry(const RTMP_Output_Bundle& b)
{
 CAON_PTR_B_DEBUG(RTMP_Node ,node)
 chiefs_.push(b.node);
 switch(b.connection_descriptor)
 {
 case RTMP_Connection_Descriptor::Call_Entry:
  b.qts << " & <-|ce|-> ";
  break;
 case RTMP_Connection_Descriptor::Cross_Sequence:
  b.qts << " & <-|cx|-> ";
  break;
 }
}

void RTMP_Output_P16::generate_token(const RTMP_Output_Bundle& b, caon_ptr<RTMP_Token> token)
{
 CAON_PTR_DEBUG(RTMP_Token ,token)
 b.qts << token->to_string() << ";";
}

void RTMP_Output_P16::generate_space_following_token(const RTMP_Output_Bundle& b)
{
 b.qts << "\n ";
}


void RTMP_Output_P16::generate_call_leave(const RTMP_Output_Bundle& b)
{
 caon_ptr<RTMP_Node> chief = chiefs_.top();
 chiefs_.pop();
 CAON_PTR_DEBUG(RTMP_Node ,chief)
 b.qts << "<-/";
 if(caon_ptr<RTMP_Token> token = chief->rtmp_token())
 {
  b.qts << token->to_string();
 }
 b.qts << ">\n";
}

void RTMP_Output_P16::generate_token_connection_descriptor(const RTMP_Output_Bundle& b)
{
 switch(b.connection_descriptor)
 {
 case RTMP_Connection_Descriptor::Call_Sequence:
  b.qts << " & <-|cs|-> ";
  break;
 case RTMP_Connection_Descriptor::Call_Continue:
  b.qts << " & <-|cc|-> ";
  break;

 }
}
