
#ifndef RZ_RELAE_TEMPLATE_OUTPUT_P16__H
#define RZ_RELAE_TEMPLATE_OUTPUT_P16__H

#include <QStack>

#include "rz-relae-template-output-base.h"
#include "rz-relae-template-output-event-handler.h"

#include "rzns.h"

RZNS_(Relae_Template)

class RTMP_Graph;
class RTMP_Document;


class RTMP_Output_P16 : public RTMP_Output_Base, private RTMP_Output_Event_Handler
{
 QStack<caon_ptr<RTMP_Node>> chiefs_;

public:

 RTMP_Output_P16(RTMP_Document& document);

 void export_p16(QString path = "..p16");
 void write_p16_output(QString& p16_output);

 void generate(QTextStream& qts);

 void generate_space_following_token(const RTMP_Output_Bundle& b) Q_DECL_OVERRIDE;
 void generate_token(const RTMP_Output_Bundle& b, caon_ptr<RTMP_Token> token) Q_DECL_OVERRIDE;
 void generate_token_connection_descriptor(const RTMP_Output_Bundle& b) Q_DECL_OVERRIDE;
 void generate_call_entry(const RTMP_Output_Bundle& b) Q_DECL_OVERRIDE;
 void generate_call_leave(const RTMP_Output_Bundle& b) Q_DECL_OVERRIDE;
};

_RZNS(Relae_Template)


#endif
