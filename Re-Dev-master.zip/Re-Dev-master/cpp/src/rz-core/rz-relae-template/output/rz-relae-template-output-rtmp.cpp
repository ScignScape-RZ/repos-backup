
#include "rz-relae-template-output-rtmp.h"

#include <QFile>
#include <QFileInfo>


#include "rz-relae-template-output-event-generator.h"
#include "kernel/document/rz-relae-template-document.h"

#include "rzns.h"

USING_RZNS(Relae_Template)


RTMP_Output_Rtmp::RTMP_Output_Rtmp(RTMP_Document& document)
 : RTMP_Output_Base(document)
{

}

void RTMP_Output_Rtmp::write_rtmp_output(QString& rtmp_output)
{
 QTextStream qts(&rtmp_output);
 generate(qts);
}

void RTMP_Output_Rtmp::generate(QTextStream& qts)
{
 RTMP_Output_Event_Generator events(*this, *this);
 events.generate(qts);
}

void RTMP_Output_Rtmp::export_rtmp(QString path)
{
 if(path.startsWith(".."))
 {
  path.remove(0, 1);
  path.prepend(document_.local_path());
 }
 else if(path.startsWith('.'))
 {
  QFileInfo qfi(document_.local_path());
  path.prepend(qfi.absolutePath() + '/' + qfi.completeBaseName());
 }
 QString rtmp_output;
 write_rtmp_output(rtmp_output);

 QFile outfile(path);
 if(outfile.open(QFile::WriteOnly | QIODevice::Text))
 {
  outfile.write(rtmp_output.toLatin1());
  outfile.close();
 }

}

