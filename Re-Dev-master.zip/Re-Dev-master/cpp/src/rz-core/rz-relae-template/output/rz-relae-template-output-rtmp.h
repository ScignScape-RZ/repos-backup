
#ifndef RZ_RELAE_TEMPLATE_OUTPUT_RTMP__H
#define RZ_RELAE_TEMPLATE_OUTPUT_RTMP__H


#include "rz-relae-template-output-base.h"
#include "rz-relae-template-output-event-handler.h"

#include "rzns.h"

RZNS_(Relae_Template)

class RTMP_Graph;
class RTMP_Document;


class RTMP_Output_Rtmp : public RTMP_Output_Base, private RTMP_Output_Event_Handler
{

public:


 RTMP_Output_Rtmp(RTMP_Document& document);

 void export_rtmp(QString path = "..rtmp");
 void write_rtmp_output(QString& rtmp_output);

 void generate(QTextStream& qts);
};

_RZNS(Relae_Template)


#endif
