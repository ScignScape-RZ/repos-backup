
#ifndef RZ_RELAE_TEMPLATE_TOKEN__H
#define RZ_RELAE_TEMPLATE_TOKEN__H

#include <QString>


#include "accessors.h"
#include "flags.h"

#include "rzns.h"


RZNS_(Relae_Template)

class RTMP_Token
{
public:

 flags_(1)
  bool is_string_literal:1;
  bool is_keyword:1;
 _flags

private:

 QString raw_text_;

public:

 ACCESSORS(QString ,raw_text)

 RTMP_Token(QString raw_text);

 QString to_string();

 QString thumbnail(int max_characters = 6);

};

_RZNS(Relae_Template)

#endif
