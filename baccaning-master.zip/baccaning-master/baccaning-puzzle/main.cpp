
#include "number-panel-monochrome-board.h"

#include "koftl/koftl-ranges.h"

#include <QApplication>

#include <QGraphicsScene>
#include <QGraphicsView>
#include <QGraphicsItem>

#include <QDebug>

//#define __connect connect(
#define _connect )
#define _connecting )

#define connecting_ QObject::connect
//#define __signal(x) &x,

int main(int argc, char **argv)
{
 QApplication qapp(argc, argv);

 QGraphicsScene scene;

 //
 float scale_factor = 2;
 //float scale_factor = 1;

// Game_Utils utils;

// Game_Panel_Board gpb(utils);

 Number_Panel_Monochrome_Board npb;


 npb.draw_to_scene(scene, scale_factor);


 QGraphicsView view(&scene);

 view.resize(1000, 600);

 view.setContextMenuPolicy(Qt::CustomContextMenu);

// view.connect(&view, &QGraphicsView::customContextMenuRequested,
// [&scene, scale_factor, &view, &npb](const QPoint& p)
// {
//  npb.handle_right_click(p, view);
//  //QMenu menu;
// }
// );

 view.connect(&scene, &QGraphicsScene::selectionChanged,
   [&scene, scale_factor, &view, &npb] ()
 {
  npb.handle_scene_selection_changed(view, scene);
 }
 );

 view.connect(&view, &QGraphicsView::customContextMenuRequested,
 [&scene, scale_factor, &view, &npb](const QPoint& p)
 {
  npb.handle_right_click(p, view);
  //QMenu menu;
 }
 );

 view.show();


// for(int i = 0; i < 196; ++i)
// {

// }

 return qapp.exec();
}
