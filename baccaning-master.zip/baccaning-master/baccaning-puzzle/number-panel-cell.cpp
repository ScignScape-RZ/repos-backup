

#include "number-panel-cell.h"


Number_Panel_Cell::Number_Panel_Cell()
 : cluster_index_frame_origin_index_(0), cluster_index_(0),
   scoring_run_(0)
{

}

bool Number_Panel_Cell::is_out_of_focus()
{
 return frames_.isEmpty();
}


void Number_Panel_Cell::add_frame(Number_Panel_Fixed_Frame* frame)
{
 frames_.push_back(frame);
}

void Number_Panel_Cell::cluster_merge(const Number_Panel_Cell& c)
{
 cluster_index_frame_origin_index_ = c.cluster_index_frame_origin_index();
 cluster_index_ = c.cluster_index();
 scoring_run_ = c.scoring_run();
}

