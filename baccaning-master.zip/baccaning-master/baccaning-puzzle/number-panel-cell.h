
#ifndef NUMBER_PANEL_CELL__H
#define NUMBER_PANEL_CELL__H

//#include "koftl/koftl-grid.h"
//#include "koftl/koftl-jackets.h"

#include <QGraphicsScene>

#include "../accessors.h"

class QGraphicsRectItem;
class Number_Panel_Fixed_Frame;


class Number_Panel_Cell
{
public:

 enum States {
   N_A, Blank, Ladder, Initial, Rotated
  };

 int row_;
 int column_;

 int randomized_index_;
 int current_number_;
 int initial_number_;
 float local_x_center_;
 float local_y_center_;
 States state_;
 mutable QGraphicsRectItem* ri_;

 QVector<Number_Panel_Fixed_Frame*> frames_;

 int cluster_index_;
 int cluster_index_frame_origin_index_;
 int scoring_run_;

public:


 ACCESSORS(int ,row)
 ACCESSORS(int ,column)

 ACCESSORS(int ,randomized_index)
 ACCESSORS(int ,current_number)
 ACCESSORS(int ,initial_number)
 ACCESSORS(float ,local_x_center)
 ACCESSORS(float ,local_y_center)
 ACCESSORS(States ,state)
 ACCESSORS__CONST(QGraphicsRectItem* ,ri)
 ACCESSORS__RGET(QVector<Number_Panel_Fixed_Frame*> ,frames)

 ACCESSORS(int ,cluster_index)
 ACCESSORS(int ,cluster_index_frame_origin_index)
 ACCESSORS(int ,scoring_run)


 bool is_out_of_focus();

 Number_Panel_Cell();

 void add_frame(Number_Panel_Fixed_Frame* frame);

 void cluster_merge(const Number_Panel_Cell& c);

};



#endif
