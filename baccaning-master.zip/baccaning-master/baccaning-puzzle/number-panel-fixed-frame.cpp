
#include "number-panel-fixed-frame.h"

#include <QtGlobal>
#include <QGraphicsRectItem>

Number_Panel_Fixed_Frame::Number_Panel_Fixed_Frame(Number_Panel_Monochrome_Board* board,
  int tlx, int tly, int brx, int bry) :
  board_(board), logical_top_left_x_(tlx), logical_top_left_y_(tly),
  logical_bottom_right_x_(brx), logical_bottom_right_y_(bry),
  scoring_run_count_(0), frame_index_(0)
{

}


void Number_Panel_Fixed_Frame::get_score_summary(
  QMap<int, QSet<Number_Panel_Cell*>>& clusters_by_index,
  QList<int>& obsolete_cluster_indexes,
  int& current_cluster_index, int scoring_run)
{
 //QString result = "Scores:\n";
 //cell_sets_.clear();
 //QSet<QSet<Number_Panel_Monochrome_Board::Cell*>> cell_sets_;

 QMap<Number_Panel_Cell*, int> cell_sets;
 QMap<int, QSet<Number_Panel_Cell*>> inverse_cell_sets;

 QMultiMap<int, int> group_index_by_number;

 int group_index = 0;

 if(scoring_run_count_ == 0)
 {
  for(int i = logical_top_left_y_; i <= logical_bottom_right_y_; ++i)
  {
   for(int j = logical_top_left_x_; j <= logical_bottom_right_x_; ++j)
   {
    Number_Panel_Cell* c = board_->get_cell(i, j);
    c->add_frame(this);
   }
  }
 }


 for(int i = logical_top_left_y_; i <= logical_bottom_right_y_; ++i)
 {
  for(int j = logical_top_left_x_; j <= logical_bottom_right_x_; ++j)
  {
   Number_Panel_Cell* c = board_->get_cell(i, j);

   int c_group_index;

   if(c->state() == Number_Panel_Cell::Blank)
    continue;
   if(c->state() == Number_Panel_Cell::Ladder)
    continue;


   if(cell_sets.contains(c))
   {
    c_group_index = cell_sets[c];
   }
   else
   {
    ++group_index;
    cell_sets[c] = group_index;
    c_group_index = group_index;
    inverse_cell_sets[group_index].insert(c);
    group_index_by_number.insertMulti(c->current_number(), group_index);
   }

   int max_bottom_right_x = board_->max_bottom_right_x();
   int max_bottom_right_y = board_->max_bottom_right_y();

   // //  Usually check cells one step left or one step down
    //    (so the vertical loop starts at i and the
    //     horizontal loop starts at j - 1).
    //
    //    Allow checks outside the frame only at frame
    //    boundary, to find clusters across multiple frames.

   // //  extra check above for frame boundary
   int ii_start = i == logical_top_left_y_? i - 1 : i;

   for(int ii = qMax(0, ii_start);
       ii <= qMin(max_bottom_right_y, i + 1); ++ii)
   {
    for(int jj = qMax(0, j - 1);   //qMax(logical_top_left_x_, j - 1);
        jj <= qMin(max_bottom_right_x, j + 1); ++jj)
    {
     if( (ii == i) &&
         (
          (jj == j) ||
          // //  extra check left, for frame boundary
          ( (j != logical_top_left_x_ ) && (jj < j) )
         )
       )
      continue;
     Number_Panel_Cell* neighbor = board_->get_cell(ii, jj);

     if(neighbor->is_out_of_focus())
      continue;

     if(neighbor->current_number() == c->current_number())
     {
      if(!cell_sets.contains(neighbor))
      {
       cell_sets[neighbor] = c_group_index;
       inverse_cell_sets[c_group_index].insert(neighbor);
      }
     }
    }
   }
  }
 }

 // merge clusters
 QMapIterator<int, int> it(group_index_by_number);// inverse_cell_sets);
 while(it.hasNext())
 {
  it.next();
  int k = it.key();
  int gi = it.value();
  QSet<Number_Panel_Cell*> cells = inverse_cell_sets[gi];
  if(cells.size() > 1)
  {
   int final_cluster_index;
   //int prior_valid_cluster_index = 0;
   Number_Panel_Cell* prior_scored_cell = nullptr;
   for(Number_Panel_Cell* c : cells)
   {
    if(c->cluster_index() > 0)
    {
     if(c->scoring_run() < scoring_run)
     {
      if(c->cluster_index_frame_origin_index_ != frame_index_)
      {
       // inherit from prior run
       //prior_valid_cluster_index = c->cluster_index();
       prior_scored_cell = c;
      }
     }
    }
   }
   if(prior_scored_cell)
   {
    // just modifying an earlier scored cluster
    for(Number_Panel_Cell* c : cells)
    {
     c->cluster_merge(*prior_scored_cell);
    }
    final_cluster_index = prior_scored_cell->cluster_index();
   }
   else
   {
    // this is a newly scored cluster
    ++current_cluster_index;
    final_cluster_index = current_cluster_index;
    for(Number_Panel_Cell* c : cells)
    {
     c->set_cluster_index(current_cluster_index);
     c->set_cluster_index_frame_origin_index(frame_index_);
     c->set_scoring_run(scoring_run);
    }
   }
   clusters_by_index[final_cluster_index].unite(cells);
     //= cells;
  }
 }


// //QMapIterator<int, QList<Number_Panel_Monochrome_Board::Cell*>> it(inverse_cell_sets);
// QMapIterator<int, int> it(group_index_by_number);// inverse_cell_sets);
// while(it.hasNext())
// {
//  it.next();
//  int k = it.key();
//  int gi = it.value();
//  QList<Number_Panel_Cell*> cells = inverse_cell_sets[gi];
//  if(cells.size() > 1)
//  {
//   for(Number_Panel_Cell* c : cells)
//   {
//    QGraphicsRectItem* qgri = c->ri();
//    QBrush qbr(QColor(200, 0, 200));
//    qgri->setBrush(qbr);
//   }
//   //Number_Panel_Monochrome_Board::Cell* c = cells.first();
//   result += QString("\n%1: %2").arg(k).arg(cells.size()); //.arg(c->current_number);
//  }
// }

 ++scoring_run_count_;
 // return result;
}
