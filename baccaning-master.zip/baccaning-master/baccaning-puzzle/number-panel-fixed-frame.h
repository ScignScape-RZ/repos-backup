
#ifndef NUMBER_PANEL_FIXED_FRAME__H
#define NUMBER_PANEL_FIXED_FRAME__H

#include "koftl/koftl-grid.h"
#include "koftl/koftl-jackets.h"

#include "number-panel-monochrome-board.h"

#include "../accessors.h"

#include <QGraphicsScene>

#include <QSet>

class Number_Panel_Fixed_Frame
{
 Number_Panel_Monochrome_Board* board_;

 int logical_top_left_x_;
 int logical_top_left_y_;

 int logical_bottom_right_x_;
 int logical_bottom_right_y_;

 int scoring_run_count_;
 int frame_index_;

 //QSet<QSet<Number_Panel_Monochrome_Board::Cell*>> cell_sets_;

public:

 ACCESSORS(int ,frame_index)


 Number_Panel_Fixed_Frame(Number_Panel_Monochrome_Board* board,
   int tlx, int tly, int brx, int bry);

 void get_score_summary(QMap<int, QSet<Number_Panel_Cell*>>& clusters_by_index,
   QList<int>& obsolete_cluster_indexes,
   int& current_cluster_index, int scoring_run);


};



#endif
