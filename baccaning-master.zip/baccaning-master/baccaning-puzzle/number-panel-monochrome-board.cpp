
#include "number-panel-monochrome-board.h"

#include "number-panel-fixed-frame.h"

#include "koftl/koftl-ranges.h"
#include "koftl/koftl-jagged.h"
#include "koftl/koftl-grid1.h"

#include <QDebug>
#include <QGraphicsTextItem>
#include <QGraphicsSimpleTextItem>

#include <QWidgetAction>

#include <QGraphicsView>
#include <QLineEdit>
#include <QMenu>
#include <QComboBox>


Number_Panel_Monochrome_Board::Number_Panel_Monochrome_Board()
 : cells_(14), selected_item_(0), current_cluster_index_(0), current_scoring_run_(0)
{
 qsrand(time(NULL));
 init_cells();
}

void Number_Panel_Monochrome_Board::get_items(const QList<QGraphicsItem*>& items, QGraphicsRectItem*& bkg,
  QGraphicsSimpleTextItem*& txt)
{
 for(QGraphicsItem* item : items)
 {
  Number_Panel_Monochrome_Board::Graphics_Item_Role role =
    (Number_Panel_Monochrome_Board::Graphics_Item_Role)
    item->data(0).value<int>();
  if(role == Number_Panel_Monochrome_Board::Graphics_Item_Role::Background)
  {
   bkg = qgraphicsitem_cast<QGraphicsRectItem*>(item);
  }
  else if(role == Number_Panel_Monochrome_Board::Graphics_Item_Role::Ladder)
  {
   bkg = qgraphicsitem_cast<QGraphicsRectItem*>(item);
  }
  else if(role == Number_Panel_Monochrome_Board::Graphics_Item_Role::Text)
  {
   txt = qgraphicsitem_cast<QGraphicsSimpleTextItem*>(item);
  }
 }
}

void Number_Panel_Monochrome_Board::get_items_at_point(const QGraphicsView& view,
  const QPoint& p, QGraphicsRectItem*& bkg,
  QGraphicsSimpleTextItem*& txt)
{
 QList<QGraphicsItem*> items = view.items(p);
 get_items(items, bkg, txt);
}


void Number_Panel_Monochrome_Board::add_frame(Number_Panel_Cell* tl, Number_Panel_Cell* br)
//(int logical_top_left_x, int logical_top_left_y,
//  int logical_bottom_right_x, int logical_bottom_right_y)
{
 int logical_top_left_x = tl->column();
 int logical_top_left_y = tl->row();

 int logical_bottom_right_x = br->column();
 int logical_bottom_right_y = br->row();

 Number_Panel_Fixed_Frame* fr = new Number_Panel_Fixed_Frame(this, logical_top_left_x, logical_top_left_y,
   logical_bottom_right_x, logical_bottom_right_y);
 frames_.push_back(fr);
 fr->set_frame_index(frames_.size());

 ++current_scoring_run_;
 //frame_report_ =


 QList<int> obsolete_cluster_indexes;

 fr->get_score_summary(clusters_by_index_, obsolete_cluster_indexes, current_cluster_index_, current_scoring_run_);

 update_frame_report();
 //qDebug() << "R: " << report;

}


void Number_Panel_Monochrome_Board::update_frame_report()
{
 frame_report_ = "Scores:\n";

 QMap<int, QList<const QSet<Number_Panel_Cell*>*>> temp_map;

 {
  QMapIterator<int, QSet<Number_Panel_Cell*>> it(clusters_by_index_);// inverse_cell_sets);
  while(it.hasNext())
  {
   it.next();
   int k = it.key();
   const QSet<Number_Panel_Cell*>& cells = it.value();
   int number = (*cells.begin())->current_number();
   temp_map[number].push_back(&cells);
  }
 }
 {
  QMapIterator<int, QList<const QSet<Number_Panel_Cell*>*>> it(temp_map);// inverse_cell_sets);
  while(it.hasNext())
  {
   it.next();
   int k = it.key();
   QList<const QSet<Number_Panel_Cell*>*> sets = it.value();
   for(const QSet<Number_Panel_Cell*>* cells : sets)
   {
    for(Number_Panel_Cell* c : *cells)
    {
     QGraphicsRectItem* qgri = c->ri();
     QBrush qbr(QColor(200, 0, 200));
     qgri->setBrush(qbr);
    }
    //Number_Panel_Monochrome_Board::Cell* c = cells.first();
    frame_report_ += QString("\n%1: %2").arg(k).arg(cells->size()); //.arg(c->current_number);
   }
  }
 }

//  if(cells.size() > 1)
//  {
//  }
}


void Number_Panel_Monochrome_Board::handle_scene_selection_changed(QGraphicsView& view, QGraphicsScene& scene)
{
 QList<QGraphicsItem*> items = scene.selectedItems();
 QGraphicsRectItem* bkg = nullptr;
 QGraphicsSimpleTextItem* txt = nullptr;

 get_items(items, bkg, txt);
 if(bkg)
 {
  if(selected_item_)
  {
   QPointF tl = selected_item_->boundingRect().topLeft();
//   int tl_x = selected_item_->boundingRect().topLeft();
//   int tl_y = selected_item_->y();
//   int br_x = bkg->x();
//   int br_y = bkg->y();
   QPointF br = bkg->boundingRect().bottomRight();

   Number_Panel_Cell* tlc = (Number_Panel_Cell*)selected_item_->data(1).toULongLong();
   Number_Panel_Cell* brc = (Number_Panel_Cell*)bkg->data(1).toULongLong();

   add_frame(tlc, brc);

   frame_report_item_->setText(frame_report_);

   QRectF qr(tl, br);
   //scene.addRect(tl_x, tl_y, br_x - tl_x, br_y - tl_y, QPen(), QBrush(QColor(200,200,200)));
   scene.addRect(qr, QPen(), QBrush(QColor(200,200,200, 20)));
   selected_item_ = nullptr;


  }
  else
  {
   selected_item_ = bkg;
  }
 }

}

void Number_Panel_Monochrome_Board::handle_right_click(const QPoint& p, QGraphicsView& view)
{
 QGraphicsRectItem* bkg = nullptr;
 QGraphicsSimpleTextItem* txt = nullptr;
 get_items_at_point(view, p, bkg, txt);
 if(bkg)
 {
  set_marked(bkg);
 }
 if(txt)
 {
  QWidgetAction* wa = new QWidgetAction(view.scene());
  QLineEdit* qle = new QLineEdit;
  wa->setDefaultWidget(qle);
  QMenu menu;

  QObject::connect(qle, &QLineEdit::returnPressed,
    [txt, &menu, qle]()
  {
   QString text = qle->text();
   int n = text.toInt();
   if(n > 0)
   {
    txt->setText(text);
   }
   qle->deleteLater();
   menu.close();
  });

  menu.addAction(wa);
  //qle->setFocusPolicy(Qt::StrongFocus);
  qle->setFocus();

  menu.exec(view.mapToGlobal(p));

 }

}

void Number_Panel_Monochrome_Board::handle_left_click(const QPoint& p,
  QGraphicsView& view)
{
 QGraphicsRectItem* bkg = nullptr;
 QGraphicsSimpleTextItem* txt = nullptr;
 get_items_at_point(view, p, bkg, txt);
 if(bkg)
 {
  set_marked(bkg);
 }
 if(txt)
 {
  QWidgetAction* wa = new QWidgetAction(view.scene());
  QComboBox* qcb = new QComboBox;

  qcb->setEditable(true);

  kf_Range<int> r{1, 22};
  r.span do_[qcb](int i, KF_CHECKED)
  {
   _KF_
   qcb->addItem(QString::number(i));
  }
  _do;

  wa->setDefaultWidget(qcb);

  QMenu menu;

  QObject::connect(qcb, static_cast<void(QComboBox::*)(const QString &)>(&QComboBox::activated),
    [txt, &menu](QString text)
  {
   int n = text.toInt();
   if(n > 0)
   {
    txt->setText(text);
   }
   menu.close();
  });

  menu.addAction(wa);
  menu.exec(view.mapToGlobal(p));

 }
}

void Number_Panel_Monochrome_Board::draw_to_scene(QGraphicsScene& scene,
  float scale_factor)
{
 // draw outer board

 int section_width = 20;

 QPen outer_pen = QPen(QColor("#059a49"));
 outer_pen.setWidth(3);

//?
// QGraphicsRectItem* item = scene.addRect(0, 0, section_width * 7 * scale_factor,
//               section_width * 8 * scale_factor, outer_pen);

// item->setData(1, QVariant("Background"));


// for(Game_Panel_Section* gps : sections_)
// {
//  gps->draw_to_scene(scene, scale_factor);
// }

//? int offset = section_width - 18;

 frame_report_item_ =  scene.addSimpleText("Scores:");
 frame_report_item_->setX(-100);
 frame_report_item_->setY(10);

 int offset = 0;

 int h_min = offset;
 int v_min = offset;
 int h_max = 8 * section_width + offset;
 int v_max = 9 * section_width + offset;

 int i = 0;

 cells_.span do_[&scene, scale_factor](const Number_Panel_Cell& c, KF_CHECKED)
 {
  _KF_

  float center_x = scale_factor * (c.local_x_center());
  float center_y = scale_factor * (c.local_y_center());

  switch(c.state())
  {
  case Number_Panel_Cell::States::Blank:
   {
    QColor qc(120, 20, 20);
    QBrush qbr(qc);
    QGraphicsEllipseItem* qgei = scene.addEllipse
      (center_x - (10 * scale_factor), center_y - (10 * scale_factor),
       10  * scale_factor, 10 * scale_factor, QPen(), qbr);
   }
   break;

  case Number_Panel_Cell::States::Ladder:
  {
    QColor qc(20, 20, 120);
    QBrush qbr(qc);
    QGraphicsRectItem* qgri = scene.addRect
      (center_x - (10 * scale_factor), center_y - (10 * scale_factor),
       8  * scale_factor, 8 * scale_factor, QPen(), qbr);

    qgri->setData(0, QVariant((int) Graphics_Item_Role::Ladder));
    qgri->setData(1, QVariant((quintptr) &c));

    qgri->setFlags(QGraphicsItem::ItemIsSelectable);

   }
   break;

 //  QBrush qbr(QColor(200, 225, 245));

  case Number_Panel_Cell::States::Initial:
   {
    QBrush qbr(QColor(255, 225, 245));
    QGraphicsRectItem* qgri = scene.addRect(center_x - (10 * scale_factor),
      center_y - (10 * scale_factor), 15, 15, Qt::NoPen, qbr);

    c.set_ri(qgri);

    qgri->setData(0, QVariant((int) Graphics_Item_Role::Background));
    qgri->setData(1, QVariant((quintptr) &c));

    qgri->setFlags(QGraphicsItem::ItemIsSelectable);

    QGraphicsSimpleTextItem* qgti = scene.addSimpleText(QString::number(c.current_number()));
    qgti->setX(center_x - (10 * scale_factor));// - scale_factor * 10);
    qgti->setY(center_y - (10 * scale_factor));// - scale_factor * 10);

    qgti->setData(0, QVariant((int) Graphics_Item_Role::Text));


    //qgti->setBrush(qbr);

   }
   break;
  case Number_Panel_Cell::States::Rotated:
   {
    QGraphicsSimpleTextItem* qgti = scene.addSimpleText(QString::number(c.current_number()));
    qgti->setX(center_x - (10 * scale_factor));
    qgti->setY(center_y - (10 * scale_factor));
   }
   break;
  default:
   break;
  }

 }
 _do;
}


void Number_Panel_Monochrome_Board::set_marked(QGraphicsRectItem* item)
{
 QBrush qbr(QColor(255, 255, 0));
 item->setBrush(qbr);

}


void Number_Panel_Monochrome_Board::init_cells()
{
 cells_.set_dimensions(14, 14);
 kf_Jagged2<int> numbers
  { 14, 15, 16, 17, 18, 19, 20, 21, 50 };

 numbers.span do_[](W_(int ,v), int i, int j, KF_CHECKED)
 {
  _KF_
  if(i == 8)
    v *= 0;
  else
    v *= i + 14;
 }
 _do;


 QVector<int> fl;
 numbers.flatten(fl);


// std::array<int,5> foo {1,2,3,4,5};
// // obtain a time-based seed:
// unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
// shuffle (foo.begin(), foo.end(), std::default_random_engine(seed));
// std::cout << "shuffled elements:";
// for (int& x: foo) std::cout << ' ' << x;
// std::cout << '\n';
// return 0;

 kf_Range2<int> r{0, 14, 0, 14};

 //kf_Range<int> shuffle_range{0, 189};
 kf_Grid1<int> indices{0, 190};


 indices.shuffle();


 kf_Pairs<int> blanks { // all to all
      {6, 7},
      {0, 6, 7, 13},
  };


 int index = 0;
 r.span do_[&blanks, &indices, &fl, &index, this](int i, int j, KF_CHECKED)
 {
  _KF_

//    ...
//    random = qrand() % number;
//    init_Number_Panel_Cells();


  //Number_Panel_Cell::States cst;

  Number_Panel_Cell& c = cells_[{i, j}];
  c.set_row(i);
  c.set_column(j);
  c.set_local_x_center(20 * j + 10);
  c.set_local_y_center(20 * i + 10);
  if(blanks.contains(i, j))
  {
   //cst = Number_Panel_Cell::Blank;
   c.set_state(Number_Panel_Cell::Blank);
  }
  else
  {
   //v = index;
   //?qDebug() << "Index: index, i, j " << index << ": " << i << " " << j;
   Number_Panel_Cell& c = cells_[{i, j}];
   int ri = indices[index];
   c.set_randomized_index(ri);
   int inum = fl[ri];
   if(inum == 0)
   {
    c.set_state(Number_Panel_Cell::Ladder);
    c.set_initial_number(inum);
    c.set_current_number(inum);
   }
   else
   {
    c.set_state(Number_Panel_Cell::Initial);
    c.set_initial_number(inum);
    c.set_current_number(inum);
   }
   ++index;
  }
  //++index;

//  if( (j == 6) || (j == 7) )
//  {
//   if( (i == 0) || (i == 1) || (i == 1) )
//  }

 }_do;



}


Number_Panel_Cell* Number_Panel_Monochrome_Board::get_cell(int i, int j)
{
 return &cells_.operator[]({i, j});
}



int Number_Panel_Monochrome_Board::get_number_at_cell(int i, int j)
{

}

Number_Panel_Cell::States Number_Panel_Monochrome_Board::get_state_at_cell(int i, int j)
{

}

