
#ifndef NUMBER_PANEL_MONOCHROME_BOARD__H
#define NUMBER_PANEL_MONOCHROME_BOARD__H

#include "koftl/koftl-grid.h"
#include "koftl/koftl-jackets.h"

#include <QGraphicsScene>

#include "number-panel-cell.h"

class Number_Panel_Fixed_Frame;

class Number_Panel_Monochrome_Board
{
//public:
// struct Cell
// {
//  enum States {
//   N_A, Blank, Ladder, Initial, Rotated
//  };

//  int row;
//  int column;

//  int randomized_index;
//  int current_number;
//  int initial_number;
//  float local_x_center;
//  float local_y_center;
//  States state;
//  mutable QGraphicsRectItem* ri;
// };

private:

 kf_Grid2<Number_Panel_Cell> cells_;

 void get_cell(int i, int j, W_(Number_Panel_Cell ,c));

 QGraphicsRectItem* selected_item_;

 QList<Number_Panel_Fixed_Frame*> frames_;

 QString frame_report_;

 QGraphicsSimpleTextItem* frame_report_item_;

 int current_cluster_index_;
 int current_scoring_run_;

 QMap<int, QSet<Number_Panel_Cell*>> clusters_by_index_;

public:

 enum class Graphics_Item_Role {
   N_A, Text, Background, Ladder, Boundary
 };

 Number_Panel_Monochrome_Board();

 int get_number_at_cell(int i, int j);
 Number_Panel_Cell::States get_state_at_cell(int i, int j);

 Number_Panel_Cell* get_cell(int i, int j);

 void init_cells();
 void draw_to_scene(QGraphicsScene& scene, float scale_factor);

 void set_marked(QGraphicsRectItem* item);

 void handle_scene_selection_changed(QGraphicsView& view, QGraphicsScene& scene);

 void handle_right_click(const QPoint& p, QGraphicsView& view);
 void handle_left_click(const QPoint& p, QGraphicsView& view);

 void get_items_at_point(const QGraphicsView& view, const QPoint& p, QGraphicsRectItem*& bkg,
   QGraphicsSimpleTextItem*& txt);

 void get_items(const QList<QGraphicsItem*>& items, QGraphicsRectItem*& bkg,
   QGraphicsSimpleTextItem*& txt);

 void handle_select(QGraphicsItem* item);

 void add_frame(Number_Panel_Cell* tl, Number_Panel_Cell* br);

 inline int max_bottom_right_x()
 {
  return 13;
 }

 inline int max_bottom_right_y()
 {
  return 13;
 }


 void update_frame_report();
//   int logical_top_left_x, int logical_top_left_y,
//   int logical_bottom_right_x, int logical_bottom_right_y;
};



#endif
