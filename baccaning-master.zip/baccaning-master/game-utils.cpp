
#include "game-utils.h"

#include "logic/game-panel-board.h"
#include "logic/game-panel-section.h"
#include "logic/game-position.h"
#include "logic/stone-panel-display.h"

#include <QDebug>


Game_Utils::Game_Utils()
{

}


void Game_Utils::move_stone_to_its_position(Stone_Panel_Display* spd)
{
#ifdef HIDE
 if(Game_Position* pos = spd->position())
 {
  switch(pos->variant())
  {
  case Game_Position::Variant::NW:
   spd->set_section(pos->get_section());
   spd->set_direction_status(Stone_Panel_Display::Direction_Status::Panel_NW);
   break;
  case Game_Position::Variant::NE:
   spd->set_section(pos->get_section());
   spd->set_direction_status(Stone_Panel_Display::Direction_Status::Panel_NE);
   break;
  case Game_Position::Variant::SE:
   spd->set_section(pos->get_section());
   spd->set_direction_status(Stone_Panel_Display::Direction_Status::Panel_SE);
   break;
  case Game_Position::Variant::SW:
   spd->set_section(pos->get_section());
   spd->set_direction_status(Stone_Panel_Display::Direction_Status::Panel_SW);
   break;
  }
 }
#endif
}

