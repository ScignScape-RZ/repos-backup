
#ifndef GAME_UTILS__H
#define GAME_UTILS__H

#include <QVector>

class Game_Position;
class Game_Panel_Board;
class Stone_Panel_Display;

class Game_Utils
{
public:

 Game_Utils();

 //?void init_c8_positions(QVector<Game_Position*>& vec, Game_Panel_Board& board);
 void move_stone_to_its_position(Stone_Panel_Display* spd);

};

#endif
