
#include "baccaning-game-capture.h"

#include "logic/stone-panel-display.h"

Baccaning_Game_Capture::Baccaning_Game_Capture(
  Stone_Panel_Display* capturing_stone,
  Stone_Panel_Display* captured_stone,
  int move_number )
 :  capturing_stone_(capturing_stone),
    captured_stone_(captured_stone),
    move_number_(move_number)
{
}

Baccaning_Game_Capture* Baccaning_Game_Capture::valid_non_capture_move()
{
 static Baccaning_Game_Capture* result = new Baccaning_Game_Capture
    (nullptr, nullptr, 0);
 return result;
}


QString Baccaning_Game_Capture::get_captured_stone_informal_label()
{
 if(captured_stone_)
 {
  return captured_stone_->informal_label();
 }
 else
 {
  return QString();
 }
}
