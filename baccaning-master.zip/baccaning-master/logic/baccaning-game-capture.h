
#ifndef BACCANING_GAME_CAPTURE__H
#define BACCANING_GAME_CAPTURE__H


#include "../accessors.h"

#include "flags.h"

#include <QString>


class Stone_Panel_Display;


class Baccaning_Game_Capture
{
 Stone_Panel_Display* capturing_stone_;
 Stone_Panel_Display* captured_stone_;

 int move_number_;


public:

 Baccaning_Game_Capture(
   Stone_Panel_Display* capturing_stone,
   Stone_Panel_Display* captured_stone,
   int move_number);

 ACCESSORS(Stone_Panel_Display* ,capturing_stone)
 ACCESSORS(Stone_Panel_Display* ,captured_stone)
 ACCESSORS(int ,move_number)

 static Baccaning_Game_Capture* valid_non_capture_move();

 QString get_captured_stone_informal_label();
};

#endif
