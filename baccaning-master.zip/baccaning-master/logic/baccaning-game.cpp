
#include "baccaning-game.h"

#include "paraviews/select-stone-dialog.h"

#include "game-panel-board.h"
#include "game-panel-gridline-intersection.h"
#include "logic/game-panel-section.h"
#include "logic/baccaning-game-capture.h"

Baccaning_Game::Baccaning_Game(Select_Stone_Dialog* select_stone_dialog)
 : Flags(0), select_stone_dialog_(select_stone_dialog), current_game_player_(nullptr),
   north_player_(nullptr), south_player_(nullptr), current_turn_(0)
{
}

void Baccaning_Game::increment_turn()
{
 ++current_turn_;
}

void Baccaning_Game::start_game()
{
 current_turn_ = 1;
}


void Baccaning_Game::analyze_guard_move(Stone_Panel_Display* spd,
  Game_Panel_Section* old_section, Game_Panel_Section* new_section)
{
 QList<Stone_Panel_Display*> old_neighbors;

 board_->get_guard_neighbors(old_section, old_neighbors);

 for(Stone_Panel_Display* neighbor : old_neighbors)
 {
  if(neighbor->is_submarine())
  {
   //  subs will remain subs here ...
  }
  else
  {
   QList<Stone_Panel_Display*> neighbor_neighbors;
   board_->get_guard_neighbors(neighbor, neighbor_neighbors);
   if(neighbor_neighbors.size() == 1)
   {
    //  i.e. spd is only neighbor_neighbor
    if(board_->is_not_adjacent(neighbor, new_section))
    {
     neighbor->make_onside_submarine();
    }
   }
  }
 }

 if(!board_->stone_is_onside_at_section(spd, new_section))
 {
  spd->make_submarine();
 }


}


Baccaning_Game_Capture* Baccaning_Game::check_move_or_capture(
  Stone_Panel_Display* spd, Game_Panel_Gridline_Intersection* intersection)
{
 Stone_Panel_Display* captured = intersection->current_stone();
 if(captured)
 {
  return new Baccaning_Game_Capture(spd, captured, current_turn_);
 }
 else
 {
  return Baccaning_Game_Capture::valid_non_capture_move();
 }
}


Baccaning_Game_Capture* Baccaning_Game::check_move_or_capture(
  Stone_Panel_Display* spd, Game_Panel_Section* section)
{
 Stone_Panel_Display* captured = section->get_center_stone();
 if(captured)
 {
  return new Baccaning_Game_Capture(spd, captured, current_turn_);
 }
 else
 {
  return Baccaning_Game_Capture::valid_non_capture_move();
 }
}

Game_Player* Baccaning_Game::current_player_is_south()
{
 if(current_game_player_ == south_player_)
   return current_game_player_;
 return nullptr;
}

Game_Player* Baccaning_Game::current_player_is_north()
{
 if(current_game_player_ == north_player_)
   return current_game_player_;
 return nullptr;
}

void Baccaning_Game::switch_players()
{
 if(current_game_player_)
 {
  if(current_game_player_ == south_player_)
  {
   current_game_player_ = north_player_;
   select_stone_dialog_->set_player_north();
  }
  else
  {
   current_game_player_ = south_player_;
   select_stone_dialog_->set_player_south();
  }
 }
 else
 {
  current_game_player_ = south_player_;
  select_stone_dialog_->set_player_south();
 }
}
