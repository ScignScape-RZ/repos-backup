
#ifndef BACCANING_GAME__H
#define BACCANING_GAME__H


class Game_Panel_Gridline_Edge;
class Game_Panel_Gridline_Intersection;
class Game_Panel_Section;
class Stone_Panel_Display;


#include "../accessors.h"

#include "flags.h"

#include <QString>


class Game_Player;
class Select_Stone_Dialog;
class Game_Panel_Board;
class Game_Panel_Gridline_Intersection;
class Baccaning_Game_Capture;

class Baccaning_Game
{

public:

 flags_(1)
  bool solitaire_mode:1;
  bool puzzle_mode:1;
  bool challenge_mode:1;
  bool referee_mode:1;
 _flags

// enum class Modes {
//  N_A, Solitaire_Puzzle, Puzzle_South, Puzzle_North, Puzzle_Referee,
//  Board_Game_South, Board_Game_North, Board_Game_Referee,
//  Challenge_South, Challenge_North, Challenge_Referee
// };

private:

 Game_Player* south_player_;
 Game_Player* north_player_;

 Game_Player* current_game_player_;

 Select_Stone_Dialog* select_stone_dialog_;

 Game_Panel_Board* board_;

 int current_turn_;

public:

 Baccaning_Game(Select_Stone_Dialog* select_stone_dialog);

 ACCESSORS(Game_Player* ,south_player)
 ACCESSORS(Game_Player* ,north_player)
 ACCESSORS(Game_Player* ,current_game_player)
 ACCESSORS(Game_Panel_Board* ,board)


 void switch_players();

 Game_Player* current_player_is_south();
 Game_Player* current_player_is_north();

 void increment_turn();
 void start_game();

 void analyze_guard_move(Stone_Panel_Display* spd,
   Game_Panel_Section* old_section,
   Game_Panel_Section* new_section);


 Baccaning_Game_Capture* check_move_or_capture(Stone_Panel_Display* spd,
   Game_Panel_Section* section);

 Baccaning_Game_Capture* check_move_or_capture(Stone_Panel_Display* spd,
   Game_Panel_Gridline_Intersection* intersection);

};

#endif
