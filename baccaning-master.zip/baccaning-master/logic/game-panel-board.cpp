

#include "game-panel-board.h"

#include "game-panel-section.h"

#include "stone-panel-display.h"

#include "game-panel-gridline-intersection.h"
#include "game-panel-vertical-gridline.h"
#include "game-panel-horizontal-gridline.h"

#include "game-panel-diagonal-gridline.h"

#include "logic/baccaning-game.h"
#include "logic/baccaning-game-capture.h"

#include <QMessageBox>
#include <QtGlobal>

#include <QGraphicsView>

#include <QGraphicsItem>

#include "logic/game-player.h"

#include "game-panel-colors.h"

#include "game-position.h"

#include "game-panel-gridline-edge.h"

#include "game-utils.h"

#include <QGraphicsView>

#include <QDebug>




void Game_Panel_Board::reset_stone_position_after_move(Stone_Panel_Display* spd)
{
#ifdef HIDE
 Game_Position* pos = spd->position();
 if(pos)
 {
  pos->set_stone(spd);
 }
 else
 {
  Game_Panel_Section* section = spd->section();
  switch(spd->direction_status())
  {
  case Stone_Panel_Display::Direction_Status::Panel_Center_Doubled_Top:
   pos = section->center_game_position();
   spd->set_position(pos);
   section->set_doubled_top(spd);
   break;

  case Stone_Panel_Display::Direction_Status::Panel_Center:
   pos = section->center_game_position();
   pos->set_stone(spd);
   spd->set_position(pos);
   break;
  case Stone_Panel_Display::Direction_Status::Panel_NW:
   pos = section->get_game_position_nw();
   pos->set_stone(spd);
   spd->set_position(pos);
   break;
  case Stone_Panel_Display::Direction_Status::Panel_NE:
   pos = section->get_game_position_ne();
   pos->set_stone(spd);
   spd->set_position(pos);
   break;
  case Stone_Panel_Display::Direction_Status::Panel_SW:
   pos = section->get_game_position_sw();
   pos->set_stone(spd);
   spd->set_position(pos);
   break;
  case Stone_Panel_Display::Direction_Status::Panel_SE:
   pos = section->get_game_position_se();
   pos->set_stone(spd);
   spd->set_position(pos);
   break;

  default:
   //?
   break;

  }

 }
 //? //? //?
#endif
}

void Game_Panel_Board::trace_stone(QString key)
{
 Stone_Panel_Display* result = get_stone_by_key(key);
 QGraphicsItem* item = result->get_graphics_item();
 if(item)
 {
  traced_stones_[item] = result;
  item->setData(1, QVariant("Trace"));
 }
}

Stone_Panel_Display* Game_Panel_Board::get_traced_stone(QGraphicsItem* item)
{
 return traced_stones_.value(item, nullptr);
}


Stone_Panel_Display* Game_Panel_Board::set_stone_at_position(int section_x,
  int section_y, QString key, Stone_Panel_Display::Direction_Status ds)
{
 //Game_Panel_Section* section = get_section(section_y, section_x);
 Stone_Panel_Display* result = get_stone_by_key(key);
 set_stone_at_position(section_x, section_y, result, ds);

 return result;
}


void Game_Panel_Board::mark_section_center_occupied(int section_x,
  int section_y, Stone_Panel_Display* spd)
{
 Game_Panel_Section* section = get_section(section_y, section_x);
 section->set_center_stone(spd);
}


void Game_Panel_Board::set_stone_at_position(int section_x,
  int section_y, Stone_Panel_Display* spd, Stone_Panel_Display::Direction_Status ds)
{
 Game_Panel_Section* section = get_section(section_y, section_x);
 //?result->set_current_value(value);
 spd->move_to_section(section, ds);
 reset_stone_position_after_move(spd);
}


Stone_Panel_Display* Game_Panel_Board::set_stone_at_intersection(int grid_x,
  int grid_y, QString key)
{
 Game_Panel_Gridline_Intersection* gpgi = get_gridline_intersection(grid_x, grid_y);
 Stone_Panel_Display* result = get_stone_by_key(key);

 //?result->set_current_value(value);
 result->move_to_intersection(gpgi);
 reset_stone_position_after_move(result);

 return result;

}



void Game_Panel_Board::init_stones()
{
#ifdef HIDE
 int stone_index = 0;
 stones_.resize(1018 + 706*2);
 stones_.push_back(nullptr);
 Stone_Panel_Display* spd;

 //G1
 for(int i = 0; i < 28; ++i)
 {
  stone_keys_index_[QString("G1-%1").arg(i + 1)] = stone_index + 1;
  for(int j = 0; j <= i; ++j)
  {
   ++stone_index;
   spd = new Stone_Panel_Display(
     Stone_Panel_Display::Team_Status::South_G1, i + 1, j, stone_index);
   stones_[stone_index] = spd;

   ++stone_index;
   spd = new Stone_Panel_Display(
     Stone_Panel_Display::Team_Status::North_G1, i + 1, j, stone_index);
   stones_[stone_index] = spd;
  }
 }

 //G2
 for(int i = 0; i < 24; ++i)
 {
  stone_keys_index_[QString("G2-%1").arg(i)] = stone_index + 1;
  for(int j = 0; j < i; ++j)
  {
   ++stone_index;
   spd = new Stone_Panel_Display(
     Stone_Panel_Display::Team_Status::South_G2, i, j, stone_index);
   stones_[stone_index] = spd;

   ++stone_index;
   spd = new Stone_Panel_Display(
     Stone_Panel_Display::Team_Status::North_G2, i, j, stone_index);
   stones_[stone_index] = spd;
  }
 }



 //D2
 stone_keys_index_["D2"] = stone_index + 1;
 for(int i = 0; i < 225; ++i)
 {
  ++stone_index;
  spd = new Stone_Panel_Display(
    Stone_Panel_Display::Team_Status::South_D2, 2, i, stone_index);
  stones_[stone_index] = spd;
  stone_keys_[QString("S-D2-%1").arg(i)] = spd;

  ++stone_index;
  spd = new Stone_Panel_Display(
    Stone_Panel_Display::Team_Status::North_D2, 2, i, stone_index);
  stones_[stone_index] = spd;
  stone_keys_[QString("N-D2-%1").arg(i)] = spd;
 }

 //D3
 stone_keys_index_["D3"] = stone_index + 1;
 for(int i = 0; i < 3; ++i)
 {
  ++stone_index;
  spd = new Stone_Panel_Display(
    Stone_Panel_Display::Team_Status::South_D3, 3, i, stone_index);
  stones_[stone_index] = spd;
  stone_keys_[QString("S-D3-%1").arg(i)] = spd;

  ++stone_index;
  spd = new Stone_Panel_Display(
    Stone_Panel_Display::Team_Status::North_D3, 3, i, stone_index);
  stones_[stone_index] = spd;
  stone_keys_[QString("N-D3-%1").arg(i)] = spd;
 }

 //D4
 stone_keys_index_["D4"] = stone_index + 1;
 for(int i = 0; i < 70; ++i)
 {
  ++stone_index;
  spd = new Stone_Panel_Display(
    Stone_Panel_Display::Team_Status::South_D4, 4, i, stone_index);
  stones_[stone_index] = spd;
  spd->resize_extras(1);
  stone_keys_[QString("S-D4-%1").arg(i)] = spd;

  ++stone_index;
  spd = new Stone_Panel_Display(
    Stone_Panel_Display::Team_Status::North_D4, 4, i, stone_index);
  spd->resize_extras(1);
  stones_[stone_index] = spd;
  stone_keys_[QString("N-D4-%1").arg(i)] = spd;
 }

 //D5
 stone_keys_index_["D5"] = stone_index + 1;
 for(int i = 0; i < 2; ++i)
 {
  ++stone_index;
  spd = new Stone_Panel_Display(
    Stone_Panel_Display::Team_Status::South_D5, 5, i, stone_index);
  stones_[stone_index] = spd;
  stone_keys_[QString("S-D5-%1").arg(i)] = spd;

  ++stone_index;
  spd = new Stone_Panel_Display(
    Stone_Panel_Display::Team_Status::North_D5, 5, i, stone_index);
  stones_[stone_index] = spd;
  stone_keys_[QString("N-D5-%1").arg(i)] = spd;
 }

 //C6
 stone_keys_index_["C6"] = stone_index + 1;
 for(int i = 0; i < 59; ++i)
 {
  ++stone_index;
  spd = new Stone_Panel_Display(
    Stone_Panel_Display::Team_Status::South_C6, 6, i, stone_index);


  spd->resize_extras(5);
  spd->set_current_value(6);
  stones_[stone_index] = spd;
  stone_keys_[QString("S-C6-%1").arg(i)] = spd;

  ++stone_index;
  spd = new Stone_Panel_Display(
    Stone_Panel_Display::Team_Status::North_C6, 6, i, stone_index);
  spd->resize_extras(5);
  spd->set_current_value(6);
  stones_[stone_index] = spd;
  stone_keys_[QString("N-C6-%1").arg(i)] = spd;
 }

 //D7
 stone_keys_index_["D7"] = stone_index + 1;
 for(int i = 0; i < 3; ++i)
 {
  ++stone_index;
  spd = new Stone_Panel_Display(
    Stone_Panel_Display::Team_Status::South_D7, 7, i, stone_index);
  stones_[stone_index] = spd;

  ++stone_index;
  spd = new Stone_Panel_Display(
    Stone_Panel_Display::Team_Status::North_D7, 7, i, stone_index);
  stones_[stone_index] = spd;
 }

 //D8D
 stone_keys_index_["D8D"] = stone_index + 1;
 for(int i = 0; i < 8; ++i)
 {
  ++stone_index;
  spd = new Stone_Panel_Display(
    Stone_Panel_Display::Team_Status::South_D8D, 8, i, stone_index);
  stones_[stone_index] = spd;

  ++stone_index;
  spd = new Stone_Panel_Display(
    Stone_Panel_Display::Team_Status::North_D8D, 8, i, stone_index);
  stones_[stone_index] = spd;
 }

 //D8R
 stone_keys_index_["D8R"] = stone_index + 1;
 for(int i = 0; i < 8; ++i)
 {
  ++stone_index;
  spd = new Stone_Panel_Display(
    Stone_Panel_Display::Team_Status::South_D8R, 8, i, stone_index);
  stones_[stone_index] = spd;

  ++stone_index;
  spd = new Stone_Panel_Display(
    Stone_Panel_Display::Team_Status::North_D8R, 8, i, stone_index);
  stones_[stone_index] = spd;
 }


 QVector<Game_Position*> c8_positions;
 utils_.init_c8_positions(c8_positions, *this);

 //C8
 stone_keys_index_["C8"] = stone_index + 1;
 for(int i = 0; i < 62; ++i)
 {
  ++stone_index;
  spd = new Stone_Panel_Display(
    Stone_Panel_Display::Team_Status::South_C8, 8, i, stone_index);
  spd->resize_extras(7);
  spd->set_current_value(7);
  stones_[stone_index] = spd;
  stone_keys_[QString("S-C8-%1").arg(i)] = spd;
  //?spd->check_init_graphic(scene);

  ++stone_index;
  spd = new Stone_Panel_Display(
    Stone_Panel_Display::Team_Status::North_C8, 8, i, stone_index);
  spd->resize_extras(7);
  spd->set_current_value(8);
  stones_[stone_index] = spd;
  stone_keys_[QString("N-C8-%1").arg(i)] = spd;

  //?spd->check_init_graphic(scene);


 }



 //  c8 positions sides
 for(int i = 0; i < 16; ++i)
 {
  QString lskey = QString("S-C8-%1").arg(i);
  QString lnkey = QString("N-C8-%1").arg(i);

  QString rskey = QString("S-C8-%1").arg(i + 16);
  QString rnkey = QString("N-C8-%1").arg(i + 16);

  Game_Position* posls;
  Game_Position* posrs;
  Game_Position* posln;
  Game_Position* posrn;
  if(i == 0)
  {
   posls = c8_positions[2];
   posln = c8_positions[0];
   posrs = c8_positions[34];
   posrn = c8_positions[32];
  }
  else if(i == 15)
  {
   posls = c8_positions[31];
   posln = c8_positions[29];
   posrs = c8_positions[63];
   posrn = c8_positions[61];

  }
  else
  {
   posls = c8_positions[2 * i + 2];
   posln = c8_positions[2 * i - 1];
   posrs = c8_positions[2 * i + 34];
   posrn = c8_positions[2 * i + 31];
  }

//  if(i == 15)
//  {
//   continue;
//  }

  Stone_Panel_Display* spdls = get_stone_by_key(lskey);
  Stone_Panel_Display* spdln = get_stone_by_key(lnkey);

  Stone_Panel_Display* spdrs = get_stone_by_key(rskey);
  Stone_Panel_Display* spdrn = get_stone_by_key(rnkey);

  posls->set_stone(spdls);
  spdls->set_position(posls);
  spdls->set_current_value(8);
  utils_.move_stone_to_its_position(spdls);

  posln->set_stone(spdln);
  spdln->set_position(posln);
  spdln->set_current_value(8);
  utils_.move_stone_to_its_position(spdln);

//  if(i != 15)
//  {

  posrs->set_stone(spdrs);
  spdrs->set_position(posrs);
  spdrs->set_current_value(8);
  utils_.move_stone_to_its_position(spdrs);

//  }

  posrn->set_stone(spdrn);
  spdrn->set_position(posrn);
  spdrn->set_current_value(8);
  utils_.move_stone_to_its_position(spdrn);

 }

 //  c8 positions S
 for(int i = 0; i < 30; ++i)
 {
  QString key = QString("S-C8-%1").arg(i + 32);
  Game_Position* pos = c8_positions[i + 94];
  Stone_Panel_Display* spd = get_stone_by_key(key);
  pos->set_stone(spd);
  spd->set_position(pos);
  spd->set_current_value(8);
  utils_.move_stone_to_its_position(spd);
 }

 //  c8 positions N
 for(int i = 0; i < 30; ++i)
 {
  QString key = QString("N-C8-%1").arg(i + 32);
  Game_Position* pos = c8_positions[i + 64];
  Stone_Panel_Display* spd = get_stone_by_key(key);
  pos->set_stone(spd);
  spd->set_position(pos);
  spd->set_current_value(8);
  utils_.move_stone_to_its_position(spd);
 }

 //D12
 stone_keys_index_["D12F"] = stone_index + 1;
 stone_keys_index_["D12G"] = stone_index + 13;
 for(int i = 0; i < 12; ++i)
 {
  switch (i)
  {
  case 0:
  case 2:
  case 4:
   ++stone_index;
   spd = new Stone_Panel_Display(
     Stone_Panel_Display::Team_Status::South_D12F, 12, i, stone_index);
   spd->resize_extras(1);
   spd->set_extra(12);
   stones_[stone_index] = spd;

   ++stone_index;
   spd = new Stone_Panel_Display(
     Stone_Panel_Display::Team_Status::North_D12F, 12, i, stone_index);
   spd->resize_extras(1);
   spd->set_extra(12);
   stones_[stone_index] = spd;
   break;
  case 1:
  case 3:
  case 5:
   ++stone_index;
   spd = new Stone_Panel_Display(
     Stone_Panel_Display::Team_Status::South_D12F, 12, i, stone_index);
   spd->resize_extras(1);
   spd->set_extra(24);
   stones_[stone_index] = spd;

   ++stone_index;
   spd = new Stone_Panel_Display(
     Stone_Panel_Display::Team_Status::North_D12F, 12, i, stone_index);
   spd->resize_extras(1);
   spd->set_extra(24);
   stones_[stone_index] = spd;
   break;
  case 6:
  case 8:
  case 10:
   ++stone_index;
   spd = new Stone_Panel_Display(
     Stone_Panel_Display::Team_Status::South_D12G, 12, i, stone_index);
   spd->resize_extras(1);
   spd->set_extra(12);
   stones_[stone_index] = spd;

   ++stone_index;
   spd = new Stone_Panel_Display(
     Stone_Panel_Display::Team_Status::North_D12G, 12, i, stone_index);
   spd->resize_extras(1);
   spd->set_extra(12);
   stones_[stone_index] = spd;

   break;
  case 7:
  case 9:
  case 11:
   ++stone_index;
   spd = new Stone_Panel_Display(
     Stone_Panel_Display::Team_Status::South_D12G, 12, i, stone_index);
   spd->resize_extras(1);
   spd->set_extra(24);
   stones_[stone_index] = spd;

   ++stone_index;
   spd = new Stone_Panel_Display(
     Stone_Panel_Display::Team_Status::North_D12G, 12, i, stone_index);
   spd->resize_extras(1);
   spd->set_extra(24);
   stones_[stone_index] = spd;

   break;

  }
 }

 //D14
 stone_keys_index_["D14F"] = stone_index + 1;
 stone_keys_index_["D14G"] = stone_index + 13;
 for(int i = 0; i < 14; ++i)
 {
  switch (i)
  {
  case 0:
  case 2:
  case 4:
   ++stone_index;
   spd = new Stone_Panel_Display(
     Stone_Panel_Display::Team_Status::South_D14F, 14, i, stone_index);
   spd->resize_extras(1);
   spd->set_extra(12);
   stones_[stone_index] = spd;

   ++stone_index;
   spd = new Stone_Panel_Display(
     Stone_Panel_Display::Team_Status::North_D14F, 14, i, stone_index);
   spd->resize_extras(1);
   spd->set_extra(12);
   stones_[stone_index] = spd;
   break;
  case 1:
  case 3:
  case 5:
   ++stone_index;
   spd = new Stone_Panel_Display(
     Stone_Panel_Display::Team_Status::South_D14F, 14, i, stone_index);
   spd->resize_extras(1);
   spd->set_extra(24);
   stones_[stone_index] = spd;

   ++stone_index;
   spd = new Stone_Panel_Display(
     Stone_Panel_Display::Team_Status::North_D14F, 14, i, stone_index);
   spd->resize_extras(1);
   spd->set_extra(24);
   stones_[stone_index] = spd;
   break;
  case 6:
  case 8:
  case 10:
  case 12:
   ++stone_index;
   spd = new Stone_Panel_Display(
     Stone_Panel_Display::Team_Status::South_D14G, 14, i, stone_index);
   spd->resize_extras(1);
   spd->set_extra(14);
   stones_[stone_index] = spd;

   ++stone_index;
   spd = new Stone_Panel_Display(
     Stone_Panel_Display::Team_Status::North_D14G, 14, i, stone_index);
   spd->resize_extras(1);
   spd->set_extra(14);
   stones_[stone_index] = spd;

   break;
  case 7:
  case 9:
  case 11:
  case 13:
   ++stone_index;
   spd = new Stone_Panel_Display(
     Stone_Panel_Display::Team_Status::South_D14G, 14, i, stone_index);
   spd->resize_extras(1);
   spd->set_extra(28);
   stones_[stone_index] = spd;

   ++stone_index;
   spd = new Stone_Panel_Display(
     Stone_Panel_Display::Team_Status::North_D14G, 14, i, stone_index);
   spd->resize_extras(1);
   spd->set_extra(28);
   stones_[stone_index] = spd;

   break;

  }
 }


 //C20L
 stone_keys_index_["C20L"] = stone_index + 1;
 for(int i = 0; i < 19; ++i)
 {
  ++stone_index;
  spd = new Stone_Panel_Display(
    Stone_Panel_Display::Team_Status::South_C20L, 20, i, stone_index);
  spd->resize_extras(19);
  spd->set_current_value(20);
  stones_[stone_index] = spd;

  ++stone_index;
  spd = new Stone_Panel_Display(
    Stone_Panel_Display::Team_Status::North_C20L, 20, i, stone_index);
  spd->resize_extras(19);
  spd->set_current_value(20);
  stones_[stone_index] = spd;
 }

 //C20R
 stone_keys_index_["C20R"] = stone_index + 1;
 for(int i = 0; i < 19; ++i)
 {
  ++stone_index;
  spd = new Stone_Panel_Display(
    Stone_Panel_Display::Team_Status::South_C20R, 20, i, stone_index);
  spd->resize_extras(19);
  spd->set_current_value(20);
  stones_[stone_index] = spd;

  ++stone_index;
  spd = new Stone_Panel_Display(
    Stone_Panel_Display::Team_Status::North_C20R, 20, i, stone_index);
  spd->resize_extras(19);
  spd->set_current_value(20);
  stones_[stone_index] = spd;
 }

 //C60
 stone_keys_index_["C60"] = stone_index + 1;
 for(int i = 0; i < 5; ++i)
 {
  ++stone_index;
  spd = new Stone_Panel_Display(
    Stone_Panel_Display::Team_Status::South_C60, 60, i, stone_index);
  spd->resize_extras(59);
  spd->set_current_value(60);
  stones_[stone_index] = spd;

  ++stone_index;
  spd = new Stone_Panel_Display(
    Stone_Panel_Display::Team_Status::North_C60, 60, i, stone_index);
  spd->resize_extras(59);
  spd->set_current_value(60);
  stones_[stone_index] = spd;
 }

 //D80
 stone_keys_index_["D80"] = stone_index + 1;
 ++stone_index;
 spd = new Stone_Panel_Display(
   Stone_Panel_Display::Team_Status::South_D80, 80, 0, stone_index);
 stones_[stone_index] = spd;

 ++stone_index;
 spd = new Stone_Panel_Display(
   Stone_Panel_Display::Team_Status::North_D80, 80, 0, stone_index);
 stones_[stone_index] = spd;

 qDebug() << stone_index;

#endif
}


int Game_Panel_Board::get_ring(int i, int j, int center, int offset)
{
 if(i <= center)
 {
  i = center - i;
 }
 else
 {
  i -= (center + offset);
 }

 if(j <= center)
 {
  j = center - j;
 }
 else
 {
  j -= (center + offset);
 }

 if(i > j)
 {
  return (i + 1) * 2;
 }
 else
 {
  return (j + 1) * 2;
 }

}

Stone_Panel_Display* Game_Panel_Board::get_stone_by_key(QString key, int offset)
{
 return stones_.value(key);
 //return stone_keys_.value(key);

#ifdef HIDE
 QChar team = key[0];

 int pos = key.indexOf('-', 2);
 QString kind = key.mid(2, pos - 2);
 QString index = key.mid(pos + 1);
 int ind;
 if(kind == "G1")
 {
  pos = index.indexOf('-');
  int g = index.mid(0, pos).toInt() + offset;
  ind = index.mid(pos + 1).toInt();
  kind.append(QString("-%1").arg(g));
 }
 else if(kind == "G2")
 {
  pos = index.indexOf('-');
  int g = index.mid(0, pos).toInt() + offset;
  ind = index.mid(pos + 1).toInt();
  kind.append(QString("-%1").arg(g));
 }
 else if(kind == "D12F" || kind == "D12G"
         || kind == "D14F" || kind == "D14G")
 {
  ind = index.mid(2).toInt() + offset;
  if(index[0] == 'H')
   ++ind;
 }
// else if(kind == "D12G")
// {

// }
// else if(kind == "D14F")
// {

// }
// else if(kind == "D14G")
// {

// }
 else
 {
  ind = index.toInt() + offset;
 }
 int base_index = stone_keys_index_[kind];
 if(team == 'N')
   ++base_index;
 base_index += 2 * ind;
 Stone_Panel_Display* result = stones_[base_index];
 return result;
#endif
}

void Game_Panel_Board::handle_stone_moved_to_intersection(int x, int y, Stone_Panel_Display* spd,
  QGraphicsScene& scene, float scale_factor)
{
 Stone_Panel_Display::Direction_Status ds;
 Game_Panel_Section* section;
 Game_Panel_Gridline_Intersection* intersection;

//?
 QString posd = get_position_description_from_intersection_coordinates(
   spd, section, intersection, ds, x, y);

// QString posd = get_position_description(
//   spd, section, intersection, ds, x, y);

 if(intersection)
 {
  Baccaning_Game_Capture* cap = game_->check_move_or_capture(spd, intersection);
  if(cap)
  {
   // // i.e., a real capture
   if(cap->captured_stone())
   {
    int ret = QMessageBox::warning(nullptr, "Confirm Capture",
      QString("Capture the %1?").arg(cap->get_captured_stone_informal_label()),
      QMessageBox::Yes | QMessageBox::No);
    if(ret != QMessageBox::Yes)
    {
     // // what else?
     draw_to_scene(scene, scale_factor);
     return;
    }
    cap->captured_stone()->remove_from_board();
   }
   confirm_move_stone(spd, intersection, ds);

   intersection->set_current_stone(spd);

   draw_to_scene(scene, scale_factor);
   //gpb.place_current_selected_stone(intersection, ds);
  }
  else
  {
   confirm_move_stone(spd, intersection, ds);
   intersection->set_current_stone(spd);
   draw_to_scene(scene, scale_factor);
  }
 }

 else if(section)
 {
  Baccaning_Game_Capture* cap = game_->check_move_or_capture(spd, section);
  if(cap)
  {
   // // i.e., a real capture
   if(cap->captured_stone())
   {
    int ret = QMessageBox::warning(nullptr, "Confirm Capture",
      QString("Capture the %1?").arg(cap->get_captured_stone_informal_label()),
      QMessageBox::Yes | QMessageBox::No);

    if(ret != QMessageBox::Yes)
    {
     // //?
     draw_to_scene(scene, scale_factor);
     return;
    }
    cap->captured_stone()->remove_from_board();
   }
   confirm_move_stone(spd, section, ds);
   draw_to_scene(scene, scale_factor);
  }
 }
}

bool Game_Panel_Board::is_not_adjacent(Stone_Panel_Display* spd, Game_Panel_Section* section)
{
 return is_not_adjacent(spd->section(), section);
}

bool Game_Panel_Board::is_not_adjacent(Game_Panel_Section* s1, Game_Panel_Section* s2)
{
 int xabs = qAbs(s1->index_x() - s2->index_x());
 if(xabs > 1)
  return true;

 int yabs = qAbs(s1->index_y() - s2->index_y());
 if(yabs > 1)
  return false;

 return true;
}

void Game_Panel_Board::get_guard_neighbors(Stone_Panel_Display* spd,
  QList<Stone_Panel_Display*>& result)
{
 get_guard_neighbors(spd->section(), result);
}

void Game_Panel_Board::get_guard_neighbors(Game_Panel_Section* section,
  QList<Stone_Panel_Display*>& result)
{
 int x_max = 7;
 int y_max = 8;

 for(int i = qMax(0, section->index_x() - 1);
     i <= qMin(x_max, section->index_x() + 1);
     ++i)
 {
  for(int j = qMax(0, section->index_y() - 1);
      j <= qMin(y_max, section->index_y() + 1);
      ++j)
  {
   if((i == section->index_x()) && (j == section->index_y()))
   {
    continue;
   }
   Game_Panel_Section* s = get_section(i, j);
   Stone_Panel_Display* spd = s->get_center_stone();
   if(spd)
   {
    if(spd->is_guard())
     result.push_back(spd);
   }
  }
 }
}


bool Game_Panel_Board::stone_is_onside_at_section(Stone_Panel_Display* spd,
  Game_Panel_Section* section)
{
 if(spd->is_north())
 {
  return section->index_y() < 4;
 }
 return section->index_y() > 5;
}

void Game_Panel_Board::handle_stone_moved_to_section_center(int x, int y, Stone_Panel_Display* spd,
  QGraphicsScene& scene, float scale_factor)
{
 Stone_Panel_Display::Direction_Status ds;
 Game_Panel_Section* section;
 Game_Panel_Gridline_Intersection* intersection;

//?
 QString posd = get_position_description_from_section_coordinates(
   spd, section, intersection, ds, x, y);

// QString posd = get_position_description(
//   spd, section, intersection, ds, x, y);

 if(intersection)
 {
  // //?
  confirm_move_stone(spd, intersection, ds);
 }

 else if(section)
 {
  Baccaning_Game_Capture* cap = game_->check_move_or_capture(spd, section);
  if(cap)
  {
   // // i.e., a real capture
   if(cap->captured_stone())
   {
    int ret = QMessageBox::warning(nullptr, "Confirm Capture",
      QString("Capture the %1?").arg(cap->get_captured_stone_informal_label()),
      QMessageBox::Yes | QMessageBox::No);

    if(ret != QMessageBox::Yes)
    {
     // //?
     draw_to_scene(scene, scale_factor);
     return;
    }
    cap->captured_stone()->remove_from_board();
   }
   if(spd->is_guard())
   {
    game_->analyze_guard_move(spd, spd->section(), section);
   }
   spd->section()->set_center_stone(nullptr);
   confirm_move_stone(spd, section, ds);
   spd->set_section(section);
   draw_to_scene(scene, scale_factor);
   section->set_center_stone(spd);
  }
 }
 switch_players();
 //qDebug() << "X: " << x << " Y: " << y;
}



void Game_Panel_Board::clear_current_selected_stone()
{
 selected_stone_to_add_ = nullptr;
}

void Game_Panel_Board::place_current_selected_stone(Game_Panel_Section* section, Stone_Panel_Display::Direction_Status ds)
{
 confirm_move_stone(selected_stone_to_add_, section, ds);
 selected_stone_to_add_ = nullptr;
}

void Game_Panel_Board::place_current_selected_stone(Game_Panel_Gridline_Intersection* intersection, Stone_Panel_Display::Direction_Status ds)
{
 confirm_move_stone(selected_stone_to_add_, intersection, ds);
 selected_stone_to_add_ = nullptr;
}

void Game_Panel_Board::get_logical_position_from_intersection_coordinates(Stone_Panel_Display* spd,
  Game_Panel_Section*& section, Game_Panel_Gridline_Intersection*& intersection,
  Stone_Panel_Display::Direction_Status& ds, int x, int y)
{
 section = nullptr;
 intersection = get_gridline_intersection(y, x);
 ds = Stone_Panel_Display::Direction_Status::Panel_Intersection;
}

void Game_Panel_Board::get_logical_position_from_section_coordinates(Stone_Panel_Display* spd,
  Game_Panel_Section*& section, Game_Panel_Gridline_Intersection*& intersection,
  Stone_Panel_Display::Direction_Status& ds, int x, int y)
{
 section = get_section(x, y);
 intersection = nullptr; //get_gridline_intersection(y, x);
 ds = Stone_Panel_Display::Direction_Status::Panel_Center;
}

void Game_Panel_Board::get_logical_position_from_offset(Stone_Panel_Display* spd,
  Game_Panel_Section*& section, Game_Panel_Gridline_Intersection*& intersection,
  Stone_Panel_Display::Direction_Status& ds, int x, int y)
{
 Game_Panel_Gridline_Intersection* gpi = spd->position()->intersection();
 section = nullptr;
 ds = Stone_Panel_Display::Direction_Status::Panel_Intersection;

 int intersection_x = gpi->vertical_gridline().index_x() + x;
 int intersection_y = gpi->horizontal_gridline().index_y() + y;
 intersection = get_gridline_intersection(intersection_y, intersection_x);

}

void Game_Panel_Board::get_logical_position(const QPoint& p,
  Game_Panel_Section*& section, Game_Panel_Gridline_Intersection*& intersection, Stone_Panel_Display::Direction_Status& ds)
{
 section = nullptr;

 int intersection_x = ((p.x() / 20.) + .5);
 int intersection_y = ((p.y() / 20.) + .5);

 intersection = get_gridline_intersection(intersection_y, intersection_x);

#ifdef HIDE
 int section_x = p.x() / 20;
 int section_y = p.y() / 20;

 int x_adj = (p.x() % 20) / 5;
 int y_adj = (p.y() % 20) / 5;

 //Stone_Panel_Display::Direction_Status ds;

 //  there's nothing situation-specific about the 10* but it allows the
 //  x_adj and y_adj to be combined into one number and for readable cases...
 switch( 10 * y_adj + x_adj )
 {
 case 0: ds = Stone_Panel_Display::Direction_Status::Panel_2NW; break;
 case 1: ds = Stone_Panel_Display::Direction_Status::Panel_NW; break;
 case 2: ds = Stone_Panel_Display::Direction_Status::Panel_2N; break;
 case 3: ds = Stone_Panel_Display::Direction_Status::Panel_NE; break;
 case 4: ds = Stone_Panel_Display::Direction_Status::Panel_2NE; break;

 case 10: ds = Stone_Panel_Display::Direction_Status::Panel_NW; break;
 case 11: ds = Stone_Panel_Display::Direction_Status::Panel_NW; break;
 case 12: ds = Stone_Panel_Display::Direction_Status::Panel_Center; break;
 case 13: ds = Stone_Panel_Display::Direction_Status::Panel_NE; break;
 case 14: ds = Stone_Panel_Display::Direction_Status::Panel_NE; break;

 case 20: ds = Stone_Panel_Display::Direction_Status::Panel_2W; break;
 case 21: ds = Stone_Panel_Display::Direction_Status::Panel_Center; break;
 case 22: ds = Stone_Panel_Display::Direction_Status::Panel_Center; break;
 case 23: ds = Stone_Panel_Display::Direction_Status::Panel_Center; break;
 case 24: ds = Stone_Panel_Display::Direction_Status::Panel_2E; break;

 case 30: ds = Stone_Panel_Display::Direction_Status::Panel_2SW; break;
 case 31: ds = Stone_Panel_Display::Direction_Status::Panel_SW; break;
 case 32: ds = Stone_Panel_Display::Direction_Status::Panel_S; break;
 case 33: ds = Stone_Panel_Display::Direction_Status::Panel_SE; break;
 case 34: ds = Stone_Panel_Display::Direction_Status::Panel_2SE; break;

 case 40: ds = Stone_Panel_Display::Direction_Status::Panel_SW; break;
 case 41: ds = Stone_Panel_Display::Direction_Status::Panel_SW; break;
 case 42: ds = Stone_Panel_Display::Direction_Status::Panel_Center; break;
 case 43: ds = Stone_Panel_Display::Direction_Status::Panel_SE; break;
 case 44: ds = Stone_Panel_Display::Direction_Status::Panel_SE; break;

 }

 section = get_section(section_x, section_y);
#endif
}

QString Game_Panel_Board::get_position_description_from_intersection_coordinates(Stone_Panel_Display* spd,
  Game_Panel_Section*& section, Game_Panel_Gridline_Intersection*& intersection,
  Stone_Panel_Display::Direction_Status& ds, int x, int y)
{
 get_logical_position_from_intersection_coordinates(spd, section, intersection, ds, x, y);

 return QString("%1, %2")
   .arg(intersection->vertical_gridline().index_x())
   .arg(intersection->horizontal_gridline().index_y())
   ;

}

QString Game_Panel_Board::get_position_description_from_section_coordinates(Stone_Panel_Display* spd,
  Game_Panel_Section*& section, Game_Panel_Gridline_Intersection*& intersection,
  Stone_Panel_Display::Direction_Status& ds, int x, int y)
{
 get_logical_position_from_section_coordinates(spd, section, intersection, ds, x, y);

 return QString("%1, %2")
   .arg(section->index_x())
   .arg(section->index_y())
   ;

}

QString Game_Panel_Board::get_position_description_from_offset(Stone_Panel_Display* spd,
  Game_Panel_Section*& section, Game_Panel_Gridline_Intersection*& intersection,
  Stone_Panel_Display::Direction_Status& ds, int x, int y)
{
 get_logical_position_from_offset(spd, section, intersection, ds, x, y);

 return QString("%1, %2")
   .arg(intersection->vertical_gridline().index_x())
   .arg(intersection->horizontal_gridline().index_y())
   ;

}

QString Game_Panel_Board::get_position_description(const QPoint& p,
  Game_Panel_Section*& section, Game_Panel_Gridline_Intersection*& intersection, Stone_Panel_Display::Direction_Status& ds)
{
 get_logical_position(p, section, intersection, ds);

 return QString("%1, %2")
   .arg(intersection->vertical_gridline().index_x())
   .arg(intersection->horizontal_gridline().index_y())
   ;

}


void Game_Panel_Board::confirm_move_stone(Stone_Panel_Display* spd, Game_Panel_Gridline_Intersection* intersection,
                        Stone_Panel_Display::Direction_Status ds)
{
 spd->move_to_intersection(intersection); //, ds);
 intersection->set_current_stone(spd);
 reset_stone_position_after_move(spd);

}


void Game_Panel_Board::confirm_move_stone(Stone_Panel_Display* spd,
  Game_Panel_Section* section,
  Stone_Panel_Display::Direction_Status ds)
{
 spd->move_to_section(section, ds);
 reset_stone_position_after_move(spd);

// QGraphicsItem* item = spd->get_graphics_item();

// view.connect(item, SLOT(itemChanged(QPoint)), this,
//   SLOT(handle_stone_item_move(QPoint)));

 //stones_.push_back(selected_stone_to_add_);


 //update();
}


QString Game_Panel_Board::stone_description(Stone_Panel_Display* spd) const
{
 return spd->description();
 //QString result = QString("%1-%2").arg(spd->s_or_n()).arg(spd->get_group_stone_label());
 //return result;
}



void Game_Panel_Board::register_stone_to_add(QString key)
{
 if(key.endsWith('K') || key.endsWith('Q'))
 {

 }
 else
 {
  int number = ++stone_keys_used_[key];
  key.append(QString::number(number));
 }
 Stone_Panel_Display* spd = stones_[key];
 selected_stone_to_add_ = spd;
}

// //int face = 0;
// int offset = 0;
// QString face_string;
// int index = description.indexOf(':');
// if(index != -1)
// {
//  //face = description.mid(index + 1).toInt();
//  face_string = description.mid(index + 1);
//  description = description.left(index);
// }
// bool default_choose_order;
// if(description.startsWith('G'))
//  default_choose_order = true;
// else if(description.startsWith("D12"))
//  default_choose_order = true;
// else if(description.contains('-'))
//  default_choose_order = false;
// else
//  default_choose_order = true;

// if(player == north_player_)
//  description.prepend("N-");
// else
//  description.prepend("S-");

// if(default_choose_order)
// {
//  int already_added = stone_keys_added_.value(description, 0);
//  stone_keys_added_.insert(description, already_added);
//  description += QString("-%1").arg(already_added);
//  ++already_added;
// }
// else
// {
//  //  The user sees rank ordered starting at 1, but
//  //  for the key it starts at 0
//  offset = -1;
// }
//// else
//// {
//// }

// qDebug() << QString("Description (offset): %1 (%2) ").arg(description).arg(offset);
// Stone_Panel_Display* spd = get_stone_by_key(description, offset);

// if(spd)
// {
//  selected_stone_to_add_ = spd;
////  QMessageBox::information(nullptr, QString("f: %1").arg(description),
////    QString("f_: %1 %2").arg(description).arg(spd->get_group_stone_label()));
// }
// else
// {
//  QMessageBox::information(nullptr, "?", "Not Found");
// }

// selected_stone_to_add_->set_current_value_from_string(face_string);
// //QMessageBox::information(nullptr, QString("f: %1").arg(face), description);
//}

void Game_Panel_Board::switch_players()
{
// if(current_player_ == north_player_)
//  current_player_ = south_player_;
// else
//  current_player_ = north_player_;

 game_->switch_players();

}



Game_Panel_Board::Game_Panel_Board(Baccaning_Game* game, Game_Utils& game_utils)
 : game_(game), utils_(game_utils), selected_stone_to_add_(nullptr)
{
 auto move_to_intersection_callback = [this](int x, int y, Stone_Panel_Display* spd, QGraphicsScene& scene, float scale_factor)
 {
  handle_stone_moved_to_intersection(x, y, spd, scene, scale_factor);
 };

 auto move_to_section_center_callback = [this](int x, int y, Stone_Panel_Display* spd, QGraphicsScene& scene, float scale_factor)
 {
  handle_stone_moved_to_section_center(x, y, spd, scene, scale_factor);
 };

// south_player_ = new Game_Player("South");
// north_player_ = new Game_Player("North");

// current_player_ = south_player_;

 boundary_width_ = 0;


 for(int i = 0; i < 9; ++i)
 {
  Game_Panel_Vertical_Gridline* v = new Game_Panel_Vertical_Gridline(i, boundary_width_ + 20 * i  );
  vertical_gridlines_.push_back(v);

  //? bool cab = (i == 2) || (i == 18);

  for(int j = 0; j < 9; ++j)
  {
   Game_Panel_Gridline_Edge& e = v->get_edge(j);

   e.set_index_x(i);
   e.set_index_y(j);

   if( (j == 4) && (i > 0) && (i < 8))
   {
    e.set_state(Game_Panel_Gridline_Edge::State::River_Hidden);
   }
   else
   {
    e.set_state(Game_Panel_Gridline_Edge::State::Plain);
   }

  }

 }

 for(int j = 0; j < 10; ++j)
 {
  Game_Panel_Horizontal_Gridline* h = new Game_Panel_Horizontal_Gridline(j, boundary_width_ + (20 * j) );

  if(h == nullptr)
  {
   qDebug() << "Fail alloc ...";
   return;
  }

  horizontal_gridlines_.push_back(h);
  //?bool cab = (j == 2) || (j == 18);

  for(int i = 0; i < 8; ++i)
  {
   Game_Panel_Gridline_Edge& e = h->get_edge(i);

   e.set_index_x(i);
   e.set_index_y(j);

//   else
//   {
    e.set_state(Game_Panel_Gridline_Edge::State::Plain);
//   }
  }

  for(int i = 0; i < 9; ++i)
  {
   Game_Panel_Gridline_Intersection::State gs = Game_Panel_Gridline_Intersection::State::Plain;

//   int r = get_ring(i + 1, j + 1, 10, 2);
//   if(r > 16)
//   {
//    gs = Game_Panel_Gridline_Intersection::State::Marked;
//   }

   Game_Panel_Vertical_Gridline* v = vertical_gridlines_[i];

   Game_Panel_Gridline_Intersection* g = new Game_Panel_Gridline_Intersection(*h, *v, gs);

   if( ((i == 1) || (i == 7)) && ((j == 2) || (j == 7)) )
   {
    g->set_state(Game_Panel_Gridline_Intersection::State::Cross);
   }
   else if( ((j == 3) || (j == 6)) && ((i % 2) == 0) )
   {
    g->set_state(Game_Panel_Gridline_Intersection::State::Cross);
   }

   else if( ((i == 0) || (i == 8)) && ((j == 0) || (j == 9) ))
   {
    g->set_state(Game_Panel_Gridline_Intersection::State::Boundary);
   }

//   else if( ((i == 0) || (i == 2) || (i == 6) || (i == 8) ) &&
//            ( (j == 4) || (j == 5) ) )
//   {
//    g->set_state(Game_Panel_Gridline_Intersection::State::Boundary);
//   }

//   else if( ((i == 0) || (i == 1) || (i == 3) || (i == 5) || (i == 7) || (i == 8)   ) &&
//            ( (j == 4) || (j == 5) ) )
//   {
//    g->set_state(Game_Panel_Gridline_Intersection::State::Boundary);
//   }

   else if( ((i == 0)  || (i == 8)   ) &&
            ( (j == 4) || (j == 5) ) )
   {
    g->set_state(Game_Panel_Gridline_Intersection::State::Boundary);
   }

   else
   {
    g->set_state(Game_Panel_Gridline_Intersection::State::Plain);
   }

   last_gridline_intersection_ = g;


   //gridline_intersections_.push_back(g);

//   int count = i + (j * 9);

//   qDebug() << "COUNT: " << count;

   gridline_intersections_[i + (j * 9)] = g;


  }



 }
 //}

 {
  Game_Panel_Gridline_Intersection* g1 = get_gridline_intersection(0, 3);
  Game_Panel_Gridline_Intersection* g2 = get_gridline_intersection(2, 5);
  Game_Panel_Diagonal_Gridline* dg = new Game_Panel_Diagonal_Gridline(g1, g2);
  diagonal_gridlines_.push_back(dg);
 }

 {
  Game_Panel_Gridline_Intersection* g1 = get_gridline_intersection(0, 5);
  Game_Panel_Gridline_Intersection* g2 = get_gridline_intersection(2, 3);
  Game_Panel_Diagonal_Gridline* dg = new Game_Panel_Diagonal_Gridline(g1, g2);
  diagonal_gridlines_.push_back(dg);
 }



 {
  Game_Panel_Gridline_Intersection* g1 = get_gridline_intersection(7, 3);
  Game_Panel_Gridline_Intersection* g2 = get_gridline_intersection(9, 5);
  Game_Panel_Diagonal_Gridline* dg = new Game_Panel_Diagonal_Gridline(g1, g2);
  diagonal_gridlines_.push_back(dg);
 }

 {
  Game_Panel_Gridline_Intersection* g1 = get_gridline_intersection(7, 5);
  Game_Panel_Gridline_Intersection* g2 = get_gridline_intersection(9, 3);
  Game_Panel_Diagonal_Gridline* dg = new Game_Panel_Diagonal_Gridline(g1, g2);
  diagonal_gridlines_.push_back(dg);
 }



 {
  Game_Panel_Gridline_Intersection* g1 = get_gridline_intersection(0, 0);
  Game_Panel_Gridline_Intersection* g2 = get_gridline_intersection(5, 5);
  Game_Panel_Diagonal_Gridline* dg = new Game_Panel_Diagonal_Gridline(g1, g2);
  diagonal_gridlines_.push_back(dg);
 }

 {
  Game_Panel_Gridline_Intersection* g1 = get_gridline_intersection(0, 8);
  Game_Panel_Gridline_Intersection* g2 = get_gridline_intersection(5, 3);
  Game_Panel_Diagonal_Gridline* dg = new Game_Panel_Diagonal_Gridline(g1, g2);
  diagonal_gridlines_.push_back(dg);
 }


 {
  Game_Panel_Gridline_Intersection* g1 = get_gridline_intersection(4, 5);
  Game_Panel_Gridline_Intersection* g2 = get_gridline_intersection(9, 0);
  Game_Panel_Diagonal_Gridline* dg = new Game_Panel_Diagonal_Gridline(g1, g2);
  diagonal_gridlines_.push_back(dg);
 }

 {
  Game_Panel_Gridline_Intersection* g1 = get_gridline_intersection(4, 3);
  Game_Panel_Gridline_Intersection* g2 = get_gridline_intersection(9, 8);
  Game_Panel_Diagonal_Gridline* dg = new Game_Panel_Diagonal_Gridline(g1, g2);
  diagonal_gridlines_.push_back(dg);
 }



 {
  Game_Panel_Gridline_Intersection* g1 = get_gridline_intersection(4, 0);
  Game_Panel_Gridline_Intersection* g2 = get_gridline_intersection(5, 1);
  Game_Panel_Diagonal_Gridline* dg = new Game_Panel_Diagonal_Gridline(g1, g2);
  diagonal_gridlines_.push_back(dg);
 }
 {
  Game_Panel_Gridline_Intersection* g1 = get_gridline_intersection(4, 1);
  Game_Panel_Gridline_Intersection* g2 = get_gridline_intersection(5, 0);
  Game_Panel_Diagonal_Gridline* dg = new Game_Panel_Diagonal_Gridline(g1, g2);
  diagonal_gridlines_.push_back(dg);
 }

 {
  Game_Panel_Gridline_Intersection* g1 = get_gridline_intersection(4, 7);
  Game_Panel_Gridline_Intersection* g2 = get_gridline_intersection(5, 8);
  Game_Panel_Diagonal_Gridline* dg = new Game_Panel_Diagonal_Gridline(g1, g2);
  diagonal_gridlines_.push_back(dg);
 }
 {
  Game_Panel_Gridline_Intersection* g1 = get_gridline_intersection(4, 8);
  Game_Panel_Gridline_Intersection* g2 = get_gridline_intersection(5, 7);
  Game_Panel_Diagonal_Gridline* dg = new Game_Panel_Diagonal_Gridline(g1, g2);
  diagonal_gridlines_.push_back(dg);
 }



 for(int i = 0; i < 8; ++i)
 {
  for(int j = 0; j < 9; ++j)
  {
   Game_Panel_Section::Patterns pattern = Game_Panel_Section::Patterns::N_A;
   Game_Panel_Section::Borders border = Game_Panel_Section::Borders::None;
   Game_Panel_Section::Center_State cs = Game_Panel_Section::Center_State::Plain;

   if( ((i == 0) || (i == 7) || (i == 3) || (i == 4)) && ((j == 2) || (j == 6) ))
   {
    pattern = Game_Panel_Section::Patterns::Ramp;
   }
   else
   {
    pattern = Game_Panel_Section::Patterns::Clear;
   }

   Game_Panel_Section* gps = new Game_Panel_Section(i, j,
    20 * i + 10, 20 * j + 10, pattern, border, cs);

   sections_.push_back(gps);
  }


 }




 for(int i = 0; i < 8; ++i)
 {
  Stone_Panel_Display* spn = new Stone_Panel_Display(Stone_Panel_Display::Team_Status::North_CPawn, i,
    move_to_intersection_callback, move_to_section_center_callback);
  Stone_Panel_Display* sps = new Stone_Panel_Display(Stone_Panel_Display::Team_Status::South_CPawn, i,
    move_to_intersection_callback, move_to_section_center_callback);

  stones_[QString("NP%1").arg(i + 1)] = spn;
  stones_[QString("SP%1").arg(i + 1)] = sps;

  Stone_Panel_Display* sgn = new Stone_Panel_Display(Stone_Panel_Display::Team_Status::North_Guard, i, move_to_intersection_callback, move_to_section_center_callback);
  Stone_Panel_Display* sgs = new Stone_Panel_Display(Stone_Panel_Display::Team_Status::South_Guard, i, move_to_intersection_callback, move_to_section_center_callback);

  stones_[QString("NG%1").arg(i + 1)] = sgn;
  stones_[QString("SG%1").arg(i + 1)] = sgs;

  if(i < 4)
  {
   set_stone_at_position(3, i, sgn, Stone_Panel_Display::Direction_Status::Panel_Center);
   mark_section_center_occupied(3, i, sgn);
   set_stone_at_position(6, i, sgs, Stone_Panel_Display::Direction_Status::Panel_Center);
   mark_section_center_occupied(6, i, sgs);
  }
  else
  {
   set_stone_at_position(2, i, sgn, Stone_Panel_Display::Direction_Status::Panel_Center);
   mark_section_center_occupied(2, i, sgn);
   set_stone_at_position(5, i, sgs, Stone_Panel_Display::Direction_Status::Panel_Center);
   mark_section_center_occupied(5, i, sgs);
  }

 }

 for(int i = 0; i < 2; ++i)
 {
  Stone_Panel_Display* sbn = new Stone_Panel_Display(Stone_Panel_Display::Team_Status::North_CBishop, i, move_to_intersection_callback, move_to_section_center_callback);
  Stone_Panel_Display* sbs = new Stone_Panel_Display(Stone_Panel_Display::Team_Status::South_CBishop, i, move_to_intersection_callback, move_to_section_center_callback);

  stones_[QString("NB%1").arg(i + 1)] = sbn;
  stones_[QString("SB%1").arg(i + 1)] = sbs;

  Stone_Panel_Display* srn = new Stone_Panel_Display(Stone_Panel_Display::Team_Status::North_CRook, i, move_to_intersection_callback, move_to_section_center_callback);
  Stone_Panel_Display* srs = new Stone_Panel_Display(Stone_Panel_Display::Team_Status::South_CRook, i, move_to_intersection_callback, move_to_section_center_callback);

  stones_[QString("NR%1").arg(i + 1)] = srn;
  stones_[QString("SR%1").arg(i + 1)] = srs;

  Stone_Panel_Display* snn = new Stone_Panel_Display(Stone_Panel_Display::Team_Status::North_CKnight, i, move_to_intersection_callback, move_to_section_center_callback);
  Stone_Panel_Display* sns = new Stone_Panel_Display(Stone_Panel_Display::Team_Status::South_CKnight, i, move_to_intersection_callback, move_to_section_center_callback);

  stones_[QString("NN%1").arg(i + 1)] = snn;
  stones_[QString("SN%1").arg(i + 1)] = sns;

 }

 {
  Stone_Panel_Display* skn = new Stone_Panel_Display(Stone_Panel_Display::Team_Status::North_CKing, 0, move_to_intersection_callback, move_to_section_center_callback);
  Stone_Panel_Display* sks = new Stone_Panel_Display(Stone_Panel_Display::Team_Status::South_CKing, 0, move_to_intersection_callback, move_to_section_center_callback);

  stones_["NK"] = skn;
  stones_["SK"] = sks;

  Stone_Panel_Display* sqn = new Stone_Panel_Display(Stone_Panel_Display::Team_Status::North_CQueen, 0, move_to_intersection_callback, move_to_section_center_callback);
  Stone_Panel_Display* sqs = new Stone_Panel_Display(Stone_Panel_Display::Team_Status::South_CQueen, 0, move_to_intersection_callback, move_to_section_center_callback);

  stones_["NQ"] = sqn;
  stones_["SQ"] = sqs;
 }


//? init_stones();

// int key = 0;
// for(Stone_Panel_Display* spd : stones_)
// {
//  if(spd)
//  {
//   QGraphicsItem* item = spd->get_graphics_item();
//   if(item)
//    item->setData(0, key);
//  }
//  ++key;
// }


}

Game_Panel_Gridline_Intersection* Game_Panel_Board::get_gridline_intersection(int j, int i)
{
 return gridline_intersections_[i + (j * 9)];
}

Game_Panel_Section* Game_Panel_Board::get_section(int i, int j)
{
 return sections_[(i * 9) + j];
}

//Stone_Panel_Display* Game_Panel_Board::get_stone_by_index(int index)
//{
// return stones_.value(index, 0);
//}


void Game_Panel_Board::add_stone_display(QString key, Stone_Panel_Display* spd)
{
 stones_[key] = spd;
}

void Game_Panel_Board::draw_to_scene(QGraphicsScene& scene, float scale_factor)
{
 // draw outer board

 int section_width = 20;

 QPen outer_pen = QPen(QColor("#059a49"));
 outer_pen.setWidth(3);

//?
// QGraphicsRectItem* item = scene.addRect(0, 0, section_width * 7 * scale_factor,
//               section_width * 8 * scale_factor, outer_pen);

// item->setData(1, QVariant("Background"));


// for(Game_Panel_Section* gps : sections_)
// {
//  gps->draw_to_scene(scene, scale_factor);
// }

//? int offset = section_width - 18;

 int offset = 0;

 int h_min = offset;
 int v_min = offset;
 int h_max = 8 * section_width + offset;
 int v_max = 9 * section_width + offset;

 int i = 0;
 for(Game_Panel_Horizontal_Gridline* h : horizontal_gridlines_)
 {
  h->draw_to_scene(scene, scale_factor, v_min, v_max);
  ++i;
//  if(i > 0)
//   break;
 }

 int j = 0;
 for(Game_Panel_Vertical_Gridline* v : vertical_gridlines_)
 {
  v->draw_to_scene(scene, scale_factor, h_min, h_max);
  ++j;
//  if(j > 0)
//   break;
 }


 for(Game_Panel_Diagonal_Gridline* dg : diagonal_gridlines_)
 {
  dg->draw_to_scene(scene, scale_factor);
  //?++j;
 }
// return ; //



 for(Game_Panel_Gridline_Intersection* g : gridline_intersections_)
 {
  g->draw_to_scene(scene, scale_factor);
 }

 for(Game_Panel_Section* gps : sections_)
 {
  gps->draw_to_scene(scene, scale_factor);
 }

 QMapIterator<QString, Stone_Panel_Display*> it(stones_);
 while(it.hasNext())
 {
  it.next();
  QString key = it.key();
  Stone_Panel_Display* spd = it.value();
  spd->draw_to_scene(scene, scale_factor);
 }

}

