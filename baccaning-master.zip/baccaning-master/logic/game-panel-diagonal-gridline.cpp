

#include "game-panel-diagonal-gridline.h"

#include "game-panel-gridline-intersection.h"

#include <QGraphicsView>



Game_Panel_Diagonal_Gridline::Game_Panel_Diagonal_Gridline(Game_Panel_Gridline_Intersection* top,
  Game_Panel_Gridline_Intersection* bottom)
 : top_(top),
   bottom_(bottom)
{
 int x = top_->vertical_gridline().index_x();
 int y = top_->horizontal_gridline().index_y();

 int x1 = bottom_->vertical_gridline().index_x();
 int y1 = bottom_->horizontal_gridline().index_y();

 if(x1 < x)
 {
  //  this should probably not be hardcoded ...
  bool strong = (x - x1) == 2;

  for(int i = 0; i < (x - x1); ++i)
  {
   Game_Panel_Gridline_Edge e;

   if(strong)
    e.set_state(Game_Panel_Gridline_Edge::State::Forward_Diagonal_Strong);
   else
    e.set_state(Game_Panel_Gridline_Edge::State::Forward_Diagonal_Soft);


   e.set_index_x(x - i);
   e.set_index_y(y + i);

   edges_.push_back(e);

   //add_edge();
  }
 }
 else
 {
  bool strong = (x1 - x) == 2;

  for(int i = 0; i < (x1 - x); ++i)
  {
   Game_Panel_Gridline_Edge e;

   if(strong)
    e.set_state(Game_Panel_Gridline_Edge::State::Back_Diagonal_Strong);
   else
    e.set_state(Game_Panel_Gridline_Edge::State::Back_Diagonal_Soft);


   e.set_index_x(x + i);
   e.set_index_y(y + i);

   edges_.push_back(e);

   //add_edge();
  }
 }

// if(x1 > x)
// {

// }



}


Game_Panel_Gridline_Edge& Game_Panel_Diagonal_Gridline::get_edge(int index)
{
 return edges_[index];
}


void Game_Panel_Diagonal_Gridline::add_edge(int i)
{

}


void Game_Panel_Diagonal_Gridline::draw_to_scene(QGraphicsScene& scene,
  float scale_factor) //, int local_x_min, int local_x_max)
{
 QBrush qbr;
 QPen qpen = QPen(QColor("#ACD0A0"));

 int pen_width = scale_factor > 1.5 ? 3 : 1;

 qpen.setWidth(pen_width);
 //?qpen.setJoinStyle(Qt::RoundJoin);

 int width = 20;

 for(const Game_Panel_Gridline_Edge& e : edges_)
 {
  e.draw_as_diagonal(scene, scale_factor);
 }



// float center_y = scale_factor * local_y_center_;

// for(int i = 0; i < 8; ++i)
// {
//  Game_Panel_Gridline_Edge& e = get_edge(i);

//  e.draw_as_horizontal(scene, scale_factor, center_y);

////?  float y_min = scale_factor * j * width + 1;
////?  float y_max = scale_factor * (j + 1) * width - 1;
// }

}

