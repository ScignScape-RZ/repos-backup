
#ifndef GAME_PANEL_DIAGONAL_GRIDLINE__H
#define GAME_PANEL_DIAGONAL_GRIDLINE__H

#include "../accessors.h"

#include "game-panel-gridline-edge.h"

#include <QList>

class QGraphicsScene;

class Game_Panel_Gridline_Intersection;


class Game_Panel_Diagonal_Gridline
{
 Game_Panel_Gridline_Intersection* top_;
 Game_Panel_Gridline_Intersection* bottom_;

public:


 Game_Panel_Diagonal_Gridline(Game_Panel_Gridline_Intersection* top,
                              Game_Panel_Gridline_Intersection* bottom);

 ACCESSORS(Game_Panel_Gridline_Intersection* ,top)
 ACCESSORS(Game_Panel_Gridline_Intersection* ,bottom)

 QList<Game_Panel_Gridline_Edge> edges_;

 void draw_to_scene(QGraphicsScene& scene,
   float scale_factor); // int local_x_min, int local_x_max);


 Game_Panel_Gridline_Edge& get_edge(int index);

 void add_edge(int i);

};


#endif
