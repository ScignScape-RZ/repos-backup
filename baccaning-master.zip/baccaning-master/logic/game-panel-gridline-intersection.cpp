

#include "game-panel-gridline-intersection.h"

#include "game-panel-colors.h"

#include <QGraphicsView>

Game_Panel_Gridline_Intersection::Game_Panel_Gridline_Intersection(Game_Panel_Horizontal_Gridline& horizontal_gridline,
  Game_Panel_Vertical_Gridline& vertical_gridline, State state) :
    horizontal_gridline_(horizontal_gridline),
    vertical_gridline_(vertical_gridline),
    state_(state), current_stone_(nullptr), ellipse_item_(nullptr)
{

}


void Game_Panel_Gridline_Intersection::draw_to_scene(QGraphicsScene& scene,
  float scale_factor)
{
 if(ellipse_item_)
   return;

// int w2 = 10;
 QBrush qbr;
 QPen qpen;// = QPen(global_colors->placement_mark_color());

 switch(state_)
 {
 case State::Cross:
  qpen = QPen(global_colors->placement_mark_color());
  break;

 case State::Boundary:
  qpen = QPen(global_colors->boundary_point_color());
  qbr = QBrush(global_colors->boundary_point_color());
  break;

 default: return;

 }

 int local_y_center = horizontal_gridline_.local_y_center();
 int local_x_center = vertical_gridline_.local_x_center();

 float center_x = scale_factor * (local_x_center);// - local_width/2);
 float center_y = scale_factor * (local_y_center);// - local_width/2);

 if(state_ == State::Cross || state_ == State::Occupied_Cross)
 {
  int local_width = 3;
  int pen_width = 3;

  qpen.setWidth(pen_width);
  qpen.setJoinStyle(Qt::RoundJoin);

  ellipse_item_ =
    scene.addEllipse(center_x - local_width/2, center_y - local_width/2, local_width, local_width, qpen, qbr);

  scene.addLine(center_x - local_width, center_y,
    center_x, center_y - local_width, qpen);

  scene.addLine(center_x, center_y - local_width,
    center_x + local_width, center_y, qpen);

  scene.addLine(center_x + local_width, center_y,
               center_x, center_y + local_width,
               qpen);

  scene.addLine(center_x, center_y + local_width,
               center_x - local_width, center_y,
               qpen);
 }

 if(state_ == State::Boundary || state_ == State::Occupied_Boundary)
 {
  int local_width = 10;
  int pen_width = 1;

  qpen.setWidth(pen_width);
  qpen.setJoinStyle(Qt::RoundJoin);

  ellipse_item_ =
    scene.addEllipse(center_x - local_width/2, center_y - local_width/2, local_width, local_width, qpen, qbr);

 }

// scene.addRect(center_x, center_y,
//               scale_factor * local_width,
//               scale_factor * local_width, qpen, qbr);

// switch (state_)
// {
// case State::Marked:
// {
//  QBrush qbr;// = QBrush(QColor("red"));
//  QPen qpen = QPen(QColor("brown"));

//  qpen.setWidth(1);
//  scene.addRect(center_x + scale_factor * w2,
//                 center_y + scale_factor * w2,
//                4, 4, qpen, qbr);
// }
// break;
// case State::Occupied:
// {
////  QBrush qbr;
////  QPen qpen = QPen(QColor("black"));
////  qpen.setBrush(qbr);

////  qpen.setWidth(1);

////  scene.addRect(center_x + scale_factor * w2,
////                center_y + scale_factor * w2,
////               2, 2, qpen, qbr);

// }
// break;
// default:
// {
// }
// break;

// }

}

