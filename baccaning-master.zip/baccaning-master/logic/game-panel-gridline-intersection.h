
#ifndef GAME_PANEL_GRIDLINE_INTERSECTION__H
#define GAME_PANEL_GRIDLINE_INTERSECTION__H

#include "../accessors.h"

#include "game-panel-horizontal-gridline.h"
#include "game-panel-vertical-gridline.h"

class QGraphicsScene;
class QGraphicsEllipseItem;

class Stone_Panel_Display;

class Game_Panel_Gridline_Intersection
{

 Game_Panel_Horizontal_Gridline& horizontal_gridline_;
 Game_Panel_Vertical_Gridline& vertical_gridline_;


 Stone_Panel_Display* current_stone_;

 QGraphicsEllipseItem* ellipse_item_;

public:

 enum class State
 {
  Plain, Marked, Occupied,
  Cross, Marked_Cross, Occupied_Cross,

  Boundary, Occupied_Boundary
 };

private:

 State state_;

public:


 Game_Panel_Gridline_Intersection(Game_Panel_Horizontal_Gridline& horizontal_gridline,
   Game_Panel_Vertical_Gridline& vertical_gridline, State state);

 ACCESSORS(Game_Panel_Horizontal_Gridline ,horizontal_gridline)
 ACCESSORS(Game_Panel_Vertical_Gridline ,vertical_gridline)
 ACCESSORS(State ,state)

 ACCESSORS(Stone_Panel_Display* ,current_stone)


 void draw_to_scene(QGraphicsScene& scene, float scale_factor);


};


#endif
