

#include "game-panel-section.h"

#include "game-panel-colors.h"

#include "stone-panel-display.h"

#include "game-position.h"

#include <QGraphicsView>
#include <QGraphicsRectItem>

Game_Panel_Section::Game_Panel_Section(int index_x, int index_y,
                                       int local_x_center, int local_y_center,
  Patterns pattern, Borders border, Center_State center_state)
 : index_x_(index_x), index_y_(index_y),
   local_x_center_(local_x_center), local_y_center_(local_y_center),
   pattern_(pattern), border_(Borders::None),
   center_state_(center_state), center_game_position_(nullptr),
   highlight_item_(nullptr)

{
 check_init_positions();

}

void Game_Panel_Section::check_init_positions()
{
 if(!center_game_position_)
 {
  center_game_position_ = new Game_Position;
  center_game_position_->set_variant(Game_Position::Variant::Center);
  center_game_position_->check_set_ref_position();
  center_game_position_->set_section(this);
 }

}

Game_Position* Game_Panel_Section::get_game_position_nw()
{
 return center_game_position_->get_section_game_position_nw();
}

Game_Position* Game_Panel_Section::get_game_position_ne()
{
 return center_game_position_->get_section_game_position_ne();
}

Game_Position* Game_Panel_Section::get_game_position_sw()
{
 return center_game_position_->get_section_game_position_sw();
}

Game_Position* Game_Panel_Section::get_game_position_se()
{
 return center_game_position_->get_section_game_position_se();
}


void Game_Panel_Section::set_doubled_top(Stone_Panel_Display* spd)
{
 spd->to_doubled_top();
 get_center_stone()->to_doubled_base();
}


int Game_Panel_Section::slot_occupied_count_given_center_occupied()
{
 if(center_game_position_)
 {
  if(center_game_position_->stone())
  {
   return center_game_position_->adjacent_slot_occupied_count();
  }
 }
 return 0;
}

void Game_Panel_Section::set_center_stone(Stone_Panel_Display* spd)
{
 if(center_game_position_)
   center_game_position_->set_stone(spd);
}


Stone_Panel_Display* Game_Panel_Section::get_center_stone()
{
 if(center_game_position_)
  return center_game_position_->stone();
 return nullptr;
}


void Game_Panel_Section::draw_to_scene(QGraphicsScene& scene,
                                       float scale_factor)
{
 if(highlight_item_)
   return;

 int width = 20;
 int w2 = 10;

 QBrush qbr;
 QPen qpen = QPen(QColor("white"));

 qpen.setWidth(1);
 qpen.setJoinStyle(Qt::RoundJoin);

 float center_x = scale_factor * (local_x_center_);
 float center_y = scale_factor * (local_y_center_);

 if(pattern_ != Patterns::Ramp)
  return;

 qpen = QPen(global_colors->boundary_point_color());
 qbr = QBrush(global_colors->boundary_point_color());

 int local_width = 10;
 int pen_width = 1;

 qpen.setWidth(pen_width);
 qpen.setJoinStyle(Qt::RoundJoin);

 //ellipse_item_ = scene.addEllipse(center_x - local_width/2, center_y - local_width/2, local_width, local_width, qpen, qbr);


 highlight_item_ = scene.addRect(center_x - local_width, center_y - local_width, local_width * 2, local_width * 2, qpen, qbr);



#ifdef HIDE
 //if(index_x_ % 2 == index_y_ % 2)
 switch (pattern_)
 {
 case Patterns::Dark_H_Cut:
 case Patterns::Dark_V_Cut:
 case Patterns::Dark_Cross:
 case Patterns::Dark:
  {
   global_colors->dark_section_brush(qbr,
                                          center_x - scale_factor * w2,
                                          center_y - scale_factor * w2,
                                          center_x + scale_factor * w2,
                                          center_y + scale_factor * w2
                                     );
  }
  break;
 case Patterns::Light_H_Cut:
 case Patterns::Light_V_Cut:
 case Patterns::Light_Cross:
 case Patterns::Light:
  {
   global_colors->light_section_brush(qbr,
                                          center_x - scale_factor * w2,
                                          center_y - scale_factor * w2,
                                          center_x + scale_factor * w2,
                                          center_y + scale_factor * w2
                                     );
  }
  break;
 case Patterns::Clear:
  {
   global_colors->clear_section_brush(qbr,
                                         center_x - scale_factor * w2,
                                         center_y - scale_factor * w2,
                                         center_x + scale_factor * w2,
                                         center_y + scale_factor * w2
                                    );
  }
  break;
 case Patterns::Left_Frontier:
  {
   global_colors->left_frontier_section_brush(qbr,
                                         center_x - scale_factor * w2,
                                         center_y - scale_factor * w2,
                                         center_x + scale_factor * w2,
                                         center_y + scale_factor * w2
                                    );
  }
  break;


 case Patterns::Right_Frontier:
  {
   global_colors->right_frontier_section_brush(qbr,
                                        center_x - scale_factor * w2,
                                        center_y - scale_factor * w2,
                                        center_x + scale_factor * w2,
                                        center_y + scale_factor * w2
                                   );
  }
 break;
 }


 QGraphicsRectItem* item = scene.addRect(center_x, center_y,
               scale_factor * width, scale_factor * width, qpen, qbr);

 item->setData(1, QVariant("Section"));


 if( (pattern_ == Patterns::Light_Cross) || (pattern_ == Patterns::Dark_Cross) )
 {
  QPen qpen = QPen(global_colors->section_box_border_color());

  int local_width = 5;
  qpen.setWidth(local_width);



  scene.addLine(center_x + scale_factor * w2,
                center_y + 2,
                center_x + scale_factor * w2,
                center_y + scale_factor * width, qpen);

  scene.addLine(center_x + scale_factor,
                center_y + scale_factor * w2,
                center_x + scale_factor * width,
                center_y + scale_factor * w2,
                qpen);

 }
 else if( (pattern_ == Patterns::Light_V_Cut) || (pattern_ == Patterns::Dark_V_Cut) )
 {
  QPen qpen = QPen(global_colors->section_box_border_color());

  int local_width = 5;
  qpen.setWidth(local_width);



  scene.addLine(center_x + scale_factor * w2,
                center_y + 3,
                center_x + scale_factor * w2,
                center_y + scale_factor * width - 3,
                qpen);

 }

 else if( (pattern_ == Patterns::Light_H_Cut) || (pattern_ == Patterns::Dark_H_Cut) )
 {
  QPen qpen = QPen(global_colors->section_box_border_color());

  int local_width = 5;
  qpen.setWidth(local_width);

  scene.addLine(center_x + scale_factor + 3,
                center_y + scale_factor * w2,
                center_x + scale_factor * width - 3,
                center_y + scale_factor * w2,
                qpen);

 }

 switch (center_state_)
 {
  case Center_State::Marked:
  {
   QBrush qbr = QBrush(global_colors->placement_mark_color());
   QPen qpen = QPen(global_colors->placement_mark_color());


   qpen.setWidth(1);
   scene.addRect(center_x + scale_factor * w2 - 3,
                 center_y + scale_factor * w2 - 3,
                6, 6, qpen, qbr);
  }
  break;
 case Center_State::Occupied:
 {
  QBrush qbr;
  QPen qpen = QPen(QColor("black"));
  qpen.setBrush(qbr);

  qpen.setWidth(1);

  scene.addRect(center_x + scale_factor * w2,
                center_y + scale_factor * w2,
               2, 2, qpen, qbr);

 }
 break;
 default:
 {
//  QBrush qbr; // = QBrush(QColor("red"));
//  QPen qpen = QPen(QColor("red"));

//  qpen.setWidth(1);
//  scene.addRect(center_x + scale_factor * w2,
//                center_y + scale_factor * w2,
//               4, 4, qpen, qbr);
 }
 break;

 }
#endif
}

