
#ifndef GAME_PANEL_VERTICAL_GRIDLINE__H
#define GAME_PANEL_VERTICAL_GRIDLINE__H

#include "../accessors.h"

#include "game-panel-gridline-edge.h"


class QGraphicsScene;




class Game_Panel_Vertical_Gridline
{
 int index_x_;

 int local_x_center_;

public:


 Game_Panel_Vertical_Gridline(int index_x,
   int local_x_center);

 Game_Panel_Gridline_Edge edges_[9];

 ACCESSORS(int, index_x)
 ACCESSORS(int, local_x_center)

 Game_Panel_Gridline_Edge& get_edge(int index);

 void draw_to_scene(QGraphicsScene& scene, float scale_factor,
   int local_x_min, int local_x_max);


};


#endif
