
#include "game-player.h"

Game_Player::Game_Player(QString full_name)
 : full_name_(full_name)
{
}
