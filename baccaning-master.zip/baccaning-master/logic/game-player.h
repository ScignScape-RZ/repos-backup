
#ifndef GAME_PLAYER__H
#define GAME_PLAYER__H


class Game_Panel_Gridline_Edge;
class Game_Panel_Gridline_Intersection;
class Game_Panel_Section;
class Stone_Panel_Display;


#include "../accessors.h"

#include <QString>


class Game_Player
{
 QString full_name_;

public:

 Game_Player(QString full_name = QString());

 ACCESSORS(QString ,full_name)

};

#endif
