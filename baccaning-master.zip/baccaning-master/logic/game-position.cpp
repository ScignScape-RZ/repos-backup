
#include "game-position.h"

#include "game-panel-section.h"

Game_Position::Game_Position()
 : section_(nullptr), stone_(nullptr)
{
}

Game_Position* Game_Position::get_section_game_position_nw()
{
 switch(variant_)
 {
 case Center:
  return ref_position_->get_section_game_position_nw();
 case NW:
  return this;
 case NE:
 case SE:
 case SW:
  return get_section()->get_game_position_nw();
 default:
  return nullptr;
 }

}

Game_Position* Game_Position::get_section_game_position_ne()
{
 switch(variant_)
 {
 case Center:
 case NW:
  return ref_position_->get_section_game_position_ne();
 case NE:
  return this;
 case SE:
 case SW:
  return get_section()->get_game_position_ne();
 default:
  return nullptr;
 }

}

Game_Position* Game_Position::get_section_game_position_se()
{
 switch(variant_)
 {
 case Center:
 case NW:
 case NE:
  return ref_position_->get_section_game_position_se();
 case SE:
  return this;
 case SW:
  return get_section()->get_game_position_se();
 default:
  return nullptr;
 }


}

Game_Position* Game_Position::get_section_game_position_sw()
{
 switch(variant_)
 {
 case Center:
 case NW:
 case NE:
 case SE:
  return ref_position_->get_section_game_position_sw();
 case SW:
  return this;
 default:
  return nullptr;
 }

}


void Game_Position::check_set_ref_position()
{
 if(!ref_position_)
 {
  switch(variant_)
  {
  case Center:
   ref_position_ = new Game_Position;
   ref_position_->set_variant(Game_Position::Variant::NW);
   ref_position_->check_set_ref_position();
   break;
  case NW:
   ref_position_ = new Game_Position;
   ref_position_->set_variant(Game_Position::Variant::NE);
   ref_position_->check_set_ref_position();
   break;
  case NE:
   ref_position_ = new Game_Position;
   ref_position_->set_variant(Game_Position::Variant::SE);
   ref_position_->check_set_ref_position();
   break;
  case SE:
   ref_position_ = new Game_Position;
   ref_position_->set_variant(Game_Position::Variant::SW);
   ref_position_->check_set_ref_position();
   break;
  default:
   // error; could be an exception?
   break;
  }
 }
}

void Game_Position::set_section(Game_Panel_Section* s)
{
 switch(variant_)
 {
 case SW:
  section_ = s;
  break;
 case Center:
 case NW:
 case NE:
 case SE:
  check_set_ref_position();
  ref_position_->set_section(s);
 default:
  // error; could be an exception?
  break;
 }
}

int Game_Position::adjacent_slot_occupied_count()
{
 int result = 0;
 switch (variant_)
 {
 case SW:
  if(stone_)
   ++result;
  break;
 case NW:
 case NE:
 case SE:
  if(stone_)
   ++result;
  result += ref_position_->adjacent_slot_occupied_count();
  break;
 case Center:
  return ref_position_->adjacent_slot_occupied_count();
 default:
  break;
 }
 return result;
}


Game_Panel_Section* Game_Position::get_section()
{
 switch(variant_)
 {
 case SW:
  return section_;
 case NW:
 case NE:
 case SE:
  return ref_position_->get_section();
 default:
  return nullptr;

 }
}

