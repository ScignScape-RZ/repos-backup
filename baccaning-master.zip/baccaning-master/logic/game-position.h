
#ifndef GAME_POSITION__H
#define GAME_POSITION__H


class Game_Panel_Gridline_Edge;
class Game_Panel_Gridline_Intersection;
class Game_Panel_Section;
class Stone_Panel_Display;


#include "../accessors.h"


class Game_Position
{
 union {
  //?Game_Panel_Gridline_Edge* edge_;
  Game_Panel_Gridline_Intersection* intersection_;
  Game_Panel_Section* section_;
  Game_Position* ref_position_;
 };

 Stone_Panel_Display* stone_;

public:

 enum Variant {
  N_A, Center, NW, NE, SE, SW, Edge, Intersection
 };

private:
 Variant variant_;

public:

 ACCESSORS(Variant ,variant)
 ACCESSORS(Stone_Panel_Display* ,stone)
  //?ACCESSORS(Game_Panel_Gridline_Edge* ,edge)
 ACCESSORS(Game_Panel_Gridline_Intersection* ,intersection)
 //ACCESSORS(Game_Panel_Section* ,section)
 ACCESSORS(Game_Position* ,ref_position)

 Game_Panel_Section* get_section();
 void set_section(Game_Panel_Section* s);
 void check_set_ref_position();

 Game_Position* get_section_game_position_nw();
 Game_Position* get_section_game_position_ne();
 Game_Position* get_section_game_position_sw();
 Game_Position* get_section_game_position_se();

 Game_Position();

 int adjacent_slot_occupied_count();

};

#endif
