

#include "game-stone-egraphic.h"

#include "game-panel-section.h"

#include "stone-panel-display.h"

#include "game-panel-gridline-intersection.h"
#include "game-panel-vertical-gridline.h"
#include "game-panel-horizontal-gridline.h"

#include "game-panel-colors.h"

#include "game-position.h"

#include "game-panel-gridline-edge.h"

#include "game-utils.h"


#include <QGraphicsView>
#include <QGraphicsEllipseItem>


#include <QDebug>


Game_Stone_EGraphic::Game_Stone_EGraphic(QGraphicsScene& scene)
 : Game_Stone_Graphic(scene)
{

}

QGraphicsItem* Game_Stone_EGraphic::item()
{
 return ellipse_item_;
}

void Game_Stone_EGraphic::hide()
{
 ellipse_item_->setVisible(false);
}

void Game_Stone_EGraphic::unhide()
{
 ellipse_item_->setVisible(true);
}


void Game_Stone_EGraphic::reset_graphics_item_flags(Stone_Panel_Display::Direction_Status ds)
{
 ellipse_item_->setFlag(QGraphicsItem::ItemIsSelectable);

 if(ds != Stone_Panel_Display::Direction_Status::Choose_Stone_Dialog)
  ellipse_item_->setFlag(QGraphicsItem::ItemIsMovable);
}

