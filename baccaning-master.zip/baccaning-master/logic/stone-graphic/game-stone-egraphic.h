
#ifndef GAME_STONE_EGRAPHIC__H
#define GAME_STONE_EGRAPHIC__H

#include <QList>

#include "stone-panel-display.h"

#include "game-stone-graphic.h"

class QGraphicsScene;
class Stone_Panel_Display;
class Game_Panel_Section;
class Game_Panel_Horizontal_Gridline;
class Game_Panel_Vertical_Gridline;
class Game_Panel_Gridline_Intersection;
class Game_Utils;

class Game_Stone_EGraphic : public Game_Stone_Graphic
{
 //QGraphicsPolygonItem*


protected:
 QGraphicsEllipseItem* ellipse_item_;

public:

 void hide() override;
 void unhide() override;
 QGraphicsItem* item() override;


 void reset_graphics_item_flags(Stone_Panel_Display::Direction_Status ds) override;


 Game_Stone_EGraphic(QGraphicsScene& scene);

};


#endif
