

#include "game-stone-graphic.h"

#include "game-panel-section.h"

#include "stone-panel-display.h"

#include "game-panel-gridline-intersection.h"
#include "game-panel-vertical-gridline.h"
#include "game-panel-horizontal-gridline.h"

#include "game-panel-colors.h"

#include "game-position.h"

#include "game-panel-gridline-edge.h"

#include "game-utils.h"


#include <QGraphicsView>

#include <QDebug>

Game_Stone_Graphic::Game_Stone_Graphic(QGraphicsScene& scene)
 : scene_(scene)
{

}

void Game_Stone_Graphic::init_figure(int center_x, int center_y,
  float scale_factor, const QPen& qpen, const QBrush& qbr,
  Stone_Panel_Display::Direction_Status ds)
{

}


void Game_Stone_Graphic::reset_graphics_item_flags(Stone_Panel_Display::Direction_Status ds)
{

}

int Game_Stone_Graphic::spread()
{
 return 0;
}

void Game_Stone_Graphic::hide()
{

}

QGraphicsItem* Game_Stone_Graphic::item()
{

}

void Game_Stone_Graphic::unhide()
{

}

void Game_Stone_Graphic::reset_current_value(int r)
{

}

void Game_Stone_Graphic::reset_indicators(int center_x, int center_y,
  float scale_factor, Stone_Panel_Display::Direction_Status ds)
{

}

void Game_Stone_Graphic::reset_font_size(int font_size)
{

}

void Game_Stone_Graphic::reset_offsets(std::vector<int>&& ints)
{

}

void Game_Stone_Graphic::reset_radius(int r)
{

}

