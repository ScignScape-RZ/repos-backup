
#ifndef GAME_STONE_GRAPHIC__H
#define GAME_STONE_GRAPHIC__H

#include <QList>

#include <vector>

#include "stone-panel-display.h"

class QGraphicsScene;
class QGraphicsItem;
class Stone_Panel_Display;
class Game_Panel_Section;
class Game_Panel_Horizontal_Gridline;
class Game_Panel_Vertical_Gridline;
class Game_Panel_Gridline_Intersection;
class Game_Utils;

class Game_Stone_Graphic
{
 //QGraphicsPolygonItem*

protected:

 QGraphicsScene& scene_;

public:


 virtual void reset_graphics_item_flags(Stone_Panel_Display::Direction_Status ds);
 virtual void init_figure(int center_x, int center_y,
   float scale_factor, const QPen& qpen, const QBrush& qbr,
   Stone_Panel_Display::Direction_Status ds);

 virtual void reset_offsets(std::vector<int>&& ints);
 virtual void reset_font_size(int font_size);

 virtual QGraphicsItem* item();

 virtual void reset_radius(int r);
 virtual void reset_current_value(int r);

 virtual void hide();
 virtual void unhide();

 virtual int spread();

 virtual void reset_indicators(int center_x, int center_y,
   float scale_factor, Stone_Panel_Display::Direction_Status ds);

 Game_Stone_Graphic(QGraphicsScene& scene);

};


#endif
