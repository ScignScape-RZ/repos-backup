

#include "game-stone-pgraphic.h"

#include "game-panel-section.h"

#include "stone-panel-display.h"

#include "game-panel-gridline-intersection.h"
#include "game-panel-vertical-gridline.h"
#include "game-panel-horizontal-gridline.h"

#include <QGraphicsPolygonItem>

#include "game-panel-colors.h"

#include "game-position.h"

#include "game-panel-gridline-edge.h"

#include "game-utils.h"


#include <QGraphicsView>

#include <QDebug>


Game_Stone_PGraphic::Game_Stone_PGraphic(QGraphicsScene& scene)
 : Game_Stone_Graphic(scene)
{

}

QGraphicsItem* Game_Stone_PGraphic::item()
{
 return polygon_item_;
}

void Game_Stone_PGraphic::hide()
{
 polygon_item_->setVisible(false);
}

void Game_Stone_PGraphic::unhide()
{
 polygon_item_->setVisible(true);
}

void Game_Stone_PGraphic::reset_graphics_item_flags(Stone_Panel_Display::Direction_Status ds)
{
 polygon_item_->setFlag(QGraphicsItem::ItemIsSelectable);

 if(ds != Stone_Panel_Display::Direction_Status::Choose_Stone_Dialog)
  polygon_item_->setFlag(QGraphicsItem::ItemIsMovable);
}


void Game_Stone_PGraphic::init_figure(int center_x, int center_y,
  const QPen& qpen, const QBrush& qbr, Stone_Panel_Display::Direction_Status ds)
{

}


