
#ifndef GAME_STONE_PGRAPHIC__H
#define GAME_STONE_PGRAPHIC__H

#include <QList>

#include "stone-panel-display.h"
#include "game-stone-graphic.h"

class QGraphicsScene;
class Stone_Panel_Display;
class Game_Panel_Section;
class Game_Panel_Horizontal_Gridline;
class Game_Panel_Vertical_Gridline;
class Game_Panel_Gridline_Intersection;
class Game_Utils;

class Game_Stone_PGraphic : public Game_Stone_Graphic
{
 //QGraphicsPolygonItem*

protected:
 QGraphicsPolygonItem* polygon_item_;


public:


 Game_Stone_PGraphic(QGraphicsScene& scene);

 void hide() override;
 void unhide() override;
 QGraphicsItem* item() override;


 virtual void init_figure(int center_x, int center_y,
   const QPen& qpen, const QBrush& qbr, Stone_Panel_Display::Direction_Status ds);

 void reset_graphics_item_flags(Stone_Panel_Display::Direction_Status ds) override;

};


#endif
