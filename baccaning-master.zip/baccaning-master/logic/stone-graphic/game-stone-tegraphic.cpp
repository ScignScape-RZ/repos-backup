

#include "game-stone-tegraphic.h"

#include "game-panel-section.h"

#include "stone-panel-display.h"

#include "game-panel-gridline-intersection.h"
#include "game-panel-vertical-gridline.h"
#include "game-panel-horizontal-gridline.h"

#include "game-panel-colors.h"

#include "game-position.h"

#include "game-panel-gridline-edge.h"

#include "game-utils.h"


#include <QGraphicsView>
#include <QGraphicsEllipseItem>
#include <QDebug>


Game_Stone_TEGraphic::Game_Stone_TEGraphic(QGraphicsScene& scene)
 : Game_Stone_EGraphic(scene), current_font_size_(0),
   text_item_(nullptr), text_item1_(nullptr), text_item2_(nullptr)
{

}

void Game_Stone_TEGraphic::check_init_text(QString label)
{
 if(text_item_)
  return;
 init_text(label, QColor("white"));
 init_text1(label, QColor("grey"));
 init_text2(label, QColor("yellow"));
}

void Game_Stone_TEGraphic::reset_font_size(int s)
{
 current_font_size_ = s;
}

void Game_Stone_TEGraphic::reset_graphics_item_flags(Stone_Panel_Display::Direction_Status ds)
{
 ellipse_item_->setFlag(QGraphicsItem::ItemIsSelectable);

 if(ds != Stone_Panel_Display::Direction_Status::Choose_Stone_Dialog)
  ellipse_item_->setFlag(QGraphicsItem::ItemIsMovable);
}

void Game_Stone_TEGraphic::set_text_item_parents()
{
 if(text_item1_)
  text_item1_->setParentItem(ellipse_item_);
 if(text_item2_)
  text_item2_->setParentItem(ellipse_item_);
 if(text_item_)
  text_item_->setParentItem(ellipse_item_);
}



void Game_Stone_TEGraphic::reset_text_position(int x, int y)
{
 text_item_->setPos(x, y);
}

void Game_Stone_TEGraphic::init_html_text(QString html)
{
 text_item_ = new QGraphicsTextItem;//scene_.addText("");
 text_item_->setHtml(html);
 if(ellipse_item_)
  text_item_->setParentItem(ellipse_item_); //ellipse_item_);
// text_item_->setPos(center_x + scale_factor * x_o, center_y + scale_factor * y_o);

}

void Game_Stone_TEGraphic::reset_text1_position(int x, int y)
{
 text_item1_->setPos(x, y);
}

void Game_Stone_TEGraphic::reset_text2_position(int x, int y)
{
 text_item2_->setPos(x, y);
}

void Game_Stone_TEGraphic::init_html1_text(QString html)
{
 text_item1_ = new QGraphicsTextItem; //scene_.addText("");
 text_item1_->setHtml(html);
 if(ellipse_item_)
  text_item1_->setParentItem(ellipse_item_); //ellipse_item_);
}

void Game_Stone_TEGraphic::init_html2_text(QString html)
{
 text_item2_ = new QGraphicsTextItem; //scene_.addText("");
 text_item2_->setHtml(html);
 if(ellipse_item_)
  text_item2_->setParentItem(ellipse_item_); //ellipse_item_);
}

void Game_Stone_TEGraphic::init_text(QString text, QColor color)
{
 bool text_italic = false;
 text_item_ = new QGraphicsTextItem(text);// scene_.addText(text);
 text_item_->setDefaultTextColor(color);
 text_item_->setFont(QFont("arial", current_font_size_, 900, text_italic));
 if(ellipse_item_)
  text_item_->setParentItem(ellipse_item_);
}

void Game_Stone_TEGraphic::init_text1(QString text, QColor color)
{
 bool text_italic = false;
 text_item1_  = new QGraphicsTextItem(text); //= scene_.addText(text);
 text_item1_->setDefaultTextColor(color);
 text_item1_->setFont(QFont("arial", current_font_size_, 900, text_italic));
 if(ellipse_item_)
  text_item1_->setParentItem(ellipse_item_);
}

void Game_Stone_TEGraphic::init_text2(QString text, QColor color)
{
 bool text_italic = false;
 text_item2_  = new QGraphicsTextItem(text);// scene_.addText(text);
 text_item2_->setDefaultTextColor(color);
 text_item2_->setFont(QFont("arial", current_font_size_, 900, text_italic));
 if(ellipse_item_)
  text_item2_->setParentItem(ellipse_item_);
}

