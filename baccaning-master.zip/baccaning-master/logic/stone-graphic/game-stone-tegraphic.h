
#ifndef GAME_STONE_TEGRAPHIC__H
#define GAME_STONE_TEGRAPHIC__H

#include <QList>

#include "stone-panel-display.h"
#include "game-stone-egraphic.h"

class QGraphicsScene;
class Stone_Panel_Display;
class Game_Panel_Section;
class Game_Panel_Horizontal_Gridline;
class Game_Panel_Vertical_Gridline;
class Game_Panel_Gridline_Intersection;
class Game_Utils;

class Game_Stone_TEGraphic : public Game_Stone_EGraphic
{
 //QGraphicsPolygonItem*

 QGraphicsTextItem* text_item_;
 QGraphicsTextItem* text_item1_;
 QGraphicsTextItem* text_item2_;

 int current_font_size_;

public:


 Game_Stone_TEGraphic(QGraphicsScene& scene);
 void reset_graphics_item_flags(Stone_Panel_Display::Direction_Status ds) override;

 void reset_font_size(int s) override;

 void set_text_item_parents();

 void init_html1_text(QString html);
 void init_html2_text(QString html);
 void init_html_text(QString html);

 void check_init_text(QString label);

 void init_text(QString text, QColor color);
 void init_text1(QString text, QColor color);
 void init_text2(QString text, QColor color);

 void reset_text_position(int x, int y);
 void reset_text1_position(int x, int y);
 void reset_text2_position(int x, int y);


};


#endif
