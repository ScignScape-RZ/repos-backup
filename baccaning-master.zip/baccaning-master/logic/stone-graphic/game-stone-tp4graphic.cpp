

#include "game-stone-tp4graphic.h"

#include "game-panel-section.h"

#include "stone-panel-display.h"

#include "game-panel-gridline-intersection.h"
#include "game-panel-vertical-gridline.h"
#include "game-panel-horizontal-gridline.h"

#include "game-panel-colors.h"

#include "game-position.h"

#include "game-panel-gridline-edge.h"

#include "game-utils.h"


#include <QGraphicsView>
#include <QGraphicsTextItem>

#include <QDebug>

Game_Stone_TP4Graphic::Game_Stone_TP4Graphic(QGraphicsScene& scene)
 : Game_Stone_TPGraphic(scene)
{

}


//void Game_Stone_TP4Graphic::reset_text2_position(int x, int y)
//{
// text_item2_->setPos(x, y);
//}

void Game_Stone_TP4Graphic::reset_text3_position(int x, int y)
{
 text_item3_->setPos(x, y);
}


//void Game_Stone_TP4Graphic::init_html2_text(QString html)
//{
// text_item2_ = scene_.addText("");
// text_item2_->setHtml(html);
// text_item2_->setParentItem(polygon_item_); //ellipse_item_);
//}

void Game_Stone_TP4Graphic::init_html3_text(QString html)
{
 text_item3_ = scene_.addText("");
 text_item3_->setHtml(html);
 text_item3_->setParentItem(polygon_item_); //ellipse_item_);
}
