
#ifndef GAME_STONE_TP4GRAPHIC__H
#define GAME_STONE_TP4GRAPHIC__H

#include <QList>

#include "stone-panel-display.h"
#include "game-stone-tpgraphic.h"

class QGraphicsScene;
class Stone_Panel_Display;
class Game_Panel_Section;
class Game_Panel_Horizontal_Gridline;
class Game_Panel_Vertical_Gridline;
class Game_Panel_Gridline_Intersection;
class Game_Utils;

class Game_Stone_TP4Graphic : public Game_Stone_TPGraphic
{
 //QGraphicsPolygonItem*
 //QGraphicsTextItem* text_item1_;
 //QGraphicsTextItem* text_item2_;
 QGraphicsTextItem* text_item3_;

public:


 Game_Stone_TP4Graphic(QGraphicsScene& scene);


// void init_html1_text(QString html);
// void init_html2_text(QString html);
 void init_html3_text(QString html);

// void reset_text1_position(int x, int y);
// void reset_text2_position(int x, int y);
 void reset_text3_position(int x, int y);


};


#endif
