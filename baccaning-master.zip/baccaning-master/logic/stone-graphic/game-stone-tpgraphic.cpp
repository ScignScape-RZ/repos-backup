

#include "game-stone-tpgraphic.h"

#include "game-panel-section.h"

#include "stone-panel-display.h"

#include "game-panel-gridline-intersection.h"
#include "game-panel-vertical-gridline.h"
#include "game-panel-horizontal-gridline.h"

#include "game-panel-colors.h"

#include "game-position.h"

#include "game-panel-gridline-edge.h"

#include "game-utils.h"


#include <QGraphicsView>
#include <QGraphicsPolygonItem>
#include <QGraphicsTextItem>

#include <QDebug>


Game_Stone_TPGraphic::Game_Stone_TPGraphic(QGraphicsScene& scene)
 : Game_Stone_Graphic(scene), current_font_size_(0),
   polygon_item_(nullptr), text_item_(nullptr), text_item1_(nullptr), text_item2_(nullptr)
{

}

QGraphicsItem* Game_Stone_TPGraphic::item()
{
 return polygon_item_;
}

void Game_Stone_TPGraphic::hide()
{
 polygon_item_->setVisible(false);
}

void Game_Stone_TPGraphic::unhide()
{
 polygon_item_->setVisible(true);
}

void Game_Stone_TPGraphic::reset_font_size(int s)
{
 current_font_size_ = s;
}

void Game_Stone_TPGraphic::set_text_item_parents()
{
 if(text_item1_)
  text_item1_->setParentItem(polygon_item_);
 if(text_item2_)
  text_item2_->setParentItem(polygon_item_);
 if(text_item_)
  text_item_->setParentItem(polygon_item_);
}

void Game_Stone_TPGraphic::reset_graphics_item_flags(Stone_Panel_Display::Direction_Status ds)
{
 polygon_item_->setFlag(QGraphicsItem::ItemIsSelectable);

 if(ds != Stone_Panel_Display::Direction_Status::Choose_Stone_Dialog)
 {
  polygon_item_->setFlag(QGraphicsItem::ItemIsMovable);
  //polygon_item_->setData();
 }
// if(ellipse_item_)
// {
//  ellipse_item_->setFlag(QGraphicsItem::ItemIsSelectable);
//  ellipse_item_->setFlag(QGraphicsItem::ItemIsMovable);
// }
}


void Game_Stone_TPGraphic::init_html_text(QString html)
{
 text_item_ = scene_.addText("");
 text_item_->setHtml(html);
 if(polygon_item_)
  text_item_->setParentItem(polygon_item_); //ellipse_item_);
// text_item_->setPos(center_x + scale_factor * x_o, center_y + scale_factor * y_o);

}

void Game_Stone_TPGraphic::reset_text1_position(int x, int y)
{
 text_item1_->setPos(x, y);
}

void Game_Stone_TPGraphic::reset_text2_position(int x, int y)
{
 text_item2_->setPos(x, y);
}

void Game_Stone_TPGraphic::reset_text_position(int x, int y)
{
 text_item_->setPos(x, y);
}


void Game_Stone_TPGraphic::init_html1_text(QString html)
{
 text_item1_ = scene_.addText("");
 text_item1_->setHtml(html);
 if(polygon_item_)
  text_item1_->setParentItem(polygon_item_); //ellipse_item_);
}

void Game_Stone_TPGraphic::init_html2_text(QString html)
{
 text_item2_ = scene_.addText("");
 text_item2_->setHtml(html);
 if(polygon_item_)
  text_item2_->setParentItem(polygon_item_); //ellipse_item_);
}

void Game_Stone_TPGraphic::init_text(QString text, QColor color)
{
 bool text_italic = false;
 text_item_ = scene_.addText(text);
 text_item_->setDefaultTextColor(color);
 text_item_->setFont(QFont("arial", current_font_size_, 900, text_italic));
 if(polygon_item_)
  text_item_->setParentItem(polygon_item_); //ellipse_item_);
}

void Game_Stone_TPGraphic::check_init_text(QString label)
{
 if(text_item_)
  return;
 init_text(label, QColor("white"));
 init_text1(label, QColor("grey"));
 init_text2(label, QColor("yellow"));
}

void Game_Stone_TPGraphic::init_text1(QString text, QColor color)
{
 bool text_italic = false;
 text_item1_ = scene_.addText(text);
 text_item1_->setDefaultTextColor(color);
 text_item1_->setFont(QFont("arial", current_font_size_, 900, text_italic));
 if(polygon_item_)
  text_item1_->setParentItem(polygon_item_); //ellipse_item_);
}

void Game_Stone_TPGraphic::init_text2(QString text, QColor color)
{
 bool text_italic = false;
 text_item2_ = scene_.addText(text);
 text_item2_->setDefaultTextColor(color);
 text_item2_->setFont(QFont("arial", current_font_size_, 900, text_italic));
 if(polygon_item_)
  text_item2_->setParentItem(polygon_item_); //ellipse_item_);
}

