
#ifndef GAME_STONE_TPGRAPHIC__H
#define GAME_STONE_TPGRAPHIC__H

#include <QList>

#include "stone-panel-display.h"
#include "game-stone-graphic.h"

class QGraphicsScene;
class Stone_Panel_Display;
class Game_Panel_Section;
class Game_Panel_Horizontal_Gridline;
class Game_Panel_Vertical_Gridline;
class Game_Panel_Gridline_Intersection;
class Game_Utils;

class Game_Stone_TPGraphic : public Game_Stone_Graphic
{
 //QGraphicsPolygonItem*
protected:

 QGraphicsTextItem* text_item_;
 QGraphicsTextItem* text_item1_;
 QGraphicsTextItem* text_item2_;

 QGraphicsPolygonItem* polygon_item_;

 int current_font_size_;

public:


 Game_Stone_TPGraphic(QGraphicsScene& scene);

 void reset_graphics_item_flags(Stone_Panel_Display::Direction_Status ds) override;

 void reset_font_size(int s) override;

 void check_init_text(QString text);

 void set_text_item_parents();

 void hide() override;
 void unhide() override;

 QGraphicsItem* item() override;



 void init_html1_text(QString html);
 void init_html2_text(QString html);
 void init_html_text(QString html);

 void init_text(QString text, QColor color);
 void init_text1(QString text, QColor color);
 void init_text2(QString text, QColor color);

 void reset_text_position(int x, int y);
 void reset_text1_position(int x, int y);
 void reset_text2_position(int x, int y);

};


#endif
