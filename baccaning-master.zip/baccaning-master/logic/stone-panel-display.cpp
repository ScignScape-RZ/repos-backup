
#include "stone-panel-display.h"

#include "game-panel-section.h"

#include "game-panel-gridline-intersection.h"

//#include "board1/display/game-color.h"

#include "game-position.h"

#include <QGraphicsSvgItem>

#include "game-panel-colors.h"

#include "stone-graphic/game-stone-egraphic.h"


#include "stone-graphic/game-stone-pgraphic.h"
#include "stone-graphic/game-stone-tegraphic.h"
#include "stone-graphic/game-stone-tpgraphic.h"
#include "stone-graphic/game-stone-tp4graphic.h"

#include <QGraphicsSceneMouseEvent>

#include <QApplication>

//#include "stone-graphic/game-stone-graphic-group-stones.h"
//#include "stone-graphic/game-stone-graphic-d2.h"
//#include "stone-graphic/game-stone-graphic-d3.h"
//#include "stone-graphic/game-stone-graphic-d4.h"
//#include "stone-graphic/game-stone-graphic-d5.h"
//#include "stone-graphic/game-stone-graphic-c6.h"
//#include "stone-graphic/game-stone-graphic-d7.h"
//#include "stone-graphic/game-stone-graphic-d8.h"
//#include "stone-graphic/game-stone-graphic-c8.h"
//#include "stone-graphic/game-stone-graphic-d12.h"
//#include "stone-graphic/game-stone-graphic-d14.h"
//#include "stone-graphic/game-stone-graphic-c20.h"
//#include "stone-graphic/game-stone-graphic-c60.h"
//#include "stone-graphic/game-stone-graphic-d80.h"

#include <QGraphicsScene>
#include <QGraphicsEllipseItem>
#include <QGraphicsTextItem>

#include <QString>

#include <QDebug>

#include <functional>


#define SVG_BASE_PATH "/extension/medusa/baccaning/Images/"


class QGig : public QGraphicsItemGroup
{
//? QPointF current_pos_;

// int initial_center_x_;
// int initial_center_y_;

 int local_radius_;
 int position_gap_;

 std::function<void(int, int, int, int, qreal)> item_moved_callback_;

public:

//? QVariant itemChange(GraphicsItemChange change, const QVariant &value) override;

 QGig(QList<QGraphicsItem*> items, int position_gap, int local_radius, //int initial_center_x,
  //int initial_center_y,
      std::function<void(int, int, int, int, qreal)> item_moved_callback);

 void mouseReleaseEvent(QGraphicsSceneMouseEvent *event) override;
 void mousePressEvent(QGraphicsSceneMouseEvent *event) override;


};


QGig::QGig(QList<QGraphicsItem*> items, int position_gap, int local_radius,
//  int initial_center_x,
//  int initial_center_y,
  std::function<void(int, int, int, int, qreal)> item_moved_callback)
  : QGraphicsItemGroup(nullptr), position_gap_(position_gap), local_radius_(local_radius),
//    initial_center_x_(initial_center_x),
//    initial_center_y_(initial_center_y),
    item_moved_callback_(item_moved_callback)
{
 for(QGraphicsItem* item : items)
 {
  addToGroup(item);
 }
}

void QGig::mousePressEvent(QGraphicsSceneMouseEvent* event)
{
 this->QGraphicsItemGroup::setZValue(2);
 this->QGraphicsItemGroup::mousePressEvent(event);
}


void QGig::mouseReleaseEvent(QGraphicsSceneMouseEvent* event)
{
 this->QGraphicsItemGroup::setZValue(0);

// qDebug() << "POS: " << event->pos();
// qDebug() << "CPOS: " << current_pos_;

// int offset_x = (current_pos_.x()/(double)position_gap_) +
//   (current_pos_.x() < 0? -0.5: 0.5);
// int offset_y = (current_pos_.y()/(double)position_gap_) +
//   (current_pos_.y() < 0? -0.5: 0.5);

// current_pos_.setX(0);
// current_pos_.setY(0);

 QPointF ep = event->pos();
 QPointF esp = event->scenePos();
 QPointF esrp = event->screenPos();


 QPointF myp = pos();
 QPointF mysp = scenePos();


 qreal epx = event->scenePos().x();
 qreal epy = event->scenePos().y();

// int offset_x = pos().x(); //epx - initial_center_x_;
// int offset_y = pos().y(); //epy - initial_center_y_;

// QPointF qpf = view.mapToScene(p);
// QPoint logical_point = qpf.toPoint() / scale_factor;

  double pox =  (local_radius_ + pos().x())/(double)position_gap_;
  double poy =  (local_radius_ + pos().y())/(double)position_gap_;

  int poxs = (int) pox;
  int poys = (int) poy;

  double poxo = pox < 0? pox + poxs: pox - poxs;
  double poyo = poy < 0? poy + poys: poy - poys;

  double poxc = poxo < 0.5? 0.5 - poxo: poxo - 0.5;
  double poyc = poyo < 0.5? 0.5 - poyo: poyo - 0.5;

  qreal avg = (poxc + poyc) / 2;

  double pre_offset_x = ( (local_radius_ + pos().x())/(double)position_gap_) +
    (pos().x() < 0? -0.5: 0.5);

  double pre_offset_y = ( (local_radius_ + pos().y())/(double)position_gap_) +
    (pos().y() < 0? -0.5: 0.5);

  int offset_x = pre_offset_x;
  int offset_y = pre_offset_y;

  this->QGraphicsItemGroup::mouseReleaseEvent(event);

 item_moved_callback_(offset_x, offset_y, poxs, poys, avg);

 // setX(0);
 // setY(0);


 //Q_EMIT(item_moved(offset_x, offset_y));

}


//QVariant QGig::itemChange(GraphicsItemChange change, const QVariant& value)
//{
// //qDebug() << "Change: " << change;
// if (change == ItemPositionChange && scene())
// {
//  QPointF newPos = value.toPointF();
//  if(QApplication::mouseButtons() == Qt::NoButton)
//    //&& qobject_cast<Scene*> (scene()))
//  {
//   current_pos_ = newPos;
//   return QGraphicsItem::itemChange(change, value);

////?   return newPos;
////   QPointF closestPoint = QPointF(20, 20); // computeTopLeftGridPoint(newPos);
////   return closestPoint; //+=offset;
//  }
//  else
//  {
//   current_pos_ = newPos;
//   return QGraphicsItem::itemChange(change, value);

////?   return newPos;
//  }
// }
// else
// {
//  return QGraphicsItem::itemChange(change, value);
// }
//}


Stone_Panel_Display::Stone_Panel_Display(Team_Status team_status,
  int group_index,
  std::function<void(int x, int y, Stone_Panel_Display* _this,
    QGraphicsScene& scene, float scale_factor)> moved_to_intersection_callback,
  std::function<void(int x, int y, Stone_Panel_Display* _this,
    QGraphicsScene& scene, float scale_factor)> moved_to_section_center_callback
  )
 : team_status_(team_status), direction_status_(Direction_Status::Off_Board),
   group_index_(group_index), //?intersection_(nullptr),
   position_(nullptr), graphic_(nullptr),
   scene_status_(Scene_Status::Not_Added), ellipse_item_(nullptr),
   moved_to_intersection_callback_(moved_to_intersection_callback),
   moved_to_section_center_callback_(moved_to_section_center_callback),
   item_group_(nullptr)

//   ellipse_item_(nullptr), polygon_item_(nullptr), secondary_polygon_item_(nullptr),
//   //?stone_kind_text_item_(nullptr), stone_spread_text_item_(nullptr),
//   text_item_(nullptr), text_item1_(nullptr), text_item2_(nullptr), text_item3_(nullptr)
{
 switch(team_status_)
 {
 case Team_Status::South_CKing:
  svg_ = new QGraphicsSvgItem(SVG_BASE_PATH "king_white.svg"); break;
 case Team_Status::South_CQueen:
  svg_ = new QGraphicsSvgItem(SVG_BASE_PATH "queen_white.svg"); break;
 case Team_Status::South_CBishop:
  svg_ = new QGraphicsSvgItem(SVG_BASE_PATH "bishop_white.svg"); break;
 case Team_Status::South_CKnight:
  svg_ = new QGraphicsSvgItem(SVG_BASE_PATH "knight_white.svg"); break;
 case Team_Status::South_CRook:
  svg_ = new QGraphicsSvgItem(SVG_BASE_PATH "rook_white.svg"); break;
 case Team_Status::South_CPawn:
  svg_ = new QGraphicsSvgItem(SVG_BASE_PATH "pawn_white.svg"); break;

 case Team_Status::North_CKing:
  svg_ = new QGraphicsSvgItem(SVG_BASE_PATH "king_black.svg"); break;
 case Team_Status::North_CQueen:
  svg_ = new QGraphicsSvgItem(SVG_BASE_PATH "queen_black.svg"); break;
 case Team_Status::North_CBishop:
  svg_ = new QGraphicsSvgItem(SVG_BASE_PATH "bishop_black.svg"); break;
 case Team_Status::North_CKnight:
  svg_ = new QGraphicsSvgItem(SVG_BASE_PATH "knight_black.svg"); break;
 case Team_Status::North_CRook:
  svg_ = new QGraphicsSvgItem(SVG_BASE_PATH "rook_black.svg"); break;
 case Team_Status::North_CPawn:
  svg_ = new QGraphicsSvgItem(SVG_BASE_PATH "pawn_black.svg"); break;

 default:
  ellipse_item_ = new QGraphicsEllipseItem();
  ellipse_item_->setFlag(QGraphicsItem::ItemIsSelectable);
  ellipse_item_->setFlag(QGraphicsItem::ItemIsMovable);

  svg_ = new QGraphicsSvgItem(SVG_BASE_PATH "plus.svg");

  //svg_ = nullptr;
  break;
 }

 if(svg_)
 {
//  svg_->setFlag(QGraphicsItem::ItemIsSelectable);
//  svg_->setFlag(QGraphicsItem::ItemIsMovable);
 }


}

void Stone_Panel_Display::remove_from_board()
{
 if(item_group_)
  item_group_->setVisible(false);
}

bool Stone_Panel_Display::is_south()
{
 switch(team_status_)
 {
 case Team_Status::South_CKing:
 case Team_Status::South_BKing:
 case Team_Status::South_CQueen:
 case Team_Status::South_BQueen:
 case Team_Status::South_CBishop:
 case Team_Status::South_BBishop:
 case Team_Status::South_CKnight:
 case Team_Status::South_BKnight:
 case Team_Status::South_CRook:
 case Team_Status::South_BRook:
 case Team_Status::South_CPawn:
 case Team_Status::South_BPawn:
 case Team_Status::South_Guard:
 case Team_Status::South_Submarine:
 case Team_Status::South_Onside_Submarine:
  return true;

 default:
  return false;
 }

}

bool Stone_Panel_Display::is_north()
{
 switch(team_status_)
 {
 case Team_Status::North_CKing:
 case Team_Status::North_BKing:
 case Team_Status::North_CQueen:
 case Team_Status::North_BQueen:
 case Team_Status::North_CBishop:
 case Team_Status::North_BBishop:
 case Team_Status::North_CKnight:
 case Team_Status::North_BKnight:
 case Team_Status::North_CRook:
 case Team_Status::North_BRook:
 case Team_Status::North_CPawn:
 case Team_Status::North_BPawn:
 case Team_Status::North_Guard:
 case Team_Status::North_Submarine:
 case Team_Status::North_Onside_Submarine:
  return true;

 default:
  return false;
 }
}

QString Stone_Panel_Display::informal_label()
{
 switch(team_status_)
 {
 case Team_Status::South_CKing:
 case Team_Status::South_BKing:
 case Team_Status::North_CKing:
 case Team_Status::North_BKing:
  return "King";
 case Team_Status::South_CQueen:
 case Team_Status::South_BQueen:
 case Team_Status::North_CQueen:
 case Team_Status::North_BQueen:
  return "Queen";
 case Team_Status::South_CBishop:
 case Team_Status::South_BBishop:
 case Team_Status::North_CBishop:
 case Team_Status::North_BBishop:
  return "Bishop";
 case Team_Status::South_CKnight:
 case Team_Status::South_BKnight:
 case Team_Status::North_CKnight:
 case Team_Status::North_BKnight:
  return "Knight";
 case Team_Status::South_CRook:
 case Team_Status::South_BRook:
 case Team_Status::North_CRook:
 case Team_Status::North_BRook:
  return "Rook";
 case Team_Status::South_CPawn:
 case Team_Status::South_BPawn:
 case Team_Status::North_CPawn:
 case Team_Status::North_BPawn:
  return "Pawn";
 case Team_Status::South_Guard:
 case Team_Status::North_Guard:
  return "Land Guard";

 case Team_Status::South_Submarine:
 case Team_Status::North_Submarine:
 case Team_Status::South_Onside_Submarine:
 case Team_Status::North_Onside_Submarine:
  return "Submarine";

 default:
  return "??";
 }
}

QString Stone_Panel_Display::description()
{
 switch(team_status_)
 {
 case Team_Status::South_CKing:
  return "SK";
 case Team_Status::South_CQueen:
  return "SQ";
 case Team_Status::South_CBishop:
  return "SB";
 case Team_Status::South_CKnight:
  return "SN";
 case Team_Status::South_CRook:
  return "SR";
 case Team_Status::South_CPawn:
  return "SP";
 case Team_Status::South_Guard:
  return "SG";
 case Team_Status::South_Onside_Submarine:
 case Team_Status::South_Submarine:
  return "SS";


 case Team_Status::North_CKing:
  return "NK";
 case Team_Status::North_CQueen:
  return "NQ";
 case Team_Status::North_CBishop:
  return "NB";
 case Team_Status::North_CKnight:
  return "NN";
 case Team_Status::North_CRook:
  return "NR";
 case Team_Status::North_CPawn:
  return "NP";
 case Team_Status::North_Guard:
  return "NG";
 case Team_Status::North_Submarine:
 case Team_Status::North_Onside_Submarine:
  return "NS";

 default:
  return "??";
 }
}


void Stone_Panel_Display::set_extra(int value)
{
 extras_[0] = value;
}

void Stone_Panel_Display::resize_extras(int size)
{
 extras_.resize(size);
}


void Stone_Panel_Display::init_qpen_and_qbrush_doubled_top(QPen& qpen, QBrush& qbr)
{
 qpen = QPen(QColor(global_colors->doubled_top_outer_color()));
 qpen.setWidth(8);
 qbr = QBrush(QColor(global_colors->south_player_stone_light_inner_color()));

// switch(team_status_)
// {
// case Team_Status::South_D5:
// case Team_Status::South_D7:
//  qpen = QPen(QColor(global_colors->south_player_stone_light_outer_color()));
//  qpen.setWidth(8);
//  qbr = QBrush(QColor(global_colors->south_player_stone_light_inner_color()));
//  break;
// case Team_Status::North_D5:
// case Team_Status::North_D7:
//  qpen = QPen(QColor(global_colors->north_player_stone_light_outer_color()));
//  qpen.setWidth(4);
//  qbr = QBrush(QColor(global_colors->north_player_stone_light_inner_color()));
//  break;
// default:
//  break;

// }
}


void Stone_Panel_Display::init_qpen_and_qbrush(QPen& qpen, QBrush& qbr)
{
#ifdef HIDE
 switch(team_status_)
 {

 case Team_Status::South_G2:
 case Team_Status::South_D80:
 case Team_Status::South_D12G:
 case Team_Status::South_D14G:
  qpen.setColor(global_colors->south_player_stone_light_outer_color());
  qbr.setColor(global_colors->south_player_stone_light_inner_color());
  break;

 case Team_Status::South_C20L:
  qpen.setColor(global_colors->south_player_stone_light_outer_color());
  qbr.setColor(global_colors->south_player_stone_light_inner_color());
  break;

 case Team_Status::North_G2:
 case Team_Status::North_D12G:
 case Team_Status::North_D14G:
 case Team_Status::North_D80:
 case Team_Status::North_C20L:
  qpen.setColor(global_colors->north_player_stone_light_outer_color());
  qbr.setColor(global_colors->north_player_stone_light_inner_color());
  break;

 case Team_Status::South_D5:
 case Team_Status::South_D7:
  // depends on whether center or slot ...
  if(direction_status_ == Direction_Status::Panel_Center)
  {
   qpen.setColor(global_colors->south_player_stone_dark_outer_color());
   qbr.setColor(global_colors->south_player_stone_dark_inner_color());
  }
  else
  {
   qpen.setColor(global_colors->south_player_stone_light_outer_color());
   qbr.setColor(global_colors->south_player_stone_light_inner_color());
  }
  break;

 case Team_Status::North_D5:
 case Team_Status::North_D7:
  // depends on whether center or slot ...
  if(direction_status_ == Direction_Status::Panel_Center)
  {
   qpen.setColor(global_colors->north_player_stone_dark_outer_color());
   qbr.setColor(global_colors->north_player_stone_dark_inner_color());
  }
  else if(direction_status_ == Direction_Status::Panel_Center_Doubled_Base)
  {
   qpen.setColor(global_colors->north_player_stone_dark_outer_color());
   qbr.setColor(global_colors->north_player_stone_dark_inner_color());
  }
  else
  {
   qpen.setColor(global_colors->north_player_stone_light_outer_color());
   qbr.setColor(global_colors->north_player_stone_light_inner_color());
  }
  break;

 case Team_Status::South_D2:
  if(current_value_ == 0)
  {
   qpen.setColor(global_colors->south_player_stone_dark_outer_color());
   qbr.setColor(global_colors->south_player_stone_dark_inner_color());
  }
  else
  {
   qpen.setColor(global_colors->south_player_stone_light_outer_color());
   qbr.setColor(global_colors->south_player_stone_light_inner_color());
  }
  break;

 case Team_Status::North_D2:
  if(current_value_ == 0)
  {
   qpen.setColor(global_colors->north_player_stone_dark_outer_color());
   qbr.setColor(global_colors->north_player_stone_dark_inner_color());
  }
  else
  {
   qpen.setColor(global_colors->north_player_stone_light_outer_color());
   qbr.setColor(global_colors->north_player_stone_light_inner_color());
  }
  break;



 case Team_Status::South_G1:
// case Team_Status::South_D2:
 case Team_Status::South_D3:
 case Team_Status::South_D4:
// case Team_Status::South_D5:
 case Team_Status::South_C6:
// case Team_Status::South_D7:
 case Team_Status::South_C8:
 case Team_Status::South_D8D:
 case Team_Status::South_D8R:
 case Team_Status::South_D12F:
 case Team_Status::South_D14F:
 //case Team_Status::South_C20L:
 case Team_Status::South_C20R:
 case Team_Status::South_C60:
    qpen.setColor(global_colors->south_player_stone_dark_outer_color());
    qbr.setColor(global_colors->south_player_stone_dark_inner_color());
  break;

//?
// case Team_Status::North_G2:
// case Team_Status::North_D12G:
// case Team_Status::North_D14G:
//  qpen.setColor(global_colors->north_player_stone_light_outer_color());
//  qbr.setColor(global_colors->north_player_stone_light_inner_color());
//  break;


 case Team_Status::North_G1:
 //?case Team_Status::North_D2:
 case Team_Status::North_D3:
 case Team_Status::North_D4:
// case Team_Status::North_D5:
 case Team_Status::North_C6:
// case Team_Status::North_D7:
 case Team_Status::North_C8:
 case Team_Status::North_D8D:
 case Team_Status::North_D8R:
 case Team_Status::North_D12F:
 case Team_Status::North_D14F:
 //case Team_Status::North_C20L:
 case Team_Status::North_C20R:
 case Team_Status::North_C60:
  qpen.setColor(global_colors->north_player_stone_dark_outer_color());
  qbr.setColor(global_colors->north_player_stone_dark_inner_color());
  break;


 default:
  break;
 }

 switch(team_status_)
 {
 default:
  qbr.setStyle(Qt::SolidPattern);
  qpen.setWidth(4);
  qpen.setJoinStyle(Qt::MiterJoin);
  break;
 }

#endif
}

//int Stone_Panel_Display::get_d12_value()
//{
// if( (current_value_ % 1) == 0)
//  return current_value_ + 1;
// return current_value_ + 13;
//}

//int Stone_Panel_Display::get_d14_value()
//{
// if( (current_value_ % 1) == 0)
//  return current_value_ + 1;
// return current_value_ + 15;

//}


QString Stone_Panel_Display::s_or_n()
{
#ifdef HIDE
 switch(team_status_)
 {
 case Team_Status::North_G1:
 case Team_Status:: North_G2:
 case Team_Status::North_D2:
 case Team_Status::North_D3:
 case Team_Status::North_D4:
 case Team_Status::North_D5:
 case Team_Status::North_C6:
 case Team_Status::North_D7:
 case Team_Status::North_C8:
 case Team_Status::North_D8D:
 case Team_Status::North_D8R:
 case Team_Status::North_D12F:
 case Team_Status::North_D12G:
 case Team_Status::North_D14F:
 case Team_Status::North_D14G:
 case Team_Status::North_C20L:
 case Team_Status::North_C20R:
 case Team_Status::North_C60:
 case Team_Status::North_D80:
  return "N";
 default:
  return "S";
 }
#endif
}


QString Stone_Panel_Display::get_d4_label()
{
 return QString("%1-%2-%3-%4").arg(11).arg(12).arg(13).arg(14);
}

QString Stone_Panel_Display::get_label(int& font_size, int& x_offset, int& y_offset)
{
#ifdef HIDE
 // font_size should be already a valid value;
 //  will only be modified in a few cases

 switch(team_status_)
 {
 case Team_Status::North_G1:
 case Team_Status::North_G2:
 case Team_Status::South_G1:
 case Team_Status::South_G2:
  {
   Stone_Panel_Display* spd = section_->get_center_stone();
   if(spd)
   {
    font_size = 6;
    if(direction_e())
    {
     if(current_value_ > 9)
      x_offset = 1;
     else
      x_offset = 4;
    }
    if(direction_s())
    {
     y_offset = 3;
    }
   }
   else
    font_size = 8;
   return get_group_stone_label();
  }


 case Team_Status::North_D4:
 case Team_Status::South_D4:
  return get_d4_label();

 case Team_Status::North_D8R:
 case Team_Status::South_D8R:
  {
   switch(current_value_)
   {
   case 0:
    return ".1";
   case 1:
    return ".2";
   case 2:
    return ".3";
   case 3:
    return "++";
   case 4:
    return "^";
   case 5:
    return "-^";
   case 6:
    return "^-";
   case 7:
    return "~";
   }
  }
  break;

 case Team_Status::North_C6:
 case Team_Status::South_C6:
  return QString::number(group_index_ + 1);
  //?return QString("%1\n %2").arg(current_value_).arg(group_index_ + 1);

 case Team_Status::North_D12F:
 case Team_Status::South_D12F:
 case Team_Status::North_D12G:
 case Team_Status::South_D12G:
  return QString::number(get_d12_value());

 case Team_Status::North_D14F:
 case Team_Status::South_D14F:
 case Team_Status::North_D14G:
 case Team_Status::South_D14G:
  return QString::number(get_d12_value());

 case Team_Status::North_D80:
 case Team_Status::South_D80:
  return QString::number(current_value_ + 1);


 default:
  return QString::number(current_value_);
 }
#endif
}

QString Stone_Panel_Display::get_group_stone_label()
{
 return QString();
// switch(group_number_)
// {
// default:
//  return QString::number(group_number_);
// }
}

int Stone_Panel_Display::spread()
{
#ifdef HIDE
 switch(team_status_)
 {
 case Team_Status::North_G1:
 case Team_Status::South_G1:
 case Team_Status::North_G2:
 case Team_Status::South_G2:
  return 1;

 case Team_Status::North_D2:
 case Team_Status::South_D2:
  return 2;

 case Team_Status::North_D3:
 case Team_Status::South_D3:
  return 3;

 case Team_Status::North_D4:
 case Team_Status::South_D4:
  return 4;

 case Team_Status::North_D5:
 case Team_Status::South_D5:
  return 5;

 case Team_Status::North_C6:
 case Team_Status::South_C6:
  return 6;

 case Team_Status::North_D7:
 case Team_Status::South_D7:
  return 7;

 case Team_Status::North_C8:
 case Team_Status::South_C8:
 case Team_Status::North_D8R:
 case Team_Status::South_D8R:
 case Team_Status::North_D8D:
 case Team_Status::South_D8D:
  return 8;

 case Team_Status::North_D12F:
 case Team_Status::North_D12G:
 case Team_Status::South_D12F:
 case Team_Status::South_D12G:
  return 12;

 case Team_Status::North_D14F:
 case Team_Status::North_D14G:
 case Team_Status::South_D14F:
 case Team_Status::South_D14G:
  return 14;

 case Team_Status::North_C20L:
 case Team_Status::North_C20R:
 case Team_Status::South_C20L:
 case Team_Status::South_C20R:
  return 20;

 case Team_Status::North_C60:
 case Team_Status::South_C60:
  return 60;

 case Team_Status::North_D80:
 case Team_Status::South_D80:
  return 80;

 }
#endif
}

bool Stone_Panel_Display::is_code_stone()
{
#ifdef HIDE
 switch(team_status_)
 {
 case Team_Status::South_C6:
 case Team_Status::South_C8:
 case Team_Status::South_C20L:
 case Team_Status::South_C20R:
 case Team_Status::South_C60:

 case Team_Status::North_C6:
 case Team_Status::North_C8:
 case Team_Status::North_C20L:
 case Team_Status::North_C20R:
 case Team_Status::North_C60:
  return true;

 default:
  return false;

 }
#endif
}


void Stone_Panel_Display::check_init_graphic(QGraphicsScene& scene)
{
#ifdef HIDE
 if(graphic_)
  return;

 switch(spread())
 {
 case 1:
  graphic_ = new Game_Stone_Graphic_Group_Stones(scene);
  break;
 case 2:
  graphic_ = new Game_Stone_Graphic_D2(scene);
  break;
 case 3:
  graphic_ = new Game_Stone_Graphic_D3(scene);
  break;
 case 4:
  graphic_ = new Game_Stone_Graphic_D4(scene);
  break;
 case 5:
  graphic_ = new Game_Stone_Graphic_D5(scene);
  break;
 case 6:
  graphic_ = new Game_Stone_Graphic_C6(scene);
  break;
 case 7:
  graphic_ = new Game_Stone_Graphic_D7(scene);
  break;
 case 8:
  if(is_code_stone())
  {
   graphic_ = new Game_Stone_Graphic_C8(scene);
  }
  else
  {
   graphic_ = new Game_Stone_Graphic_D8(scene);
  }
  break;
 case 12:
  graphic_ = new Game_Stone_Graphic_D12(scene);
  break;
 case 14:
  graphic_ = new Game_Stone_Graphic_D14(scene);
  break;
 case 20:
  graphic_ = new Game_Stone_Graphic_C20(scene);
  break;
 case 60:
  graphic_ = new Game_Stone_Graphic_C60(scene);
  break;
 case 80:
  graphic_ = new Game_Stone_Graphic_D80(scene);
  break;
 default:
  break;
 }

// QVariant qv = qVariantFromValue((void*)this);
// graphic_->item()->setData(0, qv);

// QVariant qv = QVariant("Stone");
// graphic_->item()->setData(0, qv);

// else if(spread() == 4)
// {
// }
#endif
}

void Stone_Panel_Display::reset_text_items(QGraphicsScene& scene, float center_x, float center_y, float scale_factor, const QPen& qpen, const QBrush& qbr)
{
#ifdef HIDE

 check_init_graphic(scene);

 bool text_italic = false;
 int font_size = 11;
 int x_offset = 0;
 int y_offset = 0;
 QString label = get_label(font_size, x_offset, y_offset);

 center_x += x_offset * scale_factor;
 center_y += y_offset * scale_factor;

 //int font_size = 11;
 int offset = 0;

 if(spread() == 1)
 {
  if(section_->slot_occupied_count_given_center_occupied() > 0)
  {
   Game_Stone_TPGraphic* tpgraphic = static_cast<Game_Stone_TPGraphic*>(graphic_);

   int x_o = direction_e()? -3 : -6;
   int y_o = direction_s()? -6 : -6;

   tpgraphic->init_html_text(QString("<b style='font-weight:900;font-size:6pt;color:white;background:purple'>%1</b>").arg(label));
   tpgraphic->reset_text_position(center_x + scale_factor * x_o, center_y + scale_factor * y_o);

//   text_item_ = scene_.addText("");
//   text_item_->setHtml(QString("<b style='font-weight:900;font-size:6pt;color:white;background:purple'>%1</b>").arg(label));
//   text_item_->setParentItem(polygon_item_); //ellipse_item_);
//   text_item_->setPos(center_x + scale_factor * x_o, center_y + scale_factor * y_o);
  }
 }


 if(spread() == 4)
 {
  Game_Stone_TP4Graphic* tp4graphic = static_cast<Game_Stone_TP4Graphic*>(graphic_);

  int cx = center_x - 6 * scale_factor;
  int cxr = center_x - 3 * scale_factor;
  int cy = center_y - 5 * scale_factor;
  QStringList qsl = label.split('-');

  tp4graphic->init_html2_text(QString("<b style='font-size:7pt;color:yellow;background:rgba(100,80,20,0.6)'>%1</b>").arg(qsl[3]));
  tp4graphic->reset_text2_position(cx, cy + ( 5 * scale_factor));

  tp4graphic->init_html1_text(QString("<b style='font-size:7pt;color:yellow;background:rgba(100,80,20,0.6)'>%1</b>").arg(qsl[1]));
  tp4graphic->reset_text1_position(cx - ( 5 * scale_factor), cy);

  tp4graphic->init_html3_text(QString("<b style='font-size:7pt;color:yellow;background:rgba(100,80,20,0.6)'>%1</b>").arg(qsl[2]));
  tp4graphic->reset_text3_position(cxr + ( 5 * scale_factor), cy);

  // //  add this last to have it on top...
  tp4graphic->init_html_text(QString("<b style='color:white;background:rgba(80,80,20,0.6)'>%1</b>").arg(qsl[0]));
  tp4graphic->reset_text_position(cx, cy - ( 5 * scale_factor));


//  text_item_ = scene_.addText(""); //qsl[0]);
//  text_item_->setParentItem(polygon_item_); //ellipse_item_);
//  text_item_->setPos(cx, cy - ( 5 * scale_factor));
//  text_item_->setHtml(QString("<b style='color:white;background:rgba(80,80,20,0.6)'>%1</b>").arg(qsl[0]));
//  text_item_->setFont(QFont("arial", font_size, 900, true));
//  text_item1_->setHtml(QString("<b style='font-size:7pt;color:yellow;background:rgba(100,80,20,0.6)'>%1</b>").arg(qsl[1]));
//  text_item1_->setParentItem(polygon_item_); //ellipse_item_);
//  text_item1_->setPos(cx - ( 5 * scale_factor), cy);
//  text_item2_ = scene_.addText("");
//  text_item2_->setHtml(QString("<b style='font-size:7pt;color:yellow;background:rgba(100,80,20,0.6)'>%1</b>").arg(qsl[3]));
//  text_item2_->setParentItem(polygon_item_); //ellipse_item_);
//  text_item2_->setPos(cx, cy + ( 5 * scale_factor));
//  text_item2_->setDefaultTextColor(QColor("black"));
//  text_item2_->setFont(QFont("arial", font_size, 900, true));
//  text_item1_ = scene_.addText("");
//  text_item1_->setHtml(QString("<b style='font-size:7pt;color:yellow;background:rgba(100,80,20,0.6)'>%1</b>").arg(qsl[1]));
//  text_item1_->setParentItem(polygon_item_); //ellipse_item_);
//  text_item1_->setPos(cx - ( 5 * scale_factor), cy);
//  text_item1_->setFont(QFont("arial", font_size, 900, true));
//  text_item3_ = scene_.addText("");
//  text_item3_->setHtml(QString("<b style='font-size:7pt;color:yellow;background:rgba(100,80,20,0.6)'>%1</b>").arg(qsl[2]));
//  text_item3_->setParentItem(polygon_item_); //ellipse_item_);
//  text_item3_->setPos(cxr + ( 5 * scale_factor), cy);
//  text_item3_->setFont(QFont("arial", font_size, 900, true));


  return;
 }

 if(spread() == 12)
 {
  center_y += 3;
 }

//  switch(direction_status_)
//  {
//  case Direction_Status::Panel_NW:
//  case Direction_Status::Panel_NE:
//   center_y += 3;
//   break;
//  case Direction_Status::Panel_SE:
//  case Direction_Status::Panel_SW:
//   center_x -= 1;
//   break;
//  }

 if(spread() == 6)
 {
  switch(direction_status_)
  {
  case Direction_Status::Panel_NW:
   center_x -= 2;
   center_y += 3;
   break;
  case Direction_Status::Panel_NE:
   center_x -= 1; //-= 5;
   center_y += 3;
   break;
  case Direction_Status::Panel_SE:
   center_x += 0; //-= 5;
   center_y += 3;
   break;
  case Direction_Status::Panel_SW:
   center_x -= 1;
   center_y += 3;
   break;
  }
 }

 switch(team_status_)
 {
 case Team_Status::North_D12F:
 case Team_Status::South_D12F:
 case Team_Status::North_D12G:
 case Team_Status::South_D12G:
 case Team_Status::North_D14F:
 case Team_Status::South_D14F:
 case Team_Status::North_D14G:
 case Team_Status::South_D14G:


 case Team_Status::North_D8R:
 case Team_Status::South_D8R:
   //?
  font_size = 10;
  goto case_TP;

// goto case_Team_Status_South_C8;


// goto case_Team_Status_South_C8;


 case Team_Status::North_D4:
 case Team_Status::South_D4:
   //?
  font_size = 4;
  goto case_TP;

 case Team_Status::North_D5:
 case Team_Status::South_D5:
  if(current_value_ < 4)
  {
   //?
   font_size = 10;
   goto case_TP;
  }
  else
  {
   // not showing a label ...
   break;
  }


// goto case_Team_Status_South_C8;

 case Team_Status::North_C6:
 case Team_Status::South_C6:
   //?
  font_size = 7;
  goto case_TP;


// goto case_Team_Status_South_C8;

 case Team_Status::North_C20L:
 case Team_Status::North_C20R:
 case Team_Status::South_C20L:
 case Team_Status::South_C20R:


 case Team_Status::North_C60:
 case Team_Status::South_C60:


 case Team_Status::South_G1:
 case Team_Status::South_G2:
 case Team_Status::North_G1:
 case Team_Status::North_G2:
  font_size = 8;
  offset = 1;
  goto case_TP;


 case Team_Status::South_D3:
 case Team_Status::North_D3:
  font_size = 8;
  goto case_TP;

case_TP:
 {
  graphic_->reset_font_size(font_size);
  Game_Stone_TPGraphic* tpgraphic = static_cast<Game_Stone_TPGraphic*>(graphic_);

  tpgraphic->check_init_text(label);
   //tpgraphic->init_text(label, QColor("white"));
  tpgraphic->reset_text_position(center_x - (scale_factor * (3.9 + offset) ), center_y - ( (6.1 - offset) * scale_factor));
  tpgraphic->reset_text1_position(center_x - (scale_factor * (4.1 + offset) ), center_y - ( (6.2 - offset) * scale_factor));
  tpgraphic->reset_text2_position(center_x - (scale_factor * (4 + offset) ), center_y - ( (6.3 - offset) * scale_factor));
 }
 break;

 case Team_Status::North_D80:
 case Team_Status::South_D80:
   //?
  font_size = 7;
 case Team_Status::North_C8:
 case Team_Status::South_C8:
  {
   Game_Stone_TEGraphic* tegraphic = static_cast<Game_Stone_TEGraphic*>(graphic_);

   tegraphic->check_init_text(label);
   tegraphic->reset_text_position(center_x - (scale_factor * (3.9 + offset) ), center_y - ( (6.1 - offset) * scale_factor));
   tegraphic->reset_text1_position(center_x - (scale_factor * (4.1 + offset) ), center_y - ( (6.2 - offset) * scale_factor));
   tegraphic->reset_text2_position(center_x - (scale_factor * (4 + offset) ), center_y - ( (6.3 - offset) * scale_factor));
  }
//   text_item_ = scene_.addText(label);
//   text_item_->setParentItem(polygon_item_); //ellipse_item_);
//   text_item_->setPos(center_x - (scale_factor * (4 + offset) ), center_y - ( (6.3 - offset) * scale_factor));
//   text_item_->setDefaultTextColor(QColor("yellow"));
//   text_item_->setFont(QFont("arial", font_size, 900, text_italic));

//   text_item1_ = scene_.addText(label);
//   text_item1_->setParentItem(polygon_item_); //ellipse_item_);
//   text_item1_->setPos(center_x - (scale_factor * (4.1 + offset) ), center_y - ( (6.2 - offset) * scale_factor));
//   text_item1_->setDefaultTextColor(QColor("grey"));
//   text_item1_->setFont(QFont("arial", font_size, 900, text_italic));

//   text_item_ = scene_.addText(label);
//   text_item_->setParentItem(polygon_item_); //ellipse_item_);
//   text_item_->setPos(center_x - (scale_factor * (3.9 + offset) ), center_y - ( (6.1 - offset) * scale_factor));
// //   text_item_->setDefaultTextBackground(QColor("white"));
//   text_item_->setDefaultTextColor(QColor("white"));
//   text_item_->setFont(QFont("arial", font_size, 900, text_italic));
//  }
 }
}

void Stone_Panel_Display::construct_octagon(QPolygonF& poly, float center_x, float center_y,
  float scale_factor, float x_offset, float y_offset, float width)
{
 poly
   << QPointF(center_x - scale_factor * x_offset, center_y + width)
   << QPointF(center_x - scale_factor * x_offset, center_y - width)

   << QPointF(center_x - width, center_y - scale_factor * y_offset)
   << QPointF(center_x + width, center_y - scale_factor * y_offset)

   << QPointF(center_x + scale_factor * x_offset, center_y - width)
   << QPointF(center_x + scale_factor * x_offset, center_y + width)

   << QPointF(center_x + width, center_y + scale_factor * y_offset)
   << QPointF(center_x - width, center_y + scale_factor * y_offset)
      ;

}w
w

void Stone_Panel_Display::construct_deco_plus(QPolygonF& poly, float center_x, float center_y,
  float scale_factor, float offset, float width, float deco_offset)
{
 poly
   << QPointF(center_x - scale_factor * offset, center_y - scale_factor * width)
   << QPointF(center_x - scale_factor * deco_offset, center_y - scale_factor * width)
   << QPointF(center_x - scale_factor * width, center_y - scale_factor * deco_offset)

   << QPointF(center_x - scale_factor * width, center_y - scale_factor * offset)
   << QPointF(center_x + scale_factor * width, center_y - scale_factor * offset)

   << QPointF(center_x + scale_factor * width, center_y - scale_factor * deco_offset)
   << QPointF(center_x + scale_factor * deco_offset, center_y - scale_factor * width)
   << QPointF(center_x + scale_factor * offset, center_y - scale_factor * width)


   << QPointF(center_x + scale_factor * offset, center_y + scale_factor * width)
   << QPointF(center_x + scale_factor * deco_offset, center_y + scale_factor * width)
   << QPointF(center_x + scale_factor * width, center_y + scale_factor * deco_offset)


   << QPointF(center_x + scale_factor * width, center_y + scale_factor * width)
   << QPointF(center_x + scale_factor * width, center_y + scale_factor * offset)

   << QPointF(center_x - scale_factor * width, center_y + scale_factor * offset)
   << QPointF(center_x - scale_factor * width, center_y + scale_factor * deco_offset)
   << QPointF(center_x - scale_factor * deco_offset, center_y + scale_factor * width)

   << QPointF(center_x - scale_factor * offset, center_y + scale_factor * width)
   << QPointF(center_x - scale_factor * offset, center_y - scale_factor * width)
      ;

}


void Stone_Panel_Display::construct_plus(QPolygonF& poly, float center_x, float center_y,
  float scale_factor, float offset, float width)
{
 poly
   << QPointF(center_x - scale_factor * offset, center_y - scale_factor * width)
   << QPointF(center_x - scale_factor * width, center_y - scale_factor * width)

   << QPointF(center_x - scale_factor * width, center_y - scale_factor * offset)
   << QPointF(center_x + scale_factor * width, center_y - scale_factor * offset)

   << QPointF(center_x + scale_factor * width, center_y - scale_factor * width)
   << QPointF(center_x + scale_factor * offset, center_y - scale_factor * width)

   << QPointF(center_x + scale_factor * offset, center_y + scale_factor * width)
   << QPointF(center_x + scale_factor * width, center_y + scale_factor * width)

   << QPointF(center_x + scale_factor * width, center_y + scale_factor * width)
   << QPointF(center_x + scale_factor * width, center_y + scale_factor * offset)

   << QPointF(center_x - scale_factor * width, center_y + scale_factor * offset)
   << QPointF(center_x - scale_factor * width, center_y + scale_factor * width)

   << QPointF(center_x - scale_factor * offset, center_y + scale_factor * width)
   << QPointF(center_x - scale_factor * offset, center_y - scale_factor * width)
      ;

}


void Stone_Panel_Display::construct_triangle_up(QPolygonF& poly, float center_x, float center_y,
  float scale_factor, float width, float height, float y_offset)
{
 poly
   << QPointF(center_x - scale_factor * width/2, center_y + scale_factor * y_offset)
   << QPointF(center_x + scale_factor * width/2, center_y + scale_factor * y_offset)
   << QPointF(center_x, center_y - scale_factor * height);

}


void Stone_Panel_Display::construct_triangle_down(QPolygonF& poly, float center_x, float center_y,
  float scale_factor, float width, float height, float y_offset)
{
 poly
   << QPointF(center_x - scale_factor * width/2, center_y - scale_factor * height)
   << QPointF(center_x + scale_factor * width/2, center_y - scale_factor * height)
   << QPointF(center_x, center_y + scale_factor * y_offset);

}


void Stone_Panel_Display::reset_graphics_item_flags()
{
 graphic_->reset_graphics_item_flags(direction_status_);
// if(polygon_item_)
// {
//  polygon_item_->setFlag(QGraphicsItem::ItemIsSelectable);
//  polygon_item_->setFlag(QGraphicsItem::ItemIsMovable);
// }
// if(ellipse_item_)
// {
//  ellipse_item_->setFlag(QGraphicsItem::ItemIsSelectable);
//  ellipse_item_->setFlag(QGraphicsItem::ItemIsMovable);
// }

#endif
}

void Stone_Panel_Display::reset_polygon(QGraphicsScene& scene, float center_x, float center_y, float scale_factor, const QPen& qpen, const QBrush& qbr)
{
#ifdef HIDE
 check_init_graphic(scene);
 int radius = 4;
 switch(team_status_)
 {
 case Team_Status::South_C6:
 case Team_Status::North_C6:
  {
   graphic_->init_figure(center_x, center_y, scale_factor, qpen, qbr, direction_status_);
  }
  break;

 case Team_Status::South_D4:
 case Team_Status::North_D4:
  {
   graphic_->init_figure(center_x, center_y, scale_factor, qpen, qbr, direction_status_);
  }
  break;

 case Team_Status::South_D12G:
 case Team_Status::South_D12F:
 case Team_Status::North_D12G:
 case Team_Status::North_D12F:
  {
   // case Team_Status::South_D8D:
   // case Team_Status::North_D8D:
   //radius = 5;
   graphic_->init_figure(center_x, center_y, scale_factor, qpen, qbr, direction_status_);
  }
  break;
  //goto case_Default;


 case Team_Status::South_D2:
 case Team_Status::North_D2:
  {
   // direction_status_ might be unused
   graphic_->init_figure(center_x, center_y, scale_factor, qpen, qbr, direction_status_);
//   int r = 8;
//   polygon_item_ = draw_square_at_center(scene, center_x, center_y, r, qpen, qbr);
//   reset_graphics_item_flags(ds);
  }
  break;

 case Team_Status::South_D8D:
 case Team_Status::South_D8R:
 case Team_Status::North_D8D:
 case Team_Status::North_D8R:
  {
   graphic_->init_figure(center_x, center_y, scale_factor, qpen, qbr, direction_status_);
//   int x_offset = 3;
//   int y_offset = 3;
//   int width = 4;
//   QPolygonF poly;
//   construct_octagon(poly, center_x, center_y, scale_factor, x_offset, y_offset, width);
//   polygon_item_ = scene_.addPolygon(poly, qpen, qbr);
//   reset_graphics_item_flags(ds);
//   polygon_item_->setFlag(QGraphicsItem::ItemIsSelectable);
//   polygon_item_->setFlag(QGraphicsItem::ItemIsMovable);
  }
  break;

 case Team_Status::South_D14F:
 case Team_Status::South_D14G:
 case Team_Status::North_D14F:
 case Team_Status::North_D14G:
  {
   graphic_->init_figure(center_x, center_y, scale_factor, qpen, qbr, direction_status_);
//   QPolygonF poly;

//   float x_offset = 4;
//   float y_offset = 4;
//   float width = 2;
//   construct_octagon(poly, center_x, center_y, scale_factor, x_offset, y_offset, width);
//   polygon_item_ = scene_.addPolygon(poly, qpen, qbr);
//   reset_graphics_item_flags(ds);

 //  polygon_item_->setFlag(QGraphicsItem::ItemIsSelectable);
  }
  break;

// case Team_Status::South_C20L:
// case Team_Status::South_C20R:
// case Team_Status::North_C20L:
// case Team_Status::North_C20R:?


  case Team_Status::North_D5:
  case Team_Status::South_D5:
  {
   graphic_->init_figure(center_x, center_y, scale_factor, qpen, qbr, direction_status_);
  }
  break;

 case Team_Status::South_C60:
 case Team_Status::North_C60:
  {
   graphic_->init_figure(center_x, center_y, scale_factor, qpen, qbr, direction_status_);

//   QPolygonF poly;

//   float width = 12;
//   float height = 8;
//   float y_offset = 4;

//   //?construct_plus(poly, center_x, center_y, scale_factor, offset, width);
//   construct_triangle_up(poly, center_x, center_y, scale_factor, width, height, y_offset);
//   polygon_item_ = scene_.addPolygon(poly, qpen, qbr);
////   polygon_item_->setFlag(QGraphicsItem::ItemIsSelectable);
//   reset_graphics_item_flags(ds);

//   QPolygonF poly;

//   float offset = 4;
//   float width = 1;
//   float deco_offset = 3;

//   construct_deco_plus(poly, center_x, center_y, scale_factor, offset, width, deco_offset);
//   polygon_item_ = scene_.addPolygon(poly, qpen, qbr);
//   polygon_item_->setFlag(QGraphicsItem::ItemIsSelectable);

//?
//   ellipse_item_ = scene_.addEllipse(center_x - 10, center_y - 10,
//     20, 20, qpen, qbr);
//   ellipse_item_->setFlag(QGraphicsItem::ItemIsSelectable);

  }
  break;

  case Team_Status::South_D80:
  case Team_Status::North_D80:
   {
    graphic_->init_figure(center_x, center_y, scale_factor, qpen, qbr, direction_status_);
//    QPolygonF poly;

//    float width = 12;
//    float height = 8;
//    float y_offset = 4;

//     //?construct_plus(poly, center_x, center_y, scale_factor, offset, width);
//    construct_triangle_down(poly, center_x, center_y, scale_factor, width, height, y_offset);
//    polygon_item_ = scene_.addPolygon(poly, qpen, qbr);
////    polygon_item_->setFlag(QGraphicsItem::ItemIsSelectable);

//    reset_graphics_item_flags(ds);

   }
   break;


//? case Team_Status::North_C6:

//? case Team_Status::South_D80:
//? case Team_Status::North_D80:
  case Team_Status::South_D7:
  case Team_Status::North_D7:
  {
   graphic_->reset_current_value(current_value_);
   graphic_->init_figure(center_x, center_y, scale_factor, qpen, qbr, direction_status_);
  }
  break;


//   case Team_Status::South_D3:
//   case Team_Status::North_D3:
// case Team_Status::South_D4:
// case Team_Status::North_D4:


 case Team_Status::South_C20L:
 case Team_Status::North_C20L:
 case Team_Status::South_C20R:
 case Team_Status::North_C20R:
//?  radius = 5;

//?  goto case_Default;
  {
   float offset;
   float width;
   float deco_offset;
   if(section_->slot_occupied_count_given_center_occupied() > 0)
   {
    graphic_->reset_offsets({2, 3, 1});
//    offset = 3;
//    width = 2;
//    deco_offset = 1;
   }
   else
   {
    graphic_->reset_offsets({3, 4, 2});
//    offset = 4;
//    width = 3;
//    deco_offset = 2;
   }
   graphic_->init_figure(center_x, center_y, scale_factor, qpen, qbr, direction_status_);

//   QPolygonF poly;


//   construct_deco_plus(poly, center_x, center_y, scale_factor, offset, width, deco_offset);
//   polygon_item_ = scene_.addPolygon(poly, qpen, qbr);
////   polygon_item_->setFlag(QGraphicsItem::ItemIsSelectable);
//   reset_graphics_item_flags(ds);

   //draw_circle_at_center(scene, center_x, center_y, radius * scale_factor, qpen, qbr);
   //draw_square_at_center(scene, center_x, center_y, radius * scale_factor, qpen, qbr);


  }
  break;



// case Team_Status::South_C60:
// case Team_Status::North_C60:
//  {
////   QPolygonF poly1;

////   float x_offset1 = 4;
////   float y_offset1 = 2;
////   float width1 = 4;
////   construct_octagon(poly1, center_x, center_y, scale_factor, x_offset1, y_offset1, width1);
////   polygon_item_ = scene_.addPolygon(poly1, qpen, qbr);
////   polygon_item_->setFlag(QGraphicsItem::ItemIsSelectable);

//   QPolygonF poly2;

//   float x_offset2 = 2;
//   float y_offset2 = 4;
//   float width2 = 4;
//   construct_octagon(poly2, center_x, center_y, scale_factor, x_offset2, y_offset2, width2);
//   secondary_polygon_item_ = scene_.addPolygon(poly2, qpen, qbr);
//   secondary_polygon_item_->setFlag(QGraphicsItem::ItemIsSelectable);

//  }
//  break;


 case Team_Status::South_G1:
 case Team_Status::South_G2:
 case Team_Status::North_G1:
 case Team_Status::North_G2:
  {
   if(section_->slot_occupied_count_given_center_occupied() > 0)
   {
    graphic_->reset_radius(2);
//    radius = 2;
   }
   else
   {
    graphic_->reset_radius(4);
 //   radius = 4;
   }
   graphic_->init_figure(center_x, center_y, scale_factor, qpen, qbr, direction_status_);
  }

  //?radius = 2;
  //?
//  goto case_Default;
//  //
//  {
//   int w;
//   if(section_->slot_occupied_count_given_center_occupied() > 0)
//   {
//    w = 3;
//   }
//   else
//   {
//    w = 6;
//   }
//   QPolygonF poly;
//   poly
//     << QPointF(center_x - scale_factor * w, center_y - scale_factor * w)
//     << QPointF(center_x + scale_factor * w, center_y - scale_factor * w)
//     << QPointF(center_x + scale_factor * w, center_y + scale_factor * w)
//     << QPointF(center_x - scale_factor * w, center_y + scale_factor * w);

//   polygon_item_ = scene_.addPolygon(poly, qpen, qbr);
////   polygon_item_->setFlag(QGraphicsItem::ItemIsSelectable);
//   reset_graphics_item_flags(ds);

////?
////   ellipse_item_ = scene_.addEllipse(center_x - 3 * scale_factor,
////     center_y - 3 * scale_factor, 6 * scale_factor,
////     6 * scale_factor, qpen, qbr);
////   ellipse_item_->setFlag(QGraphicsItem::ItemIsSelectable);


//  }
  break;


 case Team_Status::South_C8:
 case Team_Status::North_C8:
  {
   graphic_->init_figure(center_x, center_y, scale_factor, qpen, qbr, direction_status_);

//   QPolygonF poly;
//   poly
//     << QPointF(center_x - scale_factor * 3, center_y - scale_factor * 3)
//     << QPointF(center_x + scale_factor * 3, center_y - scale_factor * 3)
//     << QPointF(center_x + scale_factor * 3, center_y + scale_factor * 3)
//     << QPointF(center_x - scale_factor * 3, center_y + scale_factor * 3);

//   polygon_item_ = scene_.addPolygon(poly, qpen, qbr);
//   polygon_item_->setFlag(QGraphicsItem::ItemIsSelectable);

//   ellipse_item_ = scene_.addEllipse(center_x - 3 * scale_factor,
//     center_y - 3 * scale_factor, 6 * scale_factor,
//     6 * scale_factor, qpen, qbr);
////   ellipse_item_->setFlag(QGraphicsItem::ItemIsSelectable);
//   reset_graphics_item_flags(ds);


  }
  break;

// case Team_Status::North_D8R:
// case Team_Status::South_D8R:

// case Team_Status::North_D12F:
// case Team_Status::North_D12G:
// case Team_Status::South_D12F:
// case Team_Status::South_D12G:
  case Team_Status::North_D3:
  case Team_Status::South_D3:
  {
   graphic_->init_figure(center_x, center_y, scale_factor, qpen, qbr, direction_status_);
  }

  break;

case_Default:
 default:
  {
//   QPolygonF poly;
//   poly
//       << QPointF(center_x - scale_factor * radius, center_y)
//       << QPointF(center_x, center_y - scale_factor * radius)
//       << QPointF(center_x + scale_factor * radius, center_y)
//       << QPointF(center_x, center_y + scale_factor * radius);

//   polygon_item_ = scene_.addPolygon(poly, qpen, qbr);
////   polygon_item_->setFlag(QGraphicsItem::ItemIsSelectable);
//   reset_graphics_item_flags(ds);
  }
 }
#endif
}

//?
//void Stone_Panel_Display::check_init_graphic_initial(QGraphicsScene& scene)
//{
// if(section_)
// {
//  check_init_graphic(scene);
// }
//}

void Stone_Panel_Display::set_current_value_from_string(QString str)
{

// switch(team_status_)
// {
// default:
//  current_value_ = str.toInt();
//  break;
// //case Team_Status::
// }
}


void Stone_Panel_Display::check_add_to_scene(QGraphicsScene& scene)
{
 switch(scene_status_)
 {
 case Scene_Status::Not_Added:
//?
  scene.addItem(svg_);
  scene_status_ = Scene_Status::Added_Visible;
  break;
 case Scene_Status::Added_Visible:
  svg_->setVisible(true);
  break;
 case Scene_Status::Added_Not_Visible:
  svg_->setVisible(false);
  break;
 }

}

void Stone_Panel_Display::create_background_ellipse(QGraphicsScene& scene, float scale_factor,
  int center_x, int center_y)
{
 if(!ellipse_item_)
 {
  ellipse_item_ = new QGraphicsEllipseItem();

  QPen qpen;
  QBrush qbr;
  QChar d = description().at(0);
  qpen = Qt::NoPen;
  if(d == 'S')
  {
   qbr = QBrush(global_colors->south_stone_background_color());
  }
  else
  {
   qbr = QBrush(global_colors->north_stone_background_color());
  }

  int local_width = 10;
  int pen_width = 5;

  qpen.setWidth(pen_width);

  ellipse_item_->setBrush(qbr);
 //?ellipse_item_->setBrush(QBrush(QColor("white")));
  ellipse_item_->setPen(qpen);

//?  position_ellipse_item(center_x * scale_factor, center_y * scale_factor, local_width/2 * scale_factor);

  //?ellipse_item_->setParentItem(svg_);

//?  svg_->setParentItem(ellipse_item_);

//  svg_->setZValue(1);
//  ellipse_item_->setZValue(2);
  //ellipse_item_->setRect(0, 0, 20, 20);

  ellipse_item_->setFlag(QGraphicsItem::ItemIsSelectable);
  ellipse_item_->setFlag(QGraphicsItem::ItemIsMovable);

  //?
  scene.addItem(ellipse_item_);
 }

 int local_width = 20;

// ellipse_item_->setRect(center_x - (local_width/2 * scale_factor),
//   center_y - (local_width/2 * scale_factor),
//   local_width * scale_factor, local_width * scale_factor);

//?

// position_ellipse_item(0, 0, //local_width/2 * scale_factor, local_width/2 * scale_factor,
//                       local_width/2 * scale_factor);

//? position_ellipse_item(center_x * scale_factor, center_y * scale_factor, local_width/2 * scale_factor);

 //?position_ellipse_item(local_width * scale_factor, local_width * scale_factor, local_width/2 * scale_factor);

// ellipse_item_->setRect( (center_x * scale_factor) - (10 * scale_factor),
//   (center_y * scale_factor) - (10 * scale_factor));


}

void Stone_Panel_Display::position_ellipse_item(int center_x, int center_y, int radius)
{
 ellipse_item_->setRect(center_x - radius, center_y - radius, radius * 2, radius * 2);
}


void Stone_Panel_Display::draw_to_scene(QGraphicsScene& scene, float scale_factor)
{

 //if(position_ == nullptr)
 // return;
// QGraphicsItem::ItemIsMovable

 if(direction_status_ == Direction_Status::Off_Board)
  return;

 if(direction_status_ == Direction_Status::Panel_Intersection)
 {
  Game_Panel_Gridline_Intersection* gpgi = position_->intersection();
  const Game_Panel_Horizontal_Gridline& h = gpgi->horizontal_gridline();
  const Game_Panel_Vertical_Gridline& v = gpgi->vertical_gridline();
  int center_x = v.local_x_center();
  int center_y = h.local_y_center();
  qreal rw = svg_->boundingRect().width();
  svg_->setScale((20 * scale_factor) /rw);
  check_add_to_scene(scene);
  create_background_ellipse(scene, scale_factor, center_x, center_y);

  int local_width = 20;
  int local_radius = local_width/2 * scale_factor;

  if(!item_group_)
  {
   svg_->setPos(0, 0); //-(local_width/2 * scale_factor), -(local_width/2 * scale_factor));
   position_ellipse_item(local_radius, local_radius, local_radius);
   item_group_ = new QGig({ellipse_item_, svg_}, 20 * scale_factor, local_radius,
                          //?center_x, center_y,
    [this, &scene, scale_factor, center_x, center_y](int x, int y, int sx, int sy, qreal distance)
    {
//     qreal px = point.x();
//     qreal py = point.y();

     moved_to_intersection_callback_(x, y, this, scene, scale_factor);
     item_group_->setSelected(false);
    });
   scene.addItem(item_group_);

   item_group_->setPos( (center_x * scale_factor) - local_radius,
     (center_y * scale_factor) - local_radius );
   item_group_->setFlag(QGraphicsItem::ItemIsSelectable);
   item_group_->setFlag(QGraphicsItem::ItemIsMovable);
  }
  else
  {
   item_group_->setPos( (center_x * scale_factor) - local_radius,
     (center_y * scale_factor) - local_radius );
  }
  return;
 }
 else if(direction_status_ == Direction_Status::Panel_Center)
 {

  //Game_Panel_Section* section = position_->section();
  int center_x = section_->local_x_center();
  int center_y = section_->local_y_center();
  qreal rw = svg_->boundingRect().width();
  svg_->setScale((14 * scale_factor) /rw);

  Scene_Status scs = scene_status_;
  check_add_to_scene(scene);

  if(scs == Scene_Status::Not_Added)
  {
   QPen qpen;
   QBrush qbr;
   if(team_status_ == Team_Status::South_Guard)
   {
    qpen = QPen(global_colors->south_guard_outer_color());
    qbr = QBrush(global_colors->south_guard_inner_color());
   }
   else if( (team_status_ == Team_Status::South_Submarine)
            || (team_status_ == Team_Status::South_Onside_Submarine))
   {
    qpen = QPen(global_colors->south_submarine_outer_color());
    qbr = QBrush(global_colors->south_submarine_inner_color());
   }
   else if(team_status_ == Team_Status::North_Guard)
   {
    qpen = QPen(global_colors->north_guard_outer_color());
    qbr = QBrush(global_colors->north_guard_inner_color());
   }
   else if( (team_status_ == Team_Status::North_Submarine)
      || (team_status_ == Team_Status::North_Onside_Submarine) )

   {
    qpen = QPen(global_colors->north_submarine_outer_color());
    qbr = QBrush(global_colors->north_submarine_inner_color());
   }



   int pen_width = 8;

   qpen.setWidth(pen_width);

   ellipse_item_->setBrush(qbr);
   //?ellipse_item_->setBrush(QBrush(QColor("white")));
   ellipse_item_->setPen(qpen);
   scene.addItem(ellipse_item_);
   scene_status_ = Scene_Status::Added_Visible;
  }


  //  create_background_ellipse(scene, scale_factor, center_x, center_y);

  int local_width = 20;
  int local_radius = local_width/2 * scale_factor;

  int effective_local_radius = is_guard()?
    local_radius * .75 :  local_radius;


  if(!item_group_)
  {
   svg_->setPos(0, 0); //-(local_width/2 * scale_factor), -(local_width/2 * scale_factor));

   position_ellipse_item(effective_local_radius, effective_local_radius, effective_local_radius);

//   if(team_status_ == Team_Status::North_Guard || team_status_ == Team_Status::South_Guard)
//   {
//    position_ellipse_item(local_radius * .75, local_radius * .75, local_radius * .75);
//   }
//   else
//   {
//    position_ellipse_item(effective_local_radius, effective_local_radius, effective_local_radius);
//   }



   item_group_ = new QGig({ellipse_item_, svg_}, 20 * scale_factor, effective_local_radius,
                          //?center_x, center_y,
    [this, &scene, scale_factor, center_x, center_y](int x, int y, int sx, int sy, qreal distance)
    {
//     qreal px = point.x();
//     qreal py = point.y();

     if(is_guard())
     {
      moved_to_section_center_callback_(sx, sy, this, scene, scale_factor);
     }
     else if(team_status_ == Team_Status::North_BPawn ||
             team_status_ == Team_Status::North_CPawn ||
             team_status_ == Team_Status::South_BPawn ||
             team_status_ == Team_Status::South_CPawn
             )
     {
      moved_to_intersection_callback_(x, y, this, scene, scale_factor);
     }
     else
     {
      moved_to_intersection_callback_(x, y, this, scene, scale_factor);
     }


     item_group_->setSelected(false);
    });
   scene.addItem(item_group_);

   item_group_->setPos( (center_x * scale_factor) - effective_local_radius,
     (center_y * scale_factor) - effective_local_radius );
   item_group_->setFlag(QGraphicsItem::ItemIsSelectable);
   item_group_->setFlag(QGraphicsItem::ItemIsMovable);
  }
  else
  {
   QPen qpen;
   QBrush qbr;
   if(team_status_ == Team_Status::South_Guard)
   {
    qpen = QPen(global_colors->south_guard_outer_color());
    qbr = QBrush(global_colors->south_guard_inner_color());
   }
   else if( (team_status_ == Team_Status::South_Submarine)
            || (team_status_ == Team_Status::South_Onside_Submarine) )
   {
    qpen = QPen(global_colors->south_submarine_outer_color());
    qbr = QBrush(global_colors->south_submarine_inner_color());
   }
   else if(team_status_ == Team_Status::North_Guard)
   {
    qpen = QPen(global_colors->north_guard_outer_color());
    qbr = QBrush(global_colors->north_guard_inner_color());
   }
   else if( (team_status_ == Team_Status::North_Submarine)
            || (team_status_ == Team_Status::North_Onside_Submarine) )

   {
    qpen = QPen(global_colors->north_submarine_outer_color());
    qbr = QBrush(global_colors->north_submarine_inner_color());
   }

   int pen_width = 8;

   qpen.setWidth(pen_width);

   ellipse_item_->setBrush(qbr);
   //?ellipse_item_->setBrush(QBrush(QColor("white")));
   ellipse_item_->setPen(qpen);
   scene_status_ = Scene_Status::Added_Visible;

   item_group_->setPos( (center_x * scale_factor) - effective_local_radius,
     (center_y * scale_factor) - effective_local_radius );
  }
  return;
 }
#ifdef HIDE

 if(section_)
 {
  float center_x = scale_factor * (section_->local_x_center());
  float center_y = scale_factor * (section_->local_y_center());


//  int center_x = section_->local_x_center();// * scale_factor;
//  int center_y = section_->local_y_center();// * scale_factor;

  if(svg_)
  {
   qreal rw = svg_->boundingRect().width();
   qreal rh = svg_->boundingRect().height();
   svg_->setScale((20 * scale_factor) /rw);
   svg_->setPos( (center_x * scale_factor) - (10 * scale_factor),
     (center_y * scale_factor) - (10 * scale_factor));
   check_add_to_scene(scene);

   //scene.addItem(svg_);
  }
  else if(ellipse_item_)
  {
   int local_width = 12;

   ellipse_item_->setRect(center_x - (local_width/2 * scale_factor),
     center_y - (local_width/2 * scale_factor),
     local_width * scale_factor, local_width * scale_factor);

   if(scene_status_ == Scene_Status::Not_Added)
   {
    QPen qpen;
    QBrush qbr;
    if(team_status_ == Team_Status::South_Guard)
    {
     qpen = QPen(global_colors->south_guard_outer_color());
     qbr = QBrush(global_colors->south_guard_inner_color());
    }
    else if(team_status_ == Team_Status::North_Guard)
    {
     qpen = QPen(global_colors->north_guard_outer_color());
     qbr = QBrush(global_colors->north_guard_inner_color());
    }

    int pen_width = 8;

    qpen.setWidth(pen_width);

    ellipse_item_->setBrush(qbr);
    //?ellipse_item_->setBrush(QBrush(QColor("white")));
    ellipse_item_->setPen(qpen);
    scene.addItem(ellipse_item_);
    scene_status_ = Scene_Status::Added_Visible;
   }
  }
 }
#endif

#ifdef HIDE
 if(section_)
 {
  int center_x = section_->local_x_center();// * scale_factor;
  int center_y = section_->local_y_center();// * scale_factor;
  offset_by_direction_status(center_x, center_y, scale_factor);

  QPen qpen;
  QBrush qbr;
  init_qpen_and_qbrush(qpen, qbr);

  reset_polygon(scene, center_x, center_y, scale_factor, qpen, qbr);
  reset_text_items(scene, center_x, center_y, scale_factor, qpen, qbr);

//  QPolygonF poly;
//  poly
//       << QPointF(center_x - scale_factor * 4, center_y)
//       << QPointF(center_x, center_y - scale_factor * 4)
//       << QPointF(center_x + scale_factor * 4, center_y)
//       << QPointF(center_x, center_y + scale_factor * 4);

//  polygon_item_ = scene_.addPolygon(poly, qpen, qbr);
//  polygon_item_->setFlag(QGraphicsItem::ItemIsSelectable);


  show_kind_indicators(scene, center_x, center_y, scale_factor);

  graphic_->item()->setData(0, qVariantFromValue((void*) this));

 }


// QGraphicsItem* item = graphic_->item();
// item->set


#endif
}

//ellipse_item_ = scene_.addEllipse(center_x - scale_factor * 4,
// center_x - scale_factor * 4, scale_factor * 8,
// scale_factor * 8, qpen, qbr);

void Stone_Panel_Display::move_to_section(Game_Panel_Section* section,
  Stone_Panel_Display::Direction_Status ds)
{
 section_ = section;
 direction_status_ = ds;
}

void Stone_Panel_Display::move_to_intersection(Game_Panel_Gridline_Intersection* gpgi)
{
 if(!position_)
 {
  position_ = new Game_Position;
 }
// else
// {
//  position_ = new Game_Position;
// }
 position_->set_intersection(gpgi);
 direction_status_ = Direction_Status::Panel_Intersection;
}


void Stone_Panel_Display::to_doubled_top()
{
 //? direction_status_ = Direction_Status::Panel_Center_Doubled_Top;
}

void Stone_Panel_Display::to_doubled_base()
{
 //?direction_status_ = Direction_Status::Panel_Center_Doubled_Base;
}

QGraphicsItem* Stone_Panel_Display::get_graphics_item()
{
 if(graphic_)
  return graphic_->item();
 else
  return nullptr;
}

QGraphicsPolygonItem* Stone_Panel_Display::draw_square_at_center(QGraphicsScene& scene, float center_x, float center_y, float radius,
  const QPen& qpen, const QBrush& qbr)
{
 QPolygonF poly;
 poly
        << QPointF(center_x - radius/2, center_y - radius/2)
        << QPointF(center_x + radius/2, center_y - radius/2)
        << QPointF(center_x + radius/2, center_y + radius/2)
        << QPointF(center_x - radius/2, center_y + radius/2);

 return scene.addPolygon(poly, qpen, qbr);

}

void Stone_Panel_Display::draw_diamond_at_center(QGraphicsScene& scene, float center_x, float center_y, float radius,
  QPen& qpen, QBrush& qbr)
{
 QPolygonF poly;
 poly
        << QPointF(center_x - radius/2, center_y)
        << QPointF(center_x, center_y - radius/2)
        << QPointF(center_x + radius/2, center_y)
        << QPointF(center_x, center_y + radius/2);

 scene.addPolygon(poly, qpen, qbr);
}


QGraphicsEllipseItem* Stone_Panel_Display::draw_circle_at_center(QGraphicsScene& scene, float center_x, float center_y, float radius,
  const QPen& qpen, const QBrush& qbr, QGraphicsPolygonItem* parent)
{
 if(parent)
 {
  QGraphicsEllipseItem* result = new QGraphicsEllipseItem(center_x - radius/2, center_y - radius/2, radius, radius, parent);
  result->setBrush(qbr);
  result->setPen(qpen);
  return result;
 }
 else
 {
  return scene.addEllipse(center_x - radius/2, center_y - radius/2, radius, radius, qpen, qbr);
 }
}



void Stone_Panel_Display::show_kind_indicators_d8d(QGraphicsScene& scene, float center_x, float center_y, float scale_factor)
{
 int radius = scale_factor * 2.5;
 int iradius = scale_factor * 1;
 int ioffset = scale_factor * 3;
 int poffset = scale_factor * 1;

 int xoffset;// = scale_factor * 4;
 int yoffset;// = scale_factor * 4;
 int yraise = 0;// = scale_factor * 4;

 //?graphic_->reset_current_value(current_value_);
 graphic_->reset_indicators(center_x, center_y, scale_factor, direction_status_);

  // scene.addPolygon(poly, qpen, qbr);

 //scene_.addEllipse(center_x - 3, center_y - 3, 6, 6, qpen, qbr);

 //draw_circle_at_corner(scene, center_x + xoffset, center_y + yoffset, radius, qpen, qbr);
 //draw_diamond_at_corner(scene, center_x + xoffset, center_y + yoffset, radius, qpen, qbr);
 //draw_square_at_center(scene, center_x + xoffset, center_y + yoffset, radius, qpen, qbr);
}


void Stone_Panel_Display::show_kind_indicators_c6(QGraphicsScene& scene, float center_x, float center_y, float scale_factor)
{

 int radius = scale_factor * 3;
 int iradius = scale_factor * 1;
 int ioffset = scale_factor * 3;
 int poffset = scale_factor * 1;

 graphic_->reset_indicators(center_x, center_y, scale_factor, direction_status_);

 //?graphic_->reset_current_value(current_value_);

}

void Stone_Panel_Display::show_kind_indicators(QGraphicsScene& scene, float center_x, float center_y, float scale_factor)
{
 int radius = scale_factor * 3;
 int iradius = scale_factor * 1;
 int offset = scale_factor * 4;
 int ioffset = scale_factor * 3;
 int poffset = scale_factor * 1;

 QPen qpen;  //= QPen(QColor("black"));
 QBrush qbr; //= QBrush(QColor("orange"));

 switch(team_status_)
 {
// case Team_Status::South_C6:
// case Team_Status::North_C6:
//  show_kind_indicators_c6(scene, center_x, center_y, scale_factor);
//  break;

// case Team_Status::South_D8D:
// case Team_Status::North_D8D:
//  show_kind_indicators_d8d(scene, center_x, center_y, scale_factor);
//  break;

 default:
  break;




// case Team_Status::South_C8:
//  qpen = QPen(QColor("black"));
//  qbr = QBrush(QColor("orange"));
//  scene.addEllipse(center_x - offset, center_y - offset, radius, radius, qpen, qbr);
//  break;
// case Team_Status::North_C8:
//  qpen = QPen(QColor("black"));
//  qbr = QBrush(QColor("orange"));
//  scene.addEllipse(center_x - offset, center_y - offset, radius, radius, qpen, qbr);
//  break;

// case Team_Status::South_D5:
//  qpen = QPen(QColor("black"));
//  qbr = QBrush(QColor("orange"));
//  scene.addEllipse(center_x + offset, center_y + offset, radius, radius, qpen, qbr);
//  break;
// case Team_Status::North_D5:
//  qpen = QPen(QColor("black"));
//  qbr = QBrush(QColor("orange"));
//  scene.addEllipse(center_x - offset, center_y - offset, radius, radius, qpen, qbr);
//  break;

// case Team_Status::South_D7:
//  qpen = QPen(QColor("black"));
//  qbr = QBrush(QColor("orange"));
//  scene.addEllipse(center_x + offset, center_y + offset, radius, radius, qpen, qbr);
//  scene.addEllipse(center_x - offset, center_y + offset, radius, radius, qpen, qbr);
//  break;
// case Team_Status::North_D7:
//  qpen = QPen(QColor("black"));
//  qbr = QBrush(QColor("orange"));
//  scene.addEllipse(center_x - offset, center_y - offset, radius, radius, qpen, qbr);
//  qbr = QBrush(QColor("black"));
//  scene.addEllipse(center_x - ioffset, center_y - ioffset, iradius, iradius, qpen, qbr);
//  //?scene_.addEllipse(center_x + poffset, center_y - offset, radius, radius, qpen, qbr);
//  break;

// case Team_Status::South_D2:
// case Team_Status::North_D2:
//  qpen = QPen(QColor("black"));
//  qbr = QBrush(QColor("orange"));
//  scene_.addEllipse(center_x, center_y, radius, radius, qpen, qbr);
//  break;

 }
}


void Stone_Panel_Display::offset_by_direction_status(int& x, int& y,
 float scale_factor)
{
#ifdef HIDE
 switch(direction_status_)
 {
 case Direction_Status::Panel_NW:
  x -= 5;
  y -= 5;
  break;
 case Direction_Status::Panel_2NW:
  x -= 10;
  y -= 10;
  break;
 case Direction_Status::Panel_N:
  y -= 10;
  break;
 case Direction_Status::Panel_NE:
  x += 5;
  y -= 5;
  break;
 case Direction_Status::Panel_2NE:
  x += 10;
  y -= 10;
  break;
 case Direction_Status::Panel_E:
  x += 10;
  break;
 case Direction_Status::Panel_SE:
  x += 5;
  y += 5;
  break;
 case Direction_Status::Panel_2SE:
  x += 10;
  y += 10;
  break;
 case Direction_Status::Panel_S:
  y += 10;
  break;
 case Direction_Status::Panel_SW:
  x -= 5;
  y += 5;
  break;
 case Direction_Status::Panel_2SW:
  x -= 10;
  y += 10;
  break;
 case Direction_Status::Panel_W:
  x -= 10;
  break;
 default:
  break;
 }
 x *= scale_factor;
 y *= scale_factor;
#endif
}



void Stone_Panel_Display::move(Game_Panel_Section* section,
 Direction_Status direction_status)
{
 section_ = section;
 direction_status_ = direction_status;
}



