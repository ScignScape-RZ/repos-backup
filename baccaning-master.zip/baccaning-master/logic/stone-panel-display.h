
#ifndef STONE_PANEL_DISPLAY__H
#define STONE_PANEL_DISPLAY__H

#include <QString>

#include "../accessors.h"

#include <QVector>
#include <QMap>

#include <QGraphicsSvgItem>

#include <functional>

class QPolygonF;

class Game_Panel_Section;
class QBrush;
class QPen;
class QGraphicsScene;


class QGraphicsEllipseItem;
class QGraphicsPolygonItem;
class QGraphicsItem;

class QGraphicsTextItem;

class Game_Position;
class Game_Panel_Intersection;
class Game_Panel_Gridline_Intersection;

class QGig;

class Game_Stone_Graphic;

class Stone_Panel_Display
{
public:

 enum class Team_Status {
  South_CKing, South_BKing,
  South_CQueen, South_BQueen,
  South_CBishop, South_BBishop,
  South_CKnight, South_BKnight, South_Lance_Knight,
  South_CRook, South_BRook,
  South_CPawn, South_BPawn, South_Promoted_Pawn,
  South_Guard, South_Onside_Submarine, South_Submarine,

  North_CKing, North_BKing,
  North_CQueen, North_BQueen,
  North_CBishop, North_BBishop,
  North_CKnight, North_BKnight, North_Lance_Knight,
  North_CRook, North_BRook,
  North_CPawn, North_BPawn, North_Promoted_Pawn,
  North_Guard, North_Onside_Submarine, North_Submarine,

 };

 enum class Scene_Status {
  Not_Added, Added_Visible, Added_Not_Visible
 };

 enum class Direction_Status {
  Off_Board, Panel_NW, Panel_N, Panel_NE,
   Panel_E, Panel_SE, Panel_S, Panel_SW,
  Panel_W, Panel_Center, Panel_Intersection, Captured,

//  Panel_2NW, Panel_2N, Panel_2NE,
//     Panel_2E, Panel_2SE, Panel_2S, Panel_2SW,
//    Panel_2W, Panel_Center_Doubled_Base, Panel_Center_Doubled_Top,
    Choose_Stone_Dialog
 };

 static Direction_Status direction_status_from_string(QString str)
 {
  static QMap<QString, Direction_Status> static_map {{
    {"Center", Direction_Status::Panel_Center},

    {"NW", Direction_Status::Panel_NW},
    {"N", Direction_Status::Panel_N},
    {"NE", Direction_Status::Panel_NE},
    {"E", Direction_Status::Panel_E},
    {"SE", Direction_Status::Panel_SE},
    {"S", Direction_Status::Panel_S},
    {"SW", Direction_Status::Panel_SW},
    {"W", Direction_Status::Panel_W},
    {"C", Direction_Status::Panel_Center},

//    {"2NW", Direction_Status::Panel_2NW},
//    {"2N", Direction_Status::Panel_2N},
//    {"2NE", Direction_Status::Panel_2NE},
//    {"2E", Direction_Status::Panel_2E},
//    {"2SE", Direction_Status::Panel_2SE},
//    {"2S", Direction_Status::Panel_2S},
//    {"2SW", Direction_Status::Panel_2SW},
//    {"2W", Direction_Status::Panel_2W},
                                                     }};

  return static_map.value(str, Direction_Status::Off_Board);

 }

private:

 Team_Status team_status_;
 Direction_Status direction_status_;
 Scene_Status scene_status_;

 int group_index_;

 std::function<void(int x, int y, Stone_Panel_Display* _this,
   QGraphicsScene& scene, float scale_factor)> moved_to_intersection_callback_;

 std::function<void(int x, int y, Stone_Panel_Display* _this,
   QGraphicsScene& scene, float scale_factor)> moved_to_section_center_callback_;

 //?int global_index_;

 Game_Stone_Graphic* graphic_;

 QGraphicsEllipseItem* ellipse_item_;
 QGraphicsSvgItem* svg_;

 void check_init_graphic(QGraphicsScene& scene);

 void create_background_ellipse(QGraphicsScene& scene, float scale_factor,
   int center_x, int center_y);

 void position_ellipse_item(int center_x, int center_y, int radius);

 bool direction_e()
 {
  return (direction_status_ == Direction_Status::Panel_NE) || (direction_status_ == Direction_Status::Panel_SE);
 }

 bool direction_w()
 {
  return (direction_status_ == Direction_Status::Panel_NW) || (direction_status_ == Direction_Status::Panel_SW);
 }

 bool direction_n()
 {
  return (direction_status_ == Direction_Status::Panel_NW) || (direction_status_ == Direction_Status::Panel_NE);
 }

 bool direction_s()
 {
  return (direction_status_ == Direction_Status::Panel_SW) || (direction_status_ == Direction_Status::Panel_SE);
 }

// QGraphicsEllipseItem* ellipse_item_;
// QGraphicsPolygonItem* polygon_item_;
// QGraphicsPolygonItem* secondary_polygon_item_;
// QGraphicsTextItem* text_item_;
// QGraphicsTextItem* text_item1_;
// QGraphicsTextItem* text_item2_;
// QGraphicsTextItem* text_item3_;

// QGraphicsTextItem* stone_kind_text_item_;
// QGraphicsTextItem* stone_spread_text_item_;


// int x_gridline_;
// int y_gridline_;

 Game_Panel_Section* section_;
 //?Game_Panel_Intersection* intersection_;

 Game_Position* position_;

 QVector<int> extras_;

 QGig* item_group_;
 //QGraphicsItemGroup* item_group_;

 //QString description_;

 void reset_graphics_item_flags();

// int get_d12_value();
// int get_d14_value();

 void show_kind_indicators(QGraphicsScene& scene, float center_x, float center_y, float scale_factor);
 void reset_polygon(QGraphicsScene& scene, float center_x, float center_y, float scale_factor,
                    const QPen& qpen, const QBrush& qbr);
 void reset_text_items(QGraphicsScene& scene, float center_x, float center_y, float scale_factor, const QPen& qpen, const QBrush& qbr);

public:

 Stone_Panel_Display(Team_Status status,
   int group_index,
   std::function<void(int x, int y, Stone_Panel_Display* _this,
     QGraphicsScene& scene, float scale_factor)> moved_to_intersection_callback,
   std::function<void(int x, int y, Stone_Panel_Display* _this,
     QGraphicsScene& scene, float scale_factor)> moved_to_section_center_callback);

 ACCESSORS(Game_Position* ,position)
 ACCESSORS(Game_Panel_Section* ,section)
 ACCESSORS(Direction_Status ,direction_status)

 //? ACCESSORS(QString ,description)

 QString description();
 QString informal_label();

 //void check_init_graphic_initial();

 void remove_from_board();

 inline bool is_guard()
 {
  return team_status_ == (Team_Status::North_Guard)
    ||   team_status_ == (Team_Status::South_Guard)
    ||   team_status_ == (Team_Status::North_Onside_Submarine)
    ||   team_status_ == (Team_Status::South_Onside_Submarine)
    ||   team_status_ == (Team_Status::North_Submarine)
    ||   team_status_ == (Team_Status::South_Submarine);
 }

 bool is_south();
 bool is_north();


 inline void make_onside_submarine()
 {
  if( (team_status_ == (Team_Status::North_Guard))
    || (team_status_ == (Team_Status::North_Submarine)) )
  {
   team_status_ = Team_Status::North_Onside_Submarine;
  }
  else if( (team_status_ == (Team_Status::South_Guard))
     || (team_status_ == (Team_Status::South_Submarine)) )
  {
   team_status_ = Team_Status::South_Onside_Submarine;
  }
 }

 inline void make_submarine()
 {
  if( (team_status_ == (Team_Status::North_Guard))
    || (team_status_ == (Team_Status::North_Onside_Submarine)) )
  {
   team_status_ = Team_Status::North_Submarine;
  }
  else if( (team_status_ == (Team_Status::South_Guard))
     || (team_status_ == (Team_Status::South_Onside_Submarine)) )
  {
   team_status_ = Team_Status::South_Submarine;
  }
 }



 inline bool is_submarine()
 {
  return team_status_ == (Team_Status::North_Submarine)
    ||   team_status_ == (Team_Status::South_Submarine);
 }

 void move(Game_Panel_Section* section,
   Direction_Status direction_status);

 QString get_label(int& font_size, int& x_offset, int& y_offset);
 QString get_group_stone_label();

 QString get_d4_label();

 QString s_or_n();

 void set_current_value_from_string(QString str);

 QGraphicsItem* get_graphics_item();

 void to_doubled_top();
 void to_doubled_base();

 bool is_code_stone();

 int spread();

 static void construct_plus(QPolygonF& poly, float center_x, float center_y,
   float scale_factor, float offset, float width);

 static void construct_deco_plus(QPolygonF& poly, float center_x, float center_y,
   float scale_factor, float offset, float width, float deco_offset);

 static void construct_triangle_down(QPolygonF& poly, float center_x, float center_y,
   float scale_factor, float width, float height, float y_offset);

 static void construct_triangle_up(QPolygonF& poly, float center_x, float center_y,
   float scale_factor, float width, float height, float y_offset);

 void draw_to_scene(QGraphicsScene& scene, float scale_factor);

 void offset_by_direction_status(int& x, int& y, float scale_factor);
 void init_qpen_and_qbrush(QPen& qpen, QBrush& qbr);

 static void init_qpen_and_qbrush_doubled_top(QPen& qpen, QBrush& qbr);

 void resize_extras(int size);
 void set_extra(int value);


 void show_kind_indicators_c6(QGraphicsScene& scene, float center_x, float center_y, float scale_factor);

 void show_kind_indicators_d8d(QGraphicsScene& scene, float center_x, float center_y, float scale_factor);

 static void construct_octagon(QPolygonF& poly, float center_x, float center_y,
   float scale_factor, float x_offset, float y_offset, float width);

 static QGraphicsEllipseItem* draw_circle_at_center(QGraphicsScene& scene, float center_x, float center_y, float radius,
   const QPen& qpen, const QBrush& qbr, QGraphicsPolygonItem* parent = nullptr);

 static QGraphicsPolygonItem* draw_square_at_center(QGraphicsScene& scene, float center_x, float center_y, float radius,
   const QPen& qpen, const QBrush& qbr);
 static void draw_diamond_at_center(QGraphicsScene& scene, float center_x, float center_y, float radius,
   QPen& qpen, QBrush& qbr);


 static QGraphicsEllipseItem* draw_circle_at_corner(QGraphicsScene& scene, float center_x, float center_y, float radius,
   const QPen& qpen, QBrush& qbr, QGraphicsPolygonItem* parent = nullptr)
 {
  return draw_circle_at_center(scene, center_x + radius/2, center_y + radius/2, radius, qpen, qbr, parent);
 }

 static void draw_square_at_corner(QGraphicsScene& scene, float center_x, float center_y, float radius,
   QPen& qpen, QBrush& qbr)
 {
  draw_square_at_center(scene, center_x + radius/2, center_y + radius/2, radius, qpen, qbr);
 }

 static void draw_diamond_at_corner(QGraphicsScene& scene, float center_x, float center_y, float radius,
   QPen& qpen, QBrush& qbr)
 {
  draw_diamond_at_center(scene, center_x + radius/2, center_y + radius/2, radius, qpen, qbr);
 }

 void move_to_section(Game_Panel_Section* section,
   Stone_Panel_Display::Direction_Status ds);

 void move_to_intersection(Game_Panel_Gridline_Intersection* gpi);

 void check_add_to_scene(QGraphicsScene& scene);

};


#endif
