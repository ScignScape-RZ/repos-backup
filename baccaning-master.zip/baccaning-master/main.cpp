
//Patient     age gender
//Where does mass come from
//History of  cancer


//screening services


#include <QApplication>
#include <QGraphicsView>

#include <QList>
#include <QDebug>

#include <QMessageBox>

#include <QMenu>

#include <QGraphicsItem>

#include "logic/game-player.h"
#include "logic/game-panel-board.h"
#include "logic/game-panel-section.h"

#include "logic/baccaning-game.h"
#include "logic/baccaning-game-capture.h"


//#include "logic/stone-panel-display.h"
//#include "logic/game-panel-section.h"
//

#include "paraviews/select-stone-dialog.h"
#include "paraviews/players-dialog.h"

#include "game-utils.h"



int main(int argc, char **argv)
{

 QApplication qapp(argc, argv);

 QGraphicsScene scene;

 //
 float scale_factor = 2;
 //float scale_factor = 1;

 Select_Stone_Dialog* dlg = new Select_Stone_Dialog;

 Baccaning_Game* bgame = new Baccaning_Game(dlg);

 Game_Utils utils;

 Game_Panel_Board gpb(bgame, utils);

 bgame->set_board(&gpb);

 //? gpb.trace_stone("SQ");

 //?gpb.set_stone_at_intersection(0, 1, "NK");

//? gpb.set_stone_at_position(6, 3, "SP1", Stone_Panel_Display::Direction_Status::Panel_Center);

 //gpb.set_stone_at_intersection(8, 4, "SP1");

 gpb.draw_to_scene(scene, scale_factor);

 //?

 QGraphicsView view(&scene);

 view.resize(1000, 600);

 view.setContextMenuPolicy(Qt::CustomContextMenu);

 view.show();

 Players_Dialog* players_dlg = new Players_Dialog();

 Game_Player* south_game_player = new Game_Player();
 Game_Player* north_game_player = new Game_Player();

 //Game_Player* current_game_player = south_game_player;


 bgame->set_north_player(north_game_player);
 bgame->set_south_player(south_game_player);
 bgame->set_current_game_player(south_game_player);


 view.connect(dlg, &Select_Stone_Dialog::button_selected, [&gpb](QString key)
  {
   gpb.register_stone_to_add(key);
  });

 view.connect(&view, &QGraphicsView::customContextMenuRequested,
   [&scene, scale_factor, &view, &gpb, dlg, players_dlg, bgame ](const QPoint& p)
 {
  QMenu menu;

  QList<QGraphicsItem*> items = view.items(p);

  void* pV = nullptr;
  for(QGraphicsItem* item : items)
  {
   if(pV = item->data(0).value<void*>())
   {
    break;
   }
  }



  //void* v1 = item->data(1).value<void*>();

  //if(key) Stone_Panel_Display* spd = item->data(0);

  if(pV)
  {
  }
  else if(Stone_Panel_Display* spd = gpb.selected_stone_to_add())
  {
   QString desc = gpb.stone_description(spd);

   QPointF qpf = view.mapToScene(p);
   QPoint logical_point = qpf.toPoint() / scale_factor;

   Stone_Panel_Display::Direction_Status ds;
   Game_Panel_Section* section;
   Game_Panel_Gridline_Intersection* intersection;
   QString posd = gpb.get_position_description(logical_point, section, intersection, ds);

   QAction* place_action = menu.addAction(QString("Place Stone: %1 at %2").arg(desc).arg(posd));
   QAction* clear_action = menu.addAction(QString("Clear Stone: %1").arg(desc));
//   if(intersection)
//   {

//   }
//   else
//   {
//    QAction* select_position_action = menu.addAction(QString("Select Position..."));

//    view.connect(select_position_action, &QAction::triggered, [&scene, scale_factor,
//      &view, &gpb, spd, dlg, &p, section, ds, &logical_point]
//    {
//     QMenu menu;

//     menu.addAction("Center");
//     menu.addAction("NW");
//     menu.addAction("2NW");
//     menu.addAction("N");
//     menu.addAction("2N");
//     menu.addAction("NE");
//     menu.addAction("2NE");
//     menu.addAction("E");
//     menu.addAction("2E");
//     menu.addAction("SE");
//     menu.addAction("2SE");
//     menu.addAction("S");
//     menu.addAction("S2");
//     menu.addAction("SW");
//     menu.addAction("2SW");
//     menu.addAction("W");
//     menu.addAction("2W");

//     view.connect(&menu, &QMenu::triggered, [ds, scale_factor, dlg, &scene, &gpb, &spd, logical_point, section](QAction* action)
//     {
//      Stone_Panel_Display::Direction_Status revised_ds = Stone_Panel_Display::direction_status_from_string(action->text());
//      gpb.place_current_selected_stone(section, revised_ds);
//      gpb.draw_to_scene(scene, scale_factor);
//      dlg->hide();
//     });
//    });
//    menu.exec(view.mapToGlobal(p));
//   }

   view.connect(place_action, &QAction::triggered, [&scene, scale_factor,
     &view, &gpb, dlg, players_dlg, &p, section, intersection, ds, bgame ]
   {
    //QPointF qpf = QPointF(p);
    //QPointF qpf = view.mapToScene(p);
    if(intersection)
    {
     Stone_Panel_Display* spd = gpb.selected_stone_to_add();
     Baccaning_Game_Capture* cap = bgame->check_move_or_capture(spd, intersection);
     if(cap)
     {
      // // i.e., a real capture
      if(cap->captured_stone())
      {
       int ret = QMessageBox::information(nullptr, "Impossible Capture",
         QString("Cannot capture during an initial placement"),
         QMessageBox::Ok);
       gpb.clear_current_selected_stone();
       return;
      }
      else
      {
       gpb.place_current_selected_stone(intersection, ds);
      }
     }
    }
    else if(section)
    {
     Stone_Panel_Display* spd = gpb.selected_stone_to_add();
     Baccaning_Game_Capture* cap = bgame->check_move_or_capture(spd, section);
     if(cap)
     {
      int ret = QMessageBox::information(nullptr, "Impossible Capture",
        QString("Cannot capture during an initial placement"),
        QMessageBox::Ok);
      gpb.clear_current_selected_stone();
      return;
     }
    }

    gpb.draw_to_scene(scene, scale_factor);
    gpb.switch_players();
    //dlg->switch_players();
    dlg->hide();
    //view.update();
   });
   view.connect(clear_action, &QAction::triggered, [&gpb, dlg]
   {
    gpb.clear_current_selected_stone();
   });

  }
  else
  {
   QAction* show_dialog_action = menu.addAction(
     "Show Dialog", [dlg]
   {
    dlg->reset();
    dlg->show();
   });

   QAction* show_players_action = menu.addAction(
     "Show Players", [players_dlg]
   {
    //dlg->reset();
    players_dlg->show();
   });

   QAction* switch_current_player_action = menu.addAction(
     QString("Current Player: %1 (switch)").
     arg(bgame->current_player_is_south()?
       "South" : "North"),
     [players_dlg]
   {

    //dlg->reset();
    //players_dlg->show();
   });

   QAction* switch_referree_mode_action = menu.addAction(
     QString("Referree Mode: %1 (switch)").
     arg(bgame->flags.referee_mode? "On" : "Off"),
     [players_dlg]
   {
    //dlg->reset();
    //players_dlg->show();
   });

  }
  menu.exec(view.mapToGlobal(p));
 });

 dlg->show();



 return qapp.exec();


#ifdef HIDE
 Select_Stone_Dialog* dlg = new Select_Stone_Dialog(&view);
 view.connect(&view, &QGraphicsView::customContextMenuRequested, [&scene, scale_factor, &view, &gpb, dlg](const QPoint& p)
 {
  QMenu menu;

  QList<QGraphicsItem*> items = view.items(p);

  void* pV = nullptr;
  for(QGraphicsItem* item : items)
  {
   if(pV = item->data(0).value<void*>())
   {
    break;
   }
  }



  //void* v1 = item->data(1).value<void*>();

  //if(key) Stone_Panel_Display* spd = item->data(0);

  if(pV)
  {
   QPointF qpf = view.mapToScene(p);
   QPoint logical_point = qpf.toPoint() / scale_factor;

   Stone_Panel_Display* spd = static_cast<Stone_Panel_Display*>(pV);
   QString desc = gpb.stone_description(spd);

   Stone_Panel_Display::Direction_Status ds;
   Game_Panel_Section* section;
   QString posd = gpb.get_position_description(logical_point, section, ds);

   QAction* move_action = menu.addAction(QString("Move Here: %1 to %2").arg(desc).arg(posd));
   QAction* move_back_action = menu.addAction(QString("Move Back: %1").arg(desc));
   QAction* select_action = menu.addAction(QString("Select: %1").arg(desc));
   QAction* select_position_action = menu.addAction(QString("Select Position..."));

   view.connect(select_position_action, &QAction::triggered, [&scene, scale_factor,
     &view, &gpb, spd, dlg, &p, section, ds, &logical_point]
   {
    QMenu menu;

    menu.addAction("Center");
    menu.addAction("NW");
    menu.addAction("2NW");
    menu.addAction("N");
    menu.addAction("2N");
    menu.addAction("NE");
    menu.addAction("2NE");
    menu.addAction("E");
    menu.addAction("2E");
    menu.addAction("SE");
    menu.addAction("2SE");
    menu.addAction("S");
    menu.addAction("S2");
    menu.addAction("SW");
    menu.addAction("2SW");
    menu.addAction("W");
    menu.addAction("2W");

    view.connect(&menu, &QMenu::triggered, [ds, scale_factor, dlg, &scene, &gpb, &spd, logical_point, section](QAction* action)
    {
     Stone_Panel_Display::Direction_Status revised_ds = Stone_Panel_Display::direction_status_from_string(action->text());
     gpb.confirm_move_stone(spd, section, revised_ds);
     gpb.draw_to_scene(scene, scale_factor);
     dlg->hide();
    });

    menu.exec(view.mapToGlobal(p));

    //view.update();
   });



   view.connect(move_action, &QAction::triggered, [&scene, scale_factor,
     &view, &gpb, spd, dlg, &p, section, ds, &logical_point]
   {
    //QPointF qpf = QPointF(p);
    //QPointF qpf = view.mapToScene(p);
    gpb.confirm_move_stone(spd, section, ds);
    gpb.draw_to_scene(scene, scale_factor);
    dlg->hide();
    //view.update();
   });

   view.connect(select_action, &QAction::triggered, [&gpb, spd]
   {
    gpb.set_selected_stone_to_add(spd);
   });

   view.connect(move_back_action, &QAction::triggered, [&gpb, spd, &scene, scale_factor]
   {
    //?gpb.replace_stone_to_its_position(spd);
    gpb.draw_to_scene(scene, scale_factor);
   });

  }
  else if(Stone_Panel_Display* spd = gpb.selected_stone_to_add())
  {
   QString desc = gpb.stone_description(spd);

   QPointF qpf = view.mapToScene(p);
   QPoint logical_point = qpf.toPoint() / scale_factor;

   Stone_Panel_Display::Direction_Status ds;
   Game_Panel_Section* section;
   QString posd = gpb.get_position_description(logical_point, section, ds);

   QAction* place_action = menu.addAction(QString("Place Stone: %1 at %2").arg(desc).arg(posd));
   QAction* clear_action = menu.addAction(QString("Clear Stone: %1").arg(desc));

   QAction* select_position_action = menu.addAction(QString("Select Position..."));

   view.connect(select_position_action, &QAction::triggered, [&scene, scale_factor,
     &view, &gpb, spd, dlg, &p, section, ds, &logical_point]
   {
    QMenu menu;

    menu.addAction("Center");
    menu.addAction("NW");
    menu.addAction("2NW");
    menu.addAction("N");
    menu.addAction("2N");
    menu.addAction("NE");
    menu.addAction("2NE");
    menu.addAction("E");
    menu.addAction("2E");
    menu.addAction("SE");
    menu.addAction("2SE");
    menu.addAction("S");
    menu.addAction("S2");
    menu.addAction("SW");
    menu.addAction("2SW");
    menu.addAction("W");
    menu.addAction("2W");

    view.connect(&menu, &QMenu::triggered, [ds, scale_factor, dlg, &scene, &gpb, &spd, logical_point, section](QAction* action)
    {
     Stone_Panel_Display::Direction_Status revised_ds = Stone_Panel_Display::direction_status_from_string(action->text());
     gpb.place_current_selected_stone(section, revised_ds);
     gpb.draw_to_scene(scene, scale_factor);
     dlg->hide();
    });

    menu.exec(view.mapToGlobal(p));


   });

   view.connect(place_action, &QAction::triggered, [&scene, scale_factor, &view, &gpb, dlg, &p, section, ds]
   {
    //QPointF qpf = QPointF(p);
    //QPointF qpf = view.mapToScene(p);
    gpb.place_current_selected_stone(section, ds);
    gpb.draw_to_scene(scene, scale_factor);
    dlg->hide();
    //view.update();
   });
   view.connect(clear_action, &QAction::triggered, [&gpb, dlg]
   {
    gpb.clear_current_selected_stone();
   });

  }
  else
  {
   QAction* south_action = menu.addAction("Off-Board South");
   QAction* north_action = menu.addAction("Off-Board North");
   QAction* info_action = menu.addAction("Info");
   view.connect(south_action, &QAction::triggered, [dlg]
   {
    dlg->set_user_as_south();
    dlg->show();
   });
   view.connect(north_action, &QAction::triggered, [dlg]
   {
    dlg->set_user_as_north();
    dlg->show();
   });
   view.connect(info_action, &QAction::triggered, [&gpb, &view, &scene, &scale_factor]
   {
    gpb.set_stone_at_position(7, 5, "N-D5-0", 5,
      Stone_Panel_Display::Direction_Status::Panel_Center);

    gpb.draw_to_scene(scene, scale_factor);

    //view.update();
   });
  }
  menu.exec(view.mapToGlobal(p));
 });


 view.connect(dlg, &Select_Stone_Dialog::stone_selected, [&view, &gpb]
   (QString description, Game_Player* player)
 {
  gpb.register_stone_to_add(description, player);
  //QMessageBox::information(&view, player->name(), description);
 });

 dlg->set_south_player(gpb.south_player());
 dlg->set_north_player(gpb.north_player());

 dlg->hide();
 view.show();

 return qapp.exec();

#endif
}

#ifdef HIDE

gpb.set_stone_at_position(7, 7, "N-C8-0", 2,
  Stone_Panel_Display::Direction_Status::Panel_NE);

gpb.set_stone_at_position(8, 7, "N-D2-0", 0,
  Stone_Panel_Display::Direction_Status::Panel_NW);

gpb.set_stone_at_position(10, 4, "N-D2-4", 0,
  Stone_Panel_Display::Direction_Status::Panel_NE);


gpb.set_stone_at_position(8, 7, "N-D3-0", 3,
  Stone_Panel_Display::Direction_Status::Panel_NE);

gpb.set_stone_at_position(8, 7, "N-D5-0", 2,
  Stone_Panel_Display::Direction_Status::Panel_SE);

gpb.set_stone_at_position(8, 7, "N-D7-0", 2,
  Stone_Panel_Display::Direction_Status::Panel_SW);



gpb.set_stone_at_position(8, 13, "S-D5-1", 2,
  Stone_Panel_Display::Direction_Status::Panel_Center);

gpb.set_stone_at_position(9, 13, "S-D7-1", 2,
  Stone_Panel_Display::Direction_Status::Panel_Center);

gpb.set_stone_at_position(8, 14, "S-D5-0", 2,
  Stone_Panel_Display::Direction_Status::Panel_SW);

gpb.set_stone_at_position(8, 14, "S-D7-0", 2,
  Stone_Panel_Display::Direction_Status::Panel_SE);


//   gpb.set_stone_at_position(8, 8, "N-D7-1", 2,
//     Stone_Panel_Display::Direction_Status::Panel_Center);

gpb.set_stone_at_position(8, 8, "N-D5-1", 2,
  Stone_Panel_Display::Direction_Status::Panel_Center);



gpb.set_stone_at_position(9, 7, "N-D12F-0", 2,
  Stone_Panel_Display::Direction_Status::Panel_Center);


gpb.set_stone_at_position(10, 7, "N-D14F-0", 2,
  Stone_Panel_Display::Direction_Status::Panel_Center);


gpb.set_stone_at_position(11, 7, "N-D12G-0", 2,
  Stone_Panel_Display::Direction_Status::Panel_Center);


gpb.set_stone_at_position(12, 7, "N-D14G-0", 2,
  Stone_Panel_Display::Direction_Status::Panel_Center);


gpb.set_stone_at_position(10, 8, "N-D8D-0", 2,
  Stone_Panel_Display::Direction_Status::Panel_NE);

gpb.set_stone_at_position(10, 8, "N-D8R-0", 2,
  Stone_Panel_Display::Direction_Status::Panel_NW);

gpb.set_stone_at_position(10, 8, "N-D8D-1", 2,
  Stone_Panel_Display::Direction_Status::Panel_SE);

gpb.set_stone_at_position(10, 8, "N-D8R-1", 2,
  Stone_Panel_Display::Direction_Status::Panel_SW);



gpb.set_stone_at_position(11, 9, "N-C20L-0", 2,
  Stone_Panel_Display::Direction_Status::Panel_Center);

gpb.set_stone_at_position(12, 9, "N-C20R-0", 2,
  Stone_Panel_Display::Direction_Status::Panel_Center);


gpb.set_stone_at_position(12, 7, "N-C60-0", 2,
  Stone_Panel_Display::Direction_Status::Panel_Center);

gpb.set_stone_at_position(13, 7, "N-D80-0", 17,
  Stone_Panel_Display::Direction_Status::Panel_Center);


//  gpb.set_stone_at_position(10, 10, "N-D14G-1", 5,
//    Stone_Panel_Display::Direction_Status::Panel_Center);

//  gpb.set_stone_at_position(10, 5, "N-D14F-1", 5,
//    Stone_Panel_Display::Direction_Status::Panel_Center);



//  gpb.set_stone_at_position(5, 5, "N-D12G-2", 5,
//    Stone_Panel_Display::Direction_Status::Panel_Center);

//  gpb.set_stone_at_position(5, 10, "N-D12F-2", 5,
//    Stone_Panel_Display::Direction_Status::Panel_Center);


//  gpb.set_stone_at_position(12, 10, "N-D8R-1", 6,
//    Stone_Panel_Display::Direction_Status::Panel_SE);

//  gpb.set_stone_at_position(12, 10, "N-D8R-2", 5,
//    Stone_Panel_Display::Direction_Status::Panel_SW);


// gpb.set_stone_at_position(8, 7, "N-G1-5-1", 3,
//   Stone_Panel_Display::Direction_Status::Panel_NW);

// gpb.set_stone_at_position(7, 8, "N-G1-5-2", 3,
//   Stone_Panel_Display::Direction_Status::Panel_NE);

// gpb.set_stone_at_position(6, 6, "N-G1-5-3", 3,
//   Stone_Panel_Display::Direction_Status::Panel_SE);

// gpb.set_stone_at_position(6, 6, "N-G2-5-4", 3,
//   Stone_Panel_Display::Direction_Status::Panel_SW);

gpb.set_stone_at_position(5, 5, "N-D4-0", 3,
 Stone_Panel_Display::Direction_Status::Panel_Center);


gpb.set_stone_at_position(5, 6, "N-G1-5-1", 3,
  Stone_Panel_Display::Direction_Status::Panel_NW);

gpb.set_stone_at_position(5, 6, "N-G1-5-2", 3,
  Stone_Panel_Display::Direction_Status::Panel_NE);

gpb.set_stone_at_position(5, 6, "N-G1-5-3", 3,
  Stone_Panel_Display::Direction_Status::Panel_SE);


gpb.set_stone_at_position(5, 6, "N-D12F-5", 11,
 Stone_Panel_Display::Direction_Status::Panel_Center);




gpb.set_stone_at_position(5, 7, "N-D12G-5", 11,
 Stone_Panel_Display::Direction_Status::Panel_Center);




gpb.set_stone_at_position(5, 8, "N-G1-8-1", 3,
 Stone_Panel_Display::Direction_Status::Panel_NW);

gpb.set_stone_at_position(5, 8, "N-G1-8-2", 3,
 Stone_Panel_Display::Direction_Status::Panel_NE);

gpb.set_stone_at_position(5, 8, "N-G1-8-3", 3,
 Stone_Panel_Display::Direction_Status::Panel_SE);




gpb.set_stone_at_position(5, 8, "N-D14F-5", 11,
 Stone_Panel_Display::Direction_Status::Panel_Center);

gpb.set_stone_at_position(5, 9, "N-D14G-5", 11,
 Stone_Panel_Display::Direction_Status::Panel_Center);



gpb.set_stone_at_position(5, 10, "N-G1-7-2", 3,
 Stone_Panel_Display::Direction_Status::Panel_NE);

gpb.set_stone_at_position(5, 10, "N-G1-7-3", 3,
 Stone_Panel_Display::Direction_Status::Panel_SE);

gpb.set_stone_at_position(5, 10, "N-C20R-5", 11,
 Stone_Panel_Display::Direction_Status::Panel_Center);



gpb.set_stone_at_position(5, 11, "N-G1-9-2", 3,
 Stone_Panel_Display::Direction_Status::Panel_NE);

gpb.set_stone_at_position(5, 11, "N-G1-9-3", 3,
 Stone_Panel_Display::Direction_Status::Panel_SE);

gpb.set_stone_at_position(5, 11, "N-D3-2", 1,
 Stone_Panel_Display::Direction_Status::Panel_Center);


gpb.set_stone_at_position(5, 12, "N-G1-9-4", 3,
 Stone_Panel_Display::Direction_Status::Panel_NE);

gpb.set_stone_at_position(5, 12, "N-G1-9-5", 3,
 Stone_Panel_Display::Direction_Status::Panel_SE);

gpb.set_stone_at_position(5, 12, "N-D7-1", 2,
 Stone_Panel_Display::Direction_Status::Panel_Center);


gpb.set_stone_at_position(5, 13, "N-G1-9-6", 3,
 Stone_Panel_Display::Direction_Status::Panel_NE);

gpb.set_stone_at_position(5, 13, "N-G1-9-7", 3,
 Stone_Panel_Display::Direction_Status::Panel_SE);

gpb.set_stone_at_position(5, 13, "N-C20L-5", 2,
 Stone_Panel_Display::Direction_Status::Panel_Center);


gpb.set_stone_at_position(5, 14, "N-G1-9-8", 3,
 Stone_Panel_Display::Direction_Status::Panel_NE);

gpb.set_stone_at_position(5, 14, "N-G1-19-7", 3,
 Stone_Panel_Display::Direction_Status::Panel_SE);

gpb.set_stone_at_position(5, 14, "N-C20R-5", 2,
 Stone_Panel_Display::Direction_Status::Panel_Center);






gpb.set_stone_at_position(15, 15, "S-D4-0", 3,
 Stone_Panel_Display::Direction_Status::Panel_Center);




//  gpb.set_stone_at_position(7, 8, "N-C60-0", 5,
//    Stone_Panel_Display::Direction_Status::Panel_Center);


//  gpb.set_stone_at_position(8, 7, "N-C20L-0", 5,
//    Stone_Panel_Display::Direction_Status::Panel_NE);

//  gpb.set_stone_at_position(8, 7, "N-D8D-0", 4,
//    Stone_Panel_Display::Direction_Status::Panel_SW);

//  gpb.set_stone_at_position(8, 7, "N-D8R-0", 2,
//    Stone_Panel_Display::Direction_Status::Panel_SE);



//  gpb.set_stone_at_position(7, 7, "N-C20R-2", 5,
//    Stone_Panel_Display::Direction_Status::Panel_Center);

//  gpb.set_stone_at_position(7, 6, "N-C60-1", 5,
//    Stone_Panel_Display::Direction_Status::Panel_Center);


//  gpb.set_stone_at_position(4, 11, "N-D8D-0", 0,
//    Stone_Panel_Display::Direction_Status::Panel_SE);

//  gpb.set_stone_at_position(5, 12, "N-D8D-1", 1,
//    Stone_Panel_Display::Direction_Status::Panel_SE);

//  gpb.set_stone_at_position(6, 12, "N-D8D-2", 2,
//    Stone_Panel_Display::Direction_Status::Panel_SE);

//  gpb.set_stone_at_position(7, 12, "N-D8D-3", 3,
//    Stone_Panel_Display::Direction_Status::Panel_SE);

//  gpb.set_stone_at_position(8, 12, "N-D8D-4", 4,
//    Stone_Panel_Display::Direction_Status::Panel_SE);


//  gpb.set_stone_at_position(9, 12, "N-D8D-5", 5,
//    Stone_Panel_Display::Direction_Status::Panel_SE);

//  gpb.set_stone_at_position(10, 12, "N-D8D-6", 6,
//    Stone_Panel_Display::Direction_Status::Panel_SE);

//  gpb.set_stone_at_position(11, 12, "N-D8D-7", 7,
//    Stone_Panel_Display::Direction_Status::Panel_SE);


#endif





// kobane
//Latitude: 36° 53' 27.42" N    36 53 27.42N
//Longitude: 38° 21' 12.49" E   38 21 12.49E

//safed
// 32°57'57"N                   32 57 57N
// 35°30'19"E                   35 30 19E

// Distance:	507.8 km (to 4 SF*)
// Initial bearing:	211° 34′ 32″
// Final bearing:	209° 56′ 37″
// Midpoint:	34° 56′ 12″ N, 036° 53′ 43″ E



//derby line
// 45°0'8.02"N. Longitude DMS: 72°6'4.2"W
// 45 0 8.02N  72 6 4.2W

//?   42° 39' 9.2880'  42 39 9.2880
//    73 45 22.4388

// 40°59'12.34"N and a longitude of 75°11'40.65"W
//  40 59 12.34
//  75 11 40.65

// close... Point 2:
//41.05 0 9.0N
// ,
//74.48 45 22.4388W


// good ...

//Point 1:
//36 53 27.42N
// ,
//38 21 12.49E
//Point 2:
//32 58 25N
// ,
//35 29 25E
//Distance:	507.7 km (to 4 SF*)
//Initial bearing:	211° 45′ 40″
//Final bearing:	210° 07′ 14″
//Midpoint:	34° 56′ 26″ N, 036° 53′ 16″ E
//... hide map


// NA
//Point 1:
//45 0 8.02N
// ,
//72 6 4.2W
//Point 2:
//40 63 89N
// ,
//75 16 72.9W
//Distance:	507.6 km (to 4 SF*)
//Initial bearing:	211° 45′ 40″
//Final bearing:	209° 35′ 07″
//Midpoint:	43° 02′ 58″ N, 073° 44′ 42″ W



