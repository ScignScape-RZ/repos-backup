
#include "player-frame.h"

//#include "clg-db-antemodel.h";

#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QButtonGroup>

#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>
#include <QDebug>

#include <QPlainTextEdit>
#include <QTextStream>

#include <QTableWidget>

#include <QMessageBox>

//#include <QNetworkAccessManager>
//#include <QNetworkRequest>
//#include <QNetworkReply>
#include <QUrlQuery>

#include <QHeaderView>
#include <QGraphicsTextItem>
#include <QListWidget>


Player_Frame::Player_Frame(QWidget* parent) : QFrame(parent)
{
 cLE_full_name_ = new QLineEdit(this);
 cLE_given_name_ = new QLineEdit(this);
 cLE_family_name_ = new QLineEdit(this);
 cLE_middle_name_ = new QLineEdit(this);

 cLBL_full_name_ = new QLabel("Full Name: ", this);
 cLBL_given_name_ = new QLabel("Given Name: ", this);
 cLBL_family_name_ = new QLabel("Family Name: ", this);
 cLBL_middle_name_ = new QLabel("Midd;e Name: ", this);

 main_form_layout_ = new QFormLayout;
 main_form_layout_->addRow(cLBL_full_name_, cLE_full_name_);
 main_form_layout_->addRow(cLBL_given_name_, cLE_given_name_);
 main_form_layout_->addRow(cLBL_family_name_, cLE_family_name_);
 main_form_layout_->addRow(cLBL_middle_name_, cLE_middle_name_);

 main_layout_ = new QVBoxLayout;

 main_layout_->addItem(main_form_layout_);

 setLayout(main_layout_);

}


