
#ifndef PLAYER_FRAME__H
#define PLAYER_FRAME__H


#include <QString>
#include <QMainWindow>

#include <QTextEdit>
//?#include <QWebView>

//#include <QWebEngineView>
#include <QLabel>
#include <QPushButton>

#include <QDialog>

#include <QComboBox>

#include "accessors.h"

//#include "flags.h"

class QPushButton;
class QTextEdit;
class QPlainTextEdit;
class QLineEdit;
class QTabWidget;
class QDialogButtonBox;
class QVBoxLayout;
class QHBoxLayout;
class QCheckBox;
class QFormLayout;
class QSplitter;
class QGridLayout;
class QListWidget;
class QTableWidget;
class QScrollArea;
class QGroupBox;
class QTableWidgetItem;


#include <QGraphicsScene>
#include <QGraphicsView>
#include <QFrame>
#include <QStackedWidget>
#include <QComboBox>
#include <QFormLayout>

//RZNS_(QWN)
//namespace RZ{ namespace CTQ{


class Game_Player;


class Player_Frame : public QFrame
{
 Q_OBJECT

 QLineEdit* cLE_full_name_;
 QLineEdit* cLE_given_name_;
 QLineEdit* cLE_family_name_;
 QLineEdit* cLE_middle_name_;

 QLabel* cLBL_full_name_;
 QLabel* cLBL_given_name_;
 QLabel* cLBL_family_name_;
 QLabel* cLBL_middle_name_;

 QFormLayout* main_form_layout_;

 QVBoxLayout* main_layout_;

public:

 Player_Frame(QWidget* parent = nullptr);


};

//} } //_RZNS(CTQ)


#endif
