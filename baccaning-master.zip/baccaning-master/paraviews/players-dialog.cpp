
#include "players-dialog.h"

#include "player-frame.h"


#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QButtonGroup>

#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>
#include <QDebug>

#include <QPlainTextEdit>
#include <QTextStream>

#include <QTableWidget>

#include <QMessageBox>

//#include <QNetworkAccessManager>
//#include <QNetworkRequest>
//#include <QNetworkReply>
#include <QUrlQuery>

#include <QHeaderView>
#include <QGraphicsTextItem>
#include <QListWidget>


Players_Dialog::Players_Dialog(QWidget* parent)
  : QDialog(parent)
{
 button_box_ = new QDialogButtonBox();

 button_ok_ = new QPushButton("OK", this);
 button_cancel_ = new QPushButton("Cancel", this);

 button_box_ = new QDialogButtonBox(this);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 // // button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);

 main_layout_ = new QVBoxLayout;

 south_player_frame_ = new Player_Frame(this);
 north_player_frame_ = new Player_Frame(this);

 cTW_main_ = new QTabWidget(this);

 cTW_main_->addTab(south_player_frame_, "South");
 cTW_main_->addTab(north_player_frame_, "North");

 main_layout_->addWidget(cTW_main_);
 main_layout_->addWidget(button_box_);

 setLayout(main_layout_);

}

