
#ifndef PLAYERS_DIALOG__H
#define PLAYERS_DIALOG__H


#include <QString>
#include <QMainWindow>

#include <QTextEdit>
//?#include <QWebView>

//#include <QWebEngineView>
#include <QLabel>
#include <QPushButton>

#include <QDialog>

#include <QComboBox>

#include "accessors.h"

//#include "flags.h"

class QPushButton;
class QTextEdit;
class QPlainTextEdit;
class QLineEdit;
class QTabWidget;
class QDialogButtonBox;
class QVBoxLayout;
class QHBoxLayout;
class QCheckBox;
class QFormLayout;
class QSplitter;
class QGridLayout;
class QListWidget;
class QTableWidget;
class QScrollArea;
class QGroupBox;
class QTableWidgetItem;


#include <QGraphicsScene>
#include <QGraphicsView>
#include <QFrame>
#include <QStackedWidget>
#include <QComboBox>

//RZNS_(QWN)
//namespace RZ{ namespace CTQ{


class Game_Player;
class Player_Frame;
class Select_Stone_Dialog;


class Players_Dialog : public QDialog
{
 Q_OBJECT


 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;


 QVBoxLayout* main_layout_;

 Player_Frame* south_player_frame_;
 Player_Frame* north_player_frame_;

 QTabWidget* cTW_main_;



 //QPushButton* selected_button_;


public:

 Players_Dialog(QWidget* parent = nullptr);


};

//} } //_RZNS(CTQ)


#endif
