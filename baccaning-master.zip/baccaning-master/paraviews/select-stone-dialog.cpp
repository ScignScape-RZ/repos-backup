
#include "select-stone-dialog.h"

//#include "clg-db-antemodel.h";

#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QButtonGroup>

#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>
#include <QDebug>

#include <QPlainTextEdit>
#include <QTextStream>

#include <QTableWidget>

#include <QMessageBox>

//#include <QNetworkAccessManager>
//#include <QNetworkRequest>
//#include <QNetworkReply>
#include <QUrlQuery>

#include <QHeaderView>
#include <QGraphicsTextItem>
#include <QListWidget>




#include "game-panel-colors.h"

#define SVG_BASE_PATH "/extension/medusa/baccaning/Images/"


void Select_Stone_Dialog::add_row_stretch(QGridLayout* gl)
{
 int rows = gl->rowCount();
 int cols = gl->columnCount();
 QSpacerItem* qs = new QSpacerItem(1, 1, QSizePolicy::Minimum, QSizePolicy::Expanding);
 gl->addItem(qs, rows, 0, 1, cols);
}

void Select_Stone_Dialog::add_column_stretch(QGridLayout* gl)
{
 int rows = gl->rowCount();
 int cols = gl->columnCount();
 QSpacerItem* qs = new QSpacerItem(1, 1, QSizePolicy::Minimum, QSizePolicy::Expanding);
 gl->addItem(qs, 0, cols);
}


void Select_Stone_Dialog::init_stone_button(QButtonGroup* button_group,
  QPushButton* button, QString key, QString file)
{
 keys_[button] = key;
 button_group->addButton(button);
 button->setIcon(QIcon(file));
 button->setMaximumWidth(40);
 button->setCheckable(true);
}


void Select_Stone_Dialog::reset()
{
 selected_button_ = nullptr;
 button_ok_->setEnabled(false);
 north_dummy_->setChecked(true);
 south_dummy_->setChecked(true);

}

void Select_Stone_Dialog::make_dummy_button(QButtonGroup* button_group,
  QPushButton*& button)
{
 button = new QPushButton(this);
 button->setCheckable(true);
 button->setChecked(true);
 button->setVisible(false);
 button_group->addButton(button);
}

Select_Stone_Dialog::Select_Stone_Dialog() : selected_button_(nullptr)
{
 buttons_stacked_widget_ = new QStackedWidget(this);

 main_layout_ = new QVBoxLayout;

 south_frame_ = new QFrame(this);
 north_frame_ = new QFrame(this);

 south_layout_ = new QGridLayout;
 north_layout_ = new QGridLayout;

 south_king_ = new QPushButton(this);
 south_queen_ = new QPushButton(this);
 south_rook_ = new QPushButton(this);
 south_bishop_ = new QPushButton(this);
 south_knight_ = new QPushButton(this);
 south_pawn_ = new QPushButton(this);

 north_king_ = new QPushButton(this);
 north_queen_ = new QPushButton(this);
 north_rook_ = new QPushButton(this);
 north_bishop_ = new QPushButton(this);
 north_knight_ = new QPushButton(this);
 north_pawn_ = new QPushButton(this);

 // north_dummy_ = new QPushButton(this);
 // south_dummy_ = new QPushButton(this);


 south_buttons_ = new QButtonGroup(this);
 north_buttons_ = new QButtonGroup(this);

 make_dummy_button(south_buttons_, south_dummy_);
 make_dummy_button(north_buttons_, north_dummy_);

 // this -> connect (south_buttons_ &-> clicked: .[this])

 connect(south_buttons_, static_cast<void(QButtonGroup::*)(QAbstractButton *button)>
   (&QButtonGroup::buttonClicked), [this](QAbstractButton* button)
 {
  selected_button_ = qobject_cast<QPushButton*>(button);
  button_ok_->setEnabled(true);
 });

 connect(north_buttons_, static_cast<void(QButtonGroup::*)(QAbstractButton *button)>
   (&QButtonGroup::buttonClicked), [this](QAbstractButton* button)
 {
  selected_button_ = qobject_cast<QPushButton*>(button);
  button_ok_->setEnabled(true);
 });


 south_buttons_->addButton(south_dummy_);

 init_stone_button(south_buttons_, south_king_, "SK",  SVG_BASE_PATH "king_white.svg");
 init_stone_button(south_buttons_, south_queen_, "SQ", SVG_BASE_PATH "queen_white.svg");
 init_stone_button(south_buttons_, south_rook_, "SR", SVG_BASE_PATH "rook_white.svg");
 init_stone_button(south_buttons_, south_bishop_, "SB", SVG_BASE_PATH "bishop_white.svg");
 init_stone_button(south_buttons_, south_knight_, "SN", SVG_BASE_PATH "knight_white.svg");
 init_stone_button(south_buttons_, south_pawn_, "SP", SVG_BASE_PATH "pawn_white.svg");

 north_buttons_->addButton(north_dummy_);

 init_stone_button(north_buttons_, north_king_, "NK", SVG_BASE_PATH "king_black.svg");
 init_stone_button(north_buttons_, north_queen_, "NQ", SVG_BASE_PATH "queen_black.svg");
 init_stone_button(north_buttons_, north_rook_, "NR", SVG_BASE_PATH "rook_black.svg");
 init_stone_button(north_buttons_, north_bishop_, "NB", SVG_BASE_PATH "bishop_black.svg");
 init_stone_button(north_buttons_, north_knight_, "NN", SVG_BASE_PATH "knight_black.svg");
 init_stone_button(north_buttons_, north_pawn_, "NP", SVG_BASE_PATH "pawn_black.svg");



 south_layout_->addWidget(south_king_, 0, 1);
 south_layout_->addWidget(south_queen_, 0, 2);
 south_layout_->addWidget(south_rook_, 0, 3);
 south_layout_->addWidget(south_bishop_, 1, 1);
 south_layout_->addWidget(south_knight_, 1, 2);
 south_layout_->addWidget(south_pawn_, 1, 3);
 south_layout_->setSpacing(0);
 south_layout_->setMargin(0);
// add_column_stretch(south_layout_);
 south_frame_->setLayout(south_layout_);

 south_layout_->setColumnStretch(0, 1);
 south_layout_->setColumnStretch(1, 0);
 south_layout_->setColumnStretch(2, 0);
 south_layout_->setColumnStretch(3, 0);
 south_layout_->setColumnStretch(4, 1);
 //south_layout_->setColumnStretch(1, 1);

// QSpacerItem* qs = new QSpacerItem(1, 1, QSizePolicy::Minimum, QSizePolicy::Expanding);




 north_layout_->addWidget(north_king_, 0, 1);
 north_layout_->addWidget(north_queen_, 0, 2);
 north_layout_->addWidget(north_rook_, 0, 3);
 north_layout_->addWidget(north_bishop_, 1, 1);
 north_layout_->addWidget(north_knight_, 1, 2);
 north_layout_->addWidget(north_pawn_, 1, 3);
 north_layout_->setSpacing(0);
 north_layout_->setMargin(0);
 //add_column_stretch(north_layout_);

 north_layout_->setColumnStretch(0, 1);
 north_layout_->setColumnStretch(1, 0);
 north_layout_->setColumnStretch(2, 0);
 north_layout_->setColumnStretch(3, 0);
 north_layout_->setColumnStretch(4, 1);

 north_frame_->setLayout(north_layout_);


 buttons_stacked_widget_->addWidget(south_frame_);
 buttons_stacked_widget_->addWidget(north_frame_);

 buttons_stacked_widget_->setCurrentWidget(south_frame_);

 main_layout_->addWidget(buttons_stacked_widget_);


 //?button_box_ = new QDialogButtonBox(this);

 button_ok_ = new QPushButton("OK");
 //?button_proceed_ = new QPushButton("Proceed");
 button_cancel_ = new QPushButton("Cancel");

 connect(button_ok_, &QPushButton::clicked, [this]()
 {
  QString key = keys_[selected_button_];

  Q_EMIT(button_selected(key));
 });


 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

// button_proceed_->setDefault(false);
// button_proceed_->setAutoDefault(false);

 button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_ok_->setMaximumWidth(50);
 button_cancel_->setMaximumWidth(50);

// button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
//// button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
// button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);


////? connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
// connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
// connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));

 buttons_layout_ = new QHBoxLayout;

 player_ = new QComboBox(this);
 player_->addItem("South");//, QVariant(1));
 player_->addItem("North");//, QVariant(2));

 connect(player_, static_cast<void(QComboBox::*)(int)>(&QComboBox::activated),
         [=](int index)
 {
  buttons_stacked_widget_->setCurrentIndex(index);
 });

 buttons_layout_->addWidget(player_);
 buttons_layout_->addStretch();
 buttons_layout_->addWidget(button_ok_);
 buttons_layout_->addWidget(button_cancel_);

 main_layout_->addLayout(buttons_layout_);

 setLayout(main_layout_);

}

void Select_Stone_Dialog::switch_players()
{
 if(player_->currentIndex() == 0)
  set_player_north();
 else
  set_player_south();
}

void Select_Stone_Dialog::set_player_south()
{
 player_->setCurrentIndex(0);
 buttons_stacked_widget_->setCurrentIndex(0);
}

void Select_Stone_Dialog::set_player_north()
{
 player_->setCurrentIndex(1);
 buttons_stacked_widget_->setCurrentIndex(1);
}
