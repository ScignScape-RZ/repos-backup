

#include "game-panel-board.h"

#include "game-panel-section.h"

#include "stone-panel-display.h"

#include "game-panel-gridline-intersection.h"
#include "game-panel-vertical-gridline.h"
#include "game-panel-horizontal-gridline.h"

#include "game-panel-diagonal-gridline.h"

#include "logic/baccaning-game.h"
#include "logic/baccaning-game-capture.h"

#include <QMessageBox>
#include <QtGlobal>

#include <QGraphicsView>

#include <QGraphicsItem>

#include "logic/game-player.h"

#include "game-panel-colors.h"

#include "game-position.h"

#include "game-panel-gridline-edge.h"

#include "game-utils.h"

#include <QGraphicsView>

#include <QDebug>




void Game_Panel_Board::reset_stone_position_after_move(Stone_Panel_Display* spd)
{
}

void Game_Panel_Board::trace_stone(QString key)
{
 Stone_Panel_Display* result = get_stone_by_key(key);
 QGraphicsItem* item = result->get_graphics_item();
 if(item)
 {
  traced_stones_[item] = result;
  item->setData(1, QVariant("Trace"));
 }
}

Stone_Panel_Display* Game_Panel_Board::get_traced_stone(QGraphicsItem* item)
{
 return traced_stones_.value(item, nullptr);
}


Stone_Panel_Display* Game_Panel_Board::set_stone_at_position(int section_x,
  int section_y, QString key, Stone_Panel_Display::Direction_Status ds)
{
 //Game_Panel_Section* section = get_section(section_y, section_x);
 Stone_Panel_Display* result = get_stone_by_key(key);
 set_stone_at_position(section_x, section_y, result, ds);

 return result;
}


void Game_Panel_Board::mark_section_center_occupied(int section_x,
  int section_y, Stone_Panel_Display* spd)
{
 Game_Panel_Section* section = get_section(section_y, section_x);
 section->set_center_stone(spd);
}


void Game_Panel_Board::set_stone_at_position(int section_x,
  int section_y, Stone_Panel_Display* spd, Stone_Panel_Display::Direction_Status ds)
{
 Game_Panel_Section* section = get_section(section_x, section_y);
 //?result->set_current_value(value);
 spd->move_to_section(section, ds);
 reset_stone_position_after_move(spd);
}


void Game_Panel_Board::set_stone_at_intersection(int grid_x,
  int grid_y, Stone_Panel_Display* spd)
{
 Game_Panel_Gridline_Intersection* gpgi = get_gridline_intersection(grid_x, grid_y);
 spd->move_to_intersection(gpgi);
 reset_stone_position_after_move(spd);
}


Stone_Panel_Display* Game_Panel_Board::set_stone_at_intersection(int grid_x,
  int grid_y, QString key)
{
//? Game_Panel_Gridline_Intersection* gpgi = get_gridline_intersection(grid_x, grid_y);
 Stone_Panel_Display* result = get_stone_by_key(key);

 set_stone_at_intersection(grid_x, grid_y, result);
 //?result->set_current_value(value);
//? result->move_to_intersection(gpgi);
//? reset_stone_position_after_move(result);

 return result;

}



void Game_Panel_Board::init_stones()
{
}


int Game_Panel_Board::get_ring(int i, int j, int center, int offset)
{
 if(i <= center)
 {
  i = center - i;
 }
 else
 {
  i -= (center + offset);
 }

 if(j <= center)
 {
  j = center - j;
 }
 else
 {
  j -= (center + offset);
 }

 if(i > j)
 {
  return (i + 1) * 2;
 }
 else
 {
  return (j + 1) * 2;
 }

}

Stone_Panel_Display* Game_Panel_Board::get_stone_by_key(QString key, int offset)
{
 return stones_.value(key);
 //return stone_keys_.value(key);

}

void Game_Panel_Board::handle_stone_moved_to_intersection(int x, int y, Stone_Panel_Display* spd,
  QGraphicsScene& scene, float scale_factor)
{
 Stone_Panel_Display::Direction_Status ds;
 Game_Panel_Section* section;
 Game_Panel_Gridline_Intersection* intersection;

//?
 QString posd = get_position_description_from_intersection_coordinates(
   spd, section, intersection, ds, x, y);

// QString posd = get_position_description(
//   spd, section, intersection, ds, x, y);

 if(intersection)
 {
  Baccaning_Game_Capture* cap = game_->check_move_or_capture(spd, intersection);
  if(cap)
  {
   // // i.e., a real capture
   if(cap->captured_stone())
   {
    int ret = QMessageBox::warning(nullptr, "Confirm Capture",
      QString("Capture the %1?").arg(cap->get_captured_stone_informal_label()),
      QMessageBox::Yes | QMessageBox::No);
    if(ret != QMessageBox::Yes)
    {
     // // what else?
     draw_to_scene(scene, scale_factor);
     return;
    }
    cap->captured_stone()->remove_from_board();
   }
   confirm_move_stone(spd, intersection, ds);

   intersection->set_current_stone(spd);

   draw_to_scene(scene, scale_factor);
   //gpb.place_current_selected_stone(intersection, ds);
  }
  else
  {
   confirm_move_stone(spd, intersection, ds);
   intersection->set_current_stone(spd);
   draw_to_scene(scene, scale_factor);
  }
 }

 else if(section)
 {
  Baccaning_Game_Capture* cap = game_->check_move_or_capture(spd, section);
  if(cap)
  {
   // // i.e., a real capture
   if(cap->captured_stone())
   {
    int ret = QMessageBox::warning(nullptr, "Confirm Capture",
      QString("Capture the %1?").arg(cap->get_captured_stone_informal_label()),
      QMessageBox::Yes | QMessageBox::No);

    if(ret != QMessageBox::Yes)
    {
     // //?
     draw_to_scene(scene, scale_factor);
     return;
    }
    cap->captured_stone()->remove_from_board();
   }
   confirm_move_stone(spd, section, ds);
   draw_to_scene(scene, scale_factor);
  }
 }
}

bool Game_Panel_Board::is_not_adjacent(Stone_Panel_Display* spd, Game_Panel_Section* section)
{
 return is_not_adjacent(spd->section(), section);
}

bool Game_Panel_Board::is_not_adjacent(Game_Panel_Section* s1, Game_Panel_Section* s2)
{
 int xabs = qAbs(s1->index_x() - s2->index_x());
 if(xabs > 1)
  return true;

 int yabs = qAbs(s1->index_y() - s2->index_y());
 if(yabs > 1)
  return false;

 return true;
}

void Game_Panel_Board::get_guard_neighbors(Stone_Panel_Display* spd,
  QList<Stone_Panel_Display*>& result)
{
 get_guard_neighbors(spd->section(), result);
}

void Game_Panel_Board::get_guard_neighbors(Game_Panel_Section* section,
  QList<Stone_Panel_Display*>& result)
{
 int x_max = 7;
 int y_max = 8;

 for(int i = qMax(0, section->index_x() - 1);
     i <= qMin(x_max, section->index_x() + 1);
     ++i)
 {
  for(int j = qMax(0, section->index_y() - 1);
      j <= qMin(y_max, section->index_y() + 1);
      ++j)
  {
   if((i == section->index_x()) && (j == section->index_y()))
   {
    continue;
   }
   Game_Panel_Section* s = get_section(i, j);
   Stone_Panel_Display* spd = s->get_center_stone();
   if(spd)
   {
    if(spd->is_guard())
     result.push_back(spd);
   }
  }
 }
}


bool Game_Panel_Board::stone_is_onside_at_section(Stone_Panel_Display* spd,
  Game_Panel_Section* section)
{
 if(spd->is_north())
 {
  return section->index_y() < 4;
 }
 return section->index_y() > 5;
}

void Game_Panel_Board::handle_stone_moved_to_section_center(int x, int y, Stone_Panel_Display* spd,
  QGraphicsScene& scene, float scale_factor)
{
 Stone_Panel_Display::Direction_Status ds;
 Game_Panel_Section* section;
 Game_Panel_Gridline_Intersection* intersection;

//?
 QString posd = get_position_description_from_section_coordinates(
   spd, section, intersection, ds, x, y);

// QString posd = get_position_description(
//   spd, section, intersection, ds, x, y);

 if(intersection)
 {
  // //?
  confirm_move_stone(spd, intersection, ds);
 }

 else if(section)
 {
  Baccaning_Game_Capture* cap = game_->check_move_or_capture(spd, section);
  if(cap)
  {
   // // i.e., a real capture
   if(cap->captured_stone())
   {
    int ret = QMessageBox::warning(nullptr, "Confirm Capture",
      QString("Capture the %1?").arg(cap->get_captured_stone_informal_label()),
      QMessageBox::Yes | QMessageBox::No);

    if(ret != QMessageBox::Yes)
    {
     // //?
     draw_to_scene(scene, scale_factor);
     return;
    }
    cap->captured_stone()->remove_from_board();
   }
   if(spd->is_guard())
   {
    game_->analyze_guard_move(spd, spd->section(), section);
   }
   spd->section()->set_center_stone(nullptr);
   confirm_move_stone(spd, section, ds);
   spd->set_section(section);
   draw_to_scene(scene, scale_factor);
   section->set_center_stone(spd);
  }
 }
 switch_players();
 //qDebug() << "X: " << x << " Y: " << y;
}



void Game_Panel_Board::clear_current_selected_stone()
{
 selected_stone_to_add_ = nullptr;
}

void Game_Panel_Board::place_current_selected_stone(Game_Panel_Section* section, Stone_Panel_Display::Direction_Status ds)
{
 confirm_move_stone(selected_stone_to_add_, section, ds);
 selected_stone_to_add_ = nullptr;
}

void Game_Panel_Board::place_current_selected_stone(Game_Panel_Gridline_Intersection* intersection, Stone_Panel_Display::Direction_Status ds)
{
 confirm_move_stone(selected_stone_to_add_, intersection, ds);
 selected_stone_to_add_ = nullptr;
}

void Game_Panel_Board::get_logical_position_from_intersection_coordinates(Stone_Panel_Display* spd,
  Game_Panel_Section*& section, Game_Panel_Gridline_Intersection*& intersection,
  Stone_Panel_Display::Direction_Status& ds, int x, int y)
{
 section = nullptr;
 intersection = get_gridline_intersection(x, y);
 ds = Stone_Panel_Display::Direction_Status::Panel_Intersection;
}

void Game_Panel_Board::get_logical_position_from_section_coordinates(Stone_Panel_Display* spd,
  Game_Panel_Section*& section, Game_Panel_Gridline_Intersection*& intersection,
  Stone_Panel_Display::Direction_Status& ds, int x, int y)
{
 section = get_section(x, y);
 intersection = nullptr; //get_gridline_intersection(y, x);
 ds = Stone_Panel_Display::Direction_Status::Panel_Center;
}

void Game_Panel_Board::get_logical_position_from_offset(Stone_Panel_Display* spd,
  Game_Panel_Section*& section, Game_Panel_Gridline_Intersection*& intersection,
  Stone_Panel_Display::Direction_Status& ds, int x, int y)
{
 Game_Panel_Gridline_Intersection* gpi = spd->position()->intersection();
 section = nullptr;
 ds = Stone_Panel_Display::Direction_Status::Panel_Intersection;

 int intersection_x = gpi->vertical_gridline().index_x() + x;
 int intersection_y = gpi->horizontal_gridline().index_y() + y;
 intersection = get_gridline_intersection(intersection_y, intersection_x);

}

void Game_Panel_Board::get_logical_position(const QPoint& p,
  Game_Panel_Section*& section, Game_Panel_Gridline_Intersection*& intersection, Stone_Panel_Display::Direction_Status& ds)
{
 section = nullptr;

 int intersection_x = ((p.x() / 20.) + .5);
 int intersection_y = ((p.y() / 20.) + .5);

 intersection = get_gridline_intersection(intersection_y, intersection_x);

}

QString Game_Panel_Board::get_position_description_from_intersection_coordinates(Stone_Panel_Display* spd,
  Game_Panel_Section*& section, Game_Panel_Gridline_Intersection*& intersection,
  Stone_Panel_Display::Direction_Status& ds, int x, int y)
{
 get_logical_position_from_intersection_coordinates(spd, section, intersection, ds, x, y);

 return QString("%1, %2")
   .arg(intersection->vertical_gridline().index_x())
   .arg(intersection->horizontal_gridline().index_y())
   ;

}

QString Game_Panel_Board::get_position_description_from_section_coordinates(Stone_Panel_Display* spd,
  Game_Panel_Section*& section, Game_Panel_Gridline_Intersection*& intersection,
  Stone_Panel_Display::Direction_Status& ds, int x, int y)
{
 get_logical_position_from_section_coordinates(spd, section, intersection, ds, x, y);

 return QString("%1, %2")
   .arg(section->index_x())
   .arg(section->index_y())
   ;

}

QString Game_Panel_Board::get_position_description_from_offset(Stone_Panel_Display* spd,
  Game_Panel_Section*& section, Game_Panel_Gridline_Intersection*& intersection,
  Stone_Panel_Display::Direction_Status& ds, int x, int y)
{
 get_logical_position_from_offset(spd, section, intersection, ds, x, y);

 return QString("%1, %2")
   .arg(intersection->vertical_gridline().index_x())
   .arg(intersection->horizontal_gridline().index_y())
   ;

}

QString Game_Panel_Board::get_position_description(const QPoint& p,
  Game_Panel_Section*& section, Game_Panel_Gridline_Intersection*& intersection, Stone_Panel_Display::Direction_Status& ds)
{
 get_logical_position(p, section, intersection, ds);

 return QString("%1, %2")
   .arg(intersection->vertical_gridline().index_x())
   .arg(intersection->horizontal_gridline().index_y())
   ;

}


void Game_Panel_Board::confirm_move_stone(Stone_Panel_Display* spd, Game_Panel_Gridline_Intersection* intersection,
                        Stone_Panel_Display::Direction_Status ds)
{
 spd->move_to_intersection(intersection); //, ds);
 intersection->set_current_stone(spd);
 reset_stone_position_after_move(spd);

}


void Game_Panel_Board::confirm_move_stone(Stone_Panel_Display* spd,
  Game_Panel_Section* section,
  Stone_Panel_Display::Direction_Status ds)
{
 spd->move_to_section(section, ds);
 reset_stone_position_after_move(spd);

// QGraphicsItem* item = spd->get_graphics_item();

// view.connect(item, SLOT(itemChanged(QPoint)), this,
//   SLOT(handle_stone_item_move(QPoint)));

 //stones_.push_back(selected_stone_to_add_);


 //update();
}


QString Game_Panel_Board::stone_description(Stone_Panel_Display* spd) const
{
 return spd->description();
 //QString result = QString("%1-%2").arg(spd->s_or_n()).arg(spd->get_group_stone_label());
 //return result;
}



void Game_Panel_Board::register_stone_to_add(QString key)
{
 if(key.endsWith('K') || key.endsWith('Q'))
 {

 }
 else
 {
  int number = ++stone_keys_used_[key];
  key.append(QString::number(number));
 }
 Stone_Panel_Display* spd = stones_[key];
 selected_stone_to_add_ = spd;
}


void Game_Panel_Board::switch_players()
{
// if(current_player_ == north_player_)
//  current_player_ = south_player_;
// else
//  current_player_ = north_player_;

 game_->switch_players();

}



Game_Panel_Board::Game_Panel_Board(Baccaning_Game* game, Game_Utils& game_utils)
 : game_(game), utils_(game_utils),
   selected_stone_to_add_(nullptr),
   background_rectangle_item_({nullptr, nullptr, nullptr, nullptr})
{
 boundary_width_ = 0;

 for(int i = 0; i < 13; ++i)
 {
  Game_Panel_Vertical_Gridline* v = new Game_Panel_Vertical_Gridline(i, boundary_width_ + 20 * i  );
  vertical_gridlines_.push_back(v);

  for(int j = 0; j < 12; ++j)
  {
   Game_Panel_Gridline_Edge& e = v->get_edge(j);
   e.set_index_x(i);
   e.set_index_y(j);

   if( i == 6 )
   {
    e.set_state(Game_Panel_Gridline_Edge::State::Vertical_Center_Line);
   }

   else if( ( (i == 2) || (i == 3) || (i == 9) || (i == 10) )
       && ( (j == 1) || (j == 3) || (j == 8) || (j == 10) ) )
   {
    e.set_state(Game_Panel_Gridline_Edge::State::Box_Border);
   }

   else if( ( (i == 4) || (i == 8) ) && ( (j == 5) || (j == 6) ) )
   {
    e.set_state(Game_Panel_Gridline_Edge::State::River_Border);
   }
   else
   {
    e.set_state(Game_Panel_Gridline_Edge::State::Plain);
   }
  }
 }

 for(int j = 0; j < 13; ++j)
 {
  Game_Panel_Horizontal_Gridline* h = new Game_Panel_Horizontal_Gridline(j, boundary_width_ + 20 * j  );
  horizontal_gridlines_.push_back(h);

  for(int i = 0; i < 12; ++i)
  {
   Game_Panel_Gridline_Edge& e = h->get_edge(i);
   e.set_index_x(i);
   e.set_index_y(j);

   if( j == 6 )
   {
    e.set_state(Game_Panel_Gridline_Edge::State::Horizontal_Center_Line);
   }

   else if( ( (j == 2) || (j == 3) || (j == 9) || (j == 10) )
       && ( (i == 1) || (i == 3) || (i == 8) || (i == 10) ) )
   {
    e.set_state(Game_Panel_Gridline_Edge::State::Box_Border);
   }

   else if( ( (j == 2) || (j == 3) || (j == 9) || (j == 10) )
       && ( (i > 3) && (i < 8) ) )
   {
    e.set_state(Game_Panel_Gridline_Edge::State::Palace_Border);
   }


   else if( ( (i > 3) && (i < 8) ) && ( (j == 5) || (j == 7) ) )
   {
    e.set_state(Game_Panel_Gridline_Edge::State::River_Border);
   }
   else
   {
    e.set_state(Game_Panel_Gridline_Edge::State::Plain);
   }
  }

  for(int i = 0; i < 13; ++i)
  {
   Game_Panel_Gridline_Intersection::State gs = Game_Panel_Gridline_Intersection::State::Plain;
   Game_Panel_Vertical_Gridline* v = vertical_gridlines_[i];

   Game_Panel_Gridline_Intersection* g = new Game_Panel_Gridline_Intersection(*h, *v, gs);
   g->set_state(Game_Panel_Gridline_Intersection::State::Plain);
   last_gridline_intersection_ = g;
   gridline_intersections_[j + (i * 13)] = g;
   //qDebug() << "Adding: " << j + (i * 13);
  }
 }

 for(int i = 0; i < 12; ++i)
 {
  for(int j = 0; j < 12; ++j)
  {
   Game_Panel_Section::Patterns pattern = Game_Panel_Section::Patterns::N_A;
   Game_Panel_Section::Borders border = Game_Panel_Section::Borders::None;
   Game_Panel_Section::Center_State cs = Game_Panel_Section::Center_State::Plain;

   bool iodd = i % 2 == 1;
   bool jodd = j % 2 == 1;

   //?
   bool darker = iodd ^ jodd; //(iodd && !jodd) || (jodd && !iodd);
   //bool darker = iodd == jodd; //(iodd && !jodd) || (jodd && !iodd);

   if( (i == 0) || (i == 11) )
   {
    pattern = Game_Panel_Section::Patterns::Outfield;
   }
   else
   {
    switch(j)
    {
    case 0:
    case 11:
     pattern = Game_Panel_Section::Patterns::Outfield;
     break;

    case 1:
    case 10:
     if( (i < 4) || (i > 7) )
     {
      pattern = Game_Panel_Section::Patterns::Outfield;
      break;
     }
     goto dark_or_light;

    case 2:
    case 9:
     if( (i == 1) || (i == 10) )
     {
      pattern = Game_Panel_Section::Patterns::Outfield;
      break;
     }
     else if( (i > 3) && (i < 8) )
     {
      pattern = Game_Panel_Section::Patterns::Palace;
      break;
     }
     goto dark_or_light;

    case 3:
    case 8:
    case 4:
    case 7:
     goto dark_or_light;

    case 5:
     if( (i == 1) || (i == 10) )
     {
      pattern = Game_Panel_Section::Patterns::Outfield;
      break;
     }
     else if( (i == 4) || (i == 6) )
     {
      pattern = Game_Panel_Section::Patterns::Bridge_SW;
      break;
     }
     else if( (i == 5) || (i == 7) )
     {
      pattern = Game_Panel_Section::Patterns::Bridge_SE;
      break;
     }
     goto dark_or_light;

    case 6:
     if( (i == 1) || (i == 10) )
     {
      pattern = Game_Panel_Section::Patterns::Outfield;
      break;
     }
     else if( (i == 4) || (i == 6) )
     {
      pattern = Game_Panel_Section::Patterns::Bridge_NW;
      break;
     }
     else if( (i == 5) || (i == 7) )
     {
      pattern = Game_Panel_Section::Patterns::Bridge_NE;
      break;
     }
     goto dark_or_light;


dark_or_light:
     pattern = darker?
       Game_Panel_Section::Patterns::Midfield_Darker :
       Game_Panel_Section::Patterns::Midfield_Lighter;
    }
   }

   Game_Panel_Section* gps = new Game_Panel_Section(i, j,
    20 * i + 10, 20 * j + 10, pattern, border, cs);

   sections_.push_back(gps);
  }
 }

 auto move_to_intersection_callback = [this](int x, int y, Stone_Panel_Display* spd,
   QGraphicsScene& scene, float scale_factor)
 {
  handle_stone_moved_to_intersection(x, y, spd, scene, scale_factor);
 };

 auto move_to_section_center_callback = [this](int x, int y, Stone_Panel_Display* spd,
   QGraphicsScene& scene, float scale_factor)
 {
  handle_stone_moved_to_section_center(x, y, spd, scene, scale_factor);
 };

//#ifdef HIDE

 //  guards
 for(int i = 0; i < 10; ++i)
 {
  Stone_Panel_Display* ng = new Stone_Panel_Display
    (Stone_Panel_Display::Team_Status::North_Guard, i,
     move_to_intersection_callback,
     move_to_section_center_callback);
  Stone_Panel_Display* sg = new Stone_Panel_Display(Stone_Panel_Display::Team_Status::South_Guard, i, move_to_intersection_callback, move_to_section_center_callback);

  stones_[QString("NG%1").arg(i + 1)] = ng;
  stones_[QString("SG%1").arg(i + 1)] = sg;

//  set_stone_at_position(i, 0, ng,
//    Stone_Panel_Display::Direction_Status::Panel_Center);

  set_stone_at_position(i + 1, 4, ng,
    Stone_Panel_Display::Direction_Status::Panel_Center);

  set_stone_at_position(i + 1, 7, sg,
    Stone_Panel_Display::Direction_Status::Panel_Center);


  //mark_section_center_occupied(2, i, sgn);


 }
//#endif

 //  towers
 for(int i = 0; i < 6; ++i)
 {
  Stone_Panel_Display* tw = new Stone_Panel_Display
    (Stone_Panel_Display::Team_Status::Unclaimed_Tower, i,
     move_to_intersection_callback,
     move_to_section_center_callback);

  stones_[QString("TW%1").arg(i + 1)] = tw;

  if(i < 3)
  {
   set_stone_at_intersection(i + 1, 6, tw);
  }
  else
  {
   set_stone_at_intersection(i + 6, 6, tw);
  }

//  set_stone_at_position(i + 1, 4, ng,
//    Stone_Panel_Display::Direction_Status::Panel_Center);



 }



}

#ifdef HIDE
 auto move_to_intersection_callback = [this](int x, int y, Stone_Panel_Display* spd, QGraphicsScene& scene, float scale_factor)
 {
  handle_stone_moved_to_intersection(x, y, spd, scene, scale_factor);
 };

 auto move_to_section_center_callback = [this](int x, int y, Stone_Panel_Display* spd, QGraphicsScene& scene, float scale_factor)
 {
  handle_stone_moved_to_section_center(x, y, spd, scene, scale_factor);
 };

 boundary_width_ = 0;


 for(int i = 0; i < 13; ++i)
 {
  Game_Panel_Vertical_Gridline* v = new Game_Panel_Vertical_Gridline(i, boundary_width_ + 20 * i  );
  vertical_gridlines_.push_back(v);

  //? bool cab = (i == 2) || (i == 18);

  for(int j = 0; j < 13; ++j)
  {
   Game_Panel_Gridline_Edge& e = v->get_edge(j);

   e.set_index_x(i);
   e.set_index_y(j);

   if( ((j == 6) || (j == 7))  && ((i > 0) && (i < 8)) )
   {
    e.set_state(Game_Panel_Gridline_Edge::State::River_Hidden);
   }
   else
   {
    e.set_state(Game_Panel_Gridline_Edge::State::Plain);
   }

  }

 }

 for(int j = 0; j < 13; ++j)
 {
  Game_Panel_Horizontal_Gridline* h = new Game_Panel_Horizontal_Gridline(j, boundary_width_ + (20 * j) );

  if(h == nullptr)
  {
   qDebug() << "Fail alloc ...";
   return;
  }

  horizontal_gridlines_.push_back(h);
  //?bool cab = (j == 2) || (j == 18);

  for(int i = 0; i < 3; ++i)
  {
   Game_Panel_Gridline_Edge& e = h->get_edge(i);

   e.set_index_x(i);
   e.set_index_y(j);

//   else
//   {
    e.set_state(Game_Panel_Gridline_Edge::State::Plain);
//   }
  }

  for(int i = 0; i < 13; ++i)
  {
   Game_Panel_Gridline_Intersection::State gs = Game_Panel_Gridline_Intersection::State::Plain;

//   int r = get_ring(i + 1, j + 1, 10, 2);
//   if(r > 16)
//   {
//    gs = Game_Panel_Gridline_Intersection::State::Marked;
//   }

   Game_Panel_Vertical_Gridline* v = vertical_gridlines_[i];

   Game_Panel_Gridline_Intersection* g = new Game_Panel_Gridline_Intersection(*h, *v, gs);

//   if( ((i == 1) || (i == 7)) && ((j == 2) || (j == 7)) )
//   {
//    g->set_state(Game_Panel_Gridline_Intersection::State::Cross);
//   }
//   else if( ((j == 3) || (j == 6)) && ((i % 2) == 0) )
//   {
//    g->set_state(Game_Panel_Gridline_Intersection::State::Cross);
//   }

//   else if( ((i == 0) || (i == 8)) && ((j == 0) || (j == 9) ))
//   {
//    g->set_state(Game_Panel_Gridline_Intersection::State::Boundary);
//   }

//   else if( ((i == 0)  || (i == 8)   ) &&
//            ( (j == 4) || (j == 5) ) )
//   {
//    g->set_state(Game_Panel_Gridline_Intersection::State::Boundary);
//   }

//   else
//   {
    g->set_state(Game_Panel_Gridline_Intersection::State::Plain);
//   }

   last_gridline_intersection_ = g;


   //gridline_intersections_.push_back(g);

//   int count = i + (j * 9);

//   qDebug() << "COUNT: " << count;

   gridline_intersections_[i + (j * 13)] = g;


  }

 }
//#ifdef HIDE
// {
//  Game_Panel_Gridline_Intersection* g1 = get_gridline_intersection(0, 3);
//  Game_Panel_Gridline_Intersection* g2 = get_gridline_intersection(2, 5);
//  Game_Panel_Diagonal_Gridline* dg = new Game_Panel_Diagonal_Gridline(g1, g2);
//  diagonal_gridlines_.push_back(dg);
// }

// {
//  Game_Panel_Gridline_Intersection* g1 = get_gridline_intersection(0, 5);
//  Game_Panel_Gridline_Intersection* g2 = get_gridline_intersection(2, 3);
//  Game_Panel_Diagonal_Gridline* dg = new Game_Panel_Diagonal_Gridline(g1, g2);
//  diagonal_gridlines_.push_back(dg);
// }

// {
//  Game_Panel_Gridline_Intersection* g1 = get_gridline_intersection(7, 3);
//  Game_Panel_Gridline_Intersection* g2 = get_gridline_intersection(9, 5);
//  Game_Panel_Diagonal_Gridline* dg = new Game_Panel_Diagonal_Gridline(g1, g2);
//  diagonal_gridlines_.push_back(dg);
// }

// {
//  Game_Panel_Gridline_Intersection* g1 = get_gridline_intersection(7, 5);
//  Game_Panel_Gridline_Intersection* g2 = get_gridline_intersection(9, 3);
//  Game_Panel_Diagonal_Gridline* dg = new Game_Panel_Diagonal_Gridline(g1, g2);
//  diagonal_gridlines_.push_back(dg);
// }

// {
//  Game_Panel_Gridline_Intersection* g1 = get_gridline_intersection(0, 0);
//  Game_Panel_Gridline_Intersection* g2 = get_gridline_intersection(5, 5);
//  Game_Panel_Diagonal_Gridline* dg = new Game_Panel_Diagonal_Gridline(g1, g2);
//  diagonal_gridlines_.push_back(dg);
// }

// {
//  Game_Panel_Gridline_Intersection* g1 = get_gridline_intersection(0, 8);
//  Game_Panel_Gridline_Intersection* g2 = get_gridline_intersection(5, 3);
//  Game_Panel_Diagonal_Gridline* dg = new Game_Panel_Diagonal_Gridline(g1, g2);
//  diagonal_gridlines_.push_back(dg);
// }


// {
//  Game_Panel_Gridline_Intersection* g1 = get_gridline_intersection(4, 5);
//  Game_Panel_Gridline_Intersection* g2 = get_gridline_intersection(9, 0);
//  Game_Panel_Diagonal_Gridline* dg = new Game_Panel_Diagonal_Gridline(g1, g2);
//  diagonal_gridlines_.push_back(dg);
// }

// {
//  Game_Panel_Gridline_Intersection* g1 = get_gridline_intersection(4, 3);
//  Game_Panel_Gridline_Intersection* g2 = get_gridline_intersection(9, 8);
//  Game_Panel_Diagonal_Gridline* dg = new Game_Panel_Diagonal_Gridline(g1, g2);
//  diagonal_gridlines_.push_back(dg);
// }



// {
//  Game_Panel_Gridline_Intersection* g1 = get_gridline_intersection(4, 0);
//  Game_Panel_Gridline_Intersection* g2 = get_gridline_intersection(5, 1);
//  Game_Panel_Diagonal_Gridline* dg = new Game_Panel_Diagonal_Gridline(g1, g2);
//  diagonal_gridlines_.push_back(dg);
// }
// {
//  Game_Panel_Gridline_Intersection* g1 = get_gridline_intersection(4, 1);
//  Game_Panel_Gridline_Intersection* g2 = get_gridline_intersection(5, 0);
//  Game_Panel_Diagonal_Gridline* dg = new Game_Panel_Diagonal_Gridline(g1, g2);
//  diagonal_gridlines_.push_back(dg);
// }

// {
//  Game_Panel_Gridline_Intersection* g1 = get_gridline_intersection(4, 7);
//  Game_Panel_Gridline_Intersection* g2 = get_gridline_intersection(5, 8);
//  Game_Panel_Diagonal_Gridline* dg = new Game_Panel_Diagonal_Gridline(g1, g2);
//  diagonal_gridlines_.push_back(dg);
// }
// {
//  Game_Panel_Gridline_Intersection* g1 = get_gridline_intersection(4, 8);
//  Game_Panel_Gridline_Intersection* g2 = get_gridline_intersection(5, 7);
//  Game_Panel_Diagonal_Gridline* dg = new Game_Panel_Diagonal_Gridline(g1, g2);
//  diagonal_gridlines_.push_back(dg);
// }
//#endif


 for(int i = 0; i < 12; ++i)
 {
  for(int j = 0; j < 12; ++j)
  {
   Game_Panel_Section::Patterns pattern = Game_Panel_Section::Patterns::N_A;
   Game_Panel_Section::Borders border = Game_Panel_Section::Borders::None;
   Game_Panel_Section::Center_State cs = Game_Panel_Section::Center_State::Plain;

   bool iodd = i % 2 == 1;
   bool jodd = i % 2 == 1;

   bool darker = iodd && !jodd;

   if(darker) //((i == 0) || (i == 7) || (i == 3) || (i == 4)) && ((j == 2) || (j == 6) ))
   {
    pattern = Game_Panel_Section::Patterns::Ramp;
   }
   else
   {
    pattern = Game_Panel_Section::Patterns::Clear;
   }

   Game_Panel_Section* gps = new Game_Panel_Section(i, j,
    20 * i + 10, 20 * j + 10, pattern, border, cs);

   sections_.push_back(gps);
  }


 }


 for(int i = 0; i < 8; ++i)
 {
  Stone_Panel_Display* spn = new Stone_Panel_Display(Stone_Panel_Display::Team_Status::North_CPawn, i,
    move_to_intersection_callback, move_to_section_center_callback);
  Stone_Panel_Display* sps = new Stone_Panel_Display(Stone_Panel_Display::Team_Status::South_CPawn, i,
    move_to_intersection_callback, move_to_section_center_callback);

  stones_[QString("NP%1").arg(i + 1)] = spn;
  stones_[QString("SP%1").arg(i + 1)] = sps;

  Stone_Panel_Display* sgn = new Stone_Panel_Display(Stone_Panel_Display::Team_Status::North_Guard, i, move_to_intersection_callback, move_to_section_center_callback);
  Stone_Panel_Display* sgs = new Stone_Panel_Display(Stone_Panel_Display::Team_Status::South_Guard, i, move_to_intersection_callback, move_to_section_center_callback);

  stones_[QString("NG%1").arg(i + 1)] = sgn;
  stones_[QString("SG%1").arg(i + 1)] = sgs;

  if(i < 4)
  {
   set_stone_at_position(3, i, sgn, Stone_Panel_Display::Direction_Status::Panel_Center);
   mark_section_center_occupied(3, i, sgn);
   set_stone_at_position(6, i, sgs, Stone_Panel_Display::Direction_Status::Panel_Center);
   mark_section_center_occupied(6, i, sgs);
  }
  else
  {
   set_stone_at_position(2, i, sgn, Stone_Panel_Display::Direction_Status::Panel_Center);
   mark_section_center_occupied(2, i, sgn);
   set_stone_at_position(5, i, sgs, Stone_Panel_Display::Direction_Status::Panel_Center);
   mark_section_center_occupied(5, i, sgs);
  }

 }

 for(int i = 0; i < 2; ++i)
 {
  Stone_Panel_Display* sbn = new Stone_Panel_Display(Stone_Panel_Display::Team_Status::North_CBishop, i, move_to_intersection_callback, move_to_section_center_callback);
  Stone_Panel_Display* sbs = new Stone_Panel_Display(Stone_Panel_Display::Team_Status::South_CBishop, i, move_to_intersection_callback, move_to_section_center_callback);

  stones_[QString("NB%1").arg(i + 1)] = sbn;
  stones_[QString("SB%1").arg(i + 1)] = sbs;

  Stone_Panel_Display* srn = new Stone_Panel_Display(Stone_Panel_Display::Team_Status::North_CRook, i, move_to_intersection_callback, move_to_section_center_callback);
  Stone_Panel_Display* srs = new Stone_Panel_Display(Stone_Panel_Display::Team_Status::South_CRook, i, move_to_intersection_callback, move_to_section_center_callback);

  stones_[QString("NR%1").arg(i + 1)] = srn;
  stones_[QString("SR%1").arg(i + 1)] = srs;

  Stone_Panel_Display* snn = new Stone_Panel_Display(Stone_Panel_Display::Team_Status::North_CKnight, i, move_to_intersection_callback, move_to_section_center_callback);
  Stone_Panel_Display* sns = new Stone_Panel_Display(Stone_Panel_Display::Team_Status::South_CKnight, i, move_to_intersection_callback, move_to_section_center_callback);

  stones_[QString("NN%1").arg(i + 1)] = snn;
  stones_[QString("SN%1").arg(i + 1)] = sns;

 }

 {
  Stone_Panel_Display* skn = new Stone_Panel_Display(Stone_Panel_Display::Team_Status::North_CKing, 0, move_to_intersection_callback, move_to_section_center_callback);
  Stone_Panel_Display* sks = new Stone_Panel_Display(Stone_Panel_Display::Team_Status::South_CKing, 0, move_to_intersection_callback, move_to_section_center_callback);

  stones_["NK"] = skn;
  stones_["SK"] = sks;

  Stone_Panel_Display* sqn = new Stone_Panel_Display(Stone_Panel_Display::Team_Status::North_CQueen, 0, move_to_intersection_callback, move_to_section_center_callback);
  Stone_Panel_Display* sqs = new Stone_Panel_Display(Stone_Panel_Display::Team_Status::South_CQueen, 0, move_to_intersection_callback, move_to_section_center_callback);

  stones_["NQ"] = sqn;
  stones_["SQ"] = sqs;
 }
}
#endif

Game_Panel_Gridline_Intersection* Game_Panel_Board::get_gridline_intersection(int j, int i)
{
 return gridline_intersections_[i + (j * 13)];
}

Game_Panel_Section* Game_Panel_Board::get_section(int j, int i)
{
 return sections_[i + (j * 12)];
}

//Stone_Panel_Display* Game_Panel_Board::get_stone_by_index(int index)
//{
// return stones_.value(index, 0);
//}


void Game_Panel_Board::add_stone_display(QString key, Stone_Panel_Display* spd)
{
 stones_[key] = spd;
}

void Game_Panel_Board::draw_to_scene(QGraphicsScene& scene, float scale_factor)
{
 if(!background_rectangle_item_[0])
 {
  qreal max = 12 * 20 * scale_factor;

  QColor north_qbr_color = QColor("brown");
  QColor north_pen_color = QColor("black");
  north_qbr_color.setAlphaF(0.8);
  north_pen_color.setAlphaF(0.5);
  QBrush north_qbr = QBrush(north_qbr_color);
  QPen north_pen = QPen(north_pen_color);
  north_pen.setWidth(4);

  QColor south_qbr_color = QColor("white");
  QColor south_pen_color = QColor("blue");
  south_qbr_color.setAlphaF(0.5);
  south_qbr_color.setAlphaF(0.5);
  QBrush south_qbr = QBrush(south_qbr_color);
  QPen south_pen = QPen(south_pen_color);
  south_pen.setWidth(4);


  background_rectangle_item_[0] = scene.addRect(-20, -20, 40, 40, north_pen, north_qbr);

  background_rectangle_item_[1] = scene.addRect(max - 20, -20, 40, 40, north_pen, north_qbr);

  background_rectangle_item_[2] = scene.addRect(-20, max - 20, 40, 40, south_pen, south_qbr);

  background_rectangle_item_[3] = scene.addRect(max - 20, max - 20, 40, 40, south_pen, south_qbr);



 }

 // draw outer board

 int section_width = 20;

 QPen outer_pen = QPen(QColor("#059a49"));
 outer_pen.setWidth(3);

//?
// QGraphicsRectItem* item = scene.addRect(0, 0, section_width * 7 * scale_factor,
//               section_width * 8 * scale_factor, outer_pen);

// item->setData(1, QVariant("Background"));


// for(Game_Panel_Section* gps : sections_)
// {
//  gps->draw_to_scene(scene, scale_factor);
// }

//? int offset = section_width - 18;

 int offset = 0;

 int h_min = offset;
 int v_min = offset;
 int h_max = 8 * section_width + offset;
 int v_max = 9 * section_width + offset;

 int i = 0;
 for(Game_Panel_Horizontal_Gridline* h : horizontal_gridlines_)
 {
  h->draw_to_scene(scene, scale_factor, v_min, v_max);
  ++i;
//  if(i > 0)
//   break;
 }

 int j = 0;
 for(Game_Panel_Vertical_Gridline* v : vertical_gridlines_)
 {
  v->draw_to_scene(scene, scale_factor, h_min, h_max);
  ++j;
//  if(j > 0)
//   break;
 }


 for(Game_Panel_Diagonal_Gridline* dg : diagonal_gridlines_)
 {
  dg->draw_to_scene(scene, scale_factor);
  //?++j;
 }
// return ; //



 for(Game_Panel_Gridline_Intersection* g : gridline_intersections_)
 {
  g->draw_to_scene(scene, scale_factor);
 }

 for(Game_Panel_Section* gps : sections_)
 {
  gps->draw_to_scene(scene, scale_factor);
 }

 QMapIterator<QString, Stone_Panel_Display*> it(stones_);
 while(it.hasNext())
 {
  it.next();
  QString key = it.key();
  Stone_Panel_Display* spd = it.value();
  spd->draw_to_scene(scene, scale_factor);
 }

}

