
#ifndef GAME_PANEL_BOARD__H
#define GAME_PANEL_BOARD__H

#include <QList>

#include "stone-panel-display.h"

class QGraphicsScene;
class QGraphicsView;


class Stone_Panel_Display;

class Game_Panel_Section;
class Game_Panel_Horizontal_Gridline;
class Game_Panel_Vertical_Gridline;
class Game_Panel_Gridline_Intersection;
class Game_Panel_Diagonal_Gridline;

class Game_Utils;
class Game_Player;
class Baccaning_Game;

class Game_Panel_Board
{
 QList<Game_Panel_Section*> sections_;

 //QVector<Stone_Panel_Display* > stones_;

 QMap<QString, Stone_Panel_Display* > stones_;

 QList<Game_Panel_Horizontal_Gridline*> horizontal_gridlines_;
 QList<Game_Panel_Vertical_Gridline*> vertical_gridlines_;

 QList<Game_Panel_Diagonal_Gridline*> diagonal_gridlines_;

 //?QList<Game_Panel_Gridline_Intersection*> gridline_intersections_;

 Game_Panel_Gridline_Intersection* gridline_intersections_[169];

// Game_Player* south_player_;
// Game_Player* north_player_;

// Game_Player* current_player_;

 Baccaning_Game* game_;

 Game_Utils& utils_;

 QMap<QString, Stone_Panel_Display*> stone_keys_;

 QMap<QString, int> stone_keys_used_;


 QMap<QString, int> stone_keys_index_;
 QMap<QString, int> stone_keys_added_;

 QMap<QGraphicsItem*, Stone_Panel_Display*> traced_stones_;


 Stone_Panel_Display* selected_stone_to_add_;

 float boundary_width_;

 QGraphicsRectItem* background_rectangle_item_ [4];

 void handle_stone_moved_to_intersection(int x, int y, Stone_Panel_Display* spd, QGraphicsScene& scene, float scale_factor);
 void handle_stone_moved_to_section_center(int x, int y, Stone_Panel_Display* spd, QGraphicsScene& scene, float scale_factor);

public:


 Game_Panel_Board(Baccaning_Game* game, Game_Utils& game_utils);

// ACCESSORS(Game_Player* ,south_player)
// ACCESSORS(Game_Player* ,north_player)
 ACCESSORS(Stone_Panel_Display* ,selected_stone_to_add)

 QString stone_description(Stone_Panel_Display* spd) const;

 QString get_position_description_from_offset(Stone_Panel_Display* spd,
   Game_Panel_Section*& section, Game_Panel_Gridline_Intersection*& intersection,
   Stone_Panel_Display::Direction_Status& ds, int x, int y);

 QString get_position_description_from_intersection_coordinates(Stone_Panel_Display* spd,
   Game_Panel_Section*& section, Game_Panel_Gridline_Intersection*& intersection,
   Stone_Panel_Display::Direction_Status& ds, int x, int y);

 QString get_position_description_from_section_coordinates(Stone_Panel_Display* spd,
   Game_Panel_Section*& section, Game_Panel_Gridline_Intersection*& intersection,
   Stone_Panel_Display::Direction_Status& ds, int x, int y);

 void get_logical_position_from_offset(Stone_Panel_Display* spd,
   Game_Panel_Section*& section, Game_Panel_Gridline_Intersection*& intersection,
   Stone_Panel_Display::Direction_Status& ds, int x, int y);

 void get_logical_position_from_intersection_coordinates(Stone_Panel_Display* spd,
   Game_Panel_Section*& section, Game_Panel_Gridline_Intersection*& intersection,
   Stone_Panel_Display::Direction_Status& ds, int x, int y);

 void get_logical_position_from_section_coordinates(Stone_Panel_Display* spd,
   Game_Panel_Section*& section, Game_Panel_Gridline_Intersection*& intersection,
   Stone_Panel_Display::Direction_Status& ds, int x, int y);

 QString get_position_description(const QPoint& p,
   Game_Panel_Section*& section, Game_Panel_Gridline_Intersection*& intersection, Stone_Panel_Display::Direction_Status& ds);

 void get_logical_position(const QPoint& p,
   Game_Panel_Section*& section, Game_Panel_Gridline_Intersection*& intersection,
   Stone_Panel_Display::Direction_Status& ds);


 void trace_stone(QString key);

 Stone_Panel_Display* get_traced_stone(QGraphicsItem* item);

 Stone_Panel_Display* get_stone_by_index(int index);

 void confirm_move_stone(Stone_Panel_Display* spd, Game_Panel_Section* section,
                         Stone_Panel_Display::Direction_Status ds);

 void confirm_move_stone(Stone_Panel_Display* spd, Game_Panel_Gridline_Intersection* intersection,
                         Stone_Panel_Display::Direction_Status ds);

 Game_Panel_Gridline_Intersection* get_gridline_intersection(int x, int y);

 Game_Panel_Gridline_Intersection* last_gridline_intersection_;


 void clear_current_selected_stone();
 void place_current_selected_stone(Game_Panel_Section* section,
   Stone_Panel_Display::Direction_Status ds);

 void place_current_selected_stone(Game_Panel_Gridline_Intersection* intersection,
    Stone_Panel_Display::Direction_Status ds);


 static int get_ring(int i, int j, int center, int offset = 1);

 void draw_to_scene(QGraphicsScene& scene, float scale_factor);

 void add_stone_display(QString key, Stone_Panel_Display* spd);

 Game_Panel_Section* get_section(int i, int j);

 Stone_Panel_Display* get_stone_by_key(QString key, int offset = 0);

 void init_stones();
 void reset_stone_position_after_move(Stone_Panel_Display* spd);

 void switch_players();

 Stone_Panel_Display* set_stone_at_position(int section_x,
   int section_y, QString key, Stone_Panel_Display::Direction_Status ds);

 void set_stone_at_position(int section_x,
   int section_y, Stone_Panel_Display* spd, Stone_Panel_Display::Direction_Status ds);

 void mark_section_center_occupied(int section_x,
   int section_y, Stone_Panel_Display* spd);

 bool stone_is_onside_at_section(Stone_Panel_Display* spd,
   Game_Panel_Section* section);

 void set_stone_at_intersection(int grid_x,
   int grid_y, Stone_Panel_Display* spd);

 Stone_Panel_Display* set_stone_at_intersection(int grid_x,
   int grid_y, QString key);


 bool is_not_adjacent(Stone_Panel_Display* spd, Game_Panel_Section* section);
 bool is_not_adjacent(Game_Panel_Section* s1, Game_Panel_Section* s2);

 void register_stone_to_add(QString key);

 void get_guard_neighbors(Game_Panel_Section* section,
   QList<Stone_Panel_Display*>& result);

 void get_guard_neighbors(Stone_Panel_Display* spd,
   QList<Stone_Panel_Display*>& result);

 //?Game_Panel_Gridline_Intersection* get_gridline_intersection(int j, int i);


};


#endif
