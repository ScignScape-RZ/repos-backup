

#include "game-panel-colors.h"

#include <QGraphicsView>


Game_Panel_Colors* global_colors = new Game_Panel_Colors;

Game_Panel_Colors::Game_Panel_Colors()
{
 north_player_stone_dark_outer_color_ = QColor("#A00020");
 north_player_stone_dark_outer_color_.setAlphaF(0.75);
 north_player_stone_dark_inner_color_ = QColor("#B00090");
 north_player_stone_dark_inner_color_.setAlphaF(0.75);

 north_player_stone_light_outer_color_ = QColor("#A00020");
 north_player_stone_light_outer_color_.setAlphaF(0.25);
 north_player_stone_light_inner_color_ = QColor("#B00090");
 north_player_stone_light_outer_color_.setAlphaF(0.25);

 south_player_stone_dark_outer_color_ = QColor("#2000A0");
 south_player_stone_dark_outer_color_.setAlphaF(0.75);
 south_player_stone_dark_inner_color_ = QColor("#9000B0");
 south_player_stone_dark_inner_color_.setAlphaF(0.75);

 south_player_stone_light_outer_color_ = QColor("#2000A0");
 south_player_stone_light_outer_color_.setAlphaF(0.35);
 south_player_stone_light_inner_color_ = QColor("#402000");
 south_player_stone_light_inner_color_.setAlphaF(0.85);


 north_player_stone_dark_outer_select_color_ = QColor("#FFFF30");
 north_player_stone_dark_outer_select_color_.setAlphaF(1);
 north_player_stone_dark_inner_select_color_ = QColor("#B00030");
 north_player_stone_dark_inner_select_color_.setAlphaF(1);

 north_player_stone_light_outer_select_color_ = QColor("#B00030");
 north_player_stone_light_outer_select_color_.setAlphaF(1);
 north_player_stone_light_inner_select_color_ = QColor("#B00030");
 north_player_stone_light_inner_select_color_.setAlphaF(0.5);

 south_player_stone_dark_outer_select_color_ = QColor("#2000A0");
 south_player_stone_dark_outer_select_color_.setAlphaF(1);
 south_player_stone_dark_inner_select_color_ = QColor("#2000A0");
 south_player_stone_dark_inner_select_color_.setAlphaF(0.75);

 south_player_stone_light_outer_select_color_ = QColor("#2000A0");
 south_player_stone_light_outer_select_color_.setAlphaF(1);
 south_player_stone_light_inner_select_color_ = QColor("#402020");
 south_player_stone_light_inner_select_color_.setAlphaF(0.35);


 doubled_top_outer_color_ = QColor("yellow");
 doubled_top_inner_color_ = QColor("#409020");

 doubled_top_outer_color_.setAlphaF(0.25);
 doubled_top_inner_color_.setAlphaF(0.6);


 boundary_point_color_ = QColor(70, 100, 125, 160);

 strong_diagonal_color_ = QColor(70, 10, 10);
 soft_diagonal_color_ = QColor(200, 120, 120);


 south_guard_outer_color_ = QColor(0, 0, 30, 150);
 north_guard_outer_color_ = QColor(100, 0, 0, 150);

 south_guard_inner_color_ = QColor(0, 0, 30, 50);
 north_guard_inner_color_ = QColor(100, 0, 0, 50);

 south_submarine_outer_color_ = QColor(80, 80, 130, 150);
 north_submarine_outer_color_ = QColor(130, 80, 80, 150);

 south_submarine_inner_color_ = QColor(70, 70, 100, 130);
 north_submarine_inner_color_ = QColor(100, 40, 40, 130);



 south_stone_background_color_ = QColor(161, 202, 241);
 north_stone_background_color_ = QColor(200, 90, 70);


 plain_edge_color_ = QColor(94, 47, 10, 70);


 box_border_color_ = QColor(204, 47, 110, 200);
 box_border_color_.setAlphaF(0.8);

 river_border_color_ = QColor("#008b8b");
 river_border_color_.setAlphaF(0.7);


 vertical_center_line_color_ = QColor("#004b5b");
 horizontal_center_line_color_ = QColor("#005b4b");

 placement_mark_color_ = QColor(153,	0,	51, 140);
 section_box_border_color_ = QColor("brown");
 section_box_border_color_.setAlphaF(0.3);


// light_section_brush_0_color_ = QColor("#fcf1dc");
// light_section_brush_1_color_ = QColor("#fcdcf1");

// dark_section_brush_0_color_ = QColor("#cccccc");
// dark_section_brush_1_color_ = QColor("#cdcdcd");


// dark_section_brush_0_color_ = QColor("#fcf1dc");
// dark_section_brush_1_color_ = QColor("#fcdcf1");

// light_section_brush_0_color_ = QColor("#eeeeee");
// light_section_brush_1_color_ = QColor("#ffffff");



//  light_section_brush_0_color_ = QColor("#fcf1dc");
//  light_section_brush_1_color_ = QColor("#fcdcf1");

//   light_section_brush_0_color_ = QColor("#f1fcdc");
//   light_section_brush_1_color_ = QColor("#dcfcf1");

  light_section_brush_0_color_ = QColor("#8b8b00");
  light_section_brush_1_color_ = QColor("#ffffff");
  light_section_brush_0_color_.setAlphaF(0.5);

  dark_section_brush_0_color_ = QColor("#616c5c");
  dark_section_brush_1_color_ = QColor("#dc8890");

  palace_section_brush_0_color_ = QColor("#e7c079");
//  palace_section_brush_1_color_ = QColor("#f1dcfc");
  palace_section_brush_1_color_ = QColor("#efb242");
  palace_section_brush_2_color_ = QColor("#8888bb");



  clear_section_brush_0_color_ = QColor("#efb242");
  clear_section_brush_1_color_ = QColor("#e7c079");

  palace_border_color_ = QColor("#cccccc");
  palace_border_color_.setAlphaF(0.7);


//?
//    left_frontier_section_brush_0_color_ = QColor("#dcf1fc");
//    left_frontier_section_brush_1_color_ = QColor("#e7c079");

    left_frontier_section_brush_0_color_ = QColor("#e7c079");
    left_frontier_section_brush_1_color_ = QColor("#FFc079");

    right_frontier_section_brush_0_color_ = QColor("#c079FF");
    right_frontier_section_brush_1_color_ = QColor("#FF42CC");

    section_zone_border_marker_color_ = QColor("#008b8b");
    central_area_marker_color_ = QColor("#06a850");


//?    frontier_marker_color_ = QColor("#e7c079");
    south_frontier_marker_color_ = QColor(200, 40, 0, 100); //"#ee7700");
    north_frontier_marker_color_ = QColor(100, 40, 200, 100); //"#ee7700");


}

void Game_Panel_Colors::left_frontier_section_brush(QBrush& qbr,
  qreal x1, qreal y1, qreal x2, qreal y2)
{
 QLinearGradient gradient(
  x1, y1, x2, y2 );

 gradient.setColorAt(0, left_frontier_section_brush_0_color_);
 gradient.setColorAt(0.5, left_frontier_section_brush_1_color_);
 gradient.setColorAt(1, left_frontier_section_brush_0_color_);

 qbr = QBrush(gradient);

}

void Game_Panel_Colors::right_frontier_section_brush(QBrush& qbr,
  qreal x1, qreal y1, qreal x2, qreal y2)
{
 QLinearGradient gradient(
  x1, y1, x2, y2 );

 gradient.setColorAt(0, right_frontier_section_brush_0_color_);
 gradient.setColorAt(1, right_frontier_section_brush_1_color_);

 qbr = QBrush(gradient);

}

void Game_Panel_Colors::dark_section_brush(QBrush& qbr,
  qreal x1, qreal y1, qreal x2, qreal y2)
{
 QLinearGradient gradient(
  x1, y1, x2, y2 );

 gradient.setColorAt(0, dark_section_brush_0_color_);
 gradient.setColorAt(1, dark_section_brush_1_color_);

 qbr = QBrush(gradient);

}

void Game_Panel_Colors::palace_section_brush(QBrush& qbr,
  qreal x1, qreal y1, qreal x2, qreal y2)
{
 QLinearGradient gradient(
  x1, y1, x2, y2 );

 gradient.setColorAt(0, palace_section_brush_0_color_);
 gradient.setColorAt(0.4, palace_section_brush_1_color_);
 gradient.setColorAt(0.5, palace_section_brush_2_color_);
 gradient.setColorAt(0.6, palace_section_brush_1_color_);
 gradient.setColorAt(1, palace_section_brush_0_color_);

 qbr = QBrush(gradient);
}



void Game_Panel_Colors::clear_section_brush(QBrush& qbr,
  qreal x1, qreal y1, qreal x2, qreal y2)
{
 QLinearGradient gradient(
  x1, y1, x2, y2 );

 gradient.setColorAt(0, clear_section_brush_0_color_);
 gradient.setColorAt(1, clear_section_brush_1_color_);

 qbr = QBrush(gradient);
}

void Game_Panel_Colors::light_section_brush(QBrush& qbr,
  qreal x1, qreal y1, qreal x2, qreal y2)
{
 QLinearGradient gradient(
  x1, y1, x2, y2 );

 gradient.setColorAt(0, light_section_brush_0_color_);
 gradient.setColorAt(1, light_section_brush_1_color_);

 qbr = QBrush(gradient);
}





//To put it delicately, I think you’re nuts.  The tone of your response suggests a transactional mentality which is not helpful in society at large, still less in a household.  Should children or young adults be allowed to do anything they want, without thought of consequences?  Of course not.  There are civic norms which are expected of all people living in a democratic country: being diligent and working and/or studying hard, being open-minded and respectful of others, seeing the best and not the worst in competing viewpoints, being committed to peace and restraining feelings of aggression and/or emotional dependency, not bullying others or forcing them to do things against their will, respecting entrepreneurial and creative spirit and endeavors and personal “projects”.  Those values need to permeate society; they’re not “house rules” like keeping a room clean or being home for dinner.  It’s fair to expect children to respect and generally be part of the family as a loving member of a tightknit (very small) community, so if kids never spoke to parents or decided to avoid them everyday that would signal something wrong.  But holding these domestic principles up to children as a sledgehammer threatening their very existence — as if they should feel existential insecurity just for a messy room or a late evening with friends — is animalistic.  It’s not as if we live in a jungle where people can run into the woods and sustain themselves indefinitely; most people in the modern world are not adapted to that sort of asocial existence.
//I hear this talk about “living rent free” or “legs under the table” alot (I’m 43, by the way, teenage years long behind me).  What, so if your kids weren’t there you’d rent the rooms to strangers?  Are you buying them their own expensive food apart from what the family eats?  Any family I know the kids don’t take up all that much space or food or day-to-day expense that the kids hypothetically leaving home would change all that much.  Sure, you need alot more income with children but most of that is school, doctors, summer camp, and activities and the like.  Sure, your kids depend on you, but is there something wrong with that?  Don’t you depend on your employer and/or (if you’re self-employed) your customers?  Doesn’t your employer depend on government to enforce rule of law and monetary policies that make it possible for us to function financially?  Doesn’t government depend on other governments with which it enters treaties to presume overall peace among at least the large countries in the world?  Everyone depends on everyone else in the modern world.  The value of a person’s endeavors is not measured by the degree of independence it affords them from others, because to seek out material independence diminishes rather than promotes modern society.  So if you treat your children as if their dependency on you is a failing on their part, they could get a distorted picture of the relative worth of their future actions.  After all, it is important for young adults to spend some years getting educated, learning to be democratic citizens, but this does not in and of itself and while they’re in school lead to financial independence — quite the opposite.  And if you start a business, or help build a business as anything but a low-level employee, it’s quite possible you’ll be adopting a business model where loans, grants (like from the Small Business Administration), or (on a larger scale) government bailouts, are a possibly intrinsic part of revenue stream.  And unless we can get free college tuition, students will mostly have to accept government-guaranteed student loans as part of life.  All of this means that a creative dynamic society almost forces us  accept interdependence as a baseline of financial and day-to-day stability.  To prepare for this it is important for children NOT to think that they eating food at the parents’ table is somehow a privilege that can be revoked, or a source of existential insecurity.


