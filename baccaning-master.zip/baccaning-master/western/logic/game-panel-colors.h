
#ifndef GAME_PANEL_COLORS__H
#define GAME_PANEL_COLORS__H

#include "../accessors.h"

#include <QColor>
#include <QGradient>
#include <QBrush>

//class QGraphicsScene;

//class Stone_Panel_Display;

class Game_Panel_Colors
{
 QColor south_player_stone_dark_outer_color_;
 QColor south_player_stone_dark_inner_color_;

 QColor south_player_stone_light_outer_color_;
 QColor south_player_stone_light_inner_color_;

 QColor north_player_stone_dark_outer_color_;
 QColor north_player_stone_dark_inner_color_;

 QColor north_player_stone_light_outer_color_;
 QColor north_player_stone_light_inner_color_;


 QColor south_player_stone_dark_outer_select_color_;
 QColor south_player_stone_dark_inner_select_color_;

 QColor south_player_stone_light_outer_select_color_;
 QColor south_player_stone_light_inner_select_color_;

 QColor north_player_stone_dark_outer_select_color_;
 QColor north_player_stone_dark_inner_select_color_;

 QColor north_player_stone_light_outer_select_color_;
 QColor north_player_stone_light_inner_select_color_;

 QColor north_stone_background_color_;
 QColor south_stone_background_color_;


 QColor doubled_top_outer_color_;
 QColor doubled_top_inner_color_;

 QColor plain_edge_color_;
 QColor river_border_color_;
 QColor box_border_color_;
 QColor palace_border_color_;

 QColor vertical_center_line_color_;
 QColor horizontal_center_line_color_;

 QColor light_section_brush_0_color_;
 QColor light_section_brush_1_color_;

 QColor dark_section_brush_0_color_;
 QColor dark_section_brush_1_color_;

 QColor clear_section_brush_0_color_;
 QColor clear_section_brush_1_color_;

 QColor palace_section_brush_0_color_;
 QColor palace_section_brush_1_color_;
 QColor palace_section_brush_2_color_;

 QColor placement_mark_color_;
 QColor section_box_border_color_;

 QColor left_frontier_section_brush_0_color_;
 QColor left_frontier_section_brush_1_color_;

 QColor right_frontier_section_brush_0_color_;
 QColor right_frontier_section_brush_1_color_;

 QColor section_zone_border_marker_color_;
 QColor central_area_marker_color_;
 QColor south_frontier_marker_color_;
 QColor north_frontier_marker_color_;

 QColor south_guard_inner_color_;
 QColor north_guard_inner_color_;
 QColor south_guard_outer_color_;
 QColor north_guard_outer_color_;


 QColor south_submarine_outer_color_;
 QColor north_submarine_outer_color_;
 QColor south_submarine_inner_color_;
 QColor north_submarine_inner_color_;

 QColor strong_diagonal_color_;
 QColor soft_diagonal_color_;

 QColor boundary_point_color_;

public:


 Game_Panel_Colors();


 ACCESSORS__RGET(QColor ,south_player_stone_dark_outer_color)
 ACCESSORS__RGET(QColor ,south_player_stone_dark_inner_color)
 ACCESSORS__RGET(QColor ,south_player_stone_light_outer_color)
 ACCESSORS__RGET(QColor ,south_player_stone_light_inner_color)

 ACCESSORS__RGET(QColor ,north_player_stone_dark_outer_color)
 ACCESSORS__RGET(QColor ,north_player_stone_dark_inner_color)
 ACCESSORS__RGET(QColor ,north_player_stone_light_outer_color)
 ACCESSORS__RGET(QColor ,north_player_stone_light_inner_color)


 ACCESSORS__RGET(QColor ,south_player_stone_dark_outer_select_color)
 ACCESSORS__RGET(QColor ,south_player_stone_dark_inner_select_color)
 ACCESSORS__RGET(QColor ,south_player_stone_light_outer_select_color)
 ACCESSORS__RGET(QColor ,south_player_stone_light_inner_select_color)

 ACCESSORS__RGET(QColor ,north_player_stone_dark_outer_select_color)
 ACCESSORS__RGET(QColor ,north_player_stone_dark_inner_select_color)
 ACCESSORS__RGET(QColor ,north_player_stone_light_outer_select_color)
 ACCESSORS__RGET(QColor ,north_player_stone_light_inner_select_color)


 ACCESSORS__RGET(QColor ,doubled_top_outer_color)
 ACCESSORS__RGET(QColor ,doubled_top_inner_color)


 ACCESSORS__RGET(QColor ,strong_diagonal_color)
 ACCESSORS__RGET(QColor ,soft_diagonal_color)

 ACCESSORS__RGET(QColor ,boundary_point_color)

 ACCESSORS__RGET(QColor ,south_guard_outer_color)
 ACCESSORS__RGET(QColor ,north_guard_outer_color)
 ACCESSORS__RGET(QColor ,south_guard_inner_color)
 ACCESSORS__RGET(QColor ,north_guard_inner_color)


 ACCESSORS__RGET(QColor ,south_submarine_outer_color)
 ACCESSORS__RGET(QColor ,north_submarine_outer_color)
 ACCESSORS__RGET(QColor ,south_submarine_inner_color)
 ACCESSORS__RGET(QColor ,north_submarine_inner_color)


 ACCESSORS__RGET(QColor ,north_stone_background_color)
 ACCESSORS__RGET(QColor ,south_stone_background_color)


 ACCESSORS__RGET(QColor ,palace_border_color)
 ACCESSORS__RGET(QColor ,box_border_color)
 ACCESSORS__RGET(QColor ,river_border_color)
 ACCESSORS__RGET(QColor ,plain_edge_color)

 ACCESSORS__RGET(QColor ,vertical_center_line_color)
 ACCESSORS__RGET(QColor ,horizontal_center_line_color)


 ACCESSORS__RGET(QColor ,light_section_brush_0_color)
 ACCESSORS__RGET(QColor ,light_section_brush_1_color)

 ACCESSORS__RGET(QColor ,placement_mark_color)
 ACCESSORS__RGET(QColor ,section_box_border_color)

 ACCESSORS__RGET(QColor ,section_zone_border_marker_color)
 ACCESSORS__RGET(QColor ,central_area_marker_color)
 ACCESSORS__RGET(QColor ,south_frontier_marker_color)
 ACCESSORS__RGET(QColor ,north_frontier_marker_color)


 void light_section_brush(QBrush& qbr,
   qreal x1, qreal y1, qreal x2, qreal y2);

 void dark_section_brush(QBrush& qbr,
   qreal x1, qreal y1, qreal x2, qreal y2);

 void palace_section_brush(QBrush& qbr,
   qreal x1, qreal y1, qreal x2, qreal y2);

 void clear_section_brush(QBrush& qbr,
   qreal x1, qreal y1, qreal x2, qreal y2);

 void left_frontier_section_brush(QBrush& qbr,
   qreal x1, qreal y1, qreal x2, qreal y2);

 void right_frontier_section_brush(QBrush& qbr,
   qreal x1, qreal y1, qreal x2, qreal y2);

};

extern Game_Panel_Colors* global_colors;


#endif
