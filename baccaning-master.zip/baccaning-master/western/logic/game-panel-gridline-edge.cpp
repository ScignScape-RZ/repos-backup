

#include "game-panel-gridline-edge.h"

#include "game-panel-colors.h"

#include <QGraphicsView>
#include <QGraphicsLineItem>

Game_Panel_Gridline_Edge::Game_Panel_Gridline_Edge(State state) :
    state_(state), index_x_(-1), index_y_(-1), line_item_(nullptr)
{

}


void Game_Panel_Gridline_Edge::draw_as_vertical(QGraphicsScene& scene,
  float scale_factor, float center_x) const
{
 if(line_item_)
  return;

 int width = 20;

 QBrush qbr;
 QPen qpen;

 int pen_width = scale_factor > 1.5 ? 3 : 1;


 switch(state_)
 {
// case State::Central_Area_Border:
//  qpen = QPen(QColor("#06a850"));
//  break;

// case State::Section_Zone_Border_Marker:
//  qpen = QPen(QColor("#008b8b"));
//  break;

 case State::Plain:
  qpen = QPen(global_colors->plain_edge_color());
  break;

 case State::Vertical_Center_Line:
  qpen = QPen(global_colors->vertical_center_line_color());
  pen_width = 2;

  break;

 case State::Palace_Border:
  qpen = QPen(global_colors->river_border_color());
  break;

 case State::River_Border:
  qpen = QPen(global_colors->river_border_color());
  break;

 case State::Box_Border:
  qpen = QPen(global_colors->box_border_color());
  break;

 default:
  break;
 }

 qpen.setWidth(pen_width);

 float y_min = scale_factor * index_y_ * width + 1;
 float y_max = scale_factor * (index_y_ + 1) * width - 1;

 float x = center_x;// - (scale_factor * width / 2);

 line_item_ = scene.addLine(x, y_min, x, y_max, qpen);

 line_item_->setZValue(1);
 //?qpen.setJoinStyle(Qt::RoundJoin);

// float center_x = scale_factor * local_x_center_;

// //center_x -= pen_width/2;

// float y_min = scale_factor * local_y_min;
// float y_max = scale_factor * local_y_max;

//? scene.addLine(center_x, y_min, center_x, y_max, qpen);

}

void Game_Panel_Gridline_Edge::draw_as_diagonal(QGraphicsScene& scene, float scale_factor)  const
{
 if(line_item_)
  return;

 int width = 20;

 QBrush qbr;
 QPen qpen;

 int pen_width = scale_factor > 1.5 ? 2 : 1;

 int direction_offset;

 switch(state_)
 {
 case State::Back_Diagonal_Strong:
  qpen = QPen(global_colors->strong_diagonal_color());
  direction_offset = 1;
  break;
 case State::Forward_Diagonal_Strong:
  qpen = QPen(global_colors->strong_diagonal_color());
  direction_offset = -1;
  break;

 case State::Back_Diagonal_Soft:
  qpen = QPen(global_colors->soft_diagonal_color());
  direction_offset = 1;
  break;
 case State::Forward_Diagonal_Soft:
  qpen = QPen(global_colors->soft_diagonal_color());
  direction_offset = -1;
  break;
 default:
  direction_offset = 0;
  break;
 }

 qpen.setWidth(pen_width);

 float x_min = scale_factor * index_x_ * width + direction_offset;
 float x_max = scale_factor * (index_x_ + direction_offset) * width - direction_offset;

 float y_min = scale_factor * index_y_ * width + 1;
 float y_max = scale_factor * (index_y_ + 1) * width - 1;

 // adjust for inside river
 if(index_y_ == 4)
 {
  if(index_x_ == 4)
  {
   x_max -= direction_offset * (width * scale_factor) / 2;
   y_max -=  (width * scale_factor) / 2;
  }

  else if( (index_x_ == 3) || (index_x_ == 5) )
  {
   x_min += direction_offset * (width * scale_factor) / 2;
   y_min +=  (width * scale_factor) / 2;
  }

  else if( (index_x_ == 0) || (index_x_ == 8) )
  {
   x_max -= direction_offset * (width * scale_factor) / 2;
   y_max -=  (width * scale_factor) / 2;
  }

  else if( (index_x_ == 1) || (index_x_ == 7) )
  {
   x_min += direction_offset * (width * scale_factor) / 2;
   y_min +=   (width * scale_factor) / 2;
  }

 }

 line_item_ = scene.addLine(x_min, y_min, x_max, y_max, qpen);

}


void Game_Panel_Gridline_Edge::draw_as_horizontal(QGraphicsScene& scene,
  float scale_factor, float center_y) const
{
 if(line_item_)
  return;

 int width = 20;

 QBrush qbr;
 QPen qpen;

 int pen_width = scale_factor > 1.5 ? 3 : 1;

 switch(state_)
 {
// case State::Central_Area_Border:
//  qpen = QPen(global_colors->central_area_marker_color() ) ;// QColor("#06a850"));
//  break;

 case State::Plain:
  qpen = QPen(global_colors->plain_edge_color());
  break;

 case State::Horizontal_Center_Line:
  qpen = QPen(global_colors->horizontal_center_line_color());
  pen_width = 2;
  break;

 case State::Palace_Border:
  qpen = QPen(global_colors->palace_border_color());
  break;

 case State::River_Border:
  qpen = QPen(global_colors->river_border_color());
  break;

 case State::Box_Border:
  qpen = QPen(global_colors->box_border_color());
  break;


// case State::River_Hidden:
//  qpen = QPen(global_colors->river_hidden_color());
//  break;

// case State::Section_Zone_Border_Marker:
//  qpen = QPen(global_colors->section_zone_border_marker_color());
//  break;

// case State::South_Frontier_Marker:
//  qpen = QPen(global_colors->south_frontier_marker_color());
//  pen_width *= 2;
//  break;

// case State::North_Frontier_Marker:
//  qpen = QPen(global_colors->north_frontier_marker_color());
//  pen_width *= 2;
//  break;

 default:
  break;
 }

 qpen.setWidth(pen_width);

 float x_min = scale_factor * index_x_ * width + 1;
 float x_max = scale_factor * (index_x_ + 1) * width - 1;

 float y = center_y; // - scale_factor * width / 2;

 line_item_ = scene.addLine(x_min, y, x_max, y, qpen);

 line_item_->setZValue(1);


 //?qpen.setJoinStyle(Qt::RoundJoin);

// float center_x = scale_factor * local_x_center_;

// //center_x -= pen_width/2;

// float y_min = scale_factor * local_y_min;
// float y_max = scale_factor * local_y_max;

//? scene.addLine(center_x, y_min, center_x, y_max, qpen);

}

