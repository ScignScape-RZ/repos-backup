
#ifndef GAME_PANEL_GRIDLINE_EDGE__H
#define GAME_PANEL_GRIDLINE_EDGE__H

#include "../accessors.h"

//#include "game-panel-horizontal-gridline.h"
//#include "game-panel-vertical-gridline.h"

class QGraphicsScene;

class Stone_Panel_Display;
class QGraphicsLineItem;

class Game_Panel_Gridline_Edge
{
 int index_x_;
 int index_y_;

 Stone_Panel_Display* current_stone_;

 mutable QGraphicsLineItem* line_item_;

public:

 enum class State
 {
  N_A, Plain, River_Border, Box_Border, Palace_Border,

  Vertical_Center_Line, Horizontal_Center_Line,

  Forward_Diagonal_Strong, Forward_Diagonal_Soft,
  Back_Diagonal_Strong, Back_Diagonal_Soft,

//  Section_Zone_Border_Marker, Grid_Zone_Border_Marker,
//  South_Frontier_Marker, North_Frontier_Marker
 };

private:

 State state_;

public:

 Game_Panel_Gridline_Edge(State state = State::N_A);

 ACCESSORS(State ,state)
 ACCESSORS(int ,index_x)
 ACCESSORS(int ,index_y)


 void draw_as_vertical(QGraphicsScene& scene, float scale_factor, float center_x)  const;
 void draw_as_horizontal(QGraphicsScene& scene, float scale_factor, float center_y)  const;

 void draw_as_diagonal(QGraphicsScene& scene, float scale_factor) const;


};


#endif
