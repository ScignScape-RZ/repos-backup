

#include "game-panel-horizontal-gridline.h"

#include <QGraphicsView>

Game_Panel_Horizontal_Gridline::Game_Panel_Horizontal_Gridline(int index_y,
  int local_y_center)
 : index_y_(index_y),
   local_y_center_(local_y_center)
{


}


Game_Panel_Gridline_Edge& Game_Panel_Horizontal_Gridline::get_edge(int index)
{
 return edges_[index];
}


void Game_Panel_Horizontal_Gridline::draw_to_scene(QGraphicsScene& scene,
  float scale_factor, int local_x_min, int local_x_max)
{
 QBrush qbr;
 QPen qpen = QPen(QColor("#ACD0A0"));

 int pen_width = scale_factor > 1.5 ? 3 : 1;

 qpen.setWidth(pen_width);
 //?qpen.setJoinStyle(Qt::RoundJoin);

 int width = 20;

 float center_y = scale_factor * local_y_center_;

 //center_x -= pen_width/2;

// float y_min = scale_factor * local_y_min;
// float y_max = scale_factor * local_y_max;


 for(int i = 0; i < 12; ++i)
 {
  Game_Panel_Gridline_Edge& e = get_edge(i);

  e.draw_as_horizontal(scene, scale_factor, center_y);

//?  float y_min = scale_factor * j * width + 1;
//?  float y_max = scale_factor * (j + 1) * width - 1;
 }


 //?scene.addLine(center_x, y_min, center_x, y_max
}

