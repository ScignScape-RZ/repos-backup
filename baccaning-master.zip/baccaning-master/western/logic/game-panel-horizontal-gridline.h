
#ifndef GAME_PANEL_HORIZONTAL_GRIDLINE__H
#define GAME_PANEL_HORIZONTAL_GRIDLINE__H

#include "../accessors.h"

#include "game-panel-gridline-edge.h"

class QGraphicsScene;



class Game_Panel_Horizontal_Gridline
{
 int index_y_;

 int local_y_center_;

public:


 Game_Panel_Horizontal_Gridline(int index_y,
   int local_y_center);

 ACCESSORS(int, index_y)
 ACCESSORS(int, local_y_center)

 Game_Panel_Gridline_Edge edges_[12];


 void draw_to_scene(QGraphicsScene& scene,
   float scale_factor, int local_x_min, int local_x_max);


 Game_Panel_Gridline_Edge& get_edge(int index);

};


#endif
