
#ifndef GAME_PANEL_SECTION__H
#define GAME_PANEL_SECTION__H

#include "../accessors.h"

class QGraphicsScene;

class Game_Position;
class Stone_Panel_Display;
class QGraphicsItem;

class Game_Panel_Section
{
 int index_x_;
 int index_y_;

 int local_x_center_;
 int local_y_center_;

public:

 enum class Patterns
 {
  N_A, Dark, Light, Left_Frontier, Right_Frontier,
  Clear, Dark_Cross,
  Light_Cross, Dark_V_Cut, Light_V_Cut,
  Dark_H_Cut, Light_H_Cut, Ramp,

  Midfield_Lighter, Midfield_Darker, Outfield, Palace,

  Bridge_SE,  Bridge_NW, // darker ...
  Bridge_NE,  Bridge_SW, // lighter ...

 };

 enum class Borders
 {
  None, Border_L
 };

 enum class Center_State
 {
  Plain, Marked, Occupied
 };

private:

 Patterns pattern_;
 Borders border_;
 Center_State center_state_;
 Game_Position* center_game_position_;

 QGraphicsItem* highlight_item_;

 QGraphicsItem* bridge_graphics_item_;

public:



 Game_Panel_Section(int index_x, int index_y,
   int local_x_center, int local_y_center,
    Patterns pattern, Borders border, Center_State center_state);

 ACCESSORS(int ,index_x)
 ACCESSORS(int ,index_y)
 ACCESSORS(int ,local_x_center)
 ACCESSORS(int ,local_y_center)
 ACCESSORS(Game_Position* ,center_game_position)

 void draw_to_scene(QGraphicsScene& scene, float scale_factor);

 void check_init_positions();

 void set_doubled_top(Stone_Panel_Display* spd);

 Stone_Panel_Display* get_center_stone();

 void set_center_stone(Stone_Panel_Display* spd);

 int slot_occupied_count_given_center_occupied();

 Game_Position* get_game_position_nw();
 Game_Position* get_game_position_ne();
 Game_Position* get_game_position_sw();
 Game_Position* get_game_position_se();

};


#endif
