

#include "game-panel-vertical-gridline.h"

#include <QGraphicsView>

Game_Panel_Vertical_Gridline::Game_Panel_Vertical_Gridline(int index_x,
  int local_x_center)
 : index_x_(index_x),
   local_x_center_(local_x_center)
{


}

Game_Panel_Gridline_Edge& Game_Panel_Vertical_Gridline::get_edge(int index)
{
 return edges_[index];
}


void Game_Panel_Vertical_Gridline::draw_to_scene(QGraphicsScene& scene,
  float scale_factor, int local_y_min, int local_y_max)
{
 QBrush qbr;
 QPen qpen = QPen(QColor("#ACD0A0"));

 int pen_width = scale_factor > 1.5 ? 3 : 1;

 qpen.setWidth(pen_width);
 //?qpen.setJoinStyle(Qt::RoundJoin);

 int width = 20;

 float center_x = scale_factor * local_x_center_;

 //center_x -= pen_width/2;

// float y_min = scale_factor * local_y_min;
// float y_max = scale_factor * local_y_max;


 for(int j = 0; j < 12; ++j)
 {
  Game_Panel_Gridline_Edge& e = get_edge(j);

  e.draw_as_vertical(scene, scale_factor, center_x);

//?  float y_min = scale_factor * j * width + 1;
//?  float y_max = scale_factor * (j + 1) * width - 1;
 }


 //?scene.addLine(center_x, y_min, center_x, y_max, qpen);
}

