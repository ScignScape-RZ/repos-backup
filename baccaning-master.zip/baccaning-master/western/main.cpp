
//Patient     age gender
//Where does mass come from
//History of  cancer


//screening services


#include <QApplication>
#include <QGraphicsView>

#include <QList>
#include <QDebug>

#include <QMessageBox>

#include <QMenu>

#include <QGraphicsItem>

#include "logic/game-player.h"
#include "logic/game-panel-board.h"
#include "logic/game-panel-section.h"

#include "logic/baccaning-game.h"
#include "logic/baccaning-game-capture.h"


//#include "logic/stone-panel-display.h"
//#include "logic/game-panel-section.h"
//

#include "paraviews/select-stone-dialog.h"
#include "paraviews/players-dialog.h"

#include "paraviews/select-stone-dw.h"
#include "paraviews/movements-dw.h"

#include "game-utils.h"



int main(int argc, char **argv)
{

 QApplication qapp(argc, argv);

 QGraphicsScene scene;

 //
 float scale_factor = 2;
 //float scale_factor = 1;

 Select_Stone_Dialog* dlg = new Select_Stone_Dialog;

 Baccaning_Game* bgame = new Baccaning_Game(dlg);

 Game_Utils utils;

 Game_Panel_Board* gpb = new Game_Panel_Board(bgame, utils);

 bgame->set_board(gpb);

 //? gpb.trace_stone("SQ");

 //?gpb.set_stone_at_intersection(0, 1, "NK");

//? gpb.set_stone_at_position(6, 3, "SP1", Stone_Panel_Display::Direction_Status::Panel_Center);

 //gpb.set_stone_at_intersection(8, 4, "SP1");

//
 gpb->draw_to_scene(scene, scale_factor);



 //?

 QGraphicsView view(&scene);

 view.resize(1000, 600);

 view.setContextMenuPolicy(Qt::CustomContextMenu);


 QMainWindow* mw = new QMainWindow;

 Select_Stone_DW* dw = new Select_Stone_DW;

 Movements_DW* mdw = new Movements_DW;

 mw->setCentralWidget(&view);

 mw->setDockNestingEnabled(true);

 dw->setAllowedAreas(Qt::LeftDockWidgetArea);

 mw->addDockWidget(Qt::LeftDockWidgetArea, dw);

 mdw->setAllowedAreas(Qt::LeftDockWidgetArea);
 mw->addDockWidget(Qt::LeftDockWidgetArea, mdw);

 view.show();

 mw->show();

#ifdef HIDE
 Players_Dialog* players_dlg = new Players_Dialog();

 Game_Player* south_game_player = new Game_Player();
 Game_Player* north_game_player = new Game_Player();

 //Game_Player* current_game_player = south_game_player;


 bgame->set_north_player(north_game_player);
 bgame->set_south_player(south_game_player);
 bgame->set_current_game_player(south_game_player);


 view.connect(dlg, &Select_Stone_Dialog::button_selected, [&gpb](QString key)
  {
   gpb.register_stone_to_add(key);
  });

 view.connect(&view, &QGraphicsView::customContextMenuRequested,
   [&scene, scale_factor, &view, &gpb, dlg, players_dlg, bgame ](const QPoint& p)
 {
  QMenu menu;

  QList<QGraphicsItem*> items = view.items(p);

  void* pV = nullptr;
  for(QGraphicsItem* item : items)
  {
   if(pV = item->data(0).value<void*>())
   {
    break;
   }
  }



  //void* v1 = item->data(1).value<void*>();

  //if(key) Stone_Panel_Display* spd = item->data(0);

  if(pV)
  {
  }
  else if(Stone_Panel_Display* spd = gpb.selected_stone_to_add())
  {
   QString desc = gpb.stone_description(spd);

   QPointF qpf = view.mapToScene(p);
   QPoint logical_point = qpf.toPoint() / scale_factor;

   Stone_Panel_Display::Direction_Status ds;
   Game_Panel_Section* section;
   Game_Panel_Gridline_Intersection* intersection;
   QString posd = gpb.get_position_description(logical_point, section, intersection, ds);

   QAction* place_action = menu.addAction(QString("Place Stone: %1 at %2").arg(desc).arg(posd));
   QAction* clear_action = menu.addAction(QString("Clear Stone: %1").arg(desc));
   view.connect(place_action, &QAction::triggered, [&scene, scale_factor,
     &view, &gpb, dlg, players_dlg, &p, section, intersection, ds, bgame ]
   {
    //QPointF qpf = QPointF(p);
    //QPointF qpf = view.mapToScene(p);
    if(intersection)
    {
     Stone_Panel_Display* spd = gpb.selected_stone_to_add();
     Baccaning_Game_Capture* cap = bgame->check_move_or_capture(spd, intersection);
     if(cap)
     {
      // // i.e., a real capture
      if(cap->captured_stone())
      {
       int ret = QMessageBox::information(nullptr, "Impossible Capture",
         QString("Cannot capture during an initial placement"),
         QMessageBox::Ok);
       gpb.clear_current_selected_stone();
       return;
      }
      else
      {
       gpb.place_current_selected_stone(intersection, ds);
      }
     }
    }
    else if(section)
    {
     Stone_Panel_Display* spd = gpb.selected_stone_to_add();
     Baccaning_Game_Capture* cap = bgame->check_move_or_capture(spd, section);
     if(cap)
     {
      int ret = QMessageBox::information(nullptr, "Impossible Capture",
        QString("Cannot capture during an initial placement"),
        QMessageBox::Ok);
      gpb.clear_current_selected_stone();
      return;
     }
    }

    gpb.draw_to_scene(scene, scale_factor);
    gpb.switch_players();
    //dlg->switch_players();
    dlg->hide();
    //view.update();
   });
   view.connect(clear_action, &QAction::triggered, [&gpb, dlg]
   {
    gpb.clear_current_selected_stone();
   });

  }
  else
  {
   QAction* show_dialog_action = menu.addAction(
     "Show Dialog", [dlg]
   {
    dlg->reset();
    dlg->show();
   });

   QAction* show_players_action = menu.addAction(
     "Show Players", [players_dlg]
   {
    //dlg->reset();
    players_dlg->show();
   });

   QAction* switch_current_player_action = menu.addAction(
     QString("Current Player: %1 (switch)").
     arg(bgame->current_player_is_south()?
       "South" : "North"),
     [players_dlg]
   {

    //dlg->reset();
    //players_dlg->show();
   });

   QAction* switch_referree_mode_action = menu.addAction(
     QString("Referree Mode: %1 (switch)").
     arg(bgame->flags.referee_mode? "On" : "Off"),
     [players_dlg]
   {
    //dlg->reset();
    //players_dlg->show();
   });

  }
  menu.exec(view.mapToGlobal(p));
 });
#endif

// dlg->show();



 return qapp.exec();
}




// kobane
//Latitude: 36° 53' 27.42" N    36 53 27.42N
//Longitude: 38° 21' 12.49" E   38 21 12.49E

//safed
// 32°57'57"N                   32 57 57N
// 35°30'19"E                   35 30 19E

// Distance:	507.8 km (to 4 SF*)
// Initial bearing:	211° 34′ 32″
// Final bearing:	209° 56′ 37″
// Midpoint:	34° 56′ 12″ N, 036° 53′ 43″ E



//derby line
// 45°0'8.02"N. Longitude DMS: 72°6'4.2"W
// 45 0 8.02N  72 6 4.2W

//?   42° 39' 9.2880'  42 39 9.2880
//    73 45 22.4388

// 40°59'12.34"N and a longitude of 75°11'40.65"W
//  40 59 12.34
//  75 11 40.65

// close... Point 2:
//41.05 0 9.0N
// ,
//74.48 45 22.4388W


// good ...

//Point 1:
//36 53 27.42N
// ,
//38 21 12.49E
//Point 2:
//32 58 25N
// ,
//35 29 25E
//Distance:	507.7 km (to 4 SF*)
//Initial bearing:	211° 45′ 40″
//Final bearing:	210° 07′ 14″
//Midpoint:	34° 56′ 26″ N, 036° 53′ 16″ E
//... hide map


// NA
//Point 1:
//45 0 8.02N
// ,
//72 6 4.2W
//Point 2:
//40 63 89N
// ,
//75 16 72.9W
//Distance:	507.6 km (to 4 SF*)
//Initial bearing:	211° 45′ 40″
//Final bearing:	209° 35′ 07″
//Midpoint:	43° 02′ 58″ N, 073° 44′ 42″ W



