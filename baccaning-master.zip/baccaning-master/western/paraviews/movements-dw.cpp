
#include "movements-dw.h"

//#include "clg-db-antemodel.h";

#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QButtonGroup>

#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>
#include <QDebug>

#include <QPlainTextEdit>
#include <QTextStream>

#include <QTableWidget>

#include <QMessageBox>

//#include <QNetworkAccessManager>
//#include <QNetworkRequest>
//#include <QNetworkReply>
#include <QUrlQuery>

#include <QHeaderView>
#include <QGraphicsTextItem>
#include <QListWidget>




#include "game-panel-colors.h"

#define SVG_BASE_PATH "/extension/medusa/baccaning/Images/"


Movements_DW::Movements_DW()
{

 main_frame_ = new QFrame(this);
 main_layout_ = new QVBoxLayout;

 main_text_edit_ = new QTextEdit(main_frame_);

 main_layout_->addWidget(main_text_edit_);

 main_frame_->setLayout(main_layout_);

 setWidget(main_frame_);

}

