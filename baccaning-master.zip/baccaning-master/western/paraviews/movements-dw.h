
#ifndef MOVEMENTS_DW__H
#define MOVEMENTS_DW__H


#include <QString>
#include <QMainWindow>

#include <QTextEdit>
//?#include <QWebView>

//#include <QWebEngineView>
#include <QLabel>
#include <QPushButton>

#include <QDockWidget>

#include <QDialog>

#include <QComboBox>

#include "accessors.h"

//#include "flags.h"


//#include "stone-graphic/game-stone-graphic-group-stones.h"
//#include "stone-graphic/game-stone-graphic-d2.h"
//#include "stone-graphic/game-stone-graphic-d3.h"
//#include "stone-graphic/game-stone-graphic-d4.h"
//#include "stone-graphic/game-stone-graphic-d5.h"
//#include "stone-graphic/game-stone-graphic-c6.h"
//#include "stone-graphic/game-stone-graphic-d7.h"
//#include "stone-graphic/game-stone-graphic-d8.h"
//#include "stone-graphic/game-stone-graphic-c8.h"
//#include "stone-graphic/game-stone-graphic-d12.h"
//#include "stone-graphic/game-stone-graphic-d14.h"
//#include "stone-graphic/game-stone-graphic-c20.h"
//#include "stone-graphic/game-stone-graphic-c60.h"
//#include "stone-graphic/game-stone-graphic-d80.h"


//#include "incident-form-dialog.h"

class QPushButton;
class QTextEdit;
class QPlainTextEdit;
class QLineEdit;
class QTabWidget;
class QDialogButtonBox;
class QVBoxLayout;
class QHBoxLayout;
class QCheckBox;
class QFormLayout;
class QSplitter;
class QGridLayout;
class QListWidget;
class QTableWidget;
class QScrollArea;
class QGroupBox;
class QTableWidgetItem;


#include <QGraphicsScene>
#include <QGraphicsView>
#include <QFrame>
#include <QStackedWidget>
#include <QComboBox>

//RZNS_(QWN)
//namespace RZ{ namespace CTQ{


class Game_Player;


class Movements_DW : public QDockWidget
{
 Q_OBJECT


 QFrame* main_frame_;

 QVBoxLayout* main_layout_;

 QTextEdit* main_text_edit_;

public:

 Movements_DW();


};

//} } //_RZNS(CTQ)


#endif
