
#ifndef SELECT_STONE_DW__H
#define SELECT_STONE_DW__H


#include <QString>
#include <QMainWindow>

#include <QTextEdit>
//?#include <QWebView>

//#include <QWebEngineView>
#include <QLabel>
#include <QPushButton>

#include <QDockWidget>

#include <QDialog>

#include <QComboBox>

#include "accessors.h"

//#include "flags.h"


//#include "stone-graphic/game-stone-graphic-group-stones.h"
//#include "stone-graphic/game-stone-graphic-d2.h"
//#include "stone-graphic/game-stone-graphic-d3.h"
//#include "stone-graphic/game-stone-graphic-d4.h"
//#include "stone-graphic/game-stone-graphic-d5.h"
//#include "stone-graphic/game-stone-graphic-c6.h"
//#include "stone-graphic/game-stone-graphic-d7.h"
//#include "stone-graphic/game-stone-graphic-d8.h"
//#include "stone-graphic/game-stone-graphic-c8.h"
//#include "stone-graphic/game-stone-graphic-d12.h"
//#include "stone-graphic/game-stone-graphic-d14.h"
//#include "stone-graphic/game-stone-graphic-c20.h"
//#include "stone-graphic/game-stone-graphic-c60.h"
//#include "stone-graphic/game-stone-graphic-d80.h"


//#include "incident-form-dialog.h"

class QPushButton;
class QTextEdit;
class QPlainTextEdit;
class QLineEdit;
class QTabWidget;
class QDialogButtonBox;
class QVBoxLayout;
class QHBoxLayout;
class QCheckBox;
class QFormLayout;
class QSplitter;
class QGridLayout;
class QListWidget;
class QTableWidget;
class QScrollArea;
class QGroupBox;
class QTableWidgetItem;


#include <QGraphicsScene>
#include <QGraphicsView>
#include <QFrame>
#include <QStackedWidget>
#include <QComboBox>

//RZNS_(QWN)
//namespace RZ{ namespace CTQ{


class Game_Player;


class Select_Stone_DW : public QDockWidget
{
 Q_OBJECT

 float scale_factor_;
 float scratch_scale_factor_;

// QDialogButtonBox* button_box_;

 QFrame* main_frame_;

 QPushButton* button_ok_;
 QPushButton* button_cancel_;

 QHBoxLayout* buttons_layout_;

// QPushButton* button_proceed_;

// QPushButton* button_select_;

 //QGraphicsView* preview_view_;

 QVBoxLayout* main_layout_;

 QFrame* south_frame_;
 QFrame* north_frame_;

 QGridLayout* south_layout_;
 QGridLayout* north_layout_;

 QButtonGroup* south_buttons_;
 QButtonGroup* north_buttons_;


 QPushButton* south_dummy_;
 QPushButton* south_king_;
 QPushButton* south_queen_;
 QPushButton* south_rook_;
 QPushButton* south_bishop_;
 QPushButton* south_knight_;
 QPushButton* south_pawn_;

 QPushButton* north_dummy_;
 QPushButton* north_king_;
 QPushButton* north_queen_;
 QPushButton* north_rook_;
 QPushButton* north_bishop_;
 QPushButton* north_knight_;
 QPushButton* north_pawn_;

 QPushButton* selected_button_;


// QPen qpen_north_dark_;
// QPen qpen_south_dark_;
// QPen qpen_north_light_;
// QPen qpen_south_light_;

// QBrush qbrush_north_dark_;
// QBrush qbrush_south_dark_;
// QBrush qbrush_north_light_;
// QBrush qbrush_south_light_;

 QStackedWidget* buttons_stacked_widget_;

 QMap<QPushButton*, QString> keys_;

 QComboBox* player_;

 void init_stone_button(QButtonGroup* button_group, QPushButton* button, QString key, QString file);

 void make_dummy_button(QButtonGroup* button_group, QPushButton*& button);

signals:

 void button_selected(QString key);

public:

 Select_Stone_DW();

 void set_player_south();
 void set_player_north();

 void switch_players();

 void reset();

 void add_row_stretch(QGridLayout* gl);
 void add_column_stretch(QGridLayout* gl);



 // void graphic_selected(Game_Stone_Graphic* graphic);

 // not used ...
 //void handle_scene_selection_changed();

 //?void proceed();

};

//} } //_RZNS(CTQ)


#endif
