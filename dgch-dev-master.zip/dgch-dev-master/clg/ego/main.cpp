
#include <QFile>
#include <QDir>
#include <QFileInfoList>
#include <QCoreApplication>

#include <QRegularExpression>


#include <iostream>

void replace(QString& contents, QString tag)
{
 contents.replace(QString("<%1>").arg(tag), QString("`<%1>").arg(tag));
// contents.replace(QString("</%1>.").arg(tag), QString("</%1>`").arg(tag));
 contents.replace(QString("<%1 ").arg(tag), QString("`<%1 ").arg(tag));
}

void replace(QString& contents)
{
}

int main(int argc, char* argv [])
{
 QCoreApplication app(argc, argv);
 QDir dir;
 dir.setFilter(QDir::Files | QDir::Hidden | QDir::NoSymLinks);
 dir.setSorting(QDir::Size | QDir::Reversed);

 QFileInfoList qfil = dir.entryInfoList();

 QListIterator<QFileInfo> it(qfil);

 while(it.hasNext())
 {
  QFileInfo qfi = it.next();
  if(qfi.suffix() == "htm")
  {
   QString name = dir.absoluteFilePath(qfi.completeBaseName() + ".ngm");
   QFile qf_in(qfi.absoluteFilePath());
   if(qf_in.open(QFile::ReadOnly))
   {
    QString contents = qf_in.readAll();
    replace(contents);
    QFile qf_out(name);
    if(qf_out.open(QFile::WriteOnly))
    {
     qf_out.write(contents.toLatin1());
     qf_out.close();
     qf_out.flush();
    }
   }

  }
 }
 return 0;
}
