
#ifndef CLIENT__H
#define CLIENT__H

#include <QObject>
#include <QSharedPointer>

#include "rep_qrsmsg_replica.h"

class Client : public QObject
{
    Q_OBJECT
public:
    Client(QSharedPointer<QRSMsgReplica> ptr);
    ~Client();

    void send_message(QString msg);

    void init_connections();// function connect signals and slots of source and client

Q_SIGNALS:
    void echo_message(QString);// this signal is connected with server_slot(..) on the source object and echoes back switch state received from source
    void request_send_message(QString);// this signal is connected with server_slot(..) on the source object and echoes back switch state received from source
    void request_show_message();
    void remote_channel_established();

public Q_SLOTS:
    void receive_message_slot(QString); // slot to receive source state
    void handle_ready();
    void handle_current_state_code_changed(quint8);

private:
    QString client_message_; // holds received server switch state
    QSharedPointer<QRSMsgReplica> reptr;// holds reference to replica

 };

#endif
