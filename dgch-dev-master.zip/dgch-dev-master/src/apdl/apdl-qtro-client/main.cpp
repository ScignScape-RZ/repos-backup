
#include <QtRemoteObjects>

#include <QMainWindow>
#include <QApplication>

#include <QHBoxLayout>
#include <QPushButton>

#include <QLabel>
#include <QLineEdit>

#include <QFrame>
#include <QCoreApplication>

#include "client.h"

#include <QApplication>

#include <QLocalSocket>
#include <QNetworkInterface>

#include <QString>
#include <QDataStream>

#include <QMessageBox>

void run(QString msg)
{
 QSharedPointer<QRSMsgReplica> ptr;

 QRemoteObjectNode* repNode = new QRemoteObjectNode; // create remote object node
 repNode->connectToNode(QUrl(QStringLiteral("local:replica"))); // connect with remote host node

 ptr.reset(repNode->acquire<QRSMsgReplica>()); // acquire replica of source from host node

 Client* rswitch = new Client(ptr); // create client switch object and pass reference of replica to it

 QObject::connect(rswitch, &Client::remote_channel_established, [msg, rswitch]
 {
  rswitch->send_message(msg);
 });
}


void run_socket(QLineEdit* le)
{
 QLocalSocket* sock;

 sock = new QLocalSocket;

 QObject::connect(sock, &QLocalSocket::readyRead, [sock, le]()
 {
  //QDataStream qds;
  QByteArray qba = sock->readAll();

  qDebug() << "CLIENT: " << qba;

  quint64 code;

  QDataStream out(&qba, QIODevice::ReadOnly);
  out >> code;

  if(code == 12345678901234)
  {
   ++code;
   QByteArray block;
   QDataStream out(&block, QIODevice::WriteOnly);
   out << code;
   sock->write(block);
   QString msg = le->text();
   run(msg);
  }
  sock->disconnectFromServer();

 });

 QObject::connect(sock, &QLocalSocket::connected, [sock]()
 {
  qDebug() << "CLIENT: connected";
 });

 QByteArray block;
 QDataStream out(&block, QIODevice::WriteOnly);

 out << "KOKO";
 sock->write(block);

 sock->setServerName("QLS");

 sock->connectToServer();
}

int main(int argc, char *argv[])
{
 QApplication qapp(argc, argv);

 QMainWindow* mw = new QMainWindow;

 QLineEdit* le = new QLineEdit(mw);
 le->setPlaceholderText("Enter Message ...");
 QPushButton* pb = new QPushButton("Send", mw);

 QObject::connect(pb, &QPushButton::clicked, [le]
 {
  run_socket(le);
 });

 QPushButton* cb = new QPushButton("Close", mw);

 QHBoxLayout* hb = new QHBoxLayout;
 QVBoxLayout* vb = new QVBoxLayout;

 QHBoxLayout* cbhb = new QHBoxLayout;

 hb->addWidget(le);
 hb->addWidget(pb);
 vb->addLayout(hb);

 cbhb->addStretch();
 cbhb->addWidget(cb);
 cbhb->addStretch();

 vb->addLayout(cbhb);

 QFrame* fr = new QFrame;

 fr->setLayout(vb);

 mw->setCentralWidget(fr);

 mw->show();


 return qapp.exec();

}

