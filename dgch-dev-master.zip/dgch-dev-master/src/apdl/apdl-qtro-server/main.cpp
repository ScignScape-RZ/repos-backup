
#include <QtRemoteObjects>

#include <QMainWindow>
#include <QApplication>

#include <QHBoxLayout>
#include <QPushButton>
#include <QLabel>
#include <QFrame>

#include <QCoreApplication>

#include <QString>

#include "qrsmsg.h"

#include <QApplication>

#include <QLocalServer>
#include <QLocalSocket>
#include <QNetworkInterface>

#include <QString>
#include <QDataStream>

#include <QMessageBox>



void run_server(QLabel* lb)
{
 QRSMsg* src_qrsmsg = new QRSMsg; // create simple switch

 QObject::connect(src_qrsmsg, &QRSMsg::show_message_requested,
   [lb](QString msg)
 {
  qDebug() << "Lambda msg " <<  msg;
  //QMessageBox::information(nullptr, "Lambda msg ", msg);
  lb->setText(msg);
 });

 QRemoteObjectHost* src_node = new QRemoteObjectHost(QUrl(QStringLiteral("local:replica"))); // create host node without Regsitry
 src_node->enableRemoting(src_qrsmsg); // enable remoting/Sharing

}




int main(int argc, char *argv[])
{
 QApplication qapp(argc, argv);

 QMainWindow* mw = new QMainWindow;

 QLabel* lb = new QLabel("XXaaa", mw);
 QPushButton* pb = new QPushButton("XX", mw);

 QPushButton* cb = new QPushButton("Close", mw);

 QHBoxLayout* hb = new QHBoxLayout;
 QVBoxLayout* vb = new QVBoxLayout;

 QHBoxLayout* cbhb = new QHBoxLayout;

 hb->addWidget(lb);
 hb->addWidget(pb);

 vb->addLayout(hb);

 cbhb->addStretch();
 cbhb->addWidget(cb);
 cbhb->addStretch();

 vb->addLayout(cbhb);

 QFrame* fr = new QFrame;

 fr->setLayout(vb);

 mw->setCentralWidget(fr);

 mw->show();


 QLocalServer* serv;

 serv = new QLocalServer;

 QString ipAddress = QHostAddress(QHostAddress::LocalHost).toString();
 int port = 9753;
 if (!serv->listen("QLS"))//QHostAddress(ipAddress), port))
 {
  qDebug() << "Unable to start the server: " << serv->errorString();
  return 0;
 }

 qDebug() << QString("The server is running on\n\nIP: %1\nport: %2\n\n"
                             "Run the Fortune Client example now.")
                          .arg(ipAddress).arg(0);

 QLocalServer::connect(serv, &QLocalServer::newConnection, [serv, lb]()
 {
  QLocalSocket *sock = serv->nextPendingConnection();
  qDebug() <<  "SERVER: next";

  QLocalSocket::connect(sock, &QLocalSocket::readyRead, [sock, lb]
  {
   qDebug() <<  "SERVER: RR";

   QByteArray qba = sock->readAll();
   qDebug() <<  "SERVER: " << qba;

   quint64 code;

   QDataStream out(&qba, QIODevice::ReadOnly);
   out >> code;

   if(code == 12345678901235)
   {
    run_server(lb);
   }
  });

  QByteArray block;
  QDataStream out(&block, QIODevice::WriteOnly);

  quint64 code = 12345678901234;
  out << code;
  sock->write(block);
 //? sock->disconnectFromHost();

 });

 return qapp.exec();
}

