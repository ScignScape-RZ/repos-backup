
#include "qrsmsg.h"

#include <QMessageBox>

// constructor
QRSMsg::QRSMsg(QObject *parent) : QRSMsgSimpleSource(parent)
{
    set_current_state_code_(1);

    qDebug() << "Source Node Started";
}

//destructor
QRSMsg::~QRSMsg()
{
}

void QRSMsg::server_slot(QString msg)
{
    qDebug() << "1) Replica message is " << msg; // print switch state echoed back by client
    //?set_current_message_(msg + "_X");
    nonr_message_ = msg;
}

void QRSMsg::update_nonr_message(QString msg)
{
 qDebug() << "NONR message is " << msg;
 nonr_message_ = msg;
}

void QRSMsg::show_nonr_message()
{
 //?QMessageBox::information(nullptr, "SERVER: NONR", nonr_message_);
 qDebug() << " ... NONR message is " << nonr_message_;

 Q_EMIT show_message_requested(nonr_message_);

}



