
#ifndef QRSMSG__H
#define QRSMSG__H

#include "rep_qrsmsg_source.h"

#include <QString>

class QRSMsg : public QRSMsgSimpleSource
{
    Q_OBJECT
public:
    QRSMsg(QObject *parent = nullptr);
    ~QRSMsg();

    virtual void server_slot(QString msg);

    qroslot void update_nonr_message(QString msg);
    qroslot void show_nonr_message();


Q_SIGNALS:
    void ready();

    void show_message_requested(QString msg);

public Q_SLOTS:

    //?

private:
    QString nonr_message_;

};

#endif
