
#include <QApplication>
#include <QFileDialog>
#include <QDebug>


#include "textio.h"

#include "apdlns.h"

#include "apdl-refi/apdl-refi.h"

#include "apdl-refi/apdl-basic-application.h"
#include "apdl-refi/deployment/apdl-repository-info.h"

#include "base32.h"

//
USING_APDLNS(RefI)
USING_APDLNS(TextIO)
USING_APDLNS(Base32)


int main(int argc, char *argv[])
{
 APDL_Refi ari;

 ari.init_basic_application_info();
 ari.init_repository_info();

 ari.basic_application_info()->set_name("test");
 ari.repository_info()->set_url(QUrl("www.example.com"));

 QByteArray qba;
 ari.supply_data(qba);

 qDebug() << "qba: " << qba;

 QString b3;

 encode_qba(qba, b3);

 save_file("apdl.txt", b3);

 QByteArray qba1;

 decode_qstring(b3, qba1);

 qDebug() << "qba1: " << qba1;

 APDL_Refi ari1;

 ari1.absorb_data(qba1);

 qDebug() << "test1: " << ari1.basic_application_info()->name();
 qDebug() << "test1a: " << ari1.repository_info()->url();

 APDL_Refi ari2;

 ari2.absorb_data(qba);

 qDebug() << "test2: " << ari2.basic_application_info()->name();
 qDebug() << "test2a: " << ari2.repository_info()->url();

 return 0;
}

int main1(int argc, char *argv[])
{
 QApplication qapp(argc, argv);

 QString path = QFileDialog::getOpenFileName(nullptr,
   "Open APDL File");

 qDebug() << "Path: " << path;

 QString text = load_file(path);

 qDebug() << "File text: \n========\n" << text
   << "\n--------\n";

 return qapp.exec();


}
