
#ifndef BASE32__H
#define BASE32__H

#include "sens.h"

#include <QFile>
#include <QTextStream>


SENS_(Base32)

extern void encode_qba(const QByteArray& qba, QString& result);
extern void decode_qstring(QString text, QByteArray& result);

_SENS(Base32)


#endif

