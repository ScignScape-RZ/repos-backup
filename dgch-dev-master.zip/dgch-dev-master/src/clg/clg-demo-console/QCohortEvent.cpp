
#include "QCohortEvent.h"

QCohortEvent::QCohortEvent()
 : year_(0),month_(0),day_(0),hour_(0),minute_(0)
{

}




