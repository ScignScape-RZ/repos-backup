
#include "QCohortGround.h"

QCohortGround::QCohortGround()
 : QObject(nullptr)
{

}

QCohortGround::QCohortGround(const QCohortGround& rhs)
 : QObject(nullptr)
{

}
