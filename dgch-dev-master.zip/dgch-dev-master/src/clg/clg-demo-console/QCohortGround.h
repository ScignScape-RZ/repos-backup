
#ifndef QCOHORTGROUND__H
#define QCOHORTGROUND__H

#include <QString>

#include <QObject>

class QCohortGround : public QObject
{


public:

 QCohortGround();
 QCohortGround(const QCohortGround& rhs);


};




#endif

