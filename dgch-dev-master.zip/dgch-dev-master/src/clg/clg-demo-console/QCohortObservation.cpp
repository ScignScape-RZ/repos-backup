
#include "QCohortObservation.h"

QCohortObservation::QCohortObservation()
 : QObject(nullptr)
{

}

QCohortObservation::QCohortObservation(const QCohortObservation& rhs)
 : QObject(nullptr)
{

}
