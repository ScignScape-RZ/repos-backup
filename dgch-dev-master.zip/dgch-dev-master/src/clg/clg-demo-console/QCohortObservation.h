
#ifndef QCOHORTOBSERVATION__H
#define QCOHORTOBSERVATION__H

#include <QString>

#include <QObject>

class QCohortObservation : public QObject
{

public:

 QCohortObservation();

 QCohortObservation(const QCohortObservation& rhs);


};




#endif

