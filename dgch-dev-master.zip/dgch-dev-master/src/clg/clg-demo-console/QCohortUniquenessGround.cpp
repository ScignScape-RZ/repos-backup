
#include "QCohortUniquenessGround.h"

QCohortUniquenessGround::QCohortUniquenessGround()
 : QObject(nullptr)
{

}

QCohortUniquenessGround::QCohortUniquenessGround(const QCohortUniquenessGround& rhs)
 : QObject(nullptr)
{

}
