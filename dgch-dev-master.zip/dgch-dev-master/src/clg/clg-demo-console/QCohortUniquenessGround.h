
#ifndef QCOHORTUNQIUENESSGROUND__H
#define QCOHORTUNQIUENESSGROUND__H

#include <QString>

#include <QObject>

class QCohortUniquenessGround : public QObject
{

public:

 QCohortUniquenessGround();

 QCohortUniquenessGround(const QCohortUniquenessGround& rhs);


};




#endif

