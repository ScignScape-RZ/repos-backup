
#include <QMainWindow>
#include <QApplication>
#include <QTabWidget>


#include "endo-apdl-dialog/endo-apdl-dialog.h"

int main(int argc, char *argv[])
{
 QApplication a(argc, argv);
 Endo_Apdl_Dialog* dlg = new Endo_Apdl_Dialog;

 return a.exec();


}
