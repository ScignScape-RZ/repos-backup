
#ifndef ENDO_APDL_DIALOG__H
#define ENDO_APDL_DIALOG__H

#include <QDialogButtonBox>
#include <QVBoxLayout>
#include <QDialog>

#include <QTabWidget>


class Endo_Apdl_Dialog : public QDialog
{
 Q_OBJECT

 //Fore_Geometric1D_Panel fore_panel_;
 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QVBoxLayout* main_layout_;

 QTabWidget* qtw_;

public:


 Endo_Apdl_Dialog(QWidget* parent = nullptr);
 ~Endo_Apdl_Dialog();

};

#endif
