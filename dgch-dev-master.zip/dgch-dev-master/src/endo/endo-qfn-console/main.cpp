
#include <QMainWindow>
#include <QApplication>
#include <QTabWidget>


#include "endo-qfn/endo-qfn-collections.h"

int main(int argc, char *argv[])
{
 QApplication a(argc, argv);

 return a.exec();


}
