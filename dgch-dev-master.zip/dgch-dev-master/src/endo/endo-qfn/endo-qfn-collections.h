
#include <QList>


#include "syns.h"

SYNS_(Endo)

class Arr1D
{

};


_SYNS(Endo)
