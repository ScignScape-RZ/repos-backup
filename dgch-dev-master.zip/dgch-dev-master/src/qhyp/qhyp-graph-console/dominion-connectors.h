
DOMINION_MACRO(Run_Call_Sequence, "run-call-sequence")
DOMINION_MACRO(Run_Call_Entry, "run-call-entry")
