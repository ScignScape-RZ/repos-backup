
#include <QMainWindow>
#include <QApplication>
#include <QTabWidget>
#include <QDebug>

#include "qhyp-graph/qy-hyper-node.h"
#include "qhyp-graph/qy-hyper-edge.h"
#include "qhyp-graph/qy-ptr.h"

#include "qhyp-graph/qy-node.h"


USING_QYNS(Graph)

#include "_dominion.h"


int main(int argc, char *argv[])
{
// QApplication a(argc, argv);
// return a.exec();

 Connections cs;

 qy_ptr<QString> qs1 = new QString("Left");
 qy_ptr<QString> qs2 = new QString("Right");

 qy_ptr<QString> qs3 = new QString("Mid");


 QY_Hyper_Node hn1 = new _QY_Hyper_Node(qs1);
 QY_Hyper_Node hn2 = new _QY_Hyper_Node(qs2);
// QY_Hyper_Node hn3 = new _QY_Hyper_Node(qs3);

// *hn1 << hn3 >> hn2;

 *hn1 << cs.Run_Call_Entry >> hn2;

 QY_Hyper_Node hn3 = cs.Run_Call_Entry(hn1);





 //?hn->set_raw_vertex(qs);
 //?

 qy_ptr<QString> qs3a = hn3->as<QString>();

 qDebug() << *qs3a;




}
