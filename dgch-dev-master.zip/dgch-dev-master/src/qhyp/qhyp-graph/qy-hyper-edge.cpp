
#include "qy-hyper-edge.h"

USING_QYNS(Graph)


_QY_Hyper_Edge::_QY_Hyper_Edge()
{

}

QYNS_(Graph)
_QY_Hyper_Edge& operator>>(_QY_Hyper_Edge& edge, QY_Hyper_Node hn)
{
 edge.set_target(hn);
 return edge;
}
_QYNS(Graph)




