
#ifndef QY_HYPER_EDGE__H
#define QY_HYPER_EDGE__H


#include <QList>

#include "qyns.h"

#include "accessors.h"

#include "qy-ptr.h"

#include "qy-hyper-graph.h"

QYNS_(Graph)

class _QY_Hyper_Node;

class _QY_Hyper_Edge
{
 QY_Hyper_Node source_;
 QY_Hyper_Node target_;
 QY_Hyper_Node annode_;

public:

 _QY_Hyper_Edge();

 ACCESSORS(QY_Hyper_Node ,source)
 ACCESSORS(QY_Hyper_Node ,target)
 ACCESSORS(QY_Hyper_Node ,annode)

};

_QY_Hyper_Edge& operator>>(_QY_Hyper_Edge& edge, QY_Hyper_Node hn);


_QYNS(Graph)

#endif
