
#ifndef QY_HYPER_GRAPH__H
#define QY_HYPER_GRAPH__H


#include <QList>

#include "qyns.h"

#include "accessors.h"
#include "qy-ptr.h"

#include <QMap>
#include <QList>


QYNS_(Graph)

class _QY_Node;
class _QY_Hyper_Edge;

typedef qy_ptr<_QY_Node> QY_Node;

typedef qy_ptr<const _QY_Node> QY_Const_Node;

class _QY_Hyper_Node;
typedef qy_ptr<_QY_Hyper_Node> QY_Hyper_Node;

typedef QList<QY_Hyper_Node> QY_Hyper_Node_List;

typedef QList<QY_Node> QY_Node_List;

typedef qy_ptr<quint64> Qy_Any;

typedef qy_ptr<_QY_Hyper_Edge> QY_Hyper_Edge;
typedef QList<QY_Hyper_Edge> QY_Hyper_Edge_List;


_QYNS(Graph)

#endif
