
#include "qy-hyper-node.h"
#include "qy-hyper-edge.h"

#include "qy-node.h"


USING_QYNS(Graph)


_QY_Hyper_Node::_QY_Hyper_Node()
{

}

QY_Node _QY_Hyper_Node::get_first_node()
{
 if(nodes_.isEmpty())
 {
  return QY_Node(vertex_);
 }
 else
 {
  return nodes_.first();
 }
}


Qy_Any _QY_Hyper_Node::get_first_vertex()
{
 if(nodes_.isEmpty())
 {
  return vertex_;
 }
 else
 {
  return nodes_.first()->vertex();
 }
}


void _QY_Hyper_Node::add_edge(QY_Hyper_Edge edge)
{
 edge_map_[edge->annode()->get_first_node()].push_back(edge);
}


void _QY_Hyper_Node::set_head_vertex(quint64* ptr)
{
 QY_Node n = new _QY_Node(ptr);
 add_node(n);
}

void _QY_Hyper_Node::add_node(QY_Node n)
{
 nodes_.push_back(n);
}

QY_Hyper_Node _QY_Hyper_Node::find_single_target(QY_Node ann)
{
 if(edge_map_.contains(ann))
 {
  QList<QY_Hyper_Edge>& ql = edge_map_[ann];
  if(ql.isEmpty())
  {
   return nullptr;
  }
  return ql.first()->target();
 }
 return nullptr;
}

//void _QY_Hyper_Node::set_head_vertex(const quint64* ptr)
//{
// QY_Node n = new _QY_Node(const_cast<quint64*>(ptr));
// nodes_.push_back(n);
//}

QYNS_(Graph)
_QY_Hyper_Edge& operator<< (_QY_Hyper_Node& source, QY_Hyper_Node mid)
{
 QY_Hyper_Edge result = new _QY_Hyper_Edge;

 result->set_source(&source);
 result->set_annode(mid);

 source.add_edge(result);

 return *result;
}


_QY_Hyper_Edge& operator_sr_ (_QY_Hyper_Node& source,
  const _QY_Node& connector, TRUE_Type pass)
{
 QY_Hyper_Node mid = new _QY_Hyper_Node;
 mid->add_node(&connector);
 return source << mid;
}

_QYNS(Graph)
