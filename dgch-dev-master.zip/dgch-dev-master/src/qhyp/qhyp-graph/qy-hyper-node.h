
#ifndef QY_HYPER_NODE__H
#define QY_HYPER_NODE__H


#include <QList>

#include "qyns.h"

#include "accessors.h"
#include "qy-ptr.h"

#include <QMap>
#include <QList>


#include "qy-hyper-graph.h"

QYNS_(Graph)

class _QY_Hyper_Node
{
 Qy_Any vertex_;

 QY_Node proxy_;

 QVector<QY_Node> nodes_;

 QMap<QY_Node, QY_Hyper_Edge_List> edge_map_;

 typedef QMap<QY_Node, QY_Hyper_Node_List> edge_map_type;


public:

 ACCESSORS(QY_Node ,proxy)
 ACCESSORS(Qy_Any ,vertex)

 _QY_Hyper_Node();

 template<typename T>
 _QY_Hyper_Node(qy_ptr<T> vx)
 {
  vertex_.take_ptr(vx);
 }

 void set_raw_vertex(void* v)
 {
  quint64* vv = reinterpret_cast<quint64*>(v);
  vertex_.set_pointer_value(vv);
 }

 template<typename T>
 qy_ptr<T> as()
 {
  return vertex_.ptr_cast<T>();
 }

 void add_edge(QY_Hyper_Edge edge);
 void add_node(QY_Node n);

 Qy_Any get_first_vertex();
 QY_Node get_first_node();

 template <typename T>
 void set_head_vertex(T* ptr)
 {
  set_head_vertex((quint64*) ptr);
 }

 void set_head_vertex(quint64* ptr);

// template <typename T>
// QY_Hyper_Node find_single_target(const T* ptr)
// {
//  return find_single_target((const quint64*) ptr);
// }

 QY_Hyper_Node find_single_target(QY_Node ann);

// template <typename T>
// void set_head_vertex(const T* ptr)
// {
//  set_head_vertex((const quint64*) ptr);
// }
// void set_head_vertex(const quint64* ptr);

};

_QY_Hyper_Edge& operator<< (_QY_Hyper_Node& source, QY_Hyper_Node mid);


struct TRUE_Type{};
struct FALSE_Type{};

template<typename T>
struct Is_Dominion_Connector
{
 typedef FALSE_Type Type;
};


_QY_Hyper_Edge& operator_sr_ (_QY_Hyper_Node& source,
  const _QY_Node& connector, TRUE_Type pass);
//{
// QY_Hyper_Node mid = new _QY_Hyper_Node;
// mid->add_node(&connector);
// return source << mid;
//}

template<typename CONNECTOR_Type>
_QY_Hyper_Edge& operator_sr (_QY_Hyper_Node& source,
  const CONNECTOR_Type& connector, TRUE_Type pass)
{
 return operator_sr_(source, connector.node_ref(), pass);
}




template<typename CONNECTOR_Type,
  typename BOOL_Type = typename Is_Dominion_Connector<CONNECTOR_Type>::Type >
_QY_Hyper_Edge& operator<< (_QY_Hyper_Node& source,
  const CONNECTOR_Type& connector)
{
 return operator_sr(source, connector, BOOL_Type());
}

template<typename CONNECTOR_Type>
_QY_Hyper_Edge& operator<< (_QY_Hyper_Node& source,
  _QY_Node& mid)
{
 return operator_sr_(source, mid, TRUE_Type());
}




_QYNS(Graph)

#endif
