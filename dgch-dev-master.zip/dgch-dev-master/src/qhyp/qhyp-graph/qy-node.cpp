
#include "qy-node.h"

USING_QYNS(Graph)

_QY_Node::_QY_Node()
  :  vertex_(nullptr)
{

}

_QY_Node::_QY_Node(quint64* val)
  :  vertex_(val)
{

}


