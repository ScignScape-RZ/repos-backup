
#ifndef QY_NODE__H
#define QY_NODE__H


#include <QList>

#include "qyns.h"

#include "qy-ptr.h"

#include "accessors.h"

QYNS_(Graph)

typedef qy_ptr<quint64> Qy_Any;

class _QY_Node
{
 Qy_Any vertex_;

public:

 _QY_Node();
 _QY_Node(quint64* val);

 _QY_Node(const quint64* val)
   :  _QY_Node(const_cast<quint64*>(val))
 {

 }

 template<typename T>
 _QY_Node(T* val)
   :  _QY_Node((quint64*) val)
 {
 }

 template<typename T>
 _QY_Node(const T* val)
   :  _QY_Node((quint64*) val)
 {
 }

 template<typename T>
 qy_ptr<T> as()
 {
  return vertex_.ptr_cast<T>();
 }

 template<typename T>
 qy_ptr<T> as() const
 {
  return vertex_.ptr_cast<T>();
 }

 template<typename T>
 T* pRestore()
 {
  return as<T>().raw_pointer();
 }

 template<typename T>
 T* pRestore() const
 {
  return as<T>().raw_pointer();
 }


 ACCESSORS(Qy_Any ,vertex)

 bool operator ==(const _QY_Node& rhs)
 {
  return vertex_ == rhs.vertex_;
 }



};


_QYNS(Graph)

#endif
