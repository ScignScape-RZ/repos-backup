
#ifndef QY_PTR__H
#define QY_PTR__H


#include <memory>

#undef NO_QYPTR
#define QY_DEBUG

#ifdef NO_QYPTR

#include <QSharedPointer>

#define QYPTR_PTR_DEBUG(type ,ptr)
#define QYPTR_EVALUATE_DEBUG(type, name ,ptr)
#define QYPTR_PTR_B_DEBUG(type ,ptr)
#define QYPTR_PTR_BUNDLE_DEBUG(type ,ptr)
#define QYPTR_DEBUG_NOOP


template<typename T>
struct get_pointer
{
 typedef T* type;
};

template<typename T>
using qy_ptr = typename get_pointer<T>::type;


#else // NO_QYPTR

#ifdef QY_DEBUG
#define QYPTR_EVALUATE_DEBUG(type, name ,ptr) \
 const type& name = *ptr;
#define QYPTR_DEBUG(type ,ptr) \
 QYPTR_EVALUATE_DEBUG(type, _##ptr, ptr)
#define QYPTR_B_DEBUG(type ,ptr) \
 QYPTR_EVALUATE_DEBUG(type, _##ptr, b.ptr)
#define QYPTR_BUNDLE_DEBUG(type ,ptr) \
 QYPTR_EVALUATE_DEBUG(type, _##ptr, b.ptr)
#define QYPTR_DEBUG_NOOP int _QYPTR_DEBUG_NOOP_ = 0;
#else
#define QYPTR_DEBUG(type ,ptr)
#define QYPTR_EVALUATE_DEBUG(type, name ,ptr)
#define QYPTR_B_DEBUG(type ,ptr)
#define QYPTR_BUNDLE_DEBUG(type ,ptr)
#define QYPTR_DEBUG_NOOP
#endif

template<typename T>
class qy_ptr;

template<typename T>
struct qy_wrapper_type
{
 typedef qy_ptr<T> type;
};

template<typename T>
struct qy_wrapper_type<qy_ptr<T>>
{
 typedef qy_ptr<T> type;
};

template<typename TO_Type, typename FROM_Type>
qy_ptr<TO_Type> qy_reinterpret_cast(FROM_Type* ptr);

template<typename T>
class qy_ptr
{
 template<typename FROM_Type, typename TO_Type>
 static TO_Type static_qy_cast(qy_ptr<FROM_Type> rhs)
 {
  return (TO_Type)(rhs.value_);
 }

 enum Value_Classification
 {
  // //  The following are tags used by Clasp:
   //  Raw_Ptr, Special_Value, Value_Frame, Fixnum
  Raw_Ptr = 0, Checked_Ptr = 1, Array_Ptr = 2, Fixnum = 3
 };

 static constexpr size_t classifying_mask = 3; //0b11

 static constexpr size_t tagged_null = 9;

 size_t value_;


public:

 typedef T raw_pointer_type;

 void do_delete()
 {
  delete raw_pointer();
 }

 template<typename TO_Type>
 qy_ptr<TO_Type> qy_reinterpret_cast()
 {
  return ::qy_reinterpret_cast<TO_Type, T>(raw_pointer());
 }

 template<typename TO_Type>
 qy_ptr<TO_Type> qy_static_cast()
 {
  // //  Will cast from TO_Type*
  return (TO_Type*) raw_pointer();
 }

 qy_ptr(const qy_ptr& rhs) : value_(rhs.value_) {}

 qy_ptr(T* t)
 {
  if(t == nullptr)
  {
   value_ = tagged_null;
  }
  else
  {
   value_ = (size_t) t;
   set_checked();
  }
 }

 qy_ptr(const T* t)
 {
  if(t == nullptr)
  {
   value_ = tagged_null;
  }
  else
  {
   value_ = (size_t) t;
   set_checked();
  }
 }


 qy_ptr(size_t v)
  : value_(v)
 {

 }

 qy_ptr()
  : value_(tagged_null)
 {

 }

 qy_ptr(std::nullptr_t)
  : value_(tagged_null)
 {

 }

 size_t raw_direct_value() const
 {
  return value_;
 }

 template<typename U>
 qy_ptr<U> ptr_cast() const
 {
  return (qy_ptr<U>)(value_);
 }

 template<typename TO_Type>
 typename qy_wrapper_type<TO_Type>::type qy_cast()
 {
  return static_qy_cast<T, typename qy_wrapper_type<TO_Type>::type>(*this);
 }

 template<typename GALAXY_Type>
 static typename GALAXY_Type::Root_Vertex_type root_cast(T* t)
 {
  return qy_ptr<T>(t).template qy_cast<typename GALAXY_Type::Root_Void>();
 }

 void set_pointer_value(T* ptr)
 {
  if(ptr == nullptr)
  {
   value_ = tagged_null;
  }
  else
  {
   value_ = (size_t) ptr;
   set_checked();
  }
 }

 template<typename U>
 void take_ptr(qy_ptr<U> qyptr)
 {
  value_ = qyptr.raw_direct_value();
 }


 void set_direct()
 {
  value_ |= Fixnum;
 }

 void set_checked()
 {
  value_ |= Checked_Ptr;
 }


 operator bool() const
 {
  if(value_ == 0)
   return false;
  if(is_checked())
  {
   return value_ != tagged_null;
  }
  else
  {
   return raw_pointer() != nullptr;
  }
 }

 bool is_raw() const
 {
  return (value_ & classifying_mask) == Raw_Ptr;
 }

 bool is_checked() const
 {
  return (value_ & classifying_mask) == Checked_Ptr;
 }

 bool is_array() const
 {
  return (value_ & classifying_mask) == Array_Ptr;
 }

 bool is_fixnum() const
 {
  return (value_ & classifying_mask) == Fixnum;
 }

 inline T* operator->()
 {
  return raw_pointer();
 }

 inline const T* operator->() const
 {
  return raw_pointer();
 }

 inline T& operator*()
 {
  return *raw_pointer();
 }

 inline const T& operator*() const
 {
  return *raw_pointer();
 }

 T* raw_pointer()
 {
  return (T*) (value_ & (~classifying_mask));
 }

 const T* raw_pointer() const
 {
  return (T*) (value_ & (~classifying_mask));
 }

 size_t get_fixnum()
 {
  return value_ >> 2;
 }

 void set_fixnum(size_t v)
 {
  set_raw_value(v << 2);
  value_ |= Fixnum;
 }

 friend bool operator <(qy_ptr lhs, qy_ptr rhs)
 {
  return lhs.raw_pointer() < rhs.raw_pointer();
 }

 friend bool operator >(qy_ptr lhs, qy_ptr rhs)
 {
  return lhs.raw_pointer() > rhs.raw_pointer();
 }

 friend bool operator ==(qy_ptr lhs, qy_ptr rhs)
 {
  return lhs.raw_pointer() == rhs.raw_pointer();
 }

 friend bool operator !=(qy_ptr lhs, qy_ptr rhs)
 {
  return lhs.raw_pointer() != rhs.raw_pointer();
 }

 template<typename U>
 void set_direct_value(U t)
 {
  value_ = t << 2;
  set_direct();
 }

 template<typename U>
 void set_raw_value(U t)
 {
  value_ = t;
 }
};

template<typename GALAXY_Type, typename T>
typename GALAXY_Type::Root_Vertex_type
 qy_root_cast(T* t)
{
 return qy_ptr<T>::template root_cast<GALAXY_Type>(t);
}

template<typename TO_Type, typename FROM_Type>
static qy_ptr<TO_Type> qy_reinterpret_cast(FROM_Type* ptr)
{
 return qy_ptr<TO_Type>(reinterpret_cast<TO_Type*>(ptr));
}

#endif


#endif
