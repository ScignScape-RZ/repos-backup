
#ifndef QYNS__H
#define QYNS__H

#define USE_QYNS

#ifdef USE_QYNS

#define QYNS_(X) \
 namespace QY { namespace X {

#define _QYNS(X) \
 } }


#define QYNS_CLASS_DECLARE(X ,C) \
 namespace QY { namespace X { class C; } }

#ifndef INNER_NS_
#define INNER_NS_(X) \
 namespace X{
#endif

#ifndef _INNER_NS
#define _INNER_NS(X) \
 }
#endif

#define USING_QYNS(x) \
 using namespace QY::x;


#else

#define QYNS_(X) \

#define _QYNS(X) \

#define USING_QYNS(x) \

#define INNER_NS_(X)

#define _INNER_NS(X)

#endif


#endif // QYNS__H
