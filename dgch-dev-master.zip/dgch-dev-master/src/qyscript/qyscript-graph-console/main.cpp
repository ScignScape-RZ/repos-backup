
#include <QDebug>

#include "qyscript/qyscript-graph/kernel/document/qyscript-document.h"

#include "qyns.h"

USING_QYNS(QYSGraph)

void compile_qy(QString file_name)
{
 QString result;
//? RZ_QClasp_Generator::compile_rz(file, result);


 QY_Script_Document* doc = new QY_Script_Document(file_name);
 doc->parse();

//? doc->report_graph(file_name + ".txt");
}

int main(int argc, char* argv[])
{
 qDebug() << "Compiling R/Z to PreDynamo: /ext_root/kauv/qry-cmd/rz/t1.rz";
// compile_qy("/home/nlevisrael/volume/dgch/t1.qys");
 compile_qy("C:/dgch-dev/t1.qys");

}

