
#ifndef QYSCRIPT_GRAMMAR__H
#define QYSCRIPT_GRAMMAR__H

//#include "rz-parser/rz-regex.h"
//#include "rz-parser/rz-parser.h"
//#include "accessors.h"

//
#include "qy-relae/qy-relae-grammar/qy-relae-grammar.h"

//#include "kernel/QY-dominion.h"

#include "qyns.h"


QYNS_(QYSGraph)

class QY_Script_Graph;
class QY_Script_Graph_Builder;
class QY_Script_Parser;

class QY_Script_Grammar : public QY_Relae_Grammar<QY_Script_Graph, QY_Script_Parser>
{

public:

 QY_Script_Grammar();



 void init(QY_Script_Parser& p, QY_Script_Graph& g,
           QY_Script_Graph_Builder& graph_builder);


};

_QYNS(QYSGraph)

//#include "rz-parser/rz-regex.h"
//#include "rz-parser/rz-parser.h"

//#include "rz-text-typedefs.h"

//class RZ_Text_Parser : public RZ_Parser<RZ_Text_Galaxy>
//{
//public:
// RZ_Text_Parser(RZ_Text_Graph* g);
// void set_raw_text(QString s);


//};

//typedef RZ_Parser<RZ_Text_Galaxy> RZ_Text_Parser;

#endif
