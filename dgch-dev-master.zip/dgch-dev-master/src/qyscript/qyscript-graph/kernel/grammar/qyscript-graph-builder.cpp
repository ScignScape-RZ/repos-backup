
#include "qyscript-graph-builder.h"

#include "qhyp/qhyp-graph/qy-hyper-node.h"

//#include "kernel/frame/QY-frame.h"

USING_QYNS(QYSGraph)




QY_Script_Graph_Builder::QY_Script_Graph_Builder(QY_Script_Document* d,
  QY_Script_Parser& p, QY_Script_Graph& g)
 : Flags(0)
   ,document_(d)
   ,graph_(g)
   ,parser_(p)
   ,current_line_(1)
   ,current_node_(nullptr)
   ///,fr_(QY_Frame::instance())
   //?,current_position_state_(Position_States::Root_Position)
{

}

void QY_Script_Graph_Builder::init()
{

}

void QY_Script_Graph_Builder::raw_lisp_start()
{

}

void QY_Script_Graph_Builder::process_raw_lisp()
{

}

void QY_Script_Graph_Builder::add_to_raw_lisp(QString str)
{

}

void QY_Script_Graph_Builder::string_literal_start()
{

}

void QY_Script_Graph_Builder::add_to_string_literal(QString str)
{

}

void QY_Script_Graph_Builder::process_string_literal()
{

}

void QY_Script_Graph_Builder::add_run_token(QString prefix, QString token, QString suffix)
{

}

void QY_Script_Graph_Builder::check_enter_tuple(QString prefix, QString entry, QString suffix)
{

}

