
#ifndef QYSCRIPT_GRAPH_BUILD__H
#define QYSCRIPT_GRAPH_BUILD__H

#include "flags.h"

#include "accessors.h"

#include "kernel/grammar/qyscript-parse-context.h"

#include "qhyp/qhyp-graph/qy-ptr.h"


#include <QString>

#include "qyns.h"
QYNS_(QYSGraph)

//USING_RZNS(RECore)

class QY_Script_Graph;
class QY_Script_Node;
class QY_Script_Document;
class QY_Script_Parser;
class QY_Script_Graph;


class _QY_Hyper_Node;
typedef qy_ptr<_QY_Hyper_Node> QY_Hyper_Node;

//flag_(1, inside_tag_body);
//flag_(2, inside_tag_command_main_argument);
//flag_(3, pre_markup);

class QY_Script_Graph_Builder
{
public:

 flags_(1)
  bool next_token_closes_expression:1;
  bool inside_array_with_formation:1;
 _flags

 QString acc_;

 QY_Script_Parse_Context parse_context_;


 QY_Script_Document* document_;
 QY_Script_Parser& parser_;
 QY_Script_Graph& graph_;

 QY_Hyper_Node current_node_;

  // //sQY_Script_Frame& fr_;

 int current_line_;


public:

 QY_Script_Graph_Builder(QY_Script_Document* d, QY_Script_Parser& p, QY_Script_Graph& g);

 ACCESSORS__RGET(QY_Script_Parse_Context ,parse_context)

 void add_to_string_literal(QString str);
 void process_string_literal();
 void string_literal_start();

 void raw_lisp_start();
 void process_raw_lisp();
 void add_to_raw_lisp(QString str);

 void add_run_token(QString prefix, QString token, QString suffix);
 void check_enter_tuple(QString prefix, QString entry, QString suffix);

 void init();

};

_QYNS(QYSGraph)

#endif

