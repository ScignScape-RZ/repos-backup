
#include "qyscript-parse-context.h"

USING_QYNS(QYSGraph)


QY_Script_Parse_Context::QY_Script_Parse_Context(): Flags(0)
//,  current_open_print_node_(nullptr)
{

}


