
#ifndef QY_SCRIPT_PARSE_CONTEXT__H
#define QY_SCRIPT_PARSE_CONTEXT__H

///#include "relae-graph/relae-parser.h"

#include "flags.h"

#include "qyns.h"
QYNS_(QYSGraph)

//USING_RZNS(RECore)

class QY_Script_Graph;
class QY_Script_Node;

//flag_(1, inside_tag_body);
//flag_(2, inside_tag_command_main_argument);
//flag_(3, pre_markup);

class QY_Script_Parse_Context
{
 typedef QY_Script_Node tNode;

public:
 flags_(2)
  flag_(1, inside_string_literal);
  flag_(2, inside_raw_lisp);
//  flag_(3, inside_text_map_acc);
//  flag_(4, inside_run_comment);
//  flag_(5, inside_string_literal);
//  flag_(6, inside_match_literal);
//  flag_(7, inside_string_plex);
//  flag_(8, inside_path_handlers);
//  flag_(9, inside_xq_literal);
//  flag_(10, inside_raw_lisp);
//  flag_(11, inside_extended_string_literal);
//  flag_(12, arrow_pending_QYmbol_modify_to_method);
//  flag_(13, take_a_space);
    //? flag_(13, multi_arrow_last_token);
 _flags_

private:
//? caon_ptr<QY_Node> current_open_print_node_;

public:

 QY_Script_Parse_Context();

};

_QYNS(QYSGraph)

#endif
