
#include "qyscript-parser.h"

USING_QYNS(QYSGraph)


QY_Script_Parser::QY_Script_Parser(qy_ptr<QY_Script_Graph> g)
 :  QY_Relae_Parser(g)
//,  current_open_print_node_(nullptr)
{

}


