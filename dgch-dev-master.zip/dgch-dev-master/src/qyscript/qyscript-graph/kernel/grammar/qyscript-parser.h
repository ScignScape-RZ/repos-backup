
#ifndef QY_SCRIPT_PARSER__H
#define QY_SCRIOT_PARSER__H

///#include "relae-graph/relae-parser.h"

#include "flags.h"

#include "qhyp/qhyp-graph/qy-ptr.h"

#include "qy-relae/qy-relae-grammar/qy-relae-parser.h"



#include "accessors.h"

#include "qyns.h"
QYNS_(QYSGraph)

//USING_RZNS(RECore)

class QY_Script_Graph;
class QY_Script_Node;

//flag_(1, inside_tag_body);
//flag_(2, inside_tag_command_main_argument);
//flag_(3, pre_markup);

class QY_Script_Graph;

class QY_Script_Parser: public QY_Relae_Parser<QY_Script_Graph>
{
 QString raw_text_;

public:

// // ACCESSORS(SY_Graph* ,graph)
 ACCESSORS(QString ,raw_text)

 //ACCESSORS(SY_Graph* ,graph)

 QY_Script_Parser(qy_ptr<QY_Script_Graph> g);

};

_QYNS(QYSGraph)

#endif
