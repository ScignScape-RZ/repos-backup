

#include "photo-view-dialog-ch/photo-view-dialog-ch.h"

#include <QDebug>

#include <QApplication>


int main(int argc, char *argv[])
{
 qDebug() << DATA_DIR;

 QApplication a(argc, argv);

 Photo_View_Dialog_CH* dlg = new Photo_View_Dialog_CH(nullptr);
 //QMainWindow* mw = new QMainWindow;

 return a.exec();
}
