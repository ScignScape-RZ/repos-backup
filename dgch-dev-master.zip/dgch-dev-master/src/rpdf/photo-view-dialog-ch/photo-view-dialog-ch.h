#ifndef PHOTO_VIEW_DIALOG_CH__H
#define PHOTO_VIEW_DIALOG_CH__H

#include "CyStage/cy-stage-nav/nav-protocols/geometric1d/fore-simplified-geometric-1d-panel.h"
#include "CyStage/cy-stage-nav/nav-protocols/geometric1d/nav-simplified-geometric-1d-panel.h"
#include "CyStage/cy-stage-nav/nav-protocols/geometric1d/series-geometric-wrapped-ch-1d-panel.h"

#include <QVBoxLayout>

//?
KANS_CLASS_DECLARE(CYSTAGE ,CyStage_Image_Tile)
//?
USING_KANS(CYSTAGE)


#include <QDialog>
#include <QVector>
#include <QCheckBox>

class Photo_View_Dialog_CH : public QDialog
{
 Q_OBJECT

 //Fore_Geometric1D_Panel fore_panel_;
 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QVBoxLayout* main_layout_;
 QVBoxLayout* left_layout_;
 QVBoxLayout* fore_layout_;
 QHBoxLayout* center_layout_;

 QGroupBox* groupings_group_box_;
 QVBoxLayout* groupings_layout_;

 Series_Geometric_Wrapped_CH_1D_Panel* series_panel_;
 Fore_Simplified_Geometric1D_Panel* fore_panel_;
 NAV_Simplified_Geometric1D_Panel* nav_panel_;

 QVector<CyStage_Image_Tile*> tiles_;
 QMap<QString, int> path_to_index_;

 int tile_index_;

 void handle_open_series_file();

 void show_group(QCheckBox* cx, int g);
 void hide_group(QCheckBox* cx, int g);

public:

 Photo_View_Dialog_CH(QWidget* parent);

 ~Photo_View_Dialog_CH();

 void open_folder(QString path);


public Q_SLOTS:

 void handle_open_file_requested(QString);
 void handle_series_previous_requested();
 void handle_series_next_requested();


};


#endif
