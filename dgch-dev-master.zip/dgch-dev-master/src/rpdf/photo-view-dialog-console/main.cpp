

#include "photo-view-dialog/photo-view-dialog.h"

#include <QDebug>

#include <QApplication>


int main(int argc, char *argv[])
{
 qDebug() << DATA_DIR;

 QApplication a(argc, argv);

 Photo_View_Dialog* dlg = new Photo_View_Dialog;
 //QMainWindow* mw = new QMainWindow;

 return a.exec();
}
