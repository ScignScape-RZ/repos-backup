
#include "photo-view-dialog.h"

#include <QDialogButtonBox>
#include <QPushButton>
#include <QRegularExpression>
#include <QDirIterator>
#include <QGroupBox>

#include "styles.h"

void Photo_View_Dialog::handle_open_file_requested(QString path)
{
 fore_panel_->open_file(path);
 tile_index_ = path_to_index_[path];
 nav_panel_->set_picture_number_text(tile_index_ + 1);
}

void Photo_View_Dialog::open_folder(QString path)
{
 //? series_panel_->open_folder(path);

 QRegularExpression rx("r(\\d+)c(\\d+)g(\\d+)");

 bool valid_images_folder = true; // check for this ...?

 QDirIterator dirIt(path, QDirIterator::Subdirectories);

 QList<Geometic_Image_Tile_Info> infos;

 while (dirIt.hasNext())
 {
  dirIt.next();
  QFileInfo qfi = dirIt.filePath();

  if(qfi.isFile())
  {
   QString suffix = qfi.suffix().toLower();
   if(suffix == "bmp" || suffix == "jpg" || suffix == "jpeg" || suffix == "png")
   {
    QString qfin = qfi.baseName();
    if(valid_images_folder)
    {
     //     tile = current_tile_map_->value(qfin);
     //     if(!tile)
     //     {
     QRegularExpressionMatch rxm = rx.match(qfin);
     if(rxm.hasMatch())
     {
      int r = rxm.captured(1).toInt();
      int c = rxm.captured(2).toInt();
      int g = rxm.captured(3).toInt();

      //?Geometic_Image_Tile_Info giti(qfin);
      Geometic_Image_Tile_Info giti(qfin, path + "/" + qfin + "." + qfi.suffix());
      giti.set_series_row(r);
      giti.set_series_column(c);
      giti.set_grouping(g);

      infos.push_back(giti);
     }
    }
   }
  }
 }

 if(!infos.isEmpty())
 {
  series_panel_->display_tiles(infos, &tiles_, &path_to_index_);
 }
}

void Photo_View_Dialog::handle_series_previous_requested()
{
 if(tile_index_ == 0)
 {
  tile_index_ = tiles_.size();
 }
 --tile_index_;
 handle_open_series_file();
}

void Photo_View_Dialog::handle_series_next_requested()
{
 ++tile_index_;
 if(tile_index_ == tiles_.size())
 {
  tile_index_ = 0;
 }
 handle_open_series_file();
}

void Photo_View_Dialog::handle_open_series_file()
{
 CyStage_Image_Tile* tile = tiles_[tile_index_];
 fore_panel_->open_file_from_tile(tile);
 nav_panel_->set_picture_number_text(tile_index_ + 1);
 series_panel_->switch_tiles(tile);
}


Photo_View_Dialog::~Photo_View_Dialog()
{

}


Photo_View_Dialog::Photo_View_Dialog(QWidget* parent)
 : QDialog(parent), tile_index_(0)
{
 fore_panel_ = new Fore_Simplified_Geometric1D_Panel("/home/nlevisrael/volume/rpdf/h1.jpg");
 series_panel_ = new Series_Geometric_Wrapped_1D_Panel(this);

 connect(series_panel_, SIGNAL(open_file_requested(QString)),
   this, SLOT(handle_open_file_requested(QString)));
//?
// connect(series_panel_, SIGNAL(open_file_requested(QString)),
//   fore_panel_, SLOT(open_file(QString)));

 open_folder("/home/nlevisrael/volume/dgch/cpp/testdia/series");

 button_box_ = new QDialogButtonBox(this);

 //?url_label_ = new QLabel(this);
  //?url_label_->setText(url);

// name_qle_ = new QLineEdit(this);

 button_ok_ = new QPushButton("OK");
 //? button_proceed_ = new QPushButton("Proceed");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

 //?button_proceed_->setDefault(false);
 //?button_proceed_->setAutoDefault(false);

 button_cancel_->setDefault(true);

 button_ok_->setStyleSheet(basic_button_style_sheet_());
 button_cancel_->setStyleSheet(basic_button_style_sheet_());


 //?button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 //?button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);


 //?connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(close()));

 main_layout_ = new QVBoxLayout();
 left_layout_ = new QVBoxLayout();
 center_layout_ = new QHBoxLayout;

 left_layout_->addWidget(series_panel_);

 groupings_layout_ = new QVBoxLayout;

 groupings_group_box_ = new QGroupBox("Groupings", this);

 QStringList grouping_names {{
   "Entrance/Foyer/Hall",
   "Kitchen/Dining Room",
   "Living Room/Den",
   "Bath/Powder Room",
   "Bedroom/Closet",
   "Master Bedroom/Spa",
   "Basement/Game Room",
  }};

 for(int g = 1; g <= 7; ++g)
 {
  QColor c;
  Series_Geometric_Wrapped_1D_Panel::init_color_from_grouping(c, g);
  QLabel* lbl = new QLabel(grouping_names[g - 1]);
  lbl->setStyleSheet(QString("QLabel{background:%1}").arg(c.name()));
  //lbl->setStyleSheet(QString("QLabel{border-bottom:4px solid %1}").arg(c.name()));
  groupings_layout_->addWidget(lbl);
 }
 //groupings_layout_->addStretch();
 groupings_group_box_->setLayout(groupings_layout_);
 left_layout_->addWidget(groupings_group_box_);

 center_layout_->addLayout(left_layout_);

 fore_layout_ = new QVBoxLayout;
 fore_layout_->addWidget(fore_panel_);

 nav_panel_ = new NAV_Simplified_Geometric1D_Panel;

 connect(nav_panel_, SIGNAL(adjust_zoom_requested(int)),
   fore_panel_, SLOT(adjust_zoom(int)));

 connect(nav_panel_, SIGNAL(series_previous_requested()),
   this, SLOT(handle_series_previous_requested()));

 connect(nav_panel_, SIGNAL(series_next_requested()),
   this, SLOT(handle_series_next_requested()));

 //?
 fore_panel_->direct_adjust_zoom(0);
 fore_panel_->recenter_image();


 fore_layout_->addWidget(nav_panel_);

 center_layout_->addLayout(fore_layout_);
 main_layout_->addLayout(center_layout_);
 main_layout_->addWidget(button_box_);

 setLayout(main_layout_);

 handle_open_series_file();

 show();
 //fore_panel_
}
