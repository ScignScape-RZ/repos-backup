

#include "room-info-dialog/room-info-dialog.h"

#include <QDebug>

#include <iostream>

int main(int argc, char *argv[])
{
 qDebug() << DATA_DIR;

 QApplication a(argc, argv);

 Room_Info_Dialog* dlg = new Room_Info_Dialog;
 //QMainWindow* mw = new QMainWindow;

 return a.exec();
}
