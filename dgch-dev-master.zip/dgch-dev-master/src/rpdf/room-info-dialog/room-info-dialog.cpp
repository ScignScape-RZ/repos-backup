
#include <QMainWindow>
#include <QApplication>
#include <QTabWidget>
#include <QTabBar>
#include <QStylePainter>
#include <QLabel>

#include <QDialog>
#include <QFrame>
#include <QHBoxLayout>
#include <QProxyStyle>
#include <QStyleOption>
#include <QPushButton>

#include "room-info-dialog.h"

#include "styles.h"

#include <QWebEngineView>

void Room_Info_Dialog::add_info_category_tab(int index, int hsize, int vsize, QString text, QString icon_path,
                                             QString tool_tip_text)
{
 QLabel* new_label = new QLabel(QString("<span style='background:rgba(255,255,255,100);'>%1</span>").arg(text));
 new_label->setFixedSize(hsize, vsize);

 // QLabel* new_icon_label = new QLabel;
 // new_icon_label->setPixmap(QPixmap("icon_path"));
 // new_icon_label->setFixedSize(50,100);

 //? main_tabbar->insertTab(index, QIcon(icon_path), "");
 main_tabbar_->insertTab(index, "");
 main_tabbar_->setTabButton(index, QTabBar::LeftSide, new_label);
 // main_tabbar->setTabButton(index, QTabBar::RightSide, new_icon_label);

 main_tabbar_->setTabIcon(index, QIcon(icon_path));

 main_tabbar_->setTabToolTip(index, tool_tip_text);
}

QString Room_Info_Dialog::info_category_name_by_tab_index(int index)
{
 switch(index)
 {
 case 0: return "bi";
 case 1: return "rd";
 case 2: return "rx";
 case 3: return "wm";
 case 4: return "wt";
 default: return "by";
 }
}

void Room_Info_Dialog::add_room_tab(QString name, QString file_path)
{
 QWebEngineView* wev = new QWebEngineView;
 wev->load(QUrl::fromLocalFile(file_path));
 wev_.push_back(wev);
 main_tabwidget_->addTab(wev, name);
}

Room_Info_Dialog::~Room_Info_Dialog()
{
}


Room_Info_Dialog::Room_Info_Dialog(QWidget* parent)
                                   : QDialog(parent)
{
 main_background_color_ = QColor(220,150,30);
 light_background_color_ = QColor(255,245,50);

 main_frame_ = new QFrame(this);
 main_layout_ = new QHBoxLayout;
 main_tabwidget_ = new QTabWidget;
 // main_tabwidget->setTabPosition(QTabWidget::West);

 main_layout_->setContentsMargins(QMargins(0,0,0,0));
 main_layout_->setSpacing(0);

 add_room_tab("Living Room", DATA_DIR "/living-room.html");
 add_room_tab("Dining Room", DATA_DIR "/dining-room.html");
 add_room_tab("Powder Room", DATA_DIR "/powder-room.html");
 add_room_tab("Master Bedroom", DATA_DIR "/master-bedroom.html");

// QWebEngineView* wev1 = new QWebEngineView;
// wev_.push_back(wev1);
// wev1->load(QUrl::fromLocalFile("/home/nlevisrael/volume/dgch/cpp/testdia/living-room.html"));

// QWebEngineView* wev2 = new QWebEngineView;
// wev_.push_back(wev2);
// wev2->load(QUrl::fromLocalFile("/home/nlevisrael/volume/dgch/cpp/testdia/dining-room.html"));

// QWebEngineView* wev3 = new QWebEngineView;
// wev_.push_back(wev3);
// wev3->load(QUrl::fromLocalFile("/home/nlevisrael/volume/dgch/cpp/testdia/powder-room.html"));

// QWebEngineView* wev4 = new QWebEngineView;
// wev_.push_back(wev4);
// wev4->load(QUrl::fromLocalFile("/home/nlevisrael/volume/dgch/cpp/testdia/master-bedroom.html"));

 // main_tabwidget->setStyleSheet("QTabWidget {border:solid red 2px;}");


// main_tabwidget->addTab(wev1, "Living Room");
// main_tabwidget->addTab(wev2, "Dining Room");
// main_tabwidget->addTab(wev3, "Powder Bedroom");
// main_tabwidget->addTab(wev4, "Master Room");

 for(QWebEngineView* wev : wev_)
 {
  connect(wev, &QWebEngineView::loadFinished, [this, wev](bool flag)
  {
   if(flag)
   {
    run_info_category_highlight_script(0, wev);
   }
  });
 }

 //"QTabWidget::pane {background: red;}"
 //"border: 3px solid blue;"
 //"border-bottom: 3px solid #3233ff;"

 //QString str = main_background_color_.

 main_tabwidget_->setStyleSheet(QString("QTabWidget {"
                                       "background: %1;"
                                       "border: 3px solid blue;"
                                       "}"


                                       "QTabBar::tab:selected {"
                                       "border-left: 1px solid #1c1515;"
                                       "padding-left: 10px;"
                                       "border-right: 1px solid #1c1515;"
                                       "padding-right: 10px;"
                                       "border-bottom: 1px solid #1c1515;"
                                       "border-top: 1px solid #a0a0a0;"
                                       "background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,"
                                       "                                 stop: 0 #ededed, stop: 0.7 #9898ff,"
                                       "                                 stop: 0.9 #7e7fff, stop: 1.0 #3233ff);"
                                       " }"
                                       " "
                                       " QTabBar::tab:!selected {"
                                       " border-left: 1px solid #1c1515;"
                                       " padding-left: 10px;"
                                       " border-right: 1px solid #1c1515;"
                                       " padding-right: 10px;"
                                       " border-bottom: 1px solid #1c1515;"
                                       " border-top: 1px solid #a0a0a0;"
                                       " margin-bottom: 2px;"
                                       " background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,"
                                       "                                  stop: 0 #e0e0e0, stop: 0.4 #dbdbdb,"
                                       "                                  stop: 0.5 #d3d3d3, stop: 1.0 #cfcfcf);"
                                       "  }"
                                       ).arg(main_background_color_.name()));

 main_tabbar_ = new QTabBar(this);
 main_tabbar_->setShape(QTabBar::RoundedWest);

 //? tabWidget->setTabPosition(QTabWidget::West);
 main_tabbar_->setStyle(new CustomTabStyle);

 //?main_tabbar->setStyleSheet("QTabBar::tab{width:100px;height:100px;} QTabBar::tab:selected {background:red}");
 main_tabbar_->setStyleSheet(QString("QTabBar::tab:selected {background:%1}").arg(main_background_color_.name()));

 main_tabbar_->setIconSize(QSize(50,50));

 //? tabWidget->addTab(new QWidget, "General");
 //? tabWidget->addTab(new QWidget, "Permissions");
 //? tabWidget->addTab(new QWidget, "Applications");

 // main_tabbar->addTab(QIcon("/home/nlevisrael/volume/dgch/cpp/testdia/red-3d-question-mark-icon.png"), "");
 // main_tabbar->setTabButton(0, QTabBar::LeftSide, new QLabel(
 //   "<span style='background:rgba(255,255,255,100);'>Basic Info</span>"));

 ////                     "<span style='position:relative;left:-20px'>Basic Info</span>");
 // main_tabbar->setTabToolTip(0, "Basic Info");

 add_info_category_tab(0, 60, 40, "Basic Info", DATA_DIR "/red-3d-question-mark-icon.png", "Windows");
 add_info_category_tab(1, 70, 40, "Dimensions", DATA_DIR "/canva-triangle-arrows-icon.png", "Room Dimensions");
 add_info_category_tab(2, 60, 40, "Exposure", DATA_DIR "/Sunrise.png", "Room Exposure");
 add_info_category_tab(3, 60, 40, "Wall<br>Elements", DATA_DIR "/windsor-wainscot-cap-wc003_3.png", "Wainscot and Molding");
 add_info_category_tab(4, 50, 40, "Windows", DATA_DIR "/Windows_window_interface_microsoft_player.png", "Window Fixtures");

 connect(main_tabbar_, &QTabBar::currentChanged, [this](int index)
 {
  run_info_category_highlight_scripts(index);
 });

 run_info_category_highlight_scripts(0);

 //main_tabbar->addTab(QIcon("/home/nlevisrael/volume/dgch/cpp/testdia/canva-triangle-arrows-icon.png"), "Room Dimensions");
 //main_tabbar->setTabToolTip(1, "Room Dimensions");

 // main_tabbar->addTab(QIcon("/home/nlevisrael/volume/dgch/cpp/testdia/windsor-wainscot-cap-wc003_3.png"), "Wainscot and molding");
 // main_tabbar->setTabToolTip(2, "Wainscot and molding");

 // main_tabbar->addTab(QIcon("/home/nlevisrael/volume/dgch/cpp/testdia/Windows_window_interface_microsoft_player.png"),"Window Treatment");
 // main_tabbar->setTabToolTip(3, "Windows");

 // add_info_category_tab(1, "Room Dimensions", "/home/nlevisrael/volume/dgch/cpp/testdia/canva-triangle-arrows-icon.png", "Windows");
 // add_info_category_tab(2, "Wainscot and molding", "/home/nlevisrael/volume/dgch/cpp/testdia/windsor-wainscot-cap-wc003_3.png", "Windows");
 // add_info_category_tab(3, "Windows", "/home/nlevisrael/volume/dgch/cpp/testdia/Windows_window_interface_microsoft_player.png", "Windows");

 // main_tabbar->addTab(QIcon("/home/nlevisrael/volume/dgch/cpp/testdia/red-3d-question-mark-icon.png"), "");
 // main_tabbar->setTabToolTip(0, "Basic Info");

 // main_tabbar->addTab(QIcon("/home/nlevisrael/volume/dgch/cpp/testdia/canva-triangle-arrows-icon.png"), "");
 // main_tabbar->setTabToolTip(1, "Room Dimensions");

 // main_tabbar->addTab(QIcon("/home/nlevisrael/volume/dgch/cpp/testdia/windsor-wainscot-cap-wc003_3.png"), "");
 // main_tabbar->setTabToolTip(2, "Wainscot and molding");

 // main_tabbar->addTab(QIcon("/home/nlevisrael/volume/dgch/cpp/testdia/Windows_window_interface_microsoft_player.png"),"");
 // main_tabbar->setTabToolTip(3, "Windows");

 main_tabbar_->addTab("Matterport Tag Posts");
 // main_tabbar->setTabToolTip(4,
 //   "<img src='/home/nlevisrael/volume/dgch/cpp/testdia/Windows_window_interface_microsoft_player.png' style='height:20px'>");

 // main_tabbar->addTab("Page Info");

 tab_bar_layout_ = new QVBoxLayout;

 tab_bar_layout_->addWidget(main_tabbar_);
 tab_bar_layout_->addStretch();
 main_layout_->addLayout(tab_bar_layout_);
 main_layout_->addWidget(main_tabwidget_);

 button_box_ = new QDialogButtonBox(this);
 button_ok_ = new QPushButton("OK");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

 button_cancel_->setDefault(true);
 button_ok_->setStyleSheet(basic_button_style_sheet_());
 button_cancel_->setStyleSheet(basic_button_style_sheet_());

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);


 //?connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(close()));




 main_frame_->setLayout(main_layout_);
 outer_layout_ = new QVBoxLayout;
 outer_layout_->addWidget(main_frame_);
 outer_layout_->addWidget(button_box_);


 setLayout(outer_layout_);
 show();
}

void Room_Info_Dialog::run_info_category_highlight_script(int index, QWebEngineView* wev)
{
 QString div_id = this->info_category_name_by_tab_index(index);
 QString js;
 QString current_div = wev_current_div_.value(wev);
 if(current_div.isEmpty())
 {
  js = QString(
     "document.getElementById('%1').style.background='%2';"
     "document.getElementById('%1').style.borderLeftColor='%3';"
     ).arg(div_id).arg(light_background_color_.name()).arg(main_background_color_.name());
 }
 else
 {
  js = QString(
     "document.getElementById('%1').style.background='none';"
     "document.getElementById('%1').style.borderLeftColor='white';"
     "document.getElementById('%2').style.background='%3';"
     "document.getElementById('%2').style.borderLeftColor='%4';"
     ).arg(current_div).arg(div_id).arg(light_background_color_.name())
    .arg(main_background_color_.name());
 }
 wev_current_div_[wev] = div_id;
 wev->page()->runJavaScript(js);
}

void Room_Info_Dialog::run_info_category_highlight_scripts(int index)
{
 for(QWebEngineView* wev : wev_)
 {
  run_info_category_highlight_script(index, wev);
 }
}

