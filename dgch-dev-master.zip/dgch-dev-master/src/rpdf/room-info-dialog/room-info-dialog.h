
#ifndef ROOM_INFO_DIALOG__H
#define ROOM_INFO_DIALOG__H

#include <QMainWindow>
#include <QApplication>
#include <QTabWidget>
#include <QTabBar>
#include <QStylePainter>

#include <QDialog>
#include <QFrame>
#include <QHBoxLayout>
#include <QProxyStyle>
#include <QStyleOption>
#include <QColor>

#include <QWebEngineView>
#include <QDialogButtonBox>


class CustomTabStyle : public QProxyStyle
{
public:
    QSize sizeFromContents(ContentsType type, const QStyleOption *option,
                           const QSize &size, const QWidget *widget) const
    {
        QSize s = QProxyStyle::sizeFromContents(type, option, size, widget);
        if (type == QStyle::CT_TabBarTab)
            s.transpose();
        return s;
    }

    void drawControl(ControlElement element, const QStyleOption *option, QPainter *painter, const QWidget *widget) const
    {
        if (element == CE_TabBarTabLabel)
        {
            if (const QStyleOptionTab *tab = qstyleoption_cast<const QStyleOptionTab *>(option))
            {
                QStyleOptionTab opt(*tab);
                opt.shape = QTabBar::RoundedNorth;
                QProxyStyle::drawControl(element, &opt, painter, widget);
                return;
            }
        }
        QProxyStyle::drawControl(element, option, painter, widget);
    }
};



//QSize CustomTabStyle::sizeFromContents(ContentsType type, const QStyleOption *option,
//                           const QSize &size, const QWidget *widget) const
//{
//    QSize s = QProxyStyle::sizeFromContents(type, option, QSize(40, 120), widget);  // instead of size, I'm hardcoding the value with QSize(40, 120)
//    if (type == QStyle::CT_TabBarTab)
//        s.transpose();
//    return s;
//}

class MyTabBar : public QTabBar
{
protected:
    void paintEvent(QPaintEvent *) {
        QStylePainter painter(this);
        for(int i = 0; i < 3; ++i) {
            QStyleOptionTabV2 option;
            initStyleOption(&option, i);
            painter.drawItemPixmap(option.rect, Qt::AlignTop|Qt::AlignHCenter, option.icon.pixmap(30));
            painter.drawItemText(option.rect, Qt::AlignCenter|Qt::AlignHCenter, palette(), 1, option.text);
        }
    }
public:
    MyTabBar(QWidget* parent) : QTabBar(parent)
    {}
};

class Room_Info_Dialog : public QDialog
{
 void add_info_category_tab(int index, int hsize, int vsize, QString text, QString icon_path, QString tool_tip_text);

 QColor main_background_color_;
 QColor light_background_color_;

 QList<QWebEngineView*> wev_;
 QMap<QWebEngineView*, QString> wev_current_div_;

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;

 QFrame* main_frame_;
 QTabWidget* main_tabwidget_;
 QHBoxLayout* main_layout_;
 QVBoxLayout* tab_bar_layout_;
 QVBoxLayout* outer_layout_;

 QTabBar* main_tabbar_;

 QString info_category_name_by_tab_index(int index);

 void run_info_category_highlight_scripts(int index);

 void run_info_category_highlight_script(int index, QWebEngineView* wev);
 void add_room_tab(QString name, QString file_path);

public:

 Room_Info_Dialog(QWidget* parent);
 ~Room_Info_Dialog();



};


#endif
