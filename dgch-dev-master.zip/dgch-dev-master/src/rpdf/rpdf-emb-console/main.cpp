

//========================================================================
//
// xpdf.cc
//
// Copyright 1996-2105 Glyph & Cog, LLC
//
//========================================================================

#include <aconf.h>

#include <cstring>

#include "gmem.h"
#include "Object.h"
#include "XpdfApp.h"

#include "appinfo/xpdfappinfo.h"
#include "cy/lexinfo-builder.h"

#include "xpdf-qt/QtPDFCore.h"

#include "goo/parseargs.h"
#include "GlobalParams.h"
#include "XpdfViewer.h"

#include "photo-view-dialog/photo-view-dialog.h"
#include "photo-view-dialog-ch/photo-view-dialog-ch.h"
#include "webgl-view-dialog/webgl-view-dialog.h"
#include "room-info-dialog/room-info-dialog.h"

#include <QMessageBox>
#include <QTimer>
#include <QScreen>

//Q_DECLARE_METATYPE(XpdfViewer)
Q_DECLARE_METATYPE(XpdfViewer*)

#include <QCoreApplication>


//USING_KANS(KCM)
//USING_KANS(KCL)

USING_QSNS(Cy_Mesh)


//USING_KANS(KCM)
//USING_KANS(KCL)



#include <QDebug>
#include <QFileInfo>
#include <QDir>


//------------------------------------------------------------------------
// command line options
//------------------------------------------------------------------------

static GBool reverseVideoArg = gFalse;
static char paperColorArg[256] = "";
static char matteColorArg[256] = "";
static char fsMatteColorArg[256] = "";
static char initialZoomArg[256] = "";
static char antialiasArg[16] = "";
static char vectorAntialiasArg[16] = "";
static char textEncArg[128] = "";
static char passwordArg[33] = "";
static GBool fullScreen = gFalse;
static char cfgFileArg[256] = "";
static GBool printCommandsArg = gFalse;
static GBool printVersionArg = gFalse;
static GBool printHelpArg = gFalse;

static ArgDesc argDesc[] = {
  {"-rv",           argFlag,   &reverseVideoArg,   0,                          "reverse video"},
  {"-papercolor",   argString, paperColorArg,      sizeof(paperColorArg),      "color of paper background"},
  {"-mattecolor",   argString, matteColorArg,      sizeof(matteColorArg),      "color of matte background"},
  {"-fsmattecolor", argString, fsMatteColorArg,    sizeof(fsMatteColorArg),    "color of matte background in full-screen mode"},
  {"-z",            argString, initialZoomArg,     sizeof(initialZoomArg),     "initial zoom level (percent, 'page', 'width')"},
  {"-aa",           argString, antialiasArg,       sizeof(antialiasArg),       "enable font anti-aliasing: yes, no"},
  {"-aaVector",     argString, vectorAntialiasArg, sizeof(vectorAntialiasArg), "enable vector anti-aliasing: yes, no"},
  {"-enc",          argString, textEncArg,         sizeof(textEncArg),         "output text encoding name"},
  {"-pw",           argString, passwordArg,        sizeof(passwordArg),        "password (for encrypted files)"},
  {"-fullscreen",   argFlag,   &fullScreen,        0,                          "run in full-screen (presentation) mode"},
  {"-cmd",          argFlag,   &printCommandsArg,  0,                          "print commands as they're executed"},
  {"-cfg",          argString, cfgFileArg,         sizeof(cfgFileArg),         "configuration file to use in place of .xpdfrc"},
  {"-v",            argFlag,   &printVersionArg,   0,                          "print copyright and version info"},
  {"-h",            argFlag,   &printHelpArg,      0,                          "print usage information"},
  {"-help",         argFlag,   &printHelpArg,      0,                          "print usage information"},
  {"--help",        argFlag,   &printHelpArg,      0,                          "print usage information"},
  {"-?",            argFlag,   &printHelpArg,      0,                          "print usage information"},
  {NULL}
};


//USING_KANS(CMD)
USING_QSNS(Cy_Mesh)
//USING_KANS(KCM)


enum class RPDF_Dialog_Codes
{
 N_A, Photos, Photos_Alternate, Rooms, Tour, Cleanup, Screen_Shot_10, Screen_Shot_50, Screen_Shot_Mid
};

RPDF_Dialog_Codes parse_rpdf_code(QString code)
{
 static QMap<QString, RPDF_Dialog_Codes> static_map{{
   {"ph", RPDF_Dialog_Codes::Photos},
   {"pha", RPDF_Dialog_Codes::Photos_Alternate},
   {"rm", RPDF_Dialog_Codes::Rooms},
   {"tr", RPDF_Dialog_Codes::Tour},
   {"cl", RPDF_Dialog_Codes::Cleanup},
   {"ss10", RPDF_Dialog_Codes::Screen_Shot_10},
   {"ss50", RPDF_Dialog_Codes::Screen_Shot_50},
   {"ssm", RPDF_Dialog_Codes::Screen_Shot_Mid},
 }};
 return static_map.value(code, RPDF_Dialog_Codes::N_A);
}


void take_screenshot(QString save_path, int len, int target_window_id)
{
 QScreen* screen = QGuiApplication::primaryScreen();
  if (!screen)
      return;
 QApplication::beep();

 //medMainWindow* mainWindow = qobject_cast <medMainWindow *> (parent());

 QTimer::singleShot(1000 * len, [=]
 {
  QPixmap pixmap = screen->grabWindow(target_window_id);

  qDebug() << "Saving to path: " << save_path;
  QFile file(save_path);
  if(file.open(QIODevice::WriteOnly))
  {
   pixmap.save(&file, "PNG");
   qDebug() << "Save completed.";
  }
 });
}



void parse_launch_dialog(RPDF_Dialog_Codes rdc, QWidget* qw)
{
 switch (rdc)
 {
 case RPDF_Dialog_Codes::Photos:
  {
   Photo_View_Dialog* dlg = new Photo_View_Dialog(qw);
   dlg->show();
  }
  break;
 case RPDF_Dialog_Codes::Photos_Alternate:
  {
   Photo_View_Dialog_CH* dlg = new Photo_View_Dialog_CH(qw);
   dlg->show();
  }
  break;
 case RPDF_Dialog_Codes::Rooms:
  {
   Room_Info_Dialog* dlg = new Room_Info_Dialog(qw);
   dlg->show();
  }
  break;
 case RPDF_Dialog_Codes::Tour:
  {
   WebGL_View_Dialog* dlg = new WebGL_View_Dialog(qw);
   dlg->show();
  }
  break;
 case RPDF_Dialog_Codes::Cleanup:
  {
   QMessageBox::question(qw,
     "Confirm Delete",
     "Please confirm that you would "
     "like to delete local files saved for this property. "
     "Is it OK to proceed?");
  }
  break;
 case RPDF_Dialog_Codes::Screen_Shot_10:
  {
   QWidget* parent = (QWidget*)(qw->parent()?qw->parent()->parent()?qw->parent()->parent():qw->parent():qw);
   //?QWidget* parent = (QWidget*)(qw->parent()? qw->parent(): qw);
   take_screenshot("/home/nlevisrael/volume/dgch/cpp/testdia/bulletin/reslides/screenshots/ss1.png", 10, parent->winId());
  }
  break;
 case RPDF_Dialog_Codes::Screen_Shot_50:
  {
   QWidget* parent = (QWidget*)(qw->parent()?qw->parent()->parent()?qw->parent()->parent():qw->parent():qw);
   //?QWidget* parent = (QWidget*)(qw->parent()? qw->parent(): qw);
   take_screenshot("/home/nlevisrael/volume/dgch/cpp/testdia/bulletin/reslides/screenshots/ss1.png", 50, parent->winId());
  }
  break;
 case RPDF_Dialog_Codes::Screen_Shot_Mid:
  {
   take_screenshot("/home/nlevisrael/volume/dgch/cpp/testdia/bulletin/reslides/screenshots/ss1.png", 20, qw->winId());
  }
  break;
 default:
  break;
 }
}

void parse_launch_dialog(QString code, QWidget* qw)
{
 RPDF_Dialog_Codes rdc = parse_rpdf_code(code);
 parse_launch_dialog(rdc, qw);
}


int main(int argc, char *argv[])
{
 int exitCode;

 {
  QApplication qapp(argc, argv);


  const char *fileName, *dest;
  GString *color;
  GBool ok;
  int pg, i;

//  setApplicationName("XpdfReader");
//  setApplicationVersion(xpdfVersion);

  ok = parseArgs(argDesc, &argc, argv);
  if (!ok || printVersionArg || printHelpArg) {
   fprintf(stderr, "xpdf version %s\n", xpdfVersion);
   fprintf(stderr, "%s\n", xpdfCopyright);
   if (!printVersionArg) {
    printUsage("xpdf", "[<PDF-file> [:<page> | +<dest>]] ...", argDesc);
   }
   ::exit(99);
  }

  //--- set up GlobalParams; handle command line arguments
  globalParams = new GlobalParams(cfgFileArg);
#ifdef _WIN32
  QString dir = applicationDirPath();
  globalParams->setBaseDir(dir.toLocal8Bit().constData());
  dir += "/t1fonts";
  globalParams->setupBaseFonts(dir.toLocal8Bit().constData());
#else
  globalParams->setupBaseFonts(NULL);
#endif
  if (initialZoomArg[0]) {
   globalParams->setInitialZoom(initialZoomArg);
  }
  //?reverseVideo = reverseVideoArg;
  if (paperColorArg[0]) {
   //?paperColor = QColor(paperColorArg);
  } else {
   color = globalParams->getPaperColor();
   //?paperColor = QColor(color->getCString());
   delete color;
  }
//?
//  if (reverseVideo) {
//   paperColor = QColor(255 - paperColor.red(),
//                       255 - paperColor.green(),
//                       255 - paperColor.blue());
//  }
  if (matteColorArg[0]) {
//?   matteColor = QColor(matteColorArg);
  } else {
   color = globalParams->getMatteColor();
//?   matteColor = QColor(color->getCString());
   delete color;
  }
  if (fsMatteColorArg[0]) {
//?   fsMatteColor = QColor(fsMatteColorArg);
  } else {
   color = globalParams->getFullScreenMatteColor();
//?   fsMatteColor = QColor(color->getCString());
   delete color;
  }
  if (antialiasArg[0]) {
   if (!globalParams->setAntialias(antialiasArg)) {
    fprintf(stderr, "Bad '-aa' value on command line\n");
   }
  }
  if (vectorAntialiasArg[0]) {
   if (!globalParams->setVectorAntialias(vectorAntialiasArg)) {
    fprintf(stderr, "Bad '-aaVector' value on command line\n");
   }
  }
  if (textEncArg[0]) {
   globalParams->setTextEncoding(textEncArg);
  }
  if (printCommandsArg) {
   globalParams->setPrintCommands(gTrue);
  }

 // errorEventType = QEvent::registerEventType();

  //viewers = new GList();

  //--- load PDF file(s) requested on the command line
  if (argc >= 2) {
   i = 1;
   while (i < argc) {
    pg = 1;
    dest = "";
    if (i+1 < argc && argv[i+1][0] == ':') {
     fileName = argv[i];
     pg = atoi(argv[i+1] + 1);
     i += 2;
    } else if (i+1 < argc && argv[i+1][0] == '+') {
     fileName = argv[i];
     dest = argv[i+1] + 1;
     i += 2;
    } else {
     fileName = argv[i];
     ++i;
    }
   }
  }

  //  Kauvir_Code_Model code_model;// = new Kauvir_Code_Model;
  //  KCM_Command_Log log(&code_model);

  //  QLispConsole* console = QLispConsole::getInstance(nullptr);

  //  console->set_cb([](const QString& code, int* res, QString& result)
  //  {
  //   result = code + QString::number(*res);
  //  });

  //  QLispConsole_Dialog dlg(console);

  //  log([&dlg](QStringList* qsl, QString* qs)
  //  {
  //   dlg.log_command(qsl, qs);
  //  });

  //  dlg.show();



    XPDF_AppInfo* appi = new XPDF_AppInfo(nullptr);

    typedef void(*cmcbktype)(const QPoint& p, QWidget* qw);
    cmcbktype cmcbk = [](const QPoint& p, QWidget* qw)
    {
     QMenu* qm = new QMenu(qw);
     qm->addAction("View Photos", [qw]()
     {
      parse_launch_dialog(RPDF_Dialog_Codes::Photos, qw);
     });
     qm->addAction("View Photos (Alternate)", [qw]()
     {
      parse_launch_dialog(RPDF_Dialog_Codes::Photos_Alternate, qw);
     });
     qm->addAction("Virtual Tour", [qw]()
     {
      parse_launch_dialog(RPDF_Dialog_Codes::Tour, qw);
     });
     qm->addAction("View Rooms", [qw]()
     {
      parse_launch_dialog(RPDF_Dialog_Codes::Rooms, qw);
     });
     qm->addAction("Take Screenshot", [qw]()
     {
      parse_launch_dialog(RPDF_Dialog_Codes::Screen_Shot_10, qw);
     });
     qm->addAction("Take Screenshot (delay)", [qw]()
     {
      parse_launch_dialog(RPDF_Dialog_Codes::Screen_Shot_50, qw);
     });
     qm->addAction("Take Screenshot (mid)", [qw]()
     {
      parse_launch_dialog(RPDF_Dialog_Codes::Screen_Shot_Mid, qw);
     });
     qm->addAction("Cleanup Local Files", [qw]()
     {
      parse_launch_dialog(RPDF_Dialog_Codes::Cleanup, qw);
     });

     QPoint g = qw->mapToGlobal(p);
     qm->popup(g);
     //qDebug() << p;
    };
    appi->set_context_menu_callback((void*)cmcbk);

    appi->init_lexib();
    //Lexinfo_Builder lexb(appi->lexicon());
    //?appi->lexicon().check_add_lexentry("logic");
    //?appi->lexicon().check_add_lexentry("type");

    QtPDFLinkCbk cbk = [](void* data,
      const char* c1, const char* c2, int i1)
    {
     QWidget* qw = (QWidget*) data;
     if(std::strcmp(c1, "url") == 0)
     {
      QString url = QString::fromLatin1(c2);
      int index = url.indexOf("#RPDF___");
      if(index != -1)
      {
       index += 8;
       QString code = url.mid(index);
       parse_launch_dialog(code, qw);
      }
     }
    };
    appi->set_link_callback((void*)cbk);

    typedef void(*fcbktype)(int, double, double, QString&);
    fcbktype fcbk = [](int, double, double, QString& cancel)
    {
     cancel = "links Disabled";
    };
    appi->set_follow_link_callback((void*)fcbk);

    XpdfViewer* viewer = new XpdfViewer(appi, false);
    appi->set_current_viewer(viewer);


    XpdfWidget* xpdfw = viewer->get_current_xpdf_widget();
    QObject::connect(xpdfw, &XpdfWidget::postLoad, [xpdfw]()
    {
     QString fn = xpdfw->getFileName();
     if(fn.endsWith(".rpdf"))
     {
      QDir qd = QDir::currentPath();
      qd.cdUp();
      qd.cdUp();
      QString folder = qd.absolutePath() + "/rpdf/internal/tmp/";
      QMessageBox::information(nullptr,
        "Files Extracted",
        QString("Images and data related to this property have been "
        "extracted from this PDF document and saved to this folder: %1.\n\n"
        "You can delete these files by right-clicking on any "
        "page and selecting \"Cleanup Local Files\" from the context menu.").arg(folder));
     }
    });

    //viewers->append(viewer);
    viewer->show();



    viewer->connect(viewer, &XpdfViewer::fore_file_requested, []//?[&log]
                    (QString file_name, QString orig_name)
    {
     QFileInfo qfi(orig_name);
     QString ext = qfi.suffix();

//     KCM_Command_Package kcp;
//     kcp.add_fuxe_carrier("open-fore-file");
//     kcp.add_lambda_carrier(log.type_object_pair__str(), file_name);
//     log(kcp);

     qDebug() << "File Name ... " << file_name << " " << ext;
    });

    qapp.exec();

    //   // this in inside a block so that the XpdfApp object gets freed
    //    XpdfApp app(argc, argv);
    //    if (app.getNumViewers() > 0) {
    //      exitCode = app.exec();
    //    } else {
    //      exitCode = 1;
    //    }
   }

   Object::memCheck(stderr);
   gMemReport(stderr);

   return exitCode;
  }

#ifdef _WIN32
  int CALLBACK WinMain(HINSTANCE hIstance, HINSTANCE hPrevInstance,
                       LPSTR lpCmdLine, int nCmdShow) {
   wchar_t **args;
   int argc, i, n, ret;

   if (!(args = CommandLineToArgvW(GetCommandLineW(), &argc)) ||
       argc < 0) {
    return -1;
   }
   char **argv = (char  **)gmallocn(argc + 1, sizeof(char *));
   for (i = 0; i < argc; ++i) {
    n = WideCharToMultiByte(CP_ACP, 0, args[i], -1, NULL, 0, NULL, NULL);
    argv[i] = (char *)gmalloc(n);
    WideCharToMultiByte(CP_ACP, 0, args[i], -1, argv[i], n, NULL, NULL);
   }
   argv[argc] = NULL;
   LocalFree(args);
   ret = main(argc, argv);
   for (i = 0; i < argc; ++i) {
    gfree(argv[i]);
   }
   gfree(argv);
   return ret;
  }
#endif










//  void* env_qob(void* kind, void* test = nullptr)
//  {
//   static QMap<QString, void*> hold;
//   QString* k = reinterpret_cast<QString*>(kind);
//   qDebug() << *k;
//   if(test)
//   {
//    hold[*k] = test;
//   }
//   return hold.value(*k);
//  }

//  void env_qob_nor(void* kind)
//  {
//   QString* k = reinterpret_cast<QString*>(kind);
//   qDebug() << *k;
//  }


