#include <QWebEngineView>
#include <QMainWindow>
#include <QApplication>
#include <QTabWidget>
#include <QWebChannel>
#include <QWebEnginePage>
#include <QContextMenuEvent>
#include <QMenu>
#include <QWebEngineContextMenuData>

#include "webgl-view-dialog/rpdf-web-engine-page.h"
#include "webgl-view-dialog/rpdf-web-engine-view.h"

#include "webgl-view-dialog/webgl-view-dialog.h"

int main(int argc, char *argv[])
{
 QApplication a(argc, argv);
 WebGL_View_Dialog* dlg = new WebGL_View_Dialog;

 return a.exec();


}

int main1(int argc, char *argv[])
{
 QApplication a(argc, argv);

 QMainWindow* mw = new QMainWindow;

 QTabWidget* qtw = new QTabWidget;



 RPDF_Web_Engine_View* wev = new RPDF_Web_Engine_View();
 //wev->setGeometry(0,0,700,600);

//?
 RPDF_Web_Engine_Page* mwp = new RPDF_Web_Engine_Page;

 QObject::connect(mwp, &RPDF_Web_Engine_Page::urlChanged,[](const QUrl &url){
  qDebug() << "r:" << url.toString();

 });

 QObject::connect(mwp, &RPDF_Web_Engine_Page::linkHovered,[](const QUrl &url){
  qDebug() << "H:" << url.toString();

 });

 MyPage* myp = new MyPage;
 QWebChannel* channel = new QWebChannel(wev);
 channel->registerObject(QStringLiteral("content"), myp);
 mwp->setWebChannel(channel);

 //?
 wev->setPage(mwp);

//?
 mwp->load(QUrl("file:///home/nlevisrael/volume/dgch/cpp/testdia/matterport/"));
// wev->page()->load(QUrl("https://matterport.com/3d-space/wotso-workspace/"));

 qtw->addTab(wev, "tw");

 mw->setCentralWidget(qtw);
 //mw->setGeometry(5,50,900,650);

 wev->show();
 mw->show();
 return a.exec();
}



#ifdef HIDE

//class NavigationRequestInterceptor;
class NavigationRequestInterceptor : public QWebEnginePage
{
    QWebEnginePage* target;
public:
    NavigationRequestInterceptor(QWebEnginePage* parent);
    bool acceptNavigationRequest(const QUrl &url, NavigationType type,
bool isMainFrame) Q_DECL_OVERRIDE;
};

class MyWebPage : public QWebEnginePage
{
public:
    MyWebPage();
    MyWebPage(MyWebPage* parent);

    bool acceptNavigationRequest(const QUrl &url, NavigationType type,
bool isMainFrame) override;

    NavigationRequestInterceptor*
createWindow(QWebEnginePage::WebWindowType type) override;

};


NavigationRequestInterceptor::NavigationRequestInterceptor(QWebEnginePage*
parent)
 : QWebEnginePage(parent)
{
    target = parent;
}

bool NavigationRequestInterceptor::acceptNavigationRequest(const QUrl
&url, NavigationType type, bool isMainFrame)
{
    qDebug() << "acceptNavigationRequest called. type=" << type <<
"isMainFrame=" << isMainFrame;

    qDebug() << "acceptNavigationRequest called. url=" << url.toString();

//    MyWebPage *page = dynamic_cast<MyWebPage*>(target);
//    if (/*isMainFrame && */type == NavigationTypeLinkClicked && page)
//        Q_EMIT page->urlClicked(url);
//    else
//        target->load(url);

    return false;
}

//and then you return an instance of that in createWindow

//QWebEngineView*WebEngineView::createWindow(QWebEnginePage::WebWindowType type)
//{
//    Q_UNUSED(type);

//    qDebug() << "createWindow called, returning NavigationRequestInterceptor";
//    WebEngineView *result = new WebEngineView();
//    result->setPage(new NavigationRequestInterceptor(this->page()));
//    return result;
//}


class MyWebView : public QWebEngineView
{
public:
    MyWebView();

    MyWebView* sec;

    void contextMenuEvent(QContextMenuEvent *event) override;
//?    MyWebView* createWindow(QWebEnginePage::WebWindowType type) override;
    void check_sec();

};


MyWebPage::MyWebPage() : QWebEnginePage()
{

}

MyWebPage::MyWebPage(MyWebPage* parent) : QWebEnginePage(parent)
{

}

MyWebView::MyWebView():QWebEngineView()
{
 sec  =  nullptr;
}

void MyWebView::contextMenuEvent(QContextMenuEvent *event)
{
 //
    qDebug()<< "event->reason()";
    qDebug()<< event->reason();
 QMenu* menu = page()->createStandardContextMenu();

 for(QAction* a : menu->actions())
 {
     qDebug()<< a->text();
 }

 QWebEngineContextMenuData cd = page()->contextMenuData();

 qDebug() << "ST:" << cd.selectedText();
 qDebug() << "LT:" << cd.linkText();
 qDebug() << "LU:" << cd.linkUrl().toString();
 qDebug() << "mT:" << cd.mediaType();
 qDebug() << "mU:" << cd.mediaUrl().toString();

 menu->popup(event->globalPos());

}

//MyWebPage* MyWebPage::createWindow(WebWindowType type)
//{
//    qDebug()  << "WebWindowType" << type;

// return nullptr;
//}

NavigationRequestInterceptor*
MyWebPage::createWindow(QWebEnginePage::WebWindowType type)
{
        qDebug()  << "WebWindowType" << type;

            qDebug() << "createWindow called, returningNavigationRequestInterceptor";

            NavigationRequestInterceptor *result = new NavigationRequestInterceptor(this);
            //result->setPage(new NavigationRequestInterceptor(this->page()));
            return result;

}

//MyWebView* MyWebView::createWindow(QWebEnginePage::WebWindowType type)
//{
//    qDebug()  << "WebWindowType" << type;

//        qDebug() << "createWindow called, returningNavigationRequestInterceptor";

//        qDebug()  << "r" << this->page()->requestedUrl().toString();


//        MyWebView *result = new MyWebView();
//        result->setPage(new NavigationRequestInterceptor(this->page()));
//        return result;

////    sec = new MyWebView;

////    connect(sec, &QWebEngineView::loadFinished, [this](bool b)
////    {
////        qDebug()  << "Web::: " << sec->page()->url();
////    });

////check_sec();
//// return sec;
//}

void MyWebView::check_sec()
{
    if(sec)
    {
     qDebug()  << "sec: "  <<   sec->page()->url().toString();
    }
    else
    {
        qDebug()  << "xsec";
    }
}


bool MyWebPage::acceptNavigationRequest(const QUrl &url,
NavigationType type, bool isMainFrame)
{
//?
    qDebug()  << "url" << url;
    if (type == QWebEnginePage::NavigationTypeLinkClicked)
    {
//?        qDebug() << url;
    }
    return true;
   // return false;
}




int main(int argc, char *argv[])
{
 QApplication a(argc, argv);

 QMainWindow* mw = new QMainWindow;

 QTabWidget* qtw = new QTabWidget;



 MyWebView* wev = new MyWebView();
 //wev->setGeometry(0,0,700,600);

//?
 MyWebPage* mwp = new MyWebPage;

 QObject::connect(mwp, &MyWebPage::urlChanged,[](const QUrl &url){
  qDebug() << "r:" << url.toString();

 });

 QObject::connect(mwp, &MyWebPage::linkHovered,[](const QUrl &url){
  qDebug() << "H:" << url.toString();

 });

 MyPage* myp = new MyPage;
 QWebChannel* channel = new QWebChannel(wev);
 channel->registerObject(QStringLiteral("content"), myp);
 mwp->setWebChannel(channel);

 //?
 wev->setPage(mwp);

//?
 mwp->load(QUrl("file:///home/nlevisrael/volume/dgch/cpp/testdia/matterport/"));
// wev->page()->load(QUrl("https://matterport.com/3d-space/wotso-workspace/"));

 qtw->addTab(wev, "tw");

 mw->setCentralWidget(qtw);
 //mw->setGeometry(5,50,900,650);

 wev->show();
 mw->show();
 return a.exec();
}


#endif// HIDE
