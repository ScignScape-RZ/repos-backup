
#include "my-page.h"

MyPage::MyPage():QObject()
{

}

