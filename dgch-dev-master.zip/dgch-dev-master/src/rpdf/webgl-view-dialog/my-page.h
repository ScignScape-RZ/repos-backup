
#ifndef MY_PAGE__H
#define MY_PAGE__H

#include <QObject>

class MyPage : public QObject
{
public:
    MyPage();


};


#endif
