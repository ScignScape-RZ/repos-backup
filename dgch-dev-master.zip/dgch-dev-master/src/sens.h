
#ifndef SENS__H
#define SENS__H

#define USE_SENS

#ifdef USE_SENS

#define SENS_(X) \
 namespace SE { namespace X {

#define _SENS(X) \
 } }


#define SENS_CLASS_DECLARE(X ,C) \
 namespace SE { namespace X { class C; } }

#ifndef INNER_NS_
#define INNER_NS_(X) \
 namespace X{
#endif
     
#ifndef _INNER_NS
#define _INNER_NS(X) \
 }
#endif
 
#define USING_SENS(x) \
 using namespace SE::x;


#else

#define SENS_(X) \

#define _SENS(X) \

#define USING_SENS(x) \

#define INNER_NS_(X) 

#define _INNER_NS(X) 

#endif


#endif // SENS__H
