
#ifndef SE_TYPEDEFS__H
#define SE_TYPEDEFS__H

class QString;
class QTextStream;
class SE_Core_Rule;

typedef QString tString;
typedef QTextStream tStringStream;
typedef unsigned short tMid;
typedef int tInt;
typedef char tChar;

typedef tInt tyId;


typedef tInt Flag_or_Depth;
typedef tString tNodeLabel;
typedef SE_Core_Rule tRule;

#include <QString>
#include <fstream>

struct SE_Utilities
{
 static void Load_File(QString file_path, QString& contents)
 {
  std::string c;
  std::ifstream ifs (file_path.toStdString());
  if(! ifs.is_open() )
   contents = "";
  std::getline(ifs, c, '\0');
  ifs.close();
  contents = QString::fromStdString(c);
 }
};


typedef SE_Utilities Utilities_type;

#define tMap QMap
#define tVec QVector


#endif
