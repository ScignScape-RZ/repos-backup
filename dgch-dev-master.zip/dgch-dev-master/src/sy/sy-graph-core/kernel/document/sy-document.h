
#ifndef SY_DOCUMENT__H
#define SY_DOCUMENT__H

#include "relae-graph/relae-node-ptr.h"

#include "kernel/sy-dominion.h"

#include "accessors.h"

#include "syns.h"

#include <QFile>
#include <QTextStream>



SYNS_(SYCore)

class SY_Parser;
class SY_Grammar;
class SY_Graph_Build;
class SY_Word_Entry_List;
class SY_Graph;
//class SY_Graph;


class SY_Document
{
 caon_ptr<SY_Graph> graph_;
 caon_ptr<SY_Parser> parser_;
 caon_ptr<SY_Graph_Build> graph_build_;
 caon_ptr<SY_Grammar> grammar_;

 QString local_path_;
 QString raw_text_;

 QString local_directory_;

 void resolve_report_path(QString& path);

 int number_of_lines_;

 void preprocess_raw_text();
 static QString insert_block_map_signatures(QString original_source, QString sig);

public:


 ACCESSORS(QString ,local_path)
 ACCESSORS(QString ,raw_text)
 ACCESSORS(QString ,local_directory)
 ACCESSORS(caon_ptr<SY_Graph> ,graph)
 ACCESSORS__GET(caon_ptr<SY_Grammar> ,grammar)

 ACCESSORS(caon_ptr<SY_Graph_Build> ,graph_build)

 SY_Document(QString path);

 ~SY_Document();

 void load_file(QString path);
 void report_graph(QString path);

 QString sy_path_handlers();

 void write_report(QString path);

 void set_grammar(SY_Grammar* grammar = nullptr);

 void parse(int start_position = 0, int end_position = -1);

 template<typename T>
 void write_report(QString path, T& report)
 {
  resolve_report_path(path);
  QFile file(path);
  if(file.open(QFile::WriteOnly | QIODevice::Text))
  {
   QTextStream qts(&file);
   report.write_report(qts);
  }
 }



};

_SYNS(SYCore)


#endif

