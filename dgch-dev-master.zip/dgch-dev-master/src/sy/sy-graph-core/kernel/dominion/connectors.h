 
DOMINION_CONNECTOR(N_A, "No Connection")
DOMINION_CONNECTOR(Run_Function_Def_Entry, "run-function-def-entry")
DOMINION_CONNECTOR(Run_Call_Entry, "run-call-entry")
DOMINION_CONNECTOR(Run_Data_Entry, "run-data-entry")
DOMINION_CONNECTOR(Run_Call_Sequence, "run-call-sequence")
DOMINION_CONNECTOR(Run_Cross_Sequence, "run-cross-sequence")
DOMINION_CONNECTOR(Run_Fundef_Map_Key_Sequence, "run-fundef-map-key-sequence")

//  This may be obsolete
//?2DOMINION_CONNECTOR(Run_Fundef_Map_Key_Sequence_Ref, "run-fundef-map-key-sequence-ref")


DOMINION_CONNECTOR(Run_Cross_Entry, "run-cross-entry")
DOMINION_CONNECTOR(Run_Data_Leave, "run-data-leave")
DOMINION_CONNECTOR(Run_Cross_Data, "run-cross-data")
DOMINION_CONNECTOR(Run_Data_Sequence, "run-data-sequence")
DOMINION_CONNECTOR(Run_Block_Entry, "run-block-entry")
DOMINION_CONNECTOR(Block_Info, "block-info")
DOMINION_CONNECTOR(Run_Cross_Block, "run-cross-block")
