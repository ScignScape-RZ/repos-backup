
#ifndef SY_FRAME__H
#define SY_FRAME__H

#include "sy-frame.h"

#include "relae-graph/relae-node-ptr.h"

#include "kernel/sy-dominion.h"

#include "syns.h"

SYNS_(SYCore)


class SY_Frame : public node_frame<SY_Dominion>
{
 SY_Frame();
 // SY_Dominion::Connectors N_A;
 public:

 static SY_Frame& instance();

};

_SYNS(SYCore)

#endif
