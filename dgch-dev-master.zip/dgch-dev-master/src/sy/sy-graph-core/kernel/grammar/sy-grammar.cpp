
#include "sy-grammar.h"

#include "kernel/grammar/sy-parse-context.h"

#include "kernel/grammar/sy-graph-build.h"

#include "kernel/grammar/sy-parser.h"

#include "relae-graph/relae-parser.templates.h"

USING_SYNS(SYCore)

SY_Grammar::SY_Grammar()
// : Node_Parser<SY_Galaxy>(g)
{
}

void SY_Grammar::init(SY_Parser& p, SY_Graph& g, SY_Graph_Build& graph_build)
{
 // //  Check for package privates...?
 pre_rule( "script-word", "(?:[^{}()\\[\\]\\s`;,:]|(?:\\w::?\\w))+" );
 pre_rule( "ns-word", "(?: [^{}()\\[\\]\\s`;,:]+ )" );

//? pre_rule( "space-to-end-of-line", "[__\\t]* (?: ;- [^\\n]+ )? (?= \\n )" );
//? pre_rule( "end-of-line", "[__\\t\\S]* \\n" );
 pre_rule( "single-space", "[__\\t]" );

 pre_rule( "namespaced-word", "[\\w-:]+" );


 Context run_context = add_context("run-context");
 Context lisp_context = add_context("lisp-context");


 track_context({&run_context, &lisp_context});

// Context run_or_print_context = add_context("run-or-print",
// {run_context, print_context});

// Context run_or_lara_context = add_context("run-or-lara",
// {run_context, lara_context});

// Context run_or_chi_tile_context = add_context("run-or-chi-tile",
// {run_context, chi_tile_context});

 activate(run_context);

 SY_Parse_Context& parse_context = graph_build.parse_context();

 add_rule( run_context, "run-tuple-indicator",
  " (?<prefix> [;,:_+`'#$%^*~!@\\-\\.]* )"
  " (?<entry> (?: \\{{2,3} ) | (?: \\}{2,3}) | "
  "   (?: \\[{2,3} ) | (?: \\]{2,3}) | [ [({}\\])] )"
  " (?<suffix> [*~]* (?=\\s) )?"
   ,[&]
 {
  QString prefix = p.matched("prefix");
  QString entry = p.matched("entry");
  QString suffix = p.matched("suffix");
  graph_build.check_enter_tuple(prefix, entry, suffix);
 });

 add_rule( run_context, "raw-lisp-start",
  " lisp_ ",
   [&]
 {
  graph_build.raw_lisp_start();
 });
//?

 add_rule( run_context, "run-token-with-eol",
  " (?<prefix> [:,;`']* )"
  " (?<word> .script-word.) "
  " (?<suffix> :? ) ",
                      //?  " (?<eol> .space-to-end-of-line. \\n)?",
   [&]
 {
  QString prefix = p.matched("prefix");
  QString m = p.matched("word");
  QString suffix = p.matched("suffix");
   //?QString s = p.matched("eol");
  graph_build.add_run_token(prefix, m, suffix); //?, SY_Graph_Build::Token_Formations::Normal, s);
 });

}

//
#ifdef HIDE
//? parse_context.flags.pre_markup = true;

//?
// add_rule(flags_all_(parse_context ,take_a_space), run_context, "take-a-space",
//   " .single-space. ",
//   [&]
//  {
//   graph_build.finalize_take_a_space();
//  } );



 //?
// add_rule(flags_all_(parse_context ,inside_run_acc), run_context,
//  "possible-run-acc-end",
//  ".script-word. | ."
//  ,[&]
// {
//  QString s = p.match_text();
//  graph_build.check_run_acc(s);
// });



 add_rule( flags_all_(parse_context ,inside_string_literal), run_context,
  "string-literal-character",
  " (?: [^\\\"] | \\\\\" )+ ",
  [&]
 {
  QString str = p.match_text();
  if(str == "\\\"")
   str = "\"";
  graph_build.add_to_string_literal(str);
 });


 add_rule( flags_all_(parse_context ,inside_string_literal), run_context,
  "string-literal-end",
  " \" ",
  [&]
 {
  graph_build.process_string_literal();
  parse_context.flags.inside_string_literal = false;
 });


//?
// add_rule(flags_all_(parse_context ,inside_run_comment), run_context,
//  "multi-line-run-comment-end",
//  " (?<left> - -+ ) (?<right> ;+ ) "
//           ,[&]
// {
//  QString left = p.matched("left");
//  QString right = p.matched("right");
//  graph_build.check_run_comment_end(left.size(), right.size());
//  //qDebug() << "comment";
// });

// add_rule( run_context, "multi-line-run-comment-begin",
//  " (?<left> ;+ ) (?<right> - -+ ) .end-of-line. "
//  ,[&]
// {
//  QString left = p.matched("left");
//  QString right = p.matched("right");
//  graph_build.check_run_comment_begin(left.size(), right.size());
//  //qDebug() << "comment";
// });

// add_rule(flags_all_(parse_context ,inside_run_comment), run_context,
//  "multi-line-run-comment-body",
//  " (?: [^-;]+ ) | [;-] "
//   ,[&]
// {
//  QString s = p.match_text();
//  //?qDebug() << "S: " << s;
// });



// add_rule(flags_none_(parse_context ,inside_run_comment), run_context,
//  "run-comment",
//  " (?<left> ;+ - ) [^\\n]* "
//           ,[&]
// {
//  QString mt = p.match_text();
//  QString ml = p.matched("left");

// });


// add_rule( run_context, "raw-lisp-start-tmp",
//  " lisp_ ",
//   [&]
// {
//  graph_build.raw_lisp_start();
// });

//?

 add_rule( run_context, "raw-lisp-end",
  " _lisp ",
   [&]
 {
  graph_build.process_raw_lisp();
  parse_context.flags.inside_raw_lisp = false;
 });


 add_rule(flags_all_(parse_context ,inside_raw_lisp), run_context, "raw-lisp-text",
          " . "
          ,[&]
 {
  graph_build.add_to_raw_lisp(p.match_text());
 });


 add_rule( run_context, "string-literal-start",
  " \" ",
   [&]
 {
//  if(parse_context.flags.inside_xq_literal)
//    graph_build.add_to_xq_literal(p.match_text());
//  else
    graph_build.string_literal_start();
 });


 add_rule( run_context, "run-tuple-indicator",
  " (?<prefix> [;,:_+`'#$%^*~!@\\-\\.]* )"
  " (?<entry> (?: \\{{2,3} ) | (?: \\}{2,3}) | "
  "   (?: \\[{2,3} ) | (?: \\]{2,3}) | [ [({}\\])] )"
  " (?<suffix> [*~]* (?=\\s) )?"
   ,[&]
 {
  QString prefix = p.matched("prefix");
  QString entry = p.matched("entry");
  QString suffix = p.matched("suffix");
  graph_build.check_enter_tuple(prefix, entry, suffix);
 });

//?
// add_rule( run_context, "run-token-with-scope",
//  " (?<prefix> [`']* )"
//  " (?<ns> .ns-word. : )"
//  " (?<word> .script-word.) "
//  " (?<eol> .space-to-end-of-line. \\n)?",
//   [&]
// {
//  QString prefix = p.matched("prefix");
//  QString ns = p.matched("ns");

//  QString m = p.matched("word");
//  //QString suffix = p.matched("suffix");
//  QString s = p.matched("eol");
//  graph_build.add_run_token(prefix, ns + m, "", s);
// });



// // //?
// add_rule( run_context, "do-plus-block",
//  " (?<do> (?: /do/ ) | (?: do ) | (?: in ) )"
//  " \\s+ "
//  " (?<block-entry> [.]{2,}) "
//  ,[&]
// {
//  QString do_token = p.matched("do");
//  QString block_entry = p.matched("block-entry");

//  graph_build.add_token_plus_block(do_token, block_entry);
// });



// add_rule( run_context, "double-slash",
//  " (?<sl> / [\\w/]+ / )"
//  ,[&]
// {
//  QString sl = p.matched("sl");
//  if(sl != "///")
//  {
//   graph_build.add_run_token("", sl, "", SY_Graph_Build::Token_Formations::Normal);
//  }
// });

// add_rule( run_context, "if-?",
//  " (?<word> (?: if ) ) \\s+ (?<follow> (?: \\? \\?? ) | (?: not ) ) "
//  ,[&]
// {
//  QString w = p.matched("word");
//  QString f = p.matched("follow");
//  QString token = QString("%1-%2").arg(w).arg(f);
//  graph_build.add_run_token("", token, "", SY_Graph_Build::Token_Formations::Normal);
// });


// add_rule( run_context, "mvb-tokens",
//  " (?<core-fun> my )? \\s+ (?<words> (?<word> , .script-word. \\s+ ){2,} )"
//  " (?<setter> =)",
//   [&]
// {
//  QString core_fun = p.matched("core-fun");
//  QString words = p.matched("words");
//  QString setter = p.matched("setter");
//  graph_build.add_mvb_tokens(words, setter, core_fun);
// });


// add_rule( run_context, "run-token-with-ns",
//  " (?<prefix> [:,;`']* )"
//  " (?<ns> (?: .ns-word. : :? )+ )"
//  " (?<word> .script-word.) "
//  " (?<eol> .space-to-end-of-line. \\n)?",
//   [&]
// {
//  QString prefix = p.matched("prefix");
//  QString ns = p.matched("ns");

//  QString m = p.matched("word");
//  //QString suffix = p.matched("suffix");
//  QString s = p.matched("eol");
//  if(ns.endsWith("::"))
//  {
//   graph_build.add_run_token(prefix, ns + m, "", SY_Graph_Build::Token_Formations::Cpp_Scoped, s);
//  }
//  else
//  {
//   graph_build.add_run_token(prefix, ns + m, "", SY_Graph_Build::Token_Formations::Normal, s);
//  }
// });

 // add_rule( run_context, "type-indicator",
 //  " <- ",
 //   [&]
 // {
 //  QString match_text = p.match_text();
 //  graph_build.add_type_indicator(match_text);
 // });

 // add_rule( run_context, "equalizer-to-type",
 //  " == ",
 //   [&]
 // {
 //  QString match_text = p.match_text();
 //  graph_build.add_equalizer_to_type(match_text);
 // });

// add_rule( run_context, "pending-symbol-modify-to-method",
//  " --> ",
//   [&]
// {
//  QString match_text = p.match_text();
//  graph_build.pending_symbol_modify_to_method(match_text);
// });

// add_rule(flags_all_(parse_context ,arrow_pending_symbol_modify_to_method),
//   run_context, "arrow-pending-symbol-modify-to-method",
//  " -> ",
//   [&]
// {
//  parse_context.flags.arrow_pending_symbol_modify_to_method = false;
//  QString match_text = p.match_text();
//  graph_build.pending_symbol_modify_to_method(match_text);
// });



// add_rule( run_context, "run-token-with-pre-arrow",
//  " (?<pre-arrow> >- ) \\s*"
//  " (?<word> .script-word.)"
//  " (?<eol> .space-to-end-of-line. \\n)?",
//   [&]
// {
//  QString pa = p.matched("pre-arrow");
//  QString m = p.matched("word");
//  QString s = p.matched("eol");
//  if(m == "->")
//  {
//   //  i.e. the token is just >--> ...
//  }
//  else
//  {
//   parse_context.flags.arrow_pending_symbol_modify_to_method = true;
//  }
//  graph_build.add_run_token("", pa + m, "", SY_Graph_Build::Token_Formations::Normal, s);
// });

// add_rule( run_context, "run-token-with-arrow-paste",
//  " (?<prefix> [:,;`']* )"
//  " (?<word> .script-word.)"
//  " (?<suffix> :? ) "
//  " \\s+ (?<arrow>  (?: (?: \\|\\| ) | /)  --)"
//  " (?<eol> .space-to-end-of-line. \\n)?",
//   [&]
// {
//  QString prefix = p.matched("prefix");
//  QString m = p.matched("word");
//  //?
//  QString suffix = p.matched("suffix");
//  QString s = p.matched("eol");
//  QString ar = p.matched("arrow");
//  if(ar == "/--")
//   ar = "||--";
//  graph_build.add_run_token(prefix, m + ar, suffix, SY_Graph_Build::Token_Formations::Normal, s);
// });

// add_rule( run_context, "run-token-with-callback-paste",
//  " (?<prefix> [:,;`']* )"
//  " (?<word> .script-word.)"
//  " (?<suffix> :? ) "
//  " \\s+ (?: (?: \\|\\|\\| ) | /)  \\s+ (?<callback> .script-word.)"
//  " (?<eol> .space-to-end-of-line. \\n)?",
//   [&]
// {
//  QString prefix = p.matched("prefix");
//  QString m = p.matched("word");
//  //?
//  QString suffix = p.matched("suffix");
//  QString s = p.matched("eol");
//  QString cb = p.matched("callback");
//  graph_build.add_run_token(prefix, m + "||" + cb, suffix, SY_Graph_Build::Token_Formations::Normal, s);
// });


// add_rule( run_context, "run-token-type-related-function",
//  " (?<word> ::: ) "
//  " (?<eol> .space-to-end-of-line. \\n)?",
//   [&]
// {
//  QString m = p.matched("word");
//  QString s = p.matched("eol");
//  graph_build.add_run_token("", m, "", SY_Graph_Build::Token_Formations::Normal, s);
// });


 // add_rule( run_context, "run-token-semis",
 //  " (?<word> ;+ )"
 //  " (?<eol> .space-to-end-of-line. \\n)?",
 //   [&]
 // {
 //  QString m = p.matched("word");
 //  QString s = p.matched("eol");
 //  graph_build.add_semis(m, s);
 // });

 //?

#endif //def HIDE

