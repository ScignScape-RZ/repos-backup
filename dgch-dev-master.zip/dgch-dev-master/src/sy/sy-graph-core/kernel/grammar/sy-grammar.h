
#ifndef SY_GRAMMAR__H
#define SY_GRAMMAR__H

//#include "rz-parser/rz-regex.h"
//#include "rz-parser/rz-parser.h"
//#include "accessors.h"

#include "relae-graph/relae-grammar.h"

#include "kernel/sy-dominion.h"

#include "syns.h"


SYNS_(SYCore)

class SY_Graph;
class SY_Graph_Build;
class SY_Parser;

class SY_Grammar : public Relae_Grammar<SY_Graph, SY_Parser>
{

public:

 SY_Grammar();



 void init(SY_Parser& p, SY_Graph& g,
           SY_Graph_Build& graph_build);


};

_SYNS(SYCore)

//#include "rz-parser/rz-regex.h"
//#include "rz-parser/rz-parser.h"

//#include "rz-text-typedefs.h"

//class RZ_Text_Parser : public RZ_Parser<RZ_Text_Galaxy>
//{
//public:
// RZ_Text_Parser(RZ_Text_Graph* g);
// void set_raw_text(QString s);


//};

//typedef RZ_Parser<RZ_Text_Galaxy> RZ_Text_Parser;

#endif
