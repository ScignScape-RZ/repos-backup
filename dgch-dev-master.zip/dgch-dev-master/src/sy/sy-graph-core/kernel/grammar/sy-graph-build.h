
#ifndef SY_GRAPH_BUILD__H
#define SY_GRAPH_BUILD__H

#include "flags.h"

#include "accessors.h"

#include "kernel/grammar/sy-parse-context.h"

#include "syns.h"
SYNS_(SYCore)

//USING_RZNS(RECore)

class SY_Graph;
class SY_Node;
class SY_Document;
class SY_Parser;
class SY_Graph;
class SY_Frame;


//flag_(1, inside_tag_body);
//flag_(2, inside_tag_command_main_argument);
//flag_(3, pre_markup);

class SY_Graph_Build
{
public:

 flags_(1)
  bool next_token_closes_expression:1;
  bool inside_array_with_formation:1;
 _flags

 QString acc_;

 SY_Parse_Context parse_context_;


 SY_Document* document_;
 SY_Parser& parser_;
 SY_Graph& graph_;

 SY_Frame& fr_;

 int current_line_;


public:

 SY_Graph_Build(SY_Document* d, SY_Parser& p, SY_Graph& g);

 ACCESSORS__RGET(SY_Parse_Context ,parse_context)

 void add_to_string_literal(QString str);
 void process_string_literal();
 void string_literal_start();

 void raw_lisp_start();
 void process_raw_lisp();
 void add_to_raw_lisp(QString str);

 void add_run_token(QString prefix, QString token, QString suffix);
 void check_enter_tuple(QString prefix, QString entry, QString suffix);

 void init();

};

_SYNS(SYCore)

#endif

