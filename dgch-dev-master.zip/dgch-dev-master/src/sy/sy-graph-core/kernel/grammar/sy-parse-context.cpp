
#include "sy-parse-context.h"

USING_SYNS(SYCore)


SY_Parse_Context::SY_Parse_Context(): Flags(0)
//,  current_open_print_node_(nullptr)
{

}


