
#ifndef SY_CONNECTION__H
#define SY_CONNECTION__H

#include "relae-graph/relae-node-ptr.h"

#include "kernel/sy-dominion.h"

#include <QTextStream>

#include "syns.h"
#include "accessors.h"

SYNS_(SYCore)

class Run_Call_Entry;
class SY_Node;

class SY_Connection
{
 caon_ptr<SY_Node> sy_node_;

public:

 ACCESSORS(caon_ptr<SY_Node> ,sy_node)

 SY_Connection(caon_ptr<SY_Node> sy_node);



};


_SYNS(SYCore)

#endif

