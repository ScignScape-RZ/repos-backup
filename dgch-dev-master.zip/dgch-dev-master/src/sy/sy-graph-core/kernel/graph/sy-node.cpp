
#include "sy-node.h"

#include "token/sy-token.h"

#include "syns.h"

USING_SYNS(SYCore)
USING_SYNS(GVal)

void SY_Node::each_connection(std::function<void(const SY_Connectors& connector,
 const SY_Node&, const SY_Connection* connection)> fn) const
{
 targets_iterator_type it(targets_);
 while(it.hasNext())
 {
  it.next();
  const SY_Connectors& connector = *it.key();
  const SY_Node& target = *it.value();
  fn(connector, target, nullptr);
 }

 annotated_targets_iterator_type ait(annotated_targets_);
 while(ait.hasNext())
 {
  ait.next();
  const SY_Connectors& connector = *ait.key();
  const SY_Connection* connection = ait.value().first.raw_pointer();
  const SY_Node& target = *ait.value().second;
  fn(connector, target, connection);

 }

}


caon_ptr<SE_Token> SY_Node::se_token()
{
 if(sy_token())
 {
  return sy_token()->se_token();
 }
 return nullptr;
}

void SY_Node::debug_connections()
{
 targets_iterator_type it(targets_);
 while(it.hasNext())
 {
  it.next();
  CAON_EVALUATE_DEBUG(SY_Connectors ,key ,it.key())
  CAON_EVALUATE_DEBUG(SY_Node ,value ,it.value())
  //?QString val = value.label();
 }
}


void SY_Node::swap_relation(const SY_Connectors& connector,
 caon_ptr<SY_Node> n1, caon_ptr<SY_Node> n2)
{
 CAON_PTR_DEBUG(SY_Node ,n1)
 CAON_PTR_DEBUG(SY_Node ,n2)


 #ifdef NO_CAON
   SY_Connectors* pc = const_cast<SY_Connectors*>( &connector );
   targets_.remove(pc, n1);
   targets_.insert(pc, n2);
 #else
  targets_.remove(&connector, n1);
  targets_.insert(&connector, n2);
 #endif //NO_CAON

 //caon_ptr<SY_Node>& old = n1->targets_.
}


void SY_Node::delete_relation(const SY_Connectors& connector,
 caon_ptr<SY_Node> n1)
{
 CAON_PTR_DEBUG(SY_Node ,n1)
  #ifdef NO_CAON
    SY_Connectors* pc = const_cast<SY_Connectors*>( &connector );
    targets_.remove(pc, n1);
  #else
   targets_.remove(&connector, n1);
  #endif //NO_CAON
}

