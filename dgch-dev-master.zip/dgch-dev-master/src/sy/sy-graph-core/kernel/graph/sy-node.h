
#ifndef SY_NODE__H
#define SY_NODE__H

#include "relae-graph/relae-node-ptr.h"

#include "kernel/sy-dominion.h"

#include "kernel/frame/sy-frame.h"

#include <functional>

#include "syns.h"
#include "sens.h"

SYNS_CLASS_DECLARE(GVal ,SE_Token)

USING_SYNS(GVal)

//SYNS_(GBuild)
// class SE_Token;
//_SYNS(GBuild)


SYNS_(SYCore)

//?USING_SYNS(GBuild)

class SY_Node : public node_ptr<SY_Dominion>
{
public:
 #define DOMINION_TYPE DOMINION_NODE_CONSTRUCTOR
 #include "kernel/dominion/types.h"
 #undef DOMINION_TYPE

 caon_ptr<SE_Token> se_token();

 void debug_connections();

 void each_connection(std::function<void(const SY_Connectors& connector,
  const SY_Node&, const SY_Connection* connection)> fn)  const;

 void swap_relation(const SY_Connectors& connector,
  caon_ptr<SY_Node> n1, caon_ptr<SY_Node> n2);

 void delete_relation(const SY_Connectors& connector,
  caon_ptr<SY_Node> n1);

};

_SYNS(SYCore)


#endif
