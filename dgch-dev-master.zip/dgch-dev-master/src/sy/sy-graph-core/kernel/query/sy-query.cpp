
#include "sy-query.h"

#include "syns.h"


USING_SYNS(SYCore)


SY_Query::SY_Query()
 : node_query<SY_Dominion>()
  #define DOMINION_CONNECTOR(name, label) \
    ,name(SY_Connectors(SY_Connectors_Case_Labels::name, label))
  #include "kernel/dominion/connectors.h"
  #undef DOMINION_CONNECTOR
{
 int order = 0;
 #define DOMINION_CONNECTOR(name, label) \
  name.order = order; \
  ++order;
 #include "kernel/dominion/connectors.h"
 #undef DOMINION_CONNECTOR
}

const SY_Query& SY_Query::instance()
{
 static SY_Query* the_instance = nullptr;
 if(!the_instance)
  the_instance = new SY_Query;
 return *the_instance;
}
