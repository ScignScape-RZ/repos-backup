
#ifndef SY_QUERY__H
#define SY_QUERY__H

#include "kernel/sy-dominion.h"

#include "relae-graph/relae-node-ptr.h"

#include "syns.h"

SYNS_(SYCore)

//class SY_Connector
//{
// //public:
// QString label_;

// public:
//  SY_Connector(QString label) : label_(label){}

//};

//template<type

class SY_Query : public node_query<SY_Dominion>
{
 SY_Query();
 // SY_Dominion::Connectors N_A;
 public:
  #define DOMINION_CONNECTOR(name, label) \
   SY_Connectors name;
  #include "kernel/dominion/connectors.h"
  #undef DOMINION_CONNECTOR

 static const SY_Query& instance();
};

_SYNS(SYCore)

#endif
