
#ifndef SY_SY_DOMINION__H
#define SY_SY_DOMINION__H


#include "relae-graph/relae-node-ptr.h"
#include "relae-graph/relae-caon-ptr.h"

//?#include "sy-graph-sre/sy-read-table-state.h"

#include "syns.h"



#define DOMINION_HIDE_NO_NAMESPACE
#define DOMINION_TYPE DOMINION_TYPE_DECLARE
#include "dominion/types.h"
#undef DOMINION_TYPE
#undef DOMINION_HIDE_NO_NAMESPACE


SYNS_(SYCore)

struct SY_Galaxy;
class SY_Node;
class SY_Connectors;
class SY_Connection;
class SY_Annotated_Connectors;
class SY_Frame;
class SY_Document;
class SY_Graph;
class SY_Root;
class SY_Token;

struct SY_Dominion
{
 typedef SY_Galaxy Galaxy_type;
 typedef SY_Node Node_type;
 typedef SY_Frame Frame_type;
 typedef SY_Connectors Connectors_type;
 typedef SY_Connection Connection_type;
 typedef SY_Annotated_Connectors Annotated_Connectors_type;
 typedef SY_Document Document_type;
 typedef SY_Graph Graph_type;
 typedef SY_Root Root_type;

// struct Connectors : node_connectors<SY_Dominion> {

//    Connectors(QString label) : node_connectors<SY_Dominion>(label){}

// };

 enum class Type_Codes { N_A,
  #define DOMINION_TYPE DOMINION_TYPE_ENUM
  #include "dominion/types.h"
  #undef DOMINION_TYPE
 };

 template<typename T>
 Type_Codes get_type_code()
 {
 }
 //typedef Test_Connector Connector_Type;
 // typedef Test_Type_Codes Connector_Type;

};



struct SY_Galaxy : Node_Ptr_Default_Galaxy<SY_Dominion>
{
 typedef SY_Token SY_Token_type;
// typedef SY_State SY_State_type;
// typedef SY_Clasp_Source_Element Source_Element_type;

};

enum class SY_Connectors_Case_Labels
{
 #define DOMINION_CONNECTOR(name, label) \
  name,
 #include "sy-graph-core/kernel/dominion/connectors.h"
 #undef DOMINION_CONNECTOR
};

struct SY_Connectors : node_connectors<SY_Dominion>
{
  SY_Connectors(SY_Connectors_Case_Labels cl = SY_Connectors_Case_Labels::N_A,
    QString label = QString())
   : node_connectors<SY_Dominion>(label), case_label(cl),
     priority(0), order(0){}
  SY_Connectors_Case_Labels case_label;
  int priority;
  int order;
  bool operator<(const SY_Connectors& rhs) const
  {
   return order < rhs.order;
  }
  operator bool() const
  {
   return order > 0;
  }
};

struct SY_Annotated_Connectors :
  node_annotated_connectors<SY_Dominion>
{
 SY_Annotated_Connectors(const SY_Connectors& conn,
   caon_ptr<SY_Connection> cion)
   : node_annotated_connectors<SY_Dominion>{conn, cion} {}

};



//class SY_Node : public node_ptr<SY_Dominion>
//{
//public:
// #define DOMINION_TYPE DOMINION_NODE_CONSTRUCTOR
// #include "dominion/types.h"
// #undef DOMINION_TYPE
//};

_SYNS(SYCore)


#endif
