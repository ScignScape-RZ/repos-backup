
#ifndef SY_RE_ROOT__H
#define SY_RE_ROOT__H


#include "relae-graph/relae-node-ptr.h"

#include "sy-dominion.h"

#include "syns.h"

SYNS_(SYCore)

class SY_Document;

class SY_Root
{
 SY_Document* document_;

public:

 SY_Root(SY_Document* document);

 QString document_path();
};

_SYNS(SYCore)


#endif
