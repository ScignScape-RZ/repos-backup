
#ifndef SYNS__H
#define SYNS__H

#define USE_SYNS

#ifdef USE_SYNS

#define SYNS_(X) \
 namespace SY { namespace X {

#define _SYNS(X) \
 } }


#define SYNS_CLASS_DECLARE(X ,C) \
 namespace SY { namespace X { class C; } }

#ifndef INNER_NS_
#define INNER_NS_(X) \
 namespace X{
#endif
     
#ifndef _INNER_NS
#define _INNER_NS(X) \
 }
#endif
 
#define USING_SYNS(x) \
 using namespace SY::x;


#else

#define SYNS_(X) \

#define _SYNS(X) \

#define USING_SYNS(x) \

#define INNER_NS_(X) 

#define _INNER_NS(X) 

#endif


#endif // SYNS__H
