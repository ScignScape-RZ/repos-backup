
//#ifndef RELAE_GENERIC_PARSER__H
//#define RELAE_GENERIC_PARSER__H

////#include "RELAE-parser/RELAE-regex.h"
////#include "RELAE-parser/RELAE-parser.h"

//#include "methodic.h"

//class RELAE_Document_Graph;

//struct RELAE_Generic_Galaxy
//{
// typedef void tGraph;

//};


//class RELAE_Generic_Parser : public RELAE_Parser<RELAE_Generic_Galaxy>
//{

//public:
// RELAE_Generic_Parser(void* v);

//};

////#include "RELAE-parser/RELAE-regex.h"
////#include "RELAE-parser/RELAE-parser.h"

////#include "RELAE-text-typedefs.h"

////class RELAE_Text_Parser : public RELAE_Parser<RELAE_Text_Galaxy>
////{
////public:
//// RELAE_Text_Parser(RELAE_Text_Graph* g);
//// void set_raw_text(QString s);


////};

////typedef RELAE_Parser<RELAE_Text_Galaxy> RELAE_Text_Parser;

//#endif
