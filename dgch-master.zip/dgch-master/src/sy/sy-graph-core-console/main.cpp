
#include <QDebug>

#include "sy-graph-core/kernel/document/sy-document.h"

#include "syns.h"

USING_SYNS(SYCore)

void compile_sy(QString file_name)
{
 QString result;
//? RZ_QClasp_Generator::compile_rz(file, result);


 SY_Document* doc = new SY_Document(file_name);
 doc->parse();

 doc->report_graph(file_name + ".txt");
}

int main(int argc, char* argv[])
{
 qDebug() << "Compiling R/Z to PreDynamo: /ext_root/kauv/qry-cmd/rz/t1.rz";
 compile_sy("/ext_root/dgch/t1.sy");
}

