
#include "sy-document.h"

#include "relae-graph/relae-parser.templates.h"

#include "kernel/graph/sy-graph.h"
#include "kernel/grammar/sy-grammar.h"
#include "kernel/grammar/sy-parser.h"
#include "kernel/grammar/sy-graph-build.h"

#include <QFileInfo>
#include <QDir>

USING_SYNS(SYCore)


SY_Document::SY_Document(QString path)
 : graph_(nullptr), grammar_(nullptr), number_of_lines_(0)
{
 if(!path.isEmpty())
  load_file(path);
}

void SY_Document::load_file(QString path)
{
 QFile file(path);
 if(file.open(QFile::ReadOnly | QIODevice::Text))
 {
  raw_text_ = file.readAll();
  local_path_ = path;
  QFileInfo qfi(local_path_);
  local_directory_ = qfi.absoluteDir().absolutePath();
 }
}


void SY_Document::resolve_report_path(QString& path)
{
 if(path.startsWith('.'))
 {
  path = path.mid(1);
  if(path.startsWith('.'))
  {
   path = local_path_ + path;
  }
  else
  {
//   QFileInfo qfi(local_path_);
  }
 }
}

void SY_Document::report_graph(QString path)
{
 resolve_report_path(path);
 QFile file(path);
 if(file.open(QFile::WriteOnly | QIODevice::Text))
 {
  QTextStream qts(&file);
  if(graph_)
   graph_->report(qts);
 }
}


void SY_Document::set_grammar(SY_Grammar* grammar)
{
 if(grammar)
  grammar_ = grammar;
 else
  grammar_ = new SY_Grammar();
}



void SY_Document::parse(int start_position, int end_position)
{
//? preprocess_raw_text();



// caon_ptr<SY_Root> root = new SY_Root(this);
// caon_ptr<SY_Node> node = new SY_Node(root);
// RELAE_SET_NODE_LABEL(node, "<root>");
 graph_ = new SY_Graph();
// graph_->set_document(this);
 parser_ = new SY_Parser(graph_);
 parser_->set_raw_text(raw_text_);
// graph_build.reset_graph();

 graph_build_ = new SY_Graph_Build(this, *parser_, *graph_);
 graph_build_->init();

 grammar_ = new SY_Grammar;

 grammar_->init(*parser_, *graph_, *graph_build_);

// grammar_->activate_context(print);

 grammar_->compile(*parser_, *graph_, raw_text_, start_position);
}

SY_Document::~SY_Document()
{

}


