
#include "sy-graph-build.h"

#include "kernel/frame/sy-frame.h"

USING_SYNS(SYCore)




SY_Graph_Build::SY_Graph_Build(SY_Document* d, SY_Parser& p, SY_Graph& g)
 : Flags(0)
   ,document_(d)
   ,graph_(g)
   ,parser_(p)
   ,current_line_(1)
   ,fr_(SY_Frame::instance())
   //?,current_position_state_(Position_States::Root_Position)
{

}

void SY_Graph_Build::init()
{

}

void SY_Graph_Build::raw_lisp_start()
{

}

void SY_Graph_Build::process_raw_lisp()
{

}

void SY_Graph_Build::add_to_raw_lisp(QString str)
{

}

void SY_Graph_Build::string_literal_start()
{

}

void SY_Graph_Build::add_to_string_literal(QString str)
{

}

void SY_Graph_Build::process_string_literal()
{

}

void SY_Graph_Build::add_run_token(QString prefix, QString token, QString suffix)
{

}

void SY_Graph_Build::check_enter_tuple(QString prefix, QString entry, QString suffix)
{

}

