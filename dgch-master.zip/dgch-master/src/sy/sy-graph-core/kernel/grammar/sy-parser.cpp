
#include "sy-parser.h"

USING_SYNS(SYCore)

SY_Parser::SY_Parser(caon_ptr<SY_Graph> g)
 : Relae_Parser<SY_Galaxy>(g)
{
}

