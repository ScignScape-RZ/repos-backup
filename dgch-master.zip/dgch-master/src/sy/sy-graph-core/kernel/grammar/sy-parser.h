
#ifndef SY_PARSER__H
#define SY_PARSER__H

#include "relae-graph/relae-parser.h"

#include "kernel/sy-dominion.h"

#include "syns.h"
SYNS_(SYCore)

//USING_RZNS(RECore)

class SY_Graph;

class SY_Parser : public Relae_Parser<SY_Galaxy>
{
 QString raw_text_;

public:

// // ACCESSORS(SY_Graph* ,graph)
 ACCESSORS(QString ,raw_text)

 //ACCESSORS(SY_Graph* ,graph)

 SY_Parser(caon_ptr<SY_Graph> g);

// QString get_remainder();


};

_SYNS(SYCore)

//#include "rz-parser/rz-regex.h"
//#include "rz-parser/rz-parser.h"

//#include "rz-text-typedefs.h"

//class RZ_Text_Parser : public RZ_Parser<RZ_Text_Galaxy>
//{
//public:
// RZ_Text_Parser(RZ_Text_Graph* g);
// void set_raw_text(QString s);


//};

//typedef RZ_Parser<RZ_Text_Galaxy> RZ_Text_Parser;

#endif
