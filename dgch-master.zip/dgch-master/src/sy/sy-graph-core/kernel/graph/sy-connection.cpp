
#include "sy-connection.h"


#include "syns.h"
USING_SYNS(SYCore)

SY_Connection::SY_Connection(caon_ptr<SY_Node> sy_node)
 : sy_node_(sy_node)
{

}
