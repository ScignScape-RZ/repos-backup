
#ifndef SY_GRAPH__H
#define SY_GRAPH__H

#include "relae-graph/relae-node-ptr.h"

#include "kernel/sy-dominion.h"

#include <QTextStream>

#include "syns.h"

SYNS_(SYCore)


class SY_Graph : public node_graph<SY_Dominion>
{
 public:
  SY_Graph(caon_ptr<SY_Node> root_node = nullptr);

 void report(QTextStream& qts);
 void report_from_node(QTextStream& qts,
  const SY_Node& node, int indent = 0);

};

_SYNS(SYCore)


#endif
