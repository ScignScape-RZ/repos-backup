
#include "sy-root.h"

#include "kernel/document/sy-document.h"

#include "syns.h"

USING_SYNS(SYCore)


SY_Root::SY_Root(SY_Document* document)
  : document_(document)
{

}

QString SY_Root::document_path()
{
 return document_->local_path();
}
