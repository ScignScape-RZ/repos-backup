
#ifndef KOFTL_BASE__H
#define KOFTL_BASE__H

#include <QList>

#include <functional>

#include "flags.h"

#define do_ (

#define _do )

#define _then_ ,

#define KF_CHECKED void* kf_supervisor

#define kf_checked void* kf_supervisor,

#define _KF_ Inner_Supervisor kf_ins(kf_supervisor);

#define KF_BREAK kf_ins.break_return(); return
#define KF_CONTINUE return




class KF_Supervisor_Exception
{

};

enum class KF_Validation_States {
 N_A = 0,

 State_Holds_Pointer = 1,
 State_Passed_Off = 1 << 1,

 Jacket_Created = 1 << 3,
 Written = 1 << 4, Read = 1 << 5, Method_Called = 1 << 6,

 Read_Block = 1 << 8, //256,
 Read_Allow = 1 << 9, //512,
 Read_Mandate = 1 << 10, //1024,

 Read_Block_Lambda_Transitive = 1 << 11, //2048,
 Read_Allow_Lambda_Transitive = 1 << 12,  //4096,
 Read_Mandate_Lambda_Transitive = 1 << 13, //8192,

 Read_Block_Sigma_Transitive = 1 << 14, //16384,
 Read_Allow_Sigma_Transitive = 1 << 15, //32768,
 Read_Mandate_Sigma_Transitive = 1 << 16, //65536,


 Write_Block = 1 << 20, //256,
 Write_Allow = 1 << 21, //512,
 Write_Mandate = 1 << 22, //1024,

 Write_Block_Lambda_Transitive = 1 << 23, //2048,
 Write_Allow_Lambda_Transitive = 1 << 24,  //4096,
 Write_Mandate_Lambda_Transitive = 1 << 25, //8192,

 Write_Block_Sigma_Transitive = 1 << 26, //16384,
 Write_Allow_Sigma_Transitive = 1 << 27, //32768,
 Write_Mandate_Sigma_Transitive = 1 << 28, //65536,


 Run_Block = 1 << 32, //256,
 Run_Allow = 1 << 33, //512,
 Run_Mandate = 1 << 34, //1024,

 Run_Block_Lambda_Transitive = 1 << 35, //2048,
 Run_Allow_Lambda_Transitive = 1 << 36,  //4096,
 Run_Mandate_Lambda_Transitive = 1 << 37, //8192,

 Run_Block_Sigma_Transitive = 1 << 38, //16384,
 Run_Allow_Sigma_Transitive = 1 << 39, //32768,
 Run_Mandate_Sigma_Transitive = 1 << 40, //65536,

};


//void KF_Reset_State(KF_Validation_States state,
//  quint64& code, KF_Validation_States flag)
//{
//}


inline void KF_Validation_Set_State(KF_Validation_States& state,
  KF_Validation_States flag)
{
 quint64& rs = *reinterpret_cast<quint64*>(&state);
 if( (rs & 1) == 0)
 {
  rs = (quint64) flag;
 }
 else
 {
  KF_Validation_States* ps = reinterpret_cast<KF_Validation_States*>
   (rs ^ 1);  // ((quint64) state ^ 1);
  quint64& rps = *reinterpret_cast<quint64*>(ps);
  rps = (quint64) flag;
 }
}


inline void KF_Validation_Set_Initial_State(KF_Validation_States& state,
  KF_Validation_States flag)
{
 quint64& rs = *reinterpret_cast<quint64*>(&state);
 rs = (quint64) flag;
}


inline void KF_Validation_Set_Initial_State(KF_Validation_States& state,
  quint64 value)
{
 quint64& rs = *reinterpret_cast<quint64*>(&state);
 rs = value;
}



inline void KF_Validation_Set_State(KF_Validation_States& state,
  quint64 value)
{
 quint64& rs = *reinterpret_cast<quint64*>(&state);
 if( (rs & 1) == 0)
 {
  rs = value;
 }
 else
 {
  KF_Validation_States* ps = reinterpret_cast<KF_Validation_States*>
   (rs ^ 1);  // ((quint64) state ^ 1);
  quint64& rps = *reinterpret_cast<quint64*>(ps);
  rps = value;
 }
}


inline void KF_Validation_Set_State_Flag(KF_Validation_States& state,
  //quint64& code,
  KF_Validation_States flag)
{
 quint64& rs = *reinterpret_cast<quint64*>(&state);
 if( (rs & 1) == 0)
    //( (quint64) state & 1) == 0 )
 {
  rs |= (quint64) flag;
  //code = (quint64) state | (quint64) flag;
 }
 else
 {
  KF_Validation_States* ps = reinterpret_cast<KF_Validation_States*>
   (rs ^ 1);  // ((quint64) state ^ 1);
  quint64& rps = *reinterpret_cast<quint64*>(ps);
  //quint64& rps = reinterpret_cast<quint64>(*ps);
  rps |= (quint64) flag;
 }
}


inline bool KF_Validation_Check_Failed_State_Flag(const KF_Validation_States& state,
  //quint64& code,
  KF_Validation_States flag)
{
 quint64 rs = (quint64) state;
 quint64 flag_code = ((quint64) flag) | ((quint64) KF_Validation_States::State_Passed_Off);

 if( (rs & 1) == 0)
 {
  return (rs & flag_code) == 0;
 }
 // //  here we're just testing whether the state is actually
  //    a pointer to a state
 if(flag == KF_Validation_States::State_Holds_Pointer)
 {
  return true;
 }
 else
 {
  KF_Validation_States* ps = reinterpret_cast<KF_Validation_States*>
   (rs ^ 1);  // ((quint64) state ^ 1);
  quint64& rps = *reinterpret_cast<quint64*>(ps);
  //quint64& rps = reinterpret_cast<quint64>(*ps);
  return (rps & flag_code) == 0;
  //rps |= (quint64) flag;
 }
}

inline bool KF_Validation_Check_State_Flag(const KF_Validation_States& state,
  KF_Validation_States flag)
{
 quint64 rs = (quint64) state;
 quint64 flag_code = ((quint64) flag);// | ((quint64) KF_Validation_States::State_Passed_Off);

 if( (rs & 1) == 0)
 {
  return (rs & flag_code) != 0;
 }
 // //  here we're just testing whether the state is actually
  //    a pointer to a state
 if(flag == KF_Validation_States::State_Holds_Pointer)
 {
  return true;
 }
 else
 {
  KF_Validation_States* ps = reinterpret_cast<KF_Validation_States*>
   (rs ^ 1);  // ((quint64) state ^ 1);
  quint64& rps = *reinterpret_cast<quint64*>(ps);
  return (rps & flag_code) != 0;
 }
}



class Supervisor
{
 enum class Validation_States {
  N_A, Created, Confirmed_In_Yield, Post_Yield, Break_Yield
 };

 Validation_States state_;
public:
 Supervisor() : state_(Validation_States::Created)
 {

 }
 void check_in()
 {
  state_ = Validation_States::Confirmed_In_Yield;
 }
 void check_out()
 {
  state_ = Validation_States::Post_Yield;
 }
 void break_return()
 {
  state_ = Validation_States::Break_Yield;
 }
 void confirm_yield()
 {
  if(state_ != Validation_States::Post_Yield)
  {
   throw KF_Supervisor_Exception();
  }
 }
 bool break_requested()
 {
  return state_ == Validation_States::Break_Yield;
 }
};



class Inner_Supervisor
{
 Supervisor* sup_;

public:

 Inner_Supervisor(void* pv)
 {
  sup_ = static_cast<Supervisor*>(pv);
  sup_->check_in();
 }
 ~Inner_Supervisor()
 {
  sup_->check_out();
 }
 void break_return()
 {
  sup_->break_return();
 }
};

#endif
