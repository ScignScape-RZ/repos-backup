
#ifndef KOFTL_Grid2__H
#define KOFTL_Grid2__H

#include <QVector>

#include <functional>

//#include "flags.h"

#include "koftl-base.h"
#include "koftl-jacket-rX.h"

//#include "accessors.h"


template<typename VALUE_Type, typename LIST_Type>
struct kf_Grid2_
{
 typedef std::function<void(const VALUE_Type&, void*)> const_yield_function_type;
 typedef std::function<void(const VALUE_Type&, int, void*)> const_yield_index_function_type;

 typedef std::function<void(void*)> const_yield_check_type;


 void span(const_yield_function_type fn)
 {
  Supervisor sup;
  LIST_Type* _this = reinterpret_cast<LIST_Type*>(this);
  //void* kf_supervisor
  for(const VALUE_Type& v : *_this)
  {
   fn(v, &sup);
   sup.confirm_yield();
  }
 }

 void span(const_yield_index_function_type fn)
 {
  Supervisor sup;
  KF_Jacket_rX<const_yield_index_function_type> jfn(fn);
  LIST_Type* _this = reinterpret_cast<LIST_Type*>(this);
  //void* kf_supervisor
  int index = 0;
  for(const VALUE_Type& v : *_this)
  {
   jfn->operator()(v, index, &sup);
   if(sup.break_requested())
   {
    break;
   }
   else
   {
    ++index;
    sup.confirm_yield();
   }
  }
 }

 void span(const_yield_index_function_type fn, const_yield_check_type cfn)
 {
  Supervisor sup;
  LIST_Type* _this = reinterpret_cast<LIST_Type*>(this);
  //void* kf_supervisor
  int index = 0;
  for(const VALUE_Type& v : *_this)
  {
   fn(v, index, &sup);
   if(sup.break_requested())
   {
    break;
   }
   else
   {
    ++index;
    sup.confirm_yield();
    cfn(&sup);
   }
  }
 }


};

template<typename VALUE_Type>
class kf_Grid2 : public QVector<VALUE_Type>, public kf_Grid2_<VALUE_Type, QVector<VALUE_Type>>
{
 int width_;

public:

 typedef QVector<VALUE_Type> base;
 typedef Supervisor Supervisor_type;

 typedef std::function<void(const VALUE_Type&, void*)> const_yield_function_type;

 void set_dimensions(int w, int h)
 {
  width_ = w;
  this->base::resize(w * h);
 }

 int width()
 {
  return width_;
 }

 VALUE_Type& operator[](std::initializer_list<int> indices)
 {
  int i = indices.begin()[0];
  int j = indices.begin()[1];

  return base::operator[](i * width_ + j);
 }

 kf_Grid2(int w) : width_(w), base()
 {

 }


};

#endif
