
#ifndef KOFTL_GRID1__H
#define KOFTL_GRID1__H

#include <QVector>

#include <functional>

//#include "flags.h"

#include "koftl-base.h"
#include "koftl-jacket-rX.h"
#include "koftl-jacket-W.h"

#include <algorithm>    // std::shuffle
#include <array>        // std::array
#include <random>       // std::default_random_engine
#include <chrono>       // std::chrono::system_clock



template<typename VALUE_Type, typename List_Type>
struct kf_Grid1_
{
 typedef std::function<void(const VALUE_Type&, void*)> const_yield_function_type;
 typedef std::function<void(const VALUE_Type&, int, void*)> const_yield_index_function_type;
 typedef std::function<void(VALUE_Type&, int, void*)> yield_index_function_type;
 typedef std::function<void(KF_Jacket_W<VALUE_Type>, int, void*)> jacket_yield_index_function_type;

 typedef std::function<void(void*)> const_yield_check_type;


 void span(const_yield_function_type fn)
 {
  Supervisor sup;
  List_Type* _this = reinterpret_cast<List_Type*>(this);
  //void* kf_supervisor
  for(const VALUE_Type& v : *_this)
  {
   fn(v, &sup);
   sup.confirm_yield();
  }
 }

 void span(const_yield_index_function_type fn)
 {
  Supervisor sup;
  KF_Jacket_rX<const_yield_index_function_type> jfn(fn);
  List_Type* _this = reinterpret_cast<List_Type*>(this);
  //void* kf_supervisor
  int index = 0;
  for(const VALUE_Type& v : *_this)
  {
   jfn->operator()(v, index, &sup);
   if(sup.break_requested())
   {
    break;
   }
   else
   {
    ++index;
    sup.confirm_yield();
   }
  }
 }

 void span(yield_index_function_type fn)
 {
  Supervisor sup;
  KF_Jacket_rX<yield_index_function_type> jfn(fn);
  List_Type* _this = reinterpret_cast<List_Type*>(this);
  //void* kf_supervisor
  int index = 0;
  for(VALUE_Type& v : *_this)
  {
   jfn->operator()(v, index, &sup);
   if(sup.break_requested())
   {
    break;
   }
   else
   {
    ++index;
    sup.confirm_yield();
   }
  }
 }


 void span(jacket_yield_index_function_type fn)
 {
  Supervisor sup;
  KF_Jacket_rX<jacket_yield_index_function_type> jfn(fn);
  List_Type* _this = reinterpret_cast<List_Type*>(this);
  //void* kf_supervisor
  int index = 0;
  for(VALUE_Type& v : *_this)
  {
   jfn->operator()(& v, index, &sup);
   if(sup.break_requested())
   {
    break;
   }
   else
   {
    ++index;
    sup.confirm_yield();
   }
  }
 }

 void span(const_yield_index_function_type fn, const_yield_check_type cfn)
 {
  Supervisor sup;
  List_Type* _this = reinterpret_cast<List_Type*>(this);
  //void* kf_supervisor
  int index = 0;
  for(const VALUE_Type& v : *_this)
  {
   fn(v, index, &sup);
   if(sup.break_requested())
   {
    break;
   }
   else
   {
    ++index;
    sup.confirm_yield();
    cfn(&sup);
   }
  }
 }


};

template<typename VALUE_Type>
struct kf_Grid1 : public QVector<VALUE_Type>, kf_Grid1_<VALUE_Type, QVector<VALUE_Type>>
{
 typedef QVector<VALUE_Type> base;
 typedef Supervisor Supervisor_type;

 typedef std::function<void(const VALUE_Type&, void*)> const_yield_function_type;


 kf_Grid1(std::initializer_list<VALUE_Type> vs)
 {
  int min = vs.begin()[0];
  int max = vs.begin()[1];
  this->base::resize(max - min);
  this->span do_[min](W_(int ,v), int index, KF_CHECKED)
  {
   _KF_
   v *= min + index;
  }
  _do;

 }

 void shuffle()
 {
  unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();

  std::shuffle(this->begin(), this->end(), std::default_random_engine(seed));

 }

};

#endif
