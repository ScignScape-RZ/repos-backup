
#ifndef KOFTL_JACKET_W__H
#define KOFTL_JACKET_W__H

#include <QList>

#include <functional>

#include "flags.h"

#include "koftl-list.h"

#define W_(type ,sym) KF_Jacket_W<type> sym


template<typename VALUE_Type>
class KF_Jacket_W
{
 VALUE_Type* _this;


// union {
//  KF_Validation_States _state_;
//  quint64 code;
// } state_;

 mutable KF_Validation_States state_;

public:

 KF_Jacket_W(VALUE_Type* v)
  : //?Flags(0),
    _this(v)//, state_(0)
 {
  //KF_Validation_States flag = KF_Validation_States::Jacket_Created;
  KF_Validation_Set_Initial_State(state_, KF_Validation_States::Jacket_Created);

//  state_.code =
//    (quint64) KF_Validation_States::Jacket_Created;


  //flags.jacket_created = true;
 }

 KF_Jacket_W(const KF_Jacket_W& rhs)
  : _this(rhs._this) //,
    //state_(rhs.state_)
 {

  if(KF_Validation_Check_State_Flag(rhs.state_,
    KF_Validation_States::State_Holds_Pointer))
  {
   state_ = rhs.state_;
  }
  else
  {
   state_ = rhs.state_;
   //?
   KF_Validation_Set_State(rhs.state_, KF_Validation_States::State_Passed_Off);
  }

  //state_ = (quint64)(ps);
 }

 // VALUE_Type* operator->()
 // {
 //  state_.code |= (quint64) KF_Validation_States::Method_Called;
 //  //?flags.method_called = true;
 //  return _this;
 // }
 // operator VALUE_Type&()
 // {
 //  state_.code |= (quint64) KF_Validation_States::Read;
 //  //?flags.read = true;
 //  return *_this;
 // }

 template<typename RHS_Type>
 void operator=(RHS_Type rhs)
 {
  KF_Validation_Set_State_Flag(state_, //._state_, state_.code,
                               KF_Validation_States::Written);
  //? state_.code |= (quint64) KF_Validation_States::Written;
  //? flags.written = true;
  *_this = rhs;
 }

 template<typename RHS_Type>
 void operator*=(RHS_Type rhs)
 {
  KF_Validation_Set_State_Flag(state_, //? ._state_, //state_.code,
                               KF_Validation_States::Written);
  //? state_.code |= (quint64) KF_Validation_States::Written;
  //? flags.written = true;
  *_this = rhs;
 }

 ~KF_Jacket_W()
 {
  if(KF_Validation_Check_Failed_State_Flag(state_, KF_Validation_States::Written))
     //(state_.code & (quint64) KF_Validation_States::Written) == 0)
  {
   throw KF_Supervisor_Exception();
  }
 }


};



#endif
