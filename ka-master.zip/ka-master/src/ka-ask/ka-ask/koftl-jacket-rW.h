
#ifndef KOFTL_JACKET_rW__H
#define KOFTL_JACKET_rW__H

#include <QList>

#include <functional>

#include "flags.h"

#include "koftl-list.h"

#define rW_(type ,sym) KF_Jacket_rW<type> sym


template<typename VALUE_Type>
class KF_Jacket_rW
{
 VALUE_Type* _this;


 union {
  KF_Validation_States _state_;
  quint64 code;
 } state_;

public:

 KF_Jacket_rW(VALUE_Type* v)
  : //?Flags(0),
    _this(v)//, state_(0)
 {
  state_.code = (quint64) KF_Validation_States::Jacket_Created;
  //flags.jacket_created = true;
 }

 VALUE_Type* operator->()
 {
  state_.code |= (quint64) KF_Validation_States::Method_Called;
  //?flags.method_called = true;
  return _this;
 }

 operator VALUE_Type&()
 {
  state_.code |= (quint64) KF_Validation_States::Read;
  //?flags.read = true;
  return *_this;
 }

 template<typename RHS_Type>
 VALUE_Type& operator=(RHS_Type rhs)
 {
  state_.code |= (quint64) KF_Validation_States::Written;
  //flags.written = true;
  *_this = rhs;
 }

 ~KF_Jacket_rW()
 {
  if( (state_.code & (quint64) KF_Validation_States::Written) == 0)
  {
   throw KF_Supervisor_Exception();
  }
 }


};



#endif
