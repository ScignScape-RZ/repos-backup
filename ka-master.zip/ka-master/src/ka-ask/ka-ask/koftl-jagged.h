
#ifndef KOFTL_Jagged2__H
#define KOFTL_Jagged2__H

#include <QVector>

#include <functional>

//#include "flags.h"

#include "koftl-base.h"
#include "koftl-jacket-rX.h"
#include "koftl-jacket-W.h"
#include "koftl-jacket-rW.h"


//#include "accessors.h"


template<typename VALUE_Type, typename INNER_LIST_Type,  typename OUTER_LIST_Type>
struct kf_Jagged2_
{
 typedef std::function<void(const VALUE_Type&, int, int, void*)> const_yield_function_type;
 typedef std::function<void(const VALUE_Type&, int, int, int, void*)> const_yield_index_function_type;
 typedef std::function<void(VALUE_Type&, int, int, void*)> yield_function_type;

 typedef std::function<void(KF_Jacket_W<VALUE_Type>, int, int, void*)> jacket_yield_function_type;

 typedef std::function<void(void*)> const_yield_check_type;


 size_t total_length()
 {
  OUTER_LIST_Type* _this = reinterpret_cast<OUTER_LIST_Type*>(this);
  //void* kf_supervisor
  int result = 0;
  for(const INNER_LIST_Type& il : *_this)
  {
   result += il.length();
  }
  return result;
 }

 void span(const_yield_function_type fn)
 {
  Supervisor sup;
  OUTER_LIST_Type* _this = reinterpret_cast<OUTER_LIST_Type*>(this);
  //void* kf_supervisor
  int i = 0;
  for(const INNER_LIST_Type& il : *_this)
  {
   int j = 0;
   for(const VALUE_Type& v : il)
   {
    fn(v, i, j, &sup);
    sup.confirm_yield();
    ++j;
   }
   ++i;
  }
 }

 void span(const_yield_index_function_type fn)
 {
  Supervisor sup;
  OUTER_LIST_Type* _this = reinterpret_cast<OUTER_LIST_Type*>(this);
  //void* kf_supervisor
  int i = 0;
  int index = 0;
  for(const INNER_LIST_Type& il : *_this)
  {
   int j = 0;
   for(const VALUE_Type& v : il)
   {
    fn(v, i, j, index, &sup);
    sup.confirm_yield();
    ++j;
    ++index;
   }
   ++i;
  }
 }


 void span(yield_function_type fn)
 {
  Supervisor sup;
  OUTER_LIST_Type* _this = reinterpret_cast<OUTER_LIST_Type*>(this);
  //void* kf_supervisor
  int i = 0;
  for(INNER_LIST_Type& il : *_this)
  {
   int j = 0;
   for(VALUE_Type& v : il)
   {
    fn(v, i, j, &sup);
    sup.confirm_yield();
    ++j;
   }
   ++i;
  }
 }

void span(jacket_yield_function_type fn)
{
 Supervisor sup;
 OUTER_LIST_Type* _this = reinterpret_cast<OUTER_LIST_Type*>(this);
 //void* kf_supervisor
 int i = 0;
 for(INNER_LIST_Type& il : *_this)
 {
  int j = 0;
  for(VALUE_Type& v : il)
  {
   //KF_Jacket_W<VALUE_Type> jv(&v);
   fn(& v, i, j, &sup);
   sup.confirm_yield();
   ++j;
  }
  ++i;
 }
}

// void span(const_yield_index_function_type fn)
// {
//  Supervisor sup;
//  KF_Jacket_rX<const_yield_index_function_type> jfn(fn);
//  LIST_Type* _this = reinterpret_cast<LIST_Type*>(this);
//  //void* kf_supervisor
//  int index = 0;
//  for(const VALUE_Type& v : *_this)
//  {
//   jfn->operator()(v, index, &sup);
//   if(sup.break_requested())
//   {
//    break;
//   }
//   else
//   {
//    ++index;
//    sup.confirm_yield();
//   }
//  }
// }

// void span(const_yield_index_function_type fn, const_yield_check_type cfn)
// {
//  Supervisor sup;
//  LIST_Type* _this = reinterpret_cast<LIST_Type*>(this);
//  //void* kf_supervisor
//  int index = 0;
//  for(const VALUE_Type& v : *_this)
//  {
//   fn(v, index, &sup);
//   if(sup.break_requested())
//   {
//    break;
//   }
//   else
//   {
//    ++index;
//    sup.confirm_yield();
//    cfn(&sup);
//   }
//  }
// }


};

template<typename VALUE_Type>
class kf_Jagged2 : public QVector<QVector<VALUE_Type>>,
  public kf_Jagged2_<VALUE_Type, QVector<VALUE_Type>,
  QVector<QVector<VALUE_Type>>>
{
 //QList<VALUE_Type> widths_;

public:

 typedef QVector<QVector<VALUE_Type>> base;
 typedef Supervisor Supervisor_type;

 typedef std::function<void(const VALUE_Type&, void*)> const_yield_function_type;

// int width()
// {
//  return width_;
// }

 kf_Jagged2(std::initializer_list<VALUE_Type> ws) : //?width_(w),
   base()
 {
  int sz = ws.size();
  this->resize(sz);
  int index = 0;
  for(auto i = ws.begin(); i != ws.end(); ++i)
  {
   QVector<VALUE_Type>& vec = this->operator [](index);
   vec.resize(*i);
   ++index;
  }
 }


 void flatten(QVector<VALUE_Type>& fl)
 {
  fl.resize(this->total_length());
  //int index = 0;
  this->span do_[&fl](const VALUE_Type& v, int i, int j, int index, KF_CHECKED)
  {
   _KF_
   fl[index] = v;
   //?++index;
  }
  _do;
 }

};

#endif
