
#ifndef KOFTL_LIST__H
#define KOFTL_LIST__H

#include <QList>

#include <functional>

//#include "flags.h"

#include "koftl-base.h"
#include "koftl-jacket-rX.h"


template<typename VALUE_Type, typename LIST_Type>
struct kf_List_
{
 typedef std::function<void(const VALUE_Type&, void*)> const_yield_function_type;
 typedef std::function<void(const VALUE_Type&, int, void*)> const_yield_index_function_type;

 typedef std::function<void(void*)> const_yield_check_type;


 void span(const_yield_function_type fn)
 {
  Supervisor sup;
  LIST_Type* _this = reinterpret_cast<LIST_Type*>(this);
  //void* kf_supervisor
  for(const VALUE_Type& v : *_this)
  {
   fn(v, &sup);
   sup.confirm_yield();
  }
 }

 void span(const_yield_index_function_type fn)
 {
  Supervisor sup;
  KF_Jacket_rX<const_yield_index_function_type> jfn(fn);
  LIST_Type* _this = reinterpret_cast<LIST_Type*>(this);
  //void* kf_supervisor
  int index = 0;
  for(const VALUE_Type& v : *_this)
  {
   jfn->operator()(v, index, &sup);
   if(sup.break_requested())
   {
    break;
   }
   else
   {
    ++index;
    sup.confirm_yield();
   }
  }
 }

 void span(const_yield_index_function_type fn, const_yield_check_type cfn)
 {
  Supervisor sup;
  LIST_Type* _this = reinterpret_cast<LIST_Type*>(this);
  //void* kf_supervisor
  int index = 0;
  for(const VALUE_Type& v : *_this)
  {
   fn(v, index, &sup);
   if(sup.break_requested())
   {
    break;
   }
   else
   {
    ++index;
    sup.confirm_yield();
    cfn(&sup);
   }
  }
 }


};

template<typename VALUE_Type>
struct kf_List : public QList<VALUE_Type>, kf_List_<VALUE_Type, QList<VALUE_Type>>
{
 typedef QList<VALUE_Type> base;
 typedef Supervisor Supervisor_type;

 typedef std::function<void(const VALUE_Type&, void*)> const_yield_function_type;


 kf_List(std::initializer_list<VALUE_Type> vs) : base(vs)
 {

 }


};

#endif
