
#ifndef KOFTL_PAIRS__H
#define KOFTL_PAIRS__H

#include <QList>

#include <functional>

//#include "flags.h"

#include "koftl-base.h"
#include "koftl-jacket-rX.h"


//template<typename VALUE_Type>
//struct kf_Pairs_
//{
// typedef std::function<void(const VALUE_Type&, const VALUE_Type&, void*)> const_yield_function_type;
// typedef std::function<void(const VALUE_Type&, const VALUE_Type&, int, void*)> const_yield_index_function_type;

// typedef std::function<void(void*)> const_yield_check_type;


// void span(const_yield_function_type fn)
// {
//  Supervisor sup;
//  LIST_Type* _this = reinterpret_cast<LIST_Type*>(this);
//  //void* kf_supervisor

//  VALUE_Type outer_min = _this->value(0);
//  VALUE_Type outer_max = _this->value(1);

//  VALUE_Type inner_min = _this->value(2);
//  VALUE_Type inner_max = _this->value(3);

//  for(VALUE_Type ov = outer_min; ov < outer_max; ++ov)
//  {
//   bool break_requested = false;
//   for(VALUE_Type iv = inner_min; iv < inner_max; ++iv)
//   {
//    fn(ov, iv, &sup);
//    if(sup.break_requested())
//    {
//     break_requested = true;
//     break;
//    }
//    else
//    {
//     sup.confirm_yield();
//    }
//   }
//   if(break_requested)
//    break;
//  }
// }

//// void span(const_yield_index_function_type fn)
//// {
////  Supervisor sup;
////  KF_Jacket_rX<const_yield_index_function_type> jfn(fn);
////  LIST_Type* _this = reinterpret_cast<LIST_Type*>(this);
////  //void* kf_supervisor
////  int index = 0;
////  for(const VALUE_Type& v : *_this)
////  {
////   jfn->operator()(v, index, &sup);
////   if(sup.break_requested())
////   {
////    break;
////   }
////   else
////   {
////    ++index;
////    sup.confirm_yield();
////   }
////  }
//// }

//// void span(const_yield_index_function_type fn, const_yield_check_type cfn)
//// {
////  Supervisor sup;
////  LIST_Type* _this = reinterpret_cast<LIST_Type*>(this);
////  //void* kf_supervisor
////  int index = 0;
////  for(const VALUE_Type& v : *_this)
////  {
////   fn(v, index, &sup);
////   if(sup.break_requested())
////   {
////    break;
////   }
////   else
////   {
////    ++index;
////    sup.confirm_yield();
////    cfn(&sup);
////   }
////  }
//// }


//};


template<typename VALUE_Type>
struct kf_Pairs : public QList<QPair<VALUE_Type, VALUE_Type>>
{
 typedef QList<QPair<VALUE_Type, VALUE_Type>> base;

 bool contains(VALUE_Type v1, VALUE_Type v2)
 {
  return this->base::contains({v1, v2});
 }

 kf_Pairs(std::initializer_list<VALUE_Type> vs)
 {
  for(auto i = vs.begin(); i != vs.end(); ++i)
  {
   VALUE_Type v1 = *i;
   ++i;
   VALUE_Type v2 = *i;
   this->append({v1, v2});
  }
 }

 kf_Pairs(std::initializer_list<std::initializer_list<VALUE_Type>> vs)
 {
  const std::initializer_list<VALUE_Type>& v1s = vs.begin()[0];

  if(vs.size() == 1)
  {
   //int s1 = v1s.size();
   int dist = v1s.size()/2;
   int i = 0;
   for(auto vl1 = v1s.begin();
       i < dist; ++i, ++vl1)
   {
    VALUE_Type v1 = *vl1;
    VALUE_Type v2 = vl1[i + dist];
    this->append({v1, v2});
   }
  }
  else
  {
   const std::initializer_list<VALUE_Type>& v2s = vs.begin()[1];
   for(auto v1i = v1s.begin(); v1i != v1s.end(); ++v1i)
   {
    VALUE_Type v1 = *v1i;
    for(auto v2i = v2s.begin(); v2i != v2s.end(); ++v2i)
    {
     VALUE_Type v2 = *v2i;
     this->append({v1, v2});
    }
   }
  }
 }


};

#endif
