
#ifndef KOFTL_RANGE__H
#define KOFTL_RANGE__H

#include <QList>

#include <functional>

//#include "flags.h"

#include "koftl-base.h"
#include "koftl-jacket-rX.h"


template<typename VALUE_Type, typename LIST_Type>
struct kf_Range_
{
};

template<typename VALUE_Type>
struct kf_Range_<VALUE_Type, QPair<VALUE_Type, VALUE_Type>>
{
 typedef std::function<void(const VALUE_Type&, void*)> const_yield_function_type;
 typedef std::function<void(const VALUE_Type&, int, void*)> const_yield_index_function_type;

 typedef std::function<void(void*)> const_yield_check_type;


 void span(const_yield_function_type fn)
 {
  Supervisor sup;
  QPair<VALUE_Type, VALUE_Type>* _this = reinterpret_cast<QPair<VALUE_Type, VALUE_Type>*>(this);
  //void* kf_supervisor

  VALUE_Type min = _this->first;
  VALUE_Type max = _this->second;

  for(VALUE_Type v = min; v < max; ++v)
  {
   fn(v, &sup);
   if(sup.break_requested())
   {
    break;
   }
   else
   {
    sup.confirm_yield();
   }
  }
 }

// void span(const_yield_index_function_type fn)
// {
//  Supervisor sup;
//  KF_Jacket_rX<const_yield_index_function_type> jfn(fn);
//  LIST_Type* _this = reinterpret_cast<LIST_Type*>(this);
//  //void* kf_supervisor
//  int index = 0;
//  for(const VALUE_Type& v : *_this)
//  {
//   jfn->operator()(v, index, &sup);
//   if(sup.break_requested())
//   {
//    break;
//   }
//   else
//   {
//    ++index;
//    sup.confirm_yield();
//   }
//  }
// }

// void span(const_yield_index_function_type fn, const_yield_check_type cfn)
// {
//  Supervisor sup;
//  LIST_Type* _this = reinterpret_cast<LIST_Type*>(this);
//  //void* kf_supervisor
//  int index = 0;
//  for(const VALUE_Type& v : *_this)
//  {
//   fn(v, index, &sup);
//   if(sup.break_requested())
//   {
//    break;
//   }
//   else
//   {
//    ++index;
//    sup.confirm_yield();
//    cfn(&sup);
//   }
//  }
// }


};

template<typename VALUE_Type>
struct kf_Range : public QPair<VALUE_Type, VALUE_Type>, kf_Range_<VALUE_Type, QPair<VALUE_Type, VALUE_Type>>
{
 typedef QPair<VALUE_Type, VALUE_Type> base;
 typedef Supervisor Supervisor_type;

 typedef std::function<void(const VALUE_Type&, void*)> const_yield_function_type;


 kf_Range(std::initializer_list<VALUE_Type> vs) : base(vs.begin()[0], vs.begin()[1])
 {

 }



};

#endif
