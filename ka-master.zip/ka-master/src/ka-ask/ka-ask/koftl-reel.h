
#ifndef KOFTL_REEL__H
#define KOFTL_REEL__H

#include <QVector>

#include <functional>

//#include "flags.h"

#include "koftl-base.h"
#include "koftl-jacket-rX.h"

#include "koftl-list.h"


template<typename VALUE_Type>
struct kf_Reel : public QVector<VALUE_Type>, kf_List_<VALUE_Type, QVector<VALUE_Type>>
{
 typedef QList<VALUE_Type> base;
 typedef Supervisor Supervisor_type;

 typedef std::function<void(const VALUE_Type&, void*)> const_yield_function_type;


 kf_Reel(std::initializer_list<VALUE_Type> vs) : base(vs)
 {

 }


};

#endif
