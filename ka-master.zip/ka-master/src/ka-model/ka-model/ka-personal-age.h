
#ifndef KA_PERSONAL_AGE__H
#define KA_PERSONAL_AGE__H

#include "kans.h"


KANS_(MSME)

class KA_Personal_Name
{



};


_KANS(MSME)

#endif

