
#ifndef KA_PERSONAL_NAME__H
#define KA_PERSONAL_NAME__H

#include "kans.h"

#include "language/ka-languages.h"

#include "accessors.h"

#include "ka-ask/koftl-reel.h"

#include "ka-personal-single-name.h"

KANS_(MSME)

class KA_Personal_Name
{
public:

 flags_(1)
  bool family_name_first:1;
  bool multi_language:1;
  bool raw_string:1;
 _flags

private:

 static constexpr KA_Language_Code_Format current_language_code_format()
 {
  return KA_Language_Code_Format::ISO_639_2;
 }

 KA_Language_Codes__ISO_639_2 language_code_;

 kf_Reel<KA_Personal_Single_Name> single_names_;

public:

 ACCESSORS(KA_Language_Codes__ISO_639_2 ,language_code)
 ACCESSORS(kf_Reel<KA_Personal_Single_Name> ,single_names)

};


_KANS(MSME)

#endif
