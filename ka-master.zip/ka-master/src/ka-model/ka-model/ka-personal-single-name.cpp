
#include "ka-personal-single-name.h"

#include "kans.h"

USING_KANS(MSME)

KA_Personal_Single_Name::KA_Personal_Single_Name(QString raw_text)
 : Flags(0), raw_text_(raw_text)
{


}
