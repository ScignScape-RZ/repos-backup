
#ifndef KA_PERSONAL_SINGLE_NAME__H
#define KA_PERSONAL_SINGLE_NAME__H

#include "kans.h"

#include "language/ka-languages.h"

#include <QString>

#include "flags.h"

KANS_(MSME)

class KA_Personal_Single_Name
{
public:

 flags_(1)
  bool letter_initial:1;
  bool part_of_family_name:1;
  bool part_of_given_name:1;
  bool written_lowercase:1;
 _flags

private:

 QString raw_text_;

public:


 KA_Personal_Single_Name(QString raw_text);


};


_KANS(MSME)

#endif
