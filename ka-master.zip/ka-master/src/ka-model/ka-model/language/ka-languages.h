
#ifndef KA_LANGUAGES__H
#define KA_LANGUAGES__H

#include "kans.h"

KANS_(MSME)

enum class KA_Language_Code_Format : unsigned int
{
 N_A, ISO_639_2

};


enum class KA_Language_Codes__ISO_639_2
{
 N_A, Raw_String, ENG, KAN
};


_KANS(MSME)

#endif

