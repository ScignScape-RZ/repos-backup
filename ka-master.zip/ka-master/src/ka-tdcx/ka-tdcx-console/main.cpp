
#include "rz-tdcx/rz-tdcx-typed-array.h"

#include "rz-tdcx/rz-tdcx-storing-profile.h"

#include <QDebug>
#include <functional>

#include <QtEndian>
#include <QtMath>

#include "qunqlite-callback-parser.h"

#include "rz-tdcx/rz-tdcx-bridge.h"
#include "rz-tdcx/rz-tdcx-typed-array.h"
#include "rz-tdcx/rz-tdcx-typed-array-document.h"
#include "rz-tdcx/rz-tdcx-typed-array-decoder.h"

//#define DEFAULT_HTML_DIRECTORY "C:/nglp/demo"
#define DEFAULT_DATA_DIRECTORY "C:/re-dev/data"

#include "test-type.h"


#include "rzns.h"

USING_RZNS(TransDCX)

template<>
void TDCX_To_QByteArray(const Test_Type& t, QByteArray& qba)
{
 t.to_exchange(qba);
}

template<>
void TDCX_From_QByteArray(Test_Type& t, const QByteArray& qba)
{
 t.from_exchange(qba);
}


#include <QQuaternion>

int main12(int argc, char* argv[])
{
 QByteArray code("nathaniellevisrael1973zz");

 QVector4D vecs {0, 0, 0, 0};

 for(int i = 0; i < 20; i += 5)
 {
  bool ok = false;
  int x = code.mid(i, 5).toInt(&ok, 32);
  float f = (float) x;
  vecs[i/5] = f;
 }

 QQuaternion qq(vecs);

// QQuaternion qq { 2.0f, 1.0f, 0.0f, 0.0f};

 qq.normalize();

 QVector3D test {194, 6499, 71};


 QVector3D result = qq.rotatedVector(test);
 QVector3D test1 {0, 0, 0};
 float s = qq.scalar();
 qq.setScalar(-s);
 QVector3D result1 = qq.rotatedVector(result);
 qDebug() << "ok";
}

int main(int argc, char* argv[])
{
 typedef std::uint32_t u32;

 QUnQLite_Callback_Parser callback_parser;
 TDCX_Bridge tdcx_bridge([&callback_parser](QString message, int arglength, void* data) -> int
 {
  return callback_parser.run_query(message, arglength, data);
 });

 tdcx_bridge.create_or_open(DEFAULT_DATA_DIRECTORY, "t2");

 TDCX_Storing_Profile profile( (Bitsize) 40 );
 Test_Type t1 {170, 150000, 4};
 Test_Type t2 {40, 18, 17};

 TDCX_Typed_Array_Document tad;

 u32 uref1 = tad.store(t1, profile);
 u32 uref2 = tad.store(t2, profile);

 QString encode = tad.encode();

 qDebug() << encode;

 TDCX_Typed_Array_Decoder dcr(encode);
 Test_Type t3 {0, 0, 0};
 Test_Type t4 {0, 0, 0};
 dcr.decode();

 QVector<QSharedPointer<Test_Type>> values;
 dcr.reload(values);

// dcr.reload(0, t3);
// dcr.reload(1, t4);

// Test_Type t2 {0, 0, 0};
// tdcx_bridge.reload(uref, t2);

 int l = t3.y;
}

// QSharedPointer<QByteArray> sba(new QByteArray);
// {
//  QString test = "test";
//  void* args1[2] {&test, &sba};
//  tdcx_bridge->callback("DB_Load", 2, args1);
//  //TDCX_Typed_Array ta;
//  //ta.load_data(*sba);
//  //ta.read_direct_value(*sba);
// }

// TDCX_Typed_Array ta(*sba);

// Test_Type t2 {0, 0, 0};
// ta.to_value(t2);

//// QByteArray qba;
//// ta.read_direct_value(qba);
//// test t2 {0, 0, 0};
//// t2.from_exchange(qba);

// int l = sba->size();


//}


int main2(int argc, char* argv[])
{
 QUnQLite_Callback_Parser callback_parser;

 std::function<int(QString message, int arglength, void* data)>
  tdcx_callback = [&callback_parser](QString message, int arglength, void* data) -> int
 {
  return callback_parser.run_query(message, arglength, data);
 };

 TDCX_Bridge* tdcx_bridge = new TDCX_Bridge(tdcx_callback);

 QString database_directory = DEFAULT_DATA_DIRECTORY;
 QString database_file_name = "t2";

 QString* args[2] {&database_directory, &database_file_name};

 tdcx_bridge->callback("DB_Create_Or_Open", 2, args);

 TDCX_Storing_Profile profile;

 Test_Type t1 {179, 150000, 2};

 //tdcx_bridge->store("test", t1, profile);
}

// QByteArray qba;

// t1.to_exchange(qba);

// //QByteArray qba1;

// TDCX_Typed_Array ta;
// //qDebug() << ta.full_rep();

// ta.store_direct_value(qba);

// QSharedPointer<QByteArray> sba(new QByteArray);
// *sba = ta.data();

// QString test = "test";
// void* args1[2] {&test, &sba};

// tdcx_bridge->callback("DB_Store", 2, args1);


// tdcx_bridge->callback("DB_Create_Or_Open", DEFAULT_DATA_DIRECTORY, "");
// lda->set_default_open_directory(DEFAULT_HTML_DIRECTORY);
// lda->allobase_init(DEFAULT_DATA_DIRECTORY, "all-dialogs", allobase_callback);


//}

int main1(int argc, char* argv[])
{
 Test_Type t1 {179, 150000, 2};

 QByteArray qba;

 t1.to_exchange(qba);

 //QByteArray qba1;

 TDCX_Typed_Array ta;
 //qDebug() << ta.full_rep();

 ta.store_direct_value(qba);
 //qDebug() << ta.full_rep();

 QByteArray qba1;

 ta.read_direct_value(qba1);


 Test_Type t2 {0, 0, 0};

 t2.from_exchange(qba1);

 int l = qba.size();

// TDCX_Typed_Array ta;
// qDebug() << ta.full_rep();

// ta.store_direct_value(3);
// qDebug() << ta.full_rep();


// TDCX_Typed_Array ta1(ta.data());
// QString rep1 = ta1.full_rep();
// qDebug() << rep1;

}
