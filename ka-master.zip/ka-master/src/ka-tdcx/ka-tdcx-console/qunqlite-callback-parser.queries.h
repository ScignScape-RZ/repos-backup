
// //   This is not a top-level header.
//     This file is included several times,
//     setting TEMP_MACRO as needed.

TEMP_MACRO(DB_Create_Or_Open)
TEMP_MACRO(DB_Create)
TEMP_MACRO(DB_Open)
TEMP_MACRO(Test_Cursor)
TEMP_MACRO(DB_Store)
TEMP_MACRO(DB_Load)
