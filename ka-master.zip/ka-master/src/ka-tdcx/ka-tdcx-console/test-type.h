
#ifndef TEST_TYPE__H
#define TEST_TYPE__H

#include "rz-tdcx/rz-tdcx-type-info.h"
#include "rz-tdcx/rz-tdcx-typed-array.h"

#include <QByteArray>

class Test_Type
{
public:

 unsigned int x;
 unsigned int y;
 unsigned int z;

 to_exchange(QByteArray& qba) const;
 from_exchange(const QByteArray& qba);
};

template<>
struct TDCX_Type_Info<Test_Type> : TDCX_Pure_Value_Storage
{
 static QString get_QString_Type_Name(){ return "Test_Type"; }
 static int get_Type_Code(){ return 1; }
};







#endif
