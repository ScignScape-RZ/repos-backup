
#ifndef KA_TDCX_BRIDGE__H
#define KA_TDCX_BRIDGE__H

#include "ka-tdcx-callback-manager.h"
#include "ka-tdcx-typed-array.h"
#include "ka-tdcx-type-info.h"


#include <functional>
#include <QString>
#include <QSharedPointer>
#include <QByteArray>
#include <QMap>
#include <QDebug>

#include "ka-tdcx-storing-profile.h"

#include "kans.h"

KANS_(TransDCX)


class TDCX_Bridge : public TDCX_Callback_Manager
{
public:
 typedef std::uint32_t u32;
 typedef std::function<int(QString message, int arglength, void* data)> callback_type;

private:
 callback_type callback_;

 //QString default_data_directory_;

 u32 get_new_value_code(QString& str, u32& typecode, u32 inc = 1);

 QMap<QString, u32> typed_value_codes_;
 QMap<QString, u32> type_codes_;
 u32 highest_typecode_;
 u32 get_typecode(QString& str);
 u32 check_typecode(QString str);

public:

// TDCX_Bridge(QString default_data_directory, callback_type callback);
 TDCX_Bridge(callback_type callback);

 int callback(QString message, int arglength, void* data) Q_DECL_OVERRIDE;

 int create_or_open(QString database_directory, QString database_file_name);
 void check_load_typed_value_count(QString& str, u32& val, u32 inc);
 void store_load_typed_value_count(QString& str, u32& val);

 template<typename T>
 void store(QString key, u32 typecode, const T& t, TDCX_Storing_Profile& profile)
 {
  QByteArray qba;
  TDCX_To_QByteArray(t, qba);
  TDCX_Typed_Array ta(profile);
  ta.init_lengths_with_typecode(typecode);
  TDCX_Set_Storage_Mode<T>(ta);
  ta.store_direct_value(qba);
  QSharedPointer<QByteArray> sba(new QByteArray);
  *sba = ta.data();
  void* args1[2] {&key, &sba};
  callback("DB_Store", 2, args1);
 }

 template<typename T>
 u32 store(const T& t, TDCX_Storing_Profile& profile)
 {
  QString str = TDCX_Get_QString_Type_Name<T>();
  u32 typecode;
  u32 result = get_new_value_code(str, typecode);
  store(str, typecode, t, profile);
  return result;
 }


 template<typename T>
 void reload(QString key, T& t)
 {
  QSharedPointer<QByteArray> sba(new QByteArray);
  void* args[2] {&key, &sba};
  callback("DB_Load", 2, args);
  TDCX_Typed_Array ta(*sba);
  TDCX_Set_Storage_Mode<T>(ta);
  //ta.load_data(*sba);
  QByteArray qba;
  ta.read_direct_value(qba);
  TDCX_From_QByteArray(t, qba);
 }

 template<typename T>
 void reload(u32 uref, T& t)
 {
  QString key = TDCX_Get_QString_Type_Name<T>();
  u32 typecode = get_typecode(key);
  key.prepend('(');
  key.append(')');
  key.append(QString::number(uref, 32));
  reload(key, t);

 }

};

_KANS(TransDCX)

#endif
