
#ifndef KA_TDCX_CALLBACK_MANAGER__H
#define KA_TDCX_CALLBACK_MANAGER__H

#include <cstdint>
#include <QByteArray>

#include "kans.h"

#include "accessors.h"

KANS_(TransDCX)

class TDCX_Callback_Manager
{
public:

 virtual int callback(QString message, int arglength, void* data) = 0;
 virtual int callback(QString message, void* data);
 virtual int callback(QString message, QString arg1, QString arg2);
 virtual int callback(QString message);

};


_KANS(TransDCX)



#endif
