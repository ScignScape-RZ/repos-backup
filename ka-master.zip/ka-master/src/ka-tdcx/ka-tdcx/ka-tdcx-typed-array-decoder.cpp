
#include "ka-tdcx-typed-array-decoder.h"

#include <QStringList>
#include <QtEndian>
#include <QRegularExpression>

#include <QDebug>

#include "kans.h"

USING_KANS(TransDCX)

TDCX_Typed_Array_Decoder::TDCX_Typed_Array_Decoder(QString code)
 : code_(code)
{

}

void TDCX_Typed_Array_Decoder::decode()
{
 QRegularExpression split_rx("[_wxyz]");
 int index = 0;
 while(true)
 {
  QRegularExpressionMatch m = split_rx.match(code_, index);
  if(m.hasMatch())
  {
   QString str = code_.mid(index, m.capturedEnd());
   decode(str);
   index = m.capturedEnd();
  }
  else
  {
   break;
  }
 }
}

void TDCX_Typed_Array_Decoder::decode(QString str)
{
 int s = str.size() - 1;
 QChar remainder_code = str[s];
 str.chop(1);
 QByteArray result;

 int remainder;

 switch(remainder_code.toLatin1())
 {
 case 'w': remainder = 0; break;
 case 'x': remainder = 1; break;
 case 'y': remainder = 2; break;
 case 'z': remainder = 3; break;
 case '_': remainder = 4; break;
 default: remainder = 0; // error?
 }

 //?str += QString(rem, QChar('0'));

 for(int i = 0; i < s; i += 8)
 {
  QString c = str.mid(i, 8).toUpper();
  bool conversion_ok = false;
  QByteArray conv = c.toLatin1();
  u64 val = conv.toLongLong(&conversion_ok, 32);
  //val = qToBigEndian(val);

  QString vb1 = QString::number(val, 2);

  QByteArray qba(5, 0);
  memcpy(qba.data(), &val, 5); //(void*)(((size_t)&val) + 3), 5);

  result.append(qba);
 }
 // 170 2 1 240 4
 result.chop(remainder);

 QSharedPointer<TDCX_Typed_Array> ta = QSharedPointer<TDCX_Typed_Array>(new TDCX_Typed_Array(result));
 typed_arrays_.push_back(ta);
}


