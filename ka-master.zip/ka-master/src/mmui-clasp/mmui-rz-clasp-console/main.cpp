

#include "rz-qclasp-bridge/rz-qclasp-bridge.h"
#include "rz-qclasp-eval/rz-qclasp-eval.h"

#include "rz-qclasp-generator/rz-qclasp-generator.h"

#include "mmui/mmui-annotations/mmui-arrow-factory.h"
#include "mmui/mmui-annotations/mmui-arrow.h"

#include "rzns.h"

#include <QDebug>

#include <QCoreApplication>

#include <QMap>
#include <map>

USING_RZNS(RZClasp)



void compile_rz(QString file, QString& result)
{
 RZ_QClasp_Generator::compile_rz(file, result);
}

int main2(int argc, char *argv[])
{
//? QApplication qapp(argc, argv);

  QCoreApplication qapp(argc, argv);

  QString result;

  compile_rz("/home/nlevisrael/rz-lisp/rz/t1.rz", result);

  qDebug() << result;
}

//#ifdef HIDE
int main(int argc, char *argv[])
{
//? QApplication qapp(argc, argv);

  QCoreApplication qapp(argc, argv);

  QString result;
  compile_rz("/extension/ka/rz/t1/t1.rz", result);

//?  compile_rz("/home/nlevisrael/rz-lisp/rz/t1.rz", result);

  qRegisterMetaType<MMUI_Arrow_Factory>();
  qRegisterMetaType<MMUI_Arrow_Factory*>();

  qRegisterMetaType<MMUI_Arrow>();
  qRegisterMetaType<MMUI_Arrow*>();

 // qRegisterMetaType<PTN_Recommendation_Clasp_Interface>();
 // qRegisterMetaType<PTN_Recommendation_Clasp_Interface*>();

 std::map<std::string, int> dummy_map;
 dummy_map["x"] = 1;
 dummy_map["y"] = 2;

 RZ_QClasp_Eval* clasp_eval = new RZ_QClasp_Eval;


 char argc_ = 3;

 char* argv_[argc_];
 //?QDir::setCurrent(
 QString current_dir =  "/extension/CLASPQ/branches/new-testing/clasp/build/boehmdc";

 qDebug() << current_dir;

 argv_[0] = "cclasp-boehmdc";
// ////
// argv_[1] = "-l";
// argv_[2] = "/home/nlevisrael/rz-dev/cl/exit.lisp";

 argv_[1] = "-I";
 argv_[2] = "-n";

 //argv_[3] = "-I";
 //argv_[3] = "-n";


 //?clasp_eval->start_iclasp(argc, argv);

 clasp_eval->start_clasp_from_dir(argc_, argv_, current_dir);
 RZ_QClasp_Bridge* clasp_bridge = new RZ_QClasp_Bridge(*clasp_eval);

 //?QString qs1 = "(core::q-callback :invoke   (core::q-create  :|PTN_Recommendation_Clasp_Interface|) :|value_from_qcmap|     \"a\"     \"b\"      \"aaa\"      \"xxx\" ) ";
 //?qDebug() << "\n\nQS1 --- \n" << qs1 << "\n\n===\n";



 clasp_bridge->eval_file("/extension/ka/rz/t1/t1.rz.cl");

// clasp_bridge->eval_rz_file("/home/nlevisrael/rz-dev/cl/t4.rz");

 //?clasp_bridge->eval_string("(core::q-callback :invoke   (core::q-create  :|PTN_Recommendation_Clasp_Interface|) :|value_from_qcmap|     \"a\"     \"b\"      \"aaa\"      \"xxx\")");


}
//#endif


