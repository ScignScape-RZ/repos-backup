
//?
//#include "rz-qclasp-bridge/rz-qclasp-bridge.h"
//#include "rz-qclasp-eval/rz-qclasp-eval.h"

#include "rz-clasp-generator/rz-qclasp-generator.h"



//#include "ptn-path-segment.h"
//#include "ptn-path-resource.h"
//#include "ptn-file-resource.h"
//#include "ptn-resource-encoder.h"
//#include "ptn-resource-decoder.h"
//#include "ptn-site-request.h"
//#include "ptn-site-manager-bridge.h"


//#include "rz-tdcx/rz-tdcx/rz-tdcx-bridge.h"
//#include "rz-tdcx/rz-tdcx/rz-tdcx-typed-array.h"
//#include "rz-tdcx/rz-tdcx/rz-tdcx-typed-array-document.h"
//#include "rz-tdcx/rz-tdcx/rz-tdcx-typed-array-decoder.h"

#include <QtEndian>

#include <QtGlobal>
#include <QtCore>
//#include <qtendian.h>

#include <QDebug>

//#include <QNetworkRequest>
//#include <QNetworkReply>

//USING_RZNS(RZSite)
USING_RZNS(RZClasp)


//template<>
//struct TDCX_Type_Info<PTN_File_Resource> : TDCX_Byte_Array_Storage //?: TDCX_Pure_Value_Storage
//{
// static QString get_QString_Type_Name(){ return "PTN_File_Resource"; }
// static int get_Type_Code(){ return 1; }
//};


//std::string program_name()
//{
// return "Clasp";
//}


void compile_rz(QString file)
{
 QString result;
 RZ_QClasp_Generator::compile_rz(file, result);
}

int main(int argc, char *argv[])
{
 compile_rz("/extension/ka/rz/t1/t1.rz");
 return 0;
}
