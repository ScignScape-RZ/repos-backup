 
#include <QApplication>
#include <QGraphicsView>

#include <QList>
#include <QDebug>

#include <QMessageBox>

#include <QMenu>

#include <QGraphicsItem>

#include <QScreen>
#include <QTimer>
#include <QTime>

#include <QImage>

#include <QApplication>
#include <QDesktopWidget>

#include <QFileDialog>

//#include "qtarrowswidget.h"
//#include "qtarrowitem.h"


#include "mmui-arrow-factory.h"

#include "mmui-annotations-dialog.h"


//int main2(int argc, char *argv[])
//{
//  QApplication a(argc, argv);

//  QtArrowItem ait (
//     0, 0, false, 10, 10, true
//     );


////  QtArrowsWidget w;
////  {
////    //Resize the dialog and put it in the screen center
////    w.setGeometry(0,0,600,400);
////    const QRect screen = QApplication::desktop()->screenGeometry();
////    w.move( screen.center() - w.rect().center() );
////  }
////  w.show();

//  return a.exec();
//}


int main(int argc, char **argv)
{

 QApplication qapp(argc, argv);

 MMUI_Arrow_Factory af;

// af.load_arrow_package_from_file("/extension/ka/rz/arrows/a1.txt");
// af.save_encoded_arrow_package("/extension/ka/rz/arrows/a1.enc.txt");

 af.load_encoded_arrow_package_from_file("/extension/ka/rz/arrows/a1.enc.txt");

 MMUI_Annotations_Dialog dlg(&af, "/extension/ka/annotations/coolimage2.jpg");


 dlg.connect(&dlg, &MMUI_Annotations_Dialog::open_image_requested,
   [&dlg]()
 {

  QString str = QFileDialog::getOpenFileName(nullptr, "Select Image File",
    "/home/nlevisrael/NDP/tikz/smear2005/New database pictures/moderate_dysplastic/");

  dlg.open_file(str);

 });

 dlg.connect(&dlg, &MMUI_Annotations_Dialog::open_folder_requested,
   [&dlg]()
 {

  QString str = QFileDialog::getExistingDirectory(nullptr, "Select Image Folder",
    //"/home/nlevisrael/NDP/tikz/smear2005/New database pictures/"
    "/extension/ka/alexapath files/alexapath files"
                                                  );

  dlg.open_folder(str);

 });


 dlg.connect(&dlg, &MMUI_Annotations_Dialog::take_screenshot_requested,
   [&dlg]()
 {
//  qDebug() << "SS";

  QScreen* screen = QGuiApplication::primaryScreen();
//   if (const QWindow* window = windowHandle())
//       screen = window->screen();
   if (!screen)
       return;

   //if (delaySpinBox->value() != 0)
   QApplication::beep();

   int target_window_id  = dlg.winId();

   QTimer::singleShot(10000, [=]
   {
    QPixmap pixmap = screen->grabWindow(target_window_id );

//?    QString path = "/extension/ka/cpp/src/mmui/mmui-annotations-console/screen.png";


    QString path = "/home/nlevisrael/NDP/tikz/SONIC/screenshots/mmuiSS.png";

    qDebug() << "Saving to path: " << path;

    QFile file(path);
    if(file.open(QIODevice::WriteOnly))
    {
     pixmap.save(&file, "PNG");
    }

   });


 });

// dlg.open_folder("/home/nlevisrael/NDP/tikz/smear2005/New database pictures/moderate_dysplastic");

 dlg.show();

 qapp.exec();

}

int main1(int argc, char **argv)
{

 QApplication qapp(argc, argv);

 QGraphicsScene scene;

 QImage image("/extension/ka/annotations/coolimage2.jpg");

 QGraphicsPixmapItem item( QPixmap::fromImage(image));
 scene.addItem(&item);

 MMUI_Arrow_Factory af;

// af.load_arrow_package_from_file("/extension/ka/rz/arrows/a1.txt");
// af.save_encoded_arrow_package("/extension/ka/rz/arrows/a1.enc.txt");

 af.load_encoded_arrow_package_from_file("/extension/ka/rz/arrows/a1.enc.txt");
 //af.save_encoded_arrow_package("/extension/ka/rz/arrows/a1.enc.txt");


 af.add_to_scene(scene);

 //gpb.draw_to_scene(scene, scale_factor);

 //?

 QGraphicsView view(&scene);

 view.resize(1000, 600);

// view.setContextMenuPolicy(Qt::CustomContextMenu);

// QtArrowItem ait (
//    0, 0, false, 10, 10, true
//    );

// Genuine entrepreneurship is mutually collaborative and enabling: we need to encourage everyone with sufficient desire and expertise to build businesses, especially small businesses.  A culture of entrepreneurial innovation, where every business finds its best technical niche, is beneficial to all businesses.  Entrepreneurship -- more so than businesses' consolidation and expansion -- promotes professionalism and a respect for our educational system.

// scene.addItem(&ait);

 view.show();

 qapp.exec();


}
