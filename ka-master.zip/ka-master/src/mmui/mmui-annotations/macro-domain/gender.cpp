
#include "gender.h"

#include <QDataStream>

QDataStream& operator<<(QDataStream& lhs, const Gender& rhs)
{
 lhs << rhs.raw_text();
 lhs << rhs.predefined();
 return lhs;
}

QDataStream& operator>>(QDataStream& lhs, Gender& rhs)
{
 QString rt;
 lhs >> rt;
 rhs.set_raw_text(rt);
 int pre; // = Gender::Predefined::N_A;
 lhs >> pre;
 rhs.set_predefined( (Gender::Predefined) pre);
 return lhs;
}

Gender::Gender(Predefined predefined)
 : predefined_(predefined)
{

}

Gender::Gender(QString raw_text)
{
 if(raw_text.toLower() == "male")
 {
  set_to_male();
 }
 else if(raw_text_.toLower() == "female")
 {
  set_to_female();
 }
 else
 {
  predefined_ = Predefined::Other;
  raw_text_ = raw_text;
 }
}

void Gender::from_qbytearray(const QByteArray& qba)
{
 QDataStream qds(qba);
// qds >> arrows_;
 qds >> raw_text_;

 int pre;
 qds >> pre;
 predefined_ = Gender::Predefined(pre);

}


void Gender::to_qbytearray(QByteArray& qba) const
{
 QDataStream qds(&qba, QIODevice::WriteOnly);
// qds << arrows_;
 qds << raw_text_;
 qds << predefined_;

}


void Gender::set_to_male()
{
 predefined_ = Predefined::Male;
}

void Gender::set_to_female()
{
 predefined_ = Predefined::Female;
}



