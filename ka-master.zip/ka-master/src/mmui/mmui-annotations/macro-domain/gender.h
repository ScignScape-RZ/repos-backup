
#ifndef GENDER__H
#define GENDER__H

#include <QString>

#include "accessors.h"

class Gender;

QDataStream& operator<<(QDataStream& lhs, const Gender& rhs);
QDataStream& operator>>(QDataStream& lhs, Gender& rhs);

class Gender
{
 QString raw_text_;

public:
 enum class Predefined {

  N_A, Male, Female, Other

 };

private:
 Predefined predefined_;

public:

 ACCESSORS(QString ,raw_text)
 ACCESSORS(Predefined ,predefined)

 Gender(Predefined predefined = Predefined::N_A);
 Gender(QString raw_text);

 void set_to_male();
 void set_to_female();

 void from_qbytearray(const QByteArray& qba);
 void to_qbytearray(QByteArray& qba) const;



};


#endif
