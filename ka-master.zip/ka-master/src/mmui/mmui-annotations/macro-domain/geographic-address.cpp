
#include "geographic-address.h"

#include <QDataStream>

Geographic_Address::Geographic_Address()
{

}

QDataStream& operator<<(QDataStream& lhs, const Geographic_Address& rhs)
{
 lhs << rhs.raw_text();
 lhs << rhs.geographic_coordinates();
 return lhs;
}

QDataStream& operator>>(QDataStream& lhs, Geographic_Address& rhs)
{
 QString rt;
 lhs >> rt;
 rhs.set_raw_text(rt);

 QString geoc;
 lhs >> geoc;
 rhs.set_geographic_coordinates(geoc);
 return lhs;
}


void Geographic_Address::from_qbytearray(const QByteArray& qba)
{
 QDataStream qds(qba);
// qds >> arrows_;

 qds >> raw_text_;
 qds >> geographic_coordinates_;

}


void Geographic_Address::to_qbytearray(QByteArray& qba) const
{
 QDataStream qds(&qba, QIODevice::WriteOnly);
// qds << arrows_;

 qds << raw_text_;
 qds << geographic_coordinates_;

}

