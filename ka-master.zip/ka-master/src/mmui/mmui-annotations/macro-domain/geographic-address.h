
#ifndef GEOGRAPHIC_ADDRESS__H
#define GEOGRAPHIC_ADDRESS__H

#include <QString>

#include "accessors.h"

class Geographic_Address;

QDataStream& operator<<(QDataStream& lhs, const Geographic_Address& rhs);
QDataStream& operator>>(QDataStream& lhs, Geographic_Address& rhs);

class Geographic_Address
{
 QString raw_text_;
 QString geographic_coordinates_;

public:

 ACCESSORS(QString ,raw_text)
 ACCESSORS(QString ,geographic_coordinates)

 Geographic_Address();

 void from_qbytearray(const QByteArray& qba);
 void to_qbytearray(QByteArray& qba) const;

};


#endif
