
#include "legal-id.h"

#include <QDataStream>


QDataStream& operator<<(QDataStream& lhs, const Legal_Id& rhs)
{
 lhs << rhs.pan();
 lhs << rhs.aadhar();
 return lhs;
}

QDataStream& operator>>(QDataStream& lhs, Legal_Id& rhs)
{
 QString pan;
 lhs >> pan;
 rhs.set_pan(pan);

 QString aadhar;
 lhs >> aadhar;
 rhs.set_aadhar(aadhar);
 return lhs;
}

Legal_Id::Legal_Id()
{

}

void Legal_Id::from_qbytearray(const QByteArray& qba)
{
 QDataStream qds(qba);
// qds >> arrows_;

 qds >> pan_;
 qds >> aadhar_;
}


void Legal_Id::to_qbytearray(QByteArray& qba) const
{
 QDataStream qds(&qba, QIODevice::WriteOnly);
// qds << arrows_;

 qds << pan_;
 qds << aadhar_;

}

