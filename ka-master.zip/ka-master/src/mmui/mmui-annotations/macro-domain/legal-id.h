
#ifndef LEGAL_ID__H
#define LEGAL_ID__H

#include <QString>

#include "accessors.h"

class Legal_Id;

QDataStream& operator<<(QDataStream& lhs, const Legal_Id& rhs);
QDataStream& operator>>(QDataStream& lhs, Legal_Id& rhs);


class Legal_Id
{
 QString pan_;
 QString aadhar_;

public:

 ACCESSORS(QString ,pan)
 ACCESSORS(QString ,aadhar)

 Legal_Id();

 void from_qbytearray(const QByteArray& qba);
 void to_qbytearray(QByteArray& qba) const;

};


#endif
