
#include "personal-name.h"

#include <QDataStream>

#include <QString>

Personal_Name::Personal_Name(QString full_name)
 : full_name_(full_name)
{

}

QDataStream& operator<<(QDataStream& lhs, const Personal_Name& rhs)
{
 lhs << rhs.full_name();
 return lhs;
}

QDataStream& operator>>(QDataStream& lhs, Personal_Name& rhs)
{
 QString fn;
 lhs >> fn;
 rhs.set_full_name(fn);
 return lhs;
}

void Personal_Name::from_qbytearray(const QByteArray& qba)
{
 QDataStream qds(qba);
// qds >> arrows_;

 qds >> full_name_;
}


void Personal_Name::to_qbytearray(QByteArray& qba) const
{
 QDataStream qds(&qba, QIODevice::WriteOnly);
// qds << arrows_;

 qds << full_name_;

}

