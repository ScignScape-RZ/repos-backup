
#ifndef PERSONAL_NAME__H
#define PERSONAL_NAME__H

#include <QString>

#include "accessors.h"

class Personal_Name;

QDataStream& operator<<(QDataStream& lhs, const Personal_Name& rhs);
QDataStream& operator>>(QDataStream& lhs, Personal_Name& rhs);


class Personal_Name
{
 QString full_name_;

public:

 ACCESSORS(QString ,full_name)

 Personal_Name(QString full_name);

 void from_qbytearray(const QByteArray& qba);
 void to_qbytearray(QByteArray& qba) const;

};


#endif
