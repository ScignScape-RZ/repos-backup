
#include "telephone-number.h"

#include <QDataStream>

Telephone_Number::Telephone_Number(QString raw_text)
 : raw_text_(raw_text)
{

}

QDataStream& operator<<(QDataStream& lhs, const Telephone_Number& rhs)
{
 lhs << rhs.raw_text();
 return lhs;
}

QDataStream& operator>>(QDataStream& lhs, Telephone_Number& rhs)
{
 QString rt;
 lhs >> rt;
 rhs.set_raw_text(rt);
 return lhs;
}

void Telephone_Number::from_qbytearray(const QByteArray& qba)
{
 QDataStream qds(qba);
// qds >> arrows_;

 qds >> raw_text_;

}

void Telephone_Number::to_qbytearray(QByteArray& qba) const
{
 QDataStream qds(&qba, QIODevice::WriteOnly);
// qds << arrows_;

 qds << raw_text_;

}
