
#ifndef TELEPHONE_NUMBER__H
#define TELEPHONE_NUMBER__H

#include <QString>

#include "accessors.h"

class Telephone_Number;

QDataStream& operator<<(QDataStream& lhs, const Telephone_Number& rhs);
QDataStream& operator>>(QDataStream& lhs, Telephone_Number& rhs);

class Telephone_Number
{
 QString raw_text_;

public:

 ACCESSORS(QString ,raw_text)

 Telephone_Number(QString raw_text = QString());

 void from_qbytearray(const QByteArray& qba);
 void to_qbytearray(QByteArray& qba) const;

};


#endif
