
#include "basic-info.h"

#include <QDataStream>

Sociodemographic_Basic_Info::Sociodemographic_Basic_Info() :
  name_(QString()), main_telephone_number_(QString())
{

}


void Sociodemographic_Basic_Info::from_qbytearray(const QByteArray& qba)
{
 QDataStream qds(qba);
// qds >> arrows_;

 qds >> name_;
 qds >> main_telephone_number_;

 qds >> additional_telephone_numbers_;
 qds >> gender_;

 qds >> date_of_birth_;
 qds >> legal_id_;

}


void Sociodemographic_Basic_Info::to_qbytearray(QByteArray& qba) const
{
 QDataStream qds(&qba, QIODevice::WriteOnly);
// qds << arrows_;

 qds << name_;
 qds << main_telephone_number_;

 qds << additional_telephone_numbers_;
 qds << gender_;

 qds << date_of_birth_;
 qds << legal_id_;

}
