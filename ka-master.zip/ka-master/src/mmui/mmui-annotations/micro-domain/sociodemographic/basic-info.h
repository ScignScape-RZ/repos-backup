
#ifndef BASIC_INFO__H
#define BASIC_INFO__H

#include "macro-domain/personal-name.h"
#include "macro-domain/telephone-number.h"
#include "macro-domain/gender.h"
#include "macro-domain/legal-id.h"

#include "accessors.h"

#include <QList>
#include <QDate>


class Sociodemographic_Basic_Info
{
 Personal_Name name_;

 Telephone_Number main_telephone_number_;

 QList<Telephone_Number> additional_telephone_numbers_;

 Gender gender_;

 QDate date_of_birth_;

 Legal_Id legal_id_;

public:

 ACCESSORS__RGET(Personal_Name ,name)
 ACCESSORS__RGET(Telephone_Number ,main_telephone_number)
 ACCESSORS__RGET(QList<Telephone_Number> ,additional_telephone_numbers)
 ACCESSORS(Gender ,gender)
 ACCESSORS(QDate ,date_of_birth)
 ACCESSORS__RGET(Legal_Id ,legal_id)

 Sociodemographic_Basic_Info();

 void from_qbytearray(const QByteArray& qba);
 void to_qbytearray(QByteArray& qba) const;

};


#endif
