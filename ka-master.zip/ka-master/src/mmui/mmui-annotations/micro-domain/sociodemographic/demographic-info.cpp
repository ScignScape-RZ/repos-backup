
#include "demographic-info.h"

#include <QDataStream>

Demographic_Info::Demographic_Info()
 //? : address_(Geographic_Address())
{

}

void Demographic_Info::from_qbytearray(const QByteArray& qba)
{
 QDataStream qds(qba);
// qds >> arrows_;

 qds >> type_of_residence_;
 qds >> address_;

 qds >> occupation_;
 qds >> education_level_;

 qds >> place_of_birth_;

 int ms;
 qds >> ms;

 marital_status_ = (Marital_Status) ms;


}


void Demographic_Info::to_qbytearray(QByteArray& qba) const
{
 QDataStream qds(&qba, QIODevice::WriteOnly);
// qds << arrows_;
 qds << type_of_residence_;
 qds << address_;

 qds << occupation_;
 qds << education_level_;

 qds << place_of_birth_;
 qds << (int) marital_status_;

}


