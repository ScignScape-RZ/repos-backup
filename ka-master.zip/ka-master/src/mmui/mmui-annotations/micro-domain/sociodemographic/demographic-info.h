
#ifndef DEMOGRAPHIC_INFO__H
#define DEMOGRAPHIC_INFO__H

#include "macro-domain/geographic-address.h"

#include "accessors.h"

#include <QList>
#include <QDate>


class Demographic_Info
{
 QString type_of_residence_;

 Geographic_Address address_;

 QString occupation_;
 QString education_level_;
 QString place_of_birth_;

public:

 enum class Marital_Status {
   N_A, Single, Married, Divorced, Widowed
 };

private:

 Marital_Status marital_status_;


public:

 ACCESSORS(QString ,type_of_residence)
 ACCESSORS__RGET(Geographic_Address ,address)
 ACCESSORS(Marital_Status ,marital_status)

 ACCESSORS(QString ,occupation)
 ACCESSORS(QString ,education_level)
 ACCESSORS(QString ,place_of_birth)

 Demographic_Info();

 void from_qbytearray(const QByteArray& qba);
 void to_qbytearray(QByteArray& qba) const;


};


#endif
