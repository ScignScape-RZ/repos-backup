
#include "family-info.h"

#include <QDataStream>

Family_Info::Family_Info()
 :
   mothers_name_(Personal_Name(QString())),
   fathers_name_(Personal_Name(QString())),
   contact_name_(Personal_Name(QString())),
   contact_telephone_number_(Telephone_Number(QString()))
{

}

void Family_Info::from_qbytearray(const QByteArray& qba)
{
 QDataStream qds(qba);
// qds >> arrows_;

 qds >> mothers_name_;

 int ms;
 qds >> ms;
 mothers_status_ = (Mortality_Status) ms;

 qds >> fathers_name_;

 int fs;
 qds >> fs;
 fathers_status_ = (Mortality_Status) fs;

 qds >> contact_name_;
 qds >> contact_telephone_number_;
}


void Family_Info::to_qbytearray(QByteArray& qba) const
{
 QDataStream qds(&qba, QIODevice::WriteOnly);
// qds << arrows_;

 qds << mothers_name_;
 qds << (int) mothers_status_;

 qds << fathers_name_;
 qds << (int) fathers_status_;

 qds << contact_name_;
 qds << contact_telephone_number_;

}



