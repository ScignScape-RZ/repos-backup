
#ifndef FAMILY_INFO__H
#define FAMILY_INFO__H

#include "macro-domain/personal-name.h"
#include "macro-domain/telephone-number.h"
#include "macro-domain/gender.h"
#include "macro-domain/legal-id.h"

#include "accessors.h"

#include <QList>
#include <QDate>


class Family_Info
{
 Personal_Name mothers_name_;

public:
 enum class Mortality_Status {
   N_A, Alive, Deceased
 };

private:
 Mortality_Status mothers_status_;

 Personal_Name fathers_name_;
 Mortality_Status fathers_status_;

 Personal_Name contact_name_;
 Telephone_Number contact_telephone_number_;


public:

 ACCESSORS__RGET(Personal_Name ,mothers_name)
 ACCESSORS(Mortality_Status ,mothers_status)

 ACCESSORS__RGET(Personal_Name ,fathers_name)
 ACCESSORS(Mortality_Status ,fathers_status)

 ACCESSORS__RGET(Personal_Name ,contact_name)
 ACCESSORS__RGET(Telephone_Number ,contact_telephone_number)

 Family_Info();

 void from_qbytearray(const QByteArray& qba);
 void to_qbytearray(QByteArray& qba) const;

};


#endif
