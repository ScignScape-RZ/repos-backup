
#include "mmui-annotations-dialog.h"
#include "mmui-arrow-factory.h"

#include "wsi-tile.h"

#include "styles.h"

//#include "clg-db-antemodel.h";

#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QButtonGroup>
#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>

#include <QDirIterator>

#include <QPlainTextEdit>
#include <QTextStream>

#include <QPainter>
#include <QPushButton>
#include <QLabel>

#include <QTableWidget>
#include <QGraphicsPixmapItem>

#include <QMessageBox>
#include <QDebug>

#include <QGraphicsView>
#include <QScrollArea>


#include <QHeaderView>

#include <QMenu>
#include <QAction>

#include <QListWidget>

#include "mmui-arrow-group.h"

#include "mmui-clickable-label.h"

#include "mmui-ka-update-dialog.h"

#include "mmui-ka-png-dialog.h"

//?#include "styles.h"

//MMUI_Annotations_Dialog::MMUI_Annotations_Dialog(QString background_image_file)
//  : background_image_file_(background_image_file)
//{

//}


//class ClickableLabel : public QLabel {
//    Q_OBJECT

//public:
//    explicit ClickableLabel(QWidget* parent = Q_NULLPTR, Qt::WindowFlags f = Qt::WindowFlags());
//    ~ClickableLabel();

//signals:
//    void clicked();

//protected:
//    void mousePressEvent(QMouseEvent* event);

//};


//ClickableLabel::ClickableLabel(QWidget* parent, Qt::WindowFlags f)
//    : QLabel(parent) {

//}

//ClickableLabel::~ClickableLabel() {}

//void ClickableLabel::mousePressEvent(QMouseEvent* event) {
//    emit clicked();
//}


void MMUI_Annotations_Dialog::add_to_arrow_group()
{
 if(!current_arrow_group_)
 {
  init_current_arrow_group();
 }

//??

 int new_count = 1;
 QList<MMUI_Arrow*> na;
 current_arrow_group_->add_new_arrows(na, new_count);

 arrow_factory_->insert_added_arrows(na);

 arrow_factory_->draw_added_arrows_to_scene(*seli_scene_);

}

void MMUI_Annotations_Dialog::init_current_arrow_group()
{
 //MMUI_Arrow* a1 = arrows_
 current_arrow_group_ = new MMUI_Arrow_Group(current_arrow_);
}

void MMUI_Annotations_Dialog::add_arrow_annotation()
{
//? MMUI_Arrow_Factory af;
// af.load_arrow_package_from_file("/extension/ka/rz/arrows/a1.txt");
// af.save_encoded_arrow_package("/extension/ka/rz/arrows/a1.enc.txt");
// af.load_encoded_arrow_package_from_file("/extension/ka/rz/arrows/a1.enc.txt");

 MMUI_Arrow* arrow = arrow_factory_->add_to_scene(*seli_scene_);
 current_arrow_ = arrow;
 ++visible_annotations_count_;
 triangle_down_button_->setEnabled(true);
}



void MMUI_Annotations_Dialog::render_to_button(QPushButton* btn, QPolygonF& poly)
{
 QRect rect(0, 0, 40, 40);
 QPixmap* qpm = new QPixmap(rect.size());
 qpm->fill(Qt::transparent);
 QPainter painter(qpm);
 scratch_scene_->render(&painter, QRectF(0, 0, 40, 40), QRectF(0, 0, 40, 40));
 btn->setIcon(QIcon(*qpm));
 btn->setMaximumWidth(40);
 btn->setMaximumHeight(40);
 polys_[btn] = poly;
 connect(btn, SIGNAL(pressed()), this, SLOT(graphics_button_clicked()));
}

void MMUI_Annotations_Dialog::render_to_button(QPushButton* btn,
  QGraphicsPixmapItem* item, QGraphicsPixmapItem* scratch_item,
  QBoxLayout* layout, qreal x_offset,
  qreal y_offset, qreal reenlage_factor,
  QString text, qreal rotate)
{
 //btn->setText(QString("\n%1").arg(text));
 QLabel* label = new QLabel(text, this);
 label->setMinimumWidth(40);
 label->setAlignment(Qt::AlignCenter);

 label->setStyleSheet("QLabel {margin-bottom:10px;}");


 QRectF rf = item->boundingRect();
 //QRect r = rf.toAlignedRect();

 qreal xsf = 40/rf.width();
 qreal ysf = 55/rf.height();


 QRect r = item->boundingRect().toAlignedRect();


//? item->setScale(0.05);

 int mult = 10;

 QGraphicsScene scratch_scene;

 //?scratch_scene_->setSceneRect(0, 0, 0, 0);

 //QRect rect(0, 0, 55 * mult, 40 * mult);

 QRect rect(scratch_item->boundingRect().toAlignedRect());

 //?qDebug() << "RECT: " << rect;

 if(rotate != 0)
 {
  qDebug() << "rotate ...";
  QTransform qtr;
  qtr.translate(rect.height()/2.0,
                rect.width()/2.0);
  qtr.rotate(rotate);

  if(rotate == 90 || rotate == -90)
   rect = rect.transposed();

  qtr.translate(-rect.height()/2.0 ,
                -rect.width()/2.0);
  //?
  scratch_item->setTransform(qtr);

 }


 QRect rect1(scratch_item->boundingRect().toAlignedRect());

 //?qDebug() << "RECT1: " << rect1;


 scratch_scene.addItem(scratch_item);

 QRectF srect = scratch_scene.sceneRect();// (scratch_item->boundingRect().toAlignedRect());

 //?qDebug() << srect;


//  QRect rect(0, 0, 455, 1024);

 //?qDebug() << rect;




// int x_adj = x_offset;
// int y_adj = y_offset;


 QRectF srect_adj;
//   = QRectF(x_adj, y_adj,
//   srect.width() - x_adj, srect.height() - y_adj);

// if(y_offset != 0)
// {
  //x_adj = 10;
  srect_adj = QRectF(x_offset, 0,
    srect.width() - (2 * x_offset), srect.height() - y_offset);
// }


// if(rotate > 0)
// {
//  srect_adj = QRectF(x_offset, 0,
//    srect.width() - (2 * x_offset), srect.height() - 100);
//  //rect = QRect(0, 0, 1024, 749);
// }


 QPixmap* qpm = new QPixmap(rect.size());
 qpm->fill(Qt::transparent);
 QPainter painter(qpm);

 scratch_scene.render(&painter, rect, srect_adj); //QRectF(0, 0, 40, 55)); //srect_adj); //QRectF(0, 0, 56, 5)); //srect); //, rect, rect); //, rect, rect) ; //QRectF(0, 0, 40 * mult, 55 * mult),

   //QRectF(x_offset, y_offset, 40 * mult, 55 * mult));
 btn->setIcon(QIcon(*qpm));
 //btn->setIconSize(qpm->size());

//? qDebug() << "W: " << qpm->width();
//? qDebug() << "H: " << qpm->height();

 btn->setStyleSheet("QPushButton{padding:0px;margin:0px;}");

// btn->setMinimumWidth(40);
// btn->setMinimumHeight(55);
// btn->setMaximumWidth(40);
// btn->setMaximumHeight(55);
 layout->addWidget(btn);

 layout->addWidget(label);
 layout->addStretch();

 //polys_[btn] = poly;
 //connect(btn, SIGNAL(pressed()), this, SLOT(graphics_button_clicked()));

 //?  scratch_scene_->clear();


// QRect view_rect = QRect(-40, 0, 100, 100);
// item->renderer()->setViewBox(view_rect);

//         self.srenderer.setViewBox(seliRect)
//         self.seliSecond.setPos(self.centerx-10, self.centery-1)

 if(xsf < ysf)
 {
  item->setScale(reenlage_factor * xsf);
 }
 else
 {
  item->setScale(reenlage_factor * ysf);
 }


 seli_scene_->addItem(item);
 item->setVisible(false);

 labels_to_items_[item] = label;

 connect(btn, &QPushButton::pressed, [this, item, label]
 {
  if(current_seli_item_)
  {
   for(QGraphicsItem* item : current_seli_specific_items_[current_seli_item_])
   {
    item->setVisible(false);
   }
   current_seli_item_->setVisible(false);
  }
  else
  {
   enable_graphics_buttons();
  }
  if(current_seli_label_)
   current_seli_label_->setStyleSheet("QLabel { background-color : none; margin-bottom:10px;}");
  item->setVisible(true);
  label->setStyleSheet("QLabel { background-color : salmon; margin-bottom:10px;}");
  current_seli_item_ = item;
  for(QGraphicsItem* item : current_seli_specific_items_[current_seli_item_])
  {
   item->setVisible(true);
  }
  current_seli_label_ = label;
 });

}






void MMUI_Annotations_Dialog::construct_octagon(QPolygonF& poly, float center_x, float center_y,
  float scale_factor, float x_offset, float y_offset, float width)
{
 poly
   << QPointF(center_x - scale_factor * x_offset, center_y + width)
   << QPointF(center_x - scale_factor * x_offset, center_y - width)

   << QPointF(center_x - width, center_y - scale_factor * y_offset)
   << QPointF(center_x + width, center_y - scale_factor * y_offset)

   << QPointF(center_x + scale_factor * x_offset, center_y - width)
   << QPointF(center_x + scale_factor * x_offset, center_y + width)

   << QPointF(center_x + width, center_y + scale_factor * y_offset)
   << QPointF(center_x - width, center_y + scale_factor * y_offset)
      ;

}


void MMUI_Annotations_Dialog::construct_deco_plus(QPolygonF& poly, float center_x, float center_y,
  float scale_factor, float offset, float width, float deco_offset)
{
 poly
   << QPointF(center_x - scale_factor * offset, center_y - scale_factor * width)
   << QPointF(center_x - scale_factor * deco_offset, center_y - scale_factor * width)
   << QPointF(center_x - scale_factor * width, center_y - scale_factor * deco_offset)

   << QPointF(center_x - scale_factor * width, center_y - scale_factor * offset)
   << QPointF(center_x + scale_factor * width, center_y - scale_factor * offset)

   << QPointF(center_x + scale_factor * width, center_y - scale_factor * deco_offset)
   << QPointF(center_x + scale_factor * deco_offset, center_y - scale_factor * width)
   << QPointF(center_x + scale_factor * offset, center_y - scale_factor * width)


   << QPointF(center_x + scale_factor * offset, center_y + scale_factor * width)
   << QPointF(center_x + scale_factor * deco_offset, center_y + scale_factor * width)
   << QPointF(center_x + scale_factor * width, center_y + scale_factor * deco_offset)


   << QPointF(center_x + scale_factor * width, center_y + scale_factor * width)
   << QPointF(center_x + scale_factor * width, center_y + scale_factor * offset)

   << QPointF(center_x - scale_factor * width, center_y + scale_factor * offset)
   << QPointF(center_x - scale_factor * width, center_y + scale_factor * deco_offset)
   << QPointF(center_x - scale_factor * deco_offset, center_y + scale_factor * width)

   << QPointF(center_x - scale_factor * offset, center_y + scale_factor * width)
   << QPointF(center_x - scale_factor * offset, center_y - scale_factor * width)
      ;

}


void MMUI_Annotations_Dialog::construct_plus(QPolygonF& poly, float center_x, float center_y,
  float scale_factor, float offset, float width)
{
 poly
   << QPointF(center_x - scale_factor * offset, center_y - scale_factor * width)
   << QPointF(center_x - scale_factor * width, center_y - scale_factor * width)

   << QPointF(center_x - scale_factor * width, center_y - scale_factor * offset)
   << QPointF(center_x + scale_factor * width, center_y - scale_factor * offset)

   << QPointF(center_x + scale_factor * width, center_y - scale_factor * width)
   << QPointF(center_x + scale_factor * offset, center_y - scale_factor * width)

   << QPointF(center_x + scale_factor * offset, center_y + scale_factor * width)
   << QPointF(center_x + scale_factor * width, center_y + scale_factor * width)

   << QPointF(center_x + scale_factor * width, center_y + scale_factor * width)
   << QPointF(center_x + scale_factor * width, center_y + scale_factor * offset)

   << QPointF(center_x - scale_factor * width, center_y + scale_factor * offset)
   << QPointF(center_x - scale_factor * width, center_y + scale_factor * width)

   << QPointF(center_x - scale_factor * offset, center_y + scale_factor * width)
   << QPointF(center_x - scale_factor * offset, center_y - scale_factor * width)
      ;

}


void MMUI_Annotations_Dialog::construct_triangle_up(QPolygonF& poly, float center_x, float center_y,
  float scale_factor, float width, float height, float y_offset)
{
 poly
   << QPointF(center_x - scale_factor * width/2, center_y + scale_factor * y_offset)
   << QPointF(center_x + scale_factor * width/2, center_y + scale_factor * y_offset)
   << QPointF(center_x, center_y - scale_factor * height);

}


void MMUI_Annotations_Dialog::construct_triangle_down(QPolygonF& poly, float center_x, float center_y,
  float scale_factor, float width, float height, float y_offset)
{
 poly
   << QPointF(center_x - scale_factor * width/2, center_y - scale_factor * height)
   << QPointF(center_x + scale_factor * width/2, center_y - scale_factor * height)
   << QPointF(center_x, center_y + scale_factor * y_offset);

}


void MMUI_Annotations_Dialog::open_file(QString file)
{
 current_image_file_ = file;
 main_pixmap_item_->setPixmap(QPixmap::fromImage(QImage(file)));
}

void MMUI_Annotations_Dialog::open_folder(QString path)
{
//  QLabel* l1 = new QLabel("L1", this);
//  graphics_series_layout_->addWidget(l1);

//?

 current_tile_map_ = nullptr;

 QString ani_path = path + "/abnormal-images.txt";

 QFile ani_file(ani_path);

 QString ani_data;

 QRegularExpression rx("r(\\d+)c(\\d+)");


 //bool valid_wsi_folder = false;

 if (ani_file.open(QFile::ReadOnly))
 {
  ani_data = ani_file.readAll();

  qDebug() << "ANI: " << ani_data;
  QStringList qsl = ani_data.split('\n');
  for(QString line : qsl)
  {
   QStringList fields = line.split(' ');
   if(fields.length() == 5)
   {
    QString tile_file = fields[0];

    if(!tile_file.isEmpty())
    {
     QRegularExpressionMatch rxm = rx.match(tile_file);
     if(rxm.hasMatch())
     {
      int r = rxm.captured(1).toInt();
      int c = rxm.captured(2).toInt();

      if(!current_tile_map_)
      {
       current_tile_map_ = new QMap<QString, WSI_Tile*>();
      }
      WSI_Tile* tile = current_tile_map_->value(tile_file);
      if(!tile)
      {
       tile = new WSI_Tile(path + "/" + tile_file + ".jpg", r, c);
       current_tile_map_->insert(tile_file, tile);
      }
      tile->add_tile_segment(fields[1].toInt(),
        fields[2].toInt(), fields[3].toInt(), fields[4].toInt());
     }
    }
   }
  }
 }

 bool valid_wsi_folder = current_tile_map_ && !current_tile_map_->isEmpty();

 QFrame* fr = new QFrame(this);
 QVBoxLayout* vb = new QVBoxLayout;

 QDirIterator dirIt(path, QDirIterator::Subdirectories);

 int count = 0;

 WSI_Tile* last_tile = nullptr;

 while (dirIt.hasNext())
 {
  dirIt.next();
  QFileInfo qfi = dirIt.filePath();

  if(qfi.isFile())
  {
   if(qfi.suffix() == "BMP" || qfi.suffix() == "jpg")
   {
    ++count;
//    if(count == 5)
//     break;

    QString qfin = qfi.baseName();

    WSI_Tile* tile = nullptr;
    if(valid_wsi_folder)
    {
     tile = current_tile_map_->value(qfin);
     if(!tile)
     {
      QRegularExpressionMatch rxm = rx.match(qfin);
      if(rxm.hasMatch())
      {
       int r = rxm.captured(1).toInt();
       int c = rxm.captured(2).toInt();
       tile = new WSI_Tile(path + "/" + qfin + ".jpg", r, c);
       current_tile_map_->insert(qfin, tile);
      }
     }
    }
    if(last_tile)
    {
     last_tile->set_geometric_next(tile);
     tile->set_geometric_previous(last_tile);
    }
    last_tile = tile;


    QImage qim = QImage(qfi.absoluteFilePath());

    qim = qim.scaledToWidth(30);

    ClickableLabel* lbl = new ClickableLabel(this); //QLabel(qfi.fileName(), this);

    lbl->setUserData(1, reinterpret_cast<QObjectUserData*>(tile));
    tile->set_associated_qobject(lbl);

    connect(lbl, &ClickableLabel::clicked,
      [qfi, lbl, this]
    {
     if(current_clickable_label_)
     {
      QImage qim = QImage(qfi.absoluteFilePath());
      qim = qim.scaledToWidth(30);
      current_clickable_label_->setPixmap(QPixmap::fromImage(qim));
     }

     current_clickable_label_ = lbl;

     if(lbl->userData(1))
     {
      current_tile_ = reinterpret_cast<WSI_Tile*>(lbl->userData(1));
     }

     QPixmap px = *lbl->pixmap();


     QPainter p(&px);
     QPen pen = QPen(QColor::fromRgb(255, 0, 0, 100));
     pen.setWidth(6);
     p.setPen(pen);

     QBrush qbr = QBrush(QColor::fromRgb(255, 0, 0, 10));
     p.setBrush(qbr);

     p.drawRect(3, 3, px.width()-6, px.height()-6);
     p.end();
     lbl->setPixmap(px);

     open_file(lbl->path);


    });

//    if(false) //count == 3)
//    {
//     QPixmap px = QPixmap::fromImage(qim);
//     QPainter p(&px);
//     QPen pen = QPen(QColor::fromRgb(255, 0, 0, 100));
//     pen.setWidth(5);
//     p.setPen(pen);

//     QBrush qbr = QBrush(QColor::fromRgb(255, 0, 0, 10));
//     p.setBrush(qbr);

//     p.drawRect(2, 2, 26, 26);
//     p.end();
//     lbl->setPixmap(px);
//    }
//    else
//    {

    lbl->path = qfi.absoluteFilePath();
     lbl->setPixmap(QPixmap::fromImage(qim));
//    }

//    lbl->setPixmap(QPixmap::fromImage(QImage(path)));

    vb->addWidget(lbl);
    //graphics_series_layout_->addWidget(lbl);
    //qDebug()<<dirIt.filePath();
   }
  }
 }

 fr->setLayout(vb);
 graphics_series_scroll_area_->setWidget(fr);
// graphics_series_layout_->addStretch();
// graphics_series_frame_->update();
// graphics_series_frame_->repaint();

// graphics_series_scroll_area_->update();
// graphics_series_scroll_area_->repaint();



// qDebug() << "P: " << path;
// //main_pixmap_item_->setPixmap(QPixmap::fromImage(QImage(file)));
}


MMUI_Annotations_Dialog::MMUI_Annotations_Dialog(
  MMUI_Arrow_Factory* arrow_factory,
  QString background_image_file,
  QWidget* parent)
  : QDialog(parent), background_image_file_(background_image_file),
    current_image_file_(background_image_file),
    current_seli_item_(nullptr), current_seli_label_(nullptr),
    old_zoom_slider_value_(1), arrow_factory_(arrow_factory),
    current_clickable_label_(nullptr),
    visible_annotations_count_(0),
    current_arrow_(nullptr), current_arrow_group_(nullptr),
    current_tile_map_(nullptr), current_tile_(nullptr)

   //?, antemodel_(antemodel)//, config_(config)
{
 //?arrow_factory_ = new MMUI_Arrow_Factory;

 button_box_ = new QDialogButtonBox(this);

 button_ok_ = new QPushButton("OK");
 button_proceed_ = new QPushButton("Proceed");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

 button_proceed_->setDefault(false);
 button_proceed_->setAutoDefault(false);

 button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);


 QString colorful_button_style_sheet = colorful_button_style_sheet_();

 QString colorful_toggle_button_style_sheet = colorful_button_quiet_style_sheet_(); //colorful_toggle_button_style_sheet_();


 QString colorful_button_style_sheet_down = colorful_button_style_sheet_down_();
 QString colorful_button_quiet_style_sheet = colorful_button_quiet_style_sheet_();
 QString button_close_style_sheet = button_close_style_sheet_();
 QString basic_button_style_sheet = basic_button_style_sheet_();


 button_ok_->setStyleSheet(basic_button_style_sheet);
 button_proceed_->setStyleSheet(basic_button_style_sheet);
 button_cancel_->setStyleSheet(basic_button_style_sheet);


 connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));

 main_layout_ = new QVBoxLayout();

 top_buttons_layout_ = new QHBoxLayout;

 updates_button_ = new QPushButton("Updates Dialog", this);


 patient_info_button_ = new QPushButton("Patient Info Dialog", this);
 diagnostic_report_button_ = new QPushButton("Diagnostic Report", this);

 open_image_button_ = new QPushButton("Open Image", this);
 take_screenshot_button_ = new QPushButton("Screenshot", this);
 open_folder_button_ = new QPushButton("Open Folder", this);

 sonic_button_ = new QPushButton("SONIC", this);


 updates_button_->setStyleSheet(colorful_button_style_sheet);
 patient_info_button_->setStyleSheet(colorful_button_style_sheet);
 diagnostic_report_button_->setStyleSheet(colorful_button_style_sheet);
 open_image_button_->setStyleSheet(colorful_button_style_sheet);
 take_screenshot_button_->setStyleSheet(colorful_button_style_sheet);
 open_folder_button_->setStyleSheet(colorful_button_style_sheet);
 sonic_button_->setStyleSheet(colorful_button_style_sheet);

 connect(updates_button_, SIGNAL(clicked()),
   this, SLOT(updates_dialog_requested()));

 connect(take_screenshot_button_, SIGNAL(clicked()),
   this, SIGNAL(take_screenshot_requested()));

 connect(open_image_button_, SIGNAL(clicked()),
   this, SIGNAL(open_image_requested()));

 connect(open_folder_button_, SIGNAL(clicked()),
   this, SIGNAL(open_folder_requested()));


// top_buttons_layout_->addWidget(button_sort_series_geometric_);
// top_buttons_layout_->addWidget(button_sort_series_abnormal_);

 top_buttons_layout_->addStretch();

 top_buttons_layout_->addWidget(updates_button_);

 top_buttons_layout_->addWidget(patient_info_button_);
 top_buttons_layout_->addWidget(diagnostic_report_button_);

 top_buttons_layout_->addWidget(open_folder_button_);
 top_buttons_layout_->addWidget(open_image_button_);
 top_buttons_layout_->addWidget(take_screenshot_button_);

 top_buttons_layout_->addWidget(sonic_button_);

 main_layout_->addLayout(top_buttons_layout_);


 main_notebook_ = new QTabWidget(this);

 QPen qpen(QColor("yellow"));
 qpen.setWidth(2);
 QBrush qbr(QColor("red"));

 dseli_view_ = new QGraphicsView(this);
 seli_source_ = new QTextEdit(this);
 instructions_ = new QTextEdit(this);
 languages_ = new QTextEdit(this);
 seli_scene_ = new QGraphicsScene(this);

 dseli_view_->setContextMenuPolicy(Qt::CustomContextMenu);
 connect(dseli_view_, SIGNAL(customContextMenuRequested(const QPoint&)),
   this, SLOT(show_seli_view_context_menu(const QPoint&)));

 scratch_scene_ = new QGraphicsScene(this);

 star_button_ = new QPushButton(this);
 ellipse_button_ = new QPushButton(this);
 diamond_button_ = new QPushButton(this);

 int center_x = 20;
 int center_y = 20;
 int scale_factor = 1;
 int radius = 15;
 int width = 10;

 QPolygonF poly1;
 poly1
     << QPointF(center_x - scale_factor * radius, center_y)
     << QPointF(center_x, center_y - scale_factor * radius)
     << QPointF(center_x + scale_factor * radius, center_y)
     << QPointF(center_x, center_y + scale_factor * radius)
    ;

   QPolygonF spoly;
   spoly
     << QPointF(center_x - scale_factor * width, center_y - scale_factor * width)
     << QPointF(center_x + scale_factor * width, center_y - scale_factor * width)
     << QPointF(center_x + scale_factor * width, center_y + scale_factor * width)
     << QPointF(center_x - scale_factor * width, center_y + scale_factor * width)

        ;

   QPolygonF poly = poly1.united(spoly);

   //scratch_scene_->addPolygon(poly1, qpen, qbr);
   scratch_scene_->addPolygon(poly, qpen, qbr);

 render_to_button(star_button_, poly);

 scratch_scene_->clear();

 scratch_scene_->addEllipse(2, 2, 35, 35, qpen, qbr);

// QPolygonF epoly;
// epoly
//   << QPointF(center_x - scale_factor * width, center_y - scale_factor * width)
//   << QPointF(center_x + scale_factor * width, center_y - scale_factor * width)
//   << QPointF(center_x + scale_factor * width, center_y + scale_factor * width)
//   << QPointF(center_x - scale_factor * width, center_y + scale_factor * width)
//      ;

 render_to_button(ellipse_button_, poly1);
 scratch_scene_->clear();


 QPolygonF dpoly;
 radius = 15;
 dpoly
   << QPointF(center_x - scale_factor * radius, center_y)
   << QPointF(center_x, center_y - scale_factor * radius)
   << QPointF(center_x + scale_factor * radius, center_y)
   << QPointF(center_x, center_y + scale_factor * radius);
      ;

 scratch_scene_->addPolygon(dpoly, qpen, qbr);

 render_to_button(diamond_button_, dpoly);
 scratch_scene_->clear();

 {
  QPolygonF ppoly;
  width = 8;
  float offset = 1;
  float scale_factor = 5;
  construct_plus(ppoly, center_x, center_y, scale_factor, offset, width);
  scratch_scene_->addPolygon(ppoly, qpen, qbr);

  plus_button_ = new QPushButton(this);

  render_to_button(plus_button_, ppoly);
  scratch_scene_->clear();
 }


// {
//  QPolygonF cppoly;
//  width = 15;
//  float offset = 10;
//  construct_plus(cppoly, center_x, center_y, scale_factor, offset, width);
//  scratch_scene_->addPolygon(cppoly, qpen, qbr);

//  //?cross_plus_button_ = new QPushButton(this);
//  //?render_to_button(cross_plus_button_, cppoly);
//  scratch_scene_->clear();
// }

// {
//  float offset = 4;
//  float width = 1;
//  float deco_offset = 3;
//  float scale_factor = 4;

//  QPolygonF dppoly;
//  construct_plus(dppoly, center_x, center_y, scale_factor, offset, width);
//  scratch_scene_->addPolygon(dppoly, qpen, qbr);

//  deco_plus_button_ = new QPushButton(this);
//  deco_plus_button_->setObjectName("deco_plus_button_");

//  render_to_button(deco_plus_button_, dppoly);
//  scratch_scene_->clear();
// }

 {
  float scale_factor = 5;
  float x_offset = 4;
  float y_offset = 4;
  float width = 8;

  QPolygonF opoly;
  construct_octagon(opoly, center_x, center_y, scale_factor, x_offset, y_offset, width);
  scratch_scene_->addPolygon(opoly, qpen, qbr);

  octagon_button_ = new QPushButton(this);
  octagon_button_->setObjectName("octagon_button_");

  render_to_button(octagon_button_, opoly);
  scratch_scene_->clear();
 }


// {
//  float offset = 4;
//  float width = 1;
//  float deco_offset = 3;
//  float scale_factor = 4;

//  QPolygonF dpoly;
//  construct_deco_plus(dpoly, center_x, center_y, scale_factor, offset, width, deco_offset);
//  scratch_scene_->addPolygon(dpoly, qpen, qbr);

//  deco_button_ = new QPushButton(this);
//  deco_button_->setObjectName("deco_button_");

//  render_to_button(deco_button_, dpoly);
//  scratch_scene_->clear();
// }

// {
//  float scale_factor = 4;
//  float x_offset = 8;
//  float y_offset = 4;
//  float width = 2;

////  float x_offset = 6;
////  float y_offset = 8;

//  QPolygonF sopoly;
//  construct_octagon(sopoly, center_x, center_y, scale_factor, x_offset, y_offset, width);
//  scratch_scene_->addPolygon(sopoly, qpen, qbr);

//  skewed_octagon_button_ = new QPushButton(this);
//  skewed_octagon_button_->setObjectName("skewed_octagon_button_");

//  render_to_button(skewed_octagon_button_, sopoly);
//  scratch_scene_->clear();
// }


 {
  float scale_factor = 4;
  float x_offset = 4;
  float y_offset = 8;
  float width = 2;

//  float x_offset = 6;
//  float y_offset = 8;

  QPolygonF vopoly;
  construct_octagon(vopoly, center_x, center_y, scale_factor, x_offset, y_offset, width);
  scratch_scene_->addPolygon(vopoly, qpen, qbr);

  vertical_octagon_button_ = new QPushButton(this);
  vertical_octagon_button_->setObjectName("vertical_octagon_button_");

  render_to_button(vertical_octagon_button_, vopoly);
  scratch_scene_->clear();
 }


// {
//  float width = 4;
//  float offset = 3;
//  float deco_offset = 2;
//  float scale_factor = 4;

//  QPolygonF stppoly;
//  construct_deco_plus(stppoly, center_x, center_y, scale_factor, offset, width, deco_offset);
//  scratch_scene_->addPolygon(stppoly, qpen, qbr);

//  skewed_tight_plus_button_ = new QPushButton(this);
//  skewed_tight_plus_button_->setObjectName("skewed_tight_plus_button_");

//  render_to_button(skewed_tight_plus_button_, stppoly);
//  scratch_scene_->clear();

// }


// {
//  float width = 3;
//  float offset = 4;
//  float deco_offset = 2;
//  float scale_factor = 4;

//  QPolygonF tppoly;
//  construct_deco_plus(tppoly, center_x, center_y, scale_factor, offset, width, deco_offset);
//  scratch_scene_->addPolygon(tppoly, qpen, qbr);

//  tight_plus_button_ = new QPushButton(this);
//  tight_plus_button_->setObjectName("tight_plus_button_");

//  render_to_button(tight_plus_button_, tppoly);
//  scratch_scene_->clear();

// }

 {
  float width = 8;
  float height = 4;
  float offset = 3;
  float scale_factor = 4;

  QPolygonF tdpoly;
  construct_triangle_down(tdpoly, center_x, center_y, scale_factor, width, height, offset);
  scratch_scene_->addPolygon(tdpoly, qpen, qbr);

  triangle_down_button_ = new QPushButton(this);
  triangle_down_button_->setObjectName("triangle_down_button_");

  render_to_button(triangle_down_button_, tdpoly);
  scratch_scene_->clear();
 }

 {
  float width = 8;
  float height = 4;
  float offset = 3;
  float scale_factor = 4;

  QPolygonF tupoly;
  construct_triangle_up(tupoly, center_x, center_y, scale_factor, width, height, offset);
  scratch_scene_->addPolygon(tupoly, qpen, qbr);

  triangle_up_button_ = new QPushButton(this);
  triangle_up_button_->setObjectName("triangle_up_button_");

  render_to_button(triangle_up_button_, tupoly);
  scratch_scene_->clear();
 }


 //?
 dseli_view_->setScene(seli_scene_);
 //seli_view_->setScene(scratch_scene_);"

 main_pixmap_item_ = new QGraphicsPixmapItem(QPixmap::fromImage(QImage(background_image_file)));

 seli_scene_->addItem(main_pixmap_item_);

 main_pixmap_item_->setFlag(QGraphicsItem::ItemIsMovable);

 //?main_seli_item_ = new QGraphicsPixmapItem();//seli_DIR "/male-body-medium-slate-blue-silhouette.seli");
 //main_scratch_seli_item_ = new QGraphicsPixmapItem(); //seli_DIR "/male-body-medium-slate-blue-silhouette.seli");
 //?inverse_seli_names_["main"] = main_seli_item_;
 //?seli_names_[main_seli_item_] = "main";


//? main_seli_item_button_ = new QPushButton(this);
//?
// silhouettes_buttons_layout_ = new QVBoxLayout;
// silhouettes_buttons_layout_->setMargin(0);
// silhouettes_buttons_layout_->setSpacing(0);

 qreal x_offset = 0;
 qreal y_offset = 0;
 qreal reenlarge_factor = 4;

 graphics_layout_ = new QHBoxLayout;
 graphics_buttons_layout_ = new QVBoxLayout;

 graphics_series_layout_ = new QVBoxLayout;

 graphics_series_frame_ = new QFrame(this);
 graphics_series_scroll_area_ = new QScrollArea(this);

 //open_folder("/home/nlevisrael/NDP/tikz/smear2005/New database pictures/moderate_dysplastic");

// QLabel* lbl = new QLabel("L1", this);

// graphics_series_layout_->addWidget(lbl);

 graphics_series_frame_->setLayout(graphics_series_layout_);

 graphics_series_scroll_area_->setWidget(graphics_series_frame_);


// QLabel* l1 = new QLabel("L1", this);
// graphics_series_layout_->addWidget(l1);

 graphics_layout_->addWidget(graphics_series_scroll_area_);

//? graphics_layout_->addLayout(silhouettes_buttons_layout_);
 graphics_layout_->addWidget(dseli_view_);
 graphics_layout_->addLayout(graphics_buttons_layout_);



 graphics_buttons_layout_->addWidget(triangle_up_button_);
 arrows_label_ = new QLabel("Arrows", this);
 add_graphics_button_text_and_line(arrows_label_);
 //?triangle_up_button_->setEnabled(false);
 triangle_up_button_->setEnabled(true);

 connect(triangle_up_button_, SIGNAL(clicked()),
   this, SLOT(add_arrow_annotation()));


 graphics_buttons_layout_->addWidget(triangle_down_button_);
 groups_label_ = new QLabel("Groups", this);
 add_graphics_button_text_and_line(groups_label_);
 triangle_down_button_->setEnabled(false);

 connect(triangle_down_button_, SIGNAL(clicked()),
   this, SLOT(add_to_arrow_group()));


 graphics_buttons_layout_->addWidget(star_button_);
 overlays_label_ = new QLabel("Overlays", this);
 add_graphics_button_text_and_line(overlays_label_);
 star_button_->setEnabled(false);


// graphics_buttons_layout_->addWidget(skewed_tight_plus_button_);
// burning_pain_label_ = new QLabel("Burning\nPain", this);
// add_graphics_button_text_and_line(burning_pain_label_);
// skewed_tight_plus_button_->setEnabled(false);

// graphics_buttons_layout_->addWidget(diamond_button_);


 graphics_buttons_layout_->addWidget(ellipse_button_);
 persistent_pain_label_ = new QLabel("Arcs", this);
 add_graphics_button_text_and_line(persistent_pain_label_);
 ellipse_button_->setEnabled(false);


 graphics_buttons_layout_->addWidget(plus_button_);
 rulers_label_ = new QLabel("Rulers", this);
 add_graphics_button_text_and_line(rulers_label_);
 plus_button_->setEnabled(false);


 //measurements_label_

// graphics_buttons_layout_->addWidget(deco_plus_button_);
// persistent_pain_label_ = new QLabel("Aching\nPain", this);
// add_graphics_button_text_and_line(persistent_pain_label_);
// deco_plus_button_->setEnabled(false);


 //?ellipse_button_->setVisible(false);
 //?cross_plus_button_->setVisible(false);
 diamond_button_->setVisible(false);
 //?triangle_up_button_->setVisible(false);
 //?
 //plus_button_->setVisible(false);
 //?deco_plus_button_->setVisible(false);
 //?skewed_octagon_button_->setVisible(false);
 vertical_octagon_button_->setVisible(false);
//?
 //?deco_button_->setVisible(false);
 octagon_button_->setVisible(false);

// skewed_tight_plus_button_->setVisible(false);
 //?tight_plus_button_->setVisible(false);


// graphics_buttons_layout_->addWidget(triangle_up_button_);
// graphics_buttons_layout_->addWidget(cross_plus_button_);
// graphics_buttons_layout_->addWidget(deco_plus_button_);
// graphics_buttons_layout_->addWidget(skewed_octagon_button_);
// graphics_buttons_layout_->addWidget(vertical_octagon_button_);
// graphics_buttons_layout_->addWidget(deco_button_);
// graphics_buttons_layout_->addWidget(octagon_button_);

// graphics_buttons_layout_->addWidget(skewed_tight_plus_button_);
// graphics_buttons_layout_->addWidget(tight_plus_button_);


// line01->setStyleSheet("QFrame{background:rgba(255,200,200,0.7);}");
// line02->setStyleSheet("QFrame{background:rgba(255,200,200,0.7);}");

// QFont f = more_shapes_label_->font();
// f.setPointSize(7);
// more_shapes_label_->setFont(f);
// edit_colors_label_->setFont(f);

// more_shapes_label_->setStyleSheet("QLabel{color:blue}");
// edit_colors_label_->setStyleSheet("QLabel{color:blue}");

// QSpacerItem* sp1 = new QSpacerItem(1, 8);
// QSpacerItem* sp2 = new QSpacerItem(1, 8);

// graphics_buttons_layout_->addItem(sp1);

// graphics_buttons_layout_->addWidget(line01);
// graphics_buttons_layout_->addWidget(more_shapes_label_);

// graphics_buttons_layout_->addItem(sp2);

// graphics_buttons_layout_->addWidget(line02);
// graphics_buttons_layout_->addWidget(edit_colors_label_);

// graphics_buttons_layout_->addStretch();

 graphics_buttons_layout_->setSpacing(0);
 graphics_buttons_layout_->setMargin(0);

 graphics_frame_ = new QFrame(this);
 graphics_frame_->setLayout(graphics_layout_);

 series_images_frame_ = new QFrame(this);
 patient_info_summary_ = new QTextEdit(this);
 diagnostic_report_summary_ = new QTextEdit(this);

 main_notebook_->addTab(graphics_frame_, "View");
 main_notebook_->addTab(instructions_, "Instructions");

 main_notebook_->addTab(series_images_frame_, "Series Images");
 main_notebook_->addTab(languages_, "Languages");
 main_notebook_->addTab(seli_source_, "Code");
 main_notebook_->addTab(patient_info_summary_, "Patient Info Summary");
 main_notebook_->addTab(diagnostic_report_summary_, "Diagnostic Report Summary");


 main_layout_->addWidget(main_notebook_);
 //?main_layout_->addLayout(url_layout_);


// annotations_layout_ = new QVBoxLayout;

// annotations_layout_->addWidget(annotations_show_button_);
// annotations_layout_->addWidget(annotations_hide_button_);

// clear_button_->setStyleSheet(colorful_button_style_sheet);
// QPushButton* annotations_show_button_;
// QPushButton* annotations_hide_button_;
// QVBoxLayout* annotations_layout_;

 zoom_row_column_layout_ = new QVBoxLayout;
 row_column_layout_ = new QHBoxLayout;

 row_label_ = new QLabel("Row:", this);
 row_line_edit_ = new QLineEdit(this);
 row_line_edit_->setPlaceholderText("?");
 row_line_edit_->setMaximumWidth(30);

 column_label_ = new QLabel("Column:", this);
 column_line_edit_ = new QLineEdit(this);
 column_line_edit_->setPlaceholderText("?");
 column_line_edit_->setMaximumWidth(30);

 abnormality_label_ = new QLabel("Abnormality:", this);
 abnormality_line_edit_ = new QLineEdit(this);
 abnormality_line_edit_->setPlaceholderText("?");
 abnormality_line_edit_->setMaximumWidth(30);

 row_column_layout_->addWidget(row_label_);
 row_column_layout_->addWidget(row_line_edit_);

 row_column_layout_->addWidget(column_label_);
 row_column_layout_->addWidget(column_line_edit_);

 row_column_layout_->addWidget(abnormality_label_);
 row_column_layout_->addWidget(abnormality_line_edit_);

 navigation_layout_ = new QHBoxLayout;
 sort_series_layout_ = new QVBoxLayout;

 zoom_row_column_layout_ = new QVBoxLayout;

 zoom_layout_ = new QHBoxLayout;

 zoom_row_column_layout_->addLayout(row_column_layout_);

 button_sort_series_label_ = new QLabel("Sort by: ", this);

 button_sort_series_geometric_ = new QPushButton("Geometric", this);
 button_sort_series_abnormal_ = new QPushButton("Abnormality", this);

 sort_series_button_group_ = new QButtonGroup(this);

 sort_series_button_group_->setExclusive(true);

 sort_series_button_group_->addButton(button_sort_series_geometric_);
 sort_series_button_group_->addButton(button_sort_series_abnormal_);

 button_sort_series_geometric_->setStyleSheet(toggle_button_style_sheet_());
 button_sort_series_abnormal_->setStyleSheet(toggle_button_style_sheet_());

 button_sort_series_geometric_->setCheckable(true);
 button_sort_series_geometric_->setChecked(true);

 button_sort_series_abnormal_->setCheckable(true);
 button_sort_series_abnormal_->setChecked(false);

 connect(sort_series_button_group_,
         static_cast<void(QButtonGroup::*)(int)>(&QButtonGroup::buttonClicked),
     [this](int id)
 {
  if(id == -2)
  {
   button_sort_series_geometric_->setChecked(true);
   button_sort_series_abnormal_->setChecked(false);

   button_sort_series_geometric_->setStyleSheet(toggle_button_style_sheet_());
   button_sort_series_abnormal_->setStyleSheet(toggle_button_style_sheet_());

  }
  else if(id == -3)
  {
   button_sort_series_geometric_->setChecked(false);
   button_sort_series_abnormal_->setChecked(true);

   button_sort_series_geometric_->setStyleSheet(toggle_button_style_sheet_());
   button_sort_series_abnormal_->setStyleSheet(toggle_button_style_sheet_());

//   button_sort_series_abnormal_->repaint();
//   button_sort_series_geometric_->repaint();


  }
  //qDebug() << "ID: " << id;
 });

 sort_series_layout_->addWidget(button_sort_series_label_);
 sort_series_layout_->addWidget(button_sort_series_geometric_);
 sort_series_layout_->addWidget(button_sort_series_abnormal_);

 navigation_layout_->addLayout(sort_series_layout_);

 navigation_layout_->addStretch();


 tile_up_button_ = new QPushButton(this);
 tile_down_button_ = new QPushButton(this);
 tile_left_button_ = new QPushButton(this);
 tile_right_button_ = new QPushButton(this);
 tile_previous_button_ = new QPushButton(this);
 tile_next_button_ = new QPushButton(this);


 tile_up_button_->setIcon(QIcon("/extension/ka/svg/Human-go-up.svg"));
 tile_down_button_->setIcon(QIcon("/extension/ka/svg/Human-go-down.svg"));

 tile_left_button_->setIcon(QIcon("/extension/ka/svg/Human-go-previous.svg"));
 tile_right_button_->setIcon(QIcon("/extension/ka/svg/Human-go-next.svg"));

 tile_previous_button_->setIcon(QIcon("/extension/ka/svg/Gtk-go-up.svg"));
 tile_next_button_->setIcon(QIcon("/extension/ka/svg/Gtk-go-down.svg"));

 navigation_buttons_previous_next_layout_ = new QVBoxLayout;

 navigation_buttons_previous_next_layout_->addWidget(tile_previous_button_);
 navigation_buttons_previous_next_layout_->addWidget(tile_next_button_);

 connect(tile_up_button_, &QPushButton::clicked,
   [this]
 {
  if(current_tile_)
  {
   if(current_tile_map_)
   {
    int r = current_tile_->series_row();
    if(r > 0)
    {
     --r;
     int c = current_tile_->series_column();
     check_tile_geometric_navigate(r, c);
    }
   }
  }
 });

 connect(tile_left_button_, &QPushButton::clicked,
   [this]
 {
  if(current_tile_)
  {
   if(current_tile_map_)
   {
    int c = current_tile_->series_column();
    if(c > 0)
    {
     --c;
     int r = current_tile_->series_row();
     check_tile_geometric_navigate(r, c);
    }
   }
  }
 });

 connect(tile_down_button_, &QPushButton::clicked,
   [this]
 {
  if(current_tile_)
  {
   if(current_tile_map_)
   {
    int r = current_tile_->series_row();
    ++r;
    int c = current_tile_->series_column();
    check_tile_geometric_navigate(r, c);
   }
  }
 });

 connect(tile_right_button_, &QPushButton::clicked,
   [this]
 {
  if(current_tile_)
  {
   if(current_tile_map_)
   {
    int c = current_tile_->series_column();
    ++c;
    int r = current_tile_->series_row();
    check_tile_geometric_navigate(r, c);
   }
  }
 });

 connect(tile_previous_button_, &QPushButton::clicked,
   [this]
 {
  if(current_tile_)
  {
   if(WSI_Tile* new_tile = current_tile_->geometric_previous())
   {
    int r = new_tile->series_row();
    int c = new_tile->series_column();
    check_tile_geometric_navigate(r, c);
   }
  }
 });

 connect(tile_next_button_, &QPushButton::clicked,
   [this]
 {
  if(current_tile_)
  {
   if(WSI_Tile* new_tile = current_tile_->geometric_next())
   {
    int r = new_tile->series_row();
    int c = new_tile->series_column();
    check_tile_geometric_navigate(r, c);
   }
  }
 });

 navigation_buttons_layout_ = new QGridLayout;

 navigation_buttons_layout_->addWidget(tile_up_button_, 0, 1);
 navigation_buttons_layout_->addWidget(tile_left_button_, 1, 0);
 navigation_buttons_layout_->addWidget(tile_right_button_, 1, 2);
 navigation_buttons_layout_->addWidget(tile_down_button_, 2, 1);

 navigation_layout_->addLayout(navigation_buttons_layout_);

 navigation_layout_->addStretch();

 navigation_layout_->addLayout(navigation_buttons_previous_next_layout_);

 navigation_layout_->addStretch();

 QLabel* zoom_label = new QLabel("Image Zoom:", this);

 zoom_layout_->addWidget(zoom_label);

 zoom_slider_ = new QSlider(Qt::Horizontal, this);


 connect(zoom_slider_, SIGNAL(valueChanged(int)), this,
   SLOT(zoom_slider_value_changed(int)));



 QString s1 = QString("%1").arg(QChar(5184));
 zoom_in_button_ = new QPushButton(s1, this);
 zoom_in_button_->setStyleSheet("QPushButton{font-size: 12pt;"
                                "font-weight: bold;"
                                "color: brown;}");
// zoom_in_button_->setFont(zif);
 zoom_in_button_->setMaximumWidth(25);
 zoom_in_button_->setMaximumHeight(15);


 QString s2 = QString("%1").arg(QChar(5189));
 zoom_out_button_ = new QPushButton(s2, this);
 zoom_out_button_->setStyleSheet("QPushButton{font-size: 12pt;"
                                "font-weight: bold; padding:0px; "
                                "color: brown;}");
 zoom_out_button_->setMaximumWidth(25);
 zoom_out_button_->setMaximumHeight(15);

 connect(zoom_in_button_, SIGNAL(pressed()), this, SLOT(zoom_in()));
 connect(zoom_out_button_, SIGNAL(pressed()), this, SLOT(zoom_out()));

 zoom_layout_->addStretch();

 zoom_layout_->addWidget(zoom_slider_);
 zoom_layout_->addItem(new QSpacerItem(15, 1));

 zoom_layout_->addWidget(zoom_out_button_);
 zoom_layout_->addItem(new QSpacerItem(5, 1));

 zoom_layout_->addWidget(zoom_in_button_);

 zoom_layout_->addItem(new QSpacerItem(16, 1));

 zoom_layout_->addStretch();

 zoom_row_column_layout_->addLayout(zoom_layout_);


 navigation_layout_->addLayout(zoom_row_column_layout_);

 navigation_layout_->addStretch();

 annotations_show_hide_layout_ = new QVBoxLayout;

 annotations_show_hide_label_ = new QLabel("Annotations...", this);

 annotations_show_button_ = new QPushButton("Show", this);
 annotations_hide_button_ = new QPushButton("Hide", this);

 annotations_show_button_->setStyleSheet(toggle_button_style_sheet_());
 annotations_hide_button_->setStyleSheet(toggle_button_style_sheet_());

 annotations_show_button_->setCheckable(true);
 annotations_show_button_->setChecked(true);

 annotations_hide_button_->setCheckable(true);
 annotations_hide_button_->setChecked(false);



 annotations_show_hide_layout_->addWidget(annotations_show_hide_label_);
 annotations_show_hide_layout_->addWidget(annotations_show_button_);
 annotations_show_hide_layout_->addWidget(annotations_hide_button_);

 navigation_layout_->addLayout(annotations_show_hide_layout_);

 main_layout_->addLayout(navigation_layout_);



 combined_mode_button_layout_ = new QHBoxLayout;
 mode_button_layout_ = new QHBoxLayout;
 annotations_mode_button_layout_ = new QHBoxLayout;

 mode_group_box_ = new QGroupBox("Image and Group Transforms ...", this);
 mode_button_group_ = new QButtonGroup(this);
 mode_zoom_button_ = new QPushButton("Zoom", this);
 mode_zoom_button_->setCheckable(true);
 mode_pan_button_ = new QPushButton("Pan", this);
 mode_pan_button_->setCheckable(true);
 mode_slide_button_ = new QPushButton("Group Transform", this);
 mode_slide_button_->setCheckable(true);

 mode_zoom_button_->setChecked(true);
 current_mode_button_ = mode_zoom_button_;

 mode_button_group_->addButton(mode_zoom_button_);
 mode_button_group_->addButton(mode_pan_button_);
 mode_button_group_->addButton(mode_slide_button_);

 mode_button_layout_->addWidget(mode_pan_button_);
 mode_button_layout_->addWidget(mode_zoom_button_);
 mode_button_layout_->addWidget(mode_slide_button_);
 mode_group_box_->setLayout(mode_button_layout_);


 combined_mode_button_layout_->addWidget(mode_group_box_);

 annotations_mode_group_box_ = new QGroupBox("Single Annotation Transforms ...", this);
 annotations_mode_button_group_ = new QButtonGroup(this);

 annotations_mode_pan_button_ = new QPushButton("Pan", this);
 annotations_mode_pan_button_->setCheckable(true);
 annotations_mode_rotate_button_ = new QPushButton("Rotate", this);
 annotations_mode_rotate_button_->setCheckable(true);
 annotations_mode_zoom_button_ = new QPushButton("Zoom", this);
 annotations_mode_zoom_button_->setCheckable(true);

 annotations_mode_pan_button_->setChecked(true);

 annotations_mode_button_group_->addButton(annotations_mode_pan_button_);
 annotations_mode_button_group_->addButton(annotations_mode_rotate_button_);
 annotations_mode_button_group_->addButton(annotations_mode_zoom_button_);

 annotations_mode_button_layout_->addWidget(annotations_mode_pan_button_);
 annotations_mode_button_layout_->addWidget(annotations_mode_rotate_button_);
 annotations_mode_button_layout_->addWidget(annotations_mode_zoom_button_);
 annotations_mode_group_box_->setLayout(annotations_mode_button_layout_);

 mode_zoom_button_->setStyleSheet(colorful_toggle_button_style_sheet);
 mode_pan_button_->setStyleSheet(colorful_toggle_button_style_sheet);
 mode_slide_button_->setStyleSheet(colorful_toggle_button_style_sheet);
 annotations_mode_zoom_button_->setStyleSheet(colorful_toggle_button_style_sheet);
 annotations_mode_pan_button_->setStyleSheet(colorful_toggle_button_style_sheet);
 annotations_mode_rotate_button_->setStyleSheet(colorful_toggle_button_style_sheet);


 connect(annotations_mode_button_group_, SIGNAL(buttonClicked(int)),
   this, SLOT(handle_annotation_mode_button_clicked(int)));

 connect(mode_button_group_, SIGNAL(buttonClicked(int)),
   this, SLOT(handle_mode_button_clicked(int)));

 combined_mode_button_layout_->addWidget(annotations_mode_group_box_);


 main_layout_->addLayout(combined_mode_button_layout_);

// clear_button_layout_->setEnabled(false);



// QLineEdit* vbl = new QLineEdit("1  1  1  1  " , this);
// QPushButton* vb = new QPushButton("Adjust", this);

// connect(vb, &QPushButton::pressed, [this, vbl]
// {
//  QStringList qsl = vbl->text().split(" ");
//  int x = qsl[0].toInt();
//  int y = qsl[1].toInt();
//  int w = qsl[2].toInt();
//  int h = qsl[3].toInt();
//  QRect view_rect = QRect(x, y, w, h);

//  QRect viewbox = current_seli_item_->renderer()->viewBox();
//  qDebug() << viewbox;

//  current_seli_item_->renderer()->setViewBox(view_rect);
//  current_seli_item_->update();
// });

// clear_button_layout_->addWidget(vbl);
// clear_button_layout_->addWidget(vb);

// clear_button_layout_->addWidget(zoom_out_button_);
// clear_button_layout_->addItem(new QSpacerItem(5, 1));

// clear_button_layout_->addWidget(zoom_in_button_);

// clear_button_layout_->addItem(new QSpacerItem(16, 1));

// clear_button_layout_->addWidget(clear_button_);
// clear_button_layout_->addStretch();

// main_layout_->addLayout(clear_button_layout_);


 dseli_view_->setMinimumWidth(300);

 main_layout_->addWidget(button_box_);

 setLayout(main_layout_);

 original_width_ = this->width();
 original_height_ = this->height();

 //connect(this, SIGNAL(resizeEvent(QResizeEvent*)));

 show();
}

void MMUI_Annotations_Dialog::check_tile_geometric_navigate(int r, int c)
{
 QString tile_file = QString("r%1c%2").arg(r).arg(c);

 WSI_Tile* new_tile = current_tile_map_->value(tile_file);

 if(new_tile)
 {
  if(QObject* qob = new_tile->associated_qobject())
  {
   ClickableLabel* cl = qobject_cast<ClickableLabel*>(qob);
   open_file(cl->path);
   current_clickable_label_ = cl;
   current_tile_ = new_tile;
  }
 }
}


void MMUI_Annotations_Dialog::handle_mode_button_clicked(int button_id)
{
 switch(button_id)
 {
 case -2:
  current_mode_button_ = mode_pan_button_;
  triangle_down_button_->setEnabled(false);
  // pan
  //arrow_factory_->set_current_mouse_action_mode(MMUI_Arrow_Factory::Mouse_Action_Modes::Arrow_Move);
  break;

 case -3:
  current_mode_button_ = mode_zoom_button_;
  triangle_down_button_->setEnabled(false);
  // zoom
  //arrow_factory_->set_current_mouse_action_mode(MMUI_Arrow_Factory::Mouse_Action_Modes::Arrow_Rotate);
  break;

 case -4:
  // groups
  check_activate_group_transforms();
  //triangle_down_button_->setEnabled(true);
  break;

 default:
  break;
 }
}


void MMUI_Annotations_Dialog::updates_dialog_requested()
{
 MMUI_KA_Update_Dialog* dlg = new MMUI_KA_Update_Dialog(this);
 dlg->show();
}


void MMUI_Annotations_Dialog::check_activate_group_transforms()
{
 if(visible_annotations_count_ > 0)
 {
  triangle_down_button_->setEnabled(true);
 }
 else
 {
  QMessageBox::critical(this, "No visible annotations!",
    "Before creating or editing annotation groups you must "
    "have one or more non-overlay annotations added "
    "to the image, and currently visible"
                        );
  current_mode_button_->setChecked(true);
 }

}

void MMUI_Annotations_Dialog::handle_annotation_mode_button_clicked(int button_id)
{
 switch(button_id)
 {
 case -2:
  // pan
  arrow_factory_->set_current_mouse_action_mode(MMUI_Arrow_Factory::Mouse_Action_Modes::Arrow_Move);
  break;

 case -3:
  // rotate
  arrow_factory_->set_current_mouse_action_mode(MMUI_Arrow_Factory::Mouse_Action_Modes::Arrow_Rotate);
  break;

 case -4:
  // zoom
  arrow_factory_->set_current_mouse_action_mode(MMUI_Arrow_Factory::Mouse_Action_Modes::Arrow_Stretch);
  break;

 default:
  break;
 }

}


#ifdef HIDE
void MMUI_Annotations_Dialog::save_scene()
{
 QString path = QFileDialog::getSaveFileName(this, "Select Graphics", DEMO_DIR);
 QFile file (path);
 file.open(QIODevice::WriteOnly);
 QDataStream outstream(&file);

 QByteArray qba;
 get_all_scene_data(qba);
 outstream << qba;
 file.close();
}

void MMUI_Annotations_Dialog::load_all_scene_data(QByteArray& qba)
{

 current_seli_specific_items_.clear();

 QDataStream qds(&qba, QIODevice::ReadOnly);

 QMap<QString, QVector<QPair<QString, QPair<QPointF, QPair<qreal, QRectF>> > > > mm;

 QString csi;
 qds >> csi;

 if(current_seli_item_)
  current_seli_item_->setVisible(false);

 current_seli_item_ = inverse_seli_names_[csi];

 current_seli_item_->setVisible(true);

 QMap<QString, qreal> scales;
 qds >> scales;

 int zsv;
 qds >> zsv;
 zoom_slider_->setValue(zsv);

 qds >> mm;

 if(!mm.isEmpty())
 {
  enable_graphics_buttons();
 }

 QMapIterator<QString, QVector<QPair<QString, QPair<QPointF, QPair<qreal, QRectF>> > > > it(mm);
 while(it.hasNext())
 {
  it.next();
  QGraphicsPixmapItem* k = inverse_seli_names_[it.key()];
  qreal scale = scales[it.key()];
  k->setScale(scale);

  const QVector<QPair<QString, QPair<QPointF, QPair<qreal, QRectF>> > >& v = it.value();
  for(const QPair<QString, QPair<QPointF, QPair<qreal, QRectF>> >& pr : v)
  {
   QString bn = pr.first;
   QPushButton* qbn = findChildren<QPushButton*>(bn).first();
   QPolygonF poly = polys_[qbn];

   QPen qpen(QColor("red"));
   QBrush qbr(QColor("brown"));

   QGraphicsItem* item = seli_scene_->addPolygon(poly, qpen, qbr);
   item->setFlag(QGraphicsItem::ItemIsSelectable);
   item->setFlag(QGraphicsItem::ItemIsMovable);
   item->setFlag(QGraphicsItem::ItemIsFocusable);

   item->setData(0, bn);

   QPointF qpf = pr.second.first;
   qreal scale = pr.second.second.first;
   QRectF qrf = pr.second.second.second;
   item->setPos(qpf);
   item->update(qrf);
   item->setScale(scale);
//   item->setPos(qrf.topLeft());
//   item->setScale(qrf.sc
//   item->

   current_seli_specific_items_[k].push_back(item);


   if(k == current_seli_item_)
   {
    // redundant?
    item->setVisible(true);
    QLabel* lbl = labels_to_items_[k];
    lbl->setStyleSheet("QLabel { background-color : salmon; margin-bottom:10px;}");
    if(current_seli_label_)
     current_seli_label_->setStyleSheet("QLabel { background-color : none; margin-bottom:10px;}");
    current_seli_label_ = lbl;
   }
   else
    item->setVisible(false);

  }
 }

// for(QGraphicsItem* item : current_seli_specific_items_[current_seli_item_])
// {
//  item->setVisible(true);
// }


 //QMap<QString, QVector<QGraphicsItem*> > mm;

// qds >> current_seli_specific_items_;

// qba >> current_seli_specific_items_;
}

void MMUI_Annotations_Dialog::get_all_scene_data(QByteArray& qba)
{
 QDataStream qds(&qba, QIODevice::WriteOnly);

 QMap<QString, QVector<QPair<QString, QPair<QPointF, QPair<qreal, QRectF>> > > > mm;

 QMap<QString, qreal> scales;

 qds << seli_names_[current_seli_item_];

//// qba << current_seli_specific_items_;
 QMapIterator<QGraphicsPixmapItem*, QVector<QGraphicsItem*> > it(current_seli_specific_items_);
 while(it.hasNext())
 {
  it.next();
  QString k = seli_names_[it.key()];
  scales[k] = it.key()->scale();
  QVector<QPair<QString, QPair<QPointF, QPair<qreal, QRectF>> > >& v = mm[k];
  for(QGraphicsItem* qgi : it.value())
  {
   QString bn = qgi->data(0).toString();
   QRectF qrf = qgi->boundingRect();
   QPointF qpf = qgi->pos();
   qreal scale = qgi->scale();
   v.push_back({bn, {qpf, {scale, qrf}}});
  }
 }

//?
 qds << scales;

 qds << zoom_slider_->value();

 qds << mm;


}

void MMUI_Annotations_Dialog::open_scene()
{
 QString path = QFileDialog::getOpenFileName(this, "Select Graphics", DEMO_DIR);
 QFile file (path);
 if(file.open(QIODevice::ReadOnly))
 {
  QDataStream qds(&file);
  QByteArray qba;
  qds >> qba;
  load_all_scene_data(qba);
  file.close();
 }
}


void MMUI_Annotations_Dialog::handle_edit_pain_level(QGraphicsItem* item)
{
 Pain_Edit_Dialog* ped = new Pain_Edit_Dialog(this, "I-5");
 connect(ped, &Pain_Edit_Dialog::proceed_requested, [this, item](QString code)
 {
  QString constancy = code.left(1);
  QString pl = code.mid(2);
  qDebug() << "C: " << constancy << "PL: " << pl;

  QGraphicsItem* r = item->childItems().first();
  QGraphicsTextItem* ti = (QGraphicsTextItem*) r->childItems().first();

  QString h = ti->data(0).toString();

  ti->setHtml(h.arg(constancy).arg(pl));

 });
 ped->show();
}
#endif

void MMUI_Annotations_Dialog::show_seli_view_context_menu(const QPoint& p)
{
 //qDebug() << p;

 QGraphicsItem* item = dseli_view_->itemAt(p);

 QPoint scp = this->mapToGlobal(p);

  //scp -= QPoint(0, 30);

 QMenu menu;

 if(item)
 {
  QAction* save_action = menu.addAction("Save");
  connect(save_action, &QAction::triggered,
    [item, this]
  {
   save_scene();
  });

  QAction* open_action = menu.addAction("Open");
  connect(open_action, &QAction::triggered,
    [item, this]
  {
   open_scene();
  });

  // i.e., the item is a symbol icon not the silhouette
  if(item != current_seli_item_)
  {
   QAction* edit_pain_level_action = menu.addAction("Edit Arrow");
   QAction* remove_action = menu.addAction("Remove");
   QAction* smaller_action = menu.addAction("Make Smaller");
   QAction* larger_action = menu.addAction("Make Larger");


   QAction* info_action = menu.addAction("Image Info");

   connect(info_action, &QAction::triggered,
     [item, this]
   {
    MMUI_KA_PNG_Dialog* dlg = new MMUI_KA_PNG_Dialog(current_image_file_,
      //?"/home/nlevisrael/NDP/screenshots/centcomm/blood-availability-dialog-1.png",
      this);

    dlg->show();
    //?handle_edit_arrow(item);
   });



   connect(edit_pain_level_action, &QAction::triggered,
     [item, this]
   {
    //?handle_edit_arrow(item);
   });

   connect(remove_action, &QAction::triggered,
     [item, this]
   {
    seli_scene_->removeItem(item);
    //   seli_scene_->update();
   });

   connect(smaller_action, &QAction::triggered,
     [item, this]
   {
    item->setScale(item->scale() - 0.125);
    //   seli_scene_->update();
   });

   connect(larger_action, &QAction::triggered,
     [item, this]
   {
    item->setScale(item->scale() + 0.125);
    //   seli_scene_->update();
   });
  }
  menu.exec(scp);
 }
}


void MMUI_Annotations_Dialog::enable_graphics_buttons()
{
 //?deco_plus_button_->setEnabled(true);
 //?star_button_->setEnabled(true);
 //?skewed_tight_plus_button_->setEnabled(true);
 //?triangle_down_button_->setEnabled(true);
}


void MMUI_Annotations_Dialog::add_graphics_button_text_and_line(QLabel* label)
{
 graphics_buttons_layout_->addWidget(label);
 QFrame* line = new QFrame(this);
 line->setGeometry(QRect(320, 150, 118, 3));
 line->setFrameShape(QFrame::HLine);
 line->setFrameShadow(QFrame::Raised);
 graphics_buttons_layout_->addWidget(line);
 line->setStyleSheet("QFrame{background:rgba(255,200,200,0.7);}");

 QFont f = label->font();
 f.setPointSize(10);
 label->setFont(f);
 label->setStyleSheet("QLabel{color:darkslateblue;font-weight:900}");

 graphics_buttons_layout_->addStretch();
}



void MMUI_Annotations_Dialog::clear_button_clicked()
{
 //?main_text_->clear();
}

void MMUI_Annotations_Dialog::horizontal_flip_transform(QGraphicsPixmapItem* item, int x_offset)
{
 int w = item->boundingRect().width()/2;

// if(x_offset == 0)
//  x_offset = w;
// qDebug() << w;

 QTransform qtr = QTransform::fromScale(-1, 1);
// qDebug() << qtr;

 int xow = x_offset - w/2;

 item->setTransformOriginPoint(xow, 0);
 item->setTransform(qtr);
}

void MMUI_Annotations_Dialog::vertical_flip_transform_alt(QGraphicsPixmapItem* item, int y_offset)
{
 int h = item->boundingRect().height()/2;
 QTransform qtr = QTransform().translate(0, h).fromScale(1, -1).translate(0, y_offset - h);
 item->setTransform(qtr);
}


void MMUI_Annotations_Dialog::horizontal_flip_transform_alt(QGraphicsPixmapItem* item, int x_offset)
{
 int w = item->boundingRect().width()/2;

// if(x_offset == 0)
//  x_offset = w;
//// qDebug() << w;


 QTransform qtr = QTransform().translate(w, 0).fromScale(-1, 1).translate(x_offset - w, 0);
// qDebug() << qtr;

// int xow = x_offset - w/2;

// item->setTransformOriginPoint(-xow, 0);
 item->setTransform(qtr);
}


void MMUI_Annotations_Dialog::zoom_slider_value_changed(int val)
{
 int diff = val - old_zoom_slider_value_;
 old_zoom_slider_value_ = val;
 int max = zoom_slider_->maximum();
 //int current = val;

 qreal ratio = 1 + ((qreal)diff)/((qreal)max);

 //?
 main_pixmap_item_->setScale(main_pixmap_item_->scale() * ratio);

}

void MMUI_Annotations_Dialog::zoom_in()
{
 //?
 main_pixmap_item_->setScale(main_pixmap_item_->scale() + 0.125);
}

void MMUI_Annotations_Dialog::zoom_out()
{
 //?
 main_pixmap_item_->setScale(main_pixmap_item_->scale() - 0.125);
}


void MMUI_Annotations_Dialog::graphics_button_clicked()
{
 if(!current_seli_item_)
 {
  // // the buttons which emit the clicked signal
   //   should only by enabled when current_seli_item_
   //   is defined.
  return;
 }

 QPen qpen(QColor("red"));
 QBrush qbr(QColor("brown"));

 QPushButton* btn = qobject_cast<QPushButton*>(sender());
 QPolygonF poly = polys_[btn];
 QGraphicsItem* item = seli_scene_->addPolygon(poly, qpen, qbr);
 item->setFlag(QGraphicsItem::ItemIsSelectable);
 item->setFlag(QGraphicsItem::ItemIsMovable);
 item->setFlag(QGraphicsItem::ItemIsFocusable);

 QString bn = btn->objectName();
 item->setData(0, bn);

 current_seli_specific_items_[current_seli_item_].push_back(item);


 //QGraphicsTextItem* text_pc = seli_scene_->addText("?");


 QRectF r = item->boundingRect();
 r.moveTop(-6);
 r.setHeight(11);
 r.moveLeft(5);
 r.setWidth(25);

 QGraphicsRectItem* rect_pl = seli_scene_->addRect(r,
   QPen(QColor("yellow")),
   QBrush(QColor("#EA3AD2")));

 QGraphicsTextItem* text_pl = seli_scene_->addText("?");

 text_pl->setZValue(1);

 rect_pl->setParentItem(item);
 text_pl->setParentItem(rect_pl);

 text_pl->moveBy(5, -11);

// text_pc->setTextWidth(13);
// text_pl->setTextWidth(8);

 //text_pc->setF

// QString wrap = "<div style='border:solid yellow 1px;"
//   "border-right:ridge pink  1px; border-bottom:ridge yellow 1px; "
//   "width:10px;"
//   "font-family:serif'>%1</div>";

 QString wrap = "<div style='font-weight:900;font-size:7pt;"
   "color:white;width:13px;"
   "font-family:serif'>%1&nbsp;&nbsp;<span style='margin-left:6px'>%2</span></div>";

 //text_pc->setHtml(wrap.arg("I"));
 text_pl->setHtml(wrap.arg("I").arg("5"));


 text_pl->setData(0, QVariant(wrap));

// text_pc->setBrush(QBrush(QColor("black")));
// text_pc->setPen(QPen(QColor("yellow")));

// text_pl->setBrush(QBrush(QColor("black")));
// text_pl->setPen(QPen(QColor("yellow")));

// item->setData(1, text_pc);
// item->setData(2, text_pl);

}



MMUI_Annotations_Dialog::~MMUI_Annotations_Dialog()
{
 delete button_ok_;
 delete button_proceed_;
 delete button_cancel_;

// delete url_label_;
// delete name_qle_;
}


void MMUI_Annotations_Dialog::save_scene()
{
}

void MMUI_Annotations_Dialog::open_scene()
{
}

void MMUI_Annotations_Dialog::cancel()
{
 Q_EMIT(rejected());
 Q_EMIT(canceled(this));Q_EMIT(rejected());close();
//
 close();
}

void MMUI_Annotations_Dialog::accept()
{
 Q_EMIT(accepted(this));
// close();
}


