
#ifndef MMUI_ANNOTATIONS_DIALOG__H
#define MMUI_ANNOTATIONS_DIALOG__H

#include <QObject>

#include <QMetaType>

#include <QList>
#include <QGraphicsScene>
#include <QPoint>

#include <QDialog>

#include "accessors.h"


class QDialogButtonBox;
class QLabel;
class QLineEdit;
class QTabWidget;
class QTextEdit;
class QFrame;
class QHBoxLayout;
class QVBoxLayout;
class QSlider;
class QPlainTextEdit;
class QBoxLayout;
class QButtonGroup;
class QGroupBox;
class QScrollArea;
class QGridLayout;

class WSI_Tile;

class ClickableLabel;

class MMUI_Arrow_Factory;
class MMUI_Arrow_Group;
class MMUI_Arrow;

class MMUI_Annotations_Dialog : public QDialog
{

 Q_OBJECT

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QPushButton* button_proceed_;

 qreal old_zoom_slider_value_;

 QString background_image_file_;

 QLabel* url_label_;
 QLineEdit* url_line_edit_;

 QTabWidget* main_notebook_;
 QGraphicsView* dseli_view_;

 QFrame* series_images_frame_;
 QTextEdit* seli_source_;
 QTextEdit* instructions_;
 QTextEdit* languages_;

 QTextEdit* patient_info_summary_;
 QTextEdit* diagnostic_report_summary_;

 QGraphicsScene* seli_scene_;

 QGraphicsPixmapItem* current_seli_item_;

 MMUI_Arrow_Factory* arrow_factory_;

 QMap<QGraphicsPixmapItem*, QVector<QGraphicsItem*> > current_seli_specific_items_;

 //QMap<QString, QString> seli_paths_;
 QMap<QGraphicsPixmapItem*, QString> seli_names_;
 QMap<QString, QGraphicsPixmapItem*> inverse_seli_names_;

 //?QMap<QString, QPolygonF> polys_by_name_;

 QLabel* current_seli_label_;

 QGraphicsPixmapItem* main_pixmap_item_;

 QMap<QString, WSI_Tile*>* current_tile_map_;

//? QGraphicsPixmapItem* main_seli_item_;
 //QGraphicsPixmapItem* main_scratch_seli_item_;
//? QPushButton* main_seli_item_button_;

 QGraphicsScene* scratch_scene_;

 QMap<QGraphicsPixmapItem*, QLabel*> labels_to_items_;

 QPushButton* star_button_;
 QPushButton* ellipse_button_;
 QPushButton* diamond_button_;
 QPushButton* plus_button_;
 QPushButton* octagon_button_;
 QPushButton* vertical_octagon_button_;
 QPushButton* triangle_down_button_;
 QPushButton* triangle_up_button_;

 // QPushButton* cross_plus_button_;
// QPushButton* deco_plus_button_;
// QPushButton* octagon_button_;
// QPushButton* vertical_octagon_button_;
// QPushButton* deco_button_;
// QPushButton* skewed_octagon_button_;
// QPushButton* skewed_tight_plus_button_;
// QPushButton* tight_plus_button_;
// QPushButton* triangle_down_button_;
// QPushButton* triangle_up_button_;

 QLabel* arrows_label_;
 QLabel* rulers_label_;

 QLabel* persistent_pain_label_;
 QLabel* overlays_label_;
 QLabel* groups_label_;
 QLabel* burning_pain_label_;

 QFrame* graphics_frame_;
 QHBoxLayout* graphics_layout_;
 QVBoxLayout* graphics_buttons_layout_;

 QVBoxLayout* graphics_series_layout_;
 QFrame* graphics_series_frame_;
 QScrollArea* graphics_series_scroll_area_;
 QList<QGraphicsPixmapItem*> graphics_series_list_;

// QVBoxLayout* silhouettes_buttons_layout_;


 QVBoxLayout* main_layout_;


 QHBoxLayout* top_buttons_layout_;

 QButtonGroup* sort_series_button_group_;
 QPushButton* button_sort_series_geometric_;
 QPushButton* button_sort_series_abnormal_;

 QLabel* button_sort_series_label_;

 QPushButton* updates_button_;

 QPushButton* patient_info_button_;
 QPushButton* diagnostic_report_button_;

 QPushButton* open_folder_button_;

 QPushButton* open_image_button_;
 QPushButton* take_screenshot_button_;

 QPushButton* sonic_button_;


//? CTQ_Antemodel* antemodel_;

 int original_width_;
 int original_height_;

 int visible_annotations_count_;

 QHBoxLayout* navigation_layout_;
 QVBoxLayout* sort_series_layout_;

 WSI_Tile* current_tile_;

 QPushButton* tile_up_button_;
 QPushButton* tile_down_button_;
 QPushButton* tile_left_button_;
 QPushButton* tile_right_button_;

 QPushButton* tile_previous_button_;
 QPushButton* tile_next_button_;


 QGridLayout* navigation_buttons_layout_;
 QVBoxLayout* navigation_buttons_previous_next_layout_;

 QHBoxLayout* zoom_layout_;

 QLabel* annotations_show_hide_label_;
 QPushButton* annotations_show_button_;
 QPushButton* annotations_hide_button_;
 QVBoxLayout* annotations_show_hide_layout_;

 QVBoxLayout* zoom_row_column_layout_;
 QHBoxLayout* row_column_layout_;

 QLabel* row_label_;
 QLineEdit* row_line_edit_;
 QLabel* column_label_;
 QLineEdit* column_line_edit_;
 QLabel* abnormality_label_;
 QLineEdit* abnormality_line_edit_;


 QPushButton* zoom_in_button_;
 QPushButton* zoom_out_button_;

 QHBoxLayout* mode_button_layout_;

 QGroupBox* mode_group_box_;

 QHBoxLayout* combined_mode_button_layout_;
 QButtonGroup* mode_button_group_;
 QPushButton* mode_zoom_button_;
 QPushButton* mode_pan_button_;
 QPushButton* mode_slide_button_;

 QPushButton* current_mode_button_;

 QGroupBox* annotations_mode_group_box_;
 QButtonGroup* annotations_mode_button_group_;
 QHBoxLayout* annotations_mode_button_layout_;
 QPushButton* annotations_mode_pan_button_;
 QPushButton* annotations_mode_rotate_button_;
 QPushButton* annotations_mode_zoom_button_;

 ClickableLabel* current_clickable_label_;

 MMUI_Arrow_Group* current_arrow_group_;
 MMUI_Arrow* current_arrow_;

 QSlider* zoom_slider_;

 QMap<QPushButton*, QPolygonF> polys_;

 QString current_image_file_;

 void read_file(QString path, QPlainTextEdit* qpte);

 void render_to_button(QPushButton* btn, QPolygonF& poly);

 void render_to_button(QPushButton* btn, QGraphicsPixmapItem* item,
   QGraphicsPixmapItem* scratch_item, QBoxLayout* layout, qreal x_offset, qreal y_offset,
   qreal reenlage_factor, QString text, qreal rotate = 0);

 static void construct_octagon(QPolygonF& poly, float center_x, float center_y,
   float scale_factor, float x_offset, float y_offset, float width);

 static void construct_plus(QPolygonF& poly, float center_x, float center_y,
   float scale_factor, float offset, float width);

 static void construct_deco_plus(QPolygonF& poly, float center_x, float center_y,
   float scale_factor, float offset, float width, float deco_offset);

 static void construct_triangle_down(QPolygonF& poly, float center_x, float center_y,
   float scale_factor, float width, float height, float y_offset);

 static void construct_triangle_up(QPolygonF& poly, float center_x, float center_y,
   float scale_factor, float width, float height, float y_offset);


 void horizontal_flip_transform(QGraphicsPixmapItem* item, int x_offset = 0);
 void horizontal_flip_transform_alt(QGraphicsPixmapItem* item, int x_offset = 0);
 void vertical_flip_transform_alt(QGraphicsPixmapItem* item, int y_offset = 0);

 void add_graphics_button_text_and_line(QLabel* label);

 void enable_graphics_buttons();

 void check_activate_group_transforms();

 void check_tile_geometric_navigate(int r, int c);

 //?void handle_edit_pain_level(QGraphicsItem* item);


public:

 ACCESSORS(QString ,background_image_file)

 void open_file(QString file);
 void open_folder(QString path);


 MMUI_Annotations_Dialog(MMUI_Arrow_Factory* arrow_factory, QString background_image_file, QWidget* parent = nullptr);

 ~MMUI_Annotations_Dialog();

 void init_current_arrow_group();


Q_SIGNALS:
 void canceled(QDialog*);
 void accepted(QDialog*);

 void take_screenshot_requested();
 void open_image_requested();
 void open_folder_requested();

public Q_SLOTS:

 void accept();
 void cancel();

 void updates_dialog_requested();

 void add_arrow_annotation();
 void handle_annotation_mode_button_clicked(int button_id);
 void handle_mode_button_clicked(int button_id);

 void show_seli_view_context_menu(const QPoint& p);
 void add_to_arrow_group();

 //?void proceed();

 void graphics_button_clicked();
 void zoom_in();
 void zoom_out();

 void zoom_slider_value_changed(int val);

 void clear_button_clicked();

 void save_scene();
 void open_scene();


};


#endif  // MMUI_ARROW_FACTORY__H
