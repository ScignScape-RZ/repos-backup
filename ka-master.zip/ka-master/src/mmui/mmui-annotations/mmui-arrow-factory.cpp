
#include "mmui-arrow-factory.h"

#include "mmui-arrow.h"

#include "textio.h"

#include <QDebug>
#include <QDataStream>

#include "ka-tdcx/ka-tdcx/ka-tdcx-typed-array-document.h"
#include "ka-tdcx/ka-tdcx/ka-tdcx-typed-array-decoder.h"

//?#include "ka-tdcx/ka-tdcx/ka-tdcx-typed-array-encoder.h"


USING_KANS(TransDCX)

//?extern QGraphicsScene& mmui_annotations_get_scene();



QDataStream& operator<<(QDataStream& lhs, const QList<MMUI_Arrow*>& rhs)
{
 lhs << rhs.size();
 for(MMUI_Arrow* arrow : rhs)
 {
  lhs << arrow;
 }
 return lhs;
}

QDataStream& operator>>(QDataStream& lhs, QList<MMUI_Arrow*>& rhs)
{
 int size;
 lhs >> size;
 for(int i = 0; i < size; ++i)
 {
  MMUI_Arrow* ma = new MMUI_Arrow;
  lhs >> *ma;
  rhs.push_back(ma);
 }
 return lhs;
}

MMUI_Arrow_Factory::MMUI_Arrow_Factory()
 : current_mouse_action_mode_(Mouse_Action_Modes::Arrow_Move)
 //: scene_(mmui_annotations_get_scene())
{

}

MMUI_Arrow* MMUI_Arrow_Factory::make_arrow()
{
 MMUI_Arrow* result = new MMUI_Arrow;
 result->set_factory(this);
 arrows_.push_back(result);
 return result;
 //qDebug() << "called";
 //return new MMUI_Arrow;
}

MMUI_Arrow_Factory::MMUI_Arrow_Factory(const MMUI_Arrow_Factory& rhs)
 // : scene_(rhs.scene_)
{

}

void MMUI_Arrow_Factory::write_arrow_package(QByteArray& qba)
{
 QDataStream qds(&qba, QIODevice::WriteOnly);
 qds << arrows_;
}


void MMUI_Arrow_Factory::from_qbytearray(const QByteArray& qba)
{
 QDataStream qds(qba);
 qds >> arrows_;

 for(MMUI_Arrow* arrow : arrows_)
 {
  arrow->set_factory(this);
 }
}


void MMUI_Arrow_Factory::to_qbytearray(QByteArray& qba) const
{
 QDataStream qds(&qba, QIODevice::WriteOnly);
 qds << arrows_;
}


void MMUI_Arrow_Factory::load_arrow_package(const QByteArray& qba)
{
 QDataStream qds(qba);
 qds >> arrows_;
}

void MMUI_Arrow_Factory::save_arrow_package(QString file)
{
 qDebug() << "File: " << file;
 QByteArray qba;
 write_arrow_package(qba);

// TDCX_Typed_Array_Document tad;
// TDCX_Storing_Profile tsp;
// tad.


 KA::TextIO::save_file(file, qba);

}

void MMUI_Arrow_Factory::save_encoded_arrow_package(QString file)
{
 TDCX_Typed_Array_Document tad;
 TDCX_Storing_Profile profile;

 tad.store(*this, profile);
 QString result = tad.encode();

 KA::TextIO::save_file(file, result);


}

void MMUI_Arrow_Factory::load_arrow_package_from_file(QString file)
{
 QByteArray qba;
 KA::TextIO::load_file(file, qba);
 load_arrow_package(qba);
}

void MMUI_Arrow_Factory::load_encoded_arrow_package_from_file(QString file)
{
 QString text =  KA::TextIO::load_file(file);

 TDCX_Typed_Array_Decoder tad(text);

 tad.decode();
 //tad.store(*this, profile);
 //QString result = tad.encode();

 tad.reload(0, *this);

 //TDCX_Typed_Array* ta = tad.reload



}


//void MMUI_Arrow_Factory::insert_added_arrow(MMUI_Arrow* arrow)
//{
// added_arrows_.push_back(arrow);
//}


void MMUI_Arrow_Factory::insert_added_arrows(const QList<MMUI_Arrow*>& arrows)
{
 added_arrows_ << arrows;
}


void MMUI_Arrow_Factory::draw_added_arrows_to_scene(QGraphicsScene& scene)
{
 for(MMUI_Arrow* arrow : added_arrows_)
 {
  arrow->check_init_graphics();
  arrow->set_scene(&scene);

  scene.addItem(arrow->graphics_item());
 }

}


MMUI_Arrow* MMUI_Arrow_Factory::add_to_scene(QGraphicsScene& scene)
{
 for(MMUI_Arrow* arrow : arrows_)
 {
  arrow->init_origin_and_direction(QPoint(50, 50), 0.5 - 0.125);
  // direction_angle_ = 0.5 - 0.125;

  arrow->check_init_graphics();
  arrow->set_scene(&scene);

  scene.addItem(arrow->graphics_item());
 }
 return arrows_.value(0, nullptr);
}


//void MMUI_Arrow_Factory::to_scene()
//{
// qDebug() << "TSC";
//}
