
#ifndef MMUI_ARROW_FACTORY__H
#define MMUI_ARROW_FACTORY__H

#include <QObject>

#include <QMetaType>

#include <QList>
#include <QGraphicsScene>

#include "ka-tdcx/ka-tdcx/ka-tdcx-type-info.h"

#include "accessors.h"


class MMUI_Arrow;
class MMUI_Arrow_Factory;


template<>
struct TDCX_Type_Info<MMUI_Arrow> : TDCX_Byte_Array_Storage //?: TDCX_Pure_Value_Storage
{
 static QString get_QString_Type_Name(){ return "MMUI_Arrow"; }
 static int get_Type_Code(){ return 1; }
};

template<>
struct TDCX_Type_Info<MMUI_Arrow_Factory> : TDCX_Byte_Array_Storage //?: TDCX_Pure_Value_Storage
{
 static QString get_QString_Type_Name(){ return "MMUI_Arrow_Factory"; }
 static int get_Type_Code(){ return 2; }
};



class MMUI_Arrow_Factory : public QObject
{
 Q_OBJECT

public:

 enum class Mouse_Action_Modes {

  N_A, Arrow_Rotate, Arrow_Stretch, Arrow_Move, Arrows_Slide

 };

private:

 Mouse_Action_Modes current_mouse_action_mode_;


 QList<MMUI_Arrow*> arrows_;


 QList<MMUI_Arrow*> added_arrows_;

 //?QGraphicsScene& scene_;

 void write_arrow_package(QByteArray& result);

public:

 Q_INVOKABLE MMUI_Arrow_Factory();

 MMUI_Arrow_Factory(const MMUI_Arrow_Factory& rhs);

 void insert_added_arrows(const QList<MMUI_Arrow*>& arrow);
// added_arrows_;


 Q_INVOKABLE MMUI_Arrow* make_arrow();

 //?Q_INVOKABLE void to_scene();

 Q_INVOKABLE void save_arrow_package(QString file);

 Q_INVOKABLE void save_encoded_arrow_package(QString file);

 ACCESSORS(Mouse_Action_Modes ,current_mouse_action_mode)


 void load_encoded_arrow_package_from_file(QString file);

 void load_arrow_package_from_file(QString file);
 void load_arrow_package(const QByteArray& qba);

 MMUI_Arrow* add_to_scene(QGraphicsScene& scene);

 void draw_added_arrows_to_scene(QGraphicsScene& scene);


 void to_qbytearray(QByteArray& qba) const;
 void from_qbytearray(const QByteArray& qba);

};



Q_DECLARE_METATYPE(MMUI_Arrow_Factory*)
Q_DECLARE_METATYPE(MMUI_Arrow_Factory)


#endif  // MMUI_ARROW_FACTORY__H
