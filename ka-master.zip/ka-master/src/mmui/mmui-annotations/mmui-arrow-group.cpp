
#include "mmui-arrow-group.h"

#include "mmui-arrow.h"

#include <QDebug>

//USING_KANS(TransDCX)

//QDataStream& operator<<(QDataStream& lhs, const QList<MMUI_Arrow*>& rhs)
//{
// lhs << rhs.size();
// for(MMUI_Arrow* arrow : rhs)
// {
//  lhs << arrow;
// }
// return lhs;
//}
//QDataStream& operator>>(QDataStream& lhs, QList<MMUI_Arrow*>& rhs)
//{
// int size;
// lhs >> size;
// for(int i = 0; i < size; ++i)
// {
//  MMUI_Arrow* ma = new MMUI_Arrow;
//  lhs >> *ma;
//  rhs.push_back(ma);
// }
// return lhs;
//}

MMUI_Arrow* MMUI_Arrow_Group::get_first_arrow()
{
 return arrows_.value(0, nullptr);
}

void MMUI_Arrow_Group::add_new_arrows(QList<MMUI_Arrow*>& arrows, int count)
{
 int c = count + 1;

 int sz = arrows_.size();

 if(sz == 1)
 {
  for(int i = 1; i < c; ++i)
  {
   qreal fraction_of_circle = ((qreal) i)/c;
   MMUI_Arrow* result = get_first_arrow()->duplicate_around_center(center_, fraction_of_circle);

   result->set_counterclockwise_group_order(i);

   arrows.push_back(result);
   arrows_.push_back(result);
  }
 }
 else
 {
  for(int i = 1; i < count + sz; ++i)
  {
   qreal fraction_of_circle = ((qreal) i)/(count + sz);

   if(i < sz)
   {
    MMUI_Arrow* a = arrows_.value(i);
    get_first_arrow()->reposition_around_center(center_, fraction_of_circle, a);
   }
   else
   {
    MMUI_Arrow* result = get_first_arrow()->duplicate_around_center(center_, fraction_of_circle);
    result->set_counterclockwise_group_order(i);
    arrows.push_back(result);
    arrows_.push_back(result);
   }
  }
 }
}


//  fraction_of_circle = 2./3;
//  MMUI_Arrow* result2 = get_first_arrow()->duplicate_around_center(center_, fraction_of_circle);
//  arrows.push_back(result1);
//  //?
//  arrows.push_back(result2);


MMUI_Arrow_Group::MMUI_Arrow_Group(MMUI_Arrow* arrow)
 //: scene_(mmui_annotations_get_scene())
{
 arrows_.push_back(arrow);
 radius_ = 100; //75; //100;
 //QPointF tip = arrow->get_tip_point();
 center_ = arrow->get_tip_point_extended(radius_);
}
