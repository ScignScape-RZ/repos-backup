
#ifndef MMUI_ARROW_GROUP__H
#define MMUI_ARROW_GROUP__H

#include <QObject>

#include <QMetaType>

#include <QList>
#include <QGraphicsScene>

#include <QPointF>
#include <QPoint>

#include "ka-tdcx/ka-tdcx/ka-tdcx-type-info.h"

#include "accessors.h"


class MMUI_Arrow;
class MMUI_Arrow_Group;


//template<>
//struct TDCX_Type_Info<MMUI_Arrow> : TDCX_Byte_Array_Storage //?: TDCX_Pure_Value_Storage
//{
// static QString get_QString_Type_Name(){ return "MMUI_Arrow"; }
// static int get_Type_Code(){ return 1; }
//};

//template<>
//struct TDCX_Type_Info<MMUI_Arrow_Factory> : TDCX_Byte_Array_Storage //?: TDCX_Pure_Value_Storage
//{
// static QString get_QString_Type_Name(){ return "MMUI_Arrow_Factory"; }
// static int get_Type_Code(){ return 2; }
//};



class MMUI_Arrow_Group : public QObject
{
 Q_OBJECT

 QList<MMUI_Arrow*> arrows_;

 QPointF center_;

 qreal radius_;

public:

 MMUI_Arrow_Group(MMUI_Arrow* arrow);

 //?MMUI_Arrow* add_new_arrow();

 void add_new_arrows(QList<MMUI_Arrow*>& arrows, int count);


 MMUI_Arrow* get_first_arrow();

 //MMUI_Arrow_Group(const MMUI_Arrow_Group& rhs);
// void to_qbytearray(QByteArray& qba) const;
// void from_qbytearray(const QByteArray& qba);

};


//Q_DECLARE_METATYPE(MMUI_Arrow_Group*)
//Q_DECLARE_METATYPE(MMUI_Arrow_Group)


#endif  // MMUI_ARROW_GROUP__H
