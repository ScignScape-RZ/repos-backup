
#include "mmui-arrow-point-set.h"

MMUI_Arrow_Point_Set::MMUI_Arrow_Point_Set()
{

}

void MMUI_Arrow_Point_Set::get_extremes(qreal& x_min, qreal& y_min, qreal& x_max, qreal& y_max)
{
 x_min = ground_point_.x();

 if(x_min > ground_end_negative_.x())
 {
  x_min = ground_end_negative_.x();
 }
 if(x_min > ground_end_positive_.x())
 {
  x_min = ground_end_positive_.x();
 }
 if(x_min > far_end_negative_.x())
 {
  x_min = far_end_negative_.x();
 }
 if(x_min > far_end_positive_.x())
 {
  x_min = far_end_positive_.x();
 }
 if(x_min > base_end_negative_.x())
 {
  x_min = base_end_negative_.x();
 }
 if(x_min > base_end_positive_.x())
 {
  x_min = base_end_positive_.x();
 }
 if(x_min > tip_point_.x())
 {
  x_min = tip_point_.x();
 }


 x_max = ground_point_.x();

 if(x_max < ground_end_negative_.x())
 {
  x_max = ground_end_negative_.x();
 }
 if(x_max < ground_end_positive_.x())
 {
  x_max = ground_end_positive_.x();
 }
 if(x_max < far_end_negative_.x())
 {
  x_max = far_end_negative_.x();
 }
 if(x_max < far_end_positive_.x())
 {
  x_max = far_end_positive_.x();
 }
 if(x_max < base_end_negative_.x())
 {
  x_max = base_end_negative_.x();
 }
 if(x_max < base_end_positive_.x())
 {
  x_max = base_end_positive_.x();
 }
 if(x_max < tip_point_.x())
 {
  x_max = tip_point_.x();
 }


 y_min = ground_point_.y();

 if(y_min > ground_end_negative_.y())
 {
  y_min = ground_end_negative_.y();
 }
 if(y_min > ground_end_positive_.y())
 {
  y_min = ground_end_positive_.y();
 }
 if(y_min > far_end_negative_.y())
 {
  y_min = far_end_negative_.y();
 }
 if(y_min > far_end_positive_.y())
 {
  y_min = far_end_positive_.y();
 }
 if(y_min > base_end_negative_.y())
 {
  y_min = base_end_negative_.y();
 }
 if(y_min > base_end_positive_.y())
 {
  y_min = base_end_positive_.y();
 }
 if(y_min > tip_point_.y())
 {
  y_min = tip_point_.y();
 }


 y_max = ground_point_.y();

 if(y_max < ground_end_negative_.y())
 {
  y_max = ground_end_negative_.y();
 }
 if(y_max < ground_end_positive_.y())
 {
  y_max = ground_end_positive_.y();
 }
 if(y_max < far_end_negative_.y())
 {
  y_max = far_end_negative_.y();
 }
 if(y_max < far_end_positive_.y())
 {
  y_max = far_end_positive_.y();
 }
 if(y_max < base_end_negative_.y())
 {
  y_max = base_end_negative_.y();
 }
 if(y_max < base_end_positive_.y())
 {
  y_max = base_end_positive_.y();
 }
 if(y_max < tip_point_.y())
 {
  y_max = tip_point_.y();
 }



}


void MMUI_Arrow_Point_Set::to_shaft_points(QVector<QPointF>& points)
{
 points = {{
            ground_end_positive_,
            ground_end_negative_,
            far_end_negative_,
            far_end_positive_,
           }};
}

void MMUI_Arrow_Point_Set::to_head_points(QVector<QPointF>& points)
{
 points = {{
            base_end_positive_,
            base_end_negative_,
            tip_point_
           }};
}
