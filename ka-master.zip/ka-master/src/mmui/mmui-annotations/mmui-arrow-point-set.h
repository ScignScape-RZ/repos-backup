
#ifndef MMUI_ARROW_POINT_SET__H
#define MMUI_ARROW_POINT_SET__H

#include <QObject>

#include <QMetaType>

#include <QList>
#include <QGraphicsScene>
#include <QPoint>

#include "accessors.h"

class MMUI_Arrow_Point_Set
{

 QPointF ground_point_;
 QPointF ground_end_negative_;
 QPointF ground_end_positive_;
 QPointF far_end_negative_;
 QPointF far_end_positive_;
 QPointF base_end_negative_;
 QPointF base_end_positive_;
 QPointF tip_point_;


public:


 ACCESSORS(QPointF ,ground_point)
 ACCESSORS(QPointF ,ground_end_negative)
 ACCESSORS(QPointF ,ground_end_positive)
 ACCESSORS(QPointF ,far_end_negative)
 ACCESSORS(QPointF ,far_end_positive)
 ACCESSORS(QPointF ,base_end_negative)
 ACCESSORS(QPointF ,base_end_positive)
 ACCESSORS(QPointF ,tip_point)

 MMUI_Arrow_Point_Set();

 void to_shaft_points(QVector<QPointF>& points);
 void to_head_points(QVector<QPointF>& points);

 void get_extremes(qreal& x_min, qreal& y_min, qreal& x_max, qreal& y_max);

};


#endif  // MMUI_ARROW_FACTORY__H
