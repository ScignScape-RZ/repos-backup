
#include "mmui-arrow.h"

#include <QDebug>

#include "qtarrowitem.h"

#include <QGraphicsPolygonItem>

#include <QtMath>

#include <QColor>

#include <QGraphicsView>

#include "mmui-graphics-item-group.h"

#include "mmui-arrow-factory.h"

//#include <QGraphicsPolygon>

QDataStream& operator<<(QDataStream& lhs, MMUI_Arrow* rhs)
{
 lhs << rhs->shaft_length();
 lhs << rhs->shaft_width();

 lhs << rhs->head_length();
 lhs << rhs->head_width();

 lhs << rhs->shaft_brush();
 lhs << rhs->shaft_pen();
 lhs << rhs->head_brush();
 lhs << rhs->head_pen();
 return lhs;
}

QDataStream& operator>>(QDataStream& lhs, MMUI_Arrow& rhs)
{
 int shaft_length;
 lhs >> shaft_length;
 rhs.set_shaft_length(shaft_length);

 int shaft_width;
 lhs >> shaft_width;
 rhs.set_shaft_width(shaft_width);

 int head_length;
 lhs >> head_length;
 rhs.set_head_length(head_length);

 int head_width;
 lhs >> head_width;
 rhs.set_head_width(head_width);

 lhs >> rhs.shaft_brush();
 lhs >> rhs.shaft_pen();
 lhs >> rhs.head_brush();
 lhs >> rhs.head_pen();
 return lhs;
}


void MMUI_Arrow::init_point_set(qreal direction_angle,
  qreal scale_factor)
{
 current_scale_factor_ = scale_factor;

 if(!point_set_)
   point_set_ = new MMUI_Arrow_Point_Set;

 qreal sl = shaft_length_ * scale_factor;
 qreal hw = head_width_ * scale_factor;
 qreal hl = head_length_ * scale_factor;

 qreal half_sw = shaft_width_ * (scale_factor / 2);

 QPointF p1 = origin_point_;

 qreal two_pi = 2 * M_PI;

 //qreal angle = qDegreesToRadians(360 * (1 - direction_angle_));

 qreal angle = two_pi * (1 - direction_angle);

 qreal tangent = two_pi * (0.75 - direction_angle);

 qreal x = p1.x() + (sl * qCos(angle));
 qreal y = p1.y() + (sl * qSin(angle));

 qreal h3x = p1.x() + ( (sl + hl) * qCos(angle));
 qreal h3y = p1.y() + ( (sl + hl) * qSin(angle));

 QPointF p2 = QPointF(x, y);

 qreal c1x1 = p1.x() + (half_sw * qCos(tangent));
 qreal c1y1 = p1.y() + (half_sw * qSin(tangent));

 qreal c1x2 = p1.x() - (half_sw * qCos(tangent));
 qreal c1y2 = p1.y() - (half_sw * qSin(tangent));


 qreal c2x1 = p2.x() + (half_sw * qCos(tangent));
 qreal c2y1 = p2.y() + (half_sw * qSin(tangent));

 qreal c2x2 = p2.x() - (half_sw * qCos(tangent));
 qreal c2y2 = p2.y() - (half_sw * qSin(tangent));


 //qreal h1x1 =

 qreal hhw = hw + half_sw;

 qreal h1x = p2.x() + (hhw * qCos(tangent));
 qreal h1y = p2.y() + (hhw * qSin(tangent));

 qreal h2x = p2.x() - (hhw * qCos(tangent));
 qreal h2y = p2.y() - (hhw * qSin(tangent));

 point_set_->set_ground_point(p1);
 point_set_->set_ground_end_positive({c1x1, c1y1});
 point_set_->set_ground_end_negative({c1x2, c1y2});
 point_set_->set_far_end_positive({c2x1, c2y1});
 point_set_->set_far_end_negative({c2x2, c2y2});
 point_set_->set_base_end_positive({h1x, h1y});
 point_set_->set_base_end_negative({h2x, h2y});
 point_set_->set_tip_point({h3x, h3y});
}

QPointF MMUI_Arrow::get_tip_point()
{
 return point_set_->tip_point();
}


MMUI_Arrow* MMUI_Arrow::duplicate()
{
 MMUI_Arrow* result = new MMUI_Arrow;

 result->set_head_length(head_length_);
 result->set_shaft_length(shaft_length_);

 result->set_head_width(head_width_);
 result->set_shaft_width(shaft_width_);

 result->shaft_brush() = shaft_brush();
 result->shaft_pen() = shaft_pen();

 result->head_brush() = head_brush();
 result->head_pen() = head_pen();

 return result;
}

QPointF MMUI_Arrow::adjusted_ground_point()
{
// QPointF result = point_set_->ground_point();
// QPointF pos = graphics_item_->pos();

 init_ground_point_vector();

 QRectF brect = graphics_item_->boundingRect();

 QPointF br = graphics_item_->boundingRect().bottomRight();

 QPointF pos = graphics_item_->pos();


 effective_ground_point_ = QPointF(pos.x() + ground_point_vector_.x(),
   pos.y() + ground_point_vector_.y() );



 QPointF result = effective_ground_point_;
 return result;
}


void MMUI_Arrow::reposition_around_center(QPointF center, qreal rotate_angle, MMUI_Arrow* arrow)
{
 QPointF gp = get_effective_ground_point();

 qreal x_delta = center.x() - gp.x();
 qreal y_delta = center.y() - gp.y();

 QVector2D vec = QVector2D(x_delta, y_delta);

 qreal two_pi = 2 * M_PI;

 qreal ang = rotate_angle - 0.5; //1./4;

 qreal vx = vec.x();
 qreal vy = vec.y();

 qreal v1x;
 qreal v1y;

  QTransform().rotateRadians(two_pi * ang, Qt::ZAxis).map(vx, vy, &v1x, &v1y);
  qDebug() << "Z Angle: " << " v1x: " << v1x << ", v1y: " << v1y;
 QVector2D vec1 = QVector2D(v1x, v1y);
 vec1 += QVector2D(center);

 QPointF new_gp = vec1.toPointF();

 qreal angle = direction_angle_ - rotate_angle;
 if(angle < 0)
   angle += 1;

 arrow->set_origin_point(new_gp);
 arrow->init_point_set(angle, current_scale_factor_);

 //?
 arrow->graphics_item()->setVisible(false);
 arrow->set_graphics_item(nullptr);

 arrow->check_init_graphics();

}



MMUI_Arrow* MMUI_Arrow::duplicate_around_center(QPointF center, qreal rotate_angle)
{
 MMUI_Arrow* result = duplicate();

 //QPointF gp = adjusted_ground_point(); //point_set_->ground_point();

 QPointF gp = get_effective_ground_point();

// scene_->addEllipse(center.x(), center.y(), 20, 20);

 qreal x_delta = center.x() - gp.x();
 qreal y_delta = center.y() - gp.y();

 QVector2D vec = QVector2D(x_delta, y_delta);

 //QTransform().rotate()
 //QVector2D vec1 = vec; //QVector2D(-vec.x(), -vec.y());

 qreal two_pi = 2 * M_PI;

 qreal ang = rotate_angle - 0.5; //1./4;

 qreal vx = vec.x();
 qreal vy = vec.y();

 qreal v1x;
 qreal v1y;

// QTransform().rotate(180, Qt::YAxis).map(vx, vy, &v1x, &v1y);
// qDebug() << "Z Angle: " << i << " v1x: " << v1x << ", v1y: " << v1y;

 //QTransform().rotate(180, Qt::ZAxis).map(vx, vy, &v1x, &v1y);

// if(ang == 0.5)
// {
//  v1x = vx;
//  v1y = vy;

//  //qDebug() << "XX";
// }
// else
// {
  QTransform().rotateRadians(two_pi * ang, Qt::ZAxis).map(vx, vy, &v1x, &v1y);
  qDebug() << "Z Angle: " << " v1x: " << v1x << ", v1y: " << v1y;
// }

 //
// for(int i = 0; i < 360; i += 10)
// {
//  QTransform().rotate(i, Qt::ZAxis).map(vx, vy, &v1x, &v1y);
//  qDebug() << "Z Angle: " << i << " v1x: " << v1x << ", v1y: " << v1y;

////  QTransform().rotate(i, Qt::XAxis).map(vx, vy, &v1x, &v1y);
////  qDebug() << "X Angle: " << i << " v1x: " << v1x << ", v1y: " << v1y;

////  QTransform().rotate(i, Qt::YAxis).map(vx, vy, &v1x, &v1y);
////  qDebug() << "Y Angle: " << i << " v1x: " << v1x << ", v1y: " << v1y;
// }



 QVector2D vec1 = QVector2D(v1x, v1y);

 //vec1 *= 2;


// if(ang == 0.5)
// {
//  vec1 *= 1;
//  vec1 += QVector2D(center);
// }
// else
// {
//  vec1 += QVector2D(center);
// }

 vec1 += QVector2D(center);


// QPointF new_gp = vec1.toPointF();

// if(ang == 0)
// {
//  scene_->addRect(vec1.x(), vec1.y(), 30, 30,
//                  QPen(QColor("black")), QBrush(QColor("orange")));

//  scene_->addRect(center.x(), center.y(), 10, 10,
//                  QPen(QColor("red")), QBrush(QColor("blue")));


// }


 QPointF new_gp = vec1.toPointF();

 qreal angle = direction_angle_ - rotate_angle;
 if(angle < 0)
   angle += 1;

 result->set_origin_point(new_gp);
 result->init_point_set(angle, current_scale_factor_);

 return result;

}

QPointF MMUI_Arrow::get_effective_ground_point()
{
 QPointF pos = graphics_item_->pos();
 QPointF gp = QPointF(point_set_->ground_point().x(),
   point_set_->ground_point().y());

 QPointF result = QPointF(gp.x() + pos.x(),
   gp.y() + pos.y());

 return result;

}


QPointF MMUI_Arrow::get_tip_point_extended(qreal length)
{
 QPointF gp = point_set_->ground_point();
 QPointF tp = point_set_->tip_point();

 qreal x_delta = tp.x() - gp.x();
 qreal y_delta = tp.y() - gp.y();

// qreal gx = graphics_item_->x() + x_delta;
// qreal gy = graphics_item_->y() + y_delta;

 QPointF spos = graphics_item_->scenePos();

 QPointF pos = graphics_item_->pos();

 //scene_->addEllipse(pos.x(), pos.y(), 5, 5);

 //QPointF agp = adjusted_ground_point();


// QPointF agp = QPointF(point_set_->ground_point().x(),
//   point_set_->ground_point().y());


 QPointF egp = get_effective_ground_point();

// scene_->addRect(pos_gp.x(), pos_gp.y(), 10, 10, QPen(Qt::blue), QBrush(Qt::blue));

 QVector2D vec = QVector2D(x_delta, y_delta);
 // qreal len = vec.length();
 // qreal factor = (lenth + len) / len;

 vec = vec.normalized() * length;
 vec += QVector2D(egp);

 QPointF result = vec.toPointF();

 //scene_->addRect(result.x(), result.y(), 10, 10, QPen(QColor("orange")), QBrush(QColor("orange")));

 return result;
}

void MMUI_Arrow::init_polygons(QGraphicsPolygonItem* shaft_item,
   QGraphicsPolygonItem* head_item)
{
 QVector<QPointF> points;
 QVector<QPointF> hpoints;

 point_set_->to_head_points(hpoints);
 point_set_->to_shaft_points(points);

 QPolygonF poly(points);
 shaft_item->setPolygon(poly);
 shaft_item->setBrush(shaft_brush_);
 shaft_item->setPen(shaft_pen_);


 QPolygonF hpoly(hpoints);
 head_item->setPolygon(hpoly);
 head_item->setBrush(head_brush_);
 head_item->setPen(head_pen_);

}

void MMUI_Arrow::init_origin_and_direction(QPointF qp, qreal direction)
{
 origin_point_ = qp;
 direction_angle_ = direction;
}

//void MMUI_Arrow::reset_polygons(QGraphicsPolygonItem* shaft_item,
//  QGraphicsPolygonItem* head_item, qreal angle)
//{
// int scale_factor = 1;

// origin_point_ = QPoint(50, 50);
// direction_angle_ = 0.5 + 0.125;

// QGraphicsPolygonItem* shaft1 = new QGraphicsPolygonItem;
// QGraphicsPolygonItem* head1 = new QGraphicsPolygonItem;

// init_point_set(angle, scale_factor);
// init_polygons(shaft1, head1);



// MMUI_Graphics_Item_Group* mgig = new MMUI_Graphics_Item_Group(
//   {shaft1, head1}, origin_point_,
//   [this, shaft1, head1, scale_factor]
//   (MMUI_Graphics_Item_Group* _mgig, int, int, int, int, qreal angle)
//   {
//    init_point_set(angle, scale_factor);
//    init_polygons(shaft1, head1);
////?    this->reset_polygons(shaft1, head1, angle);
////    if(c == 20)
////    {
////     this->reset_polygons(shaft, head);
////    }

//   });
// mgig->setFlag(QGraphicsItem::ItemIsSelectable);
// graphics_item_ = mgig;

//}

void MMUI_Arrow::init_ground_point_vector()
{
 qreal x_min;
 qreal y_min;

 qreal x_max;
 qreal y_max;

 point_set_->get_extremes(x_min, y_min, x_max, y_max);

 QPointF gtl = graphics_item_->boundingRect().topLeft();
 QPointF gbr = graphics_item_->boundingRect().bottomRight();
// qreal x_delta = point_set_->ground_point().x() - gpos.x(); //origin_point_.x();
// qreal y_delta = point_set_->ground_point().y() - gpos.y();//origin_point_.y();
// ground_point_vector_ = QVector2D(x_delta, y_delta);

 qreal x_delta = origin_point_.x() - x_min;
 qreal y_delta = origin_point_.y() - y_min;

 ground_point_vector_ = QVector2D(x_delta, y_delta);

}

void MMUI_Arrow::check_init_graphics()
{
 if(graphics_item_)
   return;

// origin_point_ = QPoint(50, 50);
// direction_angle_ = 0.5 - 0.125;

 QGraphicsPolygonItem* shaft = new QGraphicsPolygonItem;
 QGraphicsPolygonItem* head = new QGraphicsPolygonItem;


 qreal scale_factor;
 if(!point_set_)
 {
  scale_factor = 1;
  init_point_set(direction_angle_, scale_factor);
 }
 else
 {
  scale_factor = current_scale_factor_;
 }

 init_polygons(shaft, head);

 int c = 0;

 MMUI_Graphics_Item_Group* mgig = new MMUI_Graphics_Item_Group(
   {shaft, head}, origin_point_,
   [this, shaft, head, scale_factor, &c]
   (MMUI_Graphics_Item_Group* _mgig, int, int, int, int, qreal angle) -> bool
   {
    MMUI_Arrow_Factory::Mouse_Action_Modes mode = factory_->current_mouse_action_mode();

    switch(mode)
    {
    case MMUI_Arrow_Factory::Mouse_Action_Modes::Arrow_Rotate:
     {
      // keep direction angle?
      direction_angle_ = angle;
      init_point_set(angle, scale_factor);
      init_polygons(shaft, head);

//?
//      init_ground_point_vector();

//      QPointF br = graphics_item_->boundingRect().bottomRight();

//      effective_ground_point_ = QPointF(br.x() - ground_point_vector_.x(),
//        br.y() - ground_point_vector_.y() );

      return true;
     }
     break;

    case MMUI_Arrow_Factory::Mouse_Action_Modes::Arrow_Move:
     return false;
     break;

    default:
     return false;
     break;

    }

   });

 mgig->setFlag(QGraphicsItem::ItemIsSelectable);
 mgig->setFlag(QGraphicsItem::ItemIsMovable);
 graphics_item_ = mgig;

// QPointF gpos = graphics_item_->boundingRect().topLeft();
// qreal x_delta = point_set_->ground_point().x() - gpos.x(); //origin_point_.x();
// qreal y_delta = point_set_->ground_point().y() - gpos.y();//origin_point_.y();
// ground_point_vector_ = QVector2D(x_delta, y_delta);

 init_ground_point_vector();

}


MMUI_Arrow::MMUI_Arrow()
 : graphics_item_(nullptr),
   point_set_(nullptr),
   scene_(nullptr),
   factory_(nullptr),
   current_scale_factor_(0),
   counterclockwise_group_order_(0)
{

}

MMUI_Arrow::MMUI_Arrow(const MMUI_Arrow& rhs)
 : graphics_item_(rhs.graphics_item_),
   point_set_(rhs.point_set_),
   scene_(rhs.scene_),
   factory_(rhs.factory_),
   current_scale_factor_(rhs.current_scale_factor_),
   counterclockwise_group_order_(rhs.counterclockwise_group_order_)
{
}

void MMUI_Arrow::request_scene_update()
{
 if(scene_)
 {
  scene_->update();
  scene_->views().at(0)->update();
 }
}

void MMUI_Arrow::set_shaft_length(int shaft_length)
{
 shaft_length_ = shaft_length;
}

void MMUI_Arrow::set_shaft_width(int shaft_width)
{
 shaft_width_ = shaft_width;
}


void MMUI_Arrow::set_head_length(int head_length)
{
 head_length_ = head_length;
}

void MMUI_Arrow::set_head_width(int head_width)
{
 head_width_ = head_width;
}


void MMUI_Arrow::set_rgb(int r, int g, int b)
{
 qDebug() << "called";
 QColor qc = QColor::fromRgb(r, g, b);

 shaft_brush_.setStyle(Qt::SolidPattern);

 shaft_brush_.setColor(qc);
 shaft_pen_.setColor(qc);

 head_brush_.setStyle(Qt::SolidPattern);

 head_brush_.setColor(qc);
 head_pen_.setColor(qc);

}
