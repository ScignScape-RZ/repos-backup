
#ifndef MMUI_ARROW__H
#define MMUI_ARROW__H

#include <QObject>

#include <QMetaType>

#include <QColor>
#include <QBrush>
#include <QPen>

#include <QPointF>

#include <QVector2D>

#include "accessors.h"
#include "mmui-arrow-point-set.h"


class MMUI_Arrow;
class QGraphicsItem;

QDataStream& operator<<(QDataStream& lhs, MMUI_Arrow* rhs);
QDataStream& operator>>(QDataStream& lhs, MMUI_Arrow& rhs);


class MMUI_Arrow_Factory;

class MMUI_Arrow : public QObject
{
 Q_OBJECT

 QBrush shaft_brush_;
 QPen shaft_pen_;

 QBrush head_brush_;
 QPen head_pen_;

 QGraphicsItem* graphics_item_;

 int shaft_length_;
 int shaft_width_;

 int head_width_;
 int head_length_;

 QPointF origin_point_;

 qreal direction_angle_;

 MMUI_Arrow_Point_Set* point_set_;

 QGraphicsScene* scene_;

 MMUI_Arrow_Factory* factory_;

 qreal current_scale_factor_;

 QVector2D ground_point_vector_;

 QPointF effective_ground_point_;

 int counterclockwise_group_order_;

public:


 ACCESSORS__RGET(QBrush ,shaft_brush)
 ACCESSORS__RGET(QPen ,shaft_pen)

 ACCESSORS__RGET(QBrush ,head_brush)
 ACCESSORS__RGET(QPen ,head_pen)

 ACCESSORS(QGraphicsScene* ,scene)

 ACCESSORS(QVector2D ,ground_point_vector)



// Q_INVOKABLE__ACCESSORS(int ,shaft_length)
// Q_INVOKABLE__ACCESSORS(int ,shaft_width)

 ACCESSORS__GET(int ,shaft_length)
 ACCESSORS__GET(int ,shaft_width)
 ACCESSORS__GET(int ,head_width)
 ACCESSORS__GET(int ,head_length)

 ACCESSORS(QPointF ,origin_point)


 ACCESSORS(QGraphicsItem* ,graphics_item)

 ACCESSORS(MMUI_Arrow_Factory* ,factory)

 ACCESSORS(int ,counterclockwise_group_order)


 Q_INVOKABLE MMUI_Arrow();

 void request_scene_update();
 QPointF adjusted_ground_point();

 QPointF get_effective_ground_point();

 MMUI_Arrow(const MMUI_Arrow& rhs);

 void reposition_around_center(QPointF center, qreal rotate_angle, MMUI_Arrow* arrow);

 MMUI_Arrow* duplicate_around_center(QPointF center, qreal rotate_angle);
 MMUI_Arrow* duplicate();

 Q_INVOKABLE void set_rgb(int r, int g, int b);

 Q_INVOKABLE void set_shaft_length(int shaft_length);
 Q_INVOKABLE void set_shaft_width(int shaft_width);

 Q_INVOKABLE void set_head_width(int head_width);
 Q_INVOKABLE void set_head_length(int head_length);

 void check_init_graphics();
 void init_ground_point_vector();


 void init_origin_and_direction(QPointF qp, qreal direction);

 QPointF get_tip_point();
 QPointF get_tip_point_extended(qreal length);

 void init_point_set(qreal direction_angle, qreal scale_factor);
 void init_polygons(QGraphicsPolygonItem* shaft_item,
   QGraphicsPolygonItem* head_item);

//? void reposition_around_center(QPointF center, qreal rotate_angle, MMUI_Arrow* arrow);


// void reset_polygons(QGraphicsPolygonItem* shaft_item,
//   QGraphicsPolygonItem* head_item, qreal angle);

};



Q_DECLARE_METATYPE(MMUI_Arrow*)
Q_DECLARE_METATYPE(MMUI_Arrow)


#endif  // MMUI_ARROW_FACTORY__H
