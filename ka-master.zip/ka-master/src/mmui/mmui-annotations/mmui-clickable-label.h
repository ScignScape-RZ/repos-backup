
#ifndef MMUI_CLICKABLE_LABEL__H
#define MMUI_CLICKABLE_LABEL__H

#include <QLabel>

class ClickableLabel : public QLabel
{
    Q_OBJECT

public:
    explicit ClickableLabel(QWidget* parent = Q_NULLPTR, Qt::WindowFlags f = Qt::WindowFlags());
    ~ClickableLabel();


 QString path;

signals:
    void clicked();

protected:
    void mousePressEvent(QMouseEvent* event);

};


#endif  // MMUI_CLICKABLE_LABEL__H
