
#include "mmui-diagnostic-report-summary-dialog.h"

#include "styles.h"


#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QButtonGroup>
#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>
#include <QComboBox>

#include <QDateEdit>

#include <QLineEdit>
#include <QTextStream>

#include <QPainter>
#include <QPushButton>
#include <QLabel>

#include <QPlainTextEdit>

#include <QTableWidget>
#include <QGraphicsPixmapItem>

#include <QMessageBox>
#include <QDebug>

#include <QGraphicsView>


#include <QHeaderView>

#include <QMenu>
#include <QAction>

#include <QListWidget>
#include <QDateEdit>


MMUI_Diagnostic_Report_Summary_Dialog::MMUI_Diagnostic_Report_Summary_Dialog(
  QWidget* parent)
  : QDialog(parent)
{
 //?arrow_factory_ = new MMUI_Arrow_Factory;

 button_box_ = new QDialogButtonBox(this);

 button_ok_ = new QPushButton("OK");
 button_proceed_ = new QPushButton("Proceed");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

 button_proceed_->setDefault(false);
 button_proceed_->setAutoDefault(false);

 button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);


 QString colorful_button_style_sheet = colorful_button_style_sheet_();

 QString colorful_toggle_button_style_sheet = colorful_button_quiet_style_sheet_(); //colorful_toggle_button_style_sheet_();


 QString colorful_button_style_sheet_down = colorful_button_style_sheet_down_();
 QString colorful_button_quiet_style_sheet = colorful_button_quiet_style_sheet_();

 QString tab_style_sheet = tab_style_sheet_();

 QString button_close_style_sheet = //?button_close_style_sheet_();

 "QPushButton:hover {background:rgb(150,240,190);"
 " border-left: 4px groove rgb(150,240,190); "
 " border-right: 4px ridge rgb(150,240,190); "
 "}\n"

   "QPushButton { background:rgb(220,220,230);"
   " border: 2px groove rgb(0,90,50); "
   " border-bottom: 3px groove rgb(240,190,150); "
   " border-top: 2px groove rgb(240,90,150); "
   " border-radius: 10px; "
   " padding-left:10;padding-right:10;padding-top:5;padding-bottom:5;"

//   " border-left: 4px groove rgb(0,190,150); "
//   " border-right: 4px ridge rgb(240,190,150); "

   "}\n"


 "QPushButton:pressed{ color:black; padding:1px;  border: 1px solid rgb(150,240,190);"
 "  border-bottom: 1px solid #CEF51D; "
 " border-radius: 0px; "
 " background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, "
 "  stop: 0 white, stop: 0.1 #C0C0C0, stop: 0.6 #C6CCBC "
 "  stop: 0.8 #A0ECCF, stop: 0.9 darkseagreen,  stop: 1 blue"
 "); min-width: 80px; }";


 QString basic_button_style_sheet = basic_button_style_sheet_();





 button_ok_->setStyleSheet(button_close_style_sheet);
 button_proceed_->setStyleSheet(button_close_style_sheet);
 button_cancel_->setStyleSheet(button_close_style_sheet);


 connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));



 main_layout_ = new QVBoxLayout();

 live_session_report_frame_ = new QFrame(this);
 live_session_report_layout_ = new QGridLayout;

 qL_organization_information_ = new QLabel("Organization Information", this);
 qPTE_organization_information_ = new QPlainTextEdit(this);

 live_session_report_layout_->addWidget(qL_organization_information_, 0, 0);
 live_session_report_layout_->addWidget(qPTE_organization_information_, 1, 0, 3, 1);

 qL_lead_tech_ = new QLabel("Lead Tech", this);
 qPTE_lead_tech_ = new QPlainTextEdit(this);

 live_session_report_layout_->addWidget(qL_lead_tech_, 0, 1);
 live_session_report_layout_->addWidget(qPTE_lead_tech_, 1, 1);

 qL_lead_consultant_ = new QLabel("Lead Consultant", this);
 qPTE_lead_consultant_ = new QPlainTextEdit(this);

 live_session_report_layout_->addWidget(qL_lead_consultant_, 2, 1);
 live_session_report_layout_->addWidget(qPTE_lead_consultant_, 3, 1);

 qL_size_of_specimen_ = new QLabel("Size of Specimen", this);
 qLE_size_of_specimen_ = new QLineEdit(this);

 live_session_report_layout_->addWidget(qL_size_of_specimen_, 4, 0);
 live_session_report_layout_->addWidget(qLE_size_of_specimen_, 4, 1);

 qL_stain_ = new QLabel("Stain", this);
 qLE_stain_ = new QLineEdit(this);

 live_session_report_layout_->addWidget(qL_stain_, 5, 0);
 live_session_report_layout_->addWidget(qLE_stain_, 5, 1);


 live_session_report_frame_->setLayout(live_session_report_layout_);


 gross_description_frame_ = new QFrame(this);
 gross_description_layout_ = new QVBoxLayout;
 qPTE_gross_description_ = new QPlainTextEdit(this);

 gross_description_layout_->addWidget(qPTE_gross_description_);
 gross_description_frame_->setLayout(gross_description_layout_);


 pathological_diagnosis_frame_ = new QFrame(this);
 pathological_diagnosis_layout_ = new QVBoxLayout;
 qPTE_pathological_diagnosis_ = new QPlainTextEdit(this);

 pathological_diagnosis_layout_->addWidget(qPTE_pathological_diagnosis_);
 pathological_diagnosis_frame_->setLayout(pathological_diagnosis_layout_);

 //main_layout_->addLayout(patient_info_layout_);

 main_notebook_ = new QTabWidget(this);

 main_notebook_->setStyleSheet(tab_style_sheet);

 main_notebook_->addTab(live_session_report_frame_, "Live Session Report");
 main_notebook_->addTab(gross_description_frame_, "Gross Description");
 main_notebook_->addTab(pathological_diagnosis_frame_, "Pathological Diagnosis");

 main_layout_->addWidget(main_notebook_);

 main_layout_->addWidget(button_box_);

 //?main_layout_->addLayout(clear_button_layout_);

 setLayout(main_layout_);

 show();
}



MMUI_Diagnostic_Report_Summary_Dialog::~MMUI_Diagnostic_Report_Summary_Dialog()
{
 delete button_ok_;
 delete button_proceed_;
 delete button_cancel_;

// delete url_label_;
// delete name_ qLe_;
}



void MMUI_Diagnostic_Report_Summary_Dialog::cancel()
{
 Q_EMIT(rejected());
 Q_EMIT(canceled(this));
 Q_EMIT(rejected());
 close();
//
 close();
}

void MMUI_Diagnostic_Report_Summary_Dialog::accept()
{
 Q_EMIT(accepted(this));
// close();
}


