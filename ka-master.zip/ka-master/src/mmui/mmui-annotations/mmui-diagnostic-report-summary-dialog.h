
#ifndef MMUI_DIAGNOSTIC_REPORT_SUMMARY_DIALOG__H
#define MMUI_DIAGNOSTIC_REPORT_SUMMARY_DIALOG__H

#include <QObject>

#include <QMetaType>

#include <QList>
#include <QGraphicsScene>
#include <QPoint>

#include <QDialog>

#include "accessors.h"


class QDialogButtonBox;
class QLabel;
class QLineEdit;
class QTabWidget;
class QPlainTextEdit;
class QTextEdit;
class QFrame;
class QHBoxLayout;
class QVBoxLayout;
class QSlider;
class QLineEdit;
class QBoxLayout;
class QButtonGroup;
class QGroupBox;
class QFormLayout;
class QComboBox;
class QDateEdit;
class QGridLayout;
class QLabel;

class MMUI_Arrow_Factory;

class MMUI_Diagnostic_Report_Summary_Dialog : public QDialog
{

 Q_OBJECT

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QPushButton* button_proceed_;


 QVBoxLayout* main_layout_;

 QFrame* live_session_report_frame_;
 QGridLayout* live_session_report_layout_;

 QLabel* qL_organization_information_;
 QPlainTextEdit* qPTE_organization_information_;

 QLabel* qL_lead_tech_;
 QPlainTextEdit* qPTE_lead_tech_;

 QLabel* qL_lead_consultant_;
 QPlainTextEdit* qPTE_lead_consultant_;

 QLabel* qL_size_of_specimen_;
 QLineEdit* qLE_size_of_specimen_;

 QLabel* qL_stain_;
 QLineEdit* qLE_stain_;


 QFrame* gross_description_frame_;
 QVBoxLayout* gross_description_layout_;
 QPlainTextEdit* qPTE_gross_description_;

 QFrame* pathological_diagnosis_frame_;
 QVBoxLayout* pathological_diagnosis_layout_;
 QPlainTextEdit* qPTE_pathological_diagnosis_;


 QTabWidget* main_notebook_;


public:


 MMUI_Diagnostic_Report_Summary_Dialog(QWidget* parent = nullptr);

 ~MMUI_Diagnostic_Report_Summary_Dialog();

Q_SIGNALS:
 void canceled(QDialog*);
 void accepted(QDialog*);


public Q_SLOTS:
 void accept();
 void cancel();

};


#endif  // MMUI_ARROW_FACTORY__H
