
#include "mmui-graphics-item-group.h"

#include <QDebug>

#include "qtarrowitem.h"

#include <QGraphicsPolygonItem>

#include <QtMath>

#include <QGraphicsSceneMouseEvent>
//#include <QGraphicsSceneMouseEvent>


MMUI_Graphics_Item_Group::MMUI_Graphics_Item_Group(QList<QGraphicsItem*> items,
                                                   //int position_gap, int local_radius,
//  int initial_center_x,
//  int initial_center_y,
  QPointF ground_point,
  std::function<bool(MMUI_Graphics_Item_Group* mgig, int, int, int, int, qreal)> item_moved_callback)
  : QGraphicsItemGroup(nullptr), //position_gap_(position_gap), local_radius_(local_radius),
//    initial_center_x_(initial_center_x),
//    initial_center_y_(initial_center_y),
    ground_point_(ground_point), item_moved_callback_(item_moved_callback)
{
 for(QGraphicsItem* item : items)
 {
  addToGroup(item);
 }
}

void MMUI_Graphics_Item_Group::mousePressEvent(QGraphicsSceneMouseEvent* event)
{
//? this->QGraphicsItemGroup::setZValue(2);
//? this->QGraphicsItemGroup::mousePressEvent(event);

// QPointF ep = event->pos();

// qreal angle = atan2(ep.y() - ground_point_.y(),
//                     ep.x() - ground_point_.x());

// //?angle = 0.25 - (angle / (2 * M_PI));

// qDebug() << "Angle: " << angle;

}


void MMUI_Graphics_Item_Group::mouseMoveEvent(QGraphicsSceneMouseEvent* event)
{
//? this->QGraphicsItemGroup::setZValue(2);
//? this->QGraphicsItemGroup::mousePressEvent(event);

 QPointF ep = event->pos();

 qreal angle = atan2(ep.y() - ground_point_.y(),
                     ep.x() - ground_point_.x());

 angle =  -(angle / (2 * M_PI));

 if(angle < 0)
   angle += 1;

 bool cancel_propagate = item_moved_callback_(this, 0, 0, 0, 0, angle);

 if(!cancel_propagate)
 {
  //?qDebug() << "!CP";
  this->QGraphicsItemGroup::mouseMoveEvent(event);
 }


}


void MMUI_Graphics_Item_Group::mouseReleaseEvent(QGraphicsSceneMouseEvent* event)
{
 this->QGraphicsItemGroup::setZValue(0);

 this->setSelected(false);

 QPointF ep = event->pos();
 QPointF esp = event->scenePos();
 QPointF esrp = event->screenPos();


 QPointF myp = pos();
 QPointF mysp = scenePos();


 qreal epx = event->scenePos().x();
 qreal epy = event->scenePos().y();

 //?item_moved_callback_(offset_x, offset_y, poxs, poys, avg);

}

