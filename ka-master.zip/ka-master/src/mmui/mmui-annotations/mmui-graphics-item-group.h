
#ifndef MMUI_GRAPHICS_ITEM_GROUP__H
#define MMUI_GRAPHICS_ITEM_GROUP__H

#include <QObject>

#include <QMetaType>

#include <QColor>
#include <QBrush>
#include <QPen>

#include <QGraphicsItemGroup>

#include "accessors.h"



class MMUI_Graphics_Item_Group : public QGraphicsItemGroup
{
 // int local_radius_;
 // int position_gap_;

 std::function<bool(MMUI_Graphics_Item_Group* mgig, int, int, int, int, qreal)> item_moved_callback_;

 QPointF ground_point_;

public:

//? QVariant itemChange(GraphicsItemChange change, const QVariant &value) override;

 MMUI_Graphics_Item_Group(QList<QGraphicsItem*> items, //, int position_gap, int local_radius, //int initial_center_x,
  //int initial_center_y,
      QPointF ground_point,
      std::function<bool(MMUI_Graphics_Item_Group* mgig, int, int, int, int, qreal)> item_moved_callback);

 void mouseReleaseEvent(QGraphicsSceneMouseEvent *event) override;
//?
 void mousePressEvent(QGraphicsSceneMouseEvent *event) override;

//?
 void mouseMoveEvent(QGraphicsSceneMouseEvent *event) override;

};


#endif  // MMUI_ARROW_FACTORY__H
