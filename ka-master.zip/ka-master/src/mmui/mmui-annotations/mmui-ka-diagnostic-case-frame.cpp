
#include "mmui-ka-diagnostic-case-frame.h"

#include "styles.h"


MMUI_KA_Diagnostic_Case_Frame::MMUI_KA_Diagnostic_Case_Frame(const MMUI_KA_Diagnostic_Case& diagnostic_case,
  QWidget* parent)
  :  QFrame(parent)
{
 diagnostic_case_ = diagnostic_case;

 main_layout_ = new QHBoxLayout;

 info_layout_ = new QGridLayout;

 patient_name_label_ = new QLabel("Patient Name:", this);
 patient_name_line_edit_ = new QLineEdit(diagnostic_case_.patient_name());

 case_id_label_ = new QLabel("Case ID:", this);
 case_id_line_edit_ = new QLineEdit(diagnostic_case_.case_id());

 date_label_ = new QLabel("Date Posted:", this);
 date_line_edit_ = new QLineEdit(diagnostic_case_.posted_date().toString(), this);

 info_layout_->addWidget(patient_name_label_, 0, 0);
 info_layout_->addWidget(patient_name_line_edit_, 0, 1, 1, 3);

 info_layout_->addWidget(case_id_label_, 1, 0);
 info_layout_->addWidget(case_id_line_edit_, 1, 1);

 info_layout_->addWidget(date_label_, 1, 2);
 info_layout_->addWidget(date_line_edit_, 1, 3);

 main_layout_->addLayout(info_layout_);

 download_button_ = new QPushButton("Download", this);

 download_button_->setStyleSheet(colorful_button_style_sheet_());

 main_layout_->addWidget(download_button_);

 setLayout(main_layout_);


}


