
#ifndef MMUI_KA_DIAGNOSIC_CASE_FRAME__H
#define MMUI_KA_DIAGNOSIC_CASE_FRAME__H

#include <QObject>

#include <QMetaType>

#include <QString>
#include <QDate>

#include <QFrame>
#include <QGridLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>

#include "accessors.h"

#include "mmui-ka-diagnostic-case.h"


class MMUI_KA_Diagnostic_Case_Frame : public QFrame
{
 Q_OBJECT

 MMUI_KA_Diagnostic_Case diagnostic_case_;


public:

 MMUI_KA_Diagnostic_Case_Frame(const MMUI_KA_Diagnostic_Case& diagnostic_case, QWidget* parent = nullptr);

 QHBoxLayout* main_layout_;

 QGridLayout* info_layout_;

 QLabel* patient_name_label_;
 QLineEdit* patient_name_line_edit_;

 QLabel* case_id_label_;
 QLineEdit* case_id_line_edit_;

 QLabel* date_label_;
 QLineEdit* date_line_edit_;

 QPushButton* download_button_;


};


#endif  // MMUI_KA_DIAGNOSIC_CASE__H
