
#ifndef MMUI_KA_DIAGNOSIC_CASE__H
#define MMUI_KA_DIAGNOSIC_CASE__H

#include <QObject>

#include <QMetaType>

#include <QString>
#include <QDate>

#include "accessors.h"


class MMUI_KA_Diagnostic_Case
{
 QString patient_name_;
 QDate posted_date_;
 QString case_id_;


public:

 MMUI_KA_Diagnostic_Case();

 ACCESSORS(QString ,patient_name)
 ACCESSORS(QDate ,posted_date)
 ACCESSORS(QString ,case_id)



};


#endif  // MMUI_KA_DIAGNOSIC_CASE__H
