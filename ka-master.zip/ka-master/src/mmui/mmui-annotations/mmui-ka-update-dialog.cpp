
#include "mmui-ka-update-dialog.h"

#include "styles.h"


#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QButtonGroup>
#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>
#include <QComboBox>

#include <QDateEdit>

#include <QLineEdit>
#include <QTextStream>

#include <QPainter>
#include <QPushButton>
#include <QLabel>

#include <QPlainTextEdit>

#include <QTableWidget>
#include <QGraphicsPixmapItem>

#include <QMessageBox>
#include <QDebug>

#include <QGraphicsView>


#include <QHeaderView>

#include <QMenu>
#include <QAction>

#include <QListWidget>
#include <QDateEdit>

#include "mmui-ka-diagnostic-case.h"
#include "mmui-ka-diagnostic-case-frame.h"


MMUI_KA_Update_Dialog::MMUI_KA_Update_Dialog(
  QWidget* parent)
  : QDialog(parent)
{
 //?arrow_factory_ = new MMUI_Arrow_Factory;

 button_box_ = new QDialogButtonBox(this);

 button_ok_ = new QPushButton("OK");
 button_proceed_ = new QPushButton("Proceed");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

 button_proceed_->setDefault(false);
 button_proceed_->setAutoDefault(false);
 //?button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);


 QString colorful_button_style_sheet = colorful_button_style_sheet_();

 QString colorful_toggle_button_style_sheet = colorful_button_quiet_style_sheet_(); //colorful_toggle_button_style_sheet_();


 QString colorful_button_style_sheet_down = colorful_button_style_sheet_down_();
 QString colorful_button_quiet_style_sheet = colorful_button_quiet_style_sheet_();

 QString tab_style_sheet = tab_style_sheet_();

 QString button_close_style_sheet = //?button_close_style_sheet_();

  " QPushButton:hover {background:rgb(150,240,190);"
  "  border-left: 4px groove rgb(150,240,190); "
  "  border-right: 4px ridge rgb(150,240,190); "
  " }\n "

  " QPushButton { background:rgb(220,220,230); "
  "  border: 2px groove rgb(0,90,50); "
  "  font-family:\"Comic Sans MS\", cursive, sans-serif; "
  "  border-bottom: 2px groove rgb(240,190,150); "
  "  border-top: 2px groove rgb(240,90,150); "
  "  border-radius: 10px; font-weight:600; color:rgb(0, 90, 105); "
  "  padding-left:16px;padding-right:16px;padding-top:2px;padding-bottom:2px; "

//   " border-left: 4px groove rgb(0,190,150);   "
//   " border-right: 4px ridge rgb(240,190,150); "

  " }\n"

  " QPushButton[enabled=false] { color:grey; } "



  " QPushButton:pressed{ color:black; padding:1px; "
  "  border: 1px solid rgb(150,240,190); "
  "  border-bottom: 1px solid #CEF51D; "
  "  border-radius: 0px; "
  "  background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, "
  "   stop: 0 white, stop: 0.1 #C0C0C0, stop: 0.6 #C6CCBC "
  "   stop: 0.8 #A0ECCF, stop: 0.9 darkseagreen,  stop: 1 blue"
  "  ); min-width: 80px; } ";


 QString basic_button_style_sheet = basic_button_style_sheet_();



 // button_ok_->setStyleSheet(button_close_style_sheet);
 // button_proceed_->setStyleSheet(button_close_style_sheet);
 // button_cancel_->setStyleSheet(button_close_style_sheet);


 button_ok_->setStyleSheet(basic_button_style_sheet_());
 button_proceed_->setStyleSheet(basic_button_style_sheet_());
 button_cancel_->setStyleSheet(basic_button_style_sheet_());


 connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));

 button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);


 main_layout_ = new QVBoxLayout;

 updates_layout_ = new QVBoxLayout;

 info_label_ = new QLabel("Pending Cases:", this);

 main_layout_->addWidget(info_label_);

 MMUI_KA_Diagnostic_Case c1;
 c1.set_patient_name("Sample Name");
 c1.set_case_id("Sample ID");
 c1.set_posted_date(QDate::currentDate());

 MMUI_KA_Diagnostic_Case c2;
 c2.set_patient_name("Test Name");
 c2.set_case_id("Test ID");
 c2.set_posted_date(QDate::currentDate());


 MMUI_KA_Diagnostic_Case_Frame* f1 = new MMUI_KA_Diagnostic_Case_Frame(c1);
 MMUI_KA_Diagnostic_Case_Frame* f2 = new MMUI_KA_Diagnostic_Case_Frame(c2);

 updates_layout_->addWidget(f1);
 updates_layout_->addWidget(f2);


 main_layout_->addLayout(updates_layout_);

 main_layout_->addWidget(button_box_);

 //?main_layout_->addLayout(clear_button_layout_);

 setLayout(main_layout_);

 show();
}



MMUI_KA_Update_Dialog::~MMUI_KA_Update_Dialog()
{
 delete button_ok_;
 delete button_proceed_;
 delete button_cancel_;

// delete url_label_;
// delete name_ qLe_;
}



void MMUI_KA_Update_Dialog::cancel()
{
 Q_EMIT(rejected());
 Q_EMIT(canceled(this));
 Q_EMIT(rejected());
 close();
//
 close();
}

void MMUI_KA_Update_Dialog::accept()
{
 Q_EMIT(accepted(this));
// close();
}


