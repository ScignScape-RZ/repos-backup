
#ifndef MMUI_KA_UPDATE_DIALOG__H
#define MMUI_KA_UPDATE_DIALOG__H

#include <QObject>

#include <QMetaType>

#include <QList>
#include <QGraphicsScene>
#include <QPoint>

#include <QDialog>

#include "MoND-UI/controls/single-edit-combo-box.h"

#include "accessors.h"


class QDialogButtonBox;
class QLabel;
class QLineEdit;
class QTabWidget;
class QPlainTextEdit;
class QTextEdit;
class QFrame;
class QHBoxLayout;
class QVBoxLayout;
class QGridLayout;
class QSlider;
class QLineEdit;
class QBoxLayout;
class QButtonGroup;
class QGroupBox;
class QFormLayout;
class QComboBox;
class QDateEdit;

class MMUI_Arrow_Factory;

class MMUI_KA_Update_Dialog : public QDialog
{

 Q_OBJECT

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QPushButton* button_proceed_;


 QVBoxLayout* main_layout_;


 QVBoxLayout* updates_layout_;

 QLabel* info_label_;

public:


 MMUI_KA_Update_Dialog(QWidget* parent = nullptr);

 ~MMUI_KA_Update_Dialog();


Q_SIGNALS:

 void canceled(QDialog*);
 void accepted(QDialog*);


public Q_SLOTS:

 void accept();
 void cancel();

};


#endif  // MMUI_ARROW_FACTORY__H
