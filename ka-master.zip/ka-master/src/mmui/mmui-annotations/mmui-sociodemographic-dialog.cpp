
#include "mmui-sociodemographic-dialog.h"

#include "styles.h"


#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QButtonGroup>
#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>
#include <QComboBox>

#include <QDateEdit>

#include <QLineEdit>
#include <QTextStream>

#include <QPainter>
#include <QPushButton>
#include <QLabel>

#include <QPlainTextEdit>

#include <QTableWidget>
#include <QGraphicsPixmapItem>

#include <QMessageBox>
#include <QDebug>

#include <QGraphicsView>


#include <QHeaderView>

#include <QMenu>
#include <QAction>

#include <QListWidget>
#include <QDateEdit>


MMUI_Sociodemographic_Dialog::MMUI_Sociodemographic_Dialog(
  QWidget* parent)
  : QDialog(parent)
{
 //?arrow_factory_ = new MMUI_Arrow_Factory;

 button_box_ = new QDialogButtonBox(this);

 button_ok_ = new QPushButton("OK");
 button_proceed_ = new QPushButton("Proceed");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

 button_proceed_->setDefault(false);
 button_proceed_->setAutoDefault(false);
 //?button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);


 QString colorful_button_style_sheet = colorful_button_style_sheet_();

 QString colorful_toggle_button_style_sheet = colorful_button_quiet_style_sheet_(); //colorful_toggle_button_style_sheet_();


 QString colorful_button_style_sheet_down = colorful_button_style_sheet_down_();
 QString colorful_button_quiet_style_sheet = colorful_button_quiet_style_sheet_();

 QString tab_style_sheet = tab_style_sheet_();

 QString button_close_style_sheet = //?button_close_style_sheet_();

  " QPushButton:hover {background:rgb(150,240,190);"
  "  border-left: 4px groove rgb(150,240,190); "
  "  border-right: 4px ridge rgb(150,240,190); "
  " }\n "

  " QPushButton { background:rgb(220,220,230); "
  "  border: 2px groove rgb(0,90,50); "
  "  font-family:\"Comic Sans MS\", cursive, sans-serif; "
  "  border-bottom: 2px groove rgb(240,190,150); "
  "  border-top: 2px groove rgb(240,90,150); "
  "  border-radius: 10px; font-weight:600; color:rgb(0, 90, 105); "
  "  padding-left:16px;padding-right:16px;padding-top:2px;padding-bottom:2px; "

//   " border-left: 4px groove rgb(0,190,150);   "
//   " border-right: 4px ridge rgb(240,190,150); "

  " }\n"

  " QPushButton[enabled=false] { color:grey; } "



  " QPushButton:pressed{ color:black; padding:1px; "
  "  border: 1px solid rgb(150,240,190); "
  "  border-bottom: 1px solid #CEF51D; "
  "  border-radius: 0px; "
  "  background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, "
  "   stop: 0 white, stop: 0.1 #C0C0C0, stop: 0.6 #C6CCBC "
  "   stop: 0.8 #A0ECCF, stop: 0.9 darkseagreen,  stop: 1 blue"
  "  ); min-width: 80px; } ";


 QString basic_button_style_sheet = basic_button_style_sheet_();





 button_ok_->setStyleSheet(button_close_style_sheet);
 button_proceed_->setStyleSheet(button_close_style_sheet);
 button_cancel_->setStyleSheet(button_close_style_sheet);


 connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));



 main_layout_ = new QVBoxLayout();


 qLe_last_name_ = new QLineEdit(this);
 qLe_first_name_ = new QLineEdit(this);

 sCb_gender_ = new Single_Edit_Combo_Box(this);

 sCb_gender_->addItem("Not Specified");
 sCb_gender_->addItem("Male");
 sCb_gender_->addItem("Female");
 sCb_gender_->add_single_edit_item("Other ...", "Other (edit)");

 //?QLineEdit* gender_le = new QLineEdit;
 //?gender_le->setPlaceholderText("Other");
 //?qCb_gender_->setLineEdit(gender_le);
 //?qCb_gender_->setEditable(true);


 qDe_date_of_birth_ = new QDateEdit(this);
 qDe_date_of_birth_->setCalendarPopup(true);
 qDe_date_of_birth_->setDate(QDate::currentDate());

 qLe_type_of_residence_ =  new QLineEdit(this);
 pTe_address_ =  new QPlainTextEdit(this);


 qLe_occupation_ =  new QLineEdit(this);
 qLe_marital_status_ =  new QLineEdit(this);
 qLe_education_level_ =  new QLineEdit(this);
 qLe_main_telephone_ =  new QLineEdit(this);
 qCb_additional_telephone_ = new QComboBox(this);
 qLe_PAN_number_ =  new QLineEdit(this);
 qLe_AADHAR_number_ =  new QLineEdit(this);
 qLe_place_of_birth_ = new QLineEdit(this);


 qLe_mothers_name_ =  new QLineEdit(this);
 qLe_mothers_status_ =  new QLineEdit(this);
 qLe_fathers_name_ =  new QLineEdit(this);
 qLe_fathers_status_ =  new QLineEdit(this);
 qLe_contact_person_name_ =  new QLineEdit(this);
 qLe_contact_person_phone_ =  new QLineEdit(this);

 qCb_additional_telephone_->addItem("");

 QLineEdit* le = new QLineEdit;
 le->setPlaceholderText("(Enter New Number)");

 qCb_additional_telephone_->setLineEdit(le);
 qCb_additional_telephone_->setEditable(true);


 basic_patient_info_frame_ = new QFrame(this);
 basic_patient_info_layout_ = new QFormLayout;


 basic_patient_info_layout_->addRow("Last Name", qLe_last_name_);
 basic_patient_info_layout_->addRow("First Name", qLe_first_name_);
 basic_patient_info_layout_->addRow("Gender", sCb_gender_);
 basic_patient_info_layout_->addRow("Date of Birth", qDe_date_of_birth_);
 basic_patient_info_layout_->addRow("Main Telephone", qLe_main_telephone_);
 basic_patient_info_layout_->addRow("Other Telephone", qCb_additional_telephone_);
 basic_patient_info_layout_->addRow("PAN Number", qLe_PAN_number_);
 basic_patient_info_layout_->addRow("AADHAR Number", qLe_AADHAR_number_);

 basic_patient_info_frame_->setLayout(basic_patient_info_layout_);

 demographic_info_frame_ = new QFrame(this);
 demographic_info_layout_ = new QFormLayout;


 demographic_info_layout_->addRow("Type of Residence", qLe_type_of_residence_);

 demographic_info_layout_->addRow("Address", pTe_address_);
 demographic_info_layout_->addRow("Occupation", qLe_occupation_);
 demographic_info_layout_->addRow("Marital Status", qLe_marital_status_);

 demographic_info_layout_->addRow("Education qLevel", qLe_education_level_);
 demographic_info_layout_->addRow("Place of Birth", qLe_place_of_birth_);

 demographic_info_frame_->setLayout(demographic_info_layout_);


 family_info_frame_ = new QFrame(this);
 family_info_layout_ = new QFormLayout;

 family_info_layout_->addRow("Mother's Name", qLe_mothers_name_);
 family_info_layout_->addRow("Mother's Status", qLe_mothers_status_);

 family_info_layout_->addRow("Father's Name", qLe_fathers_name_);
 family_info_layout_->addRow("Father's Status", qLe_fathers_status_);

 family_info_layout_->addRow("Contact Name", qLe_contact_person_name_);
 family_info_layout_->addRow("Contact Phone", qLe_contact_person_phone_);

 family_info_frame_->setLayout(family_info_layout_);


 //main_layout_->addLayout(patient_info_layout_);

 main_notebook_ = new QTabWidget(this);

 main_notebook_->setStyleSheet(tab_style_sheet);

 main_notebook_->addTab(basic_patient_info_frame_, "Basic Patient Info");
 main_notebook_->addTab(demographic_info_frame_, "Demographic Info");
 main_notebook_->addTab(family_info_frame_, "Family Info");

 main_layout_->addWidget(main_notebook_);

 main_layout_->addWidget(button_box_);

 //?main_layout_->addLayout(clear_button_layout_);

 setLayout(main_layout_);

 show();
}



MMUI_Sociodemographic_Dialog::~MMUI_Sociodemographic_Dialog()
{
 delete button_ok_;
 delete button_proceed_;
 delete button_cancel_;

// delete url_label_;
// delete name_ qLe_;
}



void MMUI_Sociodemographic_Dialog::cancel()
{
 Q_EMIT(rejected());
 Q_EMIT(canceled(this));
 Q_EMIT(rejected());
 close();
//
 close();
}

void MMUI_Sociodemographic_Dialog::accept()
{
 Q_EMIT(accepted(this));
// close();
}


