
#ifndef MMUI_SOCIODEMOGRAPHICS_DIALOG__H
#define MMUI_SOCIODEMOGRAPHICS_DIALOG__H

#include <QObject>

#include <QMetaType>

#include <QList>
#include <QGraphicsScene>
#include <QPoint>

#include <QDialog>

#include "MoND-UI/controls/single-edit-combo-box.h"

#include "accessors.h"


class QDialogButtonBox;
class QLabel;
class QLineEdit;
class QTabWidget;
class QPlainTextEdit;
class QTextEdit;
class QFrame;
class QHBoxLayout;
class QVBoxLayout;
class QSlider;
class QLineEdit;
class QBoxLayout;
class QButtonGroup;
class QGroupBox;
class QFormLayout;
class QComboBox;
class QDateEdit;

class MMUI_Arrow_Factory;

class MMUI_Sociodemographic_Dialog : public QDialog
{

 Q_OBJECT

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QPushButton* button_proceed_;


 QVBoxLayout* main_layout_;

 QFrame* basic_patient_info_frame_;
 QFormLayout* basic_patient_info_layout_;
 QLineEdit* qLe_last_name_;
 QLineEdit* qLe_first_name_;

 Single_Edit_Combo_Box* sCb_gender_;

 QLineEdit* qLe_main_telephone_;
 QComboBox* qCb_additional_telephone_;
 QDateEdit* qDe_date_of_birth_;
 QLineEdit* qLe_PAN_number_;
 QLineEdit* qLe_AADHAR_number_;

 QFrame* demographic_info_frame_;
 QFormLayout* demographic_info_layout_;
 QLineEdit* qLe_type_of_residence_;
 QPlainTextEdit* pTe_address_;
 QLineEdit* qLe_occupation_;
 QLineEdit* qLe_marital_status_;
 QLineEdit* qLe_education_level_;
 QLineEdit* qLe_place_of_birth_;

 QFrame* family_info_frame_;
 QFormLayout* family_info_layout_;
 QLineEdit* qLe_mothers_name_;
 QLineEdit* qLe_mothers_status_;
 QLineEdit* qLe_fathers_name_;
 QLineEdit* qLe_fathers_status_;
 QLineEdit* qLe_contact_person_name_;
 QLineEdit* qLe_contact_person_phone_;

 QTabWidget* main_notebook_;

// QString new_gender_text_;

public:


 MMUI_Sociodemographic_Dialog(QWidget* parent = nullptr);

 ~MMUI_Sociodemographic_Dialog();


Q_SIGNALS:
 void canceled(QDialog*);
 void accepted(QDialog*);


public Q_SLOTS:
 void accept();
 void cancel();

};


#endif  // MMUI_ARROW_FACTORY__H
