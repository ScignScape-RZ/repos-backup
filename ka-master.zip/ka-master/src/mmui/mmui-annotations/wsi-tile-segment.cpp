
#include "wsi-tile-segment.h"


WSI_Tile_Segment::WSI_Tile_Segment(int x, int y, int width, int height)
  :  width_(width), height_(height), x_(x), y_(y)
{
}

WSI_Tile_Segment::WSI_Tile_Segment()
  :  width_(0), height_(0), x_(0), y_(0)
{

}

