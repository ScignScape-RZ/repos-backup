
#ifndef WSI_TILE_SEGMENT__H
#define WSI_TILE_SEGMENT__H


#include "accessors.h"

#include <QPen>
#include <QBrush>
#include <QString>

class WSI_Tile_Segment
{
 int x_;
 int y_;
 int width_;
 int height_;

public:

 WSI_Tile_Segment(int x, int y, int width, int height);

 WSI_Tile_Segment();

 ACCESSORS(int ,x)
 ACCESSORS(int ,y)
 ACCESSORS(int ,width)
 ACCESSORS(int ,height)

};

#endif  //  WSI_TILE__H
