
#include "wsi-tile.h"


WSI_Tile::WSI_Tile(QString local_path, int series_row, int series_column)
  : local_path_(local_path),
    series_row_(series_row),
    series_column_(series_column),
    associated_qobject_(nullptr),
    geometric_previous_(nullptr),
    geometric_next_(nullptr)
{

}

void WSI_Tile::add_tile_segment(int x, int y, int width, int height)
{
 tile_segments_.push_back(WSI_Tile_Segment(x, y, width, height));
}
