
#ifndef WSI_TILE__H
#define WSI_TILE__H


#include "accessors.h"

#include "wsi-tile-segment.h"

#include <QPen>
#include <QBrush>
#include <QString>


class QObject;

class WSI_Tile
{
 QString local_path_;

 int series_row_;
 int series_column_;

 QVector<WSI_Tile_Segment> tile_segments_;

 QObject* associated_qobject_;

 WSI_Tile* geometric_previous_;
 WSI_Tile* geometric_next_;

public:


 WSI_Tile(QString local_path, int series_row, int series_column);


 ACCESSORS(int ,series_row)
 ACCESSORS(int ,series_column)
 ACCESSORS(QObject* ,associated_qobject)

 ACCESSORS(WSI_Tile* ,geometric_previous)
 ACCESSORS(WSI_Tile* ,geometric_next)

 void add_tile_segment(int x, int y, int width, int height);


};

#endif  //  WSI_TILE__H
