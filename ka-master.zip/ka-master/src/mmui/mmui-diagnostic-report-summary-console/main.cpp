 
#include <QApplication>
#include <QGraphicsView>

#include <QList>
#include <QDebug>

#include <QMessageBox>

#include <QMenu>

#include <QGraphicsItem>

#include <QScreen>

#include <QImage>

#include <QApplication>
#include <QDesktopWidget>

#include <QFileDialog>


#include "mmui-diagnostic-report-summary-dialog.h"



int main(int argc, char **argv)
{

 QApplication qapp(argc, argv);


 MMUI_Diagnostic_Report_Summary_Dialog dlg(nullptr);


 dlg.show();

 qapp.exec();

}
