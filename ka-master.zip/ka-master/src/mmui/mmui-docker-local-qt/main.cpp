

#include "qhttpserver.hpp"
#include "qhttpserverconnection.hpp"
#include "qhttpserverrequest.hpp"
#include "qhttpserverresponse.hpp"

#include <QtCore/QCoreApplication>
#include <QDateTime>
#include <QLocale>

#include <QFileInfo>


#include "kauv-caf-response.h"
#include "kauv-caf-response-builder.h"


#include "qwhite-database.h"
#include "qwhite-column.h"
#include "qwhite-column-set.h"



namespace {
///////////////////////////////////////////////////////////////////////////////
using namespace qhttp::server;

/** connection class for gathering incoming chunks of data from HTTP client.
 * @warning please note that the incoming request instance is the parent of
 * this QObject instance. Thus this class will be deleted automatically.
 * */
class ClientHandler : public QObject
{
public:
    explicit ClientHandler(quint64 id, QHttpRequest* req, QHttpResponse* res,
      KAUV_CAF_Response_Builder& response_builder)
        : QObject(req /* as parent*/), iconnectionId(id),
          response_builder_(response_builder)
 {

        qDebug("connection #%llu ..." , id);

        // automatically collect http body(data) upto 1KB
        //?
        //?req->collectData(1024);
        //?
        req->collectData(8*1024*1024);

//        req->onData([](QByteArray qba)
//        {
//         qDebug() << "QBA: " << qba;
//        });

        // when all the incoming data are gathered, send some response to client.
        req->onEnd([this, req, res]() {

            qDebug("  connection (#%llu): request from %s:%d\n  method: %s url: %s",
                   iconnectionId,
                   req->remoteAddress().toUtf8().constData(),
                   req->remotePort(),
                   qhttp::Stringify::toString(req->method()),
                   qPrintable(req->url().toString())
                   );

            if ( req->collectedData().size() > 0 )
                qDebug("  body (#%llu): %s",
                        iconnectionId,
                        req->collectedData().constData()
                        );

            KAUV_CAF_Response pcr(response_builder_);

            //?res->end(message());

            QByteArray qba;
            QString message = pcr.get_response(req, res, qba);
//                QString("Hello World\n  packet count = %1\n  time = %2\n")
//                .arg(iconnectionId)
//                .arg(QLocale::c().toString(QDateTime::currentDateTime(),
//                                           "yyyy-MM-dd hh:mm:ss")
//                );

            if(qba.isEmpty())
            {
             res->setStatusCode(qhttp::ESTATUS_OK);
             res->addHeaderValue("content-length", message.size());
             res->end(message.toUtf8());
            }
            else
            {
             res->setStatusCode(qhttp::ESTATUS_OK);
             res->addHeaderValue("content-length", qba.size());
             res->addHeaderValue("content-type", message);
             res->end(qba);
            }

            if ( req->headers().keyHasValue("command", "quit") ) {
                qDebug("\n\na quit has been requested!\n");
                QCoreApplication::instance()->quit();
            }
        });
    }

    virtual ~ClientHandler() {
//        qDebug("  ~ClientHandler(#%llu): I've being called automatically!",
//                iconnectionId
//                );
    }

protected:
    quint64    iconnectionId;
    KAUV_CAF_Response_Builder& response_builder_;
};

///////////////////////////////////////////////////////////////////////////////
} // namespace anon
///////////////////////////////////////////////////////////////////////////////

int main(int argc, char ** argv)
{
    QCoreApplication app(argc, argv);

//?
//#if defined(Q_OS_UNIX)
//    catchUnixSignals({SIGQUIT, SIGINT, SIGTERM, SIGHUP});
//#endif


    QString portOrUnixSocket("14416");

//    if ( argc > 1 )
//        portOrUnixSocket = argv[1];

    QHttpServer server(&app);

    KAUV_CAF_Response_Builder kcrb;

    if(argc > 1)
    {
     qDebug() << "Setting Web Root Path: /usr/src/app-deploy-root/web/mmui/public";

//     site_manager.set_web_root_path(DOCKER__MMUI_WEB_ROOT_PATH);
//     site_manager.set_data_root_path(DOCKER__MMUI_DATA_ROOT_PATH);

     kcrb.set_data_base_path(DOCKER__MMUI_DATA_BASE_PATH);
     kcrb.set_web_base_path(DOCKER__MMUI_WEB_BASE_PATH);
     kcrb.set_partials_base_path(DOCKER__MMUI_PARTIALS_BASE_PATH);
     kcrb.set_pics_base_path(DOCKER__MMUI_PICS_BASE_PATH);
     kcrb.set_css_base_path(DOCKER__MMUI_CSS_BASE_PATH);
     kcrb.set_khif_base_path(DOCKER__MMUI_KHIF_BASE_PATH);
     kcrb.set_ngml_base_path(DOCKER__MMUI_NGML_BASE_PATH);
     kcrb.set_pdf_base_path(DOCKER__MMUI_PDF_BASE_PATH);

     QString crt_file;
     QString key_file;

     QString volume = "/usr/src/persistent-deploy-volume";
     QFile file(volume);
     if(file.exists())
     {
      //site_manager.set_data_base_path(volume);
      kcrb.set_data_base_path(volume);
      crt_file = "/usr/src/app-deploy-root/ssl-keys/server.crt";
      key_file = "/usr/src/app-deploy-root/ssl-keys/server.key";
     }
     else
     {//?
   #ifdef ARUKAS_DEPLOY
      QString drp = "/usr/src/app-deploy-root/app/data/deploy";
      qDebug() << "Setting data root path: " << drp;
      server.set_data_root_path(drp.toStdString());

      site_manager.set_data_root_path(drp);


   #else
      kcrb.set_data_base_path("/usr/src/app-deploy-data");

      //?site_manager.set_data_base_path("/usr/src/app-deploy-data");
   #endif
      qDebug() << "Setting crt and key files: " << "/usr/src/app-deploy-root/ssl-keys/server.crt"
               << " " << "/usr/src/app-deploy-root/ssl-keys/server.key";
      crt_file = "/usr/src/app-deploy-root/ssl-keys/server.crt";
      key_file = "/usr/src/app-deploy-root/ssl-keys/server.key";
     }
    }
    else
    {
//     site_manager.set_web_root_path(LOCAL__MMUI_WEB_ROOT_PATH);
//     site_manager.set_data_root_path(LOCAL__MMUI_DATA_ROOT_PATH);

     kcrb.set_data_base_path(LOCAL__MMUI_DATA_BASE_PATH);
     kcrb.set_web_base_path(LOCAL__MMUI_WEB_BASE_PATH);
     kcrb.set_partials_base_path(LOCAL__MMUI_PARTIALS_BASE_PATH);
     kcrb.set_pics_base_path(LOCAL__MMUI_PICS_BASE_PATH);
     kcrb.set_css_base_path(LOCAL__MMUI_CSS_BASE_PATH);
     kcrb.set_khif_base_path(LOCAL__MMUI_KHIF_BASE_PATH);
     kcrb.set_ngml_base_path(LOCAL__MMUI_NGML_BASE_PATH);
     kcrb.set_pdf_base_path(LOCAL__MMUI_PDF_BASE_PATH);
    }

    QWhite_Database* qwdb = nullptr;//new QWhite_Database;

    kcrb["^/up__check-database/(?<which>[\\w.-]+)$"]["GET"] = [&qwdb](QHttpRequest* request,
              QHttpResponse* response,
              const QRegularExpressionMatch& rxm, QByteArray& qba)
    {
     //QString q_content = QString::fromLatin1( request->collectedData() ); //.constData().
     //QString resp = site_manager.receive_create_file(q_content);

     QString cap = rxm.captured("which");
     QString result;

     if(cap == "create")
     {
      //QWhite_Database*
      qwdb = new QWhite_Database(
       "14416", LOCAL__MMUI_DATA_ROOT_PATH "/whitedb/databases/test/test-14416.wdb"
      );
      qwdb->create();
      result = QString("Created.  In filesystem at: %1")
        .arg(LOCAL__MMUI_DATA_ROOT_PATH "/whitedb/databases/test/test-14416.wdb");
     }
     else if(qwdb)
     {
      result = qwdb->check_data(cap);
     }
     else
     {
      result = "Null Database.";
     }
     result.prepend("Update Result: ");
     return result;
    };


    kcrb["\\A/info__check-index-file-path\\Z"]["GET"] = [&kcrb](QHttpRequest* request,
      QHttpResponse* response,
      const QRegularExpressionMatch& rxm, QByteArray& qba)
    {
     QString path = kcrb.resolve_web_path("index.html");
     return QString("index.html is located at: %1").arg(path);
    };

    kcrb["\\A/info__check-database-file-path\\Z"]["GET"] = [&kcrb](QHttpRequest* request,
      QHttpResponse* response,
      const QRegularExpressionMatch& rxm, QByteArray& qba)
    {
     QString path = kcrb.resolve_web_path("index.html");
     QString result = QString("The WhiteDB database is at: %1")
       .arg(LOCAL__MMUI_DATA_ROOT_PATH "/whitedb/databases/test/test-13139.wdb");
     return result;
    };



    kcrb["\\A/\\Z"]["GET"] = [&kcrb](QHttpRequest* request,
      QHttpResponse* response,
      const QRegularExpressionMatch& rxm, QByteArray& qba)
    {
     QString path = kcrb.resolve_web_path("index.html");
     return kcrb.read_file(path);
    };

    kcrb["/ok(?<num>\\d+)"]["GET"] = [](QHttpRequest* request,
      QHttpResponse* response,
      const QRegularExpressionMatch& rxm, QByteArray& qba)
    {
     QString aa = rxm.captured("num");
     return QString(R"__(
      <b><i>OK ... %1</i></b>
      )__").arg(aa);
    };


    qDebug() << "As of: " << QDateTime::currentDateTime().toString();
    qDebug() << "Listening on port: " <<  portOrUnixSocket;

    // dumb (trivial) connection counter
    quint64 iconnectionCounter = 0;

    server.listen(portOrUnixSocket, [&](QHttpRequest* req, QHttpResponse* res){
        new ClientHandler(++iconnectionCounter, req, res, kcrb);
        // this ClientHandler object will be deleted automatically when:
        // socket disconnects (automatically after data has been sent to the client)
        //     -> QHttpConnection destroys
        //         -> QHttpRequest destroys -> ClientHandler destroys
        //         -> QHttpResponse destroys
        // all by parent-child model of QObject.
    });

    if ( !server.isListening() ) {
        fprintf(stderr, "can not listen on %s!\n", qPrintable(portOrUnixSocket));
        return -1;
    }

    app.exec();
}


