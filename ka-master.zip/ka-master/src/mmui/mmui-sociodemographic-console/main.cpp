 
#include <QApplication>
#include <QGraphicsView>

#include <QList>
#include <QDebug>

#include <QMessageBox>

#include <QMenu>

#include <QGraphicsItem>

#include <QScreen>

#include <QImage>

#include <QApplication>
#include <QDesktopWidget>

#include <QFileDialog>


#include "mmui-sociodemographic-dialog.h"



int main(int argc, char **argv)
{

 QApplication qapp(argc, argv);


 MMUI_Sociodemographic_Dialog dlg(nullptr);


 dlg.show();

 qapp.exec();

}
