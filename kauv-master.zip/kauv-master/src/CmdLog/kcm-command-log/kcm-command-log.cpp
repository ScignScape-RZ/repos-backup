
#include "kcm-command-log.h"

#include "kauvir/kauvir-code-model/kauvir-code-model.h"
#include "kauvir/kauvir-type-system/kauvir-type-system.h"

#include "CmdLog/kcm-command-package/kcm-command-package.h"

#include "kans.h"

USING_KANS(CMD)


KCM_Command_Log::KCM_Command_Log(Kauvir_Code_Model* code_model)
  :  code_model_(code_model), type_system_(code_model->type_system()),
     cb_(nullptr)
{

}

void KCM_Command_Log::operator()(const KCM_Command_Package& kcp)
{
 QString qs = kcp_to_string(kcp);
 logs_.push_back(qs);
 if(cb_)
 {
  cb_(&logs_, &qs);
 }
}

QString KCM_Command_Log::kcp_to_string(const KCM_Command_Package& kcp)
{
 QString result;
 static QString sep = ", ";
 static QString last_sep = " ";
 result += kcp.report_sigma(*code_model_, sep, last_sep, "");
 result += kcp.report_fuxe(*code_model_, sep, last_sep, "(?)");
 result += kcp.report_lambda(*code_model_, sep, last_sep, "<()>");
 return result;
}

#define TEMP_MACRO(type) \
 const KCM_Type_Object* KCM_Command_Log::type_object__##type() { \
   return code_model_->get_kcm_type_by_kauvir_type_object(&type_system_->type_object__##type()); } \
 QPair<const KCM_Type_Object*, const KCM_Type_Object*> \
   KCM_Command_Log::type_object_pair__##type() { \
   return {type_object__##type(), nullptr}; }

 TEMP_MACRO(str)
 TEMP_MACRO(u8)
 //?TEMP_MACRO(u16)
 TEMP_MACRO(u32)

#undef TEMP_MACRO

