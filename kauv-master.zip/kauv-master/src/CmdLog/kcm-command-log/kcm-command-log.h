
#ifndef KCM_COMMAND_LOG__H
#define KCM_COMMAND_LOG__H

#include "kans.h"

#include <QStringList>

#include <functional>
//#include "kauvir/kauvir-code-model/kcm-channel-group.h"

KANS_CLASS_DECLARE(KCM ,Kauvir_Code_Model)
KANS_CLASS_DECLARE(KCM ,KCM_Type_Object)
KANS_CLASS_DECLARE(Kauvir ,Kauvir_Type_System)

USING_KANS(KCM)
USING_KANS(Kauvir)


KANS_(CMD)

class KCM_Command_Package;

class KCM_Command_Log
{
 Kauvir_Code_Model* code_model_;
 Kauvir_Type_System* type_system_;
 QStringList logs_;

public:
 typedef std::function<void(QStringList*, QString*)> cb_type;

private:

 cb_type cb_;


 QString kcp_to_string(const KCM_Command_Package& kcp);

public:

 KCM_Command_Log(Kauvir_Code_Model* code_model);


 void operator()(const KCM_Command_Package& kcp);
 void operator()(cb_type cb)
 {
  cb_ = cb;
 }

#define TEMP_MACRO(type) \
 const KCM_Type_Object* type_object__##type(); \
 QPair<const KCM_Type_Object*,const KCM_Type_Object*> \
   type_object_pair__##type();

 TEMP_MACRO(str)
 TEMP_MACRO(u8)
 //?TEMP_MACRO(u16)
 TEMP_MACRO(u32)

#undef TEMP_MACRO

};

_KANS(CMD)


#endif
