
#ifndef KCM_RUNTIME_SCOPE__H
#define KCM_RUNTIME_SCOPE__H

#include "kans.h"

//#include "kauvir/kauvir-code-model/kcm-channel-group.h"

#include "accessors.h"

#include <QMap>

KANS_CLASS_DECLARE(KCM ,Kauvir_Code_Model)
KANS_CLASS_DECLARE(KCM ,KCM_Type_Object)
KANS_CLASS_DECLARE(KCM ,KCM_Lexical_Scope)
KANS_CLASS_DECLARE(KCM ,KCM_Expression)
KANS_CLASS_DECLARE(KCM ,KCM_Source_Function)


USING_KANS(KCM)

KANS_(CMD)

class KCM_Runtime_Scope
{
 KCM_Runtime_Scope* parent_scope_;

 QMap<QString, QMap<const KCM_Type_Object*, QPair<const KCM_Type_Object*, quint64> > > values_;

 KCM_Lexical_Scope* associated_lexical_scope_;

public:

 explicit KCM_Runtime_Scope(KCM_Runtime_Scope* parent_scope);

 ACCESSORS(KCM_Runtime_Scope* ,parent_scope)
 ACCESSORS(KCM_Lexical_Scope* ,associated_lexical_scope)

 void add_value(QString symbol_name, const KCM_Type_Object* kto, quint64 v);

 void find_value(QString symbol_name, KCM_Expression* kcm_expression, quint64*& v,
   const KCM_Type_Object*& kto, const KCM_Type_Object*& ckto, QString& encoded_value);

 quint64 find_held_lisp_list(QString key);

 KCM_Source_Function* find_source_function_value(QString symbol_name);

 //?quint64 parse_encoded_value();
};

_KANS(CMD)


#endif

