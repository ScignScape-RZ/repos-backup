
#ifndef KCM_COMMAND_RUNTIME_ARGUMENT__H
#define KCM_COMMAND_RUNTIME_ARGUMENT__H

#include <QtGlobal>


#include <functional>

#include <QMetaProperty>
#include <QVector>

#include <QObject>
#include <QMetaObject>

#include "kans.h"
#include "accessors.h"

//?
//#include "cl-cxx/object.hpp"
//#include "kauvir-lisp-argument.h"
//#include "kauvir-type-system/kauvir-universal-class.h"


KANS_(CMD)

//class Kauvir_Request_Runtime;
//class Kauvir_Runtime_Router_Invokable;
//class Kauvir_Channel_Group;


class KCM_Command_Runtime_Argument
{
public:

  enum class Value_Classification
  {
   N_A, Generic_Ptr, QObject_Ptr, Raw_Int, Raw_QReal
  };

private:

 QString type_name_;
 void* raw_value_;
 QString bind_code_;

 Value_Classification value_classification_;

 const QMetaObject* qmo_;
 const QMetaObject* pqmo_;
 const QMetaType* qmt_;

public:

 KCM_Command_Runtime_Argument();

 ACCESSORS(Value_Classification ,value_classification)
 ACCESSORS(void* ,raw_value)
 ACCESSORS(QString ,type_name)
 ACCESSORS(QString ,bind_code)
 ACCESSORS(const QMetaObject* ,qmo)
 ACCESSORS(const QMetaObject* ,pqmo)
 ACCESSORS(const QMetaType* ,qmt)


 QString qob_reflection_type_name();
 QString qob_reflection_modifier();

 static QString type_name_to_qt_type_name(QString tn);

};

_KANS(CMD)

#endif // KCM_COMMAND_RUNTIME_ROUTER__H
