
#ifndef KCM_COMMAND_RUNTIME_ROUTER_QOB__H
#define KCM_COMMAND_RUNTIME_ROUTER_QOB__H

#include "kcm-command-runtime-router.h"

#include "kcm-command-runtime-argument.h"

USING_KANS(CMD)


#define ARGS_TEMP_MACRO(INDEX) \
 typename Type_List_Type::Type##INDEX& arg##INDEX \
   = *reinterpret_cast<typename Type_List_Type::Type##INDEX*> \
    ( argument_info[INDEX].void_argument );

#define QARG_TEMP_MACRO(INDEX) QArgument<ARG##INDEX##_Type> \
  ( argument_info[INDEX].type_name_with_modifier(args[INDEX - 1]->qob_reflection_modifier(), args[INDEX - 1]->qob_reflection_type_name()).toLatin1(), arg##INDEX) \



#define CASE_TEMP_MACRO_(INDEX, READY, INTERCHANGE_TYPE) \
 case INDEX: \
  Cast_##READY::run<OBJECT_Type, \
    typename Interchange<Type_List_Type, INDEX, READY>:: \
    template With_Type<INTERCHANGE_TYPE>::Result_Type>  \
    (method_name, obj, next_cast_index, kcrr,  \
    argument_info, args);  \
  break;  \


#define ARGS_TEMP_MACRO(INDEX) \
 typename Type_List_Type::Type##INDEX& arg##INDEX \
   = *reinterpret_cast<typename Type_List_Type::Type##INDEX*> \
    ( argument_info[INDEX].void_argument );

#define CAST_INDEX_SWITCH(TYPE) \
   switch(cast_index) \
   { \
    CASE_TEMP_MACRO(0, TYPE) \
    CASE_TEMP_MACRO(1, TYPE) \
   } \



struct Do_Invoke_Method__Cast_Schedule__QOB
{

 struct Cast_2_Ready
 {
  template<typename OBJECT_Type, typename ARG1_Type, typename ARG2_Type>
  static void run(QString method_name, OBJECT_Type obj, QVector<KCM_Command_Runtime_Argument*>& args,
                  ARG1_Type& arg1, ARG2_Type& arg2,
                  const QVector<KCM_Command_Runtime_Router::Argument_Info>& argument_info)
  {
   QMetaObject::invokeMethod(obj, method_name.toLatin1(),
     QArgument<ARG1_Type>(argument_info[1].type_name_with_modifier(args[0]->qob_reflection_modifier(), args[0]->qob_reflection_type_name()).toLatin1(), arg1),
     QArgument<ARG2_Type>(argument_info[2].type_name_with_modifier(args[1]->qob_reflection_modifier(), args[1]->qob_reflection_type_name()).toLatin1(), arg2));
  }

  template<typename OBJECT_Type, typename RET_Type, typename ARG1_Type, typename ARG2_Type>
  static void run(QString method_name, OBJECT_Type obj,
                  QString return_type, RET_Type& ret,
                  QVector<KCM_Command_Runtime_Argument*>& args,
                  ARG1_Type& arg1, ARG2_Type& arg2,
                  const QVector<KCM_Command_Runtime_Router::Argument_Info>& argument_info)
  {
//?
   QMetaObject::invokeMethod(obj, method_name.toLatin1(),
                             QReturnArgument<RET_Type>(return_type.toLatin1(), ret),
                             QArgument<ARG1_Type>(argument_info[1].type_name_with_modifier(args[0]->qob_reflection_modifier(), args[0]->qob_reflection_type_name()).toLatin1(), arg1),
     QArgument<ARG2_Type>(argument_info[2].type_name_with_modifier(args[1]->qob_reflection_modifier(), args[1]->qob_reflection_type_name()).toLatin1(), arg2));

   qDebug() << "RET: " << ret;
  }
 };

#define CASE_TEMP_MACRO(INDEX, INTERCHANGE_TYPE) \
   CASE_TEMP_MACRO_(INDEX, 2, INTERCHANGE_TYPE)

#define CAST_INDEX_SWITCH(TYPE) \
   switch(cast_index) \
   { \
    CASE_TEMP_MACRO(0, TYPE) \
    CASE_TEMP_MACRO(1, TYPE) \
   } \

 struct Cast_2
 {
  static constexpr int ready_at_cast_index = 2;
  template<typename OBJECT_Type, typename Type_List_Type>
  static void run(QString method_name, OBJECT_Type obj,
                  int cast_index, KCM_Command_Runtime_Router& kcrr,
                  QVector<KCM_Command_Runtime_Router::Argument_Info>& argument_info,
                  QVector<KCM_Command_Runtime_Argument*>& args)
  {
   if(cast_index == ready_at_cast_index)
   {
    switch(kcrr.return_type_code())
    {
    case KCM_Command_Runtime_Router::Arg_Type_Codes::No_Return:
     {
      ARGS_TEMP_MACRO(1)
      ARGS_TEMP_MACRO(2)
      Cast_2_Ready::run(method_name, obj,
                        args, arg1, arg2, argument_info);
     }
     break;
    case KCM_Command_Runtime_Router::Arg_Type_Codes::Int:
     {
      int& rrr = (int&) kcrr.raw_result_ref();
      ARGS_TEMP_MACRO(1)
      ARGS_TEMP_MACRO(2)
      Cast_2_Ready::run(method_name, obj,
        "int",
        rrr,
        args, arg1, arg2, argument_info);
     }
     break;
    }
    //   case KCM_Command_Runtime_Router::Arg_Type_Codes::Void_Pointer:
    //    {
    //     ARGS_TEMP_MACRO(1)
    //     ARGS_TEMP_MACRO(2)
    //     Cast_2_Ready::run(method_name, obj,
    //       kcrr.return_type_name_strip_namespace(),
    //       kcrr.raw_result(),
    //       args, arg1, arg2, argument_info);
    //    }
    //    break;
    //   case KCM_Command_Runtime_Router::Arg_Type_Codes::Int:
    //    {
    //     int& x = *reinterpret_cast<int*>(kcrr.raw_result());
    //     ARGS_TEMP_MACRO(1)
    //     ARGS_TEMP_MACRO(2)
    //     Cast_2_Ready::run(method_name, obj,
    //       "int",
    //       x,
    //       args, arg1, arg2, argument_info);
    //    }
    //    break;
    //   case KCM_Command_Runtime_Router::Arg_Type_Codes::QString_Return:
    //    {
    //     QString& qs = kcrr.string_result();
    //     ARGS_TEMP_MACRO(1)
    //     ARGS_TEMP_MACRO(2)
    //     Cast_2_Ready::run(method_name, obj,
    //      "QString", qs, args, arg1, arg2, argument_info);
    //    }
    //    break;
    //   }
   }
   else
   {
    int next_cast_index = cast_index + 1;
    KCM_Command_Runtime_Router::QOB_Argument_Conventions ac =
      argument_info[next_cast_index].qob_convention;
    switch(ac)
    {
    case KCM_Command_Runtime_Router::QOB_Argument_Conventions::QString_Direct:
    case KCM_Command_Runtime_Router::QOB_Argument_Conventions::Value_From_QString:
     {
      CAST_INDEX_SWITCH(quint64)
     }
//     break;
//    case KCM_Command_Runtime_Router::QOB_Argument_Conventions::QString_Direct:
//     {
//      //?QString* arg = (QString*) args[cast_index]->raw_value();
//      //?argument_info[next_cast_index].void_argument = arg;
//      //?argument_info[next_cast_index].type_name = "QString";
//      CAST_INDEX_SWITCH(quint64)
//     }
     break;
#ifdef HIDE
    case KCM_Command_Runtime_Router::QOB_Argument_Conventions::QString_Direct:
    {
     // //! args[cast_index]
     QString arg = args[cast_index].str();
     argument_info[next_cast_index].void_argument = &arg;
     argument_info[next_cast_index].type_name = "QString";
     CAST_INDEX_SWITCH(QString)
     }
     break;
    case KCM_Command_Runtime_Router::QOB_Argument_Conventions::QMetaType_Confirmed:
    {
     const QMetaType* qmt = argument_info[next_cast_index].q_meta_type;
     int id = argument_info[next_cast_index].q_meta_type_id;
     QString type_name = QString::fromLatin1(QMetaType::typeName(id));
     //void* pv = qmt->create();
     void* pv = QMetaType::create(id);
     // //!: note args[cast_index] ...
     KCM_Command_Runtime_Router::Arg_Type_Codes atc = KCM_Command_Runtime_Router::lisp_to_q_meta_type(args[cast_index].object(), pv);
     argument_info[next_cast_index].type_name = type_name;
     argument_info[next_cast_index].void_argument = pv;
     argument_info[next_cast_index].void_argument_for_delete = pv;
     switch(atc)
     {
     case KCM_Command_Runtime_Router::Arg_Type_Codes::Int:
      CAST_INDEX_SWITCH(int)
        break;
     }
    }
     break;
    case KCM_Command_Runtime_Router::QOB_Argument_Conventions::QVariant_Cast:
    {
     QVariant qvar = KCM_Command_Runtime_Router::lisp_to_q_variant(args[cast_index].object());
     argument_info[next_cast_index].type_name = "QVariant";
     argument_info[next_cast_index].void_argument = &qvar;
     CAST_INDEX_SWITCH(QVariant)
     }
     break;
    case KCM_Command_Runtime_Router::QOB_Argument_Conventions::Opaque_pVoid:
    {
     argument_info[next_cast_index].void_argument = args[cast_index].get_proper_void_ptr();
     //get_proper_void_ptr();
     argument_info[next_cast_index].type_name = "void*";

     Kauvir_Lisp_Callback* klc = static_cast<Kauvir_Lisp_Callback*>( argument_info[next_cast_index].void_argument );

     CAST_INDEX_SWITCH(void*)
     }
     break;
    case KCM_Command_Runtime_Router::QOB_Argument_Conventions::QObject_Cast:
    {
     CAST_INDEX_SWITCH(QObject*)
       break;
    }
#endif
    }
   }
  }
 };

#define CAST_READY_MACRO(ARG_COUNT) \
 struct Cast_##ARG_COUNT##_Ready \
 { \
  template<typename OBJECT_Type  TYPENAMES_typename> \
  static void run(QString method_name, OBJECT_Type obj, QVector<KCM_Command_Runtime_Argument*>& args \
   TYPENAMES_arg,  const QVector<KCM_Command_Runtime_Router::Argument_Info>& argument_info) \
  { \
   QMetaObject::invokeMethod(obj, method_name.toLatin1() \
    QARGUMENTS ); \
  } \
  template<typename OBJECT_Type, typename RET_Type  TYPENAMES_typename> \
  static void run(QString method_name, OBJECT_Type obj, QString return_type, \
   RET_Type& ret, QVector<KCM_Command_Runtime_Argument*>& args \
   TYPENAMES_arg,  const QVector<KCM_Command_Runtime_Router::Argument_Info>& argument_info) \
  { \
   QMetaObject::invokeMethod(obj, method_name.toLatin1(), \
    QReturnArgument<RET_Type>(return_type.toLatin1(), ret) \
    QARGUMENTS  ); \
  } \
 }; \

#define CAST_STRUCT_START_MACRO(ARG_COUNT) \
 struct Cast_##ARG_COUNT \
 { \

#define CAST_STRUCT_RUN_MACRO(ARG_COUNT) \
  static constexpr int ready_at_cast_index = ARG_COUNT; \
  template<typename OBJECT_Type, typename Type_List_Type> \
  static void run(QString method_name, OBJECT_Type obj, \
    int cast_index, KCM_Command_Runtime_Router& kcrr, \
    QVector<KCM_Command_Runtime_Router::Argument_Info>& argument_info, \
    QVector<KCM_Command_Runtime_Argument*>& args) \
  { \

#define CAST_READY_SWITCH_MACRO(ARG_COUNT) \
   switch(kcrr.return_type_code()) \
   { \
   case KCM_Command_Runtime_Router::Arg_Type_Codes::No_Return: \
    { \
     ARGS_TEMP_MACROS \
     Cast_##ARG_COUNT##_Ready::run(method_name, obj, args  ARGUMENTS, argument_info); \
    } \
    break; \
   case KCM_Command_Runtime_Router::Arg_Type_Codes::Void_Pointer: \
    { \
     ARGS_TEMP_MACROS \
     Cast_##ARG_COUNT##_Ready::run(method_name, obj, \
       kcrr.return_type_name_strip_namespace(), \
       kcrr.raw_result_ref(), \
       args  ARGUMENTS, argument_info); \
     } \
    break; \
   case KCM_Command_Runtime_Router::Arg_Type_Codes::Int: \
    { \
     int& x = *reinterpret_cast<int*>(kcrr.raw_result_ref()); \
     ARGS_TEMP_MACROS \
     Cast_##ARG_COUNT##_Ready::run(method_name, obj, \
      "int", x, args  ARGUMENTS, argument_info); \
    } \
    break; \
   case KCM_Command_Runtime_Router::Arg_Type_Codes::QString_Return: \
    { \
     QString& qs = kcrr.string_result(); \
     ARGS_TEMP_MACROS \
     Cast_##ARG_COUNT##_Ready::run(method_name, obj, \
      "QString", qs, args  ARGUMENTS, argument_info); \
    } \
    break; \
   } \


#define CAST_SWITCH_MACRO(ARG_COUNT) \
   else \
   { \
    int next_cast_index = cast_index + 1; \
    KCM_Command_Runtime_Router::QOB_Argument_Conventions ac = \
      argument_info[next_cast_index].qob_convention; \
    switch(ac) \
    { \
    case KCM_Command_Runtime_Router::QOB_Argument_Conventions::QString_Direct: \
    case KCM_Command_Runtime_Router::QOB_Argument_Conventions::Value_From_QString: \
     { \
      CAST_INDEX_SWITCH(quint64) \
     } \
     break; \
    } \
   } \

#define CASE_TEMP_MACRO(INDEX, INTERCHANGE_TYPE) \
   CASE_TEMP_MACRO_(INDEX, 2, INTERCHANGE_TYPE)



#define CAST_STRUCT_END_MACRO } };



#define TEMP_MACRO(ARG_COUNT) \
 CAST_READY_MACRO(ARG_COUNT) \
 CAST_STRUCT_START_MACRO(ARG_COUNT) \
 CAST_STRUCT_RUN_MACRO(ARG_COUNT) \
 if(cast_index == ready_at_cast_index) \
 { \
  CAST_READY_SWITCH_MACRO(ARG_COUNT) \
 } \
 CAST_SWITCH_MACRO(ARG_COUNT) \
 CAST_STRUCT_END_MACRO



//#define TEMP__TEMP_MACRO(ARG_COUNT) \
// CAST_READY_MACRO(ARG_COUNT) \
// CAST_STRUCT_START_MACRO(ARG_COUNT) \
// CAST_STRUCT_RUN_MACRO(ARG_COUNT) \
// if(cast_index == ready_at_cast_index) \
// { \
//  CAST_READY_SWITCH_MACRO(ARG_COUNT) \
// } \
// else \
// { \
//  int next_cast_index = cast_index + 1; \
//  KCM_Command_Runtime_Router::QOB_Argument_Conventions ac = \
//    argument_info[next_cast_index].qob_convention; \
//  switch(ac) \
//  { \
//  case KCM_Command_Runtime_Router::QOB_Argument_Conventions::QString_Direct: \
//  case KCM_Command_Runtime_Router::QOB_Argument_Conventions::Value_From_QString: \
//   { \
//    CAST_INDEX_SWITCH(quint32) \
//   } \
//   break; \
//  } \
// } \
// CAST_STRUCT_END_MACRO


// special case for ARG_COUNT = 0

#define TEMP_MACRO_0 \
 CAST_READY_MACRO(0) \
 CAST_STRUCT_START_MACRO(0) \
 CAST_STRUCT_RUN_MACRO(0) \
 \
  CAST_READY_SWITCH_MACRO(0) \
 \
 \
 CAST_STRUCT_END_MACRO

 // for arg count 0
 #define TYPENAMES_typename
 #define TYPENAMES_arg
 #define QARGUMENTS
 #define ARGUMENTS
 #define ARGS_TEMP_MACROS

TEMP_MACRO_0

  #undef TYPENAMES_typename
  #undef TYPENAMES_arg
  #undef ARGS_TEMP_MACROS
  #undef CASE_TEMP_MACROS
  #undef ARGUMENTS
  #undef QARGUMENTS

 // end arg count 0

 // for arg count 1

 #define TYPENAMES_typename ,typename ARG1_Type
 #define TYPENAMES_arg ,ARG1_Type arg1
 #define QARGUMENTS  \
  ,QARG_TEMP_MACRO(1) \

 #define ARGUMENTS   ,arg1

 #define CASE_TEMP_MACRO(INDEX, INTERCHANGE_TYPE) \
    CASE_TEMP_MACRO_(INDEX, 1, INTERCHANGE_TYPE)

 #define CAST_INDEX_SWITCH(TYPE) \
    switch(cast_index) \
    { \
     CASE_TEMP_MACRO(0, TYPE) \
    } \


 #define ARGS_TEMP_MACROS \
  ARGS_TEMP_MACRO(1) \

  TEMP_MACRO(1)

  #undef TYPENAMES_typename
  #undef TYPENAMES_arg
  #undef ARGS_TEMP_MACROS
  #undef CASE_TEMP_MACROS
  #undef ARGUMENTS
  #undef QARGUMENTS

 // end arg count 1


  // for arg count 2

  #define TYPENAMES_typename ,typename ARG1_Type ,typename ARG2_Type
  #define TYPENAMES_arg ,ARG1_Type arg1 ,ARG2_Type arg2
  #define QARGUMENTS  \
   ,QARG_TEMP_MACRO(1) \
   ,QARG_TEMP_MACRO(2) \

  #define ARGUMENTS   ,arg1 ,arg2

  #define CASE_TEMP_MACRO(INDEX, INTERCHANGE_TYPE) \
     CASE_TEMP_MACRO_(INDEX, 2, INTERCHANGE_TYPE)

  #define CAST_INDEX_SWITCH(TYPE) \
     switch(cast_index) \
     { \
      CASE_TEMP_MACRO(0, TYPE) \
      CASE_TEMP_MACRO(1, TYPE) \
     } \


  #define ARGS_TEMP_MACROS \
   ARGS_TEMP_MACRO(1) \
   ARGS_TEMP_MACRO(2) \

//?TEMP_MACRO(2)
//  #define ARG_COUNT 2

//  CAST_READY_MACRO(ARG_COUNT)
//  CAST_STRUCT_START_MACRO(ARG_COUNT)
//  CAST_STRUCT_RUN_MACRO(ARG_COUNT)
//  if(cast_index == ready_at_cast_index)
//  {
//   CAST_READY_SWITCH_MACRO(ARG_COUNT)
//  }
//  CAST_SWITCH_MACRO(ARG_COUNT)
//  CAST_STRUCT_END_MACRO


   #undef TYPENAMES_typename
   #undef TYPENAMES_arg
   #undef ARGS_TEMP_MACROS
   #undef CASE_TEMP_MACROS
   #undef ARGUMENTS
   #undef QARGUMENTS

  // end arg count 2



};

template<int i>
struct Do_Invoke_Method__Cast_Schedule__QOB__Cast_
{
 //typedef Argument_
};

#define TEMP_MACRO(i) \
template<> \
struct Do_Invoke_Method__Cast_Schedule__QOB__Cast_<i> \
{ \
 typedef typename Do_Invoke_Method__Cast_Schedule__QOB::Cast_##i Type; \
}; \


//?
//

TEMP_MACRO(0)
TEMP_MACRO(1)
TEMP_MACRO(2)


#ifdef HIDE
#include <QtGlobal>

#include <QDebug>

#include <functional>


#include "kans.h"
#include "accessors.h"

//#include "kauvir-lisp-argument.h"
//#include "kauvir-type-system/kauvir-universal-class.h"
//#include "kauvir-runtime-router-cast-schedule.h"
//#include "kauvir-lisp-each/kauvir-lisp-callback.h"
//#include "kauvir-runtime-router.h"



KANS_(KCM)



#define CASE_TEMP_MACRO_(INDEX, READY, INTERCHANGE_TYPE) \
 case INDEX: \
  Cast_##READY::run<OBJECT_Type, \
    typename Interchange<Type_List_Type, INDEX, READY>:: \
    template With_Type<INTERCHANGE_TYPE>::Result_Type>  \
    (method_name, obj, next_cast_index, kcrr,  \
    argument_info, args);  \
  break;  \

//?
//#define RETURN_ARG_TEMP_MACRO(INDEX) \
// typename Type_List_Type::Type##INDEX& arg##INDEX \
//   = *reinterpret_cast<typename Type_List_Type::Type##INDEX*> \
//    ( argument_info[INDEX].void_argument );

#define ARGS_TEMP_MACRO(INDEX) \
 typename Type_List_Type::Type##INDEX& arg##INDEX \
   = *reinterpret_cast<typename Type_List_Type::Type##INDEX*> \
    ( argument_info[INDEX].void_argument );


// //! args[INDEX - 1]

#define QARG_TEMP_MACRO(INDEX) QArgument<ARG##INDEX##_Type> \
  ( argument_info[INDEX].type_name_with_modifier(args[INDEX - 1].qob_reflection_modifier(), args[INDEX - 1].qob_reflection_type_name()).toLatin1(), arg##INDEX) \




//template<KCM_Command_Runtime_Router::Return_Conventions RC>
struct Do_Invoke_Method__Cast_Schedule__QOB
{
// struct Cast_1_Ready
// {
//  template<typename OBJECT_Type>
//  static void run(QString method_name, OBJECT_Type obj,
//   KCM_Command_Runtime_Router::Argument_Conventions ac,
//   KCM_Command_Runtime_Argument& arg1, QVector<KCM_Command_Runtime_Argument>& args)
//  {
//   switch(ac)
//   {
//   case KCM_Command_Runtime_Router::Argument_Conventions::QString_Direct:
//    QMetaObject::invokeMethod(obj, method_name.toLatin1(),
//      Q_ARG(QString ,arg1.str) );
//   }
//  }
// };

// cast 2


#define CASE_TEMP_MACRO(INDEX, INTERCHANGE_TYPE) \
   CASE_TEMP_MACRO_(INDEX, 2, INTERCHANGE_TYPE)

#define CAST_INDEX_SWITCH(TYPE) \
   switch(cast_index) \
   { \
    CASE_TEMP_MACRO(0, TYPE) \
    CASE_TEMP_MACRO(1, TYPE) \
   } \

 struct Argument_Size_Too_Large{};

// template<int i>
// struct Cast_
// {
//  typedef Argument_Size_Too_Large Type;
// };

// #define CAST_TYPEDEF_MACRO(i)
//  template<> \
//  struct Cast_<1> \
//  { \
//   typedef Cast_1 Type; \
//  }; \



 struct Cast_2
 {
  static constexpr int ready_at_cast_index = 2;
  template<typename OBJECT_Type, typename Type_List_Type>
  static void run(QString method_name, OBJECT_Type obj,
    int cast_index, KCM_Command_Runtime_Router& kcrr,
    QVector<KCM_Command_Runtime_Router::Argument_Info>& argument_info,
    QVector<KCM_Command_Runtime_Argument>& args)
  {
   if(cast_index == ready_at_cast_index)
   {
    switch(kcrr.return_type_code())
    {
    case KCM_Command_Runtime_Router::Arg_Type_Codes::No_Return:
     {
      ARGS_TEMP_MACRO(1)
      ARGS_TEMP_MACRO(2)
      Cast_2_Ready::run(method_name, obj,
       args, arg1, arg2, argument_info);
     }
     break;
    case KCM_Command_Runtime_Router::Arg_Type_Codes::Void_Pointer:
     {
      ARGS_TEMP_MACRO(1)
      ARGS_TEMP_MACRO(2)
      Cast_2_Ready::run(method_name, obj,
        kcrr.return_type_name_strip_namespace(),
        kcrr.raw_result(),
        args, arg1, arg2, argument_info);
     }
     break;
    case KCM_Command_Runtime_Router::Arg_Type_Codes::Int:
     {
      int& x = *reinterpret_cast<int*>(kcrr.raw_result());
      ARGS_TEMP_MACRO(1)
      ARGS_TEMP_MACRO(2)
      Cast_2_Ready::run(method_name, obj,
        "int",
        x,
        args, arg1, arg2, argument_info);
     }
     break;
    case KCM_Command_Runtime_Router::Arg_Type_Codes::QString_Return:
     {
      QString& qs = kcrr.string_result();
      ARGS_TEMP_MACRO(1)
      ARGS_TEMP_MACRO(2)
      Cast_2_Ready::run(method_name, obj,
       "QString", qs, args, arg1, arg2, argument_info);
     }
     break;
    }
   }
   else
   {
    int next_cast_index = cast_index + 1;
    KCM_Command_Runtime_Router::QOB_Argument_Conventions ac =
      argument_info[next_cast_index].qob_convention;
    switch(ac)
    {
    case KCM_Command_Runtime_Router::QOB_Argument_Conventions::QString_Direct:
     {
      // //! args[cast_index]
      QString arg = args[cast_index].str();
      argument_info[next_cast_index].void_argument = &arg;
      argument_info[next_cast_index].type_name = "QString";
      CAST_INDEX_SWITCH(QString)
     }
     break;
    case KCM_Command_Runtime_Router::QOB_Argument_Conventions::QMetaType_Confirmed:
     {
      const QMetaType* qmt = argument_info[next_cast_index].q_meta_type;
      int id = argument_info[next_cast_index].q_meta_type_id;
      QString type_name = QString::fromLatin1(QMetaType::typeName(id));
       //void* pv = qmt->create();
      void* pv = QMetaType::create(id);
       // //!: note args[cast_index] ...
      KCM_Command_Runtime_Router::Arg_Type_Codes atc = KCM_Command_Runtime_Router::lisp_to_q_meta_type(args[cast_index].object(), pv);
      argument_info[next_cast_index].type_name = type_name;
      argument_info[next_cast_index].void_argument = pv;
      argument_info[next_cast_index].void_argument_for_delete = pv;
      switch(atc)
      {
      case KCM_Command_Runtime_Router::Arg_Type_Codes::Int:
       CAST_INDEX_SWITCH(int)
       break;
      }
     }
     break;
    case KCM_Command_Runtime_Router::QOB_Argument_Conventions::QVariant_Cast:
     {
      QVariant qvar = KCM_Command_Runtime_Router::lisp_to_q_variant(args[cast_index].object());
      argument_info[next_cast_index].type_name = "QVariant";
      argument_info[next_cast_index].void_argument = &qvar;
      CAST_INDEX_SWITCH(QVariant)
     }
     break;
    case KCM_Command_Runtime_Router::QOB_Argument_Conventions::Opaque_pVoid:
     {
      argument_info[next_cast_index].void_argument = args[cast_index].get_proper_void_ptr();
        //get_proper_void_ptr();
      argument_info[next_cast_index].type_name = "void*";

      Kauvir_Lisp_Callback* klc = static_cast<Kauvir_Lisp_Callback*>( argument_info[next_cast_index].void_argument );

      CAST_INDEX_SWITCH(void*)
     }
     break;
    case KCM_Command_Runtime_Router::QOB_Argument_Conventions::QObject_Cast:
     {
      CAST_INDEX_SWITCH(QObject*)
      break;
     }
    }
   }
  }
 };

 struct Cast_2_Ready
 {
  template<typename OBJECT_Type, typename ARG1_Type, typename ARG2_Type>
  static void run(QString method_name, OBJECT_Type obj, QVector<KCM_Command_Runtime_Argument>& args,
    ARG1_Type& arg1, ARG2_Type& arg2,
    const QVector<KCM_Command_Runtime_Router::Argument_Info>& argument_info)
  {
   QMetaObject::invokeMethod(obj, method_name.toLatin1(),
     QArgument<ARG1_Type>(argument_info[1].type_name_with_modifier(args[0].qob_reflection_modifier(), args[0].qob_reflection_type_name()).toLatin1(), arg1),
     QArgument<ARG2_Type>(argument_info[2].type_name_with_modifier(args[1].qob_reflection_modifier(), args[1].qob_reflection_type_name()).toLatin1(), arg2));
  }

  template<typename OBJECT_Type, typename RET_Type, typename ARG1_Type, typename ARG2_Type>
  static void run(QString method_name, OBJECT_Type obj,
    QString return_type, RET_Type& ret,
    QVector<KCM_Command_Runtime_Argument>& args,
    ARG1_Type& arg1, ARG2_Type& arg2,
    const QVector<KCM_Command_Runtime_Router::Argument_Info>& argument_info)
  {
   QMetaObject::invokeMethod(obj, method_name.toLatin1(),
     QReturnArgument<RET_Type>(return_type.toLatin1(), ret),
     QArgument<ARG1_Type>(argument_info[1].type_name_with_modifier(args[0].qob_reflection_modifier(), args[0].qob_reflection_type_name()).toLatin1(), arg1),
     QArgument<ARG2_Type>(argument_info[2].type_name_with_modifier(args[1].qob_reflection_modifier(), args[1].qob_reflection_type_name()).toLatin1(), arg2));
   qDebug() << "RET: " << ret;
  }
 };
//};

 //CAST_TYPEDEF_MACRO(2)


#define CAST_READY_MACRO(ARG_COUNT) \
 struct Cast_##ARG_COUNT##_Ready \
 { \
  template<typename OBJECT_Type  TYPENAMES_typename> \
  static void run(QString method_name, OBJECT_Type obj, QVector<KCM_Command_Runtime_Argument>& args \
   TYPENAMES_arg,  const QVector<KCM_Command_Runtime_Router::Argument_Info>& argument_info) \
  { \
   QMetaObject::invokeMethod(obj, method_name.toLatin1() \
    QARGUMENTS ); \
  } \
  template<typename OBJECT_Type, typename RET_Type  TYPENAMES_typename> \
  static void run(QString method_name, OBJECT_Type obj, QString return_type, \
   RET_Type& ret, QVector<KCM_Command_Runtime_Argument>& args \
   TYPENAMES_arg,  const QVector<KCM_Command_Runtime_Router::Argument_Info>& argument_info) \
  { \
   QMetaObject::invokeMethod(obj, method_name.toLatin1(), \
    QReturnArgument<RET_Type>(return_type.toLatin1(), ret) \
    QARGUMENTS  ); \
  } \
 }; \


#define CAST_STRUCT_START_MACRO(ARG_COUNT) \
 struct Cast_##ARG_COUNT \
 { \

#define CAST_STRUCT_RUN_MACRO(ARG_COUNT) \
  static constexpr int ready_at_cast_index = ARG_COUNT; \
  template<typename OBJECT_Type, typename Type_List_Type> \
  static void run(QString method_name, OBJECT_Type obj, \
    int cast_index, KCM_Command_Runtime_Router& kcrr, \
    QVector<KCM_Command_Runtime_Router::Argument_Info>& argument_info, \
    QVector<KCM_Command_Runtime_Argument>& args) \
  { \



#define CAST_READY_SWITCH_MACRO(ARG_COUNT) \
   switch(kcrr.return_type_code()) \
   { \
   case KCM_Command_Runtime_Router::Arg_Type_Codes::No_Return: \
    { \
     ARGS_TEMP_MACROS \
     Cast_##ARG_COUNT##_Ready::run(method_name, obj, args  ARGUMENTS, argument_info); \
    } \
    break; \
   case KCM_Command_Runtime_Router::Arg_Type_Codes::Void_Pointer: \
    { \
     ARGS_TEMP_MACROS \
     Cast_##ARG_COUNT##_Ready::run(method_name, obj, \
       kcrr.return_type_name_strip_namespace(), \
       kcrr.raw_result(), \
       args  ARGUMENTS, argument_info); \
     } \
    break; \
   case KCM_Command_Runtime_Router::Arg_Type_Codes::Int: \
    { \
     int& x = *reinterpret_cast<int*>(kcrr.raw_result()); \
     ARGS_TEMP_MACROS \
     Cast_##ARG_COUNT##_Ready::run(method_name, obj, \
      "int", x, args  ARGUMENTS, argument_info); \
    } \
    break; \
   case KCM_Command_Runtime_Router::Arg_Type_Codes::QString_Return: \
    { \
     QString& qs = kcrr.string_result(); \
     ARGS_TEMP_MACROS \
     Cast_##ARG_COUNT##_Ready::run(method_name, obj, \
      "QString", qs, args  ARGUMENTS, argument_info); \
    } \
    break; \
   } \


#define CAST_SWITCH_MACRO(ARG_COUNT) \
   else \
   { \
    int next_cast_index = cast_index + 1; \
    KCM_Command_Runtime_Router::QOB_Argument_Conventions ac = \
      argument_info[next_cast_index].qob_convention; \
    switch(ac) \
    { \
    case KCM_Command_Runtime_Router::QOB_Argument_Conventions::QString_Direct: \
     { \
      QString arg = args[cast_index].str(); \
      argument_info[next_cast_index].void_argument = &arg; \
      argument_info[next_cast_index].type_name = "QString"; \
      CAST_INDEX_SWITCH(QString) \
     } \
     break; \
    case KCM_Command_Runtime_Router::QOB_Argument_Conventions::QMetaType_Confirmed: \
     { \
      const QMetaType* qmt = argument_info[next_cast_index].q_meta_type; \
      int id = argument_info[next_cast_index].q_meta_type_id; \
      QString type_name = QString::fromLatin1(QMetaType::typeName(id)); \
      void* pv = qmt->create(); \
      KCM_Command_Runtime_Router::Arg_Type_Codes atc = \
      KCM_Command_Runtime_Router::lisp_to_q_meta_type(args[cast_index].object(), pv); \
      argument_info[next_cast_index].type_name = type_name; \
      argument_info[next_cast_index].void_argument = pv; \
      argument_info[next_cast_index].void_argument_for_delete = pv; \
      switch(atc) \
      { \
      case KCM_Command_Runtime_Router::Arg_Type_Codes::Int: \
       CAST_INDEX_SWITCH(int) \
       break; \
      } \
     } \
     break; \
    case KCM_Command_Runtime_Router::QOB_Argument_Conventions::QVariant_Cast: \
     { \
      QVariant qvar = KCM_Command_Runtime_Router::lisp_to_q_variant(args[cast_index].object()); \
      argument_info[next_cast_index].type_name = "QVariant"; \
      argument_info[next_cast_index].void_argument = &qvar; \
      CAST_INDEX_SWITCH(QVariant) \
     } \
     break; \
    case KCM_Command_Runtime_Router::QOB_Argument_Conventions::Opaque_pVoid: \
     { \
      argument_info[next_cast_index].void_argument = args[cast_index].get_proper_void_ptr(); \
      argument_info[next_cast_index].type_name = "void*"; \
      CAST_INDEX_SWITCH(void*) \
     } \
     break; \
    case KCM_Command_Runtime_Router::QOB_Argument_Conventions::QObject_Cast: \
     { \
      CAST_INDEX_SWITCH(QObject*) \
     } \
    } \
   }\



#define CAST_STRUCT_END_MACRO } };



#define TEMP_MACRO(ARG_COUNT) \
 CAST_READY_MACRO(ARG_COUNT) \
 CAST_STRUCT_START_MACRO(ARG_COUNT) \
 CAST_STRUCT_RUN_MACRO(ARG_COUNT) \
 if(cast_index == ready_at_cast_index) \
 { \
  CAST_READY_SWITCH_MACRO(ARG_COUNT) \
 } \
 CAST_SWITCH_MACRO(ARG_COUNT) \
 CAST_STRUCT_END_MACRO


// special case for ARG_COUNT = 0

#define TEMP_MACRO_0 \
 CAST_READY_MACRO(0) \
 CAST_STRUCT_START_MACRO(0) \
 CAST_STRUCT_RUN_MACRO(0) \
 \
  CAST_READY_SWITCH_MACRO(0) \
 \
 \
 CAST_STRUCT_END_MACRO









 // for arg count 0

 #define TYPENAMES_typename
 #define TYPENAMES_arg
 #define QARGUMENTS

 #define ARGUMENTS

 #define ARGS_TEMP_MACROS

// struct Cast_0
// {

TEMP_MACRO_0


#ifdef HIDE
 // CAST_READY_MACRO(0)
 struct Cast_0_Ready
 {
  template<typename OBJECT_Type  TYPENAMES_typename>
    static void run(QString method_name, OBJECT_Type obj, QVector<KCM_Command_Runtime_Argument>& args,
      TYPENAMES_arg  const QVector<KCM_Command_Runtime_Router::Argument_Info>& argument_info)
  {
   QMetaObject::invokeMethod(obj, method_name.toLatin1()
       QARGUMENTS  );
  }

// CAST_STRUCT_START_MACRO(0)

  template<typename OBJECT_Type, typename RET_Type  TYPENAMES_typename>
  static void run(QString method_name, OBJECT_Type obj, QString return_type,
    RET_Type& ret, QVector<KCM_Command_Runtime_Argument>& args
    TYPENAMES_arg,  const QVector<KCM_Command_Runtime_Router::Argument_Info>& argument_info)
  {
   QMetaObject::invokeMethod(obj, method_name.toLatin1(),
        QReturnArgument<RET_Type>(return_type.toLatin1(), ret)
        QARGUMENTS );
  }
 };

 struct Cast_0
 {
  static constexpr int ready_at_cast_index = 0;
  template<typename OBJECT_Type, typename Type_List_Type>
  static void run(QString method_name, OBJECT_Type obj,
    int cast_index, KCM_Command_Runtime_Router& kcrr,
    QVector<KCM_Command_Runtime_Router::Argument_Info>& argument_info,
    QVector<KCM_Command_Runtime_Argument>& args)
  {

// CAST_READY_SWITCH_MACRO(0)
   switch(kcrr.return_type_code())
   {
   case KCM_Command_Runtime_Router::Arg_Type_Codes::No_Return:
    {
     ARGS_TEMP_MACROS
     Cast_0_Ready::run(method_name, obj, args  ARGUMENTS,  argument_info);
    }
    break;
   case KCM_Command_Runtime_Router::Arg_Type_Codes::Void_Pointer:
    {
     ARGS_TEMP_MACROS
     Cast_0_Ready::run(method_name, obj,
       kcrr.return_type_name_strip_namespace(),
       kcrr.raw_result(),
       args  ARGUMENTS, argument_info);
    }
    break;
   case KCM_Command_Runtime_Router::Arg_Type_Codes::Int:
    {
     int& x = *reinterpret_cast<int*>(kcrr.raw_result());
     ARGS_TEMP_MACROS
     Cast_0_Ready::run(method_name, obj,
      "int", x, args  ARGUMENTS, argument_info);
    }
    break;
   case KCM_Command_Runtime_Router::Arg_Type_Codes::QString_Return:
    {
     QString& qs = kcrr.string_result();
     ARGS_TEMP_MACROS
     Cast_0_Ready::run(method_name, obj,
      "QString", qs, args  ARGUMENTS, argument_info);
    }
    break;
   }
// CAST_STRUCT_END_MACRO
  }};


#endif
 #undef TYPENAMES_typename
 #undef TYPENAMES_arg
 #undef ARGS_TEMP_MACROS
 #undef CASE_TEMP_MACROS
 #undef ARGUMENTS
 #undef QARGUMENTS

 // end arg count 0







// for arg count 1

#define TYPENAMES_typename ,typename ARG1_Type
#define TYPENAMES_arg ,ARG1_Type arg1
#define QARGUMENTS  \
 ,QARG_TEMP_MACRO(1) \

#define ARGUMENTS   ,arg1

#define CASE_TEMP_MACRO(INDEX, INTERCHANGE_TYPE) \
   CASE_TEMP_MACRO_(INDEX, 1, INTERCHANGE_TYPE)

#define CAST_INDEX_SWITCH(TYPE) \
   switch(cast_index) \
   { \
    CASE_TEMP_MACRO(0, TYPE) \
   } \


#define ARGS_TEMP_MACROS \
 ARGS_TEMP_MACRO(1) \

//?
 TEMP_MACRO(1)

// CAST_READY_MACRO(1)
//  #ifdef HIDE
//   struct Cast_1_Ready
//   {
//    template<typename OBJECT_Type  TYPENAMES_typename>
//    static void run(QString method_name, OBJECT_Type obj, QVector<KCM_Command_Runtime_Argument>& args
//     TYPENAMES_arg,  const QVector<KCM_Command_Runtime_Router::Argument_Info>& argument_info)
//    {
//     QMetaObject::invokeMethod(obj, method_name.toLatin1()

//         ,QArgument<ARG1_Type>
//         ( argument_info[1].type_name_with_modifier(args[0].qob_reflection_modifier()).toLatin1(), arg1)


//      //?QARGUMENTS
//       );
//    }
//    template<typename OBJECT_Type, typename RET_Type  TYPENAMES_typename>
//    static void run(QString method_name, OBJECT_Type obj, QString return_type,
//     RET_Type& ret, QVector<KCM_Command_Runtime_Argument>& args
//     TYPENAMES_arg,  const QVector<KCM_Command_Runtime_Router::Argument_Info>& argument_info)
//    {
//     QMetaObject::invokeMethod(obj, method_name.toLatin1(),
//      QReturnArgument<RET_Type>(return_type.toLatin1(), ret)
//      QARGUMENTS  );
//    }
//   };
//  #endif
// CAST_STRUCT_START_MACRO(1)
// CAST_STRUCT_RUN_MACRO(1)
// if(cast_index == ready_at_cast_index)
// {
//  //?
//  CAST_READY_SWITCH_MACRO(1)
//   #ifdef HIDE
//  switch(kcrr.return_type_code())
//  {
//  case KCM_Command_Runtime_Router::Arg_Type_Codes::No_Return:
//   {
//    ARGS_TEMP_MACROS
//    Cast_1_Ready::run(method_name, obj, args  ARGUMENTS, argument_info);
//   }
//   break;
//  case KCM_Command_Runtime_Router::Arg_Type_Codes::Void_Pointer:
//   {
//    ARGS_TEMP_MACROS
//    Cast_1_Ready::run(method_name, obj,
//      kcrr.return_type_name_strip_namespace(),
//      kcrr.raw_result(),
//      args  ARGUMENTS, argument_info);
//    }
//   break;
//  case KCM_Command_Runtime_Router::Arg_Type_Codes::Int:
//   {
//    int& x = *reinterpret_cast<int*>(kcrr.raw_result());
//    ARGS_TEMP_MACROS
//    Cast_1_Ready::run(method_name, obj,
//     "int", x, args  ARGUMENTS, argument_info);
//   }
//   break;
//  case KCM_Command_Runtime_Router::Arg_Type_Codes::QString_Return:
//   {
//    QString& qs = kcrr.string_result();
//    ARGS_TEMP_MACROS
//    Cast_1_Ready::run(method_name, obj,
//     "QString", qs, args  ARGUMENTS, argument_info);
//   }
//   break;
//  }
//   #endif //def HIDE
// }
// //?
// CAST_SWITCH_MACRO(1)
//  #ifdef HIDE
// else
// {
//  int next_cast_index = cast_index + 1;
//  KCM_Command_Runtime_Router::QOB_Argument_Conventions ac =
//    argument_info[next_cast_index].qob_convention;
//  switch(ac)
//  {
//  case KCM_Command_Runtime_Router::QOB_Argument_Conventions::QString_Direct:
//   {
//    QString arg = args[cast_index].str();
//    argument_info[next_cast_index].void_argument = &arg;
//    argument_info[next_cast_index].type_name = "QString";
//    CAST_INDEX_SWITCH(QString)
//   }
//   break;
//  case KCM_Command_Runtime_Router::QOB_Argument_Conventions::QMetaType_Confirmed:
//   {
//    const QMetaType* qmt = argument_info[next_cast_index].q_meta_type;
//    int id = argument_info[next_cast_index].q_meta_type_id;
//    QString type_name = QString::fromLatin1(QMetaType::typeName(id));
//    void* pv = qmt->create();
//    KCM_Command_Runtime_Router::Arg_Type_Codes atc =
//      KCM_Command_Runtime_Router::lisp_to_q_meta_type(args[cast_index].object(), pv);
//    argument_info[next_cast_index].type_name = type_name;
//    argument_info[next_cast_index].void_argument = pv;
//    argument_info[next_cast_index].void_argument_for_delete = pv;
//    switch(atc)
//    {
//    case KCM_Command_Runtime_Router::Arg_Type_Codes::Int:
//     CAST_INDEX_SWITCH(int)
//     break;
//    }
//   }
//   break;
//  case KCM_Command_Runtime_Router::QOB_Argument_Conventions::QVariant_Cast:
//   {
//    QVariant qvar = KCM_Command_Runtime_Router::lisp_to_q_variant(args[cast_index].object());
//    argument_info[next_cast_index].type_name = "QVariant";
//    argument_info[next_cast_index].void_argument = &qvar;
//    CAST_INDEX_SWITCH(QVariant)
//   }
//   break;
//  case KCM_Command_Runtime_Router::QOB_Argument_Conventions::QObject_Cast:
//   {
//    CAST_INDEX_SWITCH(QObject*)
//   }
//  }
// }
//#endif
// CAST_STRUCT_END_MACRO
////?#undef ARG_COUNT


#undef ARGS_TEMP_MACROS
#undef CASE_TEMP_MACROS
#undef ARGUMENTS
#undef QARGUMENTS

// end arg count 1



//CAST_TYPEDEF_MACRO(1)




//#define CASE_TEMP_MACRO(INDEX) CASE_TEMP_MACRO_(INDEX, 3)

#define TYPENAMES_typename ,typename ARG1_Type, typename ARG2_Type, typename ARG3_Type
#define TYPENAMES_arg ,ARG1_Type arg1, ARG2_Type arg2, ARG3_Type arg3
#define QARGUMENTS  \
 ,QARG_TEMP_MACRO(1), \
 QARG_TEMP_MACRO(2), \
 QARG_TEMP_MACRO(3) \

#define ARGUMENTS   ,arg1, arg2, arg3

#define CASE_TEMP_MACRO(INDEX, INTERCHANGE_TYPE) \
   CASE_TEMP_MACRO_(INDEX, 3, INTERCHANGE_TYPE)

#define CAST_INDEX_SWITCH(TYPE) \
   switch(cast_index) \
   { \
    CASE_TEMP_MACRO(0, TYPE) \
    CASE_TEMP_MACRO(1, TYPE) \
    CASE_TEMP_MACRO(2, TYPE) \
   } \


//#define CASE_TEMP_MACROS \
// CASE_TEMP_MACRO(0) \
// CASE_TEMP_MACRO(1) \
// CASE_TEMP_MACRO(2) \


#define ARGS_TEMP_MACROS \
 ARGS_TEMP_MACRO(1) \
 ARGS_TEMP_MACRO(2) \
 ARGS_TEMP_MACRO(3) \

 //?
TEMP_MACRO(3)


#ifdef HIDE
 struct Cast_3_Ready
 {
  template<typename OBJECT_Type, TYPENAMES_typename>
  static void run(QString method_name, OBJECT_Type obj,
   TYPENAMES_arg, const QVector<KCM_Command_Runtime_Router::Argument_Info>& argument_info)
  {
   QMetaObject::invokeMethod(obj, method_name.toLatin1(),
    QARGUMENTS );
  }
 };

 struct Cast_3
 {
  static constexpr int ready_at_cast_index = 3;
  template<typename OBJECT_Type, typename Type_List_Type>
  static void run(QString method_name, OBJECT_Type obj,
    int cast_index,
    QVector<KCM_Command_Runtime_Router::Argument_Info>& argument_info,
    QVector<KCM_Command_Runtime_Argument>& args)
  {
   if(cast_index == ready_at_cast_index)
   {
    ARGS_TEMP_MACROS
    Cast_3_Ready::run(method_name, obj, ARGUMENTS, argument_info);
   }
   else
   {
    int next_cast_index = cast_index + 1;
    KCM_Command_Runtime_Router::Argument_Conventions ac =
      argument_info[next_cast_index].convention;
    switch(ac)
    {
    case KCM_Command_Runtime_Router::Argument_Conventions::QString_Direct:
     {
      QString arg = args[next_cast_index].str;
      argument_info[next_cast_index].void_argument = &arg;
      argument_info[next_cast_index].type_name = "QString";
      CAST_INDEX_SWITCH(QString)
     }
     break;
    case KCM_Command_Runtime_Router::Argument_Conventions::QMetaType_Confirmed:
     {
      const QMetaType* qmt = argument_info[next_cast_index].q_meta_type;
      int id = argument_info[next_cast_index].q_meta_type_id;
      QString type_name = QString::fromLatin1(QMetaType::typeName(id));
      void* pv = qmt->create();
      KCM_Command_Runtime_Router::Arg_Type_Codes atc =
        KCM_Command_Runtime_Router::lisp_to_q_meta_type(args[next_cast_index].object, pv);
      argument_info[next_cast_index].type_name = type_name;
      argument_info[next_cast_index].void_argument = pv;
      argument_info[next_cast_index].void_argument_for_delete = pv;
      switch(atc)
      {
      case KCM_Command_Runtime_Router::Arg_Type_Codes::Int:
       CAST_INDEX_SWITCH(int)
       break;
      }
     }
     break;
    }
   }
  }
 };
#endif




#undef ARGS_TEMP_MACROS

//#undef CASE_TEMP_MACROS
#undef ARGUMENTS
#undef QARGUMENTS
#undef CAST_INDEX_SWITCH
#undef CASE_TEMP_MACRO

 //CAST_TYPEDEF_MACRO(3)



// For ARG_COUNT 4
#define CASE_TEMP_MACRO(INDEX, TYPE) CASE_TEMP_MACRO_(INDEX, 4, TYPE)

#define TYPENAMES_typename ,typename ARG1_Type, typename ARG2_Type, typename ARG3_Type, typename ARG4_Type
#define TYPENAMES_arg ,ARG1_Type arg1, ARG2_Type arg2, ARG3_Type arg3, ARG4_Type arg4
#define QARGUMENTS  \
 ,QARG_TEMP_MACRO(1), \
 QARG_TEMP_MACRO(2), \
 QARG_TEMP_MACRO(3), \
 QARG_TEMP_MACRO(4) \

#define ARGUMENTS   ,arg1, arg2, arg3, arg4


//#define CASE_TEMP_MACROS \
// CASE_TEMP_MACRO(0) \
// CASE_TEMP_MACRO(1) \
// CASE_TEMP_MACRO(2) \
// CASE_TEMP_MACRO(3) \

#define CAST_INDEX_SWITCH(TYPE) \
   switch(cast_index) \
   { \
    CASE_TEMP_MACRO(0, TYPE) \
    CASE_TEMP_MACRO(1, TYPE) \
    CASE_TEMP_MACRO(2, TYPE) \
    CASE_TEMP_MACRO(3, TYPE) \
   } \



#define CASE_TEMP_MACRO(INDEX, INTERCHANGE_TYPE) \
   CASE_TEMP_MACRO_(INDEX, 4, INTERCHANGE_TYPE)

#define CAST_INDEX_SWITCH(TYPE) \
   switch(cast_index) \
   { \
    CASE_TEMP_MACRO(0, TYPE) \
    CASE_TEMP_MACRO(1, TYPE) \
    CASE_TEMP_MACRO(2, TYPE) \
    CASE_TEMP_MACRO(3, TYPE) \
   } \


#define ARGS_TEMP_MACROS \
 ARGS_TEMP_MACRO(1) \
 ARGS_TEMP_MACRO(2) \
 ARGS_TEMP_MACRO(3) \
 ARGS_TEMP_MACRO(4) \

 TEMP_MACRO(4)

#undef ARGS_TEMP_MACROS
#undef CASE_TEMP_MACROS
#undef ARGUMENTS
#undef QARGUMENTS

 //CAST_TYPEDEF_MACRO(4)

};

template<//?KCM_Command_Runtime_Router::Return_Conventions RC,
         int i>
struct Do_Invoke_Method__Cast_Schedule__QOB__Cast_
{
 //typedef Argument_
};

//template<KCM_Command_Runtime_Router::Return_Conventions RC>
//struct Do_Invoke_Method__Cast_Schedule__Cast_<RC, 1>
//{
// typedef typename Do_Invoke_Method__Cast_Schedule<RC>::Cast_1 Type;
//};

//template<KCM_Command_Runtime_Router::Return_Conventions RC>
//struct Do_Invoke_Method__Cast_Schedule__Cast_<RC, 2>
//{
// typedef typename Do_Invoke_Method__Cast_Schedule<RC>::Cast_2 Type;
//};


//?KCM_Command_Runtime_Router::Return_Conventions RC
#define TEMP_MACRO(i) \
template<> \
struct Do_Invoke_Method__Cast_Schedule__QOB__Cast_<i> \
{ \
 typedef typename Do_Invoke_Method__Cast_Schedule__QOB::Cast_##i Type; \
}; \


//?
//
TEMP_MACRO(0)
TEMP_MACRO(1)
TEMP_MACRO(2)
TEMP_MACRO(3)
TEMP_MACRO(4)



// struct Cast_4_Ready
// {
//  template<typename OBJECT_Type, TYPENAMES_typename>
//  static void run(QString method_name, OBJECT_Type obj,
//   TYPENAMES_arg, QVector<QString>& type_names)
//  {
//   QMetaObject::invokeMethod(obj, method_name.toLatin1(),
//    QARGUMENTS);
//  }
// };

// struct Cast_4
// {
//  static constexpr int ready_at_cast_index = 4;
//  template<typename OBJECT_Type, typename Type_List_Type>
//  static void run(QString method_name, OBJECT_Type obj,
//    int cast_index, QVector<void*>& void_arguments, QVector<QString>& type_names,
//    const QVector<KCM_Command_Runtime_Router::Argument_Conventions>& ACs,
//    QVector<KCM_Command_Runtime_Argument>& args)
//  {
//   if(cast_index == ready_at_cast_index)
//   {
//    ARGS_TEMP_MACROS
//    Cast_4_Ready::run(method_name, obj, ARGUMENTS, type_names);
//   }
//   else
//   {
//    int next_cast_index = cast_index + 1;
//    KCM_Command_Runtime_Router::Argument_Conventions ac = ACs[next_cast_index];
//    switch(ac)
//    {
//    case KCM_Command_Runtime_Router::Argument_Conventions::QString_Direct:
//     QString arg = args[cast_index].str;
//     void_arguments[cast_index] = &arg;
//     type_names[cast_index] = "QString";
//     switch(cast_index)
//     {
//     CASE_TEMP_MACROS
//     }
//    }
//   }
//  }
// };





//};



// struct Cast_2
// {
//  template<typename OBJECT_Type, typename ARG1_Type>
//  static void run(QString method_name, OBJECT_Type obj,
//   int cast_index, KCM_Command_Runtime_Router::Argument_Conventions ac,
//   KCM_Command_Runtime_Argument& arg1,
//   const QVector<KCM_Command_Runtime_Router::Argument_Conventions>& ACs,
//   QVector<KCM_Command_Runtime_Argument>& args)
//  {
//   switch(ac)
//   {
//   case KCM_Command_Runtime_Router::Argument_Conventions::QString_Direct:
//    Cast_2_Ready::run(method_name, obj,
//      ACs[cast_index + 1], arg1.str, {"QString"}, args[cast_index]);
//   }
//  }
// };


_KANS(Kauvir)

#endif //HIDE

#endif



// struct Cast_3
// {
//  static constexpr int ready_at_cast_index = 3;
//  template<typename OBJECT_Type, typename Type_List_Type>
//  static void run(QString method_name, OBJECT_Type obj,
//    int cast_index, QVector<void*>& void_arguments, QVector<QString>& type_names,
//    const QVector<KCM_Command_Runtime_Router::Argument_Conventions>& ACs,
//    QVector<KCM_Command_Runtime_Argument>& args)
//  {
//   if(cast_index == ready_at_cast_index)
//   {
//    ARGS_TEMP_MACRO(1)
//    ARGS_TEMP_MACRO(2)
//    ARGS_TEMP_MACRO(3)
//    //Cast_3_Ready::run(method_name, obj, arg1, arg2, arg3, type_names);
//   }
//   else
//   {
//    int next_cast_index = cast_index + 1;
//    KCM_Command_Runtime_Router::Argument_Conventions ac = ACs[next_cast_index];
//    switch(ac)
//    {
//    case KCM_Command_Runtime_Router::Argument_Conventions::QString_Direct:
//     QString arg = args[cast_index].str;
//     void_arguments[cast_index] = &arg;
//     type_names[cast_index] = "QString";
//     switch(cast_index)
//     {
//     CASE_TEMP_MACRO(0)
//     CASE_TEMP_MACRO(1)
//     CASE_TEMP_MACRO(2)
//     }
//    }
//   }
//  }
// };
//#define TEMP_MACRO_X(ARG_COUNT) \
// struct Cast_##ARG_COUNT##_Ready \
// { \
//  template<typename OBJECT_Type, TYPENAMES_typename> \
//  static void run(QString method_name, OBJECT_Type obj, QVector<KCM_Command_Runtime_Argument>& args, \
//   TYPENAMES_arg, const QVector<KCM_Command_Runtime_Router::Argument_Info>& argument_info) \
//  { \
//   QMetaObject::invokeMethod(obj, method_name.toLatin1(), \
//    QARGUMENTS ); \
//  } \
//  template<typename OBJECT_Type, typename RET_Type, TYPENAMES_typename> \
//  static void run(QString method_name, OBJECT_Type obj, QString return_type, \
//   RET_Type& ret, QVector<KCM_Command_Runtime_Argument>& args, \
//   TYPENAMES_arg, const QVector<KCM_Command_Runtime_Router::Argument_Info>& argument_info) \
//  { \
//   QMetaObject::invokeMethod(obj, method_name.toLatin1(), \
//    QReturnArgument<RET_Type>(return_type.toLatin1(), ret), \
//    QARGUMENTS ); \
//  } \
// }; \
// \
// struct Cast_##ARG_COUNT \
// { \
//  static constexpr int ready_at_cast_index = ARG_COUNT; \
//  template<typename OBJECT_Type, typename Type_List_Type> \
//  static void run(QString method_name, OBJECT_Type obj, \
//    int cast_index, KCM_Command_Runtime_Router& kcrr, \
//    QVector<KCM_Command_Runtime_Router::Argument_Info>& argument_info, \
//    QVector<KCM_Command_Runtime_Argument>& args) \
//  { \
// if(cast_index == ready_at_cast_index) \
// { \
//    switch(kcrr.return_type_code()) \
//    { \
//    case KCM_Command_Runtime_Router::Arg_Type_Codes::No_Return: \
//     { \
//      ARGS_TEMP_MACROS \
//      Cast_##ARG_COUNT##_Ready::run(method_name, obj, args,  ARGUMENTS, argument_info); \
//     } \
//     break; \
//    case KCM_Command_Runtime_Router::Arg_Type_Codes::Void_Pointer: \
//     { \
//      ARGS_TEMP_MACROS \
//      Cast_##ARG_COUNT##_Ready::run(method_name, obj, \
//        kcrr.return_type_name_strip_namespace(), \
//        kcrr.raw_result(), \
//        args, ARGUMENTS, argument_info); \
//     } \
//     break; \
//    case KCM_Command_Runtime_Router::Arg_Type_Codes::Int: \
//     { \
//      int& x = *reinterpret_cast<int*>(kcrr.raw_result()); \
//      ARGS_TEMP_MACROS \
//      Cast_##ARG_COUNT##_Ready::run(method_name, obj, \
//       "int", x, args, ARGUMENTS, argument_info); \
//     } \
//     break; \
//    case KCM_Command_Runtime_Router::Arg_Type_Codes::QString_Return: \
//     { \
//      QString& qs = kcrr.string_result(); \
//      ARGS_TEMP_MACROS \
//      Cast_##ARG_COUNT##_Ready::run(method_name, obj, \
//        "QString", qs, args  ,ARGUMENTS, argument_info); \
//     } \
//     break; \
//    } \
//   } \
//   else \
//   { \
//    int next_cast_index = cast_index + 1; \
//    KCM_Command_Runtime_Router::Argument_Conventions ac = \
//      argument_info[next_cast_index].convention; \
//    switch(ac) \
//    { \
//    case KCM_Command_Runtime_Router::Argument_Conventions::QString_Direct: \
//     { \
//      QString arg = args[next_cast_index].str; \
//      argument_info[next_cast_index].void_argument = &arg; \
//      argument_info[next_cast_index].type_name = "QString"; \
//      CAST_INDEX_SWITCH(QString) \
//     } \
//     break; \
//    case KCM_Command_Runtime_Router::Argument_Conventions::QMetaType_Confirmed: \
//     { \
//      const QMetaType* qmt = argument_info[next_cast_index].q_meta_type; \
//      int id = argument_info[next_cast_index].q_meta_type_id; \
//      QString type_name = QString::fromLatin1(QMetaType::typeName(id)); \
//      void* pv = qmt->create(); \
//      KCM_Command_Runtime_Router::Arg_Type_Codes atc = \
//        KCM_Command_Runtime_Router::lisp_to_q_meta_type(args[next_cast_index].object, pv); \
//      argument_info[next_cast_index].type_name = type_name; \
//      argument_info[next_cast_index].void_argument = pv; \
//      argument_info[next_cast_index].void_argument_for_delete = pv; \
//      switch(atc) \
//      { \
//      case KCM_Command_Runtime_Router::Arg_Type_Codes::Int: \
//       CAST_INDEX_SWITCH(int) \
//       break; \
//      } \
//     } \
//     break; \
//    case KCM_Command_Runtime_Router::Argument_Conventions::QVariant_Cast: \
//     { \
//      QVariant qvar = KCM_Command_Runtime_Router::lisp_to_q_variant(args[next_cast_index].object); \
//      argument_info[next_cast_index].type_name = "QVariant"; \
//      argument_info[next_cast_index].void_argument = &qvar; \
//      CAST_INDEX_SWITCH(QVariant) \
//     } \
//     break; \
//    case KCM_Command_Runtime_Router::Argument_Conventions::QObject_Cast: \
//     { \
//      CAST_INDEX_SWITCH(QObject*) \
//     } \
//    } \
//   } \
//  } \
// }; \


//#endif // KCM_COMMAND_RUNTIME_ROUTER__H
