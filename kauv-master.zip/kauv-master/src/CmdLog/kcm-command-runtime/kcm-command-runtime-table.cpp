
#include "kcm-command-runtime-table.h"

//#include "kauvir-runtime.h"

//#include "kauvir-nl-lexicon/kauvir-nl-lexicon.h"

//?#include "kauvir-type-object-builder.h"

#include "kauvir/kauvir-code-model/kcm-channel-group.h"

#include "kans.h"

#include <QQueue>

USING_KANS(Kauvir)
USING_KANS(CMD)




KCM_Command_Runtime_Table::KCM_Command_Runtime_Table(Kauvir_Type_System& type_system)//, Kauvir_Type_Object_Builder& type_object_builder)
  :  type_system_(type_system)
//  ,
//     type_object_builder_(type_object_builder),
//     nl_lexicon_(nullptr)
{
// type_object_builder_.set_kauvir_runtime(this);
}



KCM_Channel_Group* KCM_Command_Runtime_Table::find_channel_group(const KCM_Channel_Group& channels)
{
 if(group_pointers_.contains(channels))
 {
  return group_pointers_.value(channels);
 }
 KCM_Channel_Group* result = new KCM_Channel_Group(channels);
 group_pointers_[channels] = result;
 return result;
}

KCM_Channel_Group* KCM_Command_Runtime_Table::add_s0_declared_function(QString name, const KCM_Channel_Group& channels)
{
 KCM_Channel_Group* result = find_channel_group(channels);
 s0_declared_functions_.insertMulti(name, result);
 return result;
}


KCM_Channel_Group* KCM_Command_Runtime_Table::add_s1_declared_function(QString name, const KCM_Channel_Group& channels)
{
 KCM_Channel_Group* result = find_channel_group(channels);
 s1_declared_functions_.insertMulti(name, result);
 return result;
}

//template<typename FN_type>
//void KCM_Command_Runtime_Table::add_declared_function(QString name, KCM_Channel_Group* kcg, FN_type fn)
//{
// s1_declared_functions_generic_.insert(name, {kcg, (fng_type)fn});
//}


//void KCM_Command_Runtime_Table::add_declared_function(QString name, KCM_Channel_Group* kcg, fn0_type fn)
//{
// s1_declared_functions_0_.insert(name, {kcg, fn});
// s1_declared_functions_generic_.insert(name, {kcg, (fng_type)fn});
//}


//void KCM_Command_Runtime_Table::add_declared_function(QString name, KCM_Channel_Group* kcg, fn1_type fn)
//{
// s1_declared_functions_1_.insert(name, {kcg, fn});
// s1_declared_functions_generic_.insert(name, {kcg, (fng_type)fn});
//}

//void KCM_Command_Runtime_Table::add_declared_function(QString name, KCM_Channel_Group* kcg, fn2_type fn)
//{
// s1_declared_functions_2_.insert(name, {kcg, fn});
// s1_declared_functions_generic_.insert(name, {kcg, (fng_type)fn});
//}

//void KCM_Command_Runtime_Table::add_declared_function(QString name, KCM_Channel_Group* kcg, fn3_type fn)
//{
// s1_declared_functions_3_.insert(name, {kcg, fn});
// s1_declared_functions_generic_.insert(name, {kcg, (fng_type)fn});
//}


//?
//_s0_fn1_p_type KCM_Command_Runtime_Table::find__s0_declared_function_1(QString name, KCM_Channel_Group* kcg)
//{
// for(QPair<KCM_Channel_Group*, _s0_fng_type> pr
//   : _s0_declared_functions_generic_.values(name))
// {
//  return (_s0_fn1_p_type)(pr.second);
// }
// return nullptr;
//}

s1_fng_type KCM_Command_Runtime_Table::find_s1_declared_function_0(QString name,
  KCM_Channel_Group* kcg, const KCM_Type_Object** pkto)
{
 for(QPair<KCM_Channel_Group*, s1_fng_type> pr : s1_declared_functions_generic_.values(name))
 {
  if(pkto)
  {
   KCM_Channel_Group* k_ = pr.first;
   KCM_Channel& result = k_->result();
   if(!result.carriers().isEmpty())
   {
    KCM_Carrier r1;
    result.get_carrier_at_position(0, r1);
    *pkto = r1.type_object();
   }
   else
   {
    *pkto = nullptr;
   }
  }
  return (s1_fng_type)(pr.second);
 }
 return nullptr;
}

s0_fn1_p_type KCM_Command_Runtime_Table::find_s0_declared_function_1(QString name,
  KCM_Channel_Group* kcg, const KCM_Type_Object** pkto)
{
 for(QPair<KCM_Channel_Group*, s0_fng_type> pr : s0_declared_functions_generic_.values(name))
 {
  if(pkto)
  {
   KCM_Channel_Group* k_ = pr.first;
   KCM_Channel& result = k_->result();
   if(!result.carriers().isEmpty())
   {
    KCM_Carrier r1;
    result.get_carrier_at_position(0, r1);
    *pkto = r1.type_object();
   }
   else
   {
    *pkto = nullptr;
   }
  }
  return (s0_fn1_p_type)(pr.second);
  //if(pr.first == kcg)
  //  return (fn1_type)(pr.second);
 }
 return nullptr;
}


//s0_fn1_p_type KCM_Command_Runtime_Table::find_s0_declared_function_1(QString name, KCM_Channel_Group* kcg)
//{
// for(QPair<KCM_Channel_Group*, s1_fng_type> pr : s1_declared_functions_generic_.values(name))
// {
//  if(pr.first == kcg)
//    return (s0_fn1_p_type)(pr.second);
// }
// return nullptr;
//}



//fn2_type KCM_Command_Runtime_Table::find_declared_function_2(QString name, KCM_Channel_Group* kcg)
//{
// for(QPair<KCM_Channel_Group*, fng_type> pr : s1_declared_functions_generic_.values(name))
// {
//  if(pr.first == kcg)
//    return (fn2_type)(pr.second);
// }
// return nullptr;
//}


//?
//s0_fn1_p_type KCM_Command_Runtime_Table::find_s0_declared_function_1(QString name, KCM_Channel_Group* kcg)
//{
// for(QPair<KCM_Channel_Group*, fng_type> pr : s1_declared_functions_generic_.values(name))
// {
//  if(pr.first == kcg)
//    return (fn0_type)(pr.second);
// }


// for(QPair<KCM_Channel_Group*, fn0_type> pr : s1_declared_functions_0_.values(name))
// {
//  if(pr.first == kcg)
//    return pr.second;
// }

