
#ifndef KCM_COMMAND_RUNTIME_TABLE__H
#define KCM_COMMAND_RUNTIME_TABLE__H

#include <QtGlobal>


#include <functional>

#include <QMetaProperty>
#include <QVector>

#include "kans.h"
#include "accessors.h"

//?
//#include "cl-cxx/object.hpp"
//#include "kauvir-lisp-argument.h"
//

#include "kauvir/kauvir-type-system/kauvir-universal-class.h"
#include "kauvir/kauvir-type-system/kauvir-type-system.h"
//#include "kauvir


KANS_CLASS_DECLARE(KCM ,KCM_Channel_Group)
KANS_CLASS_DECLARE(KCM ,KCM_Type_Object)

USING_KANS(KCM)
USING_KANS(Kauvir)

KANS_(CMD)

//class Kauvir_Request_Runtime;
//class Kauvir_Runtime_Router_Invokable;
//class KCM_Channel_Group;


class KCM_Command_Runtime_Table
{
 QMultiMap<QString, KCM_Channel_Group*> s1_declared_functions_;
 QMultiMap<QString, KCM_Channel_Group*> s0_declared_functions_;

 //?QMap<QString, Kauvir_Type_Object*> types_;

 QMap<KCM_Channel_Group, KCM_Channel_Group*> group_pointers_;
 KCM_Channel_Group* find_channel_group(const KCM_Channel_Group& channels);

 QMultiMap<QString, QPair<KCM_Channel_Group*, s1_fng_type>> s1_declared_functions_generic_;
 QMultiMap<QString, QPair<KCM_Channel_Group*, s0_fng_type>> s0_declared_functions_generic_;

 QMultiMap<QString, QPair<KCM_Channel_Group*, _s1_fng_type>> _s1_declared_functions_generic_;
 QMultiMap<QString, QPair<KCM_Channel_Group*, _s0_fng_type>> _s0_declared_functions_generic_;

 QMultiMap<QString, QString> declared_types_;

 Kauvir_Type_System& type_system_;
 //?Kauvir_Type_Object_Builder& type_object_builder_;

public:

 KCM_Command_Runtime_Table(Kauvir_Type_System& type_system);//, Kauvir_Type_Object_Builder& type_object_builder);

 ACCESSORS__GET(Kauvir_Type_System& ,type_system)
 //?ACCESSORS__GET(Kauvir_Type_Object_Builder& ,type_object_builder)

 KCM_Channel_Group* add_s1_declared_function(QString name, const KCM_Channel_Group& channels);
 KCM_Channel_Group* add_s0_declared_function(QString name, const KCM_Channel_Group& channels);

//? Kauvir_Type_Object* type_object_builder_complete(QString followup_code = QString());

 template<typename FN_type>
 void add_s1_declared_function(QString name, KCM_Channel_Group* kcg, FN_type fn)
 {
  s1_declared_functions_generic_.insert(name, {kcg, (s1_fng_type)fn});
 }

 template<typename FN_type>
 void add_s0_declared_function(QString name, KCM_Channel_Group* kcg, FN_type fn)
 {
  s0_declared_functions_generic_.insert(name, {kcg, (s0_fng_type)fn});
 }

//?
// template<typename FN_type>
// void add__s0_declared_function(QString name, KCM_Channel_Group* kcg, FN_type fn)
// {
//  _s0_declared_functions_generic_.insert(name, {kcg, (_s0_fng_type)fn});
// }

//? Kauvir_Type_Object* process_type_declaration(QString type_name, QString type_expression);


// Kauvir_Type_Object* check_register_type_object(QString type_name, QString cpp_name,
//   QVariant::Type qvt, int qmetatype_code);

//? fn2_type find_declared_function_2(QString name, KCM_Channel_Group* kcg);

 s0_fn1_p_type find_s0_declared_function_1(QString name,
   KCM_Channel_Group* kcg, const KCM_Type_Object** pkto);

 s1_fng_type find_s1_declared_function_0(QString name,
   KCM_Channel_Group* kcg, const KCM_Type_Object** pkto);

//? _s0_fn1_p_type find__s0_declared_function_1(QString name, KCM_Channel_Group* kcg);

//? fn0_type find_declared_function_0(QString name, KCM_Channel_Group* kcg);

 //s0_fn2_type find_declared_function_2(QString name, KCM_Channel_Group* kcg);

//? s0_fn1_p_type find_s0_declared_function_1(QString name);//, KCM_Channel_Group* kcg);

 //fn0_type find_declared_function_0(QString name, KCM_Channel_Group* kcg);


};

_KANS(CMD)

#endif // KCM_COMMAND_RUNTIME_ROUTER__H
