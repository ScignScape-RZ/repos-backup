
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)


#ifndef FORE_GEOMETRIC_1D_PANEL__H
#define FORE_GEOMETRIC_1D_PANEL__H

#include <QObject>

#include <QMetaType>

#include <QList>
#include <QGraphicsScene>
#include <QPoint>

#include <QDialog>

#include <QFrame>



#include "accessors.h"
#include "kans.h"
#include "flags.h"


class QDialogButtonBox;
class QLabel;
class QLineEdit;
class QTabWidget;
class QTextEdit;
class QFrame;
class QHBoxLayout;
class QVBoxLayout;
class QSlider;
class QPlainTextEdit;
class QBoxLayout;
class QButtonGroup;
class QGroupBox;
class QScrollArea;
class QGridLayout;
class QWebEngineView;


//?class CyStage_Clickable_Label;
//?class CyStage_Image_Tile;

KANS_(CYSTAGE)
//?namespace KA { namespace CYSTAGE {


class CyStage_Clickable_Label;
class CyStage_Image_Tile;

class Fore_Geometric1D_Panel : public QFrame
{
 Q_OBJECT

 flags_(1)
  bool windows_can_be_merged:1;
  bool description_can_be_detached:1;
  bool notebook_can_be_detached:1;
  bool everything_can_be_detached:1;
  bool image_can_be_detached:1;
 _flags


 QVBoxLayout* main_layout_;


// QPixmap* item_display_pixmap_;
// QLabel* image_label_;
// QScrollArea* item_display_scroll_area_;

 QPixmap* scrolled_image_pixmap_;
 QGraphicsView* scrolled_image_view_;
 QGraphicsScene* scrolled_image_scene_;
 QGraphicsPixmapItem* scrolled_image_pixmap_item_;
 //?int zoom_rate_;
 QGraphicsRectItem* background_rectangle_;
 int background_rectangle_center_x_;
 int background_rectangle_center_y_;


 QString pixmap_path_;

 QMap<QString, CyStage_Image_Tile*>* current_tile_map_;


 QString imf_;

 QString associated_3D_model_file_;

public:

 //?ACCESSORS(QTabWidget* ,main_notebook)


 Fore_Geometric1D_Panel(QString initial_image_file, QWidget* parent = nullptr);

 ACCESSORS(QString ,associated_3D_model_file)


 ~Fore_Geometric1D_Panel();

 void adjust_zoom(int zoom);
 void direct_adjust_zoom(int zoom);
 void recenter_image();

 void note_notebook_detached()
 {
  // // i.e., if description is already detached
   //   then "everthing" is already detached too
  flags.everything_can_be_detached = flags.description_can_be_detached;
  flags.notebook_can_be_detached = false;
  flags.windows_can_be_merged = true;
 }

 void note_description_detached()
 {
  flags.everything_can_be_detached = flags.notebook_can_be_detached;
  flags.description_can_be_detached = false;
  flags.windows_can_be_merged = true;
 }

 void note_everything_detached()
 {
  flags.windows_can_be_merged = true;
  flags.everything_can_be_detached = false;
  flags.notebook_can_be_detached = false;
  flags.description_can_be_detached = false;
 }

 void note_windows_merged()
 {
  flags.windows_can_be_merged = false;
  flags.everything_can_be_detached = true;
  flags.notebook_can_be_detached = true;
  flags.description_can_be_detached = true;
  flags.image_can_be_detached = true;
 }

 void note_image_detached()
 {
  flags.image_can_be_detached = false;
  flags.windows_can_be_merged = true;
  flags.everything_can_be_detached = false;
  flags.notebook_can_be_detached = false;
  flags.description_can_be_detached = false;
 }

Q_SIGNALS:

 void take_screenshot_requested();
 void load_3D_model_requested(QString);
 void view_item_list_requested();
 void view_shopping_cart_requested();

 void detach_image_requested();
 void detach_notebook_requested();
 void detach_description_requested();
 void detach_everything_requested();
 void merge_windows_requested();


//Q_SIGNALS:
// void canceled(QDialog*);
// void accepted(QDialog*);

public Q_SLOTS:

 void zoom_in();
 void zoom_out();
 void change_scale_ratio(qreal ratio);
 void open_file(QString path);

};

_KANS(CYSTAGE)


#endif  // FORE_GEOMETRIC_1D_PANEL__H


