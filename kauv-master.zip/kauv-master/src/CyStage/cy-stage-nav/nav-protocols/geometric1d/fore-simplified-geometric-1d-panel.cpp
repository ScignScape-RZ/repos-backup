
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)



#include "fore-simplified-geometric-1d-panel.h"

#include <QTabWidget>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QGraphicsPixmapItem>
#include <QHBoxLayout>
#include <QWebEngineView>

#include <QLabel>
#include <QMenu>

#include <QScrollBar>

//?#include "color_dialog.hpp"

#include "rz-ecs/rz-ecs-gui-library/paraviews/color-pair-dialog.h"

#include "CyStage/cy-stage-nav/subwindows/cystage-image-tile.h"

USING_RZNS(ECS)


USING_KANS(CYSTAGE)


Fore_Simplified_Geometric1D_Panel::Fore_Simplified_Geometric1D_Panel(QString initial_image_file, QWidget* parent)
  :  QFrame(parent), Flags(0), imf_(initial_image_file)
{
 flags.description_can_be_detached = true;
 flags.notebook_can_be_detached = true;
 flags.everything_can_be_detached = true;
 flags.image_can_be_detached = true;


 pixmap_path_ = imf_;
#ifdef HIDE
 image_label_ = new QLabel(this);
 item_display_pixmap_ = new QPixmap(pixmap_path_);
 image_label_->setPixmap(item_display_pixmap_->scaled(260, 500, Qt::KeepAspectRatio));
 image_label_->setContextMenuPolicy(Qt::CustomContextMenu);
 image_label_->setCursor(Qt::CrossCursor);
 connect(image_label_, &QLabel::customContextMenuRequested,
   [this](QPoint p)
 {
  QColor color = image_label_->pixmap()->toImage().pixelColor(p);// + QPoint{0, 3});
  QMenu* qm = new QMenu(this);
  qm->addAction("Explore Color Matches ...", [this, color]{
//?
    Color_Pair_Dialog* dlg = new Color_Pair_Dialog(this);
    //?color_widgets::ColorDialog* dlg = new color_widgets::ColorDialog(this);
    dlg->set_reference_color(color);
    dlg->exec();
    //   QColor select_color = QColorDialog::getColor(color);
                });

  qm->addAction("View 3D Model ...", [this]{
   Q_EMIT(load_3D_model_requested(associated_3D_model_file_));
  });

  qm->addAction("View Item List", [this]{
   Q_EMIT(view_item_list_requested());
  });

  QPoint g = image_label_->mapToGlobal(p);
  qm->popup(g);
 });

 item_display_scroll_area_ = new QScrollArea(this);
 item_display_scroll_area_->setMaximumHeight(400);
 item_display_scroll_area_->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
 item_display_scroll_area_->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);

 item_display_scroll_area_->setWidget(image_label_);

 item_display_scroll_area_->setAlignment(Qt::AlignBottom);

 item_display_scroll_area_->setWidgetResizable(true);
#endif


 scrolled_image_pixmap_ = new QPixmap(pixmap_path_);

 int sipw = scrolled_image_pixmap_->width();
 int siph = scrolled_image_pixmap_->height();

 scrolled_image_view_ = new QGraphicsView(this);

 scrolled_image_view_->setMinimumWidth(sipw*2);
 scrolled_image_view_->setMinimumHeight(siph*2);

 scrolled_image_scene_ = new QGraphicsScene(this);
  //?scrolled_image_label_ = new QLabel("Scrolled Image ...", this);
  //?scrolled_image_label_->setPixmap(*scrolled_image_pixmap_);

 scrolled_image_view_->setScene(scrolled_image_scene_);

 background_rectangle_ = scrolled_image_scene_->addRect(0, 0, sipw * 2, siph * 2);
 background_rectangle_center_x_ = background_rectangle_->boundingRect().x() +
   (background_rectangle_->boundingRect().width() / 2);
 background_rectangle_center_y_ = background_rectangle_->boundingRect().y() +
   (background_rectangle_->boundingRect().height() / 2);

 scrolled_image_pixmap_item_ = scrolled_image_scene_->addPixmap(*scrolled_image_pixmap_);
 scrolled_image_pixmap_item_->setPos(0,0);

 scrolled_image_pixmap_item_->setFlags(QGraphicsItem::ItemIsMovable);


 scrolled_image_view_->setContextMenuPolicy(Qt::CustomContextMenu);
 scrolled_image_view_->setCursor(Qt::CrossCursor);
 connect(scrolled_image_view_, &QLabel::customContextMenuRequested,
   [this](QPoint p)
 {
  QMenu* qm = new QMenu(this);

  QAction* dia = qm->addAction("Detach Image", this, SIGNAL(detach_image_requested()));
  dia->setEnabled(flags.image_can_be_detached);

  QAction* dna = qm->addAction("Detach Noteboook", this, SIGNAL(detach_notebook_requested()));
  dna->setEnabled(flags.notebook_can_be_detached);

  QAction* dda = qm->addAction("Detach Description", this, SIGNAL(detach_description_requested()));
  dda->setEnabled(flags.description_can_be_detached);

  QAction* dea = qm->addAction("Detach Everything", this, SIGNAL(detach_everything_requested()));
  dea->setEnabled(flags.everything_can_be_detached);

  QAction* mwa = qm->addAction("Merge Windows", this, SIGNAL(merge_windows_requested()));
  mwa->setEnabled(flags.windows_can_be_merged);

  QColor color = scrolled_image_pixmap_->toImage().pixelColor(p);// + QPoint{0, 3});
  qm->addAction("Explore Color Matches ...", [this, color]{
//?
    Color_Pair_Dialog* dlg = new Color_Pair_Dialog(this);
    //?color_widgets::ColorDialog* dlg = new color_widgets::ColorDialog(this);
    dlg->set_reference_color(color);
    dlg->exec();
    //   QColor select_color = QColorDialog::getColor(color);
                });

  qm->addAction("View 3D Model ...", [this]{
   Q_EMIT(load_3D_model_requested(associated_3D_model_file_));
  });

  qm->addAction("Take Screenshot", [this]{
   Q_EMIT(take_screenshot_requested());
  });

  qm->addAction("View Item List", [this]{
   Q_EMIT(view_item_list_requested());
  });

  qm->addAction("View Shopping Cart", [this]{
   Q_EMIT(view_shopping_cart_requested());
  });

  QPoint g = scrolled_image_view_->mapToGlobal(p);
  qm->popup(g);
 });


//?
// direct_adjust_zoom(25);
// recenter_image();

//? scrolled_image_view_->resize(300, 300);

//? scrolled_image_view_->setFixedHeight(300);
//? scrolled_image_view_->setFixedWidth(500);

//? image_scroll_area_ = new QScrollArea(this);
//? image_scroll_area_->setWidget(scrolled_image_view_);

 //image_scroll_area_->setGeometry(0, 0, 300, 100);

//? image_scroll_area_->setFixedHeight(100);
//? image_scroll_area_->setFixedWidth(200);

 //image_pixmap_->setDevicePixelRatio(0.5);

 //?image_layout_->addWidget(image_label_);
 //?image_layout_->addWidget(image_scroll_area_);

//? image_layout_->addStretch();

// image_layout_->addWidget(scrolled_image_view_);
// main_layout_->addLayout(image_layout_);


 main_layout_ = new QVBoxLayout;
 main_layout_->addWidget(scrolled_image_view_);
//? main_layout_ = new QVBoxLayout;
//? main_layout_->addWidget(item_display_scroll_area_);

 setLayout(main_layout_);
// main_pixmap_item_ = new QGraphicsPixmapItem(QPixmap::fromImage(QImage(imf_)));
// main_scene_->addItem(main_pixmap_item_)
// main_pixmap_item_->setFlag(QGraphicsItem::ItemIsMovable);
// main_scene_layout_ = new QHBoxLayout;
// main_scene_layout_->addWidget(main_view_);
// main_scene_frame_ = new QFrame(this);
// main_scene_frame_->setLayout(main_scene_layout_);
// main_notebook_->addTab(main_scene_frame_, "View");
// instructions_view_ = new QWebEngineView(this);
// main_notebook_->addTab(instructions_view_, "Instructions");


}

void Fore_Simplified_Geometric1D_Panel::direct_adjust_zoom(int zoom)
{
#ifdef HIDE
 qreal vr = (qreal)zoom / 10;

 qreal adj_ratio = vr * (2.0/5.0);

 //?item_display_pixmap_->setScale(adj_ratio);
 scrolled_image_pixmap_item_->setScale(adj_ratio);

 qDebug() << "DAZ: " << adj_ratio;
 // temporarily adjust for larger pics ...
 qDebug() << "Z: " << zoom;

 // 100 = 80
 // 50 = 130

 int adj_zoom = 39+zoom;
 qDebug() << "AZ: " << adj_zoom;

 qreal vr = (qreal)adj_zoom / 100;

 qreal adj_ratio = vr * 2;
 qDebug() << "DAZ: " << adj_ratio;

 //?item_display_pixmap_->setScale(adj_ratio);
 scrolled_image_pixmap_item_->setScale(adj_ratio);
#endif

 qDebug() << "Z: " << zoom;

 int adj_zoom = 99+zoom;
 qDebug() << "AZ: " << adj_zoom;

 qreal vr = (qreal)adj_zoom / 100;

 qreal adj_ratio = vr;// * 2;
 qDebug() << "DAZ: " << adj_ratio;

 //?item_display_pixmap_->setScale(adj_ratio);
 scrolled_image_pixmap_item_->setScale(adj_ratio);

}

//void Fore_Simplified_Geometric1D_Panel::rescroll_image(int amount)
//{

//}

void Fore_Simplified_Geometric1D_Panel::recenter_image()
{
 int w = scrolled_image_pixmap_item_->boundingRect().width() *
   scrolled_image_pixmap_item_->scale();
 int h = scrolled_image_pixmap_item_->boundingRect().height() *
   scrolled_image_pixmap_item_->scale();

 int new_left = background_rectangle_center_x_ - (w/2);
 int new_top = background_rectangle_center_y_ - (h/2);

 scrolled_image_pixmap_item_->setPos(new_left, new_top);

//?
// QScrollBar* const hsb = scrolled_image_view_->horizontalScrollBar();
// QScrollBar* const vsb = scrolled_image_view_->verticalScrollBar();

// int hmax = hsb->maximum();
// int hmin = hsb->minimum();
// int hcenter = (  hmin + hmax ) / 2;
// hsb->setValue( hcenter );
// hsb->update();

// int vmax = vsb->maximum();
// int vmin = vsb->minimum();
// int vcenter = (  vmin + vmax ) / 2;
// vsb->setValue( vcenter );
// vsb->update();

 scrolled_image_view_->update();
 //scrolled_image_view_->scroll();
}

void Fore_Simplified_Geometric1D_Panel::adjust_zoom(int zoom)
{
 direct_adjust_zoom(zoom);
 //?
 recenter_image();
}

Fore_Simplified_Geometric1D_Panel::~Fore_Simplified_Geometric1D_Panel()
{

}

void Fore_Simplified_Geometric1D_Panel::open_file_from_tile(CyStage_Image_Tile* tile)
{
 open_file(tile->absolute_path());
}


void Fore_Simplified_Geometric1D_Panel::open_file(QString path)
{
 pixmap_path_ = path;
 scrolled_image_pixmap_ = new QPixmap(pixmap_path_);
 scrolled_image_pixmap_item_->setPixmap(*scrolled_image_pixmap_);
 scrolled_image_pixmap_item_->update();


 int sipw = scrolled_image_pixmap_->width();
 int siph = scrolled_image_pixmap_->height();

 background_rectangle_->setRect(0, 0, sipw, siph);
 background_rectangle_center_x_ = background_rectangle_->boundingRect().x() +
   (background_rectangle_->boundingRect().width() / 2);
 background_rectangle_center_y_ = background_rectangle_->boundingRect().y() +
   (background_rectangle_->boundingRect().height() / 2);


//?
// *item_display_pixmap_ = QPixmap::fromImage(QImage(path));//.scaledToWidth(300));
// image_label_->setPixmap(item_display_pixmap_->scaled(450, 700, Qt::KeepAspectRatio));

 //?main_pixmap_item_->setPixmap(QPixmap::fromImage(QImage(path).scaledToWidth(300)));
}

void Fore_Simplified_Geometric1D_Panel::zoom_in()
{
 //?main_pixmap_item_->setScale(main_pixmap_item_->scale() + 0.115);
}

void Fore_Simplified_Geometric1D_Panel::zoom_out()
{
 //?main_pixmap_item_->setScale(main_pixmap_item_->scale() - 0.115);
}

void Fore_Simplified_Geometric1D_Panel::change_scale_ratio(qreal ratio)
{
 //?main_pixmap_item_->setScale(main_pixmap_item_->scale() * ratio);
}
