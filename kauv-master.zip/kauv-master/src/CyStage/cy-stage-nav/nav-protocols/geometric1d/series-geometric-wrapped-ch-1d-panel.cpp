
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)



#include "series-geometric-wrapped-ch-1d-panel.h"

#include "subwindows/cystage-image-tile.h"
#include "subwindows/cystage-clickable-label.h"

#include <QRegularExpression>
#include <QDebug>
#include <QRegularExpressionMatch>
#include <QDirIterator>
#include <QPainter>

#include <QVBoxLayout>

USING_KANS(CYSTAGE)


//  need to vary level size ...

Series_Geometric_Wrapped_CH_1D_Panel::Series_Geometric_Wrapped_CH_1D_Panel(QWidget *parent)
 :  QFrame(parent), level_size_(5),
   current_clickable_label_(nullptr),
   current_tile_(nullptr),
   current_tile_map_(nullptr)
{
 main_layout_ = new QGridLayout;

 for(int i = 0; i < level_size_; ++i)
 {
  main_layout_->setRowStretch(i, 0);
 }
 main_layout_->setRowStretch(level_size_, 1);

 lbl_1_ = new CyStage_Clickable_Label(this);
 lbl_2_ = new CyStage_Clickable_Label(this);

 lbl_1_->setText("Image 1 \n...");
 lbl_2_->setText("Image 2 \n...");

//?
// CyStage_Image_Tile* tile1 = new CyStage_Image_Tile("/ext_root/kauv/ecs-items/kurtka/kurtka2.JPG");
// CyStage_Image_Tile* tile2 = new CyStage_Image_Tile("/ext_root/kauv/ecs-items/kurtka/kurtka.JPG");
// lbl_1_->setPixmap(QPixmap::fromImage(QImage(tile1->local_path()).scaledToWidth(60)));
// lbl_2_->setPixmap(QPixmap::fromImage(QImage(tile2->local_path()).scaledToWidth(60)));

 main_layout_->addWidget(lbl_1_);
 main_layout_->addWidget(lbl_2_);
 //?main_layout_->addStretch();

// main_layout_->addWidget(tile1);
// main_layout_->addWidget(tile2);

 main_layout_->setSizeConstraint(QLayout::SetMinimumSize);

 setMaximumWidth(70);

 setLayout(main_layout_);
}


Series_Geometric_Wrapped_CH_1D_Panel::~Series_Geometric_Wrapped_CH_1D_Panel()
{

}

void Series_Geometric_Wrapped_CH_1D_Panel::init_color_from_grouping(QColor& c, int g)
{
 static QMap<int, QColor> static_map{{
  {0, QColor::fromRgb(180,200,180,220)},
  {1, QColor::fromRgb(180,200,180,220)},
  {2, QColor::fromRgb(180,200,180,220)},
  {3, QColor::fromRgb(180,200,180,220)},
  {4, QColor::fromRgb(180,200,180,220)},
  {5, QColor::fromRgb(180,200,180,220)},
  {6, QColor::fromRgb(180,200,180,220)},
  {7, QColor::fromRgb(180,200,180,220)},
 }};

 c = static_map.value(g, static_map.value(0));
}

void Series_Geometric_Wrapped_CH_1D_Panel::init_color_from_shown_grouping(QColor& c, int g)
{
 static QMap<int, QColor> static_map{{
  {0, QColor::fromRgb(200,200,244,220)},
  {1, QColor::fromRgb(200,200,244,220)},
  {2, QColor::fromRgb(200,200,244,220)},
  {3, QColor::fromRgb(200,200,244,220)},
  {4, QColor::fromRgb(200,200,244,220)},
  {5, QColor::fromRgb(200,200,244,220)},
  {6, QColor::fromRgb(200,200,244,220)},
  {7, QColor::fromRgb(200,200,244,220)},
 }};

 c = static_map.value(g, static_map.value(0));
}

void Series_Geometric_Wrapped_CH_1D_Panel::init_color_from_hidden_grouping(QColor& c, int g)
{
 static QMap<int, QColor> static_map{{
  {0, QColor::fromRgb(180,200,180,220)},
  {1, QColor::fromRgb(180,200,180,220)},
  {2, QColor::fromRgb(180,200,180,220)},
  {3, QColor::fromRgb(180,200,180,220)},
  {4, QColor::fromRgb(180,200,180,220)},
  {5, QColor::fromRgb(180,200,180,220)},
  {6, QColor::fromRgb(180,200,180,220)},
  {7, QColor::fromRgb(180,200,180,220)},
 }};

 c = static_map.value(g, static_map.value(0));
}



// //   Currently implemented only in the parent ...
void Series_Geometric_Wrapped_CH_1D_Panel::open_folder(QString path)
{

}

void Series_Geometric_Wrapped_CH_1D_Panel::show_group(int g)
{
// QMapIterator<QString, CyStage_Image_Tile*> it(*current_tile_map_);
// while(it.hasNext())
// {
//  it.next();
//  CyStage_Image_Tile* tile = it.value();
//  int tg = tile->get_dimensional_annotation(2);
//  if(g == tg)
//  {
//   CyStage_Clickable_Label* lbl = qobject_cast<CyStage_Clickable_Label*>( tile->associated_qobject() );
//   //lbl->show();
//   lbl->setVisible(true);
//   int c = tile->get_dimensional_annotation(1) - 1;
//   int level = c/level_size_;
//   int index = c%level_size_;
//   main_layout_->addWidget(lbl, index, level);
//  }
// }

//? QMapIterator<QString, CyStage_Image_Tile*> it(*current_tile_map_);
 int c = 0;
 int ov = 0;

// QMap<QPair<QPair<int, int>, CyStage_Clickable_Label*>> tempmap;

 QMap<QPair<int, int>, QPair<int, CyStage_Image_Tile*>> tempmap;

// QList<int> tmpkeys;
// QMap<int, int> invtmpkeys;

//? while(it.hasNext())
//? int mc = main_layout_->count();
 int ac = 0;

 QMapIterator<QString, CyStage_Image_Tile*> it(*current_tile_map_);
 while(it.hasNext())
 {
  it.next();
  CyStage_Image_Tile* tile = it.value();

  //?
  int r = tile->get_dimensional_annotation(0);
  int dc = tile->get_dimensional_annotation(1) - 1;

  int level = dc/level_size_;
  int index = dc%level_size_;

//  CyStage_Image_Tile* tile = main_layout_->itemAtPosition(level, index);

  int tg = tile->get_dimensional_annotation(2);

//?
  CyStage_Clickable_Label* lbl = qobject_cast<CyStage_Clickable_Label*>( tile->associated_qobject() );
//?  main_layout_->removeWidget(lbl);
  if(tg == g)
  {
   ++ac;
   lbl->setVisible(true);
   tempmap[{level, index}] = {ac, tile};
  }
  else if(lbl->isVisible())
  {
   tempmap[{level, index}] = {0, tile};
  }
 }

 QList<QPair<int, int>> tmpkeys = tempmap.keys();
 qSort(tmpkeys.begin(), tmpkeys.end());

 int s = tmpkeys.size();

 int nc = 0;
 int oc = 0;
 for(QPair<int, int> pr : tmpkeys)
 {
  int ac = tempmap[pr].first;
  CyStage_Image_Tile* tile = tempmap[pr].second;
  if(ac == 0)
  {
   if(nc > 0)
   {
    int rs, cs;
    auto gp = qMakePair(-1,-1);
    CyStage_Clickable_Label* lbl = qobject_cast<CyStage_Clickable_Label*>( tile->associated_qobject() );
    int ix = main_layout_->indexOf(lbl);
    main_layout_->getItemPosition(ix, &gp.first, &gp.second, &rs, &cs);
    main_layout_->removeWidget(lbl);
    int level = oc/level_size_;
    int index = oc%level_size_;

    auto ngp = qMakePair(index,level);

//?
    qDebug() << QString("Adding: old: %1,%2 new: %3,%4 ac: %5 nc: %6")
                .arg(gp.first).arg(gp.second).arg(ngp.first).arg(ngp.second).arg(ac).arg(nc);
    main_layout_->addWidget(lbl, index, level);
   }
   else
   {
    //?
    CyStage_Clickable_Label* lbl = qobject_cast<CyStage_Clickable_Label*>( tile->associated_qobject() );

    int rs, cs;
    auto gp = qMakePair(-1,-1);
    int ix = main_layout_->indexOf(lbl);
    main_layout_->getItemPosition(ix, &gp.first, &gp.second, &rs, &cs);
    //?main_layout_->removeWidget(lbl);
    int level = oc/level_size_;
    int index = oc%level_size_;

    auto ngp = qMakePair(index,level);

//?
    qDebug() << QString("Keeping: old: %1,%2 new: %3,%4 ac: %5 nc: %6")
                .arg(gp.first).arg(gp.second).arg(ngp.first).arg(ngp.second).arg(ac).arg(nc);
    //?main_layout_->addWidget(lbl, level, index);


    //?lbl->hide();
   }
  }
  else
  {
   CyStage_Clickable_Label* lbl = qobject_cast<CyStage_Clickable_Label*>( tile->associated_qobject() );
   int level = oc/level_size_;
   int index = oc%level_size_;
   ++nc;
//?
   auto ngp = qMakePair(index,level);

   qDebug() << QString("Adding,new: new: %1,%2 ac: %3 nc: %4")
               .arg(ngp.first).arg(ngp.second).arg(ac).arg(nc);

   main_layout_->addWidget(lbl, index, level);
  }
  ++oc;
 }
}

void Series_Geometric_Wrapped_CH_1D_Panel::hide_group(int g)
{
 QMapIterator<QString, CyStage_Image_Tile*> it(*current_tile_map_);
 int c = 0;
 int ov = 0;

 QMap<int, QPair<QPair<int, int>, CyStage_Clickable_Label*>> tempmap;
 QList<int> tmpkeys;
 QMap<int, int> invtmpkeys;

 while(it.hasNext())
 {
  it.next();
  CyStage_Image_Tile* tile = it.value();
  int tg = tile->get_dimensional_annotation(2);
  CyStage_Clickable_Label* lbl = qobject_cast<CyStage_Clickable_Label*>( tile->associated_qobject() );
  //
  //lbl->hide();
  main_layout_->removeWidget(lbl);
  if(g == tg)
  {
   lbl->setVisible(false);
   ++ov;
  }
  else if(lbl->isVisible())
  {
   lbl->setVisible(false);
   int tc = tile->get_dimensional_annotation(1) - 1;// - ov;
   //int tcov = tc - ov;
   int level = tc/level_size_;
   int index = tc%level_size_;
   tempmap[tc] = {{level, index}, lbl};
   tmpkeys.push_back(tc);
   invtmpkeys[tc] = c;
   ++c;
  }
  else
  {
   ++ov;
  }
 }

 int tov = 0;

// QMapIterator<QPair<int, int>, CyStage_Clickable_Label*> tempmapit(tempmap);
// while(tempmapit.hasNext())
 for(int i = 0; i < ov + c; ++i)
 {
  if(invtmpkeys.contains(i))
  {
   //int itk = tmpkeys[i];
      int tc = i - tov;
      //int level = tk;
      int level = tc/level_size_;
      int index = tc%level_size_;
      //int index = tempmap[tk].first.second;
      CyStage_Clickable_Label* lbl = tempmap[i].second;
      main_layout_->addWidget(lbl, index, level);
      lbl->setVisible(true);

  }
//  int tk = tmpkeys[i];
//  if(tempmap.contains(tk))
//  {
//   //
//   int tc = tk - tov;
//   //int level = tk;
//   int level = tc/level_size_;
//   int index = tc%level_size_;
//   //int index = tempmap[tk].first.second;
//   CyStage_Clickable_Label* lbl = tempmap[tk].second;
//   main_layout_->addWidget(lbl, index, level);
//   lbl->setVisible(true);
//  }
  else
  {
   ++tov;
  }
  //lbl->show();
 }


 //main_layout_->update()
}


void Series_Geometric_Wrapped_CH_1D_Panel::switch_tiles(CyStage_Image_Tile* new_tile)
{
 if(current_clickable_label_)
 {
  QImage qim = QImage(current_clickable_label_->path);
  qim = qim.scaledToWidth(60);
  current_clickable_label_->setPixmap(QPixmap::fromImage(qim));

  // restore border
  current_tile_ = reinterpret_cast<CyStage_Image_Tile*>(current_clickable_label_->userData(1));
  int g = current_tile_->get_dimensional_annotation(2);

  QColor c;
  init_color_from_grouping(c, g);

  QPixmap px = *current_clickable_label_->pixmap();

  QPainter p(&px);
  QPen pen = QPen(c);
  pen.setWidth(12);
  p.setPen(pen);
  p.drawRect(3, 3, 12, px.height()-8);
  p.end();
  current_clickable_label_->setPixmap(px);
 }

 CyStage_Clickable_Label* lbl = qobject_cast<CyStage_Clickable_Label*>( new_tile->associated_qobject() );
 current_clickable_label_ = lbl;

 if(lbl->userData(1))
 {
  current_tile_ = reinterpret_cast<CyStage_Image_Tile*>(lbl->userData(1));
 }

 QPixmap px = *lbl->pixmap();

 QPainter p(&px);
 QPen pen = QPen(QColor::fromRgb(155, 0, 0, 100));
 pen.setWidth(6);
 p.setPen(pen);

 QBrush qbr = QBrush(QColor::fromRgb(155, 0, 0, 10));
 p.setBrush(qbr);

 p.drawRect(3, 3, px.width()-6, px.height()-6);
 p.end();
 lbl->setPixmap(px);

 QString path = lbl->path;


 Q_EMIT(open_file_requested(path));
}


void Series_Geometric_Wrapped_CH_1D_Panel::display_tiles(QList<Geometic_Image_Tile_Info>& infos,
  QVector<CyStage_Image_Tile*>* tiles, QMap<QString, int>* index_map)
{
 lbl_1_->setVisible(false);
 lbl_2_->setVisible(false);

 main_layout_->removeItem(main_layout_->itemAt(0));
 main_layout_->removeItem(main_layout_->itemAt(1));
 main_layout_->removeItem(main_layout_->itemAt(2));

 CyStage_Image_Tile* last_tile = nullptr;

 // //   Allows the previous map to be kept in memory, if appropriate.
  //     Otherwise it should certainly be deleted and cleaned up ...
 current_tile_map_ = new QMap<QString, CyStage_Image_Tile*>();

 if(tiles)
 {
  tiles->resize(infos.size());
 }

 int raw_count = 0;
 for(const Geometic_Image_Tile_Info giti : infos)
 {
  CyStage_Image_Tile* tile = new CyStage_Image_Tile(giti.name());

  int count = giti.series_column() - 1;

  if(tiles)
  {
   (*tiles)[count] = tile;
  }
  if(index_map)
  {
   (*index_map)[giti.absolute_path()] = count;
  }
  ++raw_count;

  tile->set_dimensional_annotation(0, giti.series_row());
  tile->set_dimensional_annotation(1, giti.series_column());
  tile->set_dimensional_annotation(2, giti.grouping());

  shown_groups_.insert(giti.grouping());

  current_tile_map_->insert(giti.name(), tile);

  if(last_tile)
  {
   last_tile->set_series_next(tile);
   tile->set_series_previous(last_tile);
  }
  last_tile = tile;


  tile->set_absolute_path(giti.absolute_path());
  QImage qim = QImage(giti.absolute_path());

  qim = qim.scaledToWidth(60);

  CyStage_Clickable_Label* lbl = new CyStage_Clickable_Label(this); //QLabel(qfi.fileName(), this);

  lbl->setContentsMargins(0, 0, 0, 0);
  lbl->setMargin(0);

  lbl->setUserData(1, reinterpret_cast<QObjectUserData*>(tile));
  tile->set_associated_qobject(lbl);

  QString absolute_path = giti.absolute_path();

  connect(lbl, &CyStage_Clickable_Label::clicked,
          [absolute_path, lbl, tile, this]
  {
   switch_tiles(tile);
   int r = current_tile_->get_dimensional_annotation(0);
   int c = current_tile_->get_dimensional_annotation(1);
   if( (r >= 0) && (c >= 0) )
   {
    Q_EMIT(navigated_from_series(r, c));
   }
  });

  // highlight the first ...
//?

  lbl->path = absolute_path;
  lbl->setPixmap(QPixmap::fromImage(qim));
  //vb->addWidget(lbl);


  int c = giti.series_column() - 1;

  int level = c/level_size_;
  int index = c%level_size_;

  {
   int g = giti.grouping();

   QColor c;
   init_color_from_grouping(c, g);

   QPixmap px = *lbl->pixmap();

   QPainter p(&px);
   QPen pen = QPen(c);
   pen.setWidth(8);
   p.setPen(pen);

//   QBrush qbr = QBrush(QColor::fromRgb(155, 0, 0, 10));
//   p.setBrush(qbr);

   p.drawRect(3, px.height() - 8, px.width()-8, 8);
   p.end();
   lbl->setPixmap(px);
  }

  main_layout_->addWidget(lbl, index, level);

  if(giti.series_column() == 0)
  {
   QPixmap px = *lbl->pixmap();


   QPainter p(&px);
   QPen pen = QPen(QColor::fromRgb(155, 155, 0, 100));
   pen.setWidth(6);
   p.setPen(pen);

   QBrush qbr = QBrush(QColor::fromRgb(155, 0, 0, 10));
   p.setBrush(qbr);

   p.drawRect(3, 3, px.width()-6, px.height()-6);
   p.end();
   lbl->setPixmap(px);

   current_clickable_label_ = lbl;
  }

  //graphics_series_layout_->addWidget(lbl);
  //qDebug()<<dirIt.filePath();
 }

 //?main_layout_->addStretch();
}

CyStage_Image_Tile* Series_Geometric_Wrapped_CH_1D_Panel::find_tile_by_name(QString name)
{
 if(current_tile_map_)
 {
  return current_tile_map_->value(name);
 }
 return nullptr;
}


