
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)



#ifndef SERIES_GEOMETRIC_WRAPPED_CH_1D_PANEL__H
#define SERIES_GEOMETRIC_WRAPPED_CH_1D_PANEL__H

#include <QObject>

#include <QMetaType>

#include <QList>
#include <QGraphicsScene>
#include <QPoint>

#include <QDialog>

#include <QFrame>

#include "subwindows/cystage-clickable-label.h"
#include "structures/geometric-image-tile-info.h"


#include "accessors.h"
#include "kans.h"


class QDialogButtonBox;
class QLabel;
class QLineEdit;
class QTabWidget;
class QTextEdit;
class QFrame;
class QHBoxLayout;
class QVBoxLayout;
class QSlider;
class QPlainTextEdit;
class QBoxLayout;
class QButtonGroup;
class QGroupBox;
class QScrollArea;
class QGridLayout;

#include <QSet>

KANS_(CYSTAGE)
//?namespace KA { namespace CYSTAGE {


class CyStage_Clickable_Label;
class CyStage_Image_Tile;


class Series_Geometric_Wrapped_CH_1D_Panel : public QFrame
{
 Q_OBJECT

//?
// QMap<QGraphicsPixmapItem*, QVector<QGraphicsItem*> > current_seli_specific_items_;
// QMap<QGraphicsPixmapItem*, QString> seli_names_;
// QMap<QString, QGraphicsPixmapItem*> inverse_seli_names_;

 //?QMap<QString, QPolygonF> polys_by_name_;

//? QLabel* current_seli_label_;
//? QMap<QGraphicsPixmapItem*, QLabel*> labels_to_items_;


 QGridLayout* main_layout_;

 CyStage_Clickable_Label* lbl_1_;
 CyStage_Clickable_Label* lbl_2_;

 QMap<QString, CyStage_Image_Tile*>* current_tile_map_;

 CyStage_Clickable_Label* current_clickable_label_;
 CyStage_Image_Tile* current_tile_;

 //Series_Geometric_Wrapped_1D_Panel*

 int level_size_;

 QSet<int> shown_groups_;

public:


 Series_Geometric_Wrapped_CH_1D_Panel(QWidget* parent = nullptr);

 ACCESSORS(CyStage_Clickable_Label* ,current_clickable_label)
 ACCESSORS(CyStage_Image_Tile* ,current_tile)
 ACCESSORS(int ,level_size)

 ~Series_Geometric_Wrapped_CH_1D_Panel();

 CyStage_Image_Tile* find_tile_by_name(QString name);

 static void init_color_from_grouping(QColor& c, int g);
 static void init_color_from_shown_grouping(QColor& c, int g);
 static void init_color_from_hidden_grouping(QColor& c, int g);

 void show_group(int g);
 void hide_group(int g);


 void open_folder(QString path);

 void display_tiles(QList<Geometic_Image_Tile_Info>& infos,
   QVector<CyStage_Image_Tile*>* tiles = nullptr,
   QMap<QString, int>* index_map = nullptr);

 void switch_tiles(CyStage_Image_Tile* new_tile);


Q_SIGNALS:

 void open_file_requested(QString path);

 void navigated_from_series(int r, int c);

//?public Q_SLOTS:


};

_KANS(CYSTAGE)


#endif  // SERIES_GEOMETRIC_1D_PANEL__H



