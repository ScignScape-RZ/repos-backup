
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)



#ifndef NAV_GEOMETRIC_2D_PANEL__H
#define NAV_GEOMETRIC_2D_PANEL__H

#include <QObject>

#include <QMetaType>

#include <QList>
#include <QGraphicsScene>
#include <QPoint>

#include <QDialog>

#include <QFrame>



#include "accessors.h"
#include "kans.h"


class QDialogButtonBox;
class QLabel;
class QLineEdit;
class QTabWidget;
class QTextEdit;
class QFrame;
class QHBoxLayout;
class QVBoxLayout;
class QSlider;
class QPlainTextEdit;
class QBoxLayout;
class QButtonGroup;
class QGroupBox;
class QScrollArea;
class QGridLayout;



//?KANS_(CYSTAGE)
namespace KA { namespace CYSTAGE {


class CyStage_Clickable_Label;
class CyStage_Image_Tile;


class NAV_Geometric2D_Panel : public QFrame
{
 Q_OBJECT

 QVBoxLayout* main_layout_;
 QHBoxLayout* navigation_layout_;


 QVBoxLayout* sort_series_layout_;

 CyStage_Image_Tile* current_tile_;

 QPushButton* tile_up_button_;
 QPushButton* tile_down_button_;
 QPushButton* tile_left_button_;
 QPushButton* tile_right_button_;

 QPushButton* tile_previous_button_;
 QPushButton* tile_next_button_;


 QGridLayout* navigation_buttons_layout_;
 QVBoxLayout* navigation_buttons_previous_next_layout_;

 QHBoxLayout* zoom_layout_;

 QButtonGroup* annotations_show_hide_button_group_;
 QLabel* annotations_show_hide_label_;
 QPushButton* annotations_show_button_;
 QPushButton* annotations_hide_button_;
 QVBoxLayout* annotations_show_hide_layout_;

 QVBoxLayout* zoom_row_column_layout_;
 QHBoxLayout* row_column_layout_;

 QLabel* row_label_;
 QLineEdit* row_line_edit_;
 QLabel* column_label_;
 QLineEdit* column_line_edit_;


// //  to be moved to WSI ...
// QLabel* abnormality_label_;
// QLineEdit* abnormality_line_edit_;


 QPushButton* zoom_in_button_;
 QPushButton* zoom_out_button_;

 QHBoxLayout* mode_button_layout_;

 QGroupBox* mode_group_box_;

 QHBoxLayout* combined_mode_button_layout_;
 QButtonGroup* mode_button_group_;
 QPushButton* mode_zoom_button_;
 QPushButton* mode_pan_button_;
 QPushButton* mode_slide_button_;

 QPushButton* current_mode_button_;

 QGroupBox* annotations_mode_group_box_;
 QButtonGroup* annotations_mode_button_group_;
 QHBoxLayout* annotations_mode_button_layout_;
 QPushButton* annotations_mode_pan_button_;
 QPushButton* annotations_mode_rotate_button_;
 QPushButton* annotations_mode_zoom_button_;

 QSlider* zoom_slider_;

 qreal old_zoom_slider_value_;

//? void check_tile_geometric_navigate(int r, int c);


public:

 NAV_Geometric2D_Panel(QWidget* parent = nullptr);

 ~NAV_Geometric2D_Panel();

 void set_row_text(int r);
 void set_column_text(int c);

Q_SIGNALS:
 void canceled(QDialog*);
 void accepted(QDialog*);

 void zoom_in_requested();
 void zoom_out_requested();
 void scale_ratio_change_requested(qreal ratio);


 void geometric_up_requested();
 void geometric_down_requested();
 void geometric_left_requested();
 void geometric_right_requested();
 void series_previous_requested();
 void series_next_requested();


public Q_SLOTS:

 void zoom_slider_value_changed(int);

 void set_row_and_column_text(int r, int c);


};

_KANS(CYSTAGE)


#endif  // NAV_GEOMETRIC_2D_PANEL__H



