
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)



#ifndef NAV_IMAGE_MULTISIZE_PANEL__H
#define NAV_IMAGE_MULTISIZE_PANEL__H

#include <QObject>

#include <QMetaType>

#include <QList>
#include <QGraphicsScene>
#include <QPoint>

#include <QDialog>

#include <QFrame>



#include "accessors.h"
#include "kans.h"


class QDialogButtonBox;
class QLabel;
class QLineEdit;
class QTabWidget;
class QTextEdit;
class QFrame;
class QHBoxLayout;
class QVBoxLayout;
class QSlider;
class QPlainTextEdit;
class QBoxLayout;
class QButtonGroup;
class QGroupBox;
class QScrollArea;
class QGridLayout;



//?KANS_(CYSTAGE)
namespace KA { namespace CYSTAGE {


class CyStage_Clickable_Label;
class CyStage_Image_Tile;


class NAV_Image_Multisize_Panel : public QFrame
{
 Q_OBJECT

 QVBoxLayout* main_layout_;
 QHBoxLayout* navigation_layout_;


 QVBoxLayout* sort_series_layout_;

 CyStage_Image_Tile* current_tile_;

 QPushButton* tile_larger_button_;
 QPushButton* tile_smaller_button_;

 QPushButton* tile_previous_group_button_;
 QPushButton* tile_next_group_button_;

 QGridLayout* navigation_buttons_layout_;
 QHBoxLayout* navigation_buttons_previous_next_layout_;

 QHBoxLayout* zoom_layout_;

 QVBoxLayout* zoom_row_column_layout_;
 QHBoxLayout* row_column_layout_;

 QLabel* row_label_;
 QLineEdit* row_line_edit_;
 QLabel* column_label_;
 QLineEdit* column_line_edit_;

 QPushButton* zoom_in_button_;
 QPushButton* zoom_out_button_;


 QSlider* zoom_slider_;

 qreal old_zoom_slider_value_;

//? void check_tile_geometric_navigate(int r, int c);


public:

 NAV_Image_Multisize_Panel(QWidget* parent = nullptr);

 ~NAV_Image_Multisize_Panel();

 void set_row_text(int r);
 void set_column_text(int c);

Q_SIGNALS:
 void canceled(QDialog*);
 void accepted(QDialog*);

 void zoom_in_requested();
 void zoom_out_requested();
 void scale_ratio_change_requested(qreal ratio);


 void multisize_larger_requested();
 void multisize_smaller_requested();
 void previous_group_requested();
 void next_group_requested();


public Q_SLOTS:

 void zoom_slider_value_changed(int);

 void set_row_and_column_text(int r, int c);


};

_KANS(CYSTAGE)


#endif  // NAV_IMAGE_MULTISIZE_PANEL__H



