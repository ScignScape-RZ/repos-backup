
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)



#include "cystage-navigation-protocol-dialog.h"

#include "styles.h"


#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QButtonGroup>
#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>
#include <QComboBox>

#include <QDateEdit>

#include <QLineEdit>
#include <QTextStream>

#include <QPainter>
#include <QPushButton>
#include <QLabel>

#include <QPlainTextEdit>

#include <QTableWidget>
#include <QGraphicsPixmapItem>

#include <QMessageBox>
#include <QDebug>

#include <QGraphicsView>


#include <QHeaderView>

#include <QMenu>
#include <QAction>

#include <QListWidget>
#include <QDateEdit>

//#include "mmui-ka-diagnostic-case.h"
//#include "mmui-ka-diagnostic-case-frame.h"

//?#include "png.h"
//?#include "png.hpp"

USING_KANS(CYSTAGE)


CyStage_Navigation_Protocol_Dialog::CyStage_Navigation_Protocol_Dialog(QWidget* parent)
  : QDialog(parent)
{

 button_box_ = new QDialogButtonBox(this);

 button_ok_ = new QPushButton("OK");
 button_proceed_ = new QPushButton("Proceed");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

 button_proceed_->setDefault(false);
 button_proceed_->setAutoDefault(false);
 //?button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);

 button_ok_->setStyleSheet(basic_button_style_sheet_());
 button_proceed_->setStyleSheet(basic_button_style_sheet_());
 button_cancel_->setStyleSheet(basic_button_style_sheet_());


 connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));

 button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);


 main_layout_ = new QVBoxLayout;

 main_tab_widget_ = new QTabWidget(this);
 main_frame_ = new QFrame(this);
 main_frame_layout_ = new QVBoxLayout;

 xml_text_edit_ = new QPlainTextEdit(this);
 ss_text_edit_ = new QPlainTextEdit(this);
 cl_text_edit_ = new QPlainTextEdit(this);

 info_form_layout_ = new QFormLayout;

 name_line_edit_ = new QLineEdit(this);
 name_line_edit_->setText("Series Order + Anatomical Reflections");

 xml_file_line_edit_ = new QLineEdit(this);
 xml_file_line_edit_->setText(DEFAULT_ASSETS_FOLDER "/navigation-protocols/soar.xml");

 ss_file_line_edit_ = new QLineEdit(this);
 ss_file_line_edit_->setText(DEFAULT_ASSETS_FOLDER "/navigation-protocols/soar.ss");

 info_form_layout_->addRow("Name", name_line_edit_);
 info_form_layout_->addRow("XML File", xml_file_line_edit_);
 info_form_layout_->addRow("ScignScript File", ss_file_line_edit_);

 main_frame_layout_->addLayout(info_form_layout_);
 concepts_group_box_ = new QGroupBox(this);
 concepts_form_layout_ = new QFormLayout;

 concepts_group_box_->setTitle("Navigational Concepts:");

 // // demo concepts ...

 QVector<QString> concepts = {"Saggital Reflection",
   "Transverse Reflection", "Coronal Reflection",
   "Series Previous", "Series Next"};

 QVector<QString> files = {"saggital.png",
   "transverse.svg", "coronal.jpg",
   "series-previous.svg", "series-next.svg"};

 QString image_base_path = DEFAULT_ICON_FOLDER "/navigation-protocols/anatomical3d/";

 int i = 0;

 for(QString file : files)
 {
  QString concept = concepts[i];

  ++i;

  QLabel* concept_name = new QLabel(concept, this);
  QLabel* concept_image = new QLabel(this);

//  QString f = image_base_path + file;

//  qDebug() << f;

  concept_image->setPixmap(QPixmap::fromImage
    (QImage(image_base_path + file)));

  concept_image->setScaledContents( true );

  concept_image->setSizePolicy( QSizePolicy::Ignored, QSizePolicy::Ignored );

  concept_image->setMaximumWidth(40);

  concept_name->setMinimumWidth(140);

  concepts_form_layout_->addRow(concept_name, concept_image);
 }


 concepts_group_box_->setLayout(concepts_form_layout_);

 main_frame_layout_->addWidget(concepts_group_box_);

 main_frame_->setLayout(main_frame_layout_);

 main_tab_widget_->addTab(main_frame_, "Overview");
 main_tab_widget_->addTab(xml_text_edit_, "XML");
 main_tab_widget_->addTab(ss_text_edit_, "ScignScript");
 main_tab_widget_->addTab(cl_text_edit_, "Lisp");

 main_layout_->addWidget(main_tab_widget_);


// info_form_position_layout_->addStretch();
// info_form_position_layout_->addLayout(info_form_layout_);
// info_form_position_layout_->addStretch();

 main_layout_->addStretch();

// main_layout_->addLayout(info_form_position_layout_);
 main_layout_->addWidget(button_box_);



 //?main_layout_->addLayout(clear_button_layout_);

 setLayout(main_layout_);

 show();
}




CyStage_Navigation_Protocol_Dialog::~CyStage_Navigation_Protocol_Dialog()
{
 delete button_ok_;
 delete button_proceed_;
 delete button_cancel_;

// delete url_label_;
// delete name_ qLe_;
}



void CyStage_Navigation_Protocol_Dialog::cancel()
{
 Q_EMIT(rejected());
 Q_EMIT(canceled(this));
 Q_EMIT(rejected());
 close();
//
}

void CyStage_Navigation_Protocol_Dialog::accept()
{
 Q_EMIT(accepted(this));
// close();
}


