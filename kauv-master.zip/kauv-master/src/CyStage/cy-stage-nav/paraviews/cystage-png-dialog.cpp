
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)



#include "cystage-png-dialog.h"

#include "styles.h"


#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QButtonGroup>
#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>
#include <QComboBox>

#include <QDateEdit>

#include <QLineEdit>
#include <QTextStream>

#include <QPainter>
#include <QPushButton>
#include <QLabel>

#include <QPlainTextEdit>

#include <QTableWidget>
#include <QGraphicsPixmapItem>

#include <QMessageBox>
#include <QDebug>

#include <QGraphicsView>


#include <QHeaderView>

#include <QMenu>
#include <QAction>

#include <QListWidget>
#include <QDateEdit>


#include "png.h"
//#include "png.hpp"


USING_KANS(CYSTAGE)


CYSTAGE_PNG_Dialog::CYSTAGE_PNG_Dialog(QString file_path, QWidget* parent)
  : QDialog(parent), file_path_(file_path)
{
 //?arrow_factory_ = new MMUI_Arrow_Factory;

 button_box_ = new QDialogButtonBox(this);

 button_ok_ = new QPushButton("OK");
 button_proceed_ = new QPushButton("Proceed");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

 button_proceed_->setDefault(false);
 button_proceed_->setAutoDefault(false);
 //?button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);

 button_ok_->setStyleSheet(basic_button_style_sheet_());
 button_proceed_->setStyleSheet(basic_button_style_sheet_());
 button_cancel_->setStyleSheet(basic_button_style_sheet_());


 connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));

 button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);


 main_layout_ = new QVBoxLayout;

 image_layout_ = new QHBoxLayout;

 image_label_ = new QLabel("Image ...", this);

 image_pixmap_ = new QPixmap(QPixmap(file_path).scaledToHeight(100));
 image_label_->setPixmap(*image_pixmap_);

 scrolled_image_pixmap_ = new QPixmap(file_path);


 scrolled_image_view_ = new QGraphicsView(this);
 scrolled_image_scene_ = new QGraphicsScene(this);
  //?scrolled_image_label_ = new QLabel("Scrolled Image ...", this);
  //?scrolled_image_label_->setPixmap(*scrolled_image_pixmap_);

 scrolled_image_view_->setScene(scrolled_image_scene_);

 scrolled_image_pixmap_item_ = scrolled_image_scene_->addPixmap(*scrolled_image_pixmap_);
 scrolled_image_pixmap_item_->setPos(0,0);

 scrolled_image_view_->setFixedHeight(100);
 scrolled_image_view_->setFixedWidth(200);

//? image_scroll_area_ = new QScrollArea(this);
//? image_scroll_area_->setWidget(scrolled_image_view_);

 //image_scroll_area_->setGeometry(0, 0, 300, 100);

//? image_scroll_area_->setFixedHeight(100);
//? image_scroll_area_->setFixedWidth(200);

 //image_pixmap_->setDevicePixelRatio(0.5);

 image_layout_->addWidget(image_label_);
 //?image_layout_->addWidget(image_scroll_area_);
 image_layout_->addWidget(scrolled_image_view_);

 image_layout_->addStretch();

 main_layout_->addLayout(image_layout_);

 parse_image_info();

 info_form_position_layout_ = new QHBoxLayout;

 info_form_layout_ = new QFormLayout;

 QMapIterator<QString, QString> it(image_property_data_);

 while(it.hasNext())
 {
  it.next();

  QString key = it.key();

  key.replace('-', ' ').append(':');

  info_form_layout_->addRow(key, new QLabel(it.value(), this));

 }

 info_form_position_layout_->addStretch();
 info_form_position_layout_->addLayout(info_form_layout_);
 info_form_position_layout_->addStretch();

 main_layout_->addStretch();

 main_layout_->addLayout(info_form_position_layout_);
 main_layout_->addWidget(button_box_);



 //?main_layout_->addLayout(clear_button_layout_);

 setLayout(main_layout_);

 show();
}


void CYSTAGE_PNG_Dialog::parse_image_info()
{
 png::image<png::rgb_pixel> png_image(file_path_.toStdString());

 //?
 image_property_data_["color-type"] = "Palette";
 image_property_data_["color-mask"] = "RGB";

 image_property_data_["bit-depth"] = QString::number(png_image.m_info.get_bit_depth());

 //?png_image.m_info.

//?
 png::color_type color_type = png_image.m_info.get_color_type();

//?#ifdef HIDE
//? png::color_type color_type = png_image.get_color_type();
//#endif
 switch(color_type)
 {
 case png::color_type_none:
  image_property_data_["color-type"] = "None";
  break;
 case png::color_type_gray:
  image_property_data_["color-type"] = "Gray";
  break;
 case png::color_type_palette:
  image_property_data_["color-type"] = "Palette";
  break;
 case png::color_type_rgb:
  image_property_data_["color-type"] = "RGB";
  break;
 case png::color_type_rgb_alpha:
  image_property_data_["color-type"] = "RGB Alpha";
  break;
 case png::color_type_gray_alpha:
  image_property_data_["color-type"] = "Gray Alpha";
  break;

//?
// case png::color_type_rgba:
//  image_property_data_["color-type"] = "RGBA";
//  break;
//?
// case png::color_type_ga:
//  image_property_data_["color-type"] = "GA";
//  break;
 }
//#endif

#ifdef HIDE
 png::color_mask color_mask = png_image.get_color_mask();
 switch(color_mask)
 {
 case png::color_mask_palette:
  image_property_data_["color-mask"] = "Palette";
  break;
 case png::color_mask_color:
  image_property_data_["color-mask"] = "Color";
  break;
 case png::color_mask_rgb:
  image_property_data_["color-mask"] = "RGB";
  break;
 case png::color_mask_alpha:
  image_property_data_["color-mask"] = "Alpha";
  break;
 }
#endif //?  HIDE

#ifdef HIDE
 png::compression_type filler_type = png_image.get_filler_type();
 switch(filler_type)
 {
 case png::filler_before:
  image_property_data_["filler-type"] = "Before";
  break;
 case png::filler_after:
  image_property_data_["filler-type"] = "After";
  break;
 }
#endif //?  HIDE


#ifdef HIDE
 png::compression_type rgb_to_gray_error_action = png_image.get_rgb_to_gray_error_action();
 switch(rgb_to_gray_error_action)
 {
 case png::rgb_to_gray_silent:
  image_property_data_["rgb-to-gray-error-action"] = "Silent";
  break;
 case png::rgb_to_gray_warning:
  image_property_data_["rgb-to-gray-error-action"] = "Warning";
  break;
 case png::rgb_to_gray_error:
  image_property_data_["rgb-to-gray-error-action"] = "Error";
  break;
 }
#endif

 png::interlace_type interlace_type = png_image.get_interlace_type();
 switch(interlace_type)
 {
 case png::interlace_none:
  image_property_data_["interlace-type"] = "None";
  break;
 case png::interlace_adam7:
  image_property_data_["interlace-type"] = "Adam7";
  break;
 }


 png::compression_type ct = png_image.get_compression_type();
 switch(ct)
 {
 case png::compression_type_base:
  image_property_data_["compression-type"] = "Base";
  break;
//? case png::compression_type_default:
//  image_property_data_["compression-type"] = "Default";
//  break;
 }

 png::filter_type filter_type = png_image.get_filter_type();
 switch(filter_type)
 {
 case png::filter_type_base:
  image_property_data_["filter-type"] = "Base";
  break;
 case png::intrapixel_differencing:
  image_property_data_["filter-type"] = "Intrapixel Differencing";
  break;
//?
// case png::filter_type_default:
//  image_property_data_["filter-type"] = "Default";
//  break;
 }


}



CYSTAGE_PNG_Dialog::~CYSTAGE_PNG_Dialog()
{
 delete button_ok_;
 delete button_proceed_;
 delete button_cancel_;

// delete url_label_;
// delete name_ qLe_;
}



void CYSTAGE_PNG_Dialog::cancel()
{
 Q_EMIT(rejected());
 Q_EMIT(canceled(this));
 Q_EMIT(rejected());
 close();
//
}

void CYSTAGE_PNG_Dialog::accept()
{
 Q_EMIT(accepted(this));
// close();
}


