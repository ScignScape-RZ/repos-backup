
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)



#ifndef CYSTAGE_IMAGE_COLLECTION__H
#define CYSTAGE_IMAGE_COLLECTION__H


#include "accessors.h"

#include <QPen>
#include <QBrush>
#include <QString>


class QObject;


#endif  //  CYSTAGE_IMAGE_COLLECTION__H
