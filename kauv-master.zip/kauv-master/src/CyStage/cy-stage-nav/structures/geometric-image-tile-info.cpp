
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)



#include "geometric-image-tile-info.h"


Geometic_Image_Tile_Info::Geometic_Image_Tile_Info(QString name, QString absolute_path)
  : name_(name), absolute_path_(absolute_path),
    series_row_(-1), series_column_(-1), grouping_(-1)
{

}

