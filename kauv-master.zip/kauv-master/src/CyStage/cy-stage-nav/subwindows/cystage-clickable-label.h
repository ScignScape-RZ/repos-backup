
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)


#ifndef CyStage_Clickable_Label__H
#define CyStage_Clickable_Label__H

#include <QLabel>

#include "kans.h"

KANS_(CYSTAGE)
//?namespace KA { namespace CYSTAGE {


class CyStage_Clickable_Label : public QLabel
{
    Q_OBJECT

public:
    explicit CyStage_Clickable_Label(QWidget* parent = Q_NULLPTR, Qt::WindowFlags f = Qt::WindowFlags());
    ~CyStage_Clickable_Label();


 QString path;

Q_SIGNALS:
    void clicked();

protected:
    void mousePressEvent(QMouseEvent* event);

};

_KANS(CYSTAGE)

#endif  // CyStage_Clickable_Label__H
