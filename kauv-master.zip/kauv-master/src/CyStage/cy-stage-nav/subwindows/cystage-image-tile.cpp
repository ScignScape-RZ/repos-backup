
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)


#include "cystage-image-tile.h"

USING_KANS(CYSTAGE)


CyStage_Image_Tile::CyStage_Image_Tile(QString local_path) //, int series_row, int series_column)
  : local_path_(local_path),
//    series_row_(series_row),
//    series_column_(series_column),
    associated_qobject_(nullptr)
//    geometric_previous_(nullptr),
//    geometric_next_(nullptr)
{

}

void CyStage_Image_Tile::set_dimensional_annotation(int index, int value)
{
 int s = dimensional_annotations_.size();

 for(int i = s; i <= index; ++i)
 {
  dimensional_annotations_.push_back(-1);
 }

 dimensional_annotations_[index] = value;

}

int CyStage_Image_Tile::get_dimensional_annotation(int index)
{
 return dimensional_annotations_.value(index, -1);
}


// ... add_tile_segment(int x, int y, int width, int height)
//{
// tile_segments_.push_back(WSI_Tile_Segment(x, y, width, height));
//}
