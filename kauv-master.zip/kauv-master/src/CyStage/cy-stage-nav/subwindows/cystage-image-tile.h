
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)


#ifndef CYSTAGE_IMAGE_TILE__H
#define CYSTAGE_IMAGE_TILE__H


#include "accessors.h"
#include "kans.h"

#include <QPen>
#include <QBrush>
#include <QString>

#include <QVector>

class QObject;


KANS_(CYSTAGE)


class CyStage_Image_Tile
{
 QString local_path_;
 QString absolute_path_;

 QObject* associated_qobject_;

 QVector<int> dimensional_annotations_;

 CyStage_Image_Tile* series_previous_;
 CyStage_Image_Tile* series_next_;

public:


 CyStage_Image_Tile(QString local_path);

 ACCESSORS(QObject* ,associated_qobject)

 ACCESSORS(QString ,local_path)
 ACCESSORS(QString ,absolute_path)

 ACCESSORS(CyStage_Image_Tile* ,series_previous)
 ACCESSORS(CyStage_Image_Tile* ,series_next)



 void set_dimensional_annotation(int index, int value);
 int get_dimensional_annotation(int index);


};

_KANS(CYSTAGE)



#endif  //  CYSTAGE_IMAGE_TILE__H
