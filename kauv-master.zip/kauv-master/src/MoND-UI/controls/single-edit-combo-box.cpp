
#include "single-edit-combo-box.h"

#include <QDebug>

Single_Edit_Combo_Box::Single_Edit_Combo_Box(QWidget *parent)
 : QComboBox(parent), single_edit_item_index_(0)
{


}

void Single_Edit_Combo_Box::add_single_edit_item(QString label,
  QString edit_label, QVariant user_data)
{
 single_edit_item_index_ = count();
 single_edit_item_label_ = label;
 single_edit_item_edit_label_ = edit_label;

 addItem(label, user_data);

 connect(this,
   static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged),
   [this](int index)
 {
  if(index == single_edit_item_index_)
  {
   setItemText(single_edit_item_index_, last_single_edit_text_);
   if(count() > single_edit_item_index_ + 1)
   {
    removeItem(single_edit_item_index_ + 1);
   }
   setEditable(true);
  }
  else if(index == single_edit_item_index_ + 1)
  {
   setEditable(false);
   if(!single_edit_text_.isEmpty())
   {
    setItemText(single_edit_item_index_ + 1, single_edit_text_);
    last_single_edit_text_ = single_edit_text_;
    single_edit_text_.clear();
    setItemText(single_edit_item_index_, single_edit_item_edit_label_);
   }
  }
  else
  {
   setEditable(false);
   if(!single_edit_text_.isEmpty())
   {
    setItemText(single_edit_item_index_ + 1, single_edit_text_);
    last_single_edit_text_ = single_edit_text_;
    single_edit_text_.clear();
    setItemText(single_edit_item_index_, single_edit_item_label_);
   }
  }
 }
 );


 connect(this,
   static_cast<void (QComboBox::*)(const QString&)>(&QComboBox::currentTextChanged),
   [this](const QString& text)
 {
  // //  Only when editable is true do we get here
   //    by users actually trying to edit ...
  if(isEditable())
  {
   single_edit_text_ = text;
  }
 }
 );


}
