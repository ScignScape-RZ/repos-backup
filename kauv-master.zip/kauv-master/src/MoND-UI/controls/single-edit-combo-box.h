
#ifndef SINGLE_EDIT_COMBO_BOX__H
#define SINGLE_EDIT_COMBO_BOX__H

#include <QObject>

#include <QMetaType>

#include <QColor>
#include <QBrush>
#include <QPen>

#include <QComboBox>

#include "accessors.h"


class Single_Edit_Combo_Box : public QComboBox
{
 QString single_edit_text_;
 QString last_single_edit_text_;

 int single_edit_item_index_;

 QString single_edit_item_label_;
 QString single_edit_item_edit_label_;

public:

 Single_Edit_Combo_Box(QWidget* parent);

 void add_single_edit_item(QString label,
   QString edit_label_, QVariant user_data = QVariant());

};


#endif  // MMUI_ARROW_FACTORY__H
