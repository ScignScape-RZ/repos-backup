
#include "ka-email-message-handler.h"
#include "ka-email-message.h"

#include "kans.h"

#include <QPixmap>

#include <QRegularExpression>

USING_KANS(GUI)



KA_Email_Message_Handler::KA_Email_Message_Handler(KA_Email_Message* message)
 : message_(message)
{
}

void KA_Email_Message_Handler::do_send(std::function<void (Send_Result)> callback)
{
 SmtpClient smtp("smtp.gmail.com", 465, SmtpClient::SslConnection);

 // We need to set the username (your email address) and password
 // for smtp authentification.

 smtp.setUser(message_->smtp_address()); //"axiatropicsemantics@gmail.com");
 smtp.setPassword(message_->smtp_password()); //"vancouver2011FC");

 // Now we create a MimeMessage object. This is the email.

 MimeMessage mm;

 EmailAddress sender(message_->sender_address(), message_->sender_name()); //, "axiatropicsemantics@gmail.com", "Nathaniel Christen");
 mm.setSender(&sender);

 QStringList recipient_names;
 QStringList recipient_addresses;

 if(message_->recipient_name().startsWith('/') || message_->recipient_name().startsWith('~'))
 {
  read_recipients_from_file(message_->recipient_name(), recipient_names, recipient_addresses);
 }
 else
 {
  recipient_names = message_->recipient_name().split("+");
  recipient_addresses = message_->recipient_address().split("+");
 }

 int i = 0;
 int max = recipient_names.size() - 1;
 for(QString ra : recipient_addresses)
 {
  QString rn = recipient_names[i].simplified();
  if(i < max)
  {
   ++i;
  }
  EmailAddress* recipient = new EmailAddress(ra.simplified(), rn);
  mm.addRecipient(recipient);
 }

 mm.setSubject(message_->subject());

 // Now add some text to the email.
 // First we create a MimeText object.

 MimeHtml html;
 MimeText text;

 if(message_->message_body().trimmed().startsWith("<html"))
 {
  html.setText(message_->message_body());
  mm.addPart(&html);
 }
 else
 {
  text.setText(message_->message_body());
  mm.addPart(&text);
 }

 if(message_->pixmap())
 {
  QString path = __FILE__ ".jpeg";


  message_->pixmap()->save(path, "jpeg", 100);
  mm.addPart(new MimeAttachment(new QFile(path)));

 }

 // Now we can send the mail

 if (!smtp.connectToHost()) {
   callback(Send_Result::Failed_to_Connect);
   smtp.quit();
   return;
   //?  qDebug() << "Failed to connect to host!" << endl;
   //?  return -1;
 }

 if (!smtp.login()) {
   callback(Send_Result::Failed_to_Login);
   smtp.quit();
   return;
  //?   qDebug() << "Failed to login!" << endl;
  //?   return -2;
 }

 if (!smtp.sendMail(mm)) {
  callback(Send_Result::Failed_to_Send);

  smtp.quit();
  return;
  //?   qDebug() << "Failed to send mail!" << endl;
  //?   return -3;
 }

 smtp.quit();
 callback(Send_Result::OK);
}

void KA_Email_Message_Handler::read_recipients_from_file(QString path, QStringList& names, QStringList& addresses)
{
 QFile file(path);
 if(file.open(QIODevice::ReadOnly | QIODevice::Text ))
 {
  QTextStream in_stream(&file);
  QString contents = in_stream.readAll();

  QStringList qsl = contents.split(QRegularExpression("\\s+::\\s+"));

  QString name;
  QString address;

  for(QString s : qsl)
  {
   if(name.isEmpty())
    name = s.simplified();
   else
   {
    address = s.simplified();
    names.push_back(name);
    addresses.push_back(address);
    name.clear();
   }

  }

 }



}

QString KA_Email_Message_Handler::to_string()
{
 QString result;

 if(message_)
 {
  result += "\nSmtp Address: " + message_->smtp_address();
  result += "\nSmtp Password: " + message_->smtp_password();

  result += "\nSN: " + message_->sender_name();
  result += "\nSA: " + message_->sender_address();

  result += "\nRN: " + message_->recipient_name();
  result += "\nRA: " + message_->recipient_address();
  result += "\nS: " + message_->subject();

  result += "\nMB: " + message_->message_body();
 }

 return result;
}

