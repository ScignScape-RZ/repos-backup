
#ifndef KA_EMAIL_MESSAGE_HANDLER__H
#define KA_EMAIL_MESSAGE_HANDLER__H


#include "kans.h"
#include "accessors.h"

#include <QString>
#include <QMap>

#include <functional>


// ?
#include "SmtpMime"


KANS_(GUI)


class KA_Email_Message;


class KA_Email_Message_Handler
{

 KA_Email_Message* message_;


public:

 enum class Send_Result {
   N_A, OK, Failed_to_Connect, Failed_to_Login, Failed_to_Send
  };

 KA_Email_Message_Handler(KA_Email_Message* message);

 QString to_string();
 void do_send(std::function<void (Send_Result)> callback);

 void read_recipients_from_file(QString path, QStringList& names, QStringList& addresses);

};

} }
//_kaNS(GUI)




#endif
