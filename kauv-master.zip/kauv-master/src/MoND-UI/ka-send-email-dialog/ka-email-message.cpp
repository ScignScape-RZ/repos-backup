
#include "ka-email-message.h"

#include "kans.h"

#include <QIODevice>
#include <QDataStream>


USING_KANS(GUI)

KA_Email_Message::KA_Email_Message(QStringList args) : pixmap_(nullptr)
{
 QString* field = nullptr;

 QString unknown_field_key;
 QString unknown_field_value;

 for(QString s: args)
 {
  if(field)
  {
   *field = s;
   field = nullptr;
  }
  else
  {
   Fields f = parse_field(s, &field);
   switch(f)
   {
   case Fields::N_A:
    unknown_field_key = s;
    field = &unknown_field_value;
    // // Handle unknown field? ...
    break;

   default:
    break;

   }
  }

 }

}


KA_Email_Message::KA_Email_Message()
{

}

void KA_Email_Message::supply_data(QByteArray& qba) const
{
 QDataStream qds(&qba, QIODevice::WriteOnly);

 qds << smtp_address_;
 qds << smtp_password_;

 qds << sender_name_;
 qds << sender_address_;

 qds << recipient_name_;
 qds << recipient_address_;

 qds << subject_;

 qds << message_body_;
}


void KA_Email_Message::absorb_data(const QByteArray& qba)
{
 QDataStream qds(qba);

 qds >> smtp_address_;
 qds >> smtp_password_;

 qds >> sender_name_;
 qds >> sender_address_;

 qds >> recipient_name_;
 qds >> recipient_address_;

 qds >> subject_;

 qds >> message_body_;
}


