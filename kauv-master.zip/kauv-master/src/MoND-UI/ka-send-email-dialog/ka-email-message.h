
#ifndef KA_EMAIL_MESSAGE__H
#define KA_EMAIL_MESSAGE__H


#include "kans.h"
#include "accessors.h"

#include <QString>
#include <QMap>


class QPixmap;


KANS_(GUI)


class KA_Email_Message
{
 QString smtp_address_;
 QString smtp_password_;

 QString sender_name_;
 QString sender_address_;

 QString recipient_name_;
 QString recipient_address_;

 QString subject_;

 QString message_body_;

 enum class Fields {
   N_A,  Smtp_Address, Smtp_Password,  Sender_Name, Sender_Address,
   Recipient_Name, Recipient_Address, Subject, Message_Body
 };

 Fields parse_field(QString key, QString** field = nullptr)
 {
  static QMap<QString, QPair<Fields, QString*>> static_map {{
   { "smtp-address", {Fields::Smtp_Password, &smtp_address_} },
   { "smtp-password", {Fields::Smtp_Address, &smtp_password_} },
   { "sender-name", {Fields::Sender_Name, &sender_name_} },
   { "sender-address", {Fields::Sender_Address, &sender_address_} },
   { "recipient-name", {Fields::Recipient_Name, &recipient_name_} },
   { "recipient-address", {Fields::Recipient_Address, &recipient_address_} },
   { "subject", {Fields::Subject, &subject_} },
   { "message-body", {Fields::Message_Body, &message_body_} }
                                           }};

  QPair<Fields, QString*> result_pair = static_map.value(key, {Fields::N_A, nullptr});

  if(field)
  {
   if(result_pair.second)
   {
    *field = result_pair.second;
   }
  }

  return result_pair.first;
 }

 const QPixmap* pixmap_;

public:

 ACCESSORS(QString ,smtp_address)
 ACCESSORS(QString ,smtp_password)

 ACCESSORS(QString ,sender_name)
 ACCESSORS(QString ,sender_address)

 ACCESSORS(QString ,recipient_name)
 ACCESSORS(QString ,recipient_address)

 ACCESSORS(QString ,subject)
 ACCESSORS(const QPixmap* ,pixmap)

 ACCESSORS(QString ,message_body)

 KA_Email_Message(QStringList args);
 KA_Email_Message();

 void supply_data(QByteArray& qba) const;
 void absorb_data(const QByteArray& qba);



};

} }
//_kaNS(GUI)




#endif
