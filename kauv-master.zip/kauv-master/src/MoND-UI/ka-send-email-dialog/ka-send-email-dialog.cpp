
#include "ka-send-email-dialog.h"
#include "ka-email-message.h"

#include <QLabel>

#include "kans.h"

USING_KANS(GUI)


KA_Send_Email_Dialog::KA_Send_Email_Dialog(QWidget *parent, const KA_Email_Message& rem, const QPixmap* const pixmap)
 : QDialog(parent), pixmap_(pixmap)
{

 main_layout_ = new QVBoxLayout;

 message_layout_ = new QFormLayout;

 smtp_address_line_edit_ = new QLineEdit(rem.smtp_address(), this);
 smtp_password_line_edit_ = new QLineEdit(rem.smtp_password(), this);


 sender_name_line_edit_ = new QLineEdit(rem.sender_name(), this);
 sender_address_line_edit_ = new QLineEdit(rem.sender_address(), this);

 recipient_name_line_edit_ = new QLineEdit(rem.recipient_name(), this);
 recipient_address_line_edit_ = new QLineEdit(rem.recipient_address(), this);

 subject_line_edit_ = new QLineEdit(rem.subject(), this);

 message_body_text_edit_ = new QPlainTextEdit(rem.message_body(), this);


 status_line_edit_ = new QLineEdit(this);

 message_layout_->addRow("SMTP (address):", smtp_address_line_edit_);
 message_layout_->addRow("SMTP (password):", smtp_password_line_edit_);

 message_layout_->addRow("Sender (name):", sender_name_line_edit_);
 message_layout_->addRow("Sender (email):", sender_address_line_edit_);

 message_layout_->addRow("Recipient (name):", recipient_name_line_edit_);
 message_layout_->addRow("Recipient (address):", recipient_address_line_edit_);

 message_layout_->addRow("Subject:", subject_line_edit_);
 message_layout_->addRow("Main Text:", message_body_text_edit_);

 if(pixmap)
 {
  QLabel* pl = new QLabel(this);
  pl->setPixmap(pixmap->scaledToHeight(150, Qt::SmoothTransformation));
  message_layout_->addRow("Attach:", pl);
 }

 message_layout_->addRow("Status:", status_line_edit_);

 main_layout_->addLayout(message_layout_);

 button_box_ = new QDialogButtonBox(this);

 button_ok_ = new QPushButton("OK");
 button_send_ = new QPushButton("Send");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

 button_send_->setDefault(false);
 button_send_->setAutoDefault(false);

 button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_send_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);


 connect(button_send_, SIGNAL(clicked()), this, SLOT(handle_send()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));

 main_layout_->addWidget(button_box_);

 setLayout(main_layout_);

 show();
}


void KA_Send_Email_Dialog::convey_send_result(KA_Email_Message_Handler::Send_Result sr)
{
 switch(sr)
 {
 case KA_Email_Message_Handler::Send_Result::Failed_to_Connect:
  status_line_edit_->setText("Failed to Connect");
  break;

 case KA_Email_Message_Handler::Send_Result::Failed_to_Login:
  status_line_edit_->setText("Failed to Login");
  break;

 case KA_Email_Message_Handler::Send_Result::Failed_to_Send:
  status_line_edit_->setText("Failed to Send");
  break;

 case KA_Email_Message_Handler::Send_Result::OK:
  status_line_edit_->setText("OK");
  break;

 default:
  status_line_edit_->setText("Failed to Send (unspecified error)");
  break;

 }
}


KA_Send_Email_Dialog::~KA_Send_Email_Dialog()
{

}

void KA_Send_Email_Dialog::handle_send()
{
 KA_Email_Message* rem = new KA_Email_Message({
  "smtp-address" ,smtp_address_line_edit_->text(),
  "smtp-password" ,smtp_password_line_edit_->text(),
  "sender-name" ,sender_name_line_edit_->text(),
  "sender-address" ,sender_address_line_edit_->text(),
  "recipient-name" ,recipient_name_line_edit_->text(),
  "recipient-address" ,recipient_address_line_edit_->text(),
  "subject" ,subject_line_edit_->text(),
  "message-body" ,message_body_text_edit_->document()->toPlainText(),
 });

 if(pixmap_)
 {
  rem->set_pixmap(pixmap_);
 }

 Q_EMIT send_requested(this, rem);
}

void KA_Send_Email_Dialog::cancel()
{
 Q_EMIT canceled(this);

}
