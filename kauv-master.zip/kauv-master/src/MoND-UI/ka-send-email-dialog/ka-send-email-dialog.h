
#ifndef KA_SEND_EMAIL_DIALOG__H
#define KA_SEND_EMAIL_DIALOG__H


#include <QDialog>

#include <QLineEdit>
#include <QTextEdit>
#include <QPlainTextEdit>
#include <QVBoxLayout>
#include <QDialogButtonBox>
#include <QPushButton>
#include <QFormLayout>
#include <QPixmap>

#include "ka-email-message-handler.h"

//KANS_(GUI)
namespace KA{ namespace GUI{


class KA_Email_Message;

class KA_Send_Email_Dialog  : public QDialog
{
 Q_OBJECT

 const QPixmap* const pixmap_;

 QLineEdit* smtp_address_line_edit_;
 QLineEdit* smtp_password_line_edit_;

 QLineEdit* sender_name_line_edit_;
 QLineEdit* sender_address_line_edit_;

 QLineEdit* recipient_name_line_edit_;
 QLineEdit* recipient_address_line_edit_;

 QLineEdit* subject_line_edit_;

 QPlainTextEdit* message_body_text_edit_;

 QLineEdit* status_line_edit_;

 QVBoxLayout* main_layout_;
 QFormLayout* message_layout_;

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QPushButton* button_send_;


public:

 KA_Send_Email_Dialog(QWidget* parent,
   const KA_Email_Message& kem, const QPixmap* const pixmap = nullptr);
 ~KA_Send_Email_Dialog();

 void convey_send_result(KA_Email_Message_Handler::Send_Result sr);

public Q_SLOTS:

 void handle_send();
 void cancel();

Q_SIGNALS:

 void canceled(QDialog*);
 void send_requested(KA_Send_Email_Dialog*, KA_Email_Message*);
 void accepted();


};

} }
//_kaNS(GUI)




#endif
