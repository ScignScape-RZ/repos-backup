
#ifndef KAUV_CAF_REQUEST_PARSER__H
#define KAUV_CAF_REQUEST_PARSER__H

#include <QString>


//#include <boost/asio.hpp>
//#include <boost/regex.hpp>
//#include <boost/algorithm/string/predicate.hpp>
//#include <boost/functional/hash.hpp>
//#include <boost/filesystem.hpp>
//#include <unordered_map>
//#include <thread>
//#include <functional>
//#include <iostream>
//

#include <sstream>

//#include <string>


// // // added_
//#include "../http_parser.h"
//#include "../accessors.h"
//#include "../data/mmui-data-manager.h"

#include <QUrlQuery>

#include <QDebug>


typedef std::map<std::string, std::string> string_map;
typedef std::list<std::string> string_list;

string_list split(const std::string & s, const std::string & delim,
  bool keep_empty = true);

namespace ParseWebData {

/*!
 * Map string -> string
 */
typedef std::map<std::string, std::string> string_map;

/*!
 * Passed variable structure
 */
struct WebData {
 WebData() {
 }
 WebData(QString _value) : //const std::string& _value) :
   value(_value) {
 }
 /*!
  * Value of variable
  */
 //?std::string
 QString value;
 /*!
  * Additional attributes of variable
  */
 QMultiMap<QString, QString> attributes;
};

/*!
 * Map Variable name to variable structure
 */
typedef std::map<QString, WebData> WebDataMap;
}

void map_pairs(const std::string& s, const std::string& elemDelim,
  const std::string& pairDelim, QMultiMap<QString, QString>& result);

namespace ParseWebData {
namespace ParseMultipartFormData {

class ParseData {
public:
 ParseData(WebDataMap& _dataMap) :
   dataMap(_dataMap) {
 }
 void operator()(std::string data) {
  WebData outData;
  std::istringstream dataStream(data);
  std::string header;
  while (true) {
   std::string line;
   std::getline(dataStream, line);
   if (line.rfind('\r') == line.length() - 1)
    line.erase(line.rfind('\r'), 1);
   if (line.empty())
    break;
   header += line + "\n";
  }
  //QMultiMap<QString, QString>
  //outData.attributes =
  map_pairs(header, "\n", ": ", outData.attributes);
   //if(outData.attributes.contains("Content-Disposition"))
  //?string_map::iterator
  QMultiMap<QString, QString>::Iterator iter = outData.attributes.find("Content-Disposition");
  if (iter != outData.attributes.end())
  {
   QMultiMap<QString, QString> extraParam;

   QString teq = QString("type=%1").arg(iter.value());

   //?string_map extraParam =
   map_pairs(
     teq.toStdString(), "; ", "=", extraParam);
   //?outData.attributes.erase(iter);
   //?

   QMapIterator<QString, QString> it(extraParam);

   while(it.hasNext())
   {
    it.next();

    QString k = it.key();
    QString v = it.value();

    outData.attributes.insertMulti(it.key(), it.value());
    //outData.attributes.insert(extraParam.begin(), extraParam.end());

    //outData.attributes.

   }
  }

  //?for (iter = outData.attributes.begin();
  //?  iter != outData.attributes.end(); ++iter)

  QString new_v;

  QMutableMapIterator<QString, QString> it(outData.attributes);
  while(it.hasNext())
  {
   it.next();

   QString qk = it.key();
   QString& qv = it.value();


   std::string k = it.key().toStdString();
   std::string v = qv.toStdString();

   std::string::size_type start = v.find_first_not_of(
     "\"");
   std::string::size_type stop = v.find_last_not_of("\"");
   if (start == std::string::npos)
    v.clear();
   else
    v = v.substr(start, stop - start + 1);

   qv = QString::fromStdString(v);

  }

  std::ostringstream valueStream;
  std::copy(std::istreambuf_iterator<char>(dataStream),
    std::istreambuf_iterator<char>(),
    std::ostreambuf_iterator<char>(valueStream));

  outData.value = QString::fromStdString( valueStream.str() );
  dataMap.insert(std::make_pair(outData.attributes.value("name"), outData));
 }

private:
 WebDataMap& dataMap;
};

void sanitize_parts(string_list& parts);
//{
// string_list::iterator iter = parts.begin();
// while (iter != parts.end()) {

//  if ((*iter).find("--\r\n") == 0) { // If part starts with --\r\n - it is last boundary. remove
//   iter = parts.erase(iter);
//   continue;
//  }

//  if ((*iter).find("\r\n") == 0) { // Due to split command all parts starts with empty line. Remove it
//   (*iter).erase(0, 2);
//  }
//  if ((*iter).rfind("\r\n") == (*iter).length() - 2) { // Due to split command all parts ends with CRLF. Remove it
//   (*iter).erase((*iter).rfind("\r\n"), 2);
//  }
//  ++iter;
// }
//}

template<typename T>
bool parse_data(const std::string& data, const T& content_type, //const std::unordered_multimap<std::string, std::string>& content_type, //?const string_map& content_type,
  WebDataMap& dataMap)
{

 typename T::const_iterator bndIter = content_type.find("boundary");
 if (content_type.end() == bndIter) // No boundary indicator!
  return false;
 string_list parts = split(data, std::string("--") + bndIter.value().toStdString(),  //bndIter->second,
                           false);
 sanitize_parts(parts);

 string_list::iterator iter = parts.begin();
 while (iter != parts.end())
 {

  QString p = QString::fromStdString(*iter);

    //?  std::cout << p.toStdString() << std::endl;
  ++iter;
 }


 std::for_each(parts.begin(), parts.end(), ParseData(dataMap));
 return true;
}

} // namespace ParseMultipartFormData
} // namespace ParseWebData




namespace map_pairs_helper {

class ParsePairsFunc
{
public:
 ParsePairsFunc(const std::string& _pairDelim, QMultiMap<QString, QString>& _result) :
   pairDelim(_pairDelim), result(_result) {
 }
 void operator ()(const std::string& value) {
  string_list list = split(value, pairDelim);
  std::pair<QString, QString> pair;
  string_list::const_iterator iter = list.begin();
  if (iter != list.end()) {
   pair.first = QString::fromStdString(*iter);
   iter++;
   if (iter != list.end()) {
    pair.second = QString::fromStdString(*iter);
   }
  }

  result.insert(pair.first, pair.second);
 }

private:
 const std::string& pairDelim;
 QMultiMap<QString, QString>& result;
};
} // namespace map_pairs_helper


// // // _added






#endif
