
#include "kauv-caf-response-builder.h"

#include <QNetworkAccessManager>
#include <QNetworkRequest>

#include <QFileInfo>
#include <QDir>

#include <QMap>

//#include "lunar/date.h"

#include "kauv-caf-request-parser.h"



KAUV_CAF_Response_Builder::KAUV_CAF_Response_Builder()
{

}

void KAUV_CAF_Response_Builder::read_binary_file(QString path, QByteArray& qba)
{
 QFile infile(path);
 if(infile.open(QIODevice::ReadOnly))
 {
  qba = infile.readAll();
 }
}


QString KAUV_CAF_Response_Builder::read_file(QString path)
{
 QString result;
 QFile infile(path);
 if(infile.open(QIODevice::ReadOnly))
 {
  result = infile.readAll();
  //return contents_.length();
 }
 return result;
}

QString KAUV_CAF_Response_Builder::resolve_web_path(QString path)
{
 QFileInfo qfi(web_base_path_);
 QDir qd = qfi.absoluteDir();
 QString result = qd.absoluteFilePath(path);
 return result;
}

QString KAUV_CAF_Response_Builder::resolve_path(QString group, QString path, QString& suffix)
{
#define TEMP_MACRO(key, field) \
 { #key, \
  (QString(KAUV_CAF_Response_Builder::*)())(&KAUV_CAF_Response_Builder::field) \
 }, \

 static QMap<QString, QString(KAUV_CAF_Response_Builder::*)()> static_map
 {
  TEMP_MACRO(pics ,pics_base_path)
  TEMP_MACRO(css ,css_base_path)
  TEMP_MACRO(n2k ,khif_base_path)
  TEMP_MACRO(ngml ,ngml_base_path)
  TEMP_MACRO(pdf ,pdf_base_path)
 };

#undef TEMP_MACRO

// if(group == "pics")
//  qfi = QFileInfo(pics_base_path_);
// else if(group == "css")
//  qfi = QFileInfo(css_base_path_);
// else if(group == "n2k")
//  qfi = QFileInfo(khif_base_path_);
// else if(group == "ngml")
//  qfi = QFileInfo(ngml_base_path_);

 QString result;

 if(static_map.contains(group))
 {
  auto fn = static_map[group];
  QFileInfo qfi = (this->*fn)();
  QDir qd = qfi.absoluteDir();
  result = qd.absoluteFilePath(path);
  QFileInfo qfi1(result);
  suffix = qfi1.suffix();
 }
 return result;
}


//"HTTP/1.1 200 OK\r\nContent-Type: text/html; "
//                   "charset=UTF-8; Content-Length: "
//                << complete_partials_result.length()
//                << "\r\n\r\n" << complete_partials_result.toStdString();

void KAUV_CAF_Response_Builder::wrap_as_ok(QString& result)
{
 result = QString("HTTP/1.1 200 OK\r\nContent-Type: text/html; "
  "charset=UTF-8; Content-Length: %1"
  "\r\n\r\n%2").arg(result.length()).arg(result);
}


QString KAUV_CAF_Response_Builder::get_request_header(const qhttp::server::QHttpRequest& request,
  const QByteArray& key)
{
 return request.headers().value(key.toLower());
}


void KAUV_CAF_Response_Builder::parse_form_data(QMultiMap<QString, QString>& form_data,
  qhttp::server::QHttpRequest& request)
{
 const QByteArray& qba = request.collectedData();

 std::string data(qba); // (body_qba_.constData());
   //?= body_qba_.toStdString();

 //? std::cout << std::endl << "Data: " << data;
 //? std::cout.flush();

 ParseWebData::WebDataMap wdm;

// auto it = request.headers().find("content-type");
// if(it != request.headers().end())

 QString qct = get_request_header(request, "content-type");

 if(qct.startsWith("multipart/form-data"))
 {
  QMultiMap<QString, QString> ct;
  map_pairs(
    std::string("content-type=") + qct.toStdString(), "; ", "=", ct);

  ParseWebData::ParseMultipartFormData::parse_data(data, ct, wdm);

  for(ParseWebData::WebDataMap::const_iterator it = wdm.begin();
    it != wdm.end(); ++it)
  {
   QString k = it->first;
   QString v = it->second.value;

   form_data.insertMulti(k, v);
  }
 }
 else
 {
  map_pairs(data, "&", "=", form_data);
 }
}

bool KAUV_CAF_Response_Builder::get_content_type(QString key, QString& code)
{
 static QMap<QString, QPair<bool, QString>> static_map {
  {".htm", {false, "text/html"}},
  {".html", {false, "text/html"}},
  {".png", {true, "image/png"}},
  {".gif", {true, "image/gif"}},
  {".jpg", {true, "image/jpg"}},
  {".jpeg", {true, "image/jpeg"}},
  {".wmv", {true, "audio/x-ms-wmv"}},
  {".pdf", {true, "application/pdf"}},

  {"htm", {false, "text/html"}},
  {"html", {false, "text/html"}},
  {"png", {true, "image/png"}},
  {"gif", {true, "image/gif"}},
  {"jpg", {true, "image/jpg"}},
  {"jpeg", {true, "image/jpeg"}},
  {"wmv", {true, "audio/x-ms-wmv"}},
  {"pdf", {true, "application/pdf"}},
 };

 //
 // static_map -> contains key
 // {
 // -yes:
 //  code = static_map [] key /-> second;
 //  return static_map [] key /-> first;
 // -no:
 //  return false;
 // }
 //
 //

 // switch x [
 // &[5:
 //  code = static_map [] key /-> second;
 //  return static_map [] key /-> first;
 //  break; ]
 // &[6:
 //  return false;
 // ]];


 if(static_map.contains(key))
 {
  code = static_map[key].second;
  return static_map[key].first;
 }
 else
 {
  return false;
 }
}


QMap<QString, QString> KAUV_CAF_Response_Builder::read_partials_map()
{
 // //  It may be desirable to read these from a file, but by way of illustration ...
 QMap<QString, QString> result;
 return result;
}


QString KAUV_CAF_Response_Builder::complete_partials(QString& result, QString path, QString default_path)
{
 QString current_date_time_utc = QDateTime::currentDateTimeUtc().toString(
    "dddd MMMM d yyyy h:mm:ss ap");

 QString current_date_time =  QString("\n\n<div id = 'current-date-time'>"
  "<span class='current-date-time-text'>Current Date Time: </span>"
  "<span class='current-date-time-date'>%1</span>\n (UTC)</div>\n")
   .arg(current_date_time_utc);

// QString fr = get_french_republican_date_time();
// current_date_time += QString("\n\n<div id = 'current-date-time-fr'>"
//  "<span class='current-date-time-text'>(Republican: "
//  "<span class='current-date-time-date'>%1</span></span>)\n</div>\n")
//   .arg(fr);
// current_date_time += "\n\n<div id = 'calendar-credit'>"
//  "Conversion Library Credit <a href='http://www.projectpluto.com/'>"
//  "Project Pluto</a></div>\n\n";

 static QMap<QString, QString> partials_map = read_partials_map();

 QFile infile(path);

 if(infile.open(QIODevice::ReadOnly))
 {
  QTextStream in(&infile);
  while (!in.atEnd())
  {
   QString line = in.readLine();
   if(line.startsWith("@@"))
   {
    QString code = line.mid(2).trimmed();
    QString partial_path = partials_map.value(code);
    if(partial_path.isEmpty())
    {
     QString dp = default_path;

     // //
     if(code.startsWith("top-links"))
      dp += "top-nav";
     else if(code.endsWith("style"))
      dp += "styles";
     else if(code.endsWith("form"))
      dp += "forms";

     if(!default_path.isEmpty())
     {
      partial_path = QString("%1/%2.htm").arg(dp).arg(code);
     }
    }
    if(!partial_path.isEmpty())
    {
     QFile pinfile(partial_path);

     if(pinfile.open(QIODevice::ReadOnly))
     {
      QTextStream pin(&pinfile);
      QString ra = pin.readAll();
      ra.replace("<!--.[", "<!--[");
      ra.replace("<!.[", "<![");
      result += ra;
     }
    }
   }
   else
   {

//?
    line.replace("$$CURRENT_DATE_TIME$$", current_date_time);
    //?line.replace("$$CURRENT_DATE_TIME$$", "");

    line.replace("---", "&mdash;");

    line.replace("#{", "<span class='tterm'>");
    line.replace("}#", "</span>");

    line.replace("#^{", "<span class='tterm-cap'>");
    line.replace("}#", "</span>");

    line.replace("#(", "<span class='acronym'>");
    line.replace(")#", "</span>");

    line.replace("#^(", "<span class='acronym-cap'>");
    line.replace(")#", "</span>");

    line.replace("#[", "<span class='tlink'>");
    line.replace("]#", "</span>");

    line.replace("#^[", "<span class='tlink-cap'>");
    line.replace("]#", "</span>");

    line.replace("*(", "<span class='tquote'>&ldquo;");
    line.replace(")*", "&rdquo;</span>");

    line.replace("*[", "<span class='xquote'>&ldquo;");
    line.replace("]*", "&rdquo;</span>");

    result += line + "\n";
   }
  }
  infile.close();
 }

 return QString();
}





bool KAUV_CAF_Response_Builder::handle(QString requrl, QString method,
  QString& response_string,
  qhttp::server::QHttpRequest* request,
  qhttp::server::QHttpResponse* response, QByteArray& qba) const
{
// ret ,result = false;
// patterns_.each do .(pcrf <- &/KAUV_CAF_Route_Pattern) ->
//  pcrf -> check do .(
//   response_string = it -> value <$> request response rxm qba
//  ;;
// ;;
//
// our zRegularExpressionMatch ,rxm = pcrf \/ rx -> match requrl;
// rxm -> on-match do .(self) -> yield;;
//  //? response_string = it -> value <$> request response rxm qba;
//      pcrf -> rx <$> request response rxm qba;
//  ;;

 for(const KAUV_CAF_Route_Pattern& pcrf : patterns_)
 {
  if(pcrf.method == method)
  {
   QRegularExpressionMatch rxm = pcrf.rx.match(requrl);
   if(rxm.hasMatch())
   {
    response_string = pcrf.fn(request, response, rxm, qba);
    return true;
   }
  }
 }
 return false;
}
//  auto inner_map = patterns_.value(method);
//  QMapIterator<QRegularExpression*, std::function<QString (qhttp::server::QHttpRequest* requst,
//    qhttp::server::QHttpResponse* response,
//    const QRegularExpressionMatch& rxm,
//    QByteArray& qba)>>
//    it(inner_map);
//  while(it.hasNext())
//  {
//   it.next();
//   const QRegularExpression& rx = *it.key();
//   QRegularExpressionMatch rxm = rx.match(requrl);
//   if(rxm.hasMatch())
//   {
//    response_string = it.value()(request, response, rxm, qba);
//    return true;
//   }
//  }
// }
// return false;
//}

KAUV_CAF_Response_Builder::Route_Pattern_Holder KAUV_CAF_Response_Builder::Pattern_Holder::operator[](QString method)
{
 return {method, *this};
}

KAUV_CAF_Route_Pattern::Function_type KAUV_CAF_Response_Builder::Route_Pattern_Holder::operator=(KAUV_CAF_Route_Pattern::Function_type fn)
{
 ph._this->add_route_pattern(method, ph.regex, fn);
 return fn;
}

void KAUV_CAF_Response_Builder::add_route_pattern(QString method, QString regex,
  KAUV_CAF_Route_Pattern::Function_type fn)
{
 KAUV_CAF_Route_Pattern pcrp(QRegularExpression(regex), method, fn);
 // for debug ..
 pcrp.rx_debug = regex;
 patterns_.push_back(pcrp);
}
