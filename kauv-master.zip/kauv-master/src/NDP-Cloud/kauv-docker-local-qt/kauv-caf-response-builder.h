
#ifndef KAUV_CAF_RESPONSE_BUILDER__H
#define KAUV_CAF_RESPONSE_BUILDER__H

#include <QString>


#include "qhttpserverrequest.hpp"
#include "qhttpserverresponse.hpp"

#include <functional>
#include <QMap>
#include <QList>

#include <QRegularExpression>

#include "accessors.h"

#include "kauv-caf-route-pattern.h"

//class QHttpRequest;



class KAUV_CAF_Response_Builder
{
 struct Route_Pattern_Holder;

 struct Pattern_Holder
 {
  //QMap<QString, std::function<QString (qhttp::server::QHttpRequest* requst, qhttp::server::QHttpResponse* response)>>&
  KAUV_CAF_Response_Builder* _this;
  QString regex;

  Route_Pattern_Holder operator[](QString method);
 };

 struct Route_Pattern_Holder
 {
  QString method;
  Pattern_Holder ph;
  KAUV_CAF_Route_Pattern::Function_type operator=(KAUV_CAF_Route_Pattern::Function_type fn);
 };


 QString data_base_path_;
 QString web_base_path_;
 QString html_base_path_;

 QString css_base_path_;
 QString raw_base_path_;
 QString text_base_path_;

 QString pics_base_path_;
 QString pdf_base_path_;

 QString ngml_base_path_;
 QString khif_base_path_;
 QString partials_base_path_;

public:

 KAUV_CAF_Response_Builder();

 QList<KAUV_CAF_Route_Pattern> patterns_;

// QMap<QString, QMap<QRegularExpression*,
//   std::function<QString (qhttp::server::QHttpRequest* requst,
//   qhttp::server::QHttpResponse* response,
//   const QRegularExpressionMatch& rxm, QByteArray& qba)>>> patterns_;

 bool handle(QString requrl, QString method, QString& response_string,
   qhttp::server::QHttpRequest* request,
   qhttp::server::QHttpResponse* response, QByteArray& qba) const;

 ACCESSORS(QString ,data_base_path)
 ACCESSORS(QString ,web_base_path)
 ACCESSORS(QString ,html_base_path)

 ACCESSORS(QString ,css_base_path)
 ACCESSORS(QString ,raw_base_path)
 ACCESSORS(QString ,text_base_path)

 ACCESSORS(QString ,pics_base_path)
 ACCESSORS(QString ,pdf_base_path)

 ACCESSORS(QString ,ngml_base_path)
 ACCESSORS(QString ,khif_base_path)
 ACCESSORS(QString ,partials_base_path)

 QString resolve_web_path(QString path);

 QString resolve_path(QString group, QString path, QString& suffix);

 QString read_file(QString path);
 void read_binary_file(QString path, QByteArray& qba);

 void add_route_pattern(QString method, QString regex,
   KAUV_CAF_Route_Pattern::Function_type fn);

 static QMap<QString, QString> read_partials_map();

// static QString get_french_republican_date_time(QDate qdt, int offset = 0);
// static QString get_french_republican_date_time();

 void parse_form_data(QMultiMap<QString, QString>& form_data, qhttp::server::QHttpRequest& request);


 bool get_content_type(QString key, QString& code);

 QString complete_partials(QString& result, QString path, QString default_path);

 QString get_request_header(const qhttp::server::QHttpRequest& request, const QByteArray& key);

 void wrap_as_ok(QString& result);

// std::vector<std::pair<std::string, std::vector<std::pair<boost::regex,
// std::function<void(std::shared_ptr<typename ServerBase<socket_type>::Response>, std::shared_ptr<typename ServerBase<socket_type>::Request>)> > > > > opt_resource;


 Pattern_Holder operator[](QString key)
 {
  return {this, key};
 }
};


#endif
