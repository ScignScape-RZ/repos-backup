
#include "kauv-caf-response.h"

#include "kauv-caf-response-builder.h"

#include <QNetworkAccessManager>
#include <QNetworkRequest>


KAUV_CAF_Response::KAUV_CAF_Response(const KAUV_CAF_Response_Builder& response_builder)
 : response_builder_(response_builder)
{

}


QString KAUV_CAF_Response::get_response(qhttp::server::QHttpRequest* request,
   qhttp::server::QHttpResponse* response, QByteArray& qba)
{
 QString requrl = request->url().toString();
 QString method = request->methodString();

 QString result;
 bool handled = response_builder_.handle(requrl, method, result,
   request, response, qba);

 if(handled)
 {
  return result;
 }


// R"__(
//<html>
//<head>
//<b>OK: %1</b>
//<form method="post" action="/test">
//<input type="text" name="test"></input>
//<button type="submit"></button>
//</form>
//</head>
//</html>
// )__"

 result = QString(
    R"__(
<html>
<head>
<b>File Not Found: %1</b>
(Perhaps the path has not been completed.)
</head>
</html>


    )__").arg(QString::fromLatin1(request->collectedData())); //("<b>OK: %1</b>").arg(req->url().toString());



 return result;
 //return "<b>OK</b>";
}


