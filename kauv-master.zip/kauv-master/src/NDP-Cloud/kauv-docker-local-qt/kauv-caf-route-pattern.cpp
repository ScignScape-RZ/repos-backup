
#include "kauv-caf-route-pattern.h"

KAUV_CAF_Route_Pattern::KAUV_CAF_Route_Pattern(QRegularExpression regex,
  QString m, Function_type f)
  : rx(regex), method(m), fn(f)
{

}
