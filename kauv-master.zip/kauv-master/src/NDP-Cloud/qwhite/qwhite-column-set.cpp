 
#include "qwhite-column-set.h"

//template<>
//void qwhite_check_column_data_package_assign<int>(int* item_uid_, const int& rhs)
//{
// if(item_uid_)
// {
//  if(*item_uid_ == 0)
//  {
//   *item_uid_ = rhs;
//  }
// }
//}

//template<typename APPLICATION_DATA_Type>
//void qwhite_check_column_data_package_assign(int* item_uid_, const APPLICATION_DATA_Type& rhs)
//{

//}


QWhite_Column_Set::QWhite_Column_Set(QWhite_Database& qwhite_db)
 : qwhite_db_(qwhite_db), item_uid_(0)
{

}


//QWhite_Column_Set::QWhite_Column_As_Function_Object QWhite_Column_Set::operator[](std::string cn)
//{
// return operator [](QString::fromStdString(cn));
//}

void QWhite_Column_Set::use_columns(QStringList column_names)
{
 for(QString cn : column_names)
 {
  QWhite_Column* qc = qwhite_db_.get_column_by_name(cn);
  if(qc)
  {
   column_by_name_[cn] = qc;
  }
 }
}

QWhite_Column_Set::QWhite_Column_As_Function_Object
  QWhite_Column_Set::operator[](QString column_name)
{
 QWhite_Column* qc = qwhite_db_.get_column_by_name(column_name);
 if(qc)
 {
    //  QMap<int, int> ...
  // // ignore column_code_map for now
  return {qwhite_db_, qc, &item_uid_, nullptr};
 }
 throw QWhite_Unrecognized_Column_Exception();
}

QWhite_Column_Set::QWhite_Column_Data_Holder
  QWhite_Column_Set::operator()(QString column_name)
{
 QWhite_Column* qc = qwhite_db_.get_column_by_name(column_name);
 if(qc)
 {
  return {qwhite_db_, qc, 0};
 }
 throw QWhite_Unrecognized_Column_Exception();
}

