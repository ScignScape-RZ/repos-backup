
#ifndef QWHITE_COLUMN_SET__H
#define QWHITE_COLUMN_SET__H

//#include <whitedb/dbapi.h>
//#include <whitedb/indexapi.h>

extern "C" {
//?#define class _class_
#include "_whitedb.h"
//?#undef class
}


#include <QString>

#include <QtGlobal>

#include "accessors.h"
#include "flags.h"

#include "qwhite-database.h"


#include <exception>

class QWhite_Column;
class QWhite_Database;

template<typename APPLICATION_DATA_Type>
struct QWhite_Column_Set_Utils
{
 static void qwhite_check_column_data_package_assign(int* item_uid_, const APPLICATION_DATA_Type& rhs)
 {

 }
};

template<>
struct QWhite_Column_Set_Utils<int>
{
 static void qwhite_check_column_data_package_assign(int* item_uid_, const int& rhs)
 {
  if(item_uid_)
  {
   if(*item_uid_ == 0)
   {
    *item_uid_ = rhs;
   }
  }
 }

};



class QWhite_Unrecognized_Column_Exception : std::exception
{

};

class QWhite_Column_Set
{
  //?
public:
 struct QWhite_Column_As_Function_Object
 {
  QWhite_Database& qwhite_db_;
  QWhite_Column* column;

  //?
  int* item_uid_;
  QMap<int, int>* column_code_map_;

  struct QWhite_Column_Data_Package
  {
   quint32 record_id;
   quint32 field_number;
  };

  template<typename STREAM_Type>
  friend STREAM_Type& operator <<(STREAM_Type& lhs, const QWhite_Column_Data_Package& rhs)
  {
   //?lhs << rhs.column_id;
   lhs << rhs.record_id;
   return lhs;
  }

  template<typename WHITEDB_DATA_Type, typename APPLICATION_DATA_Type>
  QWhite_Column_Data_Package as(APPLICATION_DATA_Type rhs)
  {
   quint32 column_specific_record_index;
   quint32 field_number;

   QWhite_Column_Set_Utils<APPLICATION_DATA_Type
     >::qwhite_check_column_data_package_assign(item_uid_, rhs);
//   if(item_uid_)
//   {
//    if(*item_uid_ == 0)
//    {
//     *item_uid_ = rhs;
//    }
//   }

   //??? ...
   //int _item_uid = 1;

   //?
   //void* record =
   qwhite_db_.check_add_column_entry<WHITEDB_DATA_Type>(column, rhs,
     *item_uid_, column_specific_record_index, field_number, column_code_map_);

//   if(!record)
//   {
//    qwhite_db_.add_column_entry<WHITEDB_DATA_Type>(column, rhs, column_specific_record_index, field_number);
//   }

   //?
   //?qwhite_db_.add_column_entry<WHITEDB_DATA_Type>(column, rhs, column_specific_record_index, field_number);
   QWhite_Column_Data_Package result {column_specific_record_index, field_number};
   return result;
  }


  template<typename DATA_Type>
  QWhite_Column_Data_Package operator ()(DATA_Type rhs)
  {
   //?
   //
   return as<DATA_Type>(rhs);
   //?
   //return as<DATA_Type>(rhs, _item_uid);
   //qwhite_db_.add_column_entry(column, rhs);
  }

  template<typename STREAM_Type, typename DATA_Type>
  friend STREAM_Type operator <<(STREAM_Type lhs, QWhite_Column_Data_Package rhs)
  {
   //lhs << rhs.column_id;
   lhs << rhs.record_id;
   return lhs;
  }

 };

 struct QWhite_Column_Data_Holder;

 template<typename T>
 struct QWhite_Column_Data_Holder_As_Function_Object
 {
  QWhite_Column_Data_Holder& dh;
  T& data;
 };

 struct QWhite_Column_Data_Holder
 {
  QWhite_Database& qwhite_db_;
  QWhite_Column* column;
  quint32 record_id;

  template<typename T>
  QWhite_Column_Data_Holder_As_Function_Object<T> operator()(T& t)
  {
   return {*this, t};
  }
 };

//?
// template<typename STREAM_Type>
// friend const STREAM_Type& operator >>(const STREAM_Type& lhs, QWhite_Column_Data_Holder rhs)
// {
//  //?lhs << rhs.column_id;
//  lhs >> rhs.record_id;
//  return lhs;
// }

 template<typename STREAM_Type, typename DATA_Type>
 friend STREAM_Type& operator >>(STREAM_Type& lhs, QWhite_Column_Data_Holder_As_Function_Object<DATA_Type> rhs)
 {
  //?lhs << rhs.column_id;
  lhs >> rhs.dh.record_id;
  rhs.dh.qwhite_db_.retrieve_value(rhs.dh.column, rhs.dh.record_id, rhs.data);
  return lhs;
 }

 QWhite_Database& qwhite_db_;
 QMap<QString, QWhite_Column*> column_by_name_;
 int item_uid_;

public:

 QWhite_Column_Set(QWhite_Database& qwhite_db);

 ACCESSORS(int ,item_uid)


// template<typename WHITEDB_DATA_Type>
// QWhite_Column_As_Function_Object test(QString column_name);
// <std::string>

 QWhite_Column_As_Function_Object operator[](QString column_name);

 QWhite_Column_Data_Holder operator()(QString column_name);

 template<typename... T>
 void use_columns(T&&... ts)
 {
  use_columns({std::forward<T>(ts)...});
 }

 void use_columns(QStringList column_names);

 void use_columns(std::initializer_list<QString>(strings))
 {
  use_columns(QStringList(strings));
 }


// QWhite_Column_As_Function_Object operator[](std::string cn);

};


#endif

