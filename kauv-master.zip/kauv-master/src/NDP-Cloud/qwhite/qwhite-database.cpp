
#include "qwhite-database.h"
#include "qwhite-column.h"

#include <QByteArray>

#include <QDataStream>
#include <QtGlobal>

#include <QFileInfo>

#include <QDebug>

//#include "/ext_root/whitedb/whitedb-0.7.3/Db/dbindex.h"
//#include "/ext_root/whitedb/whitedb-0.7.3/Db/dbindex.c"

QWhite_Database::QWhite_Database(QString name, QString full_path)
 : name_(name), full_path_(full_path), max_column_code_(0),
   white_db_(nullptr), max_column_code_record_(nullptr), column_change_count_(0)
{
}

//template<>
QDataStream& operator <<(QDataStream& lhs, const QWhite_Column* const rhs)
{
 quint8 rF = rhs->Flags;
 lhs << rF;
 lhs << rhs->name();
 lhs << rhs->database_column_code();
 lhs << rhs->record_count();
 return lhs;
}

QDataStream& operator >>(QDataStream& lhs, QWhite_Column* const rhs)
{
 quint8 f;
 lhs >> f;
 rhs->Flags = f;
 QString n;
 lhs >> n;
 rhs->set_name(n);
 quint32 code;
 lhs >> code;
 rhs->set_database_column_code(code);
 quint32 record_count;
 lhs >> record_count;
 rhs->set_record_count(record_count);
 return lhs;
}

QDataStream& operator >>(QDataStream& lhs, QVector<QWhite_Column*>& rhs)
{
 quint32 len;
 lhs >> len;
 rhs.fill(nullptr, len);
 for(QWhite_Column*& qc : rhs)
 {
  qc = new QWhite_Column;
  lhs >> qc;
 }
 return lhs;
}

//template<>
//QDataStream& operator<<(QDataStream& s, const QVector<T>& v)
//{
//    s << quint32(v.size());
//    for (typename QVector<T>::const_iterator it = v.begin(); it != v.end(); ++it)
//        s << *it;
//    return s;
//}

QWhite_Column* QWhite_Database::get_column_by_name(QString name)
{
 return columns_map_.value(name, nullptr);
}

QString QWhite_Database::check_data(QString which)
{
#define TEMP_MACRO(key, field) \
 { #key, \
  (QString(QWhite_Database::*)())(&QWhite_Database::field) \
 }, \

 static QMap<QString, QString(QWhite_Database::*)()> static_map
 {
  TEMP_MACRO(name ,name)
  TEMP_MACRO(full-path ,full_path)
  TEMP_MACRO(report-columns ,report_columns)
  TEMP_MACRO(report-columns-html ,report_columns_html)
 };

#undef TEMP_MACRO

 QString result;

 if(static_map.contains(which))
 {
  auto fn = static_map[which];
  result = (this->*fn)();
 }
 return result;
}


void QWhite_Database::create()
{
 char* np = const_cast<char*>(name_.toStdString().c_str());
 white_db_ = wg_attach_database(np, 0);
 //white_db_ = wg_attach_database(name_.toStdString().c_str(), 0);
 max_column_code_record_ = wg_create_record(white_db_, 2);
 wg_set_field(white_db_, max_column_code_record_, 0, wg_encode_int(white_db_, 0));

 QByteArray qba;
 write_column_data(qba);
 wg_set_field(white_db_, max_column_code_record_, 1, wg_encode_blob(white_db_, qba.data(), NULL, qba.size()));

}

QString QWhite_Database::report_columns_html()
{
 QString result = report_columns("<br/>");
 return result;
}

QString QWhite_Database::report_columns(QString separator)
{
 QString result;
 //  columns_ -> scan do .(c result-set) [columns_] ->
 //  columns_ -> span do .(c) [result] ->
 //    result += c ->
 //

 for(QWhite_Column* c : columns_)
 {
  result += c->name() + separator;
 }
 return result;
}


quint32 QWhite_Database::new_column_code()
{
 return max_column_code_ + 1;
}

void QWhite_Database::confirm_new_column_code(quint32 id)
{
 max_column_code_ = id;
 wg_set_field(white_db_, max_column_code_record_, 0, wg_encode_int(white_db_, max_column_code_));
}

//void QWhite_Database::init_columns(QByteArray& qba)
//{
// QDataStream qds(&qba, QIODevice::ReadOnly);
// quint32 len;
// qds >> len;
// qds >> columns_;
//}

void QWhite_Database::init_columns()
{
 max_column_code_record_ = wg_get_first_record(white_db_);
 wg_int wgi = wg_get_field(white_db_, max_column_code_record_, 0);
 max_column_code_ = wg_decode_int(white_db_, wgi);
 wg_int wgi1 = wg_get_field(white_db_, max_column_code_record_, 1);

 char* blob = wg_decode_blob(white_db_, wgi1);
 wg_int wlen = wg_decode_blob_len(white_db_, wgi1);

 QByteArray qba(blob, wlen);
 QDataStream qds(&qba, QIODevice::ReadOnly);
 qds >> columns_;
 for(QWhite_Column* qc : columns_)
 {
  columns_map_[qc->name()] = qc;
 }
}


void QWhite_Database::load()
{
 char* np = const_cast<char*>(name_.toStdString().c_str());
 white_db_ = wg_attach_database(np, 0);
 init_columns();
// max_column_code_record_ = wg_get_first_record(white_db_);
// wg_int wgi = wg_get_field(white_db_, max_column_code_record_, 0);
// max_column_code_ = wg_decode_int(white_db_, wgi);
}

void QWhite_Database::reload()
{
 char* np = const_cast<char*>(name_.toStdString().c_str());
 white_db_ = wg_attach_database(np, 0);
 reload_from_file();

// char* fp = const_cast<char*>(full_path_.toStdString().c_str());
// wg_import_dump(white_db_, fp);
// init_columns();

// max_column_code_record_ = wg_get_first_record(white_db_);
// wg_int wgi = wg_get_field(white_db_, max_column_code_record_, 0);
// max_column_code_ = wg_decode_int(white_db_, wgi);
}

void QWhite_Database::reload_from_file()
{
 char* fp = const_cast<char*>(full_path_.toStdString().c_str());
 wg_import_dump(white_db_, fp);
 init_columns();
}

void QWhite_Database::check_create()
{
 char* np = const_cast<char*>(name_.toStdString().c_str());
 white_db_ = wg_attach_existing_database(np);

 if(white_db_)
 {
  init_columns();
 }
 else
 {
  QFileInfo qfi(full_path_);
  if(qfi.exists())
  {
   QFile qf(full_path_);
   if(qf.size() == 0)
   {
    // // the file contents were cleared out
     //   maybe to force a re-create of the db
    create();
   }
   else
   {
    // //  Here wg_attach_database actually creates the db in shared memory,
     //    take everything else from the file
    white_db_ = wg_attach_database(np, 0);
    reload_from_file();
   }
  }
  else
  {
   // //  Start from scratch as a last resort.
   create();
  }
 }
}

void QWhite_Database::check_delete()
{
 char* np = const_cast<char*>(name_.toStdString().c_str());
 wg_delete_database(np);
}

void QWhite_Database::check_full_delete()
{
 check_delete();
 QFile qf(full_path_);
 qf.resize(0);
}

void QWhite_Database::re_create()
{
 check_delete();
 create();
 save();
}


void QWhite_Database::write_column_data(QByteArray& qba)
{
 QDataStream qds(&qba, QIODevice::WriteOnly);
 qds << columns_;
 // qds << columns_.length();
 // for(QWhite_Column* qc : columns_)
 // {
 //  qds << qc;
 // }
 //qds << columns_;
}

void* QWhite_Database::update_column_entry_value(QWhite_Column* qc, quint32 record_id, wg_int new_value)
{
 wg_query_arg arglist [2]; // holds the arguments to the query

 int column_code = qc->database_column_code();
 arglist[0].column = 0;
 arglist[0].cond = WG_COND_EQUAL;
 arglist[0].value = wg_encode_query_param_int(white_db_, column_code);

 int col = qc->get_record_index_field_number();
 arglist[1].column = col;
 arglist[1].cond = WG_COND_EQUAL;
 arglist[1].value = wg_encode_query_param_int(white_db_, record_id);

 wg_query* qry = wg_make_query(white_db_, NULL, 0, arglist, 2);

 void* result = wg_fetch(white_db_, qry);

 if(result)
 {
  int fn = qc->get_effective_field_number();

  int old_value = wg_get_field(white_db_, result, fn);
  if(old_value != new_value)
  {
   // don't bother if haven't changed ...
   wg_set_field(white_db_, result, fn, new_value);
  }
 }
 return result;
}

void* QWhite_Database::retrieve_column_entry_value(QWhite_Column* qc, quint32 record_id, wg_int& result_value)
{
 wg_query_arg arglist [2]; // holds the arguments to the query

 int column_code = qc->database_column_code();
 arglist[0].column = 0;
 arglist[0].cond = WG_COND_EQUAL;
 arglist[0].value = wg_encode_query_param_int(white_db_, column_code);

 int col = qc->get_record_index_field_number();
 arglist[1].column = col;
 arglist[1].cond = WG_COND_EQUAL;
 arglist[1].value = wg_encode_query_param_int(white_db_, record_id);

 wg_query* qry = wg_make_query(white_db_, NULL, 0, arglist, 2);

 void* result = wg_fetch(white_db_, qry);

 if(result)
 {
  int fn = qc->get_effective_field_number();
  result_value = wg_get_field(white_db_, result, fn);
 }
 return result;

}


void* QWhite_Database::retrieve_record(QByteArray& qba, QString archive_name,
  QString index_column_name, wg_int query_param)
{
 //? wg_find_record_int(db, 7, WG_COND_EQUAL, 443, NULL);

 // wg_query_arg arglist [2]; /* holds the arguments to the query */

 QWhite_Column* qc = get_column_by_name(index_column_name);
 void* result;
 if(qc)
 {
  wg_query_arg arglist [2]; // holds the arguments to the query

  int column_code = qc->database_column_code();
  arglist[0].column = 0;
  arglist[0].cond = WG_COND_EQUAL;
  arglist[0].value = wg_encode_query_param_int(white_db_, column_code);
   // e.g. [4,*,id]
  int col = qc->get_effective_field_number();
  arglist[1].column = col;
  arglist[1].cond = WG_COND_EQUAL;
  arglist[1].value = query_param;

  wg_query* qry = wg_make_query(white_db_, NULL, 0, arglist, 2);

  void* index_record = wg_fetch(white_db_, qry);
  if(index_record)
  {
   //int col = qc->get_effective_field_number();
   int fn = qc->get_record_index_field_number();
   //int fn = qc->get_effective_field_number();
   wg_int wgi = wg_get_field(white_db_, index_record, fn);

   wg_int index = wg_decode_int(white_db_, wgi);
   wg_query_arg result_arglist [2]; // holds the arguments to the query

   QWhite_Column* aqc = get_column_by_name(archive_name);

   int acolumn_code = aqc->database_column_code();
   result_arglist[0].column = 0;
   result_arglist[0].cond = WG_COND_EQUAL;
   result_arglist[0].value = wg_encode_query_param_int(white_db_, acolumn_code);
     //  e.g. [2,1,*]
   int acol = qc->get_record_index_field_number();
   result_arglist[1].column = acol;
   result_arglist[1].cond = WG_COND_EQUAL;
   result_arglist[1].value = wg_encode_query_param_int(white_db_, index);

   wg_query* aqry = wg_make_query(white_db_, NULL, 0, result_arglist, 2);

   result = wg_fetch(white_db_, aqry);

   if(result)
   {
    int afn = aqc->get_effective_field_number();
    wg_int awgi = wg_get_field(white_db_, result, afn);

    char* blob = wg_decode_blob(white_db_, awgi);
    wg_int wlen = wg_decode_blob_len(white_db_, awgi);

    qba = QByteArray(blob, wlen);
   }
  }
 }
 else
 {
  result = nullptr;
 }
 return result;
}

void* QWhite_Database::find_record_by_column_and_item_id(QWhite_Column* qc,
  wg_int item_uid_query_param)
{
 wg_query_arg arglist [2]; // holds the arguments to the query

 int column_code = qc->database_column_code();
 arglist[0].column = 0;
 arglist[0].cond = WG_COND_EQUAL;
 arglist[0].value = wg_encode_query_param_int(white_db_, column_code);
  // e.g. [4,*,id]
 int col = qc->get_record_index_field_number();
 arglist[1].column = col;
 arglist[1].cond = WG_COND_EQUAL;
 arglist[1].value = item_uid_query_param;

 wg_query* qry = wg_make_query(white_db_, NULL, 0, arglist, 2);

 void* result = wg_fetch(white_db_, qry);
 return result;
}

void* QWhite_Database::check_create_column_entry_record(QWhite_Column* qc,
  wg_int& record_specific_index, int uid, int field_count)
{
 wg_int query_param = wg_encode_int(white_db_, uid);

 wg_query_arg arglist [2]; // holds the arguments to the query

 int column_code = qc->database_column_code();
 arglist[0].column = 0;
 arglist[0].cond = WG_COND_EQUAL;
 arglist[0].value = wg_encode_query_param_int(white_db_, column_code);
  // e.g. [4,*,id]
 int col = qc->get_effective_field_number();
 arglist[1].column = col;
 arglist[1].cond = WG_COND_EQUAL;
 arglist[1].value = query_param;

}


void* QWhite_Database::create_column_entry_record(QWhite_Column* qc,
  wg_int& record_specific_index, int field_count) //, wg_int column_id)
{
 // //  field_count defaults to 3
 void* result = wg_create_record(white_db_, field_count);
 wg_set_field(white_db_, result, 0, wg_encode_int(white_db_, qc->database_column_code()));
 record_specific_index = qc->get_next_record_index();

 // //  creates tuple like [4, NULL, NULL] where 4 = column code
 // //  the caller then creates pair lile [4, 1, NULL]
 // //  where 1 = item uid, written in record_specific_index;
 // //  finally the 3rd column is filled in ...
 return result;
}



void* QWhite_Database::update_record(QString type_column, QString archive_column,
 const QByteArray& qba, quint32 record_index)
{
//?#ifdef HIDE
 QByteArray old_qba;

 //?wg_int query_param = translate_data_to_query_param(record_index);

 wg_int query_param = wg_encode_query_param_int(white_db_, record_index);

 QString index_column_name = type_column;
 QWhite_Column* qc = get_column_by_name(index_column_name);
 void* result;
 if(qc)
 {
  wg_query_arg arglist [2]; // holds the arguments to the query

  int column_code = qc->database_column_code();
  arglist[0].column = 0;
  arglist[0].cond = WG_COND_EQUAL;
  arglist[0].value = wg_encode_query_param_int(white_db_, column_code);

  //int col = qc->get_effective_field_number();
  int col = qc->get_record_index_field_number();
  arglist[1].column = col;
  arglist[1].cond = WG_COND_EQUAL;
  arglist[1].value = query_param;

  wg_query* qry = wg_make_query(white_db_, NULL, 0, arglist, 2);

  void* record = wg_fetch(white_db_, qry);
  if(record)
  {
   int fn = qc->get_effective_field_number();

   char* c = const_cast<char*>(qba.data());
   int s = qba.size();
   wg_set_field(white_db_, record, fn,
     wg_encode_blob(white_db_, c, NULL, s ));
   return record;
  }
 }
 return nullptr;
}
// int os = old_qba.size();
// int ns = qba.size();
// int diff = ns - os;
//?#endif
//}

#ifdef HIDE
void* QWhite_Database::update_record(QString type_column, QString archive_column,
 const QByteArray& qba, quint32 record_index)
{
//?#ifdef HIDE
 QByteArray old_qba;

 //?wg_int query_param = translate_data_to_query_param(record_index);

 wg_int query_param = wg_encode_query_param_int(white_db_, record_index);

 QString index_column_name = type_column;
 QWhite_Column* qc = get_column_by_name(index_column_name);
 void* result;
 if(qc)
 {
  wg_query_arg arglist [2]; // holds the arguments to the query

  int column_code = qc->database_column_code();
  arglist[0].column = 0;
  arglist[0].cond = WG_COND_EQUAL;
  arglist[0].value = wg_encode_query_param_int(white_db_, column_code);

  //int col = qc->get_effective_field_number();
  int col = qc->get_record_index_field_number();
  arglist[1].column = col;
  arglist[1].cond = WG_COND_EQUAL;
  arglist[1].value = query_param;

  wg_query* qry = wg_make_query(white_db_, NULL, 0, arglist, 2);

  void* index_record = wg_fetch(white_db_, qry);
  if(index_record)
  {
   //int col = qc->get_effective_field_number();
   int fn = qc->get_record_index_field_number();
   //int fn = qc->get_effective_field_number();
   wg_int wgi = wg_get_field(white_db_, index_record, fn);

   wg_int index = wg_decode_int(white_db_, wgi);
   wg_query_arg result_arglist [2]; // holds the arguments to the query

   QWhite_Column* aqc = get_column_by_name(archive_column);

   int acolumn_code = aqc->database_column_code();
   result_arglist[0].column = 0;
   result_arglist[0].cond = WG_COND_EQUAL;
   result_arglist[0].value = wg_encode_query_param_int(white_db_, acolumn_code);

   int acol = qc->get_record_index_field_number();
   result_arglist[1].column = acol;
   result_arglist[1].cond = WG_COND_EQUAL;
   result_arglist[1].value = wg_encode_query_param_int(white_db_, index);

   wg_query* aqry = wg_make_query(white_db_, NULL, 0, result_arglist, 2);

   result = wg_fetch(white_db_, aqry);

   if(result)
   {
    int afn = aqc->get_effective_field_number();
    wg_int awgi = wg_get_field(white_db_, result, afn);

    char* blob = wg_decode_blob(white_db_, awgi);
    wg_int wlen = wg_decode_blob_len(white_db_, awgi);

    old_qba = QByteArray(blob, wlen);
   }
  }
 }
 int os = old_qba.size();
 int ns = qba.size();
 int diff = ns - os;
//?#endif
}

#endif


// QWhite_Column* qc = get_column_by_name(archive_column);
// char* c = const_cast<char*>(qba.data());
// int s = qba.size();

// //?
// void* result = nullptr;//create_column_entry_record(qc, record_index, 3);

// int index_col = qc->get_record_index_field_number();
// wg_set_field(white_db_, result, index_col,
//   wg_encode_int(white_db_, record_index));

// int fn = qc->get_effective_field_number();

// wg_set_field(white_db_, result, fn,
//   wg_encode_blob(white_db_, c, NULL, s ));

// return result;

//}

void* QWhite_Database::add_record(QString type_column, QString archive_column,
  const QByteArray& qba, quint32& record_index)
{
 QWhite_Column* qc = get_column_by_name(archive_column);
// QByteArray qba1(qba.size(), 0);

// int i = 0;
// for(char c : qba)
// {
//  qba1[i] = c;
//  ++i;
// }


 //(qba);

 char* c = const_cast<char*>(qba.data());
 int s = qba.size();
 wg_int ri;
 void* result = create_column_entry_record(qc, ri, 3);
 record_index = ri;

 int index_col = qc->get_record_index_field_number();
 wg_set_field(white_db_, result, index_col,
   wg_encode_int(white_db_, ri));

 int fn = qc->get_effective_field_number();

 wg_set_field(white_db_, result, fn,
   wg_encode_blob(white_db_, c, NULL, s ));

 return result;
}

void QWhite_Database::save()
{
 check_update_column_data();
// void* db = wg_attach_database("100", 0);

//// void* rec = wg_create_record(db, 10);
// void* rec1 = wg_create_record(db, 3);

//// wg_int enc = wg_encode_int(db, 443);
// wg_int enc1 = wg_encode_str(db, "this is my string", NULL);

//// wg_set_field(db, rec, 7, enc);
// int index = 1;
// int column_code = 1;

// wg_set_field(db, rec1, 0, wg_encode_int(db, column_code));
// wg_set_field(db, rec1, 1, wg_encode_int(db, index));

// wg_set_field(db, rec1, 2, enc1);

// QString str = "ok ...";

// QByteArray qba;

// QDataStream qds(&qba, QIODevice::WriteOnly);

// qds << str;

// qds << index;

// quintptr rec = wg_encode_record(db, rec1);
// qds << rec;

// ++index;

// void* rec2 = wg_create_record(db, 3);
// wg_int enc2 = wg_encode_blob(db, qba.data(), NULL, qba.size());

// //wg_int enc = wg_encode_int(db, 443);

// wg_set_field(db, rec2, 0, wg_encode_int(db, index) );

// wg_set_field(db, rec2, 1, enc2);

// wg_set_field(db, rec2, 2, wg_encode_record(db, rec1) );

// wg_create_index(db, 0, WG_INDEX_TYPE_TTREE, NULL, 0);
// wg_create_index(db, 1, WG_INDEX_TYPE_TTREE, NULL, 0);

// wg_int wgi = wg_get_field(db, rec3, 0);
// char* blob = wg_decode_blob(db, wgi);

// wg_int len = wg_decode_blob_len(db, wgi);

// QByteArray qba2(blob, len);
// QDataStream qds1(&qba2, QIODevice::ReadOnly);

// QString s1;

// qds1 >> s1;
// qDebug() << "STR: " << s1;

 char* fp = const_cast<char*>(full_path_.toStdString().c_str());
 wg_dump(white_db_, fp);

 //?wg_detach_database(db);
// wg_delete_database("100");

}

void QWhite_Database::check_update_column_data()
{
 if(column_change_count_ > 0)
 {
  QByteArray qba;
  write_column_data(qba);
  wg_set_field(white_db_, max_column_code_record_, 1, wg_encode_blob(white_db_, qba.data(), NULL, qba.size()));
  column_change_count_ = 0;
 }
}

QWhite_Column* QWhite_Database::create_new_column(QString name)
{
 quint32 id = new_column_code();
 QWhite_Column* result = new QWhite_Column(name, id);
 if(result)
 {
  columns_.push_back(result);
  columns_map_[name] = result;
  QByteArray qba;
  write_column_data(qba);
  confirm_new_column_code(id);
  wg_set_field(white_db_, max_column_code_record_, 1, wg_encode_blob(white_db_, qba.data(), NULL, qba.size()));
 }
 return result;
}


void QWhite_Database::retrieve()
{
 //void* db = wg_attach_existing_database("100");
 void* db = wg_attach_database("100", 0);
 char* fp = const_cast<char*>(full_path_.toStdString().c_str());
 wg_import_dump(db, fp);

 void* rec1 = wg_get_first_record(db);
 void* rec2 = wg_get_next_record(db, rec1);

 wg_int wgi = wg_get_field(db, rec2, 1);
 char* blob = wg_decode_blob(db, wgi);
 wg_int len = wg_decode_blob_len(db, wgi);

 qDebug() << " len: " << len;

 QByteArray qba(blob, len);

 QDataStream qds(&qba, QIODevice::ReadOnly);

 QString s1;

 qds >> s1;

 qDebug() << "STR: " << s1;

 int index;
 qds >> index;


 quintptr recptr; //= wg_encode_record(db, rec1);
 qds >> recptr;

 void* pv = wg_decode_record(db, recptr);

 //?qDebug() << " qpv1 " << qpv1;

// qDebug() << " 2 ";

// wg_query_arg arglist [2]; /* holds the arguments to the query */

// int column_code = 1;
// arglist[0].column = 0;
// arglist[0].cond = WG_COND_EQUAL;
// arglist[0].value = wg_encode_query_param_int(db, column_code);

// arglist[1].column = 1;
// arglist[1].cond = WG_COND_EQUAL;
// arglist[1].value = wg_encode_query_param_int(db, index);

   //? wg_find_record_int(db, 7, WG_COND_EQUAL, 443, NULL);

 //void* rec = wg_find_record_int(db, 0, WG_COND_EQUAL, 1, NULL);

   //
 //?wg_query* qry = wg_make_query(db, NULL, 0, arglist, 2);
 //?void* rec = wg_fetch(db, qry);


 //void* pv = reinterpret_cast<void*>(qpv1);

 //?qDebug() << " 3 " << pv;

//? wg_int wgi1 = wg_get_field(db, rec, 2);
 wg_int wgi1 = wg_get_field(db, pv, 2);

 //?qDebug() << " 4 " << pv;

 qDebug() << "STR: " << s1;

 char* qc = wg_decode_str(db, wgi1);

 qDebug() << "QC: " << qc;


// char* fp = const_cast<char*>(full_path.toStdString().c_str());
// wg_dump(db, fp);

}

template<>
wg_int QWhite_Database::translate_data(int data)
{
 return wg_encode_int(white_db_, data);
}
template<>
wg_int QWhite_Database::translate_data(quint64 data)
{
 return wg_encode_int(white_db_, (quint32) data);
}
template<>
wg_int QWhite_Database::translate_data(char data)
{
 return wg_encode_char(white_db_, data);
}
template<>
wg_int QWhite_Database::translate_data(double data)
{
 return wg_encode_double(white_db_, data);
}
template<>
wg_int QWhite_Database::translate_data(QDate data)
{
 return wg_encode_int(white_db_, data.toJulianDay());
}
template<>
wg_int QWhite_Database::translate_data(QDateTime data)
{
 return wg_encode_time(white_db_, data.toMSecsSinceEpoch());
}

template<>
wg_int QWhite_Database::translate_data(QString data)
{
//?
// QByteArray qba;
// QDataStream qds(&qba, QIODevice::WriteOnly);
// qds << data;
// char* c = const_cast<char*>(qba.data());
// int s = qba.size();
// return wg_encode_blob(white_db_, c, NULL, s);

// QByteArray qba = data.toLatin1();
// char* cc = const_cast<char*>(qba.data());
// return wg_encode_str(white_db_, cc, "EN");

 // int s = qba.size();
 // return wg_encode_blob(white_db_, c, NULL, s);


 //?
 //?char* cc = const_cast<char*>(data.toStdString().c_str());
 //?return wg_encode_str(white_db_, cc, "EN");

// if(data.startsWith("###"))
// {
//  int m = data.mid(3, 4).toInt();
//  ++m;
//  QString ms = QString::number(m);
//  if(m < 10)
//  {
//   ms.prepend('0');
//  }
//  if(m < 100)
//  {
//   ms.prepend('0');
//  }
//  if(m < 1000)
//  {
//   ms.prepend('0');
//  }
//  data.replace(3, 4, ms);
// }
// else
// {
//  data.prepend("###0000###");
// }

 //QString::number(qrand() % ((High + 1) - Low) + Low

// quint64 mss = QTime::currentTime().msecsSinceStartOfDay();

//?
// data.prepend("###0000###");
// int m = qrand() % ((10000) - 1000) + 1000;
// QString ms = QString::number(m);
// data.replace(3, 4, ms);

 char* cc = const_cast<char*>(data.toStdString().c_str());
 return wg_encode_str(white_db_, cc, "EN");
}


template<>
void QWhite_Database::untranslate_data(wg_int data, int& dt)
{
 wg_int result = wg_decode_int(white_db_, data);
 dt = result;
}
template<>
void QWhite_Database::untranslate_data(wg_int data, quint64& dt)
{
 wg_int result = wg_decode_int(white_db_, data);
 dt = result;
}
template<>
void QWhite_Database::untranslate_data(wg_int data, char& dt)
{
 dt = wg_decode_char(white_db_, data);
}
template<>
void QWhite_Database::untranslate_data(wg_int data, double& dt)
{
 dt = wg_decode_double(white_db_, data);
}
template<>
void QWhite_Database::untranslate_data(wg_int data, QDate& dt)
{
 wg_int result = wg_decode_int(white_db_, data);
 dt = QDate::fromJulianDay(result);
}
template<>
void QWhite_Database::untranslate_data(wg_int data, QDateTime& dt)
{
 wg_int result = wg_decode_int(white_db_, data);
 dt = QDateTime::fromMSecsSinceEpoch(result);
}

template<>
void QWhite_Database::untranslate_data(wg_int data, QString& dt)
{
//?
// char* blob = wg_decode_blob(white_db_, data);
// wg_int wlen = wg_decode_blob_len(white_db_, data);

// QByteArray qba(blob, wlen);
// QDataStream qds(&qba, QIODevice::ReadOnly);

// qds >> dt;

//?
// QByteArray qba = data.toLatin1();
// char* cc = const_cast<char*>(qba.data());
// return wg_encode_str(white_db_, cc, "EN");

// char* result = wg_decode_str(white_db_, data);
// wg_int len = wg_decode_str_len(white_db_, data);
// QByteArray qba = QByteArray::fromRawData(result, len);
// dt = QString::fromLatin1(qba);

 char* result = wg_decode_str(white_db_, data);
 wg_int len = wg_decode_str_len(white_db_, data);
 std::string ss = std::string(result, len);
 dt = QString::fromStdString(ss);
//?
// QString encoded = QString::fromStdString(ss);
// dt = encoded.mid(10);
}


template<>
wg_int QWhite_Database::translate_data_to_query_param(int data)
{
 return wg_encode_query_param_int(white_db_, data);
}

//template<>
//wg_int QWhite_Database::translate_data_to_query_param(quint32 data)
//{
// return wg_encode_query_param_int(white_db_, data);
//}

template<>
wg_int QWhite_Database::translate_data_to_query_param(quint64 data)
{
 return wg_encode_query_param_int(white_db_, (quint32) data);
}
template<>
wg_int QWhite_Database::translate_data_to_query_param(char data)
{
 return wg_encode_query_param_char(white_db_, data);
}
template<>
wg_int QWhite_Database::translate_data_to_query_param(double data)
{
 return wg_encode_query_param_double(white_db_, data);
}
template<>
wg_int QWhite_Database::translate_data_to_query_param(QDate data)
{
 return wg_encode_query_param_int(white_db_, data.toJulianDay());
}
template<>
wg_int QWhite_Database::translate_data_to_query_param(QDateTime data)
{
 return wg_encode_query_param_int(white_db_, data.toMSecsSinceEpoch());
}
template<>
wg_int QWhite_Database::translate_data_to_query_param(QString data)
{
 char* cc = const_cast<char*>(data.toStdString().c_str());
 return  wg_encode_query_param_str(white_db_, cc, "EN");
}


//template<typename DATA_Type>
//wg_int QWhite_Database::add_column_entry(QWhite_Column* qc, DATA_Type data,
//  quint32& column_specific_record_index, quint32& field_number)
//{
// wg_int record_specific_index;
// void* cer = create_column_entry_record(qc, record_specific_index);
// if(record_specific_index > 0) //qc->requires_record_specific_index())
// {
//  wg_set_field(white_db_, cer, qc->get_record_index_field_number(), record_specific_index);
//  column_specific_record_index = record_specific_index;
//  ++column_change_count_;
// }
// else
// {
//  column_specific_record_index = 0;
// }
// wg_int data_as_wg_int = translate_data(data);
// field_number = qc->get_effective_field_number();
// wg_int result = wg_set_field(white_db_, cer, field_number, data_as_wg_int);
// return result;
//}



