
#ifndef QWHITE_DATABASE__H
#define QWHITE_DATABASE__H

#include <QVector>

//#include <whitedb/dbapi.h>
//#include <whitedb/indexapi.h>

extern "C" {
//?#define class _class_
#include "_whitedb.h"
//?#undef class
}


#include <QString>
#include <QtGlobal>
#include <QMap>
#include <QDate>

#include "accessors.h"

#include "qwhite-column.h"

class QWhite_Column;

class QWhite_Database
{
 QString name_;
 QString full_path_;

 quint32 max_column_code_;

 void* white_db_;
 void* max_column_code_record_;

 QVector<QWhite_Column*> columns_;
 QMap<QString, QWhite_Column*> columns_map_;

 int column_change_count_;


public:

 ACCESSORS(QString ,name)
 ACCESSORS(QString ,full_path)
 ACCESSORS(quint32 ,max_column_code)


 QWhite_Database(QString name, QString full_path);

 QWhite_Column* get_column_by_name(QString name);

 quint32 new_column_code();
 void confirm_new_column_code(quint32 id);

 void write_column_data(QByteArray& qba);
 void check_update_column_data();

 QString check_data(QString which);

 QString report_columns(QString separator = "\n");

 QString report_columns_html();

 void* add_record(QString type_column, QString archive_column,
  const QByteArray& qba, quint32& record_index);

 void* update_record(QString type_column, QString archive_column,
  const QByteArray& qba, quint32 record_index);

 // qwdb.retrieve_record(qba, "Default@Patient", "Patient::Id", 1000);

 void* retrieve_record(QByteArray& qba, QString archive_name,
   QString index_column_name, wg_int data);

 template<typename T>
 void* retrieve_record(QByteArray& qba, QString archive_name,
   QString index_column_name, T data)
 {
  wg_int query_param = translate_data_to_query_param(data);
  return retrieve_record(qba, archive_name, index_column_name, query_param);
 }

 void* retrieve_column_entry_value(QWhite_Column* qc, quint32 record_id, wg_int& result_value);
 void* update_column_entry_value(QWhite_Column* qc, quint32 record_id, wg_int new_value);

 template<typename DATA_Type>
 void untranslate_data(wg_int data, DATA_Type& dt);

 template<typename DATA_Type>
 void retrieve_value(QWhite_Column* qc, quint32 record_id, DATA_Type& dt)
 {
  wg_int value;
  retrieve_column_entry_value(qc, record_id, value);
  untranslate_data(value, dt);
 }

 template<typename DATA_Type>
 void* update_value(QWhite_Column* qc, quint32 record_id, DATA_Type& dt)
 {
  wg_int value = translate_data(dt);
  return update_column_entry_value(qc, record_id, value);
  //untranslate_data(value, dt);
 }


 void retrieve();
 void save();
 void create();

 void check_create();

 void re_create();

 void reload();
 void load();

 void reload_from_file();

 void check_delete();

 void check_full_delete();

 void init_columns();
 //void init_columns(QByteArray& qba);

 QWhite_Column* create_new_column(QString name);

 void* create_column_entry_record(QWhite_Column* qc,
   wg_int& record_specific_index, int field_count = 3); //, wg_int column_id)

 void* check_create_column_entry_record(QWhite_Column* qc,
   wg_int& record_specific_index, int uid, int field_count = 3);

 void* find_record_by_column_and_item_id(QWhite_Column* qc,
   wg_int item_uid_query_param);


 template<typename DATA_Type>
 wg_int translate_data(DATA_Type dt);


 template<typename DATA_Type>
 wg_int translate_data_to_query_param(DATA_Type dt);

 template<typename DATA_Type>
 wg_int check_add_column_entry(QWhite_Column* qc, DATA_Type data,
   quint32 item_uid, quint32& column_specific_record_index,
   quint32& field_number, QMap<int, int>* column_code_map)
 {
  // //  column_code_map ignored for now ...
  wg_int query_param = wg_encode_int(white_db_, item_uid);
  void* record = find_record_by_column_and_item_id(qc, query_param);
  if(record)
  {
   // //  record should have a pattern like [4,1,*] ...
   // //  where 4 = column id, 1 = item id ...
   qint8 fn = qc->get_record_index_field_number();
   wg_int wgi = wg_get_field(white_db_, record, (int) fn);
   int record_specific_index = wg_decode_int(white_db_, wgi);
   if(record_specific_index)
   {
    //?field_number = fn;
    column_specific_record_index = record_specific_index;

    wg_int data_as_wg_int = translate_data(data);

    DATA_Type data_test;
    untranslate_data(data_as_wg_int, data_test);

    field_number = qc->get_effective_field_number();

    wg_int result;
    wg_int old_value = wg_get_field(white_db_, record, field_number);
    if(old_value == data_as_wg_int)
    {
     // don't bother if haven't changed ...
     result = 0;
    }
    else
    {
     result = wg_set_field(white_db_, record, field_number, data_as_wg_int);
    }
    return result;

   }
   // error here?
   return 0;
  }
  else
  {
   return add_column_entry(qc, data, column_specific_record_index, field_number);
  }
 }

 template<typename DATA_Type>
 wg_int add_column_entry(QWhite_Column* qc, DATA_Type data,
   quint32& column_specific_record_index, quint32& field_number)
 {
  wg_int record_specific_index;
  void* cer = create_column_entry_record(qc, record_specific_index);
  if(record_specific_index > 0) //qc->requires_record_specific_index())
  {
   // // record is now like [4, NULL, NULL]
   // // and must write record_specific_index into
   // // qc->get_record_index_field_number()
   // // (1, in simple cases)
   qint8 fn = qc->get_record_index_field_number();
   wg_set_int_field(white_db_, cer, (int) fn, record_specific_index);
   column_specific_record_index = record_specific_index;
   ++column_change_count_;
  }
  else
  {
   column_specific_record_index = 0;
  }
  wg_int data_as_wg_int = translate_data(data);

  DATA_Type data_test;
  untranslate_data(data_as_wg_int, data_test);

  field_number = qc->get_effective_field_number();
  wg_int result = wg_set_field(white_db_, cer, field_number, data_as_wg_int);
  return result;
 }
};

//template<typename DATA_Type>
//wg_int QWhite_Database::add_column_entry(QWhite_Column* qc, DATA_Type data,
//  quint32& column_specific_record_index, quint32& field_number)
//{
// wg_int record_specific_index;
// void* cer = create_column_entry_record(qc, record_specific_index);
// if(record_specific_index > 0) //qc->requires_record_specific_index())
// {
//  wg_set_field(white_db_, cer, qc->get_record_index_field_number(), record_specific_index);
//  column_specific_record_index = record_specific_index;
//  ++column_change_count_;
// }
// else
// {
//  column_specific_record_index = 0;
// }
// wg_int data_as_wg_int = translate_data(data);
// field_number = qc->get_effective_field_number();
// wg_int result = wg_set_field(white_db_, cer, field_number, data_as_wg_int);
// return result;
//}


#endif
