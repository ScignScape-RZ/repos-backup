
//#include "rz-generic-parser.h"

//#include "rz-parser.templates.h"

//RZ_Generic_Parser::RZ_Generic_Parser(void* v)
// : RZ_Parser<RZ_Generic_Galaxy>(v)
//{

//}


//template<>
//void RZ_Parser<RZ_Generic_Galaxy>::set_match(RZ_Match_Data_Base* m, tRule* r, int pos)
//{
// delete_last_match();
// last_match = Match_Info(match, rule);
// match = m;
// rule = r;
// current_position = pos;
//}

//template<>
//bool RZ_Parser<RZ_Generic_Galaxy>::check_seek(tString& s)
//{
// if(seek_string == "")
//  return false;
// else
// {
//  s = seek_string;
//  seek_string = "";
//  return true;
// }
//}

//template<>
//void* RZ_Parser<RZ_Generic_Galaxy>::reset_cancel()
//{
// void* result = cancel_info;
// cancel_info = 0;
// return result;
//}

