 
//#include <QCoreApplication>

//
#include <QApplication>

//#include <QDebug>

#include "relae-lisp-embed/relae-lisp-embed-environment.h"
#include "relae-lisp-embed/relae-lisp-eval.h"

#include "kans.h"

USING_KANS(EmbL)

int main(int argc, char* argv[])
{
 QApplication qapp(argc, argv);
 qapp.aboutQt();

 //QCoreApplication qapp(argc, argv);

 Relae_Lisp_Embed_Environment env(argc, argv);
 Relae_Lisp_Eval reval(&env);

 env.set_quicklisp_location("/home/nlevisrael/quicklisp/setup.lisp");
 reval.eval_quicklisp_setup();


//  QString s = reval.eval_string("(format t \"a: ~a\" (+ 2 5))");
//  QString s = reval.eval_string("(+ 2 5)");

 reval.eval_file("/extension/ecl/t1.lisp");

// qapp.aboutQt();
   //qDebug() << "S: " << s;
}
