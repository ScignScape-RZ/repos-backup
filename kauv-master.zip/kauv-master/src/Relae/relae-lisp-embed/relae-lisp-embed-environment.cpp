
#include "relae-lisp-embed-environment.h"

#include "kans.h"

//#include "backend/ecl.hpp"

#include "object.hpp"


USING_KANS(EmbL)


Relae_Lisp_Embed_Environment::Relae_Lisp_Embed_Environment(int argc, char *argv[])
{
 cl_boot(argc, argv);
}


