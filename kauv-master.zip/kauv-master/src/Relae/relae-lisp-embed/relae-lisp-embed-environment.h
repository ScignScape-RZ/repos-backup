
#ifndef RELAE_LISP_EMBED_ENVIRONMENT__H
#define RELAE_LISP_EMBED_ENVIRONMENT__H

#include "kans.h"

#include "accessors.h"

#include <QString>

KANS_(EmbL)


class Relae_Lisp_Embed_Environment
{
 QString quicklisp_location_;

public:

 Relae_Lisp_Embed_Environment(int argc, char *argv[]);

 ACCESSORS(QString ,quicklisp_location)




};

_KANS(Lisp)


#endif

