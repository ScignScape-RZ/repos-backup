
#include "relae-lisp-eval.h"

#include "relae-lisp-embed-environment.h"

#include "cl-cxx/object.hpp"

#include <QDebug>

#include <QDebug>
#include <QRegExp>
#include <QStringList>
#include <QFileInfo>
#include <QDir>

#include <QStringList>


USING_KANS(EmbL)


Relae_Lisp_Eval::Relae_Lisp_Eval(Relae_Lisp_Embed_Environment* e)
 : env_(e), relae_lisp_runtime_(new Relae_Lisp_Runtime)
{
//? qDebug() << "Initializing environment (with local scripts) ...";

// QString meval_progn = "(load \"" RELAE_LISP_EVAL__DEFAULT_INTERNAL_ECL_DIRECTORY
//   "/def-arrow-macro-progn.ecl\" :verbose nil)";

 QString meval = "(load \"" RELAE_LISP_EVAL__DEFAULT_INTERNAL_ECL_DIRECTORY
   "/def-arrow-macro.ecl\" :verbose nil)";

 QString dfp_eval = "(load \"" RELAE_LISP_EVAL__DEFAULT_INTERNAL_ECL_DIRECTORY
   "/define-rz-package.ecl\" :verbose nil)";

 QString smc_eval = "(load \"" RELAE_LISP_EVAL__DEFAULT_INTERNAL_ECL_DIRECTORY
   "/set-paren-macro-character.ecl\" :verbose nil)";

 QString ips_eval = "(load \"" RELAE_LISP_EVAL__DEFAULT_INTERNAL_ECL_DIRECTORY
   "/init-parenscript.ecl\" :verbose nil)";

// cl_cxx_backend::eval_string(qba.data());

// cl_cxx_backend::eval_string("(make-package 'rz)");
// cl_cxx_backend::eval_string("(in-package rz)");

 cl_cxx_backend::eval_string(meval.toLatin1().data());


 cl_cxx_backend::eval_string(smc_eval.toLatin1().data());
 cl_cxx_backend::eval_string(dfp_eval.toLatin1().data());
 cl_cxx_backend::eval_string(ips_eval.toLatin1().data());


// QStringList qsl = smc_eval.split(";split");

// for(QString qs : qsl)
//  cl_cxx_backend::eval_string(qs.toLatin1().data());

 initial_generated_string_ = meval + "\n" + smc_eval + "\n" + dfp_eval + "\n" + ips_eval;

// qDebug() << "Ok.";
}


void Relae_Lisp_Eval::minimal_eval(QString eval_text)
{
 cl_cxx_backend::eval_string(eval_text.toLatin1().data());
}

void Relae_Lisp_Eval::define_callback(cl_cxx_backend::callback_t cb,
 QString package_name, QString symbol_name, void* argument)
{
 package_name = package_name.toUpper();
 symbol_name = symbol_name.toUpper();
 cl_object obj = cl_cxx_backend::symbol(package_name.toLatin1().data(), symbol_name.toLatin1().data());
 cl_cxx_backend::define_function(obj, cb, argument);
}

void Relae_Lisp_Eval::test_callback(cl_cxx_backend::callback_t cb)
{
 cl_cxx_backend::eval_string("(COMMON-LISP-USER::TEST-CB)");
}

QObject* Relae_Lisp_Eval::get_last_qobject()
{
 return relae_lisp_runtime_->last_qobject();
}

void Relae_Lisp_Eval::prepare_callbacks()
{
 void** pass_on = (void**) malloc(2 * sizeof(void*));

 pass_on[0] = relae_lisp_runtime_;
 pass_on[1] = this;

 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   //?qDebug() << "REVAL OK";
   Relae_Lisp_Runtime* runtime = reinterpret_cast<Relae_Lisp_Runtime*>( ((void**) pass_on)[0]);
   Relae_Lisp_Eval* reval = reinterpret_cast<Relae_Lisp_Eval*>( ((void**) pass_on)[1]);

   //?qDebug() << "REVAL OK";

   QList<Relae_Lisp_Argument> args;

    //QMessageBox::information(nullptr, "OK", "Got cb");
   cl_arglist_to_qstrings(args, arglist);

   void* object_result = nullptr;

   cl_object cl_result = ECL_NIL;

//   Digamma_Ecl_Bridge::
//   cl_arglist_to_qstrings(args, arglist);
//   void* object_result = nullptr;
//   cl_object cl_result = ECL_NIL;

   QString result = runtime->run_lisp_callback(reval, args,
     object_result, cl_result);

   if(cl_result != ECL_NIL)
   {
    return cl_result;
   }
   else if(object_result)
   {

//?
//    QPair<QString, void*>* pair_result = new QPair<QString, void*>{result, object_result};

//    return cl_cxx_backend::make_foreign_data(pair_result);

   }
   else
   {
    return ECL_NIL;
//?
//    result.replace('"', "\\\"");
//    result.prepend('"');
//    result.append('"');
//    return cl_cxx_backend::eval_string(result.toStdString().c_str());
   }
   //RZ_Lisp_Eval* pRle = reinterpret_cast<RZ_Lisp_Eval*>( ((void**) pass_on)[1]);
  }, "CL-USER", "QTAG", pass_on);
}


QString Relae_Lisp_Eval::cl_arglist_to_qstring(cl_cxx_backend::cl_arglist arglist)
{
 QString result;
 cl_object result_cl = cl_cxx_backend::nth_arg(arglist, 1);
 result_cl = si_coerce_to_base_string(result_cl);
 unsigned char * cc = result_cl->base_string.self;

 for(unsigned char* c = cc; *c != 0; ++c)
 {
  QChar qc = QChar::fromLatin1(*c);
  result += qc;
 }
 return result;
}

//?void Relae_Lisp_Eval::cl_arglist_to_qstrings(QStringList& result, cl_cxx_backend::cl_arglist arglist)

void Relae_Lisp_Eval::cl_arglist_to_qstrings(QList<Relae_Lisp_Argument>& result, cl_cxx_backend::cl_arglist arglist)
{
// int i = 0;
 cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);
// int size = (int) result_size;

 int size = arglist->frame.size - 1;

// cl_index size_index = ecl_to_index(result_size);
// int size = 3;

 for(int i = 1; //size = size_index;
  size >= 0; ++i, --size)
// while( (result_cl = cl_cxx_backend::nth_arg(arglist, ++i) ) != 0)
 {
  cl_object result_cl = cl_cxx_backend::nth_arg(arglist, i);

  cl_object result_cl_str = si_coerce_to_base_string(result_cl);
  unsigned char * cc = result_cl_str->base_string.self;

  QString result_string;

  for(unsigned char* c = cc; *c != 0; ++c)
  {
   QChar qc = QChar::fromLatin1(*c);
   result_string += qc;
  }

  Relae_Lisp_Argument arg;
  arg.str = result_string;

  result << arg;
 }
}




//?void Relae_Lisp_Eval::set_result_holder(QTextStream* qts)
//{
////? rh_.set_q_text_stream(qts);
//}

//QString Relae_Lisp_Eval::make_flag_lambdas(QString flag, int position)
//{
// int mask = 1 << position;
// QString result;
// result += QString("\n(flags-%1 :accessor flags-%1 :initform #'(lambda (this)"
//                   " (logand (this -> flags) %2) ))").arg(flag).arg(mask);
// result += QString("\n(flagt-%1 :accessor flagt-%1 :initform #'(lambda (this)"
//                   " (this -> set-flags (logior flags %2) ) ))").arg(flag).arg(mask);
// result += QString("\n(flagf-%1 :accessor flagf-%1 :initform #'(lambda (this)"
//                   " (this -> set-flags (logxor flags %2) ) ))").arg(flag).arg(mask);
// result += QString("\n(flagr-%1 :accessor flagr-%1 :initform #'(lambda (this)"
//                   " (this -> set-flags (logandc3 flags %2) ) ))").arg(flag).arg(mask);

//// " (if (this -> flagt-%1) (flagf-%1) (flagt-%1) ) ))").arg(flag);

// return result;
//}


void Relae_Lisp_Eval::check_flags_replace(QString& eval_text)
{
 while(true)
 {
  int start = eval_text.indexOf("flags_");
  if(start == -1)
   return;
  //// 6 = length of "flags_" and "_flags"
  int end = eval_text.indexOf("_flags", start + 6);
  if(end == -1)
   return;
  QString flags = eval_text.mid(start + 6, end - (start + 6));
  QStringList flag_list = flags.split(QRegExp("\\s+"), QString::SkipEmptyParts);
  QStringListIterator it(flag_list);

  QString result = ";;; flags generated \n-(dfgs flags-mask)-\n-(dg flag-index)-\n"
    "\n(flag-t :accessor flag-t :initform #'(lambda (this flag)"
    "\n (let( (index (gethash flag (this -> flag-index) ) ))"
    "\n  (if index (this -> set-flags-mask (logior (this -> flags-mask) (ash 1 index) ))) )))"
    "\n(flag-f :accessor flag-f :initform #'(lambda (this flag)"
    "\n (let( (index (gethash flag (this -> flag-index) ) ))"
    "\n  (if index (this -> set-flags-mask (logxor (this -> flags-mask) (ash 1 index) ))) )))"
    "\n(flag-r :accessor flag-r :initform #'(lambda (this flag)"
    "\n (let( (index (gethash flag (this -> flag-index) ) ))"
    "\n  (if index (this -> set-flags-mask (logandc3 (this -> flags-mask) (ash 1 index) ))) )))"
    "\n(flag-? :accessor flag-? :initform #'(lambda (this flag)"
    "\n (let( (index (gethash flag (this -> flag-index) ) ))"
    "\n  (if index (> (logand (this -> flags-mask) (ash 1 index) ) 0 ) ))) )"
    "\n";


  QString flag_index_map = "(flag-index_ :accessor flag-index_ :initform (rz-make-flag-hash ";
  flag_index_map += QString::number(flag_list.size());

  QString flag_str = "\n(flag-str :accessor flag-str :initform #'(lambda (this)"
   "\n (let( (result \"\") ) "
   "\n  (loop for flag being each hash-key of (this -> flag-index) do"
   "\n   (if (this -> flag-? flag)"
   "\n    (setf result (concatenate 'String result (symbol-name flag) \" \" )) ))"
   "\n ;return \n  result\n )))\n";

  result += flag_str + "\n";

  result += "\n(flag-c :accessor flag-c :initform #'(lambda (this)"
    "\n (this -> set-flags-mask 0) ))"
    "\n;;;";

  int position = 0;
  while(it.hasNext())
  {
   QString flag = it.next();
//   result += make_flag_lambdas(flag, position);
   flag_index_map += " :" + flag;
   ++position;
  }
  result += "\n" + flag_index_map + "))\n";
  result += "\n;;;end flags\n";
  eval_text.replace(start, end + 6 - start, result);
 }
}

void Relae_Lisp_Eval::eval_quicklisp_setup()
{
 eval_raw_text(QString("(load \"%1\")").arg(env_->quicklisp_location()));
}


void Relae_Lisp_Eval::eval_raw_file_via_load(QString file_name)
//cl_object qs_lisp(const QString& call)
{
 eval_raw_text(QString("(load \"%1\")").arg(file_name));
// QString eval =
// return cl_eval(c_string_to_object(call.toStdString().c_str()));
}


void Relae_Lisp_Eval::eval_raw_file(QString file_name)
{
 QFile file(file_name);

 if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
  return;
 QString eval_text = file.readAll();

 file.close();

 eval_raw_text(eval_text);
}

cl_object Relae_Lisp_Eval::eval_raw_text(QString eval_text)
{
 return cl_cxx_backend::eval_string(eval_text.toLatin1().data());
}



void Relae_Lisp_Eval::eval_file(QString file_name, int load_depth, QString top_file)
{
 QFile file(file_name);

 if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
  return;
 QString eval_text = file.readAll();

 QFileInfo fi(file_name);
 QDir default_dir = fi.absoluteDir();

 if(top_file.isEmpty())
  top_file = file_name;

 QString fe = eval(eval_text, "", file_name, load_depth, top_file, &default_dir);

//?
// QString outfile_name = file_name;
// outfile_name.replace(QRegExp(".rzi$"),".rze");

// QFile outfile(outfile_name);
// if (!outfile.open(QIODevice::WriteOnly | QIODevice::Text))
//  return;
// outfile.write(fe.toLatin1());
// outfile.close();
}

void Relae_Lisp_Eval::eval_loaded_file(QString eval_text, QString extra_support, QString file_name)
{
 QFileInfo fi(file_name);
 QDir default_dir = fi.absoluteDir();

 QString fe = eval(eval_text, extra_support, file_name, 0, file_name, &default_dir);

 QString outfile_name = file_name;
 outfile_name.replace(QRegExp(".rzi$"),".rze");

 QFile outfile(outfile_name);
 if (!outfile.open(QIODevice::WriteOnly | QIODevice::Text))
  return;
 outfile.write(fe.toLatin1());
 outfile.close();

}


QString Relae_Lisp_Eval::eval_string(QString eval_text)
{
 QString result;
 cl_object result_cl = cl_cxx_backend::eval_string(eval_text.toLatin1().data());
 result_cl = si_coerce_to_base_string(result_cl);
 unsigned char * cc = result_cl->base_string.self;

 for(unsigned char* c = cc; *c != 0; ++c)
 {
  QChar qc = QChar::fromLatin1(*c);
  result += qc;
 }
 return result;
}


QString Relae_Lisp_Eval::eval(QString eval_text, QString extra_support, QString file_name, int load_depth, QString top_file, QDir* default_dir)
{
 QRegExp load_finder("#load([^;]+);");

 QRegExp gen_finder("#gen([^;]+);");

 QRegExp Relae_symbols_finder("#rz-(symbols|dominion|class_|class|resource|resource_)([^;]+);");

 QRegExp raw_macro_finder("-(\\((?:[^())]|\\((?!-))*\\))-");
 QRegExp method_start("\\bm_\\s+[^\\s()]+");
 QRegExp method_end("\\b_m\\b");

 QRegExp method_call_replace("([^\\s(]*)\\\\/([^\\s()]+)");

 QRegExp double_quote_replace("``([^\\s()]+)");
 QRegExp type_name_replace("''([^\\s()]+)");

 QString symbols = "\n;;; generated rz symbols\n (progn \n";

 QString support_file_name;
 QString load_support_file;
 QString load_support_comment;
 QString support_text;

 QStringList load_support_file_list;
 QStringList load_support_loads;

 int load_support_file_count = 0;

 if(!file_name.isEmpty())
 {
  int i = eval_text.indexOf(gen_finder);
  if(i != -1)
  {
   QString cap_text = gen_finder.cap(1);
   QStringList sl = cap_text.split(QRegExp("\\s"), QString::SkipEmptyParts);
   QString replacement = "#rz#lsf ;";
   load_support_comment = " Loaded";
   bool use_default_dir = false;
   bool load_str_in_support = false;
   for(QString text : sl)
   {
    if(text.endsWith(".rzs"))
    {
     support_file_name = file_name;
     support_file_name.replace(QRegExp(".rzi$"),".rzs");
     load_support_file += "(load \"" + support_file_name + "\")";
     load_support_comment += " " + support_file_name;
     continue;
    }
    if(text == "<-")
    {
     use_default_dir = true;
     load_str_in_support = true;
     continue;
    }
    if(text == "<--")
    {
     load_str_in_support = true;
     continue;
    }
    if(load_str_in_support)
    {
     if(use_default_dir)
     {
      load_support_loads << "\n(load \"" RELAE_LISP_EVAL__DEFAULT_INTERNAL_ECL_DIRECTORY
        "/" + text + "\" :verbose nil)";
      load_support_comment += " and (in that file) " + text;
     }
     else
     {
      load_support_loads << "\n(load \"" + text + "\" :verbose nil)";
      load_support_comment += " and (in that file) " + text;
     }
     continue;
    }
    // /  We're adding a load in the main file, not the support
    ++load_support_file_count;
    if(use_default_dir)
    {
     load_support_file_list << "(load \"" RELAE_LISP_EVAL__DEFAULT_INTERNAL_ECL_DIRECTORY
       "/" + text + "\" :verbose nil)";
     load_support_comment += " and " + text;
    }
    else
    {
     load_support_file_list << "(load \"" + text + "\" :verbose nil)";
     load_support_comment += " and " + text;
    }
   }
   int size = gen_finder.cap(0).size();
   eval_text.replace(i, size, replacement);
  }
 }

 int rzntl_flag_index = eval_text.indexOf("#rzntl");
 if(rzntl_flag_index != -1)
 {
  eval_text.insert(rzntl_flag_index, ';');
 }

 for(int i = 0; i != -1;)
 {
  i = eval_text.indexOf(load_finder);
  if(i != -1)
  {
   QString cap_text = load_finder.cap(1);
   int number_of_lines = cap_text.count('\n') + 1;
   QStringList sl = cap_text.split(QRegExp("\\s"), QString::SkipEmptyParts);
   QString replacement;
   for(QString text : sl)
   {
    if(text.startsWith('!'))
    {
     text = text.mid(1);
     if(default_dir)
      text = default_dir->absolutePath() + "/" + text;
    }
    else if(!text.contains('/') && default_dir)
     text = default_dir->absolutePath() + "/" + text;
    eval_file(text, load_depth + 1, top_file);
    text.replace(QRegExp(".rzi$"),".rze");
    replacement += "(load \"" + text + "\" :verbose nil)";
   }
   replacement += " ; generated file loads";
   while(--number_of_lines > 0)
   {
    replacement += "\n ; ...continued";
   }
   int size = load_finder.cap(0).size();
   eval_text.replace(i, size, replacement);
  }
 }

 for(int i = 0; i != -1;)
 {
  i = eval_text.indexOf(Relae_symbols_finder);
  if(i != -1)
  {
   QString symbol_type = Relae_symbols_finder.cap(1);
   QString symbol_names = Relae_symbols_finder.cap(2);
   QStringList sl = symbol_names.split(QRegExp("\\s"), QString::SkipEmptyParts);
   QString replacement;
   if(symbol_type == "symbols")
    replacement = ";;; moved rz symbol declarations\n";
   for(QString symbol_name : sl)
   {
    if(symbol_type == "dominion")
    {
     symbol_name = QString("dm-") + symbol_name;
     replacement += QString("(setf rz:%1 (rz::make-RZ-Dominion \"%1\"))").arg(symbol_name);
    }
    else if(symbol_type == "resource")
    {
     symbol_name = QString("rs-") + symbol_name;
     replacement += QString("(setf rz:%1 (rz::make-RZ-Resource \"%1\"))").arg(symbol_name);
    }
    else if(symbol_type == "class")
    {
     symbol_name = QString("cl-") + symbol_name;
     replacement += QString("(setf rz:%1 (rz::make-RZ-Class \"%1\"))").arg(symbol_name);
    }
    else if(symbol_type == "class_")
    {
     symbol_name = QString("cl-") + symbol_name;
     replacement +=
      QString("(setf rz:%1 (rz::make-RZ-Class \"%1\"))"
              " (let ((self rz:%1)) ;;; entering classdef..."
              ).arg(symbol_name);
    }
    else if(symbol_type == "resource_")
    {
     symbol_name = QString("rs-") + symbol_name;
     replacement +=
      QString("(setf rz:%1 (rz::make-RZ-Resource \"%1\"))"
              " (let ((self rz:%1)) ;;; entering resource def..."
              ).arg(symbol_name);
    }

    symbols += "  (rz::rz-symbol \"" + symbol_name + "\")\n";

   }
   int size = Relae_symbols_finder.cap(0).size();
   eval_text.replace(i, size, replacement);
  }
 }

 symbols += "  )\n;;; end generated rz symbols\n\n";

 support_text += symbols;

 support_text += load_support_loads.join("\n");


 eval_text.replace("@-", "rz::dm-"); // dominion
 eval_text.replace("$-", "rz::cl-"); // class
 eval_text.replace("^-", "rz::ty-"); // type
// eval_text.replace("^^-", "rz:ty-"); // type

// eval_text.replace("%-", "rz:py-"); // property

// eval_text.replace("&-", "rz:fd-"); // field
// eval_text.replace("*-", "rz:fd-"); // node
// eval_text.replace("/-", "rz:fd-"); // connector

 eval_text.replace("#_rz-class", ");;; end classdef\n");
 eval_text.replace("#_rz-resource", ");;; end resource def\n");

 check_flags_replace(eval_text);

// eval_text.replace(method_call_replace, QString("(this -> \\2)"));

 for(int i = 0; i != -1;)
 {
  // //  Nifty: by matching only the last method call in the regex
  //     (which I first thought was an error) this loop actually
  //     handles cases like x\/y\/z... automatically because
  //     it "unrolls" the arrows from right to left, e.g.
  //     x\/y\/z becomes (x\/y -> z) and so on.
  i = eval_text.indexOf(method_call_replace);
  if(i != -1)
  {
   QString object = method_call_replace.cap(1);
   QString method = method_call_replace.cap(2);
   if(object.isEmpty())
     object = "this";
   eval_text.replace(i, method_call_replace.cap(0).size(),
     QString("(%1 -> %2)").arg(object).arg(method));
  }
 }

 eval_text.replace(double_quote_replace, QString("\"\\1\""));
 eval_text.replace(type_name_replace, QString("(rz::rz-type-name \\1)"));

 for(int i = 0; i != -1;)
 {
  i = eval_text.indexOf(raw_macro_finder);
  if(i != -1)
  {
   QString text = raw_macro_finder.cap(1);
   text.insert(1, "rz::");
   cl_object new_text_clo = cl_cxx_backend::eval_string(text.toLatin1().data());
//   std::string s = cl_cxx::from_cl_object<std::string>(new_text_clo);

   new_text_clo = si_coerce_to_base_string(new_text_clo);
   unsigned char * cc = new_text_clo->base_string.self;

   QString new_text_qs;

   for(unsigned char* c = cc; *c != 0; ++c)
   {
    QChar qc = QChar::fromLatin1(*c);
    new_text_qs += qc;
   }
   eval_text.replace(i, text.size() - 2, new_text_qs);
  }
 }

 for(int i = 0; i != -1;)
 {
  i = eval_text.indexOf(method_start);
  if(i != -1)
  {
   QString text = method_start.cap(0);
   int size = text.size();
   text = QString("(rz::%1)").arg(text);
   cl_object new_text_clo = cl_cxx_backend::eval_string(text.toLatin1().data());

   new_text_clo = si_coerce_to_base_string(new_text_clo);
   unsigned char * cc = new_text_clo->base_string.self;

   QString new_text_qs;

   for(unsigned char* c = cc; *c != 0; ++c)
   {
    QChar qc = QChar::fromLatin1(*c);
    new_text_qs += qc;
   }


   //   std::string s = cl_cxx::from_cl_object<std::string>(new_text_clo);
//   QString new_text_qs = QString::fromStdString(s);
   eval_text.replace(i, size, new_text_qs);
  }
 }

 for(int i = 0; i != -1;)
 {
  i = eval_text.indexOf(method_end);
  if(i != -1)
  {
   QString text = method_end.cap(0);
   int size = text.size();
   text = QString("(rz::%1)").arg(text);
   cl_object new_text_clo = cl_cxx_backend::eval_string(text.toLatin1().data());

   new_text_clo = si_coerce_to_base_string(new_text_clo);
   unsigned char * cc = new_text_clo->base_string.self;

   QString new_text_qs;

   for(unsigned char* c = cc; *c != 0; ++c)
   {
    QChar qc = QChar::fromLatin1(*c);
    new_text_qs += qc;
   }

//   std::string s = cl_cxx::from_cl_object<std::string>(new_text_clo);
//   QString new_text_qs = QString::fromStdString(s);

   eval_text.replace(i, size, new_text_qs);
  }
 }

// for(int i = 0; i != -1;)
// {
//  i = eval_text.indexOf(raw_macro_finder);
//  if(i != -1)
//  {
//   QString text = raw_macro_finder.cap(1);
//   cl_object new_text_clo = cl_cxx_backend::eval_string(text.toLatin1().data());

//   new_text_clo = si_coerce_to_base_string(new_text_clo);
//   unsigned char * cc = new_text_clo->base_string.self;

//   QString new_text_qs;

//   for(unsigned char* c = cc; *c != 0; ++c)
//   {
//    QChar qc = QChar::fromLatin1(*c);
//    new_text_qs += qc;
//   }

////   std::string s = cl_cxx::from_cl_object<std::string>(new_text_clo);
////   QString new_text_qs = QString::fromStdString(s);

//   eval_text.replace(i, text.size() + 2, new_text_qs);
//  }
// }


 cl_cxx_backend::eval_string(symbols.toLatin1().data());

 QString saved_eval_text = eval_text;

 QString to_be_replaced = "#rz#lsf ;";
 int i = saved_eval_text.indexOf(to_be_replaced);
 if(i != -1)
 {
  saved_eval_text.replace(i, to_be_replaced.size(), load_support_file + " (progn ");
  saved_eval_text += "); end progn wrapper";
 }
 i = eval_text.indexOf(to_be_replaced);
 if(i != -1)
 {
  eval_text.replace(i, to_be_replaced.size(), "(progn " );//QString(" (progn ; progn wrapper.  " + load_support_comment));
  eval_text += "); end progn wrapper";
 }

 support_text += extra_support;
//   QString("\n\n;;; progn wrapper\n(progn \n%1\n);;;end progn wrapper")
//   .arg(eval_text);

 QString result_string;

 if(load_depth == 0)
 {
  if(support_file_name.isEmpty())
  {
   if(rzntl_flag_index == -1)
    result_string = initial_generated_string_ + saved_eval_text;
   else
    result_string = saved_eval_text;
  }
  else
  {
   QFile outfile(support_file_name);
   if (outfile.open(QIODevice::WriteOnly | QIODevice::Text))
   {
    outfile.write(initial_generated_string_.toLatin1());
    outfile.write("\n");
    outfile.write(support_text.toLatin1());
    outfile.close();
   }
   result_string = saved_eval_text;
  }
 }
 else
  result_string = ";;; loaded from top " + top_file + "\n\n" + saved_eval_text;

// qDebug() << "eval...\n" << load_support_file;

 for(QString sf : load_support_loads)
 {
  cl_cxx_backend::eval_string(sf.toLatin1().data());
 }
 for(QString sf : load_support_file_list)
 {
  cl_cxx_backend::eval_string(sf.toLatin1().data());
 }
// cl_cxx_backend::eval_string(load_support_file_list.toLatin1().data());
// cl_cxx_backend::eval_string(load_support_loads.toLatin1().data());

 cl_cxx_backend::eval_string(extra_support.toLatin1().data());

 // if(load_support_file_count == 1)
// {
//  load_support_file.replace(".rzs", ".rzsx");
//  qDebug() << "eval...\n" << load_support_file;

//  cl_cxx_backend::eval_string(load_support_file.toLatin1().data());
// }
// else if(load_support_file_count > 1)
// {
//  QStringList qsl = load_support_file.split(QRegExp("(\\))(?=\\()|$"));
//  for(QString sf : qsl)
//  {
//   sf += ')';
//   qDebug() << "eval...\n" << sf;
//   cl_cxx_backend::eval_string(sf.toLatin1().data());
//  }
// }



//? qDebug() << "eval...\n" << eval_text;
  cl_object obj = cl_cxx_backend::eval_string(eval_text.toLatin1().data());


 return result_string;

}

