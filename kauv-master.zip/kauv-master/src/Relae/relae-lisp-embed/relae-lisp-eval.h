
#ifndef RELAE_LISP_EVAL__H
#define RELAE_LISP_EVAL__H

//?
#define RELAE_LISP_EVAL__DEFAULT_INTERNAL_ECL_DIRECTORY "/extension/ecl/internal/ecl"

#include "relae-lisp-runtime/relae-lisp-runtime.h"
#include "relae-lisp-runtime/relae-lisp-argument.h"

#include "cl-cxx/object.hpp"

#include <QString>

class QDir;
class QStringList;

#include "kans.h"
KANS_(EmbL)

USING_KANS(EmbL)

class Relae_Lisp_Embed_Environment;

class Relae_Lisp_Eval
{
 Relae_Lisp_Embed_Environment* env_;

 Relae_Lisp_Runtime* relae_lisp_runtime_;

 QString initial_generated_string_;
// cdm_Result_Holder rh_;

public:

 Relae_Lisp_Eval(Relae_Lisp_Embed_Environment* e);

 void eval_quicklisp_setup();

 QObject* get_last_qobject();
//  : env_(e){}

// void set_result_holder(QTextStream* qts);

// typedef cl_cxx_backend::callback_t;

 static QString cl_arglist_to_qstring(cl_cxx_backend::cl_arglist arglist);


//? static void cl_arglist_to_qstrings(QStringList& result, cl_cxx_backend::cl_arglist arglist);
 static void cl_arglist_to_qstrings(QList<Relae_Lisp_Argument>& result, cl_cxx_backend::cl_arglist arglist);


 void check_flags_replace(QString& eval_text);

 void define_callback(cl_cxx_backend::callback_t cb,
  QString package_name, QString symbol_name, void* argument);

 void test_callback(cl_cxx_backend::callback_t cb);

 void prepare_callbacks();


 QString eval_string(QString eval_text);

 void eval_loaded_file(QString eval_text, QString extra_support, QString file_name);
 void eval_file(QString file_name, int load_depth = 0, QString top_file = QString());
 QString eval(QString eval_text, QString extra_support, QString file_name = QString(), int load_depth = 0, QString top_file = QString(), QDir* default_dir = nullptr);
 // cdm_Lisp_Embed_Environment* environment_;

 void eval_raw_file(QString file_name);

 void eval_raw_file_via_load(QString file_name);

 static cl_object eval_raw_text(QString eval_text);

 void minimal_eval(QString eval_text);

};


_KANS(EmbL)

#endif
