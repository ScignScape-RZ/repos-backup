

#ifndef RELAE_LISP_ARGUMENT__H
#define RELAE_LISP_ARGUMENT__H


#include "kans.h"


#include <QString>

//?#include <QDomDocument>

//class T_sp;
//typedef T_sp& Clasp_Object;


KANS_(EmbL)


struct Relae_Lisp_Argument
{
 QString internal_type;
 QString str;
  //?Clasp_Object object;
 QString declared_type;
 QString modifier;
};


_KANS(EmbL)

#endif


