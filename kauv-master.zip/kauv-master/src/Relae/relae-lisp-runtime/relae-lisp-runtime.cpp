
#include "relae-lisp-runtime.h"

#include <QDebug>

USING_KANS(EmbL)


Relae_Lisp_Runtime::Relae_Lisp_Runtime()
  : current_qobject_(nullptr)
{

}

QString Relae_Lisp_Runtime::run_lisp_callback(Relae_Lisp_Eval* reval, QList<Relae_Lisp_Argument>& args,
  void*& object_result, cl_object cl_result)
{
 QString result;
 QString cb_name = args.takeFirst().str;

 if(cb_name.startsWith('@'))
 {
  cb_name = cb_name.mid(1);

  if(cb_name.startsWith('_'))
  {
   last_qobject_ = current_qobject_;
   current_qobject_ = nullptr;
  }
  else if(cb_name.endsWith('_'))
  {
   cb_name = cb_name.append("builder");
   int id = QMetaType::type(cb_name.toLatin1());
   cb_name.append("*");

   //  cl += "*";
   int id_with_ptr = QMetaType::type(cb_name.toLatin1());

   const QMetaObject* qmo1 = QMetaType::metaObjectForType(id_with_ptr);

   if(qmo1)
   {
    void* pv = QMetaType::create(id);
    QObject* obj = static_cast<QObject*>(pv);

    current_qobject_ = obj;

    const QMetaObject* qmo = obj->metaObject();

    QString method_name = "check_construction";

//?   QMetaObject::invokeMethod(obj, method_name.toLatin1());

    qmo->invokeMethod(obj, method_name.toLatin1());

   //o->check();

   }
  }
  qDebug() << "CB_NAME: " << cb_name;
  //FictionBook_builder
 }
 else
 {
  QString mname;
  QString arg1;
  QString arg2;

  int arg_count = 0;

  typedef QMap<QString, QString> QStringMap_type;

  if( !held_tag_with_attributes_.isEmpty() &&
      (cb_name.startsWith("%!") || !cb_name.startsWith('%') ) )
  {
   if(current_qobject_)
   {
    const QMetaObject* qmo = current_qobject_->metaObject();
    if(held_ns_.isEmpty())
    {
     qmo->invokeMethod(current_qobject_, held_tag_with_attributes_.toLatin1(),
       Q_ARG(const QStringMap_type& ,stringmap_arg_));
    }
    else
    {
     qmo->invokeMethod(current_qobject_, held_tag_with_attributes_.toLatin1(),
       Q_ARG(QString ,held_ns_), Q_ARG(const QStringMap_type& ,stringmap_arg_));
     held_ns_.clear();
    }
    held_tag_with_attributes_.clear();
    stringmap_arg_.clear();

   }
  }

  if(cb_name.startsWith('%'))
  {
   mname = cb_name.mid(1);
   if(mname.startsWith('!'))
   {
    int pos = mname.indexOf(':');
    if(pos != -1)
    {
     held_ns_ = mname.mid(1, pos - 1);
     held_tag_with_attributes_ = mname.mid(pos + 1).prepend("Tag_");
    }
    else
    {
     held_tag_with_attributes_ = mname.mid(1).prepend("Tag_");
    }
    return QString();
   }
   else
   {
    mname = "absorb_attr";
    int pos = cb_name.indexOf(' ');
    if(pos != -1)
    {
     arg1 = cb_name.mid(1, pos - 1);
     arg2 = cb_name.mid(pos + 1);
     if(held_tag_with_attributes_.isEmpty())
     {
      arg_count = 2;
     }
     else
     {
      stringmap_arg_[arg1] = arg2;
      return QString();
     }
    }
   }
  }
  else if(cb_name.startsWith('&'))
  {
   mname = cb_name.mid(1);
   mname.replace('-', '_');
   mname.prepend("Tag__");
  }
//  else if(cb_name.startsWith("$%"))
//  {
//   mname = cb_name.mid(2);
//   mname.replace('-', '_');
//   held_tag_with_attributes_ = mname;
//   return QString();
//  }
  else if(cb_name.startsWith('$'))
  {
   int pos = cb_name.indexOf('/');
   if(pos != -1)
   {
    mname = cb_name.mid(pos + 1);
    arg1 = cb_name.mid(1, pos);

    mname.replace('-', '_');
    mname.prepend("Tag_");

    if(arg1.startsWith('%'))
    {
     held_ns_ = arg1.mid(1);
     held_tag_with_attributes_ = mname.prepend("Tag_");
     return QString();
    }

    ++arg_count;
    if(args.size() > 0)
    {
     arg2 = args.takeFirst().str;
     ++arg_count;
    }
   }
   else
   {
    mname = cb_name.mid(1);

    if(mname.startsWith('%'))
    {
     held_tag_with_attributes_ = mname.mid(1).prepend("Tag_");
     return QString();
    }

    mname.replace('-', '_');
    mname.prepend("Tag_");

    if(args.size() > 0)
    {
     arg1 = args.takeFirst().str;
     ++arg_count;
    }
   }
  }
  else
  {
   mname = cb_name;
   mname.replace('-', '_');
   mname.prepend("Tag_");
   if(args.size() > 0)
   {
    arg1 = args.takeFirst().str;
    arg_count = 1;
   }
  }

  if(current_qobject_)
  {
   const QMetaObject* qmo = current_qobject_->metaObject();
   switch(arg_count)
   {
   case 0:
    {
     qmo->invokeMethod(current_qobject_, mname.toLatin1());
    }
    break;
   case 1:
    {
     qmo->invokeMethod(current_qobject_, mname.toLatin1(),
      Q_ARG(QString ,arg1) );
    }
    break;
   case 2:
    {
     qmo->invokeMethod(current_qobject_, mname.toLatin1(),
      Q_ARG(QString ,arg1), Q_ARG(QString ,arg2));
    }
    break;
   }
  }

 }

 return QString();

 //qDebug() << "CB_NAME: " << cb_name;

}
