

#ifndef RELAE_LISP_RUNTIME__H
#define RELAE_LISP_RUNTIME__H

//?
#define RELAE_LISP_EVAL__DEFAULT_INTERNAL_ECL_DIRECTORY "/extension/ecl/internal/ecl"


#include "cl-cxx/object.hpp"

#include <QString>
#include <QMap>
#include <QMessageBox>


#include "accessors.h"

class QDir;
class QStringList;

#include "relae-lisp-argument.h"

#include "kans.h"

KANS_(EmbL)

USING_KANS(EmbL)

class Relae_Lisp_Eval;


class Relae_Lisp_Runtime
{

 QString initial_generated_string_;

 QObject* current_qobject_;
 QObject* last_qobject_;

// cdm_Result_Holder rh_;

 enum class Extra_Object_Types {
  N_A, _QDomDocument_,

 };

 Extra_Object_Types get_object_type_enum(QString key)
 {
  static QMap<QString, Extra_Object_Types> static_map {{
   {"QDomDocument", Extra_Object_Types::_QDomDocument_},
   }};
  return static_map.value(key, Extra_Object_Types::N_A);
 }


 static const QMetaObject*  get_qmo(QString key)
 {
  static QMap<QString, const QMetaObject* > static_map
  {{
   {"QMessageBox", &QMessageBox::staticMetaObject},
     //?{"Digamma_Runtime_Router", &Digamma_Runtime_Router::staticMetaObject},
  }};

  //static_map["QMessageBox"] = QMessageBox::staticMetaObject;

  return static_map.value(key, nullptr);

 }


// QDomDocument* qdd_;
// Digamma_Network_Runtime network_runtime_;
// Digamma_Xml_Source xml_source_;

 QMap<QString, QString> stringmap_arg_;

 QString held_tag_with_attributes_;
 QString held_ns_;



public:

 Relae_Lisp_Runtime();

 ACCESSORS(QObject* ,last_qobject)


 //?ACCESSORS(QDomDocument* ,qdd)


 QString run_lisp_callback(Relae_Lisp_Eval* reval, QList<Relae_Lisp_Argument>& args,
   void*& object_result, cl_object cl_result);

 //?static void parse_string_plex(QString code, QMap<QString, QString>& result);

//?
// QString run_read_request(QDomDocument& qdd, QMap<QString, QString>& string_map);
// QString run_write_request(QMap<QString, QString>& string_map);

};


_KANS(EmbL)

#endif

