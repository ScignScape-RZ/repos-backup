
#include <iostream>
#include <cstdlib>
#include <ecl/ecl.h>

#include <QString>

#include "relae-lisp-embed/relae-lisp-embed-environment.h"
#include "relae-lisp-embed/relae-lisp-eval.h"

#include "kans.h"

USING_KANS(EmbL)


//// Define a function to run arbitrary Lisp expressions
//cl_object lisp(const std::string & call)
//{
// return cl_safe_eval(c_string_to_object(call.c_str()), Cnil, Cnil);
//}


//cl_object us_lisp(const std::string & call)
//{
// return cl_eval(c_string_to_object(call.c_str()));
//}


//cl_object qs_lisp(const QString& call)
//{
// return cl_eval(c_string_to_object(call.toStdString().c_str()));
//}


//void initialize(int argc, char **argv)
//{
// // Bootstrap
////? cl_boot(argc, argv);
////? atexit(cl_shutdown);

// // Run initrc script
// lisp("(load \"/extension/ecl/initrc.lisp\")");
//}

int main(int argc, char* argv[])
{

 Relae_Lisp_Embed_Environment env(argc, argv);
 Relae_Lisp_Eval reval(&env);

 // Bootstrap Lisp
//? initialize(argc,argv);

//? qs_lisp("(load \"/extension/ecl/t2.lisp\")");
// us_lisp("(load \"../t2.lisp\")");

 env.set_quicklisp_location("/home/nlevisrael/quicklisp/setup.lisp");
 reval.eval_quicklisp_setup();

 reval.eval_raw_file_via_load("/extension/ecl/t1.cl");

// reval.eval_quicklisp_setup();

// lisp("(load \"../t1.lisp\")");

 return EXIT_SUCCESS;
}

