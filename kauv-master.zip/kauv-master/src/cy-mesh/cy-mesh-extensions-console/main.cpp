
/***************************************************************************
                          main.cpp  -  description
                             -------------------
    begin                : mar mar 8 2005
    copyright            : (C) 2005 by houssem
    email                : houssem@localhost
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include <QApplication>
#include <QMainWindow>
#include "cy-mesh-extensions/qlispconsole-dialog.h"
#include "cy-mesh-extensions/qlispconsole.h"

/* Define the following to fix __ctype_* from GLIBC2.3 and upper
   if not compiled using the same GLIBC */
//#define FIX__CTYPE_

#ifdef FIX__CTYPE_
#include <ctype.h>
__const unsigned short int *__ctype_b;
__const __int32_t *__ctype_tolower;
__const __int32_t *__ctype_toupper;

void ctSetup()
{
  __ctype_b = *(__ctype_b_loc());
  __ctype_toupper = *(__ctype_toupper_loc());
  __ctype_tolower = *(__ctype_tolower_loc());
}
#endif

USING_QSNS(Cy_Mesh)

//The main entry
int main( int argc, char ** argv )
{
#ifdef FIX__CTYPE_
    ctSetup();
#endif
    QApplication a( argc, argv );

    //Create and show the main window
    //QMainWindow mw;
    //mw.setMinimumSize(640, 480);
    //Instantiate and set the focus to the QLispConsole
    QLispConsole* console = QLispConsole::getInstance(nullptr);

    console->set_cb([](const QString& code, int* res, QString& result)
    {
     result = code + QString::number(*res);

    });

    QLispConsole_Dialog dlg(console);

    dlg.show();


    return a.exec();
}


