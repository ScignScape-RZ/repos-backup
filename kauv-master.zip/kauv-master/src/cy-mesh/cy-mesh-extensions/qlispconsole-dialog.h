
#ifndef QLISPCONSOLE_DIALOG__H
#define QLISPCONSOLE_DIALOG__H


#include <QString>
#include <QMainWindow>

#include <QTextEdit>
//?#include <QWebView>

#include <QLabel>
#include <QPushButton>

#include <QDialog>

#include <QApplication>

#include <QComboBox>

#include "accessors.h"

#include "flags.h"

#include "qsns.h"

#include <QEvent>
#include <QMouseEvent>

#include <QTabWidget>

#include <QFrame>

//#include "incident-form-dialog.h"

class QPushButton;
class QTextEdit;
class QPlainTextEdit;
class QLineEdit;
class QTabWidget;
class QDialogButtonBox;
class QVBoxLayout;
class QHBoxLayout;
class QCheckBox;
class QFormLayout;
class QSplitter;
class QGridLayout;
class QListWidget;
class QTableWidget;
class QScrollArea;
class QGroupBox;
class QTableWidgetItem;
class QGraphicsRectItem;
class QRubberBand;

class QLispConsole;

//qsns_(Cy_Mesh)
namespace QScign{ namespace Cy_Mesh{


class QLispConsole_Dialog : public QDialog
{
 Q_OBJECT

 QTabWidget* main_notebook_;
 QLispConsole* main_console_;
 QTextEdit* cmd_log_text_edit_;
 QTextEdit* http_log_text_edit_;

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QPushButton* button_proceed_;


 QVBoxLayout* main_layout_;




public:

 QLispConsole_Dialog(QLispConsole* main_console, QWidget* parent = nullptr);

 int get_current_line_number();

 void log_command(QStringList* list, QString* cmd);

 ~QLispConsole_Dialog();

 //void close_button_clicked();

Q_SIGNALS:
 void canceled(QDialog*);
 void accepted(QDialog*);


public Q_SLOTS:
 void accept();
 void cancel();

 void proceed();


};

} } //_qsns(Cy_Mesh)



#endif //  QLISPCONSOLE_DIALOG__H


