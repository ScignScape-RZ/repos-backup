

#include <QApplication>
#include <QGraphicsView>

#include <QList>
#include <QDebug>

#include <QMessageBox>

#include <QMenu>

#include <QGraphicsItem>

#include <QScreen>
#include <QTimer>
#include <QTime>

#include <QToolBar>

#include <QImage>

#include <QApplication>
#include <QDesktopWidget>

#include <QFileDialog>
#include <QUrl>


#include "cy-mesh-webview-dialog/paraviews/cymesh-custom-web-view-dialog.h"
#include "cy-mesh-webview-dialog/cymesh-custom-navigation-request-resolver.h"

#include "cy-mesh-webview-dialog/pleneviews/cymesh-custom-web-view-frame.h"

#include "textio.h"

USING_QSNS(Cy_Mesh)


//?USING_QSNS(EmbL)



int main(int argc, char **argv)
{

 QApplication qapp(argc, argv);

 QString page = "/ext_root/kauv/cpp/src/cy-mesh/web-repl.html";

 QUrl url = QUrl::fromLocalFile(page);

 CyMesh_Custom_Web_View_Dialog dlg(url);

 CyMesh_Custom_Navigation_Request_Resolver ccnrr;
 dlg.init_navigation_request_resolver(ccnrr, url);

 QObject::connect(&ccnrr, &CyMesh_Custom_Navigation_Request_Resolver::navigation_requested,
   [](const QUrl& url, QObject* recip)
 {
  CyMesh_Custom_Web_View_Frame* ccwvf = qobject_cast<CyMesh_Custom_Web_View_Frame*>(recip);

  if(!ccwvf)
  {
   // something wrong ...
   return;
  }

     QString cl;
     cl.append("===========================");
     cl.append("(test)");
     cl.append("---------------------------");

     cl.replace('\"', "%qq%");
     cl.replace('\\n', "%nl%");

     QString jscode = QString("write_response(\"%1\")").arg(cl);

     ccwvf->get_current_custom_web_page()->runJavaScript(jscode,
       [](const QVariant& res)
     {
      qDebug() << "RES: " << res.toString();
     });


//  ccwvf->get_current_custom_web_page()->runJavaScript(QString("document.getElementById('lisp-text-area').value"),
//                                            [ccwvf](const QVariant& res)
//  {
//   qDebug() << "Lisp Code = " << res.toString();
//   QString cl;
//   cl.append("\n\n<br>===========================<br>\n");
//   cl.append("(test)");
//   cl.append("\n<br>---------------------------<br>\n\n");

//   cl.replace('\"', "%qq%");

//   QString jscode = QString("write_response(\"%1\")").arg(cl);

//   ccwvf->get_current_custom_web_page()->runJavaScript(jscode,
//     [](const QVariant& res)
//   {
//    qDebug() << "RES: " << res.toString();
//   });

//  });

 });



 //ScignSeer_Main_Reader_Dialog dlg("/ext_root/fbreader/books/9783110495331_epub/OPS/content/01_Cover.xhtml");
 dlg.show();

 return qapp.exec();

}


