
#include "cymesh-custom-navigation-request-resolver.h"


USING_QSNS(Cy_Mesh)


CyMesh_Custom_Navigation_Request_Resolver::CyMesh_Custom_Navigation_Request_Resolver()
  : navigation_recipient_(nullptr), containing_dialog_(nullptr)
{

}

bool CyMesh_Custom_Navigation_Request_Resolver::check_navigation(const QUrl& url)
{
 if(url == origin_url_)
 {
  return true;
 }
 if(navigation_recipient_)
 {
  Q_EMIT(navigation_requested(url, navigation_recipient_, containing_dialog_));
  return false;
 }
 else
 {
  return true;
 }

}
