
#ifndef CYMESH_CUSTOM_NAVIGATION_REQUEST_RESOLVER__H
#define CYMESH_CUSTOM_NAVIGATION_REQUEST_RESOLVER__H

#include <QObject>

#include <QString>

#include "qsns.h"

#include "accessors.h"

#include <QUrl>


namespace QScign{ namespace Cy_Mesh{

class CyMesh_Custom_Web_View_Dialog;


class CyMesh_Custom_Navigation_Request_Resolver : public QObject
{
 Q_OBJECT

 QObject* navigation_recipient_;

 QUrl origin_url_;

 CyMesh_Custom_Web_View_Dialog* containing_dialog_;

public:

 CyMesh_Custom_Navigation_Request_Resolver();

 ACCESSORS(QObject* ,navigation_recipient)
 ACCESSORS(QUrl ,origin_url)
 ACCESSORS(CyMesh_Custom_Web_View_Dialog* ,containing_dialog)


 bool check_navigation(const QUrl& url);

Q_SIGNALS:

 void navigation_requested(const QUrl&, QObject*, CyMesh_Custom_Web_View_Dialog*);



};


} }

#endif
