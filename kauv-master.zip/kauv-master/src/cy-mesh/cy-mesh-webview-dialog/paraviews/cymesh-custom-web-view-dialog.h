
#ifndef CYMESH_CUSTOM_WEB_VIEW_DIALOG__H
#define CYMESH_CUSTOM_WEB_VIEW_DIALOG__H


#include <QString>
#include <QMainWindow>

#include <QTextEdit>
//?#include <QWebView>

#include <QWebEngineView>
#include <QLabel>
#include <QPushButton>

#include <QDialog>

#include <QApplication>

#include <QComboBox>

#include "accessors.h"

#include "flags.h"

#include "qsns.h"

#include <QEvent>
#include <QMouseEvent>

#include <QFrame>

//#include "incident-form-dialog.h"

class QPushButton;
class QTextEdit;
class QPlainTextEdit;
class QLineEdit;
class QTabWidget;
class QDialogButtonBox;
class QVBoxLayout;
class QHBoxLayout;
class QCheckBox;
class QFormLayout;
class QSplitter;
class QGridLayout;
class QListWidget;
class QTableWidget;
class QScrollArea;
class QGroupBox;
class QTableWidgetItem;
class QGraphicsRectItem;
class QRubberBand;

//qsns_(Cy_Mesh)
namespace QScign{ namespace Cy_Mesh{


class NDP_Antemodel;
class NDP_Project;
class NDP_Project_Initial;

class CyMesh_Custom_Web_View_Frame;
class CyMesh_Custom_Navigation_Request_Resolver;

class CyMesh_Custom_Web_View_Dialog : public QDialog
{
 Q_OBJECT

 CyMesh_Custom_Web_View_Frame* main_frame_;

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QPushButton* button_proceed_;


 QVBoxLayout* main_layout_;


 QUrl original_url_;

public:

 CyMesh_Custom_Web_View_Dialog(QUrl url, QWidget* parent = nullptr);


 void init_navigation_request_resolver(CyMesh_Custom_Navigation_Request_Resolver& ccnrr, QUrl url);

 ~CyMesh_Custom_Web_View_Dialog();


 void register_navigation_request_resolver(CyMesh_Custom_Navigation_Request_Resolver* scnrr);

 void load_url(const QUrl& url);
 void load_url(QString url);
 void load_new_url(QUrl url, QString url_text);
 void load_local_file(QString path);
 void close_button_clicked();

 void reload_page();


Q_SIGNALS:
 void canceled(QDialog*);
 void accepted(QDialog*);


public Q_SLOTS:
 void accept();
 void cancel();

 void proceed();


};

} } //_qsns(Cy_Mesh)



#endif //  CYMESH_CUSTOM_WEB_VIEW_DIALOG__H


