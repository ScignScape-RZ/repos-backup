
#include "cymesh-pdf-view-dialog/paraviews/cymesh-pdf-view-dialog.h"
#include "cymesh-pdf-view-dialog/pleneviews/view-pdf-frame.h"
#include "cymesh-pdf-view-dialog/subwindows/pdf-document-widget.h"

#include <QApplication>

USING_QSNS(Cy_Mesh)

int main(int argc, char *argv[])
{
 QApplication qapp(argc, argv);
 CyMesh_PDF_View_Dialog* vpd = new CyMesh_PDF_View_Dialog(nullptr,
   "/ext_root/kauv/pdf/tex/t1.pdf");
 vpd->show();
 qapp.exec();
 return 0;
}
