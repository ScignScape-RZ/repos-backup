
#include "rz-dynamo-expression.h"

#include "rz-dynamo-form.h"

#include "rzns.h"

USING_RZNS(RECore)
USING_RZNS(GVal)

RZ_Dynamo_Expression::RZ_Dynamo_Expression(RZ_Dynamo_Form& form)
  :  form_(form)
{

}

caon_ptr<RZ_Dynamo_Form> RZ_Dynamo_Expression::ptr_to_form()
{
 return &form_;
}


void RZ_Dynamo_Expression::write_as_statement(QTextStream& qts)
{
 if(assignment_token_.isEmpty())
 {
  qts << "\n;statement_\n";
  qts << "\n(kb::st_)\n";
  write(qts);
  qts << "\n(kb::_st)\n";
  qts << "\n ;_statement\n";
 }
 else
 {
  QString assignment_target = form_.get_assignment_target();
  qts << "\n;assignment statement_\n";
  qts << "\n(kb::sa_ :|" << encode_assignment_token() << "| "
      << assignment_target << ")\n";
  write(qts);
  qts << "\n(kb::_sa)\n";
  qts << "\n ;_assignment statement\n";
 }
}

QString RZ_Dynamo_Expression::encode_assignment_token()
{
 if(assignment_token_ == "\\=")
 {
  return "sng";
 }
 else if(assignment_token_ == "\\\\=")
 {
  return "dbl";
 }
 else
 {
  // others? ...
  return "?";
 }
}


void RZ_Dynamo_Expression::write(QTextStream& qts)
{
 form_.write_unmediated(qts);
}
