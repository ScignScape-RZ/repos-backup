
#include "rz-dynamo-form.h"
#include "rz-dynamo-block.h"

#include "rz-graph-core/code/rz-re-block-entry.h"

#include "rz-graph-valuer/scope/rz-lisp-graph-block-info.h"

#include "rz-dynamo-type-declaration.h"
#include "rz-dynamo-expression.h"

#include "rzns.h"

USING_RZNS(GVal)

RZ_Dynamo_Form::RZ_Dynamo_Form(caon_ptr<RZ_Dynamo_Form> parent)
  :  parent_(parent), parent_lambda_position_(-1),
     first_nested_block_(nullptr), implicit_added_depth_(0),
     type_declaration_(nullptr), expression_(nullptr)
{

}

RZ_Dynamo_Form::RZ_Dynamo_Form(caon_ptr<RZ_Dynamo_Block> block)
  :  parent_(nullptr), plene_block_(block),
     first_nested_block_(nullptr), implicit_added_depth_(0),
     type_declaration_(nullptr), expression_(nullptr)
{

}

QString RZ_Dynamo_Form::get_assignment_target()
{
 return inner_elements_.first().second.mid(1);
}

void RZ_Dynamo_Form::write_as_statement(QTextStream& qts)
{
 if(type_declaration_)
 {
  type_declaration_->write(qts);
 }
 else if(expression_)
 {
  expression_->write_as_statement(qts);
 }
 else
 {
  write(qts);
 }

// if(first_nested_block_)
// {
//  // don't wrap in st_ ...
//  write(qts);
// }
// else
// {
////?
////  qts << "\n;statement_\n";
////  qts << "\n(kb::st_)\n";
//  write(qts);
////?
////  qts << "\n(kb::_st)\n";
////  qts << "\n ;_statement\n";
// }


 //if(caon_ptr<RE_Node> start_node = )
}

//?
//void RZ_Dynamo_Form::close_with_prelim(QString text)
//{
// prelim_ = text;
//}


void RZ_Dynamo_Form::add_prin1_quoted_form(QString text, QString note)
{
 RZ_Dynamo_Form* new_form = new RZ_Dynamo_Form(this);
 new_form->set_raw_text(QString("\n\n(prin1-to-string '(%1))\n\n").arg(text));
  //"\n\n(kb::hp (prin1-to-string '(" << prelim_ << ")))\n\n";
 inner_elements_.push_back({new_form, note});

}

void RZ_Dynamo_Form::init_type_declaration(QString cmd)
{
 // // should distinguish cmd == "my" and "our" ...
 type_declaration_ = new RZ_Dynamo_Type_Declaration(*this);
}

void RZ_Dynamo_Form::init_expression()
{
 expression_ = new RZ_Dynamo_Expression(*this);
}

void RZ_Dynamo_Form::init_assignment_expression(QString tok)
{
 //chief_ = tok;
 init_expression();
 expression_->set_assignment_token(tok);
}

void RZ_Dynamo_Form::set_assignment_token(QString rt)
{
 rt.prepend('=');
 inner_elements_.push_back({nullptr, rt});
}


void RZ_Dynamo_Form::write(QTextStream& qts)
{
 if(type_declaration_)
 {
  type_declaration_->write(qts);
 }
 else if(expression_)
 {
  expression_->write(qts);
 }
 else if(!raw_text_.isEmpty())
 {
  qts << raw_text_;
 }
 else
 {
  write_unmediated(qts);
 }
}

void RZ_Dynamo_Form::write_unmediated(QTextStream& qts)
{
 QString icd = QString(implicit_added_depth_, '(');

 qts << icd;

 if(plene_block_)
 {
  qts << "\n;block_\n";

  if(caon_ptr<RE_Block_Entry> rbe = plene_block_->get_block_entry())
  {
   if(rbe->flags.if_block)
   {
    //?
    qts << "(progn \n";
   }
  }
  else
  {
   // so get info plene_block_ mode ...
   qts << "\n;; fn body"
     "\n(kb::fb_)";

//   switch(plene_block_->block_sequence_mode())
//   {
//   case RZ_Dynamo_Block::Block_Sequence_Modes::Ghost:
//    qts << "(progn\n";
//    break;
//   default:
//    qts << "(lambda (ks)\n";
//    break;
//   }

  }

  plene_block_->write(qts);
 }
 else
 {
  //?qts << '(';
 }

 QList<caon_ptr<RZ_Dynamo_Form>> nested_forms;
 int nf_count = 0;

 for(QPair<caon_ptr<RZ_Dynamo_Form>, QString> element : inner_elements_)
 {
  if(element.first)
  {
   caon_ptr<RZ_Dynamo_Form> ef = element.first;
   CAON_PTR_DEBUG(RZ_Dynamo_Form ,ef)

   QString note = element.second;

   if(note.isEmpty())
   {
    // //  there are deferred to after ...
    nested_forms.push_back(ef);
    ++nf_count;
    qts << " :#" << nf_count << ' ';
   }
   else
   {
    qts << ' ' << note << ' ';
    element.first->write(qts);
    qts << ' ';
   }
  }
  else
  {
   char c = element.second[0].toLatin1();
   QString str = element.second.mid(1);
   switch(c)
   {
   case '.':
    qts << "\n(" << str;;
    break;

   case '@':
    qts << ' ' << str << ' ';
    break;

   case '&':
    qts << "\n(kb::fc \"" << str << "\")";
    break;

   case '$':
    qts << "\n(kb::lc \"" << str << "\")";
    break;

   case '#':
    qts << "\n(kb::ll \"" << str << "\")";
    break;

   case '=':
    qts << "\n;;assignment: " << str;
    break;

   }

   //?qts << element.second << " ";
  }
 }

 if(chief_.startsWith('.'))
 {
  qts << "\n;;instruction\n)\n";
 }

 if(plene_block_)
 {
  qts << "\n;_plene_block";
  qts << "\n(kb::_fb)";
  //?qts << ")\n";
 }
 else
 {
  //?qts << ')';
 }

 for(caon_ptr<RZ_Dynamo_Form> nf: nested_forms)
 {
  qts << ' ';
  nf->write(qts);
  qts << ' ';
 }


// qts << follow_;

 //if(caon_ptr<RE_Node> start_node = )


}

void RZ_Dynamo_Form::add_instruction_token(QString tok)
{
 chief_ = tok.prepend('.');
 add_string_token(chief_);
}

void RZ_Dynamo_Form::add_assignment_initialization_token(QString tok)
{
 // // none that this mimics add_fn_token ...
 chief_ = tok.prepend('&');
 add_string_token(chief_);
 //expression_->set_assignment_target(tok);
}

void RZ_Dynamo_Form::add_argument_token(QString tok)
{
 if(chief_.startsWith('.'))
 {
  add_kauvir_token(tok);
 }
//?
// else if(chief_.endsWith('='))
// {
//  expression_->add_list_token(tok);
// }
 else
 {
  add_carrier_token(tok);
 }
}


void RZ_Dynamo_Form::add_literal_token(QString tok)
{
 if(chief_.startsWith('.'))
 {
  add_kauvir_token(tok);
 }
 else
 {
  add_string_token(tok.prepend('#'));
 }
}

void RZ_Dynamo_Form::add_carrier_token(QString tok)
{
 add_string_token(tok.prepend('$'));
}

void RZ_Dynamo_Form::add_bridge_token(QString tok)
{
 add_string_token(tok.prepend('%'));
}

void RZ_Dynamo_Form::add_fn_token(QString tok)
{
 chief_ = tok.prepend('&');
 add_string_token(chief_);
}

void RZ_Dynamo_Form::add_kauvir_token(QString tok)
{
 if(tok.startsWith('('))
 {
  add_string_token(tok.prepend('@'));
 }
 else if(tok.startsWith("$\\"))
 {
  tok.prepend("@\"");
  tok.append('\"');
  add_string_token(tok);
 }
 else if(!tok.startsWith(':'))
 {
  tok.prepend("@'|");
  tok.append('|');
  add_string_token(tok);
 }
 else
 {
  add_string_token(tok.prepend('@'));
 }
}

void RZ_Dynamo_Form::add_string_token(QString tok)
{
 inner_elements_.push_back({nullptr, tok});
}

void RZ_Dynamo_Form::add_expression(caon_ptr<RZ_Dynamo_Form> form)
{
 inner_elements_.push_back({form, QString()});
}

void RZ_Dynamo_Form::add_nested_block(caon_ptr<RZ_Dynamo_Block> block)
{
 if(!first_nested_block_)
 {
  first_nested_block_ = block;
 }
 caon_ptr<RZ_Dynamo_Form> form = new RZ_Dynamo_Form(block);
 inner_elements_.push_back({form, QString()});
}

