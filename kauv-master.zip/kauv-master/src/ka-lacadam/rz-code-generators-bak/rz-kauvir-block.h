
#ifndef RZ_KAUVIR_BLOCK__H
#define RZ_KAUVIR_BLOCK__H

#include "accessors.h"
#include "flags.h"

#include <QString>
#include <QMap>

#include <QVector>

#include <QTextStream>

#include "rzns.h"

#include "relae-graph/relae-caon-ptr.h"

RZNS_(RECore)
 class RE_Node;
 class RE_Block_Entry;
_RZNS(RECore)

USING_RZNS(RECore)

RZNS_(GBuild)
 class RZ_Lisp_Graph_Visitor;
 class RZ_Lisp_Graph_Visitor_Kauvir;
_RZNS(GBuild)

USING_RZNS(GBuild)

RZNS_(GVal)

class RZ_Kauvir_Form;
class RZ_Lisp_Graph_Lexical_Scope;
class RZ_Function_Def_Syntax;
class RZ_Lisp_Graph_Block_Info;


class RZ_Kauvir_Block
{
public:

 enum class Block_Sequence_Modes {
  N_A, If_Else, If_Elsif, Map, Ghost
 };

private:


 caon_ptr<RZ_Lisp_Graph_Lexical_Scope> lexical_scope_;

 caon_ptr<RZ_Kauvir_Block> parent_block_;
 caon_ptr<RZ_Kauvir_Block> continue_block_;

 QVector<caon_ptr<RZ_Kauvir_Form>> forms_;

 caon_ptr<RZ_Kauvir_Form> current_form_;
 caon_ptr<RZ_Kauvir_Form> last_form_;

 caon_ptr<RZ_Lisp_Graph_Block_Info> pending_block_info_;
 caon_ptr<RZ_Lisp_Graph_Block_Info> block_info_;
 caon_ptr<RZ_Kauvir_Form> preceding_expression_form_;

 QString held_token_;

 QString entry_lisp_code_;

 int parent_lambda_position_;

 void add_form_from_call_entry_node(RZ_Lisp_Graph_Visitor_Kauvir& visitor_kauvir,
   RE_Node& entry_node);

 QString es_argument_;

 Block_Sequence_Modes block_sequence_mode_;

public:

 RZ_Kauvir_Block(caon_ptr<RZ_Kauvir_Block> parent_block = nullptr);

 ACCESSORS(caon_ptr<RZ_Kauvir_Block> ,parent_block)
 ACCESSORS(caon_ptr<RZ_Kauvir_Block> ,continue_block)

 ACCESSORS(QVector<caon_ptr<RZ_Kauvir_Form>> ,forms)
 ACCESSORS(int ,parent_lambda_position)
 ACCESSORS(QString ,entry_lisp_code)

 ACCESSORS(caon_ptr<RZ_Lisp_Graph_Block_Info> ,pending_block_info)
 ACCESSORS(caon_ptr<RZ_Lisp_Graph_Block_Info> ,block_info)
 ACCESSORS(caon_ptr<RZ_Kauvir_Form> ,preceding_expression_form)

 ACCESSORS(Block_Sequence_Modes ,block_sequence_mode)

 ACCESSORS(caon_ptr<RZ_Lisp_Graph_Lexical_Scope> ,lexical_scope)




 ACCESSORS(QString ,es_argument)

 caon_ptr<RE_Block_Entry> get_block_entry();

 RZ_Lisp_Graph_Visitor& visitor();

 void write(QTextStream& qts);

 void scan_top_level(RZ_Lisp_Graph_Visitor_Kauvir& visitor_kauvir);

 void scan(RZ_Lisp_Graph_Visitor_Kauvir& visitor_kauvir, RE_Node& start_node);

 void scan_form_from_start_node(RZ_Lisp_Graph_Visitor_Kauvir& visitor_kauvir,
   RE_Node& start_node);

 void scan_form_from_statement_entry_node(RZ_Lisp_Graph_Visitor_Kauvir& visitor_kauvir,
   RE_Node& start_node);

 //ACCESSORS(QString ,symbol_separator)

};

_RZNS(GVal)

#endif
