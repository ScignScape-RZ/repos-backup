
#ifndef RZ_KAUVIR_FORM__H
#define RZ_KAUVIR_FORM__H

#include "accessors.h"
#include "flags.h"

#include <QString>
#include <QMap>
#include <QVector>
#include <QPair>

#include <QTextStream>

#include "rzns.h"

#include "relae-graph/relae-caon-ptr.h"


RZNS_(GBuild)
 class RZ_Lisp_Graph_Visitor;
 class RZ_Lisp_Graph_Visitor_Kauvir;
_RZNS(GBuild)

USING_RZNS(GBuild)

RZNS_(GVal)

class RZ_Kauvir_Block;


class RZ_Kauvir_Form
{
 QVector<QPair<caon_ptr<RZ_Kauvir_Form>, QString>> inner_elements_;

 typedef QVector<QPair<caon_ptr<RZ_Kauvir_Form>, QString>> inner_elements_type;

 caon_ptr<RZ_Kauvir_Form> parent_;

 caon_ptr<RZ_Kauvir_Block> plene_block_;

 int parent_lambda_position_;

 int implicit_added_depth_;

public:

 RZ_Kauvir_Form(caon_ptr<RZ_Kauvir_Form> parent = nullptr);

 RZ_Kauvir_Form(caon_ptr<RZ_Kauvir_Block> block);

 void write(QTextStream& qts);
 void write_as_statement(QTextStream& qts);

 ACCESSORS__RGET(inner_elements_type ,inner_elements)
 ACCESSORS(caon_ptr<RZ_Kauvir_Form> ,parent)
 ACCESSORS(int ,parent_lambda_position)
 ACCESSORS(int ,implicit_added_depth)


 void add_string_token(QString tok);
 void add_expression(caon_ptr<RZ_Kauvir_Form> form);

 void add_nested_block(caon_ptr<RZ_Kauvir_Block> block);

};

_RZNS(GVal)

#endif
