
#ifndef RZ_KAUVIR_OUTPUT__H
#define RZ_KAUVIR_OUTPUT__H

#include "accessors.h"
#include "flags.h"

#include <QString>
#include <QMap>

#include <QTextStream>

#include "rzns.h"

#include "relae-graph/relae-caon-ptr.h"

#include "rz-function-def-syntax.h"



RZNS_(GBuild)
 class RZ_Lisp_Graph_Visitor;
 class RZ_Lisp_Graph_Visitor_Kauvir;
_RZNS(GBuild)

USING_RZNS(GBuild)

RZNS_(GVal)

class RZ_Kauvir_Block;



class RZ_Kauvir_Output
{

 RZ_Lisp_Graph_Visitor_Kauvir& visitor_kauvir_;
 RZ_Lisp_Graph_Visitor& visitor();

 caon_ptr<RZ_Kauvir_Block> top_level_block_;

 //?RZ_Function_Def_Syntax function_def_syntax_;

 void init_function_def_syntax();

public:

 RZ_Kauvir_Output(RZ_Lisp_Graph_Visitor_Kauvir& visitor_kauvir);

 void write(QTextStream& qts);

 void init_top_level_block();

 //ACCESSORS(QString ,symbol_separator)

};

_RZNS(GVal)

#endif
