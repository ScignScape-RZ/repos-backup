
//#ifndef RZ_DYNAMO_SPECIAL_FORM__H
//#define RZ_DYNAMO_SPECIAL_FORM__H

//#include "accessors.h"
//#include "flags.h"

//#include <QString>
//#include <QMap>
//#include <QVector>
//#include <QPair>

//#include <QTextStream>

//#include "rzns.h"

//#include "relae-graph/relae-caon-ptr.h"


//RZNS_(GBuild)
// class RZ_Lisp_Graph_Visitor;
// class RZ_Lisp_Graph_Visitor_Kauvir;
//_RZNS(GBuild)

//USING_RZNS(GBuild)

//RZNS_(GVal)

//class RZ_Dynamo_Block;
//class RZ_Dynamo_Type_Declaration;
//class RZ_Dynamo_Expression;
//class RZ_Dynamo_Form;


//class RZ_Dynamo_Special_Form
//{

//public:

// RZ_Dynamo_Special_Form(caon_ptr<RZ_Dynamo_Form> parent = nullptr);

// void write(QTextStream& qts);


//};

//_RZNS(GVal)

//#endif
