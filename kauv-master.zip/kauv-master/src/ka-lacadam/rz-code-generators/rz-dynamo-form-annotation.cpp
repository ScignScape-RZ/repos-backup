
#include "rz-dynamo-form-annotation.h"
#include "rzns.h"

#include "rz-dynamo-block.h"

USING_RZNS(GVal)

RZ_Dynamo_Form_Annotation::RZ_Dynamo_Form_Annotation()
  :  Flags(0)
{

}

