
#include "rz-dynamo-form.h"
#include "rz-dynamo-block.h"

#include "rz-graph-core/code/rz-re-block-entry.h"

#include "rz-graph-valuer/scope/rz-lisp-graph-block-info.h"

#include "rz-dynamo-type-declaration.h"
#include "rz-dynamo-expression.h"

#include "rz-dynamo-form-annotation.h"

#include <functional>

#include "rzns.h"

#define ANNOTATION_FLAG(x) \
  (annotation_ && annotation_->flags.x)

USING_RZNS(GVal)

RZ_Dynamo_Form::RZ_Dynamo_Form(caon_ptr<RZ_Dynamo_Form> parent)
  :  parent_(parent), parent_lambda_position_(-1),
     first_nested_block_(nullptr), implicit_added_depth_(0),
     nesting_level_(0),
     type_declaration_(nullptr), expression_(nullptr),
     assignment_token_(MS_Token::Null()), annotation_(nullptr)
{

}

RZ_Dynamo_Form::RZ_Dynamo_Form(caon_ptr<RZ_Dynamo_Block> block)
  :  parent_(nullptr), plene_block_(block),
     first_nested_block_(nullptr), implicit_added_depth_(0),
     type_declaration_(nullptr), expression_(nullptr),
     assignment_token_(MS_Token::Null())
{

}

QString RZ_Dynamo_Form::get_assignment_target()
{
 return assignment_token_.raw_text;
}

void RZ_Dynamo_Form::write_as_statement(QTextStream& qts)
{
 if(type_declaration_)
 {
  CAON_PTR_DEBUG(RZ_Dynamo_Type_Declaration ,type_declaration_)
  type_declaration_->write(qts);
 }
 else if(expression_)
 {
  expression_->write_as_statement(qts);
 }
 else
 {
  write(qts);
 }

// if(first_nested_block_)
// {
//  // don't wrap in st_ ...
//  write(qts);
// }
// else
// {
////?
////  qts << "\n;statement_\n";
////  qts << "\n(kb::st_)\n";
//  write(qts);
////?
////  qts << "\n(kb::_st)\n";
////  qts << "\n ;_statement\n";
// }


 //if(caon_ptr<RE_Node> start_node = )
}

//?
//void RZ_Dynamo_Form::close_with_prelim(QString text)
//{
// prelim_ = text;
//}


void RZ_Dynamo_Form::add_prin1_quoted_form(QString text, MS_Token mt)
{
 check_init_annotation();
 annotation_->flags.has_prin1_quoted_form = true;

 RZ_Dynamo_Form* new_form = new RZ_Dynamo_Form(this);

 new_form->set_raw_text(QString("\n\n(prin1-to-string '(%1))\n\n").arg(text));
  //"\n\n(kb::hp (prin1-to-string '(" << prelim_ << ")))\n\n";

 inner_elements_.push_back({new_form, mt});

 //?inner_elements_.push_back({new_form, {MS_Token_Kinds::Internal_String, note}});

}

void RZ_Dynamo_Form::init_type_declaration(QString cmd)
{
 if(type_declaration_)
 {
  CAON_PTR_DEBUG(RZ_Dynamo_Type_Declaration ,type_declaration_)
  // // this is an error ...
  return;
 }
 // // should distinguish cmd == "my" and "our" ...
 type_declaration_ = new RZ_Dynamo_Type_Declaration(*this);
 type_declaration_->set_cmd(cmd);
}

void RZ_Dynamo_Form::init_expression()
{
 expression_ = new RZ_Dynamo_Expression(*this);
}

void RZ_Dynamo_Form::init_assignment_expression(QString tok)
{
 //chief_ = tok;
 init_expression();
 expression_->set_assignment_token(tok);
}

void RZ_Dynamo_Form::init_formula_expression(QString tok)
{
 //chief_ = tok;
 init_expression();
 expression_->set_assignment_token(tok);
}

void RZ_Dynamo_Form::write(QTextStream& qts)
{
 check_init_annotation_flags();
 CAON_PTR_DEBUG(RZ_Dynamo_Form_Annotation ,annotation_)
 if(type_declaration_)
 {
  CAON_PTR_DEBUG(RZ_Dynamo_Type_Declaration ,type_declaration_)
  type_declaration_->write(qts);
 }
 else if(expression_)
 {
  expression_->write(qts);
 }
 else if(!raw_text_.isEmpty())
 {
  qts << raw_text_;
 }
 else
 {
  write_unmediated(qts);
 }
}

void RZ_Dynamo_Form::add_expression(caon_ptr<RZ_Dynamo_Form> form)
{
 inner_elements_.push_back({form, MS_Token::Null()});
}

void RZ_Dynamo_Form::add_nested_block(caon_ptr<RZ_Dynamo_Block> block)
{
 if(!first_nested_block_)
 {
  first_nested_block_ = block;
 }
 caon_ptr<RZ_Dynamo_Form> form = new RZ_Dynamo_Form(block);
 inner_elements_.push_back({form, MS_Token::Null()});
}

void RZ_Dynamo_Form::mark_as_fn_no_block()
{
 check_init_annotation();
 annotation_->flags.is_fn_no_block = true;
 CAON_PTR_DEBUG(RZ_Dynamo_Form_Annotation ,annotation_)
}

void RZ_Dynamo_Form::mark_as_assignment_expression()
{
 check_init_annotation();
 annotation_->flags.is_nested_as_assignment = true;
 CAON_PTR_DEBUG(RZ_Dynamo_Form_Annotation ,annotation_)
}

// obsolete?
//void RZ_Dynamo_Form::inner_mark_as_assignment_expression()
//{
// if(expression_)
// {
//  expression_->mark_form_as_assignment_expression();
// }
//}

void RZ_Dynamo_Form::check_init_annotation()
{
 if(!annotation_)
 {
  annotation_ = new RZ_Dynamo_Form_Annotation();
 }
}

void RZ_Dynamo_Form::check_init_annotation(QString fn)
{
 typedef std::function<void(RZ_Dynamo_Form*)> fn_type;
 static QMap<QString, fn_type> static_map {{
  {"kb::if-without-elsif", [](RZ_Dynamo_Form* _this)
   {
    _this->check_init_annotation();
    _this->annotation_->flags.is_general_if = true;
    _this->annotation_->flags.is_if = true;
   }
  },
  {"kb::if-with-else", [](RZ_Dynamo_Form* _this)
   {
    _this->check_init_annotation();
    _this->annotation_->flags.is_general_if = true;
    _this->annotation_->flags.is_if_with_else = true;
   }
  },
  {"kb::if-with-elsif", [](RZ_Dynamo_Form* _this)
   {
    _this->check_init_annotation();
    _this->annotation_->flags.is_general_if = true;
    _this->annotation_->flags.is_if_with_elsif = true;
   }
  },
 }};
 if(static_map.contains(fn))
 {
  static_map[fn](this);
 }
}

bool RZ_Dynamo_Form::implict_end_form_before_nested_written()
{
 if(annotation_)
 {
  return annotation_->flags.implict_end_form_before_nested_written;
 }
 return false;
}

void RZ_Dynamo_Form::check_init_annotation_flags()
{
 if(annotation_)
 {
  if(!annotation_->flags.checked)
  {
   annotation_->flags.checked = true;
   if(annotation_->flags.is_general_if)
   {
    annotation_->flags.end_form_before_nested = true;
    annotation_->flags.surround_nested_secondary = true;
    annotation_->flags.write_pull_nested_form_group = true;
    annotation_->flags.write_push_nested_form_group = true;
    annotation_->flags.skip_write_command_package = true;
   }
  }
 }
}

void RZ_Dynamo_Form::write_statement_entry(QTextStream& qts)
{
 qts << "\n;statement_\n";
  //?qts << "\n(kb::st_)\n";
 qts << "\n( ; from write_statement_entry\n";
}

void RZ_Dynamo_Form::write_statement_leave(QTextStream& qts)
{
 if(ANNOTATION_FLAG(skip_write_command_package))
 {

 }
 else
 {
  if(!ANNOTATION_FLAG(statement_form_closed_before_nested))
  {
   qts << "\n);_statement\n";
  }
  qts << "\n(kb::write-promote-expression)";
  qts << "\n(kb::write-cmd-eval)";
  qts << "\n(kb::write-statement-clear)";
 }
}


void RZ_Dynamo_Form::check_write_first_nested_is_assignment_leave(QTextStream& qts)
{
 CAON_PTR_DEBUG(RZ_Dynamo_Form_Annotation ,annotation_)
 if(ANNOTATION_FLAG(first_nested_is_assignment))
 {
  if(!annotation_->flags.child_implict_end_form_before_nested_written)
  {
   qts << "\n ) ; end nested assignment expression ... \n ";
  }
 }
}


void RZ_Dynamo_Form::write_checked_unmediated(QTextStream& qts)
{
 qts << "( ; write_unmediated_ \n";
 write_unmediated(qts);
 if(ANNOTATION_FLAG(has_prin1_quoted_form))
 {
  if(annotation_->flags.is_fn_no_block)
  {
   qts << ") ; _write_unmediated (with prin1; no block) \n";
  }
  else
  {
   qts << " ; _write_unmediated (with prin1) \n";
  }
 }
 else
 {
  qts << ") ; _write_unmediated \n";
 }
}

void RZ_Dynamo_Form::write_unmediated(QTextStream& qts)
{
 check_init_annotation_flags();
 QString icd = QString(implicit_added_depth_, '(');

 qts << icd;

 if(!ANNOTATION_FLAG(has_instruction_token))
 {
  if(ANNOTATION_FLAG(infer_write_s0_statement))
  {
   qts << "kb::write-s0-expression ";

   MS_Token askt = MS_Token {MS_Token_Kinds::Assignment_Kind, "none"};
   qts << askt.encode();
   qts << ' ';

  }
  else if(ANNOTATION_FLAG(unsurrounded_nested))
  {
   MS_Token mst {MS_Token_Kinds::Paren_Entry, QString::number(nesting_level_)};
   QString mste = mst.encode();
   qts << "\n " << mste << ' ';
  }
  else if(ANNOTATION_FLAG(first_nested_is_assignment))
  {
   qts << " ; for assignment ... \n ";
  }
  else if(ANNOTATION_FLAG(is_nested_as_assignment))
  {
   qts << " ; nested for assignment ... \n ";
  }
  else if(plene_block_)
  {
   qts << "kb::write-plene-block ";
  }
  else
  {
   //?MS_Token lisp_call_mode_token {MS_Token_Kinds::Note_Symbol, ":lc-n"};
   MS_Token lisp_call_mode_token {MS_Token_Kinds::Note_Symbol, ":lc-f"};
   qts << "kb::prepare-expression " << lisp_call_mode_token.encode();
  }
 }

 if(plene_block_)
 {
  qts << "\n;block_\n";

  if(caon_ptr<RE_Block_Entry> rbe = plene_block_->get_block_entry())
  {
   if(rbe->flags.if_block)
   {
    //?
    //?qts << "(progn \n";
   }
  }
  else
  {
   // so get info plene_block_ mode ...
   qts << "\n;; fn body"
     "\n(kb::write-enter-plebod)";

//   switch(plene_block_->block_sequence_mode())
//   {
//   case RZ_Dynamo_Block::Block_Sequence_Modes::Ghost:
//    qts << "(progn\n";
//    break;
//   default:
//    qts << "(lambda (ks)\n";
//    break;
//   }

  }

  qts << "\n(kb::write-enter-plene-block)\n";
  plene_block_->write(qts);
  qts << "\n(kb::write-leave-plene-block)\n";
 }
 else
 {
  //?qts << '(';
 }

 QList<caon_ptr<RZ_Dynamo_Form>> nested_forms;
 int nf_count = 0;
 int count = 0;

 for(QPair<caon_ptr<RZ_Dynamo_Form>, MS_Token> element : inner_elements_)
 {
  if(element.first)
  {
   caon_ptr<RZ_Dynamo_Form> ef = element.first;
   CAON_PTR_DEBUG(RZ_Dynamo_Form ,ef)

   QString note = element.second.raw_text;

   if( (count == 0) && (assignment_token_.has_text() ) )
   {
    if(ANNOTATION_FLAG(first_nested_is_assignment))
    {
     // // should I set this here or elsewhere?
     element.first->mark_as_assignment_expression();
    }

    element.first->write(qts);
   }
   else if(note.isEmpty())
   {
    // //  these are deferred to after ...
    nested_forms.push_back(ef);
    ++nf_count;

    MS_Token mst {MS_Token_Kinds::Nested_Forward,
      QString("%1-%2").arg(nesting_level_).arg(nf_count)};
    qts << ' ' << mst.encode() << ' ';
   }
   else
   {
    //?qts << ' ' << note << ' ';
    qts << ' ' << element.second.encode() << ' ';
    element.first->write(qts);
    qts << ' ';
   }
  }
  else
  {
   QString rt = element.second.raw_text;
   MS_Token_Kinds mstk = element.second.kind;

   QString str = element.second.encode();

   qts << ' ' << str << ' ';


//   switch(mstk)
//   {
//   case MS_Token_Kinds::Literal:
//   default:
//    qts << ' ' << rt << ' ';
//   }

   //?qts << element.second << " ";
  }
  ++count;
 }

 if(chief_.startsWith('.'))
 {
  qts << "\n;;instruction\n)\n";
 }

 if(plene_block_)
 {
  qts << "\n;_plene_block";
    //? qts << "\n(kb::_fb)";
  //?qts << ")\n";
 }
 else
 {
  //?qts << ')';
 }

 // ?? always end ...?

 // // //? temp ...
 if(!nested_forms.isEmpty())
 {
  check_init_annotation();
  annotation_->flags.surround_nested = true;
 }

 //?qts << "\n) ; nested forms ...\n";
 if(ANNOTATION_FLAG(end_form_before_nested))
 {
  qts << "\n) ;end form before nested...\n";
 }
 //?
 else if(nested_forms.isEmpty())
 {
  qts << "\n ; nothing nested...\n";
 }
 else if(!ANNOTATION_FLAG(skip_implicit_end_form_before_nested))
 {
  annotation_->flags.statement_form_closed_before_nested = true;
  annotation_->flags.implict_end_form_before_nested_written = true;

  CAON_PTR_DEBUG(RZ_Dynamo_Form_Annotation ,annotation_)

  qts << "\n) ;implicit end form before nested...\n";

   //?qts << "\n ; continuing into nested...\n";
 }

 if(ANNOTATION_FLAG(write_push_nested_form_group))
 {
  qts << "\n(kb::push-nested-form-group)\n";
 }

 if(ANNOTATION_FLAG(unsurrounded_nested))
 {
  MS_Token mst {MS_Token_Kinds::Paren_Leave, QString::number(nesting_level_)};
  qts << "\n " << mst.encode() << ' ';
 }

 int nfb_count = 0;

 for(caon_ptr<RZ_Dynamo_Form> nf: nested_forms)
 {
  CAON_PTR_DEBUG(RZ_Dynamo_Form_Annotation ,annotation_)
  ++nfb_count;

  if(ANNOTATION_FLAG(implict_end_form_before_nested_written))
  {
//?   if(annotation_->flags.needs_mark_parent_implict_end_form_before_nested_written)
//?   {
   nf->mark_parent_implict_end_form_before_nested_written();
   if(parent_)
   {
    parent_->mark_child_implict_end_form_before_nested_written();
   }
//?   }
  }

  if(ANNOTATION_FLAG(surround_nested_secondary))
  {
   MS_Token mst {MS_Token_Kinds::Nested_Back,
     QString("%1-%2").arg(nesting_level_).arg(nfb_count)   //QString::number(nfb_count)
                };
   qts << "\n(kb::enter-secondary-nested-form " << mst.encode() << ")\n";

   //?
   //? qts << "\n(kb::nested-form-body \n(";
   qts << "( ; secondary-nested-form-body_ \n";
  }
  else if(ANNOTATION_FLAG(surround_nested))
  {
   MS_Token mst {MS_Token_Kinds::Nested_Back,
     QString("%1-%2").arg(nesting_level_).arg(nfb_count)   //? QString::number(nfb_count)
                };
   qts << "\n(kb::enter-nested-form " << mst.encode() << ")\n";

   //?
   //? qts << "\n(kb::nested-form-body \n(";
   qts << "( ; nested-form-body_ \n";
  }
  else
  {
   nf->mark_unsurrounded_nested();
  }
  nf->set_nesting_level(nesting_level_ + 1);
  qts << ' ';
  nf->write(qts);
  qts << ' ';
  if(ANNOTATION_FLAG(surround_nested_secondary))
  {
   //?
   //?qts << "\n) \n); _kb::nested-form-body\n";

   qts << "\n) ; _nested-form-body \n";


   qts << "\n(kb::leave-secondary-nested-form)\n";
  }
  else if(ANNOTATION_FLAG(surround_nested))
  {
   //?
   //?qts << "\n) \n); _kb::nested-form-body\n";

   CAON_PTR_DEBUG(RZ_Dynamo_Form_Annotation ,annotation_)

   if(annotation_->flags.parent_implict_end_form_before_nested_written)
   {
    if(annotation_->flags.skip_close_paren_on_parent_written)
    {
     qts << "\n ; _nested-form-body (lisp form already closed; parent) \n";
    }
    else if(nf->implict_end_form_before_nested_written())
    {
     qts << "\n ; _nested-form-body (nested form already closed; parent closed) \n";
    }
    else
    {
     qts << "\n) ; _nested-form-body (despite parent closed) \n";
    }
   }
   else
   {
    // // make sure this is always kosher
    if(nf->implict_end_form_before_nested_written())
    {
     qts << "\n ; _nested-form-body (lisp form already closed) \n";
    }
    else
    {
     qts << "\n) ; _nested-form-body \n";
    }
   }


   qts << "\n(kb::leave-nested-form)\n";
  }
 }

 if(ANNOTATION_FLAG(write_pull_nested_form_group))
 {
  qts << "\n(kb::pull-nested-form-group)\n";
 }

 // qts << follow_;
 //if(caon_ptr<RE_Node> start_node = )
}



#ifdef HIDE
   char c = element.second[0].toLatin1();
   QString str = element.second.mid(1);
   switch(c)
   {
   case '.':
    qts << "\n(" << str;;
    break;

   case '@':
    qts << ' ' << str << ' ';
    break;

   case '&':
    qts << "\n(kb::fc \"" << str << "\")";
    break;

   case '$':
    qts << "\n(kb::lc \"" << str << "\")";
    break;

   case '#':
    qts << "\n(kb::ll \"" << str << "\")";
    break;

   case '=':
    qts << "\n;;assignment: " << str;
    break;

   }
#endif


void RZ_Dynamo_Form::mark_unsurrounded_nested()
{
 check_init_annotation();
 annotation_->flags.unsurrounded_nested = true;
}

void RZ_Dynamo_Form::mark_parent_implict_end_form_before_nested_written()
{
 check_init_annotation();
 annotation_->flags.parent_implict_end_form_before_nested_written = true;
}

void RZ_Dynamo_Form::mark_child_implict_end_form_before_nested_written()
{
 check_init_annotation();
 annotation_->flags.child_implict_end_form_before_nested_written = true;
}

void RZ_Dynamo_Form::set_assignment_token(MS_Token mt)
{
 // always?
 check_init_annotation();
 annotation_->flags.first_nested_is_assignment = true;

 CAON_PTR_DEBUG(RZ_Dynamo_Form_Annotation ,annotation_)

 assignment_token_ = mt;
 //inner_elements_.push_back({nullptr, mt});
}

void RZ_Dynamo_Form::add_assignment_initialization_token(MS_Token mt)
{
 inner_elements_.push_back({nullptr, mt});
}

void RZ_Dynamo_Form::add_literal_token(MS_Token mt)
{
 inner_elements_.push_back({nullptr, mt});
}

void RZ_Dynamo_Form::add_insert_token(MS_Token mt)
{
 inner_elements_.push_back({nullptr, mt});
}

void RZ_Dynamo_Form::add_carrier_token(MS_Token mt)
{
 inner_elements_.push_back({nullptr, mt});
}

void RZ_Dynamo_Form::add_kauvir_token(MS_Token mt)
{
 inner_elements_.push_back({nullptr, mt});
}

void RZ_Dynamo_Form::init_inferred_s0_statement()
{
 check_init_annotation();
 annotation_->flags.infer_write_s0_statement = true;
}

void RZ_Dynamo_Form::add_fn_token(MS_Token mt)
{
 inner_elements_.push_back({nullptr, mt});
}

void RZ_Dynamo_Form::add_bridge_token(MS_Token mt)
{
 inner_elements_.push_back({nullptr, mt});
}

void RZ_Dynamo_Form::add_instruction_token(MS_Token mt)
{
 check_init_annotation();
 annotation_->flags.has_instruction_token = true;
 inner_elements_.push_back({nullptr, mt});
}

void RZ_Dynamo_Form::add_argument_token(MS_Token mt)
{
 inner_elements_.push_back({nullptr, mt});
}


#ifdef HIDE
void RZ_Dynamo_Form::set_assignment_token(QString rt)
{
 rt.prepend('=');
 inner_elements_.push_back({nullptr, rt});
}

void RZ_Dynamo_Form::add_instruction_token(QString tok)
{
 chief_ = tok.prepend('.');
 add_string_token(chief_);
}

void RZ_Dynamo_Form::add_assignment_initialization_token(QString tok)
{
 // // none that this mimics add_fn_token ...
 chief_ = tok.prepend('&');
 add_string_token(chief_);
 //expression_->set_assignment_target(tok);
}


void RZ_Dynamo_Form::add_argument_token(QString tok)
{
 if(chief_.startsWith('.'))
 {
  add_kauvir_token(tok);
 }
 else
 {
  add_carrier_token(tok);
 }
}

//void RZ_Dynamo_Form::add_argument_token(QString tok)
//{
// inner_elements_.push_back({nullptr, tok});
//}


void RZ_Dynamo_Form::add_literal_token(QString tok)
{
 if(chief_.startsWith('.'))
 {
  add_kauvir_token(tok);
 }
 else
 {
  add_string_token(tok.prepend('#'));
 }
}

void RZ_Dynamo_Form::add_carrier_token(QString tok)
{
 add_string_token(tok.prepend('$'));
}

void RZ_Dynamo_Form::add_bridge_token(QString tok)
{
 add_string_token(tok.prepend('%'));
}

void RZ_Dynamo_Form::add_fn_token(QString tok)
{
 chief_ = tok.prepend('&');
 add_string_token(chief_);
}

void RZ_Dynamo_Form::add_kauvir_token(QString tok)
{
 if(tok.startsWith('('))
 {
  add_string_token(tok.prepend('@'));
 }
 else if(tok.startsWith("$\\"))
 {
  tok.prepend("@\"");
  tok.append('\"');
  add_string_token(tok);
 }
 else if(!tok.startsWith(':'))
 {
  tok.prepend("@'|");
  tok.append('|');
  add_string_token(tok);
 }
 else
 {
  add_string_token(tok.prepend('@'));
 }
}

void RZ_Dynamo_Form::add_string_token(QString tok)
{
 inner_elements_.push_back({nullptr, tok});
}

#endif

