
#ifndef SEMANTIC_READTABLE_EMULATOR__H
#define SEMANTIC_READTABLE_EMULATOR__H


#include "relae-graph/relae-node-ptr.h"


template<typename DOMINION_Type,
   typename GALAXY_Type = typename DOMINION_Type::Galaxy_type>
class Semantic_Readtable_Emulator
{

public:

 typedef typename GALAXY_Type::SRE_Token_type sre_token_type;
 typedef typename GALAXY_Type::SRE_State_type sre_state_type;
 typedef typename GALAXY_Type::Source_Element_type source_element_type;

 virtual void init() = 0;
 virtual void begin() = 0;
 virtual void advance() = 0;
 virtual void load_sre_token(sre_token_type& sre_token, caon_ptr<source_element_type>& source_element) = 0;
 virtual typename sre_state_type::Read_Table_State read_table_state() = 0;
 virtual typename sre_state_type::Post_Advance_State post_advance_state() = 0;
};


#endif
