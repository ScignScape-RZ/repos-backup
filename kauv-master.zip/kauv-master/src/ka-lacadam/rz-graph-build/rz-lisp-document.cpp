
#include "rz-lisp-document.h"

//#include "grammar/rz-lisp-grammar.h"
//#include "grammar/rz-lisp-parser.h"

//#include "grammar/rz-lisp-graph-build.h"

#include "rz-graph-token/token/rz-lisp-token.h"

//#include "query/rz-lisp-query.h"

#include "rzns.h"
USING_RZNS(GBuild)


RZ_Lisp_Document::RZ_Lisp_Document(RE_Document& re_document)
 : re_document_(re_document)
{

}


//RZ_Lisp_Document::RZ_Lisp_Document(QString path)
// : path_(path)
//  ,graph_(nullptr)
//  ,parser_(nullptr)
//  ,graph_build_(nullptr)
//  ,grammar_(nullptr)
// ,number_of_lines_(0)
//{

//}


//RZ_Lisp_Document::RZ_Lisp_Document()
// : graph_(nullptr)
//  ,parser_(nullptr)
//  ,graph_build_(nullptr)
//  ,grammar_(nullptr)
//  ,number_of_lines_(0)
//{

//}


//void RZ_Lisp_Document::open(QString path)
//{
// path_ = path;
// open();
//}


//void RZ_Lisp_Document::open()
//{
// if(path_.isEmpty())
//  return;
// if(!raw_text_.isEmpty())
//  return;
// QFile infile(path_);
// if (!infile.open(QIODevice::ReadOnly | QIODevice::Text))
//  return;
// QTextStream in(&infile);
// raw_text_ = in.readAll();
// infile.close();
//}



//void RZ_Lisp_Document::set_grammar()
//{
// set_grammar(new RZ_Lisp_Grammar());
//}

//void RZ_Lisp_Document::add_rz_comment(QString comment, int line)
//{
// comments_by_line_[line] = comment;
//}


//void RZ_Lisp_Document::parse(int start_position)
//{
// graph_ = new RZ_Lisp_Graph;
// graph_->set_document(this);
// parser_ = new RZ_Lisp_Parser(graph_);
// parser_->set_raw_text(raw_text_);
//// graph_build.reset_graph();

// graph_build_ = new RZ_Lisp_Graph_Build(this, *graph_, *parser_);
// graph_build_->init();

// grammar_->init(*parser_, *graph_, *graph_build_);

//// grammar_->activate_context(print);

// grammar_->compile(*graph_, *parser_, raw_text_, start_position);
//}
