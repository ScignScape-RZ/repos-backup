
//#include "token/rz-script-token.h"


#include "token/rz-lisp-token.h"

#include "rz-string.h"

USING_RZNS(GBuild)

RZ_String::operator tString() const
{
 return to_string();
}

tString RZ_String::to_string() const
{
 if(flags.has_raw_string)
  return raw_string_;
 return token_->string_value();
}

bool RZ_String::operator>(const RZ_String& rhs) const
{
 return to_string() > rhs.to_string();
}

bool RZ_String::operator<(const RZ_String& rhs) const
{
 return to_string() < rhs.to_string();
}
