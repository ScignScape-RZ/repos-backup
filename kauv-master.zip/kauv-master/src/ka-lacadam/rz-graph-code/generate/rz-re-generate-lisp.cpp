#include "rz-re-generate-lisp.h"

#include "rz-graph-visit/rz-lisp-graph-visitor.h"
#include "rz-graph-visit/rz-lisp-graph-visitor-clasp.h"
#include "rz-graph-visit/rz-lisp-graph-visitor-run-state.h"
#include "rz-graph-visit/rz-lisp-graph-visitor-run-plugin.h"

#include "rz-code-generators/rz-function-def-info.h"

#include "rz-graph-core/kernel/graph/rz-re-graph.h"

#include "rz-graph-run/token/rz-graph-run-token.h"

#include "rz-graph-embed/rz-graph-cpp/rz-graph-cpp-token.h"
#include "rz-graph-embed/rz-graph-clasp/rz-graph-clasp-token.h"


//?
//#include "rz-clasp-project/rz-clasp-project.h"
//#include "rz-clasp-project/rz-clasp-cpp-project.h"
//#include "rz-clasp-project/rz-clasp-embed-normal.h"
//#include "rz-clasp-project/rz-clasp-cpp-embed-normal.h"
//#include "rz-clasp-project/embed/rz-clasp-embed-branch.noop.h"
//#include "rz-clasp-project/code/rz-clasp-code-block.h"
//#include "rz-clasp-code/rz-clasp-code-generator.h"
//#include "rz-clasp-code/rz-clasp-code-block-kinds.h"
//#include "rz-clasp-code/rz-clasp-code-special-conditions.h"
//#include "rz-clasp-code/rz-clasp-code-lexmap.h"
//#include "rz-clasp-code/elements/rz-clasp-source-element.h"
//#include "rz-clasp-code/elements/rz-clasp-source-fundef.h"





//#include "rz-clasp-project/embed/rz-clasp-embed-branch.class.h"
//#include "rz-clasp-project/embed/rz-clasp-embed-branch.self-closing-statement.h"
//#include "rz-clasp-project/embed/rz-clasp-embed-branch.access-modifier.h"


#include "rz-graph-sre/rz-sre-token.h"


#include "rz-graph-embed/rz-graph-clasp/rz-graph-clasp-token.h"

#include "rz-graph-valuer/scope/rz-lisp-graph-block-info.h"

#include "kernel/graph/rz-re-node.h"
#include "rz-graph-token/token/rz-lisp-token.h"

#include "rz-graph-core/code/rz-re-block-entry.h"

#include "rz-graph-valuer/valuer/rz-lisp-graph-valuer.h"

#include "rz-graph-valuer/valuer/rz-opaque-call.h"
#include "rz-graph-valuer/vector/rz-lisp-vector.h"


#include "rz-graph-core/token/rz-re-token.h"

USING_RZNS(RECore)
USING_RZNS(GBuild)


RE_Generate_Lisp::RE_Generate_Lisp(RZ_Lisp_Graph_Visitor& visitor)
 : sre_(visitor),
     //?ccg_(*visitor.RZ_Lisp_code_generator()),
   project_(nullptr),
     //?clasp_cpp_project_(nullptr),
   current_block_(nullptr), current_parent_block_(nullptr),
   current_embed_branch_(nullptr), current_labeled_call_entry_object_(nullptr),
   current_block_info_(nullptr), pending_raw_lisp_node_(nullptr),
   block_count_(0)
   //, function_def_syntax_(RZ_Function_Def_Syntax(",", ""))
{
}

void RE_Generate_Lisp::init_function_def_syntax()
{
 function_def_syntax_.flags.type_before_symbol = true;
 function_def_syntax_.set_argument_default_type("auto");
}

#ifdef HIDE
void RE_Generate_Lisp::init_project(RZ_File_List_Type& extra_files)
{
 project_ = new RZ_Lisp_Project(extra_files);
 //?
 visitor().take_project(project_);
}
#endif // HIDE

void RE_Generate_Lisp::init_clasp_cpp_project()
{
#ifdef HIDE
 clasp_cpp_project_ = new RZ_Lisp_Cpp_Project();
 ccg_.init_cpp_code_generation();
#endif // HIDE
}


void RE_Generate_Lisp::write(QTextStream& qts)
{
 sre_.init();

 //ccg_.write(qts);

#ifdef HIDE
 if(clasp_cpp_project_)
 {
  current_embed_branch_ = new RZ_Lisp_Cpp_Embed_Normal(qts, nullptr, ccg_);
   //? ccg.init_cpp_code_generation();
 }
 else
  current_embed_branch_ = new RZ_Lisp_Embed_Normal(qts, nullptr, ccg_);
#endif // HIDE


 check_advance(qts);

//? run_state().flags.cpp_mode = true;
//? run_state().flags.cpp_mode = false;

}


void RE_Generate_Lisp::prepare_expression_entry(QTextStream& qts)
{

}

void RE_Generate_Lisp::prepare_statement_entry(QTextStream& qts)
{

}

void RE_Generate_Lisp::write_file_entry(QTextStream& qts)
{
// qts << "\n#include \"project-global-rz-include.h\"\n\n\n";
//?
// qts << "\n\rXXX#include <Clasp/client.h> //Misc client side stuff";
// qts << "\n\r#include <Clasp/clientlib.h> //Complete DOM/HTML5 interface";
// qts << "\n\r#include <Clasp/webgl.h> //WebGL interface\n\n\n";
}


#ifdef HIDE
Basic_Token_Kinds RE_Generate_Lisp::get_current_token
 (RZ_SRE_Token& sre_token, caon_ptr<RZ_Lisp_Source_Element>& current_source_element)
{
 sre_.load_sre_token(sre_token, current_source_element);
 //visitor().get_current_token(rzt);
 Basic_Token_Kinds kind = sre_token.run_token()->kind();
 return kind;
}
#endif // HIDE


void RE_Generate_Lisp::write_function_def_redirect(QTextStream& qts,
 QString function_name, RZ_Function_Def_Info& fdi)
{
 QString return_channel = fdi.return_channel_string_clasp();
 QString lambda_channel = fdi.lambda_channel_string(function_def_syntax_);

 QString context_channel = fdi.context_channel_string();

 qts << return_channel << ' ' <<  context_channel << ' ' << function_name
  << '(' << lambda_channel << ')';
}


void RE_Generate_Lisp::check_raw_lisp(QTextStream& qts, caon_ptr<RE_Node> node)
{
 CAON_PTR_DEBUG(RE_Node ,node)
 pending_raw_lisp_node_ = visitor().check_raw_lisp(node);
 if(pending_raw_lisp_node_)
 {
  CAON_PTR_DEBUG(RE_Node ,pending_raw_lisp_node_)
  CAON_DEBUG_NOOP
 }
}

#ifdef HIDE
void RE_Generate_Lisp::check_pending_raw_lisp(QTextStream& qts, RZ_Lisp_Code_Lisp_Paste_Modes mode)
{
 if(pending_raw_lisp_node_)
 {
  CAON_PTR_DEBUG(RE_Node ,pending_raw_lisp_node_)
  if(caon_ptr<RE_Token> re_token = pending_raw_lisp_node_->re_token())
  {
   QString lisp = re_token->raw_text();
   current_embed_branch_->ccg_add_raw_lisp(lisp, mode);
  }
  pending_raw_lisp_node_ = nullptr;
 }
}
#endif // HIDE


void RE_Generate_Lisp::check_root_raw_lisp(QTextStream& qts, caon_ptr<RE_Node> node)
{
 CAON_PTR_DEBUG(RE_Node ,node)
 if(caon_ptr<RE_Node> raw_lisp_node =  visitor().check_raw_lisp(node))
 {
  if(caon_ptr<RE_Token> re_token = raw_lisp_node->re_token())
  {
   QString lisp = re_token->raw_text();
   //?current_embed_branch_->ccg_add_raw_lisp(lisp, RZ_Lisp_Code_Lisp_Paste_Modes::Root);
  }
 }
}


void RE_Generate_Lisp::check_raw_lisp(QTextStream& qts)
{
 caon_ptr<RE_Node> cn = visitor_clasp().current_node();
 if(cn)
 {
  CAON_PTR_DEBUG(RE_Node ,cn)
  check_raw_lisp(qts, cn);
 }
}


void RE_Generate_Lisp::check_advance(QTextStream& qts)
{
 RZ_Read_Table_Post_Advance_State padv_state;
 RZ_Read_Table_State rts;// = read_table_state();

 RZ_Graph_Run_Token rzt;
 caon_ptr<RE_Node> current_node = nullptr;
 RZ_SRE_Token sre_token(&rzt, current_node);

 caon_ptr<RE_Node> type_indicator_node = nullptr;

 //?caon_ptr<RZ_Lisp_Source_Element> current_source_element = nullptr;

 Basic_Token_Kinds kind;


read_table_state_loop:
 rts = sre_.read_table_state();


#ifdef HIDE
 switch(rts)
 {
 case RZ_Read_Table_State::Inactive:
  return;

 case RZ_Read_Table_State::Graph_End:
  return;

 case RZ_Read_Table_State::Root:

  check_raw_lisp(qts, visitor_clasp().current_node());

  sre_.advance();

  //check_root_raw_lisp(qts, current_node);

  //rts = read_table_state();
  break;

 case RZ_Read_Table_State::File_Block_Pre_Entry:
  {
   // //?! current_embed_branch_->ccg_add_file_entry();

  //?ccg_.add_file_entry();
   //write_file_entry(qts);

//? current_block_ = new RZ_Lisp_Code_Block(nullptr);
//? current_block_info_ = current_block_->block_info();
//?
   sre_.advance();
   //rts = read_table_state();
//?
   break;
  }
  // fallthrough? ...

 case RZ_Read_Table_State::Block_Pre_Entry:
  {
   //?! RZ_Lisp_Code_Block_Kinds block_kind = RZ_Lisp_Code_Block_Kinds::N_A;
   //?!  caon_ptr<RZ_Lisp_Code_Lexmap> rlx = nullptr;

//     RZ_Lisp_Code_Block_Kinds::N_A;
//     bool current_element_is_source_file = ccg_.current_element_is_source_file();
//     if(current_element_is_source_file)
//     {
//      block_kind = RZ_Lisp_Code_Block_Kinds::File_Block;
//     }
   if(caon_ptr<RE_Block_Entry> rbe = visitor_clasp().current_node_as_block_entry())
   {
    CAON_PTR_DEBUG(RE_Block_Entry ,rbe)
    //?! rlx = check_block_lexicals(qts, rbe);
    if(rbe->flags.if_block)
    {
       //?! block_kind = RZ_Lisp_Code_Block_Kinds::If_Block;
     //?    qts << " then \n";
     visitor().valuer()->check_assignments();
    }
    else if(rbe->flags.else_block)
    {
     //?!  block_kind = RZ_Lisp_Code_Block_Kinds::Else_Block;
     //?    qts << " else \n";
     visitor().valuer()->check_assignments();
    }
    else if(rbe->flags.elsif_block)
    {
     //?!  block_kind = RZ_Lisp_Code_Block_Kinds::Elsif_Block;
     //?    qts << " else \n";
     visitor().valuer()->check_assignments();
    }
    else if(rbe->flags.scan_block)
    {
     //?!  block_kind = RZ_Lisp_Code_Block_Kinds::Scan_Block;
     //?    qts << " else \n";
     visitor().valuer()->check_assignments();
    }
    else if(rbe->flags.file_default)
    {
      //?!  block_kind = RZ_Lisp_Code_Block_Kinds::File_Block;
     //?
     visitor().valuer()->check_assignments();
    }
    else if(rbe->flags.function_definition)
    {
//     if(rbe->flags.do_block_entry)
//     {
//      block_kind = RZ_Lisp_Code_Block_Kinds::Do_Block;
//     }
//     else
//     {
     //?!  block_kind = RZ_Lisp_Code_Block_Kinds::Fundef_Block;
//     }
    }
    else
    {
     //?
     //     rbe->flags.file_block = true;
    }

    if(current_block_)
    {
#ifdef HIDE
     if(caon_ptr<RZ_Lisp_Graph_Block_Info> rbi = current_block_->block_info())
     {
      CAON_PTR_DEBUG(RZ_Lisp_Graph_Block_Info ,rbi)
        CAON_PTR_DEBUG(RZ_Lisp_Code_Block ,current_block_)
       //  this should really be in valuer ...
        rbi->set_child_block_info(current_block_info_);
     }
#endif // HIDE
    }

//    if(current_element_is_source_file)
//    {
//     // //  Should rbe be modified here
//     rbe->flags.file_block = true;
//    }

    caon_ptr<RE_Node> cn = visitor_clasp().current_node();
    CAON_PTR_DEBUG(RE_Node ,cn)

  #ifdef HIDE
    if(current_block_)
    {
     caon_ptr<RE_Node> ben = current_block_->block_entry_node();
     CAON_PTR_DEBUG(RE_Node ,ben)
     CAON_DEBUG_NOOP
    }

    //?current_block_ = new RZ_Lisp_Code_Block(current_block_, rbe);
    current_block_ = new RZ_Lisp_Code_Block(current_block_, cn);
    current_block_->set_block_info(current_block_info_);
    CAON_PTR_DEBUG(RZ_Lisp_Graph_Block_Info ,current_block_info_)
    CAON_PTR_DEBUG(RZ_Lisp_Code_Block ,current_block_)
    CAON_DEBUG_NOOP
     //? current_embed_branch_->write_line_standalone(" --{.");
  #endif // HIDE
   }
#ifdef HIDE
   if(block_kind == RZ_Lisp_Code_Block_Kinds::File_Block)
   {
    //?current_embed_branch_->ccg_block_pre_entry(block_kind);

    current_embed_branch_->ccg_set_current_code_block(current_block_, block_kind);

    //?
    //current_embed_branch_->ccg_check_nested_block_pre_entry(block_kind);
   }
   else
   {
    current_embed_branch_->ccg_check_nested_block_pre_entry(current_block_, block_kind);

   }
   current_embed_branch_->ccg_register_block_objects(rlx);
#endif // HIDE


   //? ccg_.nested_block_pre_entry(block_kind);
   sre_.advance();
   //rts = read_table_state();
   //?goto rz_Bypass_Check_Kind;
   break;
  }

 case RZ_Read_Table_State::Block_Entry:
  {
   check_noop_embed_branch(qts);
   sre_.advance();
  }
  break;

#ifdef HIDE
#endif // HIDE
 case RZ_Read_Table_State::Statement_Pre_Entry:
  {
   check_noop_embed_branch(qts);
   CAON_PTR_DEBUG(RZ_Lisp_Embed_Branch ,current_embed_branch_)
//?   QString label = visitor_clasp().call_entry_label();
   current_embed_branch_->ccg_prepare_statement_entry();
   sre_.advance();
  }
  break;


 case RZ_Read_Table_State::Block_Continue_Call_Pre_Entry:
  {
   CAON_PTR_DEBUG(RZ_Lisp_Embed_Branch ,current_embed_branch_)
   current_embed_branch_->ccg_prepare_expression_entry("");
   sre_.advance();
  }
  break;

 case RZ_Read_Table_State::Expression_Pre_Entry:
  {
   CAON_PTR_DEBUG(RZ_Lisp_Embed_Branch ,current_embed_branch_)
   QString prefix = visitor_clasp().current_call_entry_prefix();
   current_embed_branch_->ccg_prepare_expression_entry(prefix);
   sre_.advance();
  }
  break;

 case RZ_Read_Table_State::Expression_Final:
  {
   current_embed_branch_->ccg_prepare_expression_leave();
   //?ccg_.prepare_expression_leave();
   sre_.advance();
   break;
  }

 case RZ_Read_Table_State::Do_Map_Block_Leave:
  {
   current_embed_branch_->ccg_prepare_expression_leave();
   //?ccg_.prepare_expression_leave();
   sre_.advance();
   break;
  }

 case RZ_Read_Table_State::Do_Map_Block_Statement_Leave:
  {
   current_embed_branch_->ccg_end_statement();
    //?
    //  leave after do-map block...
    current_embed_branch_->ccg_prepare_statement_leave_after_block_map();
   sre_.advance();
   break;
  }

 case RZ_Read_Table_State::Nested_Block_Leave_Statement_Final:
  {
   current_embed_branch_->ccg_prepare_expression_leave();
   current_embed_branch_->ccg_end_statement();
   sre_.advance();
   break;
  }
 //? // fallthrough... ?
 case RZ_Read_Table_State::Statement_Final:
  {
   current_embed_branch_->ccg_prepare_expression_leave();
   current_embed_branch_->ccg_end_statement();

   //?current_embed_branch_->ccg_prepare_statement_leave();
   //?ccg_.prepare_statement_leave();
   //?ccg_.prepare_expression_leave();
   sre_.advance();


   check_raw_lisp(qts);
   check_pending_raw_lisp(qts, RZ_Lisp_Code_Lisp_Paste_Modes::Follow);

   break;
  }

//?
 case RZ_Read_Table_State::Expression_Rewind:
 case RZ_Read_Table_State::Rewind:


    //?check_raw_lisp(qts);
    //?check_pending_raw_lisp(qts, RZ_Lisp_Code_Lisp_Paste_Modes::Follow);

  //fallthrough...

// case RZ_Read_Table_State::Expression_Rewind:
 case RZ_Read_Table_State::Expression_End:

     //?case RZ_Read_Table_State::Expression_Leave:
 //?case RZ_Read_Table_State::Statement_Final:
   //? case RZ_Read_Table_State::Expression_Leave:
 case RZ_Read_Table_State::Statement_End:
 //?case RZ_Read_Table_State::Statement_Leave:
 case RZ_Read_Table_State::Block_End:
 case RZ_Read_Table_State::Block_Leave:
  {
//?
//     check_raw_lisp(qts);
//     check_pending_raw_lisp(qts, RZ_Lisp_Code_Lisp_Paste_Modes::Follow);

   sre_.advance();


//        check_raw_lisp(qts);
//        check_pending_raw_lisp(qts, RZ_Lisp_Code_Lisp_Paste_Modes::Immediate);

   break;
  }

  // case RZ_Read_Table_State::Expression_Rewind:
  // case RZ_Read_Table_State::Rewind:
 case RZ_Read_Table_State::Expression_Leave:
  {
   //?

   sre_.advance();

   caon_ptr<RE_Node> rn = visitor_clasp().rewind_node();
   if(rn)
   {
    check_raw_lisp(qts, rn);
    visitor_clasp().set_rewind_node(nullptr);
   }
   //?

   check_pending_raw_lisp(qts, RZ_Lisp_Code_Lisp_Paste_Modes::Immediate);

   break;
  }



 case RZ_Read_Table_State::Statement_Leave:
  {
   check_reset_current_embed_branch();
   //?
   sre_.advance();
   check_raw_lisp(qts);
   check_pending_raw_lisp(qts, RZ_Lisp_Code_Lisp_Paste_Modes::Follow);
   break;
  }

 case RZ_Read_Table_State::Do_Map_Block_Continue:
  {
   CAON_PTR_DEBUG(RZ_Lisp_Embed_Branch ,current_embed_branch_)

   current_embed_branch_->ccg_prepare_block_map_continue();


    //? current_embed_branch_->ccg_prepare_expression_entry("");
   sre_.advance();
   break;
  }

 case RZ_Read_Table_State::Nested_Block_Rewind_Pre_Continue:
  {
   CAON_PTR_DEBUG(RZ_Lisp_Embed_Branch ,current_embed_branch_)

  // CAON_PTR_DEBUG(RZ_Lisp_Source_Element ,current_source_element)

   current_embed_branch_->ccg_nested_block_rewind_prepare_continue();

   //?current_embed_branch_->ccg_nested_block_prepare_continue();
   //?current_embed_branch_->ccg_prepare_expression_entry("");
   sre_.advance();
   break;
  }


 case RZ_Read_Table_State::Block_Pre_Continue:
  {
   CAON_PTR_DEBUG(RZ_Lisp_Embed_Branch ,current_embed_branch_)
   //?current_embed_branch_->ccg_nested_block_prepare_continue();
   current_embed_branch_->ccg_prepare_expression_entry("");
   sre_.advance();
   break;
  }
// case RZ_Read_Table_State::Block_Continue:
//  {
//   sre_.advance();
//   break;
//  }


 case RZ_Read_Table_State::Nested_Block_Leave_No_Continue:
  {
   caon_ptr<RE_Node> cn = visitor_clasp().current_node();
   CAON_PTR_DEBUG(RE_Node ,cn)

   RZ_Lisp_Code_Block_Kinds block_kind;

   caon_ptr<RZ_Lisp_Source_Fundef> fundef = current_embed_branch_->ccg_nested_block_leave(block_kind);

   // //  In place of all this it may be better to use a
    //    statment_final state to leave the enclosing
    //    statement.  However, this appears to work
    //    because we assume that leaving the nested
    //    block means leaving the enclosing statement
    //    (which forbids nested blocks not at tail...)
   current_embed_branch_->ccg_unwind_expression_leave();
    //
   CAON_PTR_DEBUG(RZ_Lisp_Source_Fundef ,fundef)
   if(fundef && fundef->is_do_lambda())
   {

   }
   else if(block_kind == RZ_Lisp_Code_Block_Kinds::Generic_Block)
   {

   }
   else if(fundef)
   {
    // //  Fundef is always statement end...
    //?current_embed_branch_->ccg_end_statement();
   }
   else
   {
    //? handled by nested block leave statement final? ...
    //current_embed_branch_->ccg_end_statement();
   }
    //?current_embed_branch_->ccg_end_statement();

   sre_.advance();
   break;
  }

 case RZ_Read_Table_State::Block_Leave_No_Continue:
  {
   caon_ptr<RE_Node> cn = visitor_clasp().current_node();
   CAON_PTR_DEBUG(RE_Node ,cn)
   current_embed_branch_->ccg_block_leave();
   sre_.advance();
   break;
  }

 case RZ_Read_Table_State::Block_Final:
 {
  CAON_PTR_DEBUG(RZ_Lisp_Code_Block ,current_block_)

  caon_ptr<RZ_Lisp_Code_Block> pb = current_block_->parent_block();

  CAON_PTR_DEBUG(RZ_Lisp_Code_Block ,pb)

  if(pb)
  {
   if(caon_ptr<RE_Block_Entry> rbe = pb->get_block_entry())
   {
    CAON_PTR_DEBUG(RE_Block_Entry ,rbe)
    if(caon_ptr<RE_Node> sen = rbe->statement_entry_node())
    {
     CAON_PTR_DEBUG(RE_Node ,sen)
     CAON_DEBUG_NOOP
     // does this work for all block rewinds?
     //?visitor_clasp().set_current_block_node(rbe);
    }
   }
   if(caon_ptr<RE_Node> pben = pb->block_entry_node())
   {
    CAON_PTR_DEBUG(RE_Node ,pben)
    //  this needs to be only if there's no block continue ...
    //?
     //visitor_clasp().set_current_block_node(pben);
    //?
    //?

    //? here ...?
    //? ?!?
    //?
    visitor_clasp().check_confirm_pending_parent_block_node();
    visitor_clasp().set_current_pending_parent_block_node(pben);

    if(caon_ptr<RE_Block_Entry> rbe1 = pben->re_block_entry())
    {
     CAON_PTR_DEBUG(RE_Block_Entry ,rbe1)
     if(caon_ptr<RE_Node> sen1 = rbe1->statement_entry_node())
     {
      CAON_PTR_DEBUG(RE_Node ,sen1)
      CAON_DEBUG_NOOP
     }
    }
   }
  }
//?
//  if(current_block_info_)
//  {
//   current_embed_branch_->ccg_nested_block_leave();
//   current_embed_branch_->ccg_prepare_expression_leave();
//   current_embed_branch_->ccg_end_statement();
//  }
//  else
//  {
//   current_embed_branch_->ccg_block_leave();
//  }
  sre_.advance();
  break;
 }


 case RZ_Read_Table_State::Cross_Pre_Continue:
 {
  //?CAON_PTR_DEBUG(RE_Node ,current_node_)
  sre_.advance();
    //rts = read_table_state();
  break;
 }
 case RZ_Read_Table_State::Cross_Continue:
  ccg_.prepare_expression_continue();
  //  fallthrough...

 case RZ_Read_Table_State::Expression_Entry:
 case RZ_Read_Table_State::Expression_Sequence:
 case RZ_Read_Table_State::Block_Continue:
   //  fallthrough...
 case RZ_Read_Table_State::Statement_Entry:
  {
   CAON_PTR_DEBUG(RZ_Lisp_Embed_Branch ,current_embed_branch_)

   if(current_labeled_call_entry_object_ != visitor_clasp().current_call_entry_object())
   {
    // //  Checks for a label construct on the entry...
    QString label = visitor_clasp().call_entry_label();
    if(!label.isEmpty())
    {
     current_labeled_call_entry_object_ = visitor_clasp().current_call_entry_object();
     current_embed_branch_->ccg_register_call_entry_label(label);
    }
   }
  }
  // fallthrough
  get_kind:
  {
   //???
   check_raw_lisp(qts, visitor_clasp().current_node());

   // note -- currently this is run even if there's no current token...
   //?caon_ptr<RZ_Lisp_Source_Element> rcse = nullptr;

   QString ntest1 = sre_token.node_label();
   kind = get_current_token(sre_token, current_source_element);
   if(current_source_element)
   {
    CAON_PTR_DEBUG(RZ_Lisp_Source_Element ,current_source_element)
    CAON_DEBUG_NOOP
   }
   QString test = sre_token.text_value();
   QString ntest = sre_token.node_label();

   run_state().set_advance_token_state(RZ_Read_Table_Advance_Token_State::Token_Read);

   visitor_clasp().check_type_indicator(type_indicator_node);

   sre_.advance();
     //??
     //check_raw_lisp(qts, visitor_clasp().current_node());
   //rts = read_table_state();
   break;
  }

// case RZ_Read_Table_State::Expression_Sequence:
//  sre_.advance();
//  break;

 default:
  sre_.advance();
  break;
 }

 padv_state = sre_.post_advance_state();

 //
 //check_pending_raw_lisp(qts);

 switch(padv_state)
 {
 case RZ_Read_Table_Post_Advance_State::Reenter:
  //rts = read_table_state();
  goto read_table_state_loop;
 case RZ_Read_Table_Post_Advance_State::Holds_Token:
   goto rz_Check_Kind;
 case RZ_Read_Table_Post_Advance_State::N_A:
 case RZ_Read_Table_Post_Advance_State::No_Token:
  goto rz_Bypass_Check_Kind;
 case RZ_Read_Table_Post_Advance_State::Deactivate:
  return;
 }

rz_Check_Kind:
 {
  //? check_assignment_block_entry(qts, rzt);

  //?  caon_ptr<RZ_Graph_Clasp_Token> rct = visitor().last_graph_Clasp_token();
  //?  CAON_PTR_DEBUG(RZ_Graph_Clasp_Token ,rct)
  if(current_source_element)
  {
   CAON_PTR_DEBUG(RZ_Lisp_Source_Element ,current_source_element)
   current_embed_branch_->ccg_add_source_element(current_source_element);
    //?ccg_.add_source_element(current_source_element);
  }
  else
  {
   switch(kind)
   {
   case Basic_Token_Kinds::Symbol_Token:
    if(rzt.flags.is_function_expression_entry)
    {
     //  //  check for retval construct ...
     if(caon_ptr<RE_Node> retval_node = visitor().valuer()->retval_follow(sre_token.node()))
     {
      CAON_PTR_DEBUG(RE_Node ,retval_node)
      current_embed_branch_->ccg_setup_retval();
     }


//     QString label = visitor_clasp().call_entry_label();
//?     if(label.isEmpty())
     current_embed_branch_->ccg_function_expression_entry(rzt, sre_token);
//?     else
//?      current_embed_branch_->ccg_labeled_function_expression_entry(rzt, sre_token);

     //?ccg_.function_expression_entry(rzt, sre_token);
      //? check_init_embed_branch(qts, rzt);
     //?current_embed_branch_->write_function_name(sre_token);
    }
    else
    {
     if(type_indicator_node)
     {
      if(caon_ptr<RE_Token> re_token = type_indicator_node->re_token())
      {
       CAON_PTR_DEBUG(RE_Token ,re_token);
       QString type = re_token->raw_text();
       current_embed_branch_->ccg_add_symbol_with_type(rzt, type);
      }
     }
     else
     {
      current_embed_branch_->ccg_add_symbol(rzt);
     }

    }
      //?ccg_.add_symbol(rzt);
     //?current_embed_branch_->write_symbol_name(sre_token);
    break;
   case Basic_Token_Kinds::String_Token:
    current_embed_branch_->ccg_add_string_literal(rzt);
     //?ccg_.add_string_literal(rzt);
    //?current_embed_branch_->write_string_literal(sre_token);
    break;
   case Basic_Token_Kinds::Class_Def_Redirect:
     //? qDebug() << "+++++XXXXX+++++";
    break;
   case Basic_Token_Kinds::Function_Def_Redirect:
    write_function_def_redirect(qts, rzt.string_value(),
      *visitor_clasp().last_graph_clasp_token()->function_def_info());
    break;
   }
  }
  //?
  check_pending_raw_lisp(qts, RZ_Lisp_Code_Lisp_Paste_Modes::Immediate);
 }
// }
rz_Bypass_Check_Kind:

 //rts = read_table_state();
 goto read_table_state_loop;
#endif // HIDE

}

//?
//void RE_Generate_Lisp::check_init_embed_branch(QTextStream& qts, RZ_Graph_Run_Token& rzt)
//{
// Embed_Branch_Junctions j = find_embed_branch_junction(rzt.string_value());
// switch(j)
// {
// case Embed_Branch_Junctions::Class:
//  current_embed_branch_ = new RZ_Lisp_Embed_Branch__Class(qts,
//   current_embed_branch_,
//   current_embed_branch_->current_indentation_depth());
//  break;
// case Embed_Branch_Junctions::Leave_Logical_Scope:
//  current_embed_branch_ = new RZ_Lisp_Embed_Branch__Self_Closing_Statement("\n}",
//   qts, current_embed_branch_, current_embed_branch_->current_indentation_depth());
//  break;
// case Embed_Branch_Junctions::Access_Modifier:
//  current_embed_branch_ = new RZ_Lisp_Embed_Branch__Access_Modifier(qts,
//   current_embed_branch_, current_embed_branch_->current_indentation_depth());
// default: break;
// }
//}


caon_ptr<RZ_Lisp_Code_Block> RE_Generate_Lisp::current_block_parent()
{
 CAON_PTR_DEBUG(RZ_Lisp_Code_Block ,current_block_)
 if(current_block_)
 {
  //?! return current_block_->parent_block();
 }
 return nullptr;
}

void RE_Generate_Lisp::check_noop_embed_branch(QTextStream& qts)
{
 if(run_state().flags.current_noop)
 {
    //?!  current_embed_branch_ = new RZ_Lisp_Embed_Branch__Noop(qts, current_embed_branch_, ccg_);


   //current_embed_branch_->current_indentation_depth());
 }
}

void RE_Generate_Lisp::check_reset_current_embed_branch()
{
 // //  This assumes noop cannot last beyond one statement...
 run_state().flags.current_noop = false;

 // //   Normally the end of a statement means reverting
 //      current_embed_branch_ to its parent

   //?!  caon_ptr<RZ_Lisp_Embed_Branch> parent = current_embed_branch_->parent_branch();
//?!  if(parent)
//?!  {
  //?parent->current_indentation_depth() = current_embed_branch_->current_indentation_depth();
//?!   current_embed_branch_ = parent;
//?!  }
}


void RE_Generate_Lisp::check_if_block_leave(QTextStream& qts)
{
 if(current_block_info_) //caon_ptr<RZ_Lisp_Graph_Block_Info> bli = visitor().current_block_info())
 {
  if(current_block_info_->needs_else())
  {
   //?current_embed_branch_->check_else();
   // // Separate delete function?
    //?delete current_block_info_;
    //?current_block_info_ = nullptr;
  }
  else
  {
   //?
    // check_assignment_block_leave(qts);
   current_block_info_->reset_iterator();
  }
 }
}



void RE_Generate_Lisp::check_assignment_block_leave(QTextStream& qts)
{
#ifdef HIDE
 if(current_block_)
 {
  CAON_PTR_DEBUG(RZ_Lisp_Code_Block ,current_block_)
  if(caon_ptr<RE_Block_Entry> rbe = current_block_->get_block_entry())
  {
   CAON_PTR_DEBUG(RE_Block_Entry ,rbe)
   if(rbe->flags.if_block)
   {
    if(rbe->flags.has_else_block)
    {
     return;
    }
   }
  }
 }
 if(current_block_info_)
 {
  CAON_PTR_DEBUG(RZ_Lisp_Graph_Block_Info ,current_block_info_)
//  qts << " } in ";
//  if(current_block_info_->has_returns_assignments())
//  {
//   qts << "returns";
//  }
 }
#endif // HIDE
}

void RE_Generate_Lisp::check_assignment_block_entry(QTextStream& qts, RZ_Graph_Run_Token& rzt)
{
 if(caon_ptr<RZ_Lisp_Graph_Block_Info> bli = visitor_clasp().current_block_info())
 {
  current_block_info_ = bli;
  CAON_PTR_DEBUG(RZ_Lisp_Graph_Block_Info ,current_block_info_)
  CAON_PTR_DEBUG(RZ_Lisp_Code_Block ,current_block_)
  //current_block_->set_block_info(bli);
  QListIterator<caon_ptr<RE_Node>> it(bli->assignment_order());

  int count = 0;

//bli->assignment_order().count();
//  qts << " Let ";
//  if(count > 1)
//   qts << " ("

  QString let_insertions;
  while(it.hasNext())
  {
   //++count;
   caon_ptr<RE_Node> n = it.next();
   if(caon_ptr<RZ_Lisp_Token> token = n->lisp_token())
   {
//    if(count > 0)
//     let_insertions += ", ";
    QString sym = bli->symbol_string(token->lisp_string_value());
//    let_insertions += sym;
    ++count;
   }
  }
  CAON_PTR_DEBUG(RZ_Lisp_Graph_Block_Info ,bli)
  caon_ptr<RE_Node> ben = bli->block_entry_node();
  CAON_PTR_DEBUG(RE_Node ,ben)
  int extras = bli->returns_assignments().count();
  if(extras == 1)
  {
   if(count > 0)
    let_insertions += ", ";
   let_insertions += "returns";
   ++count;
  }
  else
  {
   while(extras > 0)
   {
    QString symbol = QString("returns'%1").arg(extras);
    if(count > 0)
     let_insertions += ", ";
    let_insertions += symbol;
    ++count;
    --extras;
   }
  }
  if(count == 0)
   return;

//  qts << " let { ";
  if(count > 1)
  {
//   qts << '(';
  }
//  qts << let_insertions;
  if(count > 1)
  {
//   qts << ')';
  }
//  qts << " = \n";
 }
}


void RE_Generate_Lisp::check_block_end(QTextStream& qts)
{
#ifdef HIDE

 // //  returns the (old) current block after setting current_block_ to its parent,
  //    if this exists, otherwise nullptr
 CAON_PTR_DEBUG(RZ_Lisp_Code_Block ,current_block_)
 if(caon_ptr<RZ_Lisp_Code_Block> parent = current_block_->parent_block())
 {
  check_if_block_leave(qts);
  check_assignment_block_leave(qts);
//?  //current_embed_branch_->check_block_end();
//?  current_embed_branch_->write_line_standalone(" --}");
//?  current_embed_branch_->write_line_standalone(current_block_->block_end_string());
  CAON_PTR_DEBUG(RZ_Lisp_Graph_Block_Info ,current_block_info_)
  //?current_block_ = parent;
  current_parent_block_ = parent;
  reset_current_block_info();
 }
//? --current_embed_branch_->current_indentation_depth();

#endif // HIDE
}

void RE_Generate_Lisp::check_block_entry(QTextStream& qts)
{
 //? current_embed_branch_->write_line_standalone(QString(" --{.%1").arg(block_count_));
 ++block_count_;
}

void RE_Generate_Lisp::reset_current_block_info()
{
 CAON_PTR_DEBUG(RZ_Lisp_Code_Block ,current_block_)
 //?! current_block_info_ = current_block_->block_info(); //
 CAON_PTR_DEBUG(RZ_Lisp_Graph_Block_Info ,current_block_info_)
 CAON_DEBUG_NOOP
}

#ifdef HIDE
caon_ptr<RZ_Lisp_Code_Lexmap> RE_Generate_Lisp::check_block_lexicals(QTextStream& qts, caon_ptr<RE_Block_Entry> rbe)
{
 caon_ptr<RZ_Lisp_Code_Lexmap> result = nullptr;
 if(rbe)
 {
  bool else_block = rbe->flags.else_block;
  QString last_key;
  //?  lex_iterator_entry_nodes_.push(visitor().current_node());
  CAON_PTR_DEBUG(RE_Block_Entry ,rbe)
  if(caon_ptr<RZ_Lisp_Graph_Lexical_Scope> rls = rbe->lexical_scope())
  {
   CAON_PTR_DEBUG(RZ_Lisp_Graph_Lexical_Scope ,rls)
   if(!rls->symbol_order().isEmpty())
   {
    result = new RZ_Lisp_Code_Lexmap();
    QListIterator<QString> it(rls->symbol_order());
    while(it.hasNext())
    {
     bool break_short = false;
     bool key_is_found = last_key.isEmpty();

     QString key = it.next();

     if(!key_is_found)
     {
      if(key == last_key)
       key_is_found = true;
      continue;
     }
     const RZ_Lisp_Graph_Scope_Token& st = rls->symbols()[key];
     CAON_EVALUATE_DEBUG(RZ_Lisp_Token ,ft ,st.function_token())
     CAON_EVALUATE_DEBUG(RZ_Lisp_Token ,dt ,st.declaration_token())

     //?key.replace('-', '_');
     RZ_Lisp_Graph_Basic_Type_Groups g =
       visitor().valuer()->parse_basic_type_group(st);
     switch(g)
     {
     case RZ_Lisp_Graph_Basic_Type_Groups::Opaque_Call:
      {
       QString type = st.type_to_string();
       caon_ptr<RZ_Opaque_Call> opc = st.vh().pRestore<RZ_Opaque_Call>();
       CAON_PTR_DEBUG(RZ_Opaque_Call ,opc)
       if(caon_ptr<RE_Node> pe_node = opc->pre_entry_node())
       {
        CAON_PTR_DEBUG(RE_Node ,pe_node)
        if(!type.isEmpty())
        {
         //?qts << " :: " << type << "; " << key << ' ';
        }
        result->add_value(key, pe_node);
        break;
        //?qts << " = ";
        //?init_expression_entry(pe_node, scope, key);
        break_short = true;
        break;
       }
      }

     case RZ_Lisp_Graph_Basic_Type_Groups::Core_Function:
      {
       QString type = st.type_to_string();
       if(!type.isEmpty())
       {
        //?qts << " :: " << translate_type(type) << "; " << key << ' ';
       }
       caon_ptr<RZ_Lisp_Core_Function> cf = st.vh().pRestore<RZ_Lisp_Core_Function>();
       CAON_PTR_DEBUG(RZ_Lisp_Core_Function ,cf)
       if(caon_ptr<RE_Node> pe_node = st.vh().pRetrieve<RE_Node>())
       {
        CAON_PTR_DEBUG(RE_Node ,pe_node)
        //?qts << " = ";
        //?init_expression_entry(pe_node, scope, key);
        break_short = true;
       }
       break;
      }

     case RZ_Lisp_Graph_Basic_Type_Groups::Opaque_Symbol:
      {
       caon_ptr<RE_Node> symbol_node = st.vh().pRetrieve<RE_Node>();
       CAON_PTR_DEBUG(RE_Node ,symbol_node)
       caon_ptr<RZ_Lisp_Token> token = symbol_node->lisp_token();
       QString type = st.type_to_string();
       if(!type.isEmpty())
       {
        //?qts << " :: " << translate_type(type) << "; " << key << ' ';
       }
       QString val = token->string_value();
       //?if(type.isEmpty())
       //? qts << " = " << val << ';';
       //?else
       //? qts << " :: " << translate_type(type) << "; " << key <<  " = " << val << ';';
       result->add_value(key, symbol_node);
       //?qts << " = " << token->cpp_string_value() << ';';
       break;

      }

     case RZ_Lisp_Graph_Basic_Type_Groups::Tuple:
      {
       QString type = st.type_to_string();
       caon_ptr<RZ_Lisp_Vector> rlv = st.vh().pRestore<RZ_Lisp_Vector>();
       CAON_PTR_DEBUG(RZ_Lisp_Vector ,rlv)
       if(caon_ptr<RE_Node> entry_node = rlv->get_call_entry_node())
       {
        CAON_PTR_DEBUG(RE_Node ,entry_node)
        if(!type.isEmpty())
        {
        }
        // this only used for Haskell?
        //?break_short = true;
        break_short = true;
        break;
       }
      }

     case RZ_Lisp_Graph_Basic_Type_Groups::Function_Def_Info:
      {
       QString type = st.type_to_string();
       caon_ptr<RZ_Function_Def_Info> rfdi = st.vh().pRestore<RZ_Function_Def_Info>();
       CAON_PTR_DEBUG(RZ_Function_Def_Info ,rfdi)
       if(caon_ptr<RE_Node> entry_node = rfdi->function_def_entry_node())
       {
        CAON_PTR_DEBUG(RE_Node ,entry_node)
        result->add_value(key, entry_node);
         // this only used for Haskell?
         //?break_short = true;
        break;
       }
      }


     default:
      {
       QString type;
       QString val = visitor_clasp().valuer().value_to_string(type, st);
       result->add_value(key, val);
      }
     }
     if(break_short)
      break;
    }
    //?write_block_lexicals(qts, rls, "\n } in \n");
   }
  }
 }
 return result;
}
#endif






//void RE_Generate_Lisp::write_function_name(QTextStream& qts, const RZ_Graph_Run_Token& rzt)
//{
// qts << get_function_name(rzt);
// qts << '(';
//}

//void RE_Generate_Lisp::write_symbol_name(QTextStream& qts, const RZ_Graph_Run_Token& rzt)
//{
// QString str = rzt.string_value();
// if(rzt.flags.is_infix_operator_entry)
// {
//  held_infix_operator_ = str;
// }
// else
// {
//  qts << str << ' ';
//  check_write_held_infix_operator(qts);
// }
//}

//void RE_Generate_Lisp::write_string_literal(QTextStream& qts, const RZ_Graph_Run_Token& rzt)
//{
// qts << '"' << rzt.string_value() << '"' << ' ';
// check_write_held_infix_operator(qts);
//}

//QString RE_Generate_Lisp::check_hold_infix_operator(const RZ_Graph_Run_Token& rzt,
// QString str)
//{
// if(rzt.flags.is_infix_operator_entry)
// {
//  held_infix_operator_ = str;
//  return QString();
// }
// return str;
//}


//void RE_Generate_Lisp::check_write_held_infix_operator(QTextStream& qts)
//{
// if(!held_infix_operator_.isEmpty())
//  qts << held_infix_operator_ << ' ';
// held_infix_operator_.clear();;
//}


//caon_ptr<RZ_Lisp_Graph_Visitor> RE_Prerun_Normalize::scan()
//{
// caon_ptr<RZ_Lisp_Graph_Visitor> result = new RZ_Lisp_Graph_Visitor(&graph_);
// result->normalize();
// return result;
//}




//#include "kernel/graph/rz-re-graph.h"
//#include "kernel/graph/rz-re-node.h"

//#include "kernel/rz-re-root.h"

//#include "token/rz-re-token.h"

//#include "tuple/rz-re-tuple-info.h"

//#include "rzns.h"

//USING_RZNS(RECore)

//RE_Pre_Normal_Lisp::RE_Pre_Normal_Lisp(caon_ptr<RE_Document> document)
// : RE_Lisp_Output(document)
//{

//}


//void RE_Pre_Normal_Lisp::report_token(QTextStream& qts,
// const RE_Token& token)
//{
// if(token.flags.is_symbol_declaration)
// {
//  qts << "(rz-decl " << token.raw_text() << ")";
// }
// else
//  qts << token.get_lisp_out();
//}

//void RE_Pre_Normal_Lisp::report_tuple_info_entry(QTextStream& qts,
// const RE_Tuple_Info& rti)
//{
// qts << '(' << rti.lisp_out() << ' ';
//}

//void RE_Pre_Normal_Lisp::report_tuple_info_leave(QTextStream& qts,
// const RE_Tuple_Info& rti)
//{
// qts << ')';
//}

////void RE_Pre_Normal_Lisp::output_from_node(QTextStream& qts,
//// const RE_Node& node, int indent)
////{
//// //CAON_PTR_DEBUG(RE_Node ,node)

//// QString padding(indent, ' ');
////// qts << "\n" << padding;

//// if(caon_ptr<RE_Token> token = node.re_token())
//// {
////  qts << get_lisp_out(*token);
//// }

//// if(caon_ptr<RE_Call_Entry> rce = node.re_call_entry())
//// {
////  //  qts << get_lisp_out(*token);
//// }

//// if(caon_ptr<RE_Node> next_node = rq_.Run_Call_Sequence(&node))
//// {
////  qts << ' ';
////  output_from_node(qts, *next_node, indent + 1);
////  //qts << ' ';
//// }

//// if(caon_ptr<RE_Node> next_node = rq_.Run_Call_Entry(&node))
//// {
////  qts << "\n" << padding;
////  qts << '(';
////  output_from_node(qts, *next_node, indent + 1);
////  qts << ')';
////  if(caon_ptr<RE_Node> cross_node = rq_.Run_Cross_Continue(next_node))
////  {
////   output_from_node(qts, *cross_node, indent);
////  }
//// }

//// if(caon_ptr<RE_Node> next_node = rq_.Run_Data_Entry(&node))
//// {
////  if(caon_ptr<RE_Tuple_Info> rti = next_node->re_tuple_info())
////  {
////   qts << "\n" << padding << ' ';
////   report_tuple_info_entry(qts, *rti);
////   if(next_node = rq_.Run_Data_Entry(next_node))
////    output_from_node(qts, *next_node, indent + 1);
////   report_tuple_info_leave(qts, *rti);
////  }
////  if(caon_ptr<RE_Node> cross_node = rq_.Run_Cross_Continue(next_node))
////  {
////   output_from_node(qts, *cross_node, indent);
////  }
//// }
////}


//RE_Generate_Tqns::RE_Generate_Tqns(RZ_Lisp_Graph_Visitor& visitor)
// : sre_(visitor)
////    , project_(nullptr), current_block_(nullptr), block_count_(0),
////    current_embed_branch_(nullptr), //, function_def_syntax_(RZ_Function_Def_Syntax("", "::"))
////    current_block_info_(nullptr) //, last_assign_from_preinit_embed_branch_(nullptr)
//{
// //init_function_def_syntax();
//}

//void RE_Generate_Tqns::init_project()
//{
//// project_ = new RZ_Tqns_Project;
//// visitor().take_project(project_);
//}

//void RE_Generate_Tqns::write(QTextStream& qts)
//{
// sre_.init();

// qts << "xxx";
//}

// current_embed_branch_ = new RZ_Tqns_Embed_Normal(qts, nullptr, 0);
// run_state().flags.cpp_mode = true;
// check_advance(qts);
// run_state().flags.cpp_mode = false;

#ifdef HIDE

void RE_Generate_Tqns::init_function_def_syntax()
{
 function_def_syntax_.flags.hide_type = true; //set_type_from_symbol_separator("::");
 function_signature_syntax_.flags.hide_symbol = true;
 function_signature_syntax_.set_symbol_separator("->");
}


void RE_Generate_Tqns::init_project()
{
 project_ = new RZ_Tqns_Project;
 visitor().take_project(project_);
}

void RE_Generate_Tqns::write(QTextStream& qts)
{
 sre_.init();
 //visitor().reset();

 current_embed_branch_ = new RZ_Tqns_Embed_Normal(qts, nullptr, 0);


 run_state().flags.cpp_mode = true;
 check_advance(qts);

 run_state().flags.cpp_mode = false;

 //qts << "xxx";
 //visitor().anticipate();
}


void RE_Generate_Tqns::prepare_expression_entry(QTextStream& qts, bool nested)
{
 if(caon_ptr<RE_Node> node = visitor().next_node())
 {
  CAON_PTR_DEBUG(RE_Node ,node)
  if(caon_ptr<RZ_Lisp_Token> token = node->lisp_token())
  {
   CAON_PTR_DEBUG(RZ_Lisp_Token ,token)
   if(token->flags.is_block_entry_suppressing_expression)
    return;

  }
 }
 if(caon_ptr<RE_Node> current_node = visitor().current_node())
 {
  CAON_PTR_DEBUG(RE_Node ,current_node)
  if(caon_ptr<RZ_Lisp_Token> token = current_node->lisp_token())
  {
   CAON_PTR_DEBUG(RZ_Lisp_Token ,token)
   // //?  Is this the right way to do this?
   if(token->flags.has_mapkey)
   {
    //?qts << '@';
    return;
   }
  }
 }

 // // when is this needed?
 if(nested)
  qts << '(';


 //current_embed_branch_->write_line_standalone("(");
 //qts << ' ' << '(';
}

void RE_Generate_Tqns::prepare_statement_entry(QTextStream& qts)
{
 current_embed_branch_->write_statement_entry();
 //if(run_state().flags.current_noop)

}

void RE_Generate_Tqns::write_file_entry(QTextStream& qts)
{
 qts << tqns_code_model().tqns_code();
 // qts << "\n#include \"project-global-rz-include.h\"\n\n\n";
}

RZ_Tqns_Code& RE_Generate_Tqns::tqns_code_model()
{
 return sre_.visitor().valuer()->rz_tqns_code();
}


Basic_Token_Kinds RE_Generate_Tqns::get_current_token(RZ_SRE_Token& sre_token)
{
 if(run_state().flags.current_noop)
 {
  return Basic_Token_Kinds::NOOP_Token;
 }
 // return;

 sre_.load_sre_token(sre_token);
 //visitor().get_current_token(rzt);
 Basic_Token_Kinds kind = sre_token.run_token()->kind();
 return kind;
}

void RE_Generate_Tqns::write_function_def_type_expression_redirect(QTextStream& qts,
 QString function_name, RZ_Function_Def_Info& fdi)
{
 QString lambda_channel = fdi.lambda_channel_string(function_def_syntax_);

 if(fdi.flags.type_symbol_assignment)
 {
  qts << "type " << function_name << ' ' << lambda_channel << " = ";

  if(caon_ptr<RE_Function_Def_Entry> rfde = fdi.function_def_entry())
  {
   if(caon_ptr<RE_Node> node = rfde->node())
   {
    QString expression = visitor().type_expression_from_node(node);
    qts << expression;
   }
   //rfde->
  }

  qts << ";\n";
 }

}


void RE_Generate_Tqns::write_function_def_redirect(QTextStream& qts,
 QString function_name, RZ_Function_Def_Info& fdi)
{
 if(fdi.flags.type_expression)
 {
  write_function_def_type_expression_redirect(qts, function_name, fdi);
  return;
 }

 QString return_channel = fdi.return_channel_string_tqns();
 QString lambda_channel = fdi.lambda_channel_string(function_signature_syntax_);

 bool not_call_arrow_with_matching = !fdi.flags.with_matching;
 QString lambda_channel_def;

 if(not_call_arrow_with_matching)
  lambda_channel_def = fdi.lambda_channel_string(function_def_syntax_);

 QString monad_channel = fdi.monad_channel_string(function_signature_syntax_);

// qts << return_channel << ' ' << function_name
//  << '(' << lambda_channel << ')';

 bool monad_or_lambda = !(monad_channel.isEmpty() && lambda_channel.isEmpty());


 if(monad_or_lambda)
 {
  if(monad_channel.isEmpty())
  {
   qts << function_name << " :: " <<
    lambda_channel;
  }
  else
  {
   qts << function_name << " :: " <<
    monad_channel;
  }
 }

 if(!return_channel.isEmpty())
 {
  qts << " -> " << return_channel;
 }

 if(monad_or_lambda)
  qts << ";\n";


 if(not_call_arrow_with_matching)
  qts << function_name << ' ' << lambda_channel_def << " = ";
 else
 {
  qts << " {-. withhold def of " << function_name << " (matchings below) .-} ";
 }

 if(fdi.flags.monad)
  qts << "do ";

 held_signature_ = function_name;

}



//void RE_Generate_Tqns::check_statement_noop(QTextStream& qts)
//{
// //if(rq_.)
//}


void RE_Generate_Tqns::check_noop_embed_branch(QTextStream& qts)
{
 if(run_state().flags.current_noop)
 {
  current_embed_branch_ = new RZ_Tqns_Embed_Branch__Noop(qts,
   current_embed_branch_, current_embed_branch_->current_indentation_depth());
 }
}

void RE_Generate_Tqns::check_block_lexicals(QTextStream& qts)
{
 if(caon_ptr<RE_Block_Entry> rbe = visitor().current_node()->re_block_entry())
 {
  bool else_block = rbe->flags.else_block;
//  if(rbe->flags.else_block)
//  {
//    //? qts << '(';
//   //? qts << "\n  else  \n";
//   return;
//  }
  lex_iterator_entry_nodes_.push(visitor().current_node());
  CAON_PTR_DEBUG(RE_Block_Entry ,rbe)
  if(caon_ptr<RZ_Lisp_Graph_Lexical_Scope> rls = rbe->lexical_scope())
  {
   if(!rls->symbol_order().isEmpty())
   {
    CAON_PTR_DEBUG(RZ_Lisp_Graph_Lexical_Scope ,rls)
    qts << " let {";
    write_block_lexicals(qts, rls, "\n } in \n");
   }
  }
 }
}

void RE_Generate_Tqns::write_block_lexicals(QTextStream& qts,
 caon_ptr<RZ_Lisp_Graph_Lexical_Scope> scope, QString write_when_complete, QString last_key)
{
 CAON_PTR_DEBUG(RZ_Lisp_Graph_Lexical_Scope ,scope)

 bool break_short = false;
 bool key_is_found = last_key.isEmpty();
 QListIterator<QString> it(scope->symbol_order());
 while(it.hasNext())
 {
  //QMapIterator<QString, RZ_Lisp_Graph_Scope_Token> it(scope->symbols());
  QString key = it.next();

  if(!key_is_found)
  {
   if(key == last_key)
    key_is_found = true;
   continue;
  }
  const RZ_Lisp_Graph_Scope_Token& st = scope->symbols()[key];
  CAON_EVALUATE_DEBUG(RZ_Lisp_Token ,ft ,st.function_token())
  CAON_EVALUATE_DEBUG(RZ_Lisp_Token ,dt ,st.declaration_token())

  key.replace('-', '_');
  qts << "\n  " << key << ' ';
  RZ_Lisp_Graph_Basic_Type_Groups g =
    visitor().valuer()->parse_basic_type_group(st);
  switch(g)
  {
  case RZ_Lisp_Graph_Basic_Type_Groups::Opaque_Call:
   {
    QString type = st.type_to_string();
    caon_ptr<RZ_Opaque_Call> oc = st.vh().pRestore<RZ_Opaque_Call>();
    CAON_PTR_DEBUG(RZ_Opaque_Call ,oc)
    if(caon_ptr<RE_Node> pe_node = oc->pre_entry_node())
    {
     CAON_PTR_DEBUG(RE_Node ,pe_node)
     if(!type.isEmpty())
     {
      qts << " :: " << type << "; " << key << ' ';
     }
     qts << " = ";
     init_expression_entry(pe_node, scope, key);
     break_short = true;
     break;
    }
   }

  case RZ_Lisp_Graph_Basic_Type_Groups::Core_Function:
   {
    QString type = st.type_to_string();
    if(!type.isEmpty())
    {
     qts << " :: " << translate_type(type) << "; " << key << ' ';
    }
    caon_ptr<RZ_Lisp_Core_Function> cf = st.vh().pRestore<RZ_Lisp_Core_Function>();
    CAON_PTR_DEBUG(RZ_Lisp_Core_Function ,cf)
    if(caon_ptr<RE_Node> pe_node = st.vh().pRetrieve<RE_Node>())
    {
     CAON_PTR_DEBUG(RE_Node ,pe_node)
     qts << " = ";
     init_expression_entry(pe_node, scope, key);
     break_short = true;
    }
    break;
   }

  case RZ_Lisp_Graph_Basic_Type_Groups::Opaque_Symbol:
   {
    caon_ptr<RE_Node> symbol_node = st.vh().pRetrieve<RE_Node>();
    CAON_PTR_DEBUG(RE_Node ,symbol_node)
    caon_ptr<RZ_Lisp_Token> token = symbol_node->lisp_token();
    QString type = st.type_to_string();
    if(!type.isEmpty())
    {
     qts << " :: " << translate_type(type) << "; " << key << ' ';
    }
    qts << " = " << token->cpp_string_value() << ';';
    break;

   }

  case RZ_Lisp_Graph_Basic_Type_Groups::Tuple:
   {
    QString type = st.type_to_string();
    caon_ptr<RZ_Lisp_Vector> rlv = st.vh().pRestore<RZ_Lisp_Vector>();
    CAON_PTR_DEBUG(RZ_Lisp_Vector ,rlv)
    if(caon_ptr<RE_Node> entry_node = rlv->get_call_entry_node())
    {
     CAON_PTR_DEBUG(RE_Node ,entry_node)
     if(!type.isEmpty())
     {
      qts << " :: " << type << "; " << key << ' ';
     }
     qts << " = ";
     init_tuple_entry(entry_node, scope, key);
     break_short = true;
     break;
    }
   }

  default:
   {
    QString type;
    QString val = valuer().value_to_string(type, st);
    if(type.isEmpty())
     qts << " = " << val << ';';
    else
     qts << " :: " << translate_type(type) << "; " << key <<  " = " << val << ';';
   }
  }
  if(break_short)
   break;
 }
 if(!break_short)
 {
  qts << write_when_complete;
  sre_.run_state().set_read_table_state(RZ_Read_Table_State::Lexical_Declarations_Leave);
  sre_.run_state().set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
  caon_ptr<RE_Node> old_current_node = lex_iterator_entry_nodes_.pop();
  CAON_PTR_DEBUG(RE_Node ,old_current_node)
  visitor().set_current_node(old_current_node);
 }
}


RZ_Lisp_Graph_Valuer& RE_Generate_Tqns::valuer()
{
 return *visitor().valuer();
}

void RE_Generate_Tqns::check_block_entry(QTextStream& qts)
{
 current_embed_branch_->write_line_standalone(QString(" --{.%1").arg(block_count_));
 ++block_count_;
 // if(caon_ptr<RZ_Lisp_Token> token = visitor().current_lisp_token())
 // {
 //  if(token->flags.is_block_entry_caserun)
 //  {
 //   //current_block_->flags.s
 //  }
 // }
}

void RE_Generate_Tqns::init_tuple_entry(caon_ptr<RE_Node> entry_node,
 caon_ptr<RZ_Lisp_Graph_Lexical_Scope> scope, QString last_key)
{
 lex_iterators_.push({scope, last_key});
 CAON_PTR_DEBUG(RE_Node ,entry_node)
 entry_node->debug_connections();
 sre_.run_state().set_read_table_state(RZ_Read_Table_State::Lexical_Expression_Pre_Entry);
 sre_.run_state().set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
 sre_.visitor().set_current_node(entry_node);
 sre_.visitor().set_current_lex_iterator(&lex_iterators_.top());
 CAON_DEBUG_NOOP
}
// if(caon_ptr<RE_Node> den = sre_.visitor().get_data_entry(entry_node))
// {
//  CAON_PTR_DEBUG(RE_Node ,den)
//  if(caon_ptr<RE_Node> dn = sre_.visitor().get_data_entry(den))
//  {
//   CAON_PTR_DEBUG(RE_Node ,dn)
//   sre_.run_state().set_read_table_state(RZ_Read_Table_State::Lexical_Expression_Pre_Entry);
//   sre_.run_state().set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//   sre_.visitor().set_current_node(dn);
//   sre_.visitor().set_current_lex_iterator(&lex_iterators_.top());
//   CAON_DEBUG_NOOP
//  }
// }
//}

void RE_Generate_Tqns::init_expression_entry(caon_ptr<RE_Node> entry_node,
 caon_ptr<RZ_Lisp_Graph_Lexical_Scope> scope, QString last_key)
{
 lex_iterators_.push({scope, last_key});
 CAON_PTR_DEBUG(RE_Node ,entry_node)
 sre_.run_state().set_read_table_state(RZ_Read_Table_State::Lexical_Expression_Pre_Entry);
 sre_.run_state().set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
 sre_.visitor().set_current_node(entry_node);
 sre_.visitor().set_current_lex_iterator(&lex_iterators_.top());
 CAON_DEBUG_NOOP
}

void RE_Generate_Tqns::continue_lexical_declarations(QTextStream& qts)
{
 QPair<caon_ptr<RZ_Lisp_Graph_Lexical_Scope>, QString> top = lex_iterators_.pop();
 write_block_lexicals(qts, top.first, "\n } in \n", top.second);
 //lex_iterators_.push({entry_node, it});
}

void RE_Generate_Tqns::check_advance(QTextStream& qts)
{
 RZ_Read_Table_Post_Advance_State padv_state;
 RZ_Read_Table_State rts;// = read_table_state();

 RZ_Graph_Run_Token rzt;
 caon_ptr<RE_Node> current_node = nullptr;
 RZ_SRE_Token sre_token(&rzt, current_node);

 Basic_Token_Kinds kind;


read_table_state_loop:
 rts = sre_.read_table_state();
 switch(rts)
 {
 case RZ_Read_Table_State::Inactive:
  return;

 case RZ_Read_Table_State::Graph_End:
  return;

 case RZ_Read_Table_State::Root:
  sre_.advance();
  //rts = read_table_state();
  break;

 case RZ_Read_Table_State::Cpp_File_Entry:
  write_file_entry(qts);
  current_block_ = new RZ_Tqns_Code_Block(nullptr);
  sre_.advance();
  //rts = read_table_state();
  break;

 case RZ_Read_Table_State::Statement_Pre_Entry:
  //check_statement_noop(qts);
  {
   CAON_PTR_DEBUG(RZ_Tqns_Embed_Branch ,current_embed_branch_)
   check_noop_embed_branch(qts);
   prepare_statement_entry(qts);
   sre_.advance();
  //rts = read_table_state();
   break;
  }

 case RZ_Read_Table_State::Statement_Prepare_Entry:
  //check_statement_noop(qts);
  {
   check_noop_embed_branch(qts);
   prepare_statement_entry(qts);
   // //?
    current_embed_branch_->write_line_indentation();

   prepare_expression_entry(qts, false);
   sre_.advance();
   //rts = read_table_state();
   break;
  }

 case RZ_Read_Table_State::Lexical_Expression_Pre_Entry:
  {
   sre_.advance();
  //rts = read_table_state();
   break;
  }

 case RZ_Read_Table_State::Block_Pre_Entry_As_Sequence:
  {
   if(caon_ptr<RE_Block_Entry> rbe = visitor().current_node_as_block_entry())
   {
    CAON_PTR_DEBUG(RE_Block_Entry ,rbe)
    if(rbe->flags.if_block)
    {
     qts << " then \n";
     visitor().valuer()->check_assignments();
    }
    else if(rbe->flags.else_block)
    {
     qts << " else \n";
     visitor().valuer()->check_assignments();
    }

    if(caon_ptr<RZ_Lisp_Graph_Block_Info> rbi = current_block_->block_info())
    {
     CAON_PTR_DEBUG(RZ_Lisp_Graph_Block_Info ,rbi)
     CAON_PTR_DEBUG(RZ_Tqns_Code_Block ,current_block_)
     //  this should really be in valuer ...
     rbi->set_child_block_info(current_block_info_);
    }

    current_block_ = new RZ_Tqns_Code_Block(current_block_, rbe);
    current_block_->set_block_info(current_block_info_);
    CAON_PTR_DEBUG(RZ_Lisp_Graph_Block_Info ,current_block_info_)
    CAON_PTR_DEBUG(RZ_Tqns_Code_Block ,current_block_)

    current_embed_branch_->write_line_standalone(" --{.");
   }
   sre_.advance();
  //rts = read_table_state();
  }
  break;

 case RZ_Read_Table_State::Block_Statement_List_Pre_Entry:
  sre_.advance();
  break;

 case RZ_Read_Table_State::List_Pre_Entry:
  prepare_expression_entry(qts, true);
  sre_.advance();
  //rts = read_table_state();
  break;

 case RZ_Read_Table_State::Lex_Tuple_Pre_Entry:
 {
  prepare_expression_entry(qts, true);
  sre_.advance();
  //rts = read_table_state();
  break;
 }

 case RZ_Read_Table_State::Lex_Tuple_Entry:
 {
  write_lex_tuple_entry(qts);
  //qts << " VEC ";
  //prepare_expression_entry(qts, true);
  sre_.advance();
  //rts = read_table_state();
  break;
 }

 case RZ_Read_Table_State::Lambda_Block_Statement_Pre_Entry:
  {
   sre_.advance();
   break;
  }
 case RZ_Read_Table_State::Lambda_Block_Statement_Entry:
  {
   //?
   //?prepare_expression_entry(qts, true);

   //?
   check_block_lexicals(qts);
   check_noop_embed_branch(qts);

   sre_.advance();
   current_embed_branch_->write_line_indentation();
   break;
  }
 case RZ_Read_Table_State::Block_Statement_Entry:
  {
   //?
   //?prepare_expression_entry(qts, true);

   //?
   check_block_lexicals(qts);
   check_noop_embed_branch(qts);

   sre_.advance();
   current_embed_branch_->write_line_indentation();
   break;
  }

 case RZ_Read_Table_State::Statement_Entry_Indent:
  current_embed_branch_->write_line_indentation();

 case RZ_Read_Table_State::Statement_Entry:
//  current_embed_branch_->write_line_indentation();
//  qts << '@';

  //qts << QString(current_indentation_depth_, ' ');
  //  Fallthrough...

 case RZ_Read_Table_State::List_Entry:
    // //  The token here (List_Entry) should hold a callable value;
    //     opportunity to intercept

 case RZ_Read_Table_State::List_Embed_Sequence:
 case RZ_Read_Table_State::List_Sequence:
  kind = get_current_token(sre_token);
  if(sre_token.run_token())
  {
   CAON_EVALUATE_DEBUG(RZ_Graph_Run_Token ,srt ,sre_token.run_token())
   CAON_DEBUG_NOOP
  }
  sre_.advance();
  //rts = read_table_state();
  break;

 case RZ_Read_Table_State::Lexical_Declarations_Leave:
  {
   sre_.advance();
   goto rz_Bypass_Check_Kind; //break;
  }
 case RZ_Read_Table_State::Lexical_Expression_Leave:
  {
   qts << ";\n";
   continue_lexical_declarations(qts);
 //  sre_.advance();
   goto rz_Bypass_Check_Kind; //break;
  }
 case RZ_Read_Table_State::Cpp_Block_Entry:
  {
   check_block_lexicals(qts);
   check_noop_embed_branch(qts);
   sre_.advance();
  //rts = read_table_state();
   break;
  }

 case RZ_Read_Table_State::Block_Pre_Entry:
  if(caon_ptr<RE_Block_Entry> rbe = visitor().current_node_as_block_entry())
  {
   // duplicated! ...
   if(caon_ptr<RZ_Lisp_Graph_Block_Info> rbi = current_block_->block_info())
   {
    CAON_PTR_DEBUG(RZ_Lisp_Graph_Block_Info ,rbi)
    CAON_PTR_DEBUG(RZ_Tqns_Code_Block ,current_block_)
    //  this should really be in valuer ...
    rbi->set_child_block_info(current_block_info_);
   }

   CAON_PTR_DEBUG(RE_Block_Entry ,rbe)
   current_block_ = new RZ_Tqns_Code_Block(current_block_, rbe);

   current_block_->set_block_info(current_block_info_);
   CAON_PTR_DEBUG(RZ_Lisp_Graph_Block_Info ,current_block_info_)
   CAON_PTR_DEBUG(RZ_Tqns_Code_Block ,current_block_)
   check_block_entry(qts);
  }
  //qts << '\n' << QString(current_indentation_depth_, ' ') << "{\n";
  ++current_embed_branch_->current_indentation_depth();
  sre_.advance();
  //rts = read_table_state();
  goto rz_Bypass_Check_Kind;
  break;

 case RZ_Read_Table_State::Cpp_Redirect_Leave:
  sre_.advance();
  //rts = read_table_state();
  goto rz_Check_Kind;
  break;

 case RZ_Read_Table_State::Cpp_Redirect_Leave_Block_Pre_Entry:
  sre_.advance();
  //kind = get_current_token(sre_token);

  //rts = read_table_state();
  break;

 case RZ_Read_Table_State::Cpp_Redirect_Final:
  sre_.advance();
  //rts = read_table_state();
  goto rz_Bypass_Check_Kind;
  break;

 case RZ_Read_Table_State::List_End:
  sre_.advance();
  //rts = read_table_state();
  goto rz_Check_Kind;

 case RZ_Read_Table_State::List_Final:
  if(visitor().current_call_entry_is_function_expression())
   qts << ')';
  sre_.advance();
  //rts = read_table_state();
  break;

 case RZ_Read_Table_State::Statement_Final:
  if(!run_state().flags.current_noop)
  {
   if(visitor().current_call_entry_is_function_expression())
    current_embed_branch_->write_function_expression_leave();
    //qts << ')';
   //if(run_state().flags.quasi_statements)
   if(visitor().quasi_statements())
    current_embed_branch_->write_quasi_statement_final();
   else
    current_embed_branch_->write_statement_final();
  }
  run_state().flags.current_noop = false;

  check_reset_current_embed_branch();
    //qts << ';' << '\n';

  sre_.advance();
  //rts = read_table_state();
  break;

 case RZ_Read_Table_State::Statement_End:
  sre_.advance();
  //rts = read_table_state();
  break;

 case RZ_Read_Table_State::Cross_Pre_Entry:
 {
  check_block_end(qts);
  //?prepare_expression_entry(qts);
  sre_.advance();
   //?
  break;
 }
 case RZ_Read_Table_State::Block_End:
 {
  check_block_end(qts);
  sre_.advance();
  break;
 }
 case RZ_Read_Table_State::Block_Rewind:
 {
  if(current_block_parent())
  {
   check_block_end(qts);
   sre_.run_state().set_read_table_state(RZ_Read_Table_State::Block_End);
  }
  sre_.advance();
  break;
 }
 default:
  break;
 }

 padv_state = sre_.post_advance_state();

 switch(padv_state)
 {
 case RZ_Read_Table_Post_Advance_State::Reenter:
  //rts = read_table_state();
  goto read_table_state_loop;
 case RZ_Read_Table_Post_Advance_State::Holds_Token:
   goto rz_Check_Kind;
 case RZ_Read_Table_Post_Advance_State::N_A:
 case RZ_Read_Table_Post_Advance_State::No_Token:
  goto rz_Bypass_Check_Kind;
 case RZ_Read_Table_Post_Advance_State::Deactivate:
  return;
 }

rz_Check_Kind:
// if(rzt.flags.has_Clasp_redirect)
// {
//  qts << rzt.string_value() << ' ';
// }
// else
// {
  switch(kind)
  {
  case Basic_Token_Kinds::NOOP_Token:
   break;
  case Basic_Token_Kinds::Symbol_Token:
   check_statement_mapkey(qts, rzt, sre_token.node());
   if(rzt.flags.is_function_expression_entry || rzt.flags.is_core_function_symbol)
   {
    // //? flags.is_return_statement ??
    if(rzt.string_value() == "return")
    {
     sre_.run_state().flags.override_quasi_statements = true;
    }
    check_assignment_block_entry(qts, rzt);
    check_init_embed_branch(qts, rzt);
    current_embed_branch_->write_function_name(sre_token);
   }
   else if(rzt.flags.is_inserted_tuple_info)
   {
    check_init_tuple_embed_branch(qts, rzt);
    current_embed_branch_->write_function_name(sre_token);
    check_leave_tuple_embed_branch();
   }
   else
    current_embed_branch_->write_symbol_name(sre_token);
   break;
  case Basic_Token_Kinds::Empty_Tuple_Indicator:
   break;
  case Basic_Token_Kinds::String_Token:
    current_embed_branch_->write_string_literal(sre_token);
   break;
  case Basic_Token_Kinds::Function_Def_Redirect:
   // ? cpp_string_value?
   write_function_def_redirect(qts, rzt.cpp_string_value(),
     *visitor().last_graph_tqns_token()->function_def_info());
   break;
  }
// }
rz_Bypass_Check_Kind:

 //rts = read_table_state();
 goto read_table_state_loop;
}

caon_ptr<RZ_Tqns_Code_Block> RE_Generate_Tqns::current_block_parent()
{
 CAON_PTR_DEBUG(RZ_Tqns_Code_Block ,current_block_)
 if(current_block_)
 {
  return current_block_->parent_block();
 }
 return nullptr;
}

void RE_Generate_Tqns::check_block_end(QTextStream& qts)
{
 // //  returns the (old) current block after setting current_block_ to its parent,
  //    if this exists, otherwise nullptr
 CAON_PTR_DEBUG(RZ_Tqns_Code_Block ,current_block_)
 if(caon_ptr<RZ_Tqns_Code_Block> parent = current_block_->parent_block())
 {
  check_if_block_leave(qts);
  check_assignment_block_leave(qts);
  //current_embed_branch_->check_block_end();
  current_embed_branch_->write_line_standalone(" --}");
  current_embed_branch_->write_line_standalone(current_block_->block_end_string());
  CAON_PTR_DEBUG(RZ_Lisp_Graph_Block_Info ,current_block_info_)
  current_block_ = parent;
  reset_current_block_info();
 }
 --current_embed_branch_->current_indentation_depth();
}


void RE_Generate_Tqns::reset_current_block_info()
{
 CAON_PTR_DEBUG(RZ_Tqns_Code_Block ,current_block_)
 current_block_info_ = current_block_->block_info(); //
 CAON_PTR_DEBUG(RZ_Lisp_Graph_Block_Info ,current_block_info_)
 CAON_DEBUG_NOOP
}


void RE_Generate_Tqns::check_leave_tuple_embed_branch()
{
 check_reset_current_embed_branch();
}


void RE_Generate_Tqns::write_lex_tuple_entry(QTextStream& qts)
{
 caon_ptr<RE_Node> current_node = visitor().current_node();
 CAON_PTR_DEBUG(RE_Node ,current_node)

 if(caon_ptr<RE_Tuple_Info> rti = current_node->re_tuple_info())
 {
  CAON_PTR_DEBUG(RE_Tuple_Info ,rti)
  QString h = rti->tqns_out(true);
  qts << h << ' ';
 }
}


void RE_Generate_Tqns::check_init_tuple_embed_branch(QTextStream& qts, RZ_Graph_Run_Token& rzt)
{
 caon_ptr<RE_Node> current_node = visitor().current_node();
 CAON_PTR_DEBUG(RE_Node, current_node)

 if(caon_ptr<RE_Tuple_Info> rti = current_node->re_tuple_info())
 {
  if(caon_ptr<RE_Call_Entry> rce = visitor().current_call_entry_object())
  {
   caon_ptr<RE_Node> rce_node = rce->ref_node();
   CAON_PTR_DEBUG(RE_Node, rce_node)
   rce_node->debug_connections();
   current_node->debug_connections();
   CAON_PTR_DEBUG(RE_Call_Entry, rce)

   //visitor().run_state().flags.has_run_plugin = true;

   if(rce->flags.is_data_branch_entry)
   {
    current_embed_branch_ = new RZ_Tqns_Embed_Branch__Tuple(qts,
     current_embed_branch_,
     current_embed_branch_->current_indentation_depth(),
      *rti, *current_node);
    //sre_.run_state().set_read_table_state(RZ_Read_Table_State::List_Sequence);
    //current_embed_branch_->write_function_name();
   }
  }
 }
}

void RE_Generate_Tqns::check_if_block_leave(QTextStream& qts)
{
 if(current_block_info_) //caon_ptr<RZ_Lisp_Graph_Block_Info> bli = visitor().current_block_info())
 {
  if(current_block_info_->needs_else())
  {
   current_embed_branch_->check_else();
   // // Separate delete function?
    //?delete current_block_info_;
    //?current_block_info_ = nullptr;
  }
  else
  {
   //?
    // check_assignment_block_leave(qts);
   current_block_info_->reset_iterator();
  }
 }
}

void RE_Generate_Tqns::check_statement_mapkey(QTextStream& qts, RZ_Graph_Run_Token& rzt, caon_ptr<RE_Node> node)
{
 if(rzt.flags.has_mapkey)
 {
  QString mapkey_string = visitor().get_mapkey_string(node);
  qts << mapkey_string << " -> ";
 }
}


void RE_Generate_Tqns::check_assignment_block_leave(QTextStream& qts)
{
 if(current_block_)
 {
  CAON_PTR_DEBUG(RZ_Tqns_Code_Block ,current_block_)
  if(caon_ptr<RE_Block_Entry> rbe = current_block_->block_entry())
  {
   CAON_PTR_DEBUG(RE_Block_Entry ,rbe)
   if(rbe->flags.if_block)
   {
    if(rbe->flags.has_else_block)
    {
     return;
    }
   }
  }
 }
 if(current_block_info_)
 {
  CAON_PTR_DEBUG(RZ_Lisp_Graph_Block_Info ,current_block_info_)
  qts << " } in ";
  if(current_block_info_->has_returns_assignments())
  {
   qts << "returns";
  }
 }
}

void RE_Generate_Tqns::check_assignment_block_entry(QTextStream& qts, RZ_Graph_Run_Token& rzt)
{
 if(caon_ptr<RZ_Lisp_Graph_Block_Info> bli = visitor().current_block_info())
 {
  current_block_info_ = bli;
  CAON_PTR_DEBUG(RZ_Lisp_Graph_Block_Info ,current_block_info_)
  CAON_PTR_DEBUG(RZ_Tqns_Code_Block ,current_block_)
  //current_block_->set_block_info(bli);
  QListIterator<caon_ptr<RE_Node>> it(bli->assignment_order());

  int count = 0;

//bli->assignment_order().count();
//  qts << " Let ";
//  if(count > 1)
//   qts << " ("

  QString let_insertions;
  while(it.hasNext())
  {
   //++count;
   caon_ptr<RE_Node> n = it.next();
   if(caon_ptr<RZ_Lisp_Token> token = n->lisp_token())
   {
    if(count > 0)
     let_insertions += ", ";
    QString sym = bli->symbol_string(token->lisp_string_value());
    let_insertions += sym;
    ++count;
   }
  }
  CAON_PTR_DEBUG(RZ_Lisp_Graph_Block_Info ,bli)
  caon_ptr<RE_Node> ben = bli->block_entry_node();
  CAON_PTR_DEBUG(RE_Node ,ben)
  int extras = bli->returns_assignments().count();
  if(extras == 1)
  {
   if(count > 0)
    let_insertions += ", ";
   let_insertions += "returns";
   ++count;
  }
  else
  {
   while(extras > 0)
   {
    QString symbol = QString("returns'%1").arg(extras);
    if(count > 0)
     let_insertions += ", ";
    let_insertions += symbol;
    ++count;
    --extras;
   }
  }
  if(count == 0)
   return;

  qts << " let { ";
  if(count > 1)
  {
   qts << '(';
  }
  qts << let_insertions;
  if(count > 1)
  {
   qts << ')';
  }
  qts << " = \n";
 }
// caon_ptr<RE_Node> cn = visitor().current_node();
// CAON_PTR_DEBUG(RE_Node ,cn)
// cn->debug_connections();
// CAON_DEBUG_NOOP
}

void RE_Generate_Tqns::check_init_embed_branch(QTextStream& qts, RZ_Graph_Run_Token& rzt)
{
 Embed_Branch_Junctions j = find_embed_branch_junction(rzt.string_value());
 switch(j)
 {
 case Embed_Branch_Junctions::Class:
  current_embed_branch_ = new RZ_Tqns_Embed_Branch__Class(qts,
   current_embed_branch_,
   current_embed_branch_->current_indentation_depth());
  break;

 case Embed_Branch_Junctions::Leave_Logical_Scope:
  current_embed_branch_ = new RZ_Tqns_Embed_Branch__Self_Closing_Statement("\n}",
   qts, current_embed_branch_, current_embed_branch_->current_indentation_depth());
  break;

 case Embed_Branch_Junctions::Access_Modifier:
  current_embed_branch_ = new RZ_Tqns_Embed_Branch__Access_Modifier(qts,
   current_embed_branch_, current_embed_branch_->current_indentation_depth());
  break;

 case Embed_Branch_Junctions::Matching:
  current_embed_branch_ = new RZ_Tqns_Embed_Branch__Matching(qts,
   current_embed_branch_, current_embed_branch_->current_indentation_depth(), held_signature_);
  break;

 case Embed_Branch_Junctions::Assign_From_Preinit:
 {
  CAON_PTR_DEBUG(RZ_Lisp_Graph_Block_Info ,current_block_info_)
  current_embed_branch_ = new RZ_Tqns_Embed_Branch__Assign_From_Preinit(qts,
   current_embed_branch_, current_embed_branch_->current_indentation_depth(),
   current_block_info_
    //last_assign_from_preinit_embed_branch_
   );
   //? last_assign_from_preinit_embed_branch_ = current_embed_branch_;
  break;
 }
 case Embed_Branch_Junctions::Assign_From_Returns:

  current_embed_branch_->add_assignment("returns");

  current_embed_branch_ = new RZ_Tqns_Embed_Branch__Assign_From_Preinit(qts,
   current_embed_branch_,
   current_embed_branch_->current_indentation_depth(), current_block_info_,
   //last_assign_from_preinit_embed_branch_,
   RZ_Tqns_Embed_Branch__Assign_From_Preinit::Kind::Returns, "returns");
  break;

 case Embed_Branch_Junctions::Assign_From_Init:

  current_embed_branch_ = new RZ_Tqns_Embed_Branch__Assign_From_Preinit(qts,
   current_embed_branch_,
   current_embed_branch_->current_indentation_depth(), current_block_info_,
   //last_assign_from_preinit_embed_branch_,
   RZ_Tqns_Embed_Branch__Assign_From_Preinit::Kind::Init);
  break;

 default: break;
 }
}


void RE_Generate_Tqns::check_reset_current_embed_branch()
{
 // //   Normally the end of a statement means reverting
  //      current_embed_branch_ to its parent
 caon_ptr<RZ_Tqns_Embed_Branch> parent = current_embed_branch_->parent_branch();
 if(parent)
 {
  parent->current_indentation_depth() = current_embed_branch_->current_indentation_depth();
  current_embed_branch_ = parent;
 }
}

















//void RE_Generate_Tqns::write_function_name(QTextStream& qts, const RZ_Graph_Run_Token& rzt)
//{
// qts << get_function_name(rzt);
// qts << '(';
//}

//void RE_Generate_Tqns::write_symbol_name(QTextStream& qts, const RZ_Graph_Run_Token& rzt)
//{
// QString str = rzt.string_value();
// if(rzt.flags.is_infix_operator_entry)
// {
//  held_infix_operator_ = str;
// }
// else
// {
//  qts << str << ' ';
//  check_write_held_infix_operator(qts);
// }
//}

//void RE_Generate_Tqns::write_string_literal(QTextStream& qts, const RZ_Graph_Run_Token& rzt)
//{
// qts << '"' << rzt.string_value() << '"' << ' ';
// check_write_held_infix_operator(qts);
//}

//QString RE_Generate_Tqns::check_hold_infix_operator(const RZ_Graph_Run_Token& rzt,
// QString str)
//{
// if(rzt.flags.is_infix_operator_entry)
// {
//  held_infix_operator_ = str;
//  return QString();
// }
// return str;
//}


//void RE_Generate_Tqns::check_write_held_infix_operator(QTextStream& qts)
//{
// if(!held_infix_operator_.isEmpty())
//  qts << held_infix_operator_ << ' ';
// held_infix_operator_.clear();;
//}


//caon_ptr<RZ_Lisp_Graph_Visitor> RE_Prerun_Normalize::scan()
//{
// caon_ptr<RZ_Lisp_Graph_Visitor> result = new RZ_Lisp_Graph_Visitor(&graph_);
// result->normalize();
// return result;
//}




//#include "kernel/graph/rz-re-graph.h"
//#include "kernel/graph/rz-re-node.h"

//#include "kernel/rz-re-root.h"

//#include "token/rz-re-token.h"

//#include "tuple/rz-re-tuple-info.h"

//#include "rzns.h"

//USING_RZNS(RECore)

//RE_Pre_Normal_Lisp::RE_Pre_Normal_Lisp(caon_ptr<RE_Document> document)
// : RE_Lisp_Output(document)
//{

//}


//void RE_Pre_Normal_Lisp::report_token(QTextStream& qts,
// const RE_Token& token)
//{
// if(token.flags.is_symbol_declaration)
// {
//  qts << "(rz-decl " << token.raw_text() << ")";
// }
// else
//  qts << token.get_lisp_out();
//}

//void RE_Pre_Normal_Lisp::report_tuple_info_entry(QTextStream& qts,
// const RE_Tuple_Info& rti)
//{
// qts << '(' << rti.lisp_out() << ' ';
//}

//void RE_Pre_Normal_Lisp::report_tuple_info_leave(QTextStream& qts,
// const RE_Tuple_Info& rti)
//{
// qts << ')';
//}

////void RE_Pre_Normal_Lisp::output_from_node(QTextStream& qts,
//// const RE_Node& node, int indent)
////{
//// //CAON_PTR_DEBUG(RE_Node ,node)

//// QString padding(indent, ' ');
////// qts << "\n" << padding;

//// if(caon_ptr<RE_Token> token = node.re_token())
//// {
////  qts << get_lisp_out(*token);
//// }

//// if(caon_ptr<RE_Call_Entry> rce = node.re_call_entry())
//// {
////  //  qts << get_lisp_out(*token);
//// }

//// if(caon_ptr<RE_Node> next_node = rq_.Run_Call_Sequence(&node))
//// {
////  qts << ' ';
////  output_from_node(qts, *next_node, indent + 1);
////  //qts << ' ';
//// }

//// if(caon_ptr<RE_Node> next_node = rq_.Run_Call_Entry(&node))
//// {
////  qts << "\n" << padding;
////  qts << '(';
////  output_from_node(qts, *next_node, indent + 1);
////  qts << ')';
////  if(caon_ptr<RE_Node> cross_node = rq_.Run_Cross_Continue(next_node))
////  {
////   output_from_node(qts, *cross_node, indent);
////  }
//// }

//// if(caon_ptr<RE_Node> next_node = rq_.Run_Data_Entry(&node))
//// {
////  if(caon_ptr<RE_Tuple_Info> rti = next_node->re_tuple_info())
////  {
////   qts << "\n" << padding << ' ';
////   report_tuple_info_entry(qts, *rti);
////   if(next_node = rq_.Run_Data_Entry(next_node))
////    output_from_node(qts, *next_node, indent + 1);
////   report_tuple_info_leave(qts, *rti);
////  }
////  if(caon_ptr<RE_Node> cross_node = rq_.Run_Cross_Continue(next_node))
////  {
////   output_from_node(qts, *cross_node, indent);
////  }
//// }
////}

#endif //HIDE


#ifdef HIDE
 case RZ_Read_Table_State::Cpp_Redirect_Leave_Block_Pre_Entry:
  sre_.advance();
  //rts = read_table_state();
  goto rz_Bypass_Check_Kind;
  break;


 case RZ_Read_Table_State::Root:
  sre_.advance();
  //rts = read_table_state();
  break;

 case RZ_Read_Table_State::Cpp_File_Entry:
  current_embed_branch_->ccg_add_file_entry();
   //?ccg_.add_file_entry();
  //write_file_entry(qts);
  current_block_ = new RZ_Lisp_Code_Block(nullptr);
  current_block_info_ = current_block_->block_info();
  sre_.advance();
  //rts = read_table_state();
  break;

 case RZ_Read_Table_State::Block_Statement_Entry:
  //ccg_.prepare_statement_entry(); //qts);
  sre_.advance();
  //rts = read_table_state();
  break;

 case RZ_Read_Table_State::Block_Statement_List_Pre_Entry:
  current_embed_branch_->ccg_prepare_statement_entry();
   //?ccg_.prepare_statement_entry();
  sre_.advance();
  //rts = read_table_state();
  break;

 case RZ_Read_Table_State::Cross_Block_Pre_Entry:
  current_embed_branch_->ccg_nested_block_leave();
   //?ccg_.nested_block_leave();
  check_block_end(qts);
  //?ccg_.prepare_statement_entry();
  sre_.advance();
  //rts = read_table_state();
  break;

 case RZ_Read_Table_State::Cross_Block_Statement_Pre_Entry:
  check_noop_embed_branch(qts);
  //?ccg_.prepare_statement_entry();
  sre_.advance();
  //rts = read_table_state();
  break;

 case RZ_Read_Table_State::Statement_Pre_Entry:
  //ccg_.prepare_statement_entry(); //qts);
  sre_.advance();
  //rts = read_table_state();
  break;

 case RZ_Read_Table_State::List_Pre_Entry:
  current_embed_branch_->ccg_prepare_expression_entry();
   //?ccg_.prepare_expression_entry(); //(qts);
  sre_.advance();
  //rts = read_table_state();
  break;


// case RZ_Read_Table_State::Statement_Prepare_Entry:

 case RZ_Read_Table_State::Statement_Entry_Indent:
  //?current_embed_branch_->write_line_indentation();
  sre_.advance();
  break;
  //?goto get_kind;
  //?  Fallthrough...

 case RZ_Read_Table_State::Statement_Entry:
 {
  CAON_PTR_DEBUG(RZ_Lisp_Embed_Branch ,current_embed_branch_)
  current_embed_branch_->ccg_prepare_statement_entry();

  //ccg_.prepare_statement_entry();
   //?current_embed_branch_->write_line_indentation();

 }
  //?current_embed_branch_->write_line_indentation();
  //qts << QString(current_indentation_depth_, ' ');
  //  Fallthrough...

 case RZ_Read_Table_State::Statement_Prepare_Entry:
  check_noop_embed_branch(qts);
  //  Fallthrough...
  //? ccg_.prepare_statement_entry();

 case RZ_Read_Table_State::List_Entry:
    // //  The token here (List_Entry) should hold a callable value;
    //     opportunity to intercept

 case RZ_Read_Table_State::List_Embed_Sequence:
 case RZ_Read_Table_State::List_Sequence:
 get_kind:
  {
   kind = get_current_token(sre_token, current_source_element);
   QString test = sre_token.text_value();
   QString ntest = sre_token.node_label();
   sre_.advance();
   //rts = read_table_state();
   break;
  }

 case RZ_Read_Table_State::Cpp_Block_Entry:
  sre_.advance();
  //rts = read_table_state();
  break;

 case RZ_Read_Table_State::Block_Pre_Entry_As_Sequence:
 {
  RZ_Lisp_Code_Block_Kinds block_kind = RZ_Lisp_Code_Block_Kinds::N_A;
  if(caon_ptr<RE_Block_Entry> rbe = visitor().current_node_as_block_entry())
  {
   CAON_PTR_DEBUG(RE_Block_Entry ,rbe)
   if(rbe->flags.if_block)
   {
    block_kind = RZ_Lisp_Code_Block_Kinds::If_Block;
//?    qts << " then \n";
    visitor().valuer()->check_assignments();
   }
   else if(rbe->flags.else_block)
   {
    block_kind = RZ_Lisp_Code_Block_Kinds::Else_Block;
//?    qts << " else \n";
    visitor().valuer()->check_assignments();
   }

   if(caon_ptr<RZ_Lisp_Graph_Block_Info> rbi = current_block_->block_info())
   {
    CAON_PTR_DEBUG(RZ_Lisp_Graph_Block_Info ,rbi)
    CAON_PTR_DEBUG(RZ_Lisp_Code_Block ,current_block_)
    //  this should really be in valuer ...
    rbi->set_child_block_info(current_block_info_);
   }

   current_block_ = new RZ_Lisp_Code_Block(current_block_, rbe);
   current_block_->set_block_info(current_block_info_);
   CAON_PTR_DEBUG(RZ_Lisp_Graph_Block_Info ,current_block_info_)
   CAON_PTR_DEBUG(RZ_Lisp_Code_Block ,current_block_)

   //? current_embed_branch_->write_line_standalone(" --{.");
  }
  current_embed_branch_->ccg_nested_block_pre_entry(block_kind);
   //? ccg_.nested_block_pre_entry(block_kind);
  sre_.advance();
  //rts = read_table_state();
  goto rz_Bypass_Check_Kind;
  break;
 }
 case RZ_Read_Table_State::Block_Pre_Entry:
 {
  RZ_Lisp_Code_Block_Kinds block_kind = RZ_Lisp_Code_Block_Kinds::N_A;
  if(caon_ptr<RE_Block_Entry> rbe = visitor().current_node_as_block_entry())
  {
   // duplicated! ...
   if(caon_ptr<RZ_Lisp_Graph_Block_Info> rbi = current_block_->block_info())
   {
    CAON_PTR_DEBUG(RZ_Lisp_Graph_Block_Info ,rbi)
    CAON_PTR_DEBUG(RZ_Lisp_Code_Block ,current_block_)
    //  this should really be in valuer ...
    rbi->set_child_block_info(current_block_info_);
   }

   CAON_PTR_DEBUG(RE_Block_Entry ,rbe)
   current_block_ = new RZ_Lisp_Code_Block(current_block_, rbe);

   current_block_->set_block_info(current_block_info_);
   CAON_PTR_DEBUG(RZ_Lisp_Graph_Block_Info ,current_block_info_)
   CAON_PTR_DEBUG(RZ_Lisp_Code_Block ,current_block_)
   check_block_entry(qts);
   if(rbe->flags.if_block)
   {
    block_kind = RZ_Lisp_Code_Block_Kinds::If_Block;
   }
   else if(rbe->flags.else_block)
   {
    block_kind = RZ_Lisp_Code_Block_Kinds::Else_Block;
   }
   else if(rbe->flags.elsif_block)
   {
    block_kind = RZ_Lisp_Code_Block_Kinds::Elsif_Block;
   }
   else if(rbe->flags.function_definition)
   {
    block_kind = RZ_Lisp_Code_Block_Kinds::Fundef_Block;
   }
  }
  //qts << '\n' << QString(current_indentation_depth_, ' ') << "{\n";
  //++current_embed_branch_->current_indentation_depth();
  //sre_.advance();
  //rts = read_table_state();
  //goto rz_Bypass_Check_Kind;
  //break;
  current_embed_branch_->ccg_block_pre_entry(block_kind);
   //?ccg_.block_pre_entry(block_kind);
  //?current_block_ = new RZ_Lisp_Code_Block(current_block_);
  //?current_embed_branch_->write_line_standalone("{");
   //?++current_embed_branch_->current_indentation_depth();
  sre_.advance();
  //rts = read_table_state();
  goto rz_Bypass_Check_Kind;
  break;
 }
 case RZ_Read_Table_State::Cpp_Redirect_Leave:
  sre_.advance();
  //rts = read_table_state();
  goto rz_Check_Kind;
  break;

 case RZ_Read_Table_State::Cpp_Redirect_Final:
  sre_.advance();
  //rts = read_table_state();
  goto rz_Bypass_Check_Kind;
  break;

 case RZ_Read_Table_State::List_End:
  sre_.advance();
  //rts = read_table_state();
  goto rz_Check_Kind;

 case RZ_Read_Table_State::List_Final:
  if(visitor().current_call_entry_is_function_expression())
   current_embed_branch_->ccg_prepare_expression_leave();
   //?ccg_.prepare_expression_leave();
  //   qts << ')';
  sre_.advance();
  //rts = read_table_state();
  break;

 case RZ_Read_Table_State::Statement_Final:
  //?  if(visitor().current_call_entry_is_function_expression())
  //?   current_embed_branch_->write_function_expression_leave();
  //?  current_embed_branch_->write_statement_final();
  check_reset_current_embed_branch();
    //qts << ';' << '\n';
  current_embed_branch_->ccg_end_statement();

  //?ccg_.end_statement();
  sre_.advance();
  //rts = read_table_state();
  break;

 case RZ_Read_Table_State::Statement_End:
  sre_.advance();
  //rts = read_table_state();
  break;

 case RZ_Read_Table_State::Block_End:
 {
  current_embed_branch_->ccg_nested_block_leave();
   //?ccg_.nested_block_leave();
  check_block_end(qts);
  sre_.advance();
  break;
 }
 case RZ_Read_Table_State::Block_Rewind:
 {
  if(current_parent_block_)
  {
   current_block_ = current_parent_block_;
   current_parent_block_ = nullptr;
   caon_ptr<RE_Call_Entry> rce = visitor().current_call_entry_object();
   CAON_PTR_DEBUG(RE_Call_Entry ,rce)
   run_state().set_read_table_state(RZ_Read_Table_State::Block_Rewind_Reset);

   CAON_DEBUG_NOOP
   //caon_ptr<RE_Node>
  }
  //? current_parent_block_
  //  if(current_block_parent())
  //  {
  //   check_block_end(qts);
  //   //current_block_ = current_parent_block_;
  //   sre_.run_state().set_read_table_state(RZ_Read_Table_State::Block_End);
  //  }
  sre_.advance();
  break;
 }
#endif
