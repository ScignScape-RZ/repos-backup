
#include "rz-ngml-folder.h"

#include "rz-ngml-document.h"

#include "output/rz-ngml-output-html.h"
#include "output/rz-ngml-output-khif.h"
#include "output/rz-ngml-output-latex.h"
#include "output/rz-ngml-output-event-based-html.h"


#include <QFile>
#include <QFileInfo>

#include <QDir>

#include <QDebug>

#include "ctqns.h"
USING_CTQNS(RZ)


NGML_Folder::NGML_Folder(QString local_path)
 : local_path_(local_path)
{

}


void NGML_Folder::read_output_path(QString path)
{
 QFileInfo qfi(path);
 QFile file(path);
 if(file.open(QFile::ReadOnly | QIODevice::Text))
 {
  output_path_ = file.readAll().trimmed();
  local_path_ = qfi.absolutePath();
  input_path_ = path;
 }
}


void NGML_Folder::convert_all_files(QString output_path)
{
 QDir dir(local_path_);
 dir.setFilter(QDir::Files | QDir::Hidden | QDir::NoSymLinks);
 dir.setSorting(QDir::Size | QDir::Reversed);

 QFileInfoList qfil = dir.entryInfoList();

 QListIterator<QFileInfo> it(qfil);

 QStringList qsl;
 QString cabinet;

 while(it.hasNext())
 {
  QFileInfo qfi = it.next();
  if(qfi.suffix() == "ngm")
  {
   qDebug() << qfi.absoluteFilePath();
   if(qfi.baseName() == "cabinet")
   {
    cabinet = qfi.absoluteFilePath();
   }
   else
   {
    qsl << qfi.absoluteFilePath();
   }
  }
 }

 if(!cabinet.isEmpty())
 {
  qsl << cabinet;
 }

 QStringListIterator slit(qsl);
 while(slit.hasNext())
 {
  QString path = slit.next();
  NGML_Document ngd(&annotations_, &user_highlights_);
  ngd.load_file(path);
  ngd.output_ngml(output_path + "/raws");
  NGML_Output_Event_Based_Html ngo(&ngd);
//   NGML_Output_Html ngo(&ngd);
//  ngo.set_path_alternative();
  ngo.output_with_extension_htm(output_path);
  NGML_Output_Khif kf(&ngd);
  kf.output_with_extension_kf(output_path + "/raws");

  QFileInfo fi(path);
  QString n = fi.baseName().toUpper();

  QString latex;
  QTextStream qtls(&latex);
  NGML_Output_Latex ngol(&ngd);
  ngol.generate(qtls);

  n.replace("1", "One");
  n.replace("2", "Two");
  n.replace("3", "Three");
  n.replace("4", "Four");
  n.replace("5", "Five");
  n.replace("6", "Six");
  n.replace("7", "Seven");
  n.replace("8", "Eight");
  n.replace("9", "Nine");
  n.replace("0", "Zero");

  n.replace(QRegExp("\\W"), "");

  latex_code_ += "\n\n\\newcommand{\\rzFileContents" +
    n + "}{\\rzNgmlInputFile{" + path + "}\n\n\\begin{rzFileEnv"
    + n +
    "}"
    + latex +
    "\n\\end{rzFileEnv" + n + "}\n\n\\rzEndNgmlInputFile{" + path + "}}\n\n";
 }
// latex_code_.replace("#{}","\\rzSemHighlight{");
// latex_code_.replace("\\rzTile{}}#","}");

 latex_code_.replace("#{","\\rzSemHighlight{");
 latex_code_.replace("}#","}");
// QRegExp repl("([^\\\\])#");
// latex_code_.replace(repl, repl.cap(1) + "#");

 latex_code_.replace(QRegExp("([^\\\\])(?=#)"), "\\1\\");
 latex_code_.replace("LaTeX","{\\LaTeX}");
 latex_code_.replace("&amp;", "{\\rzAMP}");
 latex_code_.replace("&xi;", "{\\rzXI}");
 latex_code_.replace("&chi;", "{\\rzCHI}");
 latex_code_.replace("&ouml;", "{\\rzOUML}");
 latex_code_.replace("&bull;", "{\\rzBULLET}");
 latex_code_.replace("&atilde;", "{\\rzATILDE}");
 latex_code_.replace("&auml;", "{\\rzAUML}");
 latex_code_.replace("<br>", "{\\rzNewLine}");
 latex_path_ = input_path_ + ".tex";
 QFile outfile(latex_path_);
 if(outfile.open(QIODevice::WriteOnly | QIODevice::Text))
 {
  QTextStream out(&outfile);
  out << "\n\\documentclass{article}\n\\input{C:/rz/ngml/latex/commands.tex}\n"
      << latex_code_ << "\n\\begin{document}\n\\input{" + input_path_ + ".rzdoclist.tex}\n\\end{document}\n";
 }
}

void NGML_Folder::convert_all_files()
{
 convert_all_files(output_path_);
}

void NGML_Folder::display_user_highlights()
{
 QFile file(input_path_ + ".usrh.txt");
 if(file.open(QFile::WriteOnly | QIODevice::Text))
 {
  QTextStream qts(&file);
//  QMap<QString, int>& uh = user_highlights_;
  QMapIterator<QString, int> it(user_highlights_);
  while(it.hasNext())
  {
   it.next();
   QString text = it.key();
   int num = it.value();
   qts << text << ' ' << num <<"\n";
  }
  file.close();
 }

}
