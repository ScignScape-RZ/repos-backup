
#ifndef RZ_RE_FRAME__H
#define RZ_RE_FRAME__H

#include "rz-re-frame.h"

#include "relae-graph/relae-node-ptr.h"

#include "kernel/rz-re-dominion.h"

#include "rzns.h"

RZNS_(RECore)


class RE_Frame : public node_frame<RE_Dominion>
{
 RE_Frame();
 // RE_Dominion::Connectors N_A;
 public:

 static RE_Frame& instance();

};

_RZNS(RECore)

#endif
