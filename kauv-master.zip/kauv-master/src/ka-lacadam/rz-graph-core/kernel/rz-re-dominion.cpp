

#include "rz-re-dominion.h"

#include "graph/rz-re-node.h"

#define DOMINION_NODE_NAMESPACE RZ::RECore
#define DOMINION_TYPE DOMINION_RETRIEVE_TYPE_CODE
#include "dominion/types.h"
#undef DOMINION_TYPE
#undef DOMINION_NODE_NAMESPACE

