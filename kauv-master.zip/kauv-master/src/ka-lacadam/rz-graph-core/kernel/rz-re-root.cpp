
#include "rz-re-root.h"

#include "kernel/document/rz-re-document.h"

#include "rzns.h"

USING_RZNS(RECore)


RE_Root::RE_Root(RE_Document* document)
  : document_(document)
{

}

QString RE_Root::document_path()
{
 return document_->local_path();
}
