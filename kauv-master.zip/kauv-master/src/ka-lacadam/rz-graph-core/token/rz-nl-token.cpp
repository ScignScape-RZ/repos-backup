
#include "rz-nl-token.h"

//#include "rz-nl/rz-nl-lexicon/rz-nl-lexentry.h"

#include <QRegularExpression>

#include "rzns.h"

USING_RZNS(RECore)

NL_Token::NL_Token(QString raw_text, int line_number)
 :  //?Flags(0),
   lisp_token_(nullptr), lexentry_(nullptr),
   raw_text_(raw_text), line_number_(line_number)
{
}

//QString NL_Token::pos_as_keyword()
//{
// return QString(":%1").arg(lexentry_->);
//}

//QString NL_Token::quote_raw_text()
//{
// return QString("'%1").arg(raw_text_);
//}
