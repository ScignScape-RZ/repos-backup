
#ifndef NL_TOKEN__H
#define NL_TOKEN__H

#include "accessors.h"
#include "flags.h"


#include <QString>

#include <functional>

#include "rz-graph-token/token/rz-lisp-token.h"

#include "relae-graph/relae-caon-ptr.h"

#include "rzns.h"

USING_RZNS(GBuild)


RZNS_CLASS_DECLARE(NL ,NL_Lexentry)
USING_RZNS(NL)


//RZNS_(RECore)

RZNS_(RECore)


class NL_Token
{

 //public:

// flags_(1)
// _flags

 QString raw_text_;
 int line_number_;

 caon_ptr<RZ_Lisp_Token> lisp_token_;

 caon_ptr<NL_Lexentry> lexentry_;


public:

 ACCESSORS(QString ,raw_text)
 ACCESSORS(int ,line_number)
 ACCESSORS(caon_ptr<RZ_Lisp_Token> ,lisp_token)
 ACCESSORS(caon_ptr<NL_Lexentry> ,lexentry)

 //ACCESSORS(RE_Code_Representation::Special_Token ,special_token)


 NL_Token(QString raw_text, int line_number = 0);

// QString pos_as_keyword();
// QString quote_raw_text();

};

_RZNS(RECore)

#endif
