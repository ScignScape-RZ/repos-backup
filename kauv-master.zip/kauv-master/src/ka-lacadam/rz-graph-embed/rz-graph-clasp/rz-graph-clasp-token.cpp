
#include "rz-graph-clasp-token.h"

#include <QStringList>


USING_RZNS(GEmbed)

RZ_Graph_Clasp_Token::RZ_Graph_Clasp_Token(QString raw_text, Basic_Token_Kinds kind)
 : RZ_Graph_Embed_Token(raw_text, kind), source_element_(nullptr)
{

}


