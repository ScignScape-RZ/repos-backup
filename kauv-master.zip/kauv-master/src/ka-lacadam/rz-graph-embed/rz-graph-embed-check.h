#ifndef RUN__RZ_GRAPH_EMBED_CHECK__H
#define RUN__RZ_GRAPH_EMBED_CHECK__H


#include <QMap>
#include <QString>

#include "rzns.h"


RZNS_(GEmbed)

class RZ_Graph_Embed_Check
{

public:


};

_RZNS(GEmbed)


#endif
