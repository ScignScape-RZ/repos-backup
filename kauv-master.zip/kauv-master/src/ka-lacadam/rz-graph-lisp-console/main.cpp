
//?
//#include "rz-qclasp-bridge/rz-qclasp-bridge.h"
//#include "rz-qclasp-eval/rz-qclasp-eval.h"

//?#include "rz-clasp-generator/rz-qclasp-generator.h"

#include "rz-code-generators/rz-kauvir-output.h"

#include "rz-graph-visit/rz-lisp-graph-visitor-dynamo.h"


#include <QtEndian>

#include <QtGlobal>
#include <QtCore>
//#include <qtendian.h>

#include <QDebug>

#include "rzns.h"

#include "rz-graph-core/kernel/document/rz-re-document.h"
#include "rz-graph-core/output/rz-re-pre-normal-lisp.h"

#include "rz-graph-code/prerun/rz-re-prerun-tokens.h"
#include "rz-graph-code/prerun/rz-re-prerun-normalize.h"
#include "rz-graph-code/prerun/rz-re-prerun-anticipate.h"

#include "rz-graph-visit/rz-lisp-graph-visitor.h"
#include "rz-code-generators/rz-dynamo-output.h"

//?#include "relae-graph/relae-node-ptr.h"

#include "sexp/parser.hpp"
#include "lisp/writer.hpp"

#include "kauvir-lisp-embed/kauvir-lisp-embed-environment.h"
#include "kauvir-lisp-embed/kauvir-lisp-eval.h"

//?#include "kauvir-runtime/kauvir-runtime.h"

#include "kauvir-gui-library/kauvir-test-dialog.h"
#include "kauvir-gui-library/kauvir-parse-dialog.h"
#include "kauvir-gui-library/kauvir-dynamic-dialog.h"

#include "kans.h"

#include "kauvir-type-system/kauvir-universal-class.h"


#include "/ext_root/openshift-oc3/mmui-caf/site-manager/mmui-site-manager-bridge/mmui-site-manager-bridge.h"

#include <functional>
#include <QDebug>

USING_KANS(Kauvir)

//?#include <iostream>

//?//#include "kauvir-gui-library/paraviews/kauvir-image-view-dialog.h"
//?//#include "kauvir-gui-library/paraviews/kauvir-wsi-image-view-dialog.h"

//Q_DECLARE_METATYPE(QPushButton)
//?Q_DECLARE_METATYPE(QPushButton*)




USING_RZNS(RECore)

void compile_rz(QString file_name)
{
 QString result;
//? RZ_QClasp_Generator::compile_rz(file, result);


 RE_Document* doc = new RE_Document(file_name);
 doc->parse();

 doc->report_graph(file_name + ".txt");

 RE_Pre_Normal_Lisp prenorm(doc);
 prenorm.output("..prenorm.txt");

 RE_Prerun_Tokens tokens(doc); //, &RZ_Lisp_Token::init_lisp_token);
 tokens.output("..prenorm2.txt");


 RE_Prerun_Normalize normalize(*doc->graph());


 caon_ptr<RZ_Lisp_Graph_Visitor> visitor = normalize.scan();

 visitor->set_document_directory(doc->local_directory());

 RZ_Lisp_Graph_Visitor_Dynamo visitor_dynamo(*visitor);
 RZ_Dynamo_Output rdo(visitor_dynamo);

 visitor->set_dynamo_output(&rdo);

 QString handlers = doc->rz_path_handlers();
 if(!handlers.isEmpty())
 {
  visitor->prepare_rz_path_handlers_output(handlers);
 }


 doc->report_graph(file_name + ".re1.txt");

 RE_Pre_Normal_Lisp prenorm1(doc);
 prenorm1.output("..prenorm1.txt");


//? RZ_Clasp_Code_Generator& ccg = *visitor->rz_clasp_code_generator();


//? RE_Generate_Clasp gen(*visitor);


 RE_Prerun_Anticipate anticipate(*visitor);

//? RZ_File_List_Type extra_files;
//? gen.init_project(extra_files);

 anticipate.scan();

 QString output;
 QTextStream qts(&output);


 rdo.write(qts);

//?gen.write(qts);

//? QString output1;


//? QTextStream qts1(&output1);


//? ccg.write(qts1);

 QString result_file = doc->local_path() + ".cl";
 QFile outfile(result_file);


 if(outfile.open(QIODevice::WriteOnly | QIODevice::Text))
 {
  QTextStream out(&outfile);
  out << output;
  outfile.close();
 }
 result = output;

 result.prepend("\n(:|RZ_GENERATED| ");
 result.append(')');

 //sexpresso::Sexp sxp = sexpresso::parse(result.toStdString());

 //?

//?#ifdef HIDE
 sexp::Value value = sexp::Parser::from_string(result.toStdString());

 //? QString clean_out;

 // lisp::Writer writer(clean_out);


 QString clean_result_file = doc->local_path() + ".lisp";
 QFile clean_outfile(clean_result_file);

 if(clean_outfile.open(QIODevice::WriteOnly | QIODevice::Text))
 {
  QTextStream out(&clean_outfile);

  QString vstr = QString::fromStdString(value.str_with_indent(0));
  QString start = "\n(:|RZ_GENERATED| ";
  if(vstr.startsWith(start))
  {
   vstr = vstr.mid(start.length());
  }
  if(vstr.endsWith(')'))
  {
   vstr.chop(1);
  }

  out << vstr;
  clean_outfile.close();
 }
//?#endif // HIDE
}

#ifdef HIDE
void run_lisp(QString path, int argc, char *argv[])
{
 qRegisterMetaType<QPushButton*>();

 qRegisterMetaType<QVBoxLayout*>();
 qRegisterMetaType<QHBoxLayout*>();

 qRegisterMetaType<MMUI_Site_Manager_Bridge>();
 qRegisterMetaType<MMUI_Site_Manager_Bridge*>();

 Kauvir_Lisp_Embed_Environment env(argc, argv);
 Kauvir_Lisp_Eval kle(&env);

 Kauvir_Runtime kr(*kle.get_type_system(), *kle.get_type_object_builder());

 kle.set_kauvir_runtime(&kr);

//? Kauvir_Channel_Group g1;

 kle.prepare_callbacks();
// env.set_quicklisp_location("/home/nlevisrael/quicklisp/setup.lisp");
// kle.eval_quicklisp_setup();

 kle.eval_script_file(path);

}
#endif

int main(int argc, char *argv[])
{
 QApplication qapp(argc, argv);

 compile_rz("/ext_root/kauv/qry-cmd/rz/t1.rz");
 //compile_rz("/ext_root/kauv/lisp-cmd/rz-cmd/t1.rz");
 return 0;
}

#ifdef HIDE


//?
//
//?
//?
 //

 //compile_rz("/ext_root/kauv/rz/edit/edit1.rz");
//?
 //?
//? run_lisp("/ext_root/kauv/rz/edit/edit1.rz.lisp", argc, argv);

//? compile_rz("/ext_root/kauv/rz/t3.rz");
//? run_lisp("/ext_root/kauv/rz/t3.rz.lisp", argc, argv);


void run_clasp(QString file)
{
 RZ_QClasp_Eval* clasp_eval = new RZ_QClasp_Eval;

 char argc_ = 3;

 char* argv_[argc_];
 //?QDir::setCurrent(
 QString current_dir =  "/run/media/nlevisrael/DualBootShared/CLASPQ/branches/new-testing/clasp/build/boehmdc";

 qDebug() << current_dir;

 argv_[0] = "cclasp-boehmdc";
// ////
// argv_[1] = "-l";
// argv_[2] = "/home/nlevisrael/rz-dev/cl/exit.lisp";

 argv_[1] = "-I";
 argv_[2] = "-n";

 clasp_eval->start_clasp_from_dir(argc_, argv_, current_dir);
 RZ_QClasp_Bridge* clasp_bridge = new RZ_QClasp_Bridge(*clasp_eval);

 clasp_bridge->eval_file(file);

}

int main(int argc, char *argv[])
{
//? QApplication qapp(argc, argv);

  QCoreApplication qapp(argc, argv);
  qRegisterMetaType<PTN_Site_Manager_Bridge>();
  qRegisterMetaType<PTN_Site_Manager_Bridge*>();

// qRegisterMetaType<PTN_Recommendation_Clasp_Interface>();
// qRegisterMetaType<PTN_Recommendation_Clasp_Interface*>();

 std::map<std::string, int> dummy_map;
 dummy_map["x"] = 1;
 dummy_map["y"] = 2;

 compile_rz("/home/nlevisrael/scignscape-git/scripts/rz/t1.rz");
  //? run_clasp("/home/nlevisrael/scignscape-git/scripts/rz/t1.rz.cl");

}

// qRegisterMetaType<PTN_Recommendation_Clasp_Interface>();
// qRegisterMetaType<PTN_Recommendation_Clasp_Interface*>();
// qRegisterMetaType<PTN_Recommendation_Clasp_Interface>();
// qRegisterMetaType<PTN_Recommendation_Clasp_Interface*>();



int main1(int argc, char *argv[])
{
 QCoreApplication app(argc, argv);

 PTN_Site_Manager_Bridge psmb;

 psmb.set_web_root_folder("/home/nlevisrael/openshift/pvc/pvc-docker-image/web/pvc/public");

 //psmb.set_current_file_relative("index.html");

//
//? psmb.set_current_file_relative("seo-shared/sitemap.xml");
//?
//? psmb.set_host("pvc-dev.arukascloud.io");
//?
//? psmb.set_scheme("https");

// psmb.set_web_root_folder("/home/nlevisrael/openshift/ptn-test");
// psmb.set_current_file_relative("test-update/test-update.html");
// psmb.set_host("localhost");
// psmb.set_port(17260);

//? QString result = psmb.send_update();

//? qDebug() << "\nResult: " << result;
 return 0;
}
#endif

