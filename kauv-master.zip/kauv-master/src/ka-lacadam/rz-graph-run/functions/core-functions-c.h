
//?RZ_LISP_GRAPH_FUNCTION_DECLARE(preen, Preen, 1, Preempt)

//RZ_LISP_GRAPH_FUNCTION_DECLARE(pr, Print_Line)
//RZ_LISP_GRAPH_FUNCTION_DECLARE(prs, Print_String)

//?RZ_LISP_GRAPH_FUNCTION_DECLARE(---, Enter_Logical_Scope_3, 1, Preempt)

RZ_LISP_GRAPH_FUNCTION_DECLARE(----, Enter_Logical_Scope_4, 1, Preempt)
RZ_LISP_GRAPH_FUNCTION_DECLARE(if, If, 1, Preempt)
RZ_LISP_GRAPH_FUNCTION_DECLARE(elsif, Elsif, 1, Preempt)

RZ_LISP_GRAPH_FUNCTION_DECLARE(project-info, Project_Info, 1, Preempt)
RZ_LISP_GRAPH_FUNCTION_DECLARE(do, Do, 1, Preempt)
RZ_LISP_GRAPH_FUNCTION_DECLARE(scan, Scan, 1, Preempt)


//?RZ_LISP_GRAPH_FUNCTION_DECLARE(-----, Enter_Logical_Scope_5, 1, Preempt)
//?RZ_LISP_GRAPH_FUNCTION_DECLARE(------, Enter_Logical_Scope_6, 1, Preempt)

//RZ_LISP_GRAPH_FUNCTION_DECLARE(-----, Enter_Logical_Scope_5)
//RZ_LISP_GRAPH_FUNCTION_DECLARE(------, Enter_Logical_Scope_6)
//RZ_LISP_GRAPH_FUNCTION_DECLARE(project, Set_Project)
//RZ_LISP_GRAPH_FUNCTION_DECLARE(db-save, DB_Save)
