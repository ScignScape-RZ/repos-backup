
//?RZ_LISP_GRAPH_FUNCTION_DECLARE(gen, Gen, 0, Preempt)

RZ_LISP_GRAPH_FUNCTION_DECLARE(;;;;, Leave_Logical_Scope_4, 0, Preempt)

//?RZ_LISP_GRAPH_FUNCTION_DECLARE(-#, Haskell_Setting, 0, Preempt)


//RZ_LISP_GRAPH_FUNCTION_DECLARE(import, Haskell_Import, 0, Preempt)

//?RZ_LISP_GRAPH_FUNCTION_DECLARE(;;;;;, Leave_Logical_Scope_5, 0, Preempt)


//?RZ_LISP_GRAPH_FUNCTION_DECLARE(gclos, Generate_Clos, 0, Preempt)

//?RZ_LISP_GRAPH_FUNCTION_DECLARE(->, Function_Entry, 0, Preempt)

