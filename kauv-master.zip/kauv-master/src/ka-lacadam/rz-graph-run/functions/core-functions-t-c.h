
RZ_LISP_GRAPH_FUNCTION_DECLARE(class, Class, 1, Preempt)

RZ_LISP_GRAPH_FUNCTION_DECLARE(namespace, Namespace, 1, Preempt)

//?RZ_LISP_GRAPH_FUNCTION_DECLARE(resource, Resource, 1, Preempt)

RZ_LISP_GRAPH_FUNCTION_DECLARE(package, Package, 1, Preempt)

//RZ_LISP_GRAPH_FUNCTION_DECLARE(task, Task)
