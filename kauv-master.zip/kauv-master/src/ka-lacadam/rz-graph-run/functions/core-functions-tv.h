
//CTQ_CORE_FUNCTION_DECLARE(my, My)
//CTQ_CORE_FUNCTION_DECLARE(ty, Ty)


//??
RZ_LISP_GRAPH_FUNCTION_DECLARE(returns, Set_Returns_To_Equal, 1, Preempt)
