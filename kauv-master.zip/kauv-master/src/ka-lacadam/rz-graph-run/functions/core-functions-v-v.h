
RZ_LISP_GRAPH_FUNCTION_DECLARE(=, Set_Equal, 2, Preempt)

RZ_LISP_GRAPH_FUNCTION_DECLARE(==, Set_Equal_Via_Type, 2, Preempt)

//?RZ_LISP_GRAPH_FUNCTION_DECLARE(===, Set_Preinit_To_Equal, 2, Preempt)


RZ_LISP_GRAPH_FUNCTION_DECLARE(:::, Assign_To_Type, 2, Preempt)

RZ_LISP_GRAPH_FUNCTION_DECLARE(<|, Assign_To_Type_No_Re_Init, 2, Preempt)

RZ_LISP_GRAPH_FUNCTION_DECLARE(<<|, Set_Preinit_Equal_Formula, 2, Preempt)


RZ_LISP_GRAPH_FUNCTION_DECLARE(\\=, Set_Preinit_Equal, 2, Preempt)

RZ_LISP_GRAPH_FUNCTION_DECLARE(\\==, Set_Preinit_Equal_To_Type, 2, Preempt)


RZ_LISP_GRAPH_FUNCTION_DECLARE(=>>, Assign_To_Type_Overloadable, 2, Preempt)

RZ_LISP_GRAPH_FUNCTION_DECLARE(\\=>>, Preinit_Assign_To_Type_Overloadable, 2, Preempt)

  //RZ_LISP_GRAPH_FUNCTION_DECLARE(?=, Set_If_False),
