
//RZ_LISP_GRAPH_FUNCTION_DECLARE(within, Within, 1, Valuer_N_S)

//RZ_LISP_GRAPH_FUNCTION_DECLARE(assume, Assume, 1, Valuer_N_S)

//?//
//RZ_LISP_GRAPH_FUNCTION_DECLARE(call-rz, Call_RZ, 1, Valuer_N_S)

//RZ_LISP_GRAPH_FUNCTION_DECLARE(lisp_, Enter_Paste_Lisp, 1, Valuer_N_S)
//?//
