//?//
//RZ_LISP_GRAPH_FUNCTION_DECLARE(upload-resource, Upload_Resource, 0, Valuer_N)
//?//

//RZ_LISP_GRAPH_FUNCTION_DECLARE(within, Within, 0, Valuer)

//RZ_LISP_GRAPH_FUNCTION_DECLARE(assume, Assume, 0, Valuer)

 //? RZ_LISP_GRAPH_FUNCTION_DECLARE(pr, print, 0, Valuer_RN)



//?RZ_LISP_GRAPH_FUNCTION_DECLARE(nglp-analyze, NGLP_Analyze, 0, Valuer_RN)

RZ_LISP_GRAPH_FUNCTION_DECLARE(@, elt_kw, 0, Valuer_RN)

RZ_LISP_GRAPH_FUNCTION_DECLARE(#, elt, 0, Valuer_RN)
