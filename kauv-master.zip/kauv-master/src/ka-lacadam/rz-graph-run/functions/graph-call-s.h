#ifndef RUN__CORE_CALL_S__H
#define RUN__CORE_CALL_S__H

#include "token/rz-lisp-token.h"

#include "rz-graph-valuer/valuer/rz-lisp-graph-valuer.h"

//#include "types/run-type-value.h"

//?#include "rz/graph/rz-lisp-graph-visitor.h"

#include "functions/rz-lisp-graph-function-families.h"

RZNS_(GRun)


typedef RZ::RECore::RE_Node tNode;

//?typedef CTQ::Lisp::RZ_Lisp_Node tNode;

//?typedef RZ_Lisp_Galaxy::tNode tNode;


#define RZ_LISP_GRAPH_FUNCTION_DECLARE(str, name, arity, status) name,

#define RZ_TEMP_MACRO_(X) \
 template<> \
 struct RZ_Lisp_Graph_Function_Family_<X> \
 { enum Code { \
  null = 0, \


#define _RZ_TEMP_MACRO }; };

//RZ_TEMP_MACRO_(RZ_Graph_Call_S)
// #include "functions/core-functions-s.h"
//_RZ_TEMP_MACRO


RZ_LISP_GRAPH_FUNCTION_CODES_(RZ_Graph_Call_S)
 null = 0,
 #include "core-functions-s.h"
_RZ_LISP_GRAPH_FUNCTION_CODES

#undef RZ_LISP_GRAPH_FUNCTION_DECLARE

//?
//RZ_GCALL_IMPLEMENT <RZ_GCALL_S(Gen, Internal)>
//{
//// template<typename T1>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Token& token, caon_ptr<tNode> start_node)
// {
//  QString s = token.string_value();
//  rh.valuer().register_generate(start_node, s);
////  RZ_Lisp_Generator& gen = *rh.valuer().lisp_generator();
////?  RZ_Lisp_Token* fn_token = pass_node->lisp_token();

//  token.redirect_paste("#gen .rzs <- rz-runtime.ecl;");
////?  gen.prepare_support();
////?  fn_token->skip_lisp_out();  //comment_lisp("c*load");
// }

//};



#define RZ_GCALL_TEMP_DEFAULT_IMPLEMENTATION(count) \
 RZ_GCALL_IMPLEMENT <RZ_GCALL_S(Leave_Logical_Scope_##count, Internal)> \
 { \
  static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Token& start_token, caon_ptr<tNode> pass_node) \
  { \
   start_token.redirect_paste("#_rz-class"); \
  } \
 }; \

//?//
RZ_GCALL_IMPLEMENT <RZ_GCALL_S(Leave_Logical_Scope_4, Internal)>
{
 static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Token& start_token, caon_ptr<tNode> pass_node)
 {
//?
  QString scope_kind = rh.valuer().leave_logical_scope(4, rh);
//  scope_kind.prepend("#_rz-");
//  rh.function_token()->redirect_paste(scope_kind);
 }
};


//RZ_GCALL_IMPLEMENT <RZ_GCALL_S(Haskell_Setting, Internal)>
//{
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Token& start_token, caon_ptr<tNode> pass_node)
// {
////?
//  rh.valuer().haskell_setting(pass_node);
//  //scope_kind.prepend("#_rz-");
////  rh.function_token()->redirect_paste(scope_kind);
// }
//};



//?
//RZ_GCALL_IMPLEMENT <RZ_GCALL_S(Leave_Logical_Scope_5, Internal)>
//{
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Token& start_token, caon_ptr<tNode> pass_node)
// {
//  QString scope_kind = rh.valuer().leave_logical_scope(4);
//  scope_kind.prepend("#_rz-");
//  rh.function_token()->redirect_paste(scope_kind);
// }
//};

//?
//RZ_GCALL_IMPLEMENT <RZ_GCALL_S(Generate_Clos, Internal)>
//{
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Token& start_token, caon_ptr<tNode> pass_node)
// {
//  QString class_name = rh.valuer().current_user_class_name();
//  if(class_name.isEmpty())
//  {
//   rh.function_token()->redirect_paste(QString(
//    "(rz-error \"gclos cannot determine class name\")"));
//  }
//  else
//  {
//   rh.function_token()->redirect_paste(QString(
//    "(self -> generate-clos '%1)").arg(class_name));
//  }
// }
//};

//?   rh.valuer().pop_logical_scope(count); \

//RZ_GCALL_TEMP_DEFAULT_IMPLEMENTATION(4)
//RZ_GCALL_TEMP_DEFAULT_IMPLEMENTATION(5)
//RZ_GCALL_TEMP_DEFAULT_IMPLEMENTATION(6)

#undef RZ_GCALL_TEMP_DEFAULT_IMPLEMENTATION

#define RZ_GCALL_TEMP_DEFAULT_IMPLEMENTATION(fun_name, v_method) \
 RZ_GCALL_IMPLEMENT <RZ_GCALL_S(fun_name, Internal)> \
 { \
  static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Token& start_token, caon_ptr<tNode> pass_node) \
  { \
   rh.valuer->v_method(rh, start_token, pass_node); \
  } \
 }; \


//?RZ_GCALL_TEMP_DEFAULT_IMPLEMENTATION(Function_Entry, function_entry)

//?
//RZ_GCALL_IMPLEMENT <RZ_GCALL_S(Function_Entry, Core_Operative)>
//{
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Token& start_token, caon_ptr<tNode> pass_node)
// {
////?  rh.valuer().function_entry(rh, start_token, pass_node);
// }
//};


//?
//RZ_GCALL_IMPLEMENT <RZ_GCALL_S(Function_Entry, Internal)>
//{
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Token& start_token, caon_ptr<tNode> pass_node)
// {
//  rh.valuer().function_entry(rh, start_token, pass_node);
// }
//};

#undef RZ_GCALL_TEMP_DEFAULT_IMPLEMENTATION

#define RZ_GCALL_TEMP_DEFAULT_IMPLEMENTATION(fun_name, v_method) \
 RZ_GCALL_IMPLEMENT <RZ_GCALL_S(fun_name, Internal)> \
 { \
  static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Token& start_token, caon_ptr<tNode> pass_node) \
  { \
   rh.valuer->v_method(start_token, pass_node); \
  } \
 }; \


//?RZ_GCALL_TEMP_DEFAULT_IMPLEMENTATION(Class_Extends, register_parent_class)
//RZ_GCALL_TEMP_DEFAULT_IMPLEMENTATION(GUI_Resource, gui_resource)
//RZ_GCALL_TEMP_DEFAULT_IMPLEMENTATION(Self_Launch, launch)
//RZ_GCALL_TEMP_DEFAULT_IMPLEMENTATION(Self_Scribe, scribe)
//RZ_GCALL_TEMP_DEFAULT_IMPLEMENTATION(Process_Layer_Flags_, process_flags_layer)
//RZ_GCALL_TEMP_DEFAULT_IMPLEMENTATION(Process_Layer_GUI_, process_gui_layer)
//RZ_GCALL_TEMP_DEFAULT_IMPLEMENTATION(Process_Layer_Book_, process_book_layer)
//RZ_GCALL_TEMP_DEFAULT_IMPLEMENTATION(Process_Layer_Axia_, process_axia_layer)
//RZ_GCALL_TEMP_DEFAULT_IMPLEMENTATION(Set_Default_User_Object_Name, set_default_user_object_name)

#undef RZ_GCALL_TEMP_DEFAULT_IMPLEMENTATION

_RZNS(GRun)

#endif
