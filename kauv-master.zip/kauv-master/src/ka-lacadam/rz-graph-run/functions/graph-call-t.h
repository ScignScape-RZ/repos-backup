#ifndef RUN__CORE_CALL_T__H
#define RUN__CORE_CALL_T__H

#include "token/rz-lisp-token.h"
#include "rz-graph-valuer/valuer/rz-lisp-graph-valuer.h"

//#include "types/run-type-value.h"

#include "functions/rz-lisp-graph-function-families.h"

#include "rzns.h"

RZNS_(GRun)

#define RZ_LISP_GRAPH_FUNCTION_DECLARE(str, name, arity, status) name,

RZ_LISP_GRAPH_FUNCTION_CODES_(RZ_Graph_Call_T)
 null = 0,
 #include "core-functions-t.h"
_RZ_LISP_GRAPH_FUNCTION_CODES

#undef RZ_LISP_GRAPH_FUNCTION_DECLARE

//RZ_GCALL_IMPLEMENT <RZ_GCALL_T(Haskell_Import, Internal)>
//{
// template<typename T1>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1)
// {
// }

//// template<typename T1>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Token& token)
// {
//  rh.valuer().register_user_dominion(token.string_value());
//  //  rh.function_token()->comment_lisp(QString("Dominion: %1 registered")
//  //    .arg(token.string_value()));
// }

//};


//?
//RZ_GCALL_IMPLEMENT <RZ_GCALL_T(Use_Dominion, Internal)>
//{
// template<typename T1>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1)
// {
// }

//// template<typename T1>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Token& token)
// {
//  rh.valuer().register_user_dominion(token.string_value());
//  rh.function_token()->comment_lisp(QString("Dominion: %1 registered")
//    .arg(token.string_value()));
// }

//};


// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Token& token,
//  RZ_Lisp_Symbol& sym)
// {
//  RZ_Lisp_Token* ft = rh.function_token();
//  rh.valuer().register_lexical_symbol(ft, token, sym);
//  rh.mark_continue_statement(& reinterpret_cast<tNode&>(sym) );
////  rh.comment_lisp("setting value...");
// }
//}


_RZNS(GRun)


#endif
