

#ifndef RUN__CORE_CALL_TV__H
#define RUN__CORE_CALL_TV__H

#include "token/rz-lisp-token.h"

//#include "valuer/rz-lisp-core-valuer.h"
//#include "types/run-type-value.h"

#include "rz-graph-valuer/valuer/rz-lisp-graph-valuer.h"

#include "relae-graph/relae-caon-ptr.h"

#include "functions/rz-lisp-graph-function-families.h"

#include "rzns.h"

RZNS_(GRun)

#define RZ_LISP_GRAPH_FUNCTION_DECLARE(str, name, arity, status) name,

RZ_LISP_GRAPH_FUNCTION_CODES_(RZ_Graph_Call_Tv)
 null = 0,
 #include "core-functions-tv.h"
_RZ_LISP_GRAPH_FUNCTION_CODES

#undef RZ_LISP_GRAPH_FUNCTION_DECLARE

RZ_GCALL_IMPLEMENT
<RZ_GCALL_Tv(Set_Returns_To_Equal, Internal)>
{
 static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Token& t1,
                 RZ_Lisp_Graph_Value_Holder& v1)
 {
  caon_ptr<RZ_Lisp_Token> ft = rh.get_lead_function_token();
  if(ft)
  {
   rh.valuer().set_returns_to_equal(rh, v1);
  }
 }
};


//RZ_GCALL_IMPLEMENT


//RZ_GCALL_IMPLEMENT
//<RZ_GCALL_CC(Subtract, Core_Operative__Core_Operative)>
//{
// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2)
// {
////  qDebug() << "Sub: ";
// }

// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, int& t1, int& t2)
// {
//  rh << t1 - t2;
// }
//};

_RZNS(GRun)

#endif


//#ifndef RUN__CORE_CALL_TV__H
//#define RUN__CORE_CALL_TV__H

////#include "graph/ctq-token.h"

//#include "rz-graph-valuer/valuer/rz-lisp-graph-valuer.h"


////?#include "types/run-type-value.h"


//CTQ_CORE_FUNCTION_CODES(Ctq_Core_Call_Tv)
//null = 0,
//#include "core-functions-tv.h"
//_CTQ_CORE_FUNCTION_CODES

//CTQ_CORE_IMPLEMENT <CTQ_Tv(My, Core_Class)>
//{
// template<typename T1, typename T2>
// static void run(Ctq_Result_Holder& rh, T1& t1, T2& t2)
// {

// }

// template<typename T1, typename T2>
// static void run(Ctq_Result_Holder& rh, Ctq_Token& token, Ctq_Symbol& sym)
// {
//  Ctq_Token* t = rh.valuer->process_lexical_symbol_entry(token, sym);
//  //  if(sym.flags.is_declaration_point)
//  //  {
//  //   rh.valuer->set_lookup_token(sym);
//  //  }
//  rh.valuer->run_token_as_first_argument(*t, rh);
// }

// // template<typename T1, typename T2>
// // static void run(Ctq_Result_Holder& rh, Ctq_Symbol& sym, Ctq_Token& token)
// // {
// //  if(sym.flags.is_declaration_point)
// //  {
// //   rh.valuer->insert_lexical_symbol(sym.get_string_value());
// //  }
// //  qDebug() << " /// Sym: " << token.string_value;
// // }

//};


//CTQ_CORE_IMPLEMENT <CTQ_Tv(Ty, Core_Class)>
//{
// template<typename T1, typename T2>
// static void run(Ctq_Result_Holder& rh, Ctq_Token& token, Ctq_Symbol& sym)
// {
//  Ctq_Run_Type_Value* rtv =
//    rh.valuer->get_token_run_type_value(token);
//  rh.set_value(rtv);


// }
// template<typename T1, typename T2>//, typename RET_Type>
// static void run(Ctq_Result_Holder& rh, Ctq_Token& token, T2& t2)
// {
//  Ctq_Run_Type_Value* rtv =
//    rh.valuer->get_token_run_type_value(token);
//  rh.set_value(rtv);

//  //  rh.write_value_to(qDebug());
// }
//};




//#endif
