
#include "rz-lisp-graph-valuer.h"
#include "rz/graph/rz-lisp-graph-visitor.h"

#include "rz-core/rz-lisp/token/rz-lisp-token.h"

RZ_Lisp_Graph_Valuer::RZ_Lisp_Graph_Valuer(RZ_Lisp_Graph_Visitor* rz_lisp_graph_visitor)
 : rz_lisp_graph_visitor_(rz_lisp_graph_visitor)
{
 init_type_objects();

 RZ_Lisp_Token* tok = new RZ_Lisp_Token("<monotail>", 0);
 tok->set_type_object(type_variety_.get_type_object(RZ_Run_Types::Null_Value));
 tok->set_value(new RZ_Null_Value("<monotail>"));
 the_monotail_ = new tNode(tok);
}

void RZ_Lisp_Graph_Valuer::init_type_objects()
{
#define RZ_RUN_TYPE(enum_name, name, cpp_name, fam) \
 type_objects_by_code_.insert({ \
  RZ_Lisp_get_native_type_code<cpp_name>(), \
   type_variety_.add_type_object(RZ_Run_Types::enum_name, #enum_name)});
#include "rz-core/rz-lisp/types/type-codes.h"
#undef RZ_RUN_TYPE


}

void RZ_Lisp_Graph_Valuer::redirect_core_function(RZ_Lisp_Graph_Result_Holder& rh,
 QString function_name, tNode* start_node)
{

}

void RZ_Lisp_Graph_Valuer::register_user_package(QString name)
{

}


void RZ_Lisp_Graph_Valuer::check_node_type(tNode*& node)
{
 check_monotail(node);
 if(!node)
  return;
 RZ_Lisp_Token* tok = node->lisp_token();
 if(tok->type_object())
  return;
 if(tNode* value_node = rlq_.Static_Init_Value(node))
 {
  RZ_Lisp_Kernel_Types::Codes tc = value_node->native_type_code();
  RZ_Type_Object* tobj = type_objects_by_code_[tc];
  value_node->to_vh(tok->vh(), tobj);
  return;
 }
 if(tok->flags.is_nested_opaque_call)
 {
  //? init_opaque_call(node);
  return;
 }
 if(tok->flags.is_symbol_declaration)
 {
  tok->set_type_object(type_variety_.get_type_object(RZ_Run_Types::Sym));
  tok->set_value(node);
  return;
 }
 else if(tok->flags.is_numeric_literal)
  type_numeric_token(tok);
 else if(tok->flags.is_string_literal)
  type_string_token(tok);
 else if(RZ_Lisp_Graph_Core_Function* cf =
  rz_lisp_graph_visitor_->find_core_function(tok->string_value()))
 {
  tok->flags.is_deferred_core_function_symbol = true;
  tok->set_type_object(type_variety_.get_type_object(RZ_Run_Types::CoreFun));
  tok->set_value(cf);
 }
 else
 {
  tok->set_type_object(type_variety_.get_type_object(RZ_Run_Types::Ots));
  tok->set_value(node);
 }
}

void RZ_Lisp_Graph_Valuer::check_monotail(tNode*& node)
{
 if(node)
  return;
 node = the_monotail_;
}

void RZ_Lisp_Graph_Valuer::type_numeric_token(RZ_Lisp_Token* tok)
{
 QString s = tok->raw_text();
 if(s.contains('.'))
 {
  tok->set_type_object(type_variety_.get_type_object(RZ_Run_Types::Dbl));
  tok->set_new_copy_value(s.toDouble());
 }
 else
 {
  tok->set_type_object(type_variety_.get_type_object(RZ_Run_Types::Int));
  tok->set_direct_value(s.toInt());
 }
}

void RZ_Lisp_Graph_Valuer::type_string_token(RZ_Lisp_Token* tok)
{
 tok->set_type_object(type_variety_.get_type_object(RZ_Run_Types::Str));
 tok->mark_as_string_literal();
}

RZ_Lisp_Graph_Valuer::tNode*
 RZ_Lisp_Graph_Valuer::check_node_type_with_entry_premise(RZ_Lisp_Query_Token* premise,
  tNode*& node)
{
 tNode* result = nullptr;
 if(premise)
 {
  switch(premise->relation_label())
  {
  case RZ_Lisp_Query_Token::Run_Vector_Entry:
  //? result = initialize_vector(node);
   break;
  }

 }
 else check_node_type(node);

 return result;
}

RZ_Type_Object* RZ_Lisp_Graph_Valuer::get_node_type_object(tNode* node)
{
 if(type_objects_by_code_.find(node->native_type_code()) != type_objects_by_code_.end())
  return type_objects_by_code_[node->native_type_code()];
 return nullptr;
//? return type_objects_by_code_.value(node->native_type_code(), nullptr);
}


