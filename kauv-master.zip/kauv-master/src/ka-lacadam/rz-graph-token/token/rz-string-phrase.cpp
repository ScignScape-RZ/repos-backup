
#include "rz-string-phrase.h"

#include "rzns.h"


USING_RZNS(GBuild)

RZ_String_Phrase::RZ_String_Phrase(QStringList& strings, int weight)
 : strings_(strings), weight_(weight)
{
}
