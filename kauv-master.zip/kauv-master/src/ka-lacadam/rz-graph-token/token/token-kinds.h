
#ifndef TOKEN_KINDS__H
#define TOKEN_KINDS__H

#include "rzns.h"
RZNS_(GBuild)


enum class Basic_Token_Kinds {
 Symbol_Token, String_Token, Quote_Token, Backquote_Token, Escape_Quote_Token,
 Escape_Character_Token, NOOP_Token,
   // // C++ specific
   Function_Def_Redirect, Empty_Tuple_Indicator,
    Class_Def_Redirect
};


_RZNS(GBuild)

#endif
