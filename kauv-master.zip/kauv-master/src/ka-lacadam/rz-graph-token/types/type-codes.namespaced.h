
// // List run types.  The RZ_RUN_TYPE macro is redefined in different places
//   and expands to different code using the two values written on each line
//   here, depending on the context in which this file is included.



RZ_RUN_TYPE_NS(GVal, Str, str, RZ_String, RZ_Haskell_String, Core_Class)
RZ_RUN_TYPE_NS(GVal, Mlt, mlt, RZ_Match_Literal, RZ_Haskell_Match_Literal, Core_Class)
RZ_RUN_TYPE_NS(GVal, Sym, sym, RZ_Lisp_Symbol, RZ_Haskell_Symbol, Core_Class)
RZ_RUN_TYPE_NS(GVal, Opc, opc, RZ_Opaque_Call, RZ_Haskell_Opaque_Call, Core_Class)
RZ_RUN_TYPE_NS(GVal, Ots, ots, RZ_Opaque_Type_Symbol, RZ_Haskell_Opaque_Type_Symbol, Core_Class)
RZ_RUN_TYPE_NS(GVal, Block_Info, block_info, RZ_Lisp_Graph_Block_Info, RZ_Haskell_Lisp_Graph_Block_Info, Core_Class)
RZ_RUN_TYPE_NS(GBuild, Null_Value, Null_Value, RZ_Null_Value, RZ_Haskell_Null_Value, Core_Class)
//?RZ_RUN_TYPE_NS(GBuild, TokenCoreFun, cfn, RZ_Lisp_Core_Function, RZ_Haskell_Token_Core_Function, Core_Class)
RZ_RUN_TYPE_NS(GBuild, GraphCoreFun, cfn, RZ_Lisp_Graph_Core_Function, RZ_Haskell_Graph_Core_Function, Core_Class)
RZ_RUN_TYPE_NS(GBuild, EmptyTuple, empty-tuple, RZ_Lisp_Empty_Tuple, RZ_Haskell_Empty_Tuple, Core_Class)
RZ_RUN_TYPE_NS(GVal, Phrase, phr, RZ_String_Phrase, RZ_Haskell_String_Phrase, Core_Class)
RZ_RUN_TYPE_NS(GVal, Vec, vec, RZ_Lisp_Vector, RZ_Haskell_Vector, Core_Class)
RZ_RUN_TYPE_NS(GVal, StrPlex, str_plex, RZ_String_Plex, RZ_String_Plex, Core_Class)
RZ_RUN_TYPE_NS(GVal, Map, map, RZ_Lisp_Map, RZ_Haskell_Map, Core_Class)

RZ_RUN_TYPE_NS(GVal, FnDefInfo, fdef, RZ_Function_Def_Info, RZ_Haskell_Function_Def_Info, Core_Class)


//RZ_RUN_TYPE(Key, key, RZ_Keyword, Core_Class)
//RZ_RUN_TYPE(Sym, sym, RZ_Lisp_Symbol, Core_Class)
//RZ_RUN_TYPE(Type, type, RZ_Run_Type_Value, Core_Class)
//RZ_RUN_TYPE(Fn, fn, RZ_User_Function, Core_Class)
//RZ_RUN_TYPE(Cl, cl, RZ_User_Class, Core_Class)
//RZ_RUN_TYPE(Obj, obj, RZ_User_Object, Core_Class)
//RZ_RUN_TYPE(CoreFun, map, RZ_Core_Function_Token, Core_Class)


//RZ_RUN_TYPE(Str, str, RZ_String, Core_Class)
//RZ_RUN_TYPE(Rule, rule, RZ_Rule, Core_Class)
//RZ_RUN_TYPE(Simplex, simplex, RZ_Simplex, Core_Class)
//RZ_RUN_TYPE(Match, match, RZ_Match, Core_Class)
//RZ_RUN_TYPE(Int, int, int, Core_Operative)
//RZ_RUN_TYPE(Dbl, dbl, double, Core_Operative)
//RZ_RUN_TYPE(Sym, sym, RZ_Lisp_Symbol, Core_Class)
//RZ_RUN_TYPE(Type, type, RZ_Run_Type_Value, Core_Class)
//RZ_RUN_TYPE(Fn, fn, RZ_User_Function, Core_Class)
//RZ_RUN_TYPE(Cl, cl, RZ_User_Class, Core_Class)
//RZ_RUN_TYPE(Obj, obj, RZ_User_Object, Core_Class)
//RZ_RUN_TYPE(Bool, bool, RZ_Boolean, Core_Class)
//RZ_RUN_TYPE(CoreFun, map, RZ_Core_Function_Token, Core_Class)
//RZ_RUN_TYPE(Corex, corex, RZ_Core_Extension_Object, Core_Extension)
//RZ_RUN_TYPE(Vec, vec, RZ_Vector, Core_Class)
//RZ_RUN_TYPE(Map, map, RZ_Map, Core_Class)
//RZ_RUN_TYPE(Key, key, RZ_Keyword, Core_Class)

#define RZ_TEMP_CASES_TYPECODE_NAMESPACED 18

