
#ifndef RZ_LISP_CORE_FUNCTION__H
#define RZ_LISP_CORE_FUNCTION__H


//?#include "core/rz-core-function-info.h"

#include "valuer/rz-lisp-graph-function-info.h"

#include "accessors.h"

#include "flags.h"

#include <QString>

#include "rzns.h"
RZNS_(GBuild)


class RZ_Lisp_Core_Function
{
public:
 enum Status_Codes {
  Preempt, Defer, Valuer_DC, Valuer_CB, Valuer_RN, Valuer_N,
  Valuer_N_S, Valuer_N_S_S, Valuer_N_T, Paste, Both,
  CO_Preempt, CO_Defer, CO_Both
 };

 flags_(1)
  bool preempt:1;
  bool defer:1;
  bool use_out_name:1;
  bool use_rz_out_name:1;
  bool paste:1;
  bool valuer:1;
 _flags

private:

 QString rz_name_;
 QString name_;
 int arity_;
 RZ_Lisp_Graph_Function_Info info_;
 QString out_name_;

 static QMap<QString, QString> out_pastes_;

public:

 ACCESSORS(QString ,rz_name)
 ACCESSORS(QString ,name)
 ACCESSORS(int ,arity)
 ACCESSORS__RGET(RZ_Lisp_Graph_Function_Info ,info)
 ACCESSORS(QString ,out_name)

 RZ_Lisp_Core_Function(QString rz_name, QString name, int arity, Status_Codes sc);

 QString get_out_name();
 QString get_out_name_or_string();

// {
//  if(flags.use_out_name)
//   return out_name_;
//  if(flags.use_cdm_out_name)
//   return QString("rz**%1").arg(name_);
//  return name_;
// }
};

_RZNS(GBuild)


#endif
