
//#ifndef RZ_LISP_GRAPH_VALUE_HOLDER__H
//#define RZ_LISP_GRAPH_VALUE_HOLDER__H

//#include "methodic.h"
//#include "flags.h"

//#include "types/rz-type-object.h"

//#include "rz-graph-build/types/core-types.h"

//#include "types/type-families.h"


//#include <QString>

//#include "ctqns.h"
//#include "rzns.h"

//RZNS_(GVal)

//class RZ_Lisp_Graph_Value_Holder
//{
//private:

// void* value_;
// RZ_Type_Object* type_object_;
//// int type_code_;

//// RZ_Lisp_Node*

//public:

// CTQ_METHODIC(void* ,value)
// CTQ_METHODIC(RZ_Type_Object* ,type_object)

// template<typename T>
// void set_direct_value(T t)
// {
//  value_ = reinterpret_cast<void*>(t);
// }

// void set_typecode(RZ_Run_Types::Enum e);


// template<typename T>
// T* pRestore()
// {
////  if()
//  return reinterpret_cast<T*>(value_);
// }

// template<typename T>
// T* pRetrieve()
// {
//  if(type_object_->flags.is_direct_value)
//  {
//   return reinterpret_cast<T*>(&value_);
//  }
//  return pRestore<T>();
// }

// template<typename T>
// void write_value_to(T& t)
// {}

// QString to_string() const;
// QString to_lisp_string() const;


// RZ_Lisp_Graph_Value_Holder();

// int typecode();
//};

//_RZNS(GVal)

//#endif
