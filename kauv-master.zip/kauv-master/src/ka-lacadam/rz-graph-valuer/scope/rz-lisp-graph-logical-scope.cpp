
#include "rz-lisp-graph-logical-scope.h"

#include "token/rz-lisp-token.h"

//#include "graph/rz-lisp-node.h"

#include <QString>
#include <QMap>

#include <QStringList>

USING_RZNS(GVal)

RZ_Lisp_Graph_Logical_Scope::RZ_Lisp_Graph_Logical_Scope(caon_ptr<RZ_Lisp_Graph_Logical_Scope> p)
 : parent_(p), user_class_(nullptr), scope_type_(N_A)
{}

void RZ_Lisp_Graph_Logical_Scope::set_user_class(RZ_Lisp_Graph_User_Class& uc)
{
 user_class_ = &uc;
 scope_type_ = User_Class;
}

void RZ_Lisp_Graph_Logical_Scope::set_user_namespace(RZ_Lisp_Graph_User_Namespace& unsp)
{
 user_namespace_ = &unsp;
 scope_type_ = User_Namespace;
}


void RZ_Lisp_Graph_Logical_Scope::set_user_package(RZ_Lisp_Graph_User_Package& upkg)
{
 user_package_ = &upkg;
 scope_type_ = User_Package;
}



void RZ_Lisp_Graph_Logical_Scope::add_annotations(RZ_Lisp_Token& tok, QStringList& sl)
{
 for(QString qs : sl)
  annotations_.insert(tok.raw_text(), qs);
}

QStringList RZ_Lisp_Graph_Logical_Scope::get_annotations(RZ_Lisp_Token& tok)
{
 return annotations_.values(tok.raw_text());
}

QStringList RZ_Lisp_Graph_Logical_Scope::get_annotations(QString key)
{
 return annotations_.values(key);
}



QString RZ_Lisp_Graph_Logical_Scope::kind_name()
{
 switch(scope_type_)
 {
 case User_Class:
  return "class";
 case User_Resource:
  return "resource";
 case User_Package:
  return "package";
 default:
  return QString();

 }
}

QString RZ_Lisp_Graph_Logical_Scope::default_field_marker()
{
 switch(scope_type_)
 {
 case User_Class:
  return "field-with-default";
 case User_Resource:
  return "field";
 default:
  return QString();

 }

}


QString RZ_Lisp_Graph_Logical_Scope::default_field_prefix()
{
 switch(scope_type_)
 {
 case User_Class:
  return "``";
 case User_Resource:
  return "'";
 default:
  return QString();

 }

}


void RZ_Lisp_Graph_Logical_Scope::set_user_resource(RZ_Lisp_Graph_User_Resource& uc)
{
 user_resource_ = &uc;
 scope_type_ = User_Resource;
}


caon_ptr<RZ_Lisp_Graph_User_Package> RZ_Lisp_Graph_Logical_Scope::user_package()
{
 if(scope_type_ == User_Package)
  return user_package_;
 return nullptr;
}

caon_ptr<RZ_Lisp_Graph_User_Class> RZ_Lisp_Graph_Logical_Scope::user_class()
{
 if(scope_type_ == User_Class)
  return user_class_;
 return nullptr;
}

caon_ptr<RZ_Lisp_Graph_User_Resource> RZ_Lisp_Graph_Logical_Scope::user_resource()
{
 if(scope_type_ == User_Resource)
  return user_resource_;
 return nullptr;
}

RZ_Lisp_Graph_Scope_Token* RZ_Lisp_Graph_Logical_Scope::contains_symbol(QString symbol_name)
{
 if(symbols_.contains(symbol_name))
 {
  return &symbols_[symbol_name];
 }
 if(parent_)
 {
  return parent_->contains_symbol(symbol_name);
 }
 return nullptr;
}


caon_ptr<RE_Node> RZ_Lisp_Graph_Logical_Scope::get_symbol(QString key)
{
 if(symbols_.contains(key))
 {
  RZ_Lisp_Graph_Scope_Token rlst = symbols_[key];
  return rlst.value_node();
//  return rlst.function_token();
 }
 return nullptr;
}

//template<typename T>
//T* RZ_Lisp_Graph_Logical_Scope::pSymbol_as(QString name)
//{
// if(RE_Node* n = get_symbol(name))
// {
//  return n->pValue_as<T>();
// }
// else if(symbols_.contains(name))
// {
//  RZ_Lisp_Graph_Scope_Token rlst = symbols_[name];
//  return rlst.vh().pRestore<T>();
// //  return rlst.function_token();
// }
// return nullptr;
//}


void RZ_Lisp_Graph_Logical_Scope::add_symbol(RZ_Lisp_Token& function_token, RZ_Lisp_Token& tok)
{
 symbols_.insert(tok.raw_text(), RZ_Lisp_Graph_Scope_Token(&function_token, &tok));
}

void RZ_Lisp_Graph_Logical_Scope::add_type_named_symbol(RZ_Lisp_Token& function_token,
 RZ_Lisp_Token& tok, QString type_name)
{
 symbols_.insert(tok.raw_text(), RZ_Lisp_Graph_Scope_Token(function_token, tok, type_name));
}

void RZ_Lisp_Graph_Logical_Scope::mark_value_node(const RZ_Lisp_Token& tok,
  caon_ptr<RE_Node> value_node)
{
 if(symbols_.contains(tok.raw_text()))
 {
//  RZ_Lisp_Graph_Scope_Token& st = symbols_[tok.raw_text()];
//  st.set_value_node(value_node);
  symbols_[tok.raw_text()].set_value_node(value_node);
 }
}

void RZ_Lisp_Graph_Logical_Scope::mark_value(const RZ_Lisp_Token& tok, RZ_Lisp_Graph_Value_Holder& vh)
{
 if(symbols_.contains(tok.raw_text()))
 {
//  RZ_Lisp_Graph_Scope_Token& st = symbols_[tok.raw_text()];
//  st.set_value_node(value_node);
  symbols_[tok.raw_text()].set_vh(vh);
 }
}



//#include "user/ctq-flags-layer.h"
//#include "ctq-gui/ctq-gui-layer.h"

//#include "valuer/ctq-core-valuer.h"

//#include "user/ctq-axia-layer.h"

//Ctq_Flags_Layer* Ctq_Logical_Scope::new_flags_layer()
//{
// flags_layer = new Ctq_Flags_Layer;
// return flags_layer;
//}

//Ctq_Axia_Layer* Ctq_Logical_Scope::new_axia_layer()
//{
// axia_layer = new Ctq_Axia_Layer(this);
// return axia_layer;
//}


//Ctq_GUI_Layer* Ctq_Logical_Scope::new_gui_layer()
//{
// gui_layer = valuer->new_gui_layer(get_user_class());// new Ctq_GUI_Layer( Ctq_Class_Descriptor(get_user_class()) );
// return gui_layer;
//}



//void Ctq_Logical_Scope::merge_flags(Ctq_Logical_Scope* scope)
//{
// if(scope->flags_layer)
// {
//  flags_layer = Ctq_Logical_Scope::new_flags_layer();
//  flags_layer->merge_flags(flags_layer);
// }

//}

//void Ctq_Logical_Scope::set_flag(tString flag_name, bool b)
//{
// if(flags_layer)
//  flags_layer->set_flag(flag_name, b);
// // else error...
//}

//bool Ctq_Logical_Scope::get_flag(tString flag_name)
//{
// if(flags_layer)
//  return flags_layer->get_flag(flag_name);
// // else error...
// return false;
//}


//void Ctq_Logical_Scope::register_symbol(tString s, Ctq_Logical_Symbol* sym)
//{
// symbols[s] = sym;
//}

//void Ctq_Logical_Scope::set_as_logical_symbol(tString s, Ctq_Value_Holder& vh)//Ctq_Script_Token* token)
//{
// if(Ctq_Logical_Symbol* sym = get_logical_symbol(s))
// {
//  sym->hold_value(vh);
// }
// else
// {
//  //valuer->raise_error...
// }
//}

//void Ctq_Logical_Scope::get_logical_symbol(tString s, Ctq_Value_Holder& vh)//Ctq_Script_Token* token)
//{
// if(Ctq_Logical_Symbol* sym = get_logical_symbol(s))
// {
//  sym->write_to_value_holder(vh);
// }
// else
// {
//  //valuer->raise_error...
// }
//}

//Ctq_Logical_Symbol* Ctq_Logical_Scope::get_logical_symbol(tString s)//Ctq_Script_Token* token)
//{
// if(symbols.contains(s))
//  return symbols[s];
// if(parent_scope)
//  return parent_scope->get_logical_symbol(s);
// return nullptr;
//}

