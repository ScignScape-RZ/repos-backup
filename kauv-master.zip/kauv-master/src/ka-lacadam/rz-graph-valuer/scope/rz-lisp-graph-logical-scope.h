
#ifndef RZ_LISP_GRAPH_LOGICAL_SCOPE__H
#define RZ_LISP_GRAPH_LOGICAL_SCOPE__H

#include "accessors.h"
#include "flags.h"

//#include "rz-lisp-value-holder.h"

#include <QString>
#include <QMap>
#include <QMultiMap>

#include "rz-lisp-graph-scope-token.h"

//#include "rz-graph-build/graph/rz-lisp-node.h"

#include "relae-graph/relae-caon-ptr.h"

#include "rzns.h"

//#include "ctqns.h"

#include "rz-graph-core/kernel/graph/rz-re-node.h"


RZNS_(RECore)

class RE_Node;

_RZNS(RECore)


RZNS_(GBuild)

class RZ_Lisp_Token;

_RZNS(GBuild)


RZNS_(GVal)

class RZ_Lisp_Graph_User_Class;
class RZ_Lisp_Graph_User_Namespace;
class RZ_Lisp_Graph_User_Dominion;
class RZ_Lisp_Graph_User_Library;
class RZ_Lisp_Graph_User_Module;
class RZ_Lisp_Graph_User_Resource;
class RZ_Lisp_Graph_User_Package;

class RZ_Lisp_Graph_Logical_Scope
{
//public:
// flags_(1)
// _flags

//private:

 QMap<QString, RZ_Lisp_Graph_Scope_Token> symbols_;
 typedef QMap<QString, RZ_Lisp_Graph_Scope_Token> symbols_type;

 caon_ptr<RZ_Lisp_Graph_Logical_Scope> parent_;

 union {
  caon_ptr<RZ_Lisp_Graph_User_Class> user_class_;
  caon_ptr<RZ_Lisp_Graph_User_Namespace> user_namespace_;
  caon_ptr<RZ_Lisp_Graph_User_Dominion> user_dominion_;
  caon_ptr<RZ_Lisp_Graph_User_Resource> user_resource_;
  caon_ptr<RZ_Lisp_Graph_User_Package> user_package_;
 };

 enum Scope_Type
 {
  N_A, User_Class, User_Resource, User_Package, User_Namespace, Module, Dominion, Library
 };

 QMultiMap<QString, QString> annotations_;

 Scope_Type scope_type_;

public:

 ACCESSORS__RGET(symbols_type ,symbols)
 ACCESSORS(caon_ptr<RZ_Lisp_Graph_Logical_Scope> ,parent)

 RZ_Lisp_Graph_Logical_Scope(caon_ptr<RZ_Lisp_Graph_Logical_Scope> p = nullptr);

 typedef QMapIterator<QString, RZ_Lisp_Graph_Scope_Token> symbols_iterator_type;

 QString kind_name();

 QString default_field_marker();

 QStringList get_annotations(RZ_Lisp_Token& tok);
 QStringList get_annotations(QString key);

 void add_annotations(RZ_Lisp_Token& tok, QStringList& sl);


 template<typename T>
 caon_ptr<T> pSymbol_as(QString name)
 {
  if(caon_ptr<RE_Node> n = get_symbol(name))
  {
   return n->as<T>();
   //return n->pValue_as<T>();
  }
  else if(symbols_.contains(name))
  {
   RZ_Lisp_Graph_Scope_Token rlst = symbols_[name];
    //?return rlst.vh().pRestore<T>();
  //  return rlst.function_token();
  }
  return nullptr;
 }


 void add_symbol(RZ_Lisp_Token& function_token, RZ_Lisp_Token& tok);

 caon_ptr<RE_Node> get_symbol(QString key);

 RZ_Lisp_Graph_Scope_Token* contains_symbol(QString symbol_name);

 void add_type_named_symbol(RZ_Lisp_Token& function_token, RZ_Lisp_Token& tok,
  QString type_name);

 void mark_value_node(const RZ_Lisp_Token& tok, caon_ptr<RE_Node> value_node);
 void mark_value(const RZ_Lisp_Token& tok, RZ_Lisp_Graph_Value_Holder& vh);

 void set_user_class(RZ_Lisp_Graph_User_Class& uc);
 void set_user_namespace(RZ_Lisp_Graph_User_Namespace& unsp);
 void set_user_resource(RZ_Lisp_Graph_User_Resource& ur);
 void set_user_package(RZ_Lisp_Graph_User_Package& upkg);

 QString default_field_prefix();


 caon_ptr<RZ_Lisp_Graph_User_Resource> user_resource();
 caon_ptr<RZ_Lisp_Graph_User_Class> user_class();
 caon_ptr<RZ_Lisp_Graph_User_Package> user_package();

};

_RZNS(GVal)

#endif
