
#include "rz-lisp-graph-user-package.h"
#include "rz-lisp-graph-logical-scope.h"

//#include "graph/rz-lisp-node.h"

#include <QString>
#include <QMap>

USING_RZNS(GVal)

RZ_Lisp_Graph_User_Package::RZ_Lisp_Graph_User_Package(QString name)
 : name_(name)
{}


//template<typename T>
//T* RZ_Lisp_Graph_User_Package::pSymbol_as(QString name)
//{
// return scope_->pSymbol_as<T>(name);
//}



