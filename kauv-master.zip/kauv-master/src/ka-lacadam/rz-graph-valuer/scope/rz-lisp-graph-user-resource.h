
#ifndef RZ_LISP_USER_RESOURCE__H
#define RZ_LISP_USER_RESOURCE__H

#include "accessors.h"
#include "flags.h"

//#include "rz-lisp-value-holder.h"

#include <QString>
#include <QMap>
#include <QDebug>


//#include "rz-lisp-scope-token.h"

#include "rzns.h"
RZNS_(GVal)

class RZ_Lisp_Logical_Scope;

class RZ_Lisp_Graph_User_Resource
{
 QString name_;
 RZ_Lisp_Logical_Scope* scope_;

public:

 ACCESSORS(QString ,name)
 ACCESSORS(RZ_Lisp_Logical_Scope* ,scope)

 RZ_Lisp_Graph_User_Resource(QString name);

 template<typename T>
 friend void operator<<(T& t, const RZ_Lisp_Graph_User_Resource&)
 {
 }

 friend void operator<<(QDebug qd, RZ_Lisp_Graph_User_Resource&)
 {
 }

};

_RZNS(GVal)

#endif
