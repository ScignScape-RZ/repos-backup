#ifndef RZ_LISP_VECTOR__H
#define RZ_LISP_VECTOR__H

#include "rz-typedefs.h"
#include "flags.h"
#include "accessors.h"


#include "relae-graph/relae-caon-ptr.h"


#include <QDebug>
#include <QVector>
#include <QStringList>
#include <QList>
#include <QMap>
#include <QMultiMap>


#include "rzns.h"


RZNS_(RECore)

class RE_Node;
class RE_Tuple_Info;

_RZNS(RECore)

USING_RZNS(RECore)


RZNS_(GBuild)

class RZ_Type_Object;
class RZ_Lisp_Token;
//class RZ_Lisp_Node;
class RZ_String_Phrase;

_RZNS(GBuild)

USING_RZNS(GBuild)


RZNS_(GVal)

class RZ_String;

class RZ_Lisp_Graph_Valuer;

//struct RZ_Script_Token;
//struct RZ_Lisp_Graph_Result_Holder;
//struct RZ_Type_Not_Set;
//struct RZ_Core_Valuer;
//struct RZ_Symbol;
//struct RZ_User_Function;
//struct RZ_Run_Type_Value;
//struct RZ_Boolean;

class RZ_Lisp_Vector
{
 typedef RE_Node tNode;

public:

 flags_(1)
  bool is_declaration_array:1;
  bool is_final:1;
  bool is_pure_token:1;
 _flags

private:

 //RE_Tuple_Info& rti
 caon_ptr<RE_Tuple_Info> tuple_info_;
 caon_ptr<RZ_Lisp_Token> token_representation_;

 QVector<caon_ptr<tNode>> nodes_;

 caon_ptr<tNode> entry_node_;

// RZ_String ctq_string_;

public:

// CTQ_METHODIC_RGET(RZ_String ,ctq_string)

// RZ_Lisp_Vector(RZ_Lisp_Token* t = nullptr):Flags(0), ctq_string_(t){}
//tNode* n
 RZ_Lisp_Vector(caon_ptr<RE_Tuple_Info> tuple_info, RZ_Type_Object& rto);
  //: Flags(0), ctq_string_(s)


 bool elements_are_evaluable()
 {
  return !(flags.is_declaration_array || flags.is_pure_token);
 }

 ACCESSORS(caon_ptr<RE_Tuple_Info> ,tuple_info)
 ACCESSORS(caon_ptr<RZ_Lisp_Token> ,token_representation)

 ACCESSORS__RGET(QVector<caon_ptr<tNode>> ,nodes)

 caon_ptr<tNode> get_call_entry_node();

 void add_node(caon_ptr<tNode> n);

 void to_string_list(QStringList& qsl, RZ_Lisp_Graph_Valuer& valuer);
 void to_string_phrase_vector(QVector<QStringList>& qv, RZ_Lisp_Graph_Valuer& valuer);
 void to_string_phrase_map_multimap(QMap<QString,
  QMultiMap<double, QStringList > >& qmm, RZ_Lisp_Graph_Valuer& valuer);

 template<typename T>
 friend T& operator<<(T& t, const RZ_Lisp_Vector& rhs)
 {
//?  return t << rhs.to_string();
 }


 friend void operator<<(QDebug lhs, const RZ_Lisp_Vector& rhs)
 {
//?  tString s = rhs.to_string();
//?  lhs << s;
 }

// operator RZ_String()
// {
//  return ctq_string;
// }

// template<typename T>
// friend T& operator<<(T& t, const RZ_Lisp_Vector& rhs)
// {
//  t << rhs.
// }


// #include "types/type-operators.h"

// friend bool operator==(const RZ_String& lhs, const RZ_String& rhs)
// {
//  return lhs.to_string() == rhs.to_string();
// }

// operator bool()
// {
//  tString s = to_string();
//  return s.isEmpty() || s.isNull();
// }

// bool operator>(const RZ_String& rhs) const;
// bool operator<(const RZ_String& rhs) const;

//  template<typename T>
//  friend T& operator<<(T& t, const RZ_String& s)
//  {
//   return t << s.to_string();
//  }

//  friend RZ_Lisp_Graph_Result_Holder& operator<<(RZ_Lisp_Graph_Result_Holder& rh, const RZ_String& s)
//  {
//   rh << s;
//   return rh;
//  }


//  RZ_String operator+(const RZ_String& rhs )
//  {
//   return RZ_String( to_string() + rhs.to_string() );
//  }

//  template<typename T>
//  bool operator>(const T& rhs) const
//  {
//   return false;
//  }

//  template<typename T>
//  bool operator<(const T& rhs) const
//  {
//   return false;
//  }

//  template<typename T>
//  friend bool operator>(const T& lhs, const RZ_String& rhs)
//  {
//   return false;
//  }

//  template<typename T>
//  friend bool operator<(const T& lhs, const RZ_String& rhs)
//  {
//   return false;
//  }


// bool operator>(const RZ_Symbol& rhs) const
// {
//  return false;
// }
// bool operator<(const RZ_Symbol& rhs) const
// {
//  return false;
// }
// bool operator>(const RZ_Type_Not_Set& rhs) const
// {
//  return false;
// }
// bool operator<(const RZ_Type_Not_Set& rhs) const
// {
//  return false;
// }
// bool operator>(const RZ_User_Function& rhs) const
// {
//  return false;
// }
// bool operator<(const RZ_User_Function& rhs) const
// {
//  return false;
// }
// bool operator>(const RZ_Run_Type_Value& rhs) const
// {
//  return false;
// }
// bool operator<(const RZ_Run_Type_Value& rhs) const
// {
//  return false;
// }
// bool operator>(const RZ_Boolean& rhs) const
// {
//  return false;
// }
// bool operator<(const RZ_Boolean& rhs) const
// {
//  return false;
// }


};

_RZNS(GVal)

#endif
