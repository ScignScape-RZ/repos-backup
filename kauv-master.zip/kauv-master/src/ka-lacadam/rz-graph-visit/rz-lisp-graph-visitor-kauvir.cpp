
#include "rz-lisp-graph-visitor.h"

#include "rz-lisp-graph-visitor-kauvir.h"

#include "rz-graph-run/token/rz-graph-run-token.h"
#include "rz-graph-token/token/rz-lisp-token.h"
#include "rz-graph-core/kernel/graph/rz-re-node.h"
#include "rz-code-generators/rz-function-def-info.h"
#include "rz-graph-token/rz-lisp-graph-core-function.h"
#include "rz-graph-core/token/rz-re-token.h"
#include "rz-graph-embed/rz-graph-embed-token.h"
#include "rz-graph-embed/rz-graph-cpp/rz-graph-cpp-token.h"
#include "rz-graph-embed/rz-graph-haskell/rz-graph-haskell-token.h"
#include "rz-graph-embed/rz-graph-cheerp/rz-graph-cheerp-token.h"
#include "rz-graph-embed/rz-graph-clasp/rz-graph-clasp-token.h"
#include "rz-block-entry-run-plugin.h"
#include "rz-graph-core/code/rz-re-function-def-entry.h"
#include "rz-graph-valuer/scope/rz-lisp-graph-lexical-scope.h"
#include "rz-graph-valuer/valuer/rz-lisp-graph-valuer.h"
#include "rz-graph-run/rz-lisp-graph-runner.h"
#include "rz-graph-build/rz-lisp-graph-result-holder.h"
#include "rz-graph-build/types/run-type-codes.h"
#include "rz-graph-embed/rz-graph-run-embedder.h"
#include "rz-graph-embed-run/rz-graph-embed-run-valuer.h"
#include "rz-graph-embed/rz-graph-embed-check.h"
#include "rz-graph-core/code/rz-re-call-entry.h"
#include "rz-graph-core/code/rz-re-block-entry.h"
#include "rz-embed-branch-run-plugin.h"
#include "rz-graph-core/tuple/rz-re-tuple-info.h"
#include "rz-graph-sre/rz-sre-token.h"

#include "rz-graph-valuer/scope/rz-lisp-graph-block-info.h"

#include <QRegularExpression>
#include <QRegularExpressionMatch>

#include "rzns.h"

USING_RZNS(GBuild)

USING_RZNS(GEmbed)

RZ_Lisp_Graph_Visitor_Kauvir::RZ_Lisp_Graph_Visitor_Kauvir(RZ_Lisp_Graph_Visitor& visitor)
 : visitor_(visitor), pending_block_info_(nullptr)
//  ,current_node_(nullptr)
//  ,rewind_node_(nullptr)
//  ,next_node_(nullptr)
//  ,current_call_entry_object_(nullptr)
//  ,current_call_entry_node_(nullptr)
//  ,last_graph_clasp_token_(nullptr)
//  ,current_run_plugin_(nullptr)
//  ,current_block_node_(nullptr)
//  ,current_pending_parent_block_node_(nullptr)
//  ,tail_rewind_count_(0)
//run_state_;
{

}

//? needed any more?
caon_ptr<RZ_Lisp_Graph_Block_Info> RZ_Lisp_Graph_Visitor_Kauvir::block_info_from_block_entry_node(caon_ptr<RE_Node> ben)
{
 caon_ptr<RZ_Lisp_Graph_Block_Info> result = nullptr;
 if(caon_ptr<RE_Block_Entry> rbe = ben->re_block_entry())
 {
  CAON_PTR_DEBUG(RE_Block_Entry ,rbe)
  CAON_DEBUG_NOOP
 }
 return nullptr;
}


caon_ptr<RZ_Lisp_Graph_Block_Info> RZ_Lisp_Graph_Visitor_Kauvir::check_pending_block_info(caon_ptr<RE_Node> node)
{
 return visitor_.get_block_info_from_function_node(node);
}


QString RZ_Lisp_Graph_Visitor_Kauvir::lisp_token_from_token_text(QString text,
  QString& bridge_code)
{
 static QMap<QString, QString> static_map {{
   {":::", ""},
   {"->", ""},
   {"@->", ""},
  }};

 if(text.startsWith("$-"))
 {
  bridge_code = "$-";
  return text.mid(2);
 }
 else if(text.startsWith("#-"))
 {
  bridge_code = "#-";
  return text.mid(2);
 }
 else if(text.startsWith("%-"))
 {
  bridge_code = "%";
  return text.mid(2);
 }
 else
 {
  return static_map.value(text, text);
 }
}

QString RZ_Lisp_Graph_Visitor_Kauvir::function_name_from_token_text(QString text)
{
 static QMap<QString, QString> static_map {{
   {"my", "ka::sd"},
   {"our", "ka::sx"},
   {"\\=", "ka::si"},
   {"\\==", "ka::si"},
   {"/->", "ka::fc"},
   {"do", "ka::clf"},
   {"elsif", ""},

   {"KAUVIR_DECLARE_INTERACTIVE", "ka::sr"},

  }};

 return static_map.value(text, text);

}

QString RZ_Lisp_Graph_Visitor_Kauvir::wrap_token_with_bridge_code(QString token, QString bridge_code, QString es_argument)
{
 char c = bridge_code.at(0).toLatin1();
 switch(c)
 {
 case '$':
  return QString("(ka::svs %1 %2)").arg(es_argument).arg(token);
 default:
  return QString("(ka::sv %1 %2)").arg(es_argument).arg(token);
 }
}

//?
caon_ptr<RZ_Lisp_Graph_Block_Info> RZ_Lisp_Graph_Visitor_Kauvir::clear_pending_block_info()
{
 caon_ptr<RZ_Lisp_Graph_Block_Info> result = pending_block_info_;
 pending_block_info_ = nullptr;
 return result;
}

caon_ptr<RE_Node> RZ_Lisp_Graph_Visitor_Kauvir::get_next_node(caon_ptr<RE_Node> start_node,
  RZ_Lisp_Graph_Visitor::Next_Node_Premise& next_node_premise)
{
 // next_node_premise is read-write
 caon_ptr<RE_Node> result = nullptr;

 if(pending_block_info_)
 {
  next_node_premise = RZ_Lisp_Graph_Visitor::Next_Node_Premise::Block_Entry;
  CAON_PTR_DEBUG(RZ_Lisp_Graph_Block_Info ,pending_block_info_)
  result = pending_block_info_->block_entry_node();
  //pending_block_info_ = nullptr;
  return result;
 }

 switch(next_node_premise)
 {
 case RZ_Lisp_Graph_Visitor::Next_Node_Premise::Expression:
  next_node_premise = visitor_.get_cross_node(start_node, result);
  break;
 default:
  next_node_premise = visitor_.get_next_node(start_node, result);
  break;
 }
 return result;
}

caon_ptr<RE_Node> RZ_Lisp_Graph_Visitor_Kauvir::leave_nested_block(caon_ptr<RZ_Lisp_Graph_Block_Info> rbi, caon_ptr<RZ_Lisp_Graph_Block_Info>& nn_bi)
{
 if(rbi)
 {
  CAON_PTR_DEBUG(RZ_Lisp_Graph_Block_Info ,rbi)
  caon_ptr<RE_Node> result = rbi->continue_node();
  CAON_PTR_DEBUG(RE_Node ,result)

  // for debug ...
  {
   if(caon_ptr<RE_Node> ben = rbi->block_entry_node())
   {
    if(caon_ptr<RE_Block_Entry> rbe = ben->re_block_entry())
    {
     CAON_PTR_DEBUG(RE_Block_Entry ,rbe)
     CAON_DEBUG_NOOP
    }
   }
  }

  if(result)
  {
   nn_bi = visitor_.get_block_info_from_function_node(result);
  }
  else
  {
   nn_bi = nullptr;
  }
  return result;
 }
 nn_bi = nullptr;
 return nullptr;
}

caon_ptr<RE_Node> RZ_Lisp_Graph_Visitor_Kauvir::block_entry_node_from_function_def_entry_node(caon_ptr<RE_Node> start_node)
{
 CAON_PTR_DEBUG(RE_Node ,start_node)
 return visitor_.nested_block_entry_from_prior_node(start_node);
}

caon_ptr<RE_Node> RZ_Lisp_Graph_Visitor_Kauvir::call_entry_node_from_block_entry_node(caon_ptr<RE_Node> start_node)
{
 CAON_PTR_DEBUG(RE_Node ,start_node)
 return visitor_.call_entry_from_node(start_node);
}

caon_ptr<RZ_Function_Def_Info> RZ_Lisp_Graph_Visitor_Kauvir::get_function_def_info_from_entry(caon_ptr<RE_Function_Def_Entry> fde)
{
 caon_ptr<RE_Node> prior_node = fde->prior_node();
 CAON_PTR_DEBUG(RE_Node ,prior_node)

 if(caon_ptr<RE_Node> fdi_node = visitor_.get_call_sequence_node(prior_node))
 {
  CAON_PTR_DEBUG(RE_Node ,fdi_node)
  if(caon_ptr<RZ_Lisp_Token> tok = fdi_node->lisp_token())
  {
   return tok->pRestore<RZ_Function_Def_Info>();
   //return fdi_node->rz_function_def_info();
  }
 }
 return nullptr;
}


caon_ptr<RE_Node> RZ_Lisp_Graph_Visitor_Kauvir::start_node_from_call_entry_node(caon_ptr<RE_Node> entry_node)
{
 return visitor_.entry_from_call_entry(entry_node);
}

caon_ptr<RE_Node> RZ_Lisp_Graph_Visitor_Kauvir::find_statement_cross_sequence_node(caon_ptr<RE_Node> start_node)
{
 CAON_PTR_DEBUG(RE_Node ,start_node)
 caon_ptr<RE_Node> result = visitor_.get_cross_sequence_node(start_node);
 CAON_PTR_DEBUG(RE_Node ,result)
 return result;
}

