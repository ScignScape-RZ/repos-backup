
#ifndef RZ_INVOCATION_BLOCK__H
#define RZ_INVOCATION_BLOCK__H


#include "rzns.h"

RZNS_(RECore)

class RZ_Invocation_Block
{

};


_RZNS(RECore)


#endif //RZ_INVOCATION_BLOCK__H
