
#ifndef RZ_INVOCATION_DOCK__H
#define RZ_INVOCATION_DOCK__H


#include "rzns.h"

RZNS_(RECore)

class RZ_Invocation_Dock_Position
{

};


_RZNS(RECore)


#endif //RZ_INVOCATION_DOCK__H

