
#ifndef RZ_INVOCATION_KINDS__H
#define RZ_INVOCATION_KINDS__H


#include "rzns.h"

RZNS_(RECore)

enum class RZ_Invocation_Kinds {

 N_A,
   Docked_Single_Return_Channel,
   MultiDocked_Return_Channel,
   Docked_Single_Select_Return_Channel,

   Loomed_Single_Return_Channel,
   MultiLoomed_Return_Channel,
   Loomed_Single_Select_Return_Channel,

   Exception_Channel,

   Input_Channel,
   Privileged_Input_Channel,

   Capture_Channel,
   Privileged_Capture_Channel,

};


_RZNS(RECore)


#endif //RZ_INVOCATION_DOCK__H

