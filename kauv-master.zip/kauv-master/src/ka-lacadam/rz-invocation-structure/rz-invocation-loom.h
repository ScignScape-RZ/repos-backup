
#ifndef RZ_INVOCATION_LOOM__H
#define RZ_INVOCATION_LOOM__H


#include "rzns.h"

RZNS_(RECore)

class RZ_Invocation_Loom
{

};


_RZNS(RECore)


#endif //RZ_INVOCATION_LOOM__H


