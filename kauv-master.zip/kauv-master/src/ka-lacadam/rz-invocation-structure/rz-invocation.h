
#ifndef RZ_INVOCATION__H
#define RZ_INVOCATION__H


#include "rzns.h"

RZNS_(RECore)

class RZ_Invocation
{

};


_RZNS(RECore)


#endif //RZ_INVOCATION__H




