

#include <QApplication>
#include <QGraphicsView>

#include <QList>
#include <QDebug>

#include <QMessageBox>

#include <QMenu>

#include <QGraphicsItem>

#include <QScreen>
#include <QTimer>
#include <QTime>

#include <QToolBar>

#include <QImage>

#include <QApplication>
#include <QDesktopWidget>

#include <QFileDialog>

#include "ka-sonic/ka-sonic-main-reader-dialog.h"
#include "ka-sonic/FictionBook_builder.h"

#include "ka-sonic/epub/ka-epub-builder.h"

#include "Relae/relae-lisp-embed/relae-lisp-eval.h"
#include "Relae/relae-lisp-embed/relae-lisp-embed-environment.h"

#include "textio.h"


USING_KANS(EmbL)



int main(int argc, char **argv)
{

 QApplication qapp(argc, argv);

 //?


 //?KA_Sonic_FB2_Dialog dlg("/ext_root/fbreader/FBReader-master/fbreader/data/help/MiniHelp.desktop.en.fb2");
//

// KA_Sonic_Main_Reader_Dialog dlg("http://ieeexplore.ieee.org/document/7562400/");
// /ext_root/fbreader/books/9783110495331_epub/OPS/content/

 KA_Sonic_Main_Reader_Dialog dlg("/ext_root/fbreader/books/9783110495331_epub/OPS/content/01_Cover.xhtml");

//   = new KA_Sonic_FB2_Dialog("/ext_root/fbreader/xmltest.xml");

 Relae_Lisp_Embed_Environment env(argc, argv);
 Relae_Lisp_Eval reval(&env);


 qRegisterMetaType<FictionBook_builder*>();
 qRegisterMetaType<FictionBook_builder>();


 qRegisterMetaType<KA_EPub_builder*>();
 qRegisterMetaType<KA_EPub_builder>();

 //qRegisterMetaType<KA_Sonic_FB2_Document_Builder*>();


 reval.prepare_callbacks();

//? reval.eval_file("/ext_root/fbreader/xmltest.xml.md.ecl");

//? reval.eval_raw_file_via_load("/ext_root/fbreader/xmltest.xml.md.ecl");


 KA_Sonic_Main_Reader_Dialog::connect(&dlg, &KA_Sonic_Main_Reader_Dialog::metadata_file_ready,
   [&reval](QString path)
  {
  qDebug() << "DLG1";
   reval.eval_raw_file(path);
  });

 KA_Sonic_Main_Reader_Dialog::connect(&dlg, &KA_Sonic_Main_Reader_Dialog::document_file_ready,
   [&reval](QString path)
  {
  qDebug() << "DLG2";
   reval.eval_raw_file(path);
  });


 KA_Sonic_Main_Reader_Dialog::connect(&dlg, &KA_Sonic_Main_Reader_Dialog::proceed_requested,
   [&reval](KA_Sonic_Main_Reader_Dialog* dlg)
  {
   qDebug() << "DLG";

   QString mp = dlg->metadata_ecl_path();
   QString dp = dlg->document_ecl_path();

//   QString dhp = dlg->document_html_path();
//   QString dh = dlg->document_html();

   reval.eval_raw_file_via_load(mp);

   //?KA::TextIO::save_file(dhp, dh);


   //?reval.eval_raw_file_via_load(dp);
   //?reval.eval_file(dp);

   //?QString mp = dlg->
   //?reval.eval_raw_file(path);
  });



//// env.set_quicklisp_location("/home/nlevisrael/quicklisp/setup.lisp");
//// reval.eval_quicklisp_setup();

////? reval.eval_file("/extension/ecl/t1.lisp");


 dlg.set_lisp_embed_environment(&env);
 dlg.set_lisp_eval(&reval);

 dlg.show();

 qapp.exec();

}

