
#include "FictionBook_builder.h"

#include <QDebug>


FictionBook_builder::FictionBook_builder()
 :  fb2_document_(new KA_Sonic_FB2_Document)
{
}


FictionBook_builder::FictionBook_builder(const FictionBook_builder& rhs)
  :  fb2_document_(rhs.fb2_document_)
{

}

FictionBook_builder::~FictionBook_builder()
{

}

void FictionBook_builder::check_construction()
{
 qDebug() << "CC OK";
}


void FictionBook_builder::Tag_title_info(QString str)
{

}

void FictionBook_builder::Tag_description(QString str)
{
 fb2_document_->set_description(str);
}

void FictionBook_builder::Tag_author(QString str)
{
 fb2_document_->set_author(str);
}

void FictionBook_builder::Tag_last_name(QString str)
{
 fb2_document_->set_last_name(str);
}

void FictionBook_builder::Tag_book_title(QString str)
{
 fb2_document_->set_book_title(str);
}

void FictionBook_builder::Tag_lang(QString str)
{
 fb2_document_->set_lang(str);
}


