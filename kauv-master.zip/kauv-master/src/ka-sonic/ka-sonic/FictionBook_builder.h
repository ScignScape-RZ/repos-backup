

#ifndef FICTIONBOOK__BUILDER__H
#define FICTIONBOOK__BUILDER__H

#include <QObject>

#include <QMetaType>

#include "accessors.h"

#include "ka-sonic-fb2-document.h"


class FictionBook_builder : public QObject
{
 Q_OBJECT


 KA_Sonic_FB2_Document* fb2_document_;

public:


 FictionBook_builder();

 FictionBook_builder(const FictionBook_builder& rhs);

 ~FictionBook_builder();


 Q_INVOKABLE void check_construction();

 Q_INVOKABLE void Tag_title_info(QString str);
 Q_INVOKABLE void Tag_description(QString str);
 Q_INVOKABLE void Tag_author(QString str);
 Q_INVOKABLE void Tag_last_name(QString str);
 Q_INVOKABLE void Tag_book_title(QString str);
 Q_INVOKABLE void Tag_lang(QString str);

};


Q_DECLARE_METATYPE(FictionBook_builder*)
Q_DECLARE_METATYPE(FictionBook_builder)

#endif  // KA_SONIC_FB2_DIALOG__H

