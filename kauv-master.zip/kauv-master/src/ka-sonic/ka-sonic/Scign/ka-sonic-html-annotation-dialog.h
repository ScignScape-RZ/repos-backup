#ifndef KA_SONIC_HTML_ANNOTATION_DIALOG__H
#define KA_SONIC_HTML_ANNOTATION_DIALOG__H

#include <QDialog>
#include <QString>

#include <QLineEdit>
#include <QPlainTextEdit>
#include <QFormLayout>

#include <QTabWidget>
#include <QWebEngineView>
#include <QFrame>
#include <QDialogButtonBox>
#include <QPushButton>


class KA_Sonic_HTML_Annotation_Dialog  :  public QDialog
{
 Q_OBJECT

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QPushButton* button_proceed_;


 QLineEdit* writer_line_edit_;
 QLineEdit* annotation_code_line_edit_;
 QPlainTextEdit* main_text_edit_;
 QPlainTextEdit* css_text_edit_;


 QFormLayout* central_layout_;

 QTabWidget* main_tab_widget_;
 QWebEngineView* main_preview_;

 QFrame* main_frame_;

 QString annotation_code_;

 QVBoxLayout* main_layout_;

public:

 KA_Sonic_HTML_Annotation_Dialog
   (QString annotation_code, QWidget* parent = nullptr);

 ~KA_Sonic_HTML_Annotation_Dialog();


Q_SIGNALS:

 void canceled(QDialog*);
 void accepted(QDialog*);


public Q_SLOTS:

 void accept();
 void cancel();

 void proceed();



};


#endif // KA_SONIC_HTML_ANNOTATION_DIALOG

