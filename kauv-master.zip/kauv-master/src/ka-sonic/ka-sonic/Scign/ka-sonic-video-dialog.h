
#ifndef KA_SONIC_VIDEO_DIALOG__H
#define KA_SONIC_VIDEO_DIALOG__H


#include <QString>
#include <QMainWindow>

#include <QTextEdit>
//?#include <QWebView>

#include <QWebEngineView>
#include <QLabel>
#include <QPushButton>

#include <QDialog>

#include <QApplication>

#include <QComboBox>

#include "accessors.h"

#include "flags.h"

#include "kans.h"

#include <QEvent>
#include <QMouseEvent>

//#include "incident-form-dialog.h"

class QPushButton;
class QTextEdit;
class QPlainTextEdit;
class QLineEdit;
class QTabWidget;
class QDialogButtonBox;
class QVBoxLayout;
class QHBoxLayout;
class QCheckBox;
class QFormLayout;
class QSplitter;
class QGridLayout;
class QListWidget;
class QTableWidget;
class QScrollArea;
class QGroupBox;
class QTableWidgetItem;
class QGraphicsRectItem;
class QRubberBand;

#include <QtMultimedia>
#include <QtMultimediaWidgets>



//RZNS_(QWN)
namespace KA{ namespace MoND_UI{


class NDP_Antemodel;
class NDP_Project;
class NDP_Project_Initial;

class Sonic_Web_View_Dialog;


class KA_Sonic_Video_Dialog : public QDialog
{
 Q_OBJECT

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QPushButton* button_proceed_;

 QLabel* url_label_;
 QLineEdit* url_line_edit_;


 QMediaPlayer* media_player_;

 QGraphicsVideoItem* video_item_;

 QGraphicsScene* graphics_scene_;
 QGraphicsView* graphics_view_;

// graphicsView->scene()->addItem(item);
// graphicsView->show();

// player->setMedia(QUrl("http://example.com/myclip4.ogv"));
// player->play();

 QHBoxLayout* navigation_layout_;
 QPushButton* navigation_rewind_button_;
 QPushButton* navigation_pause_button_;
 QPushButton* navigation_forward_button_;

 QHBoxLayout* url_layout_;
 QVBoxLayout* main_layout_;



public:

 KA_Sonic_Video_Dialog(QString url, QWidget* parent = nullptr);


 ~KA_Sonic_Video_Dialog();


Q_SIGNALS:

 void canceled(QDialog*);
 void accepted(QDialog*);


public Q_SLOTS:
 void accept();
 void cancel();
 //?void proceed();

// void go_button_clicked();
// void close_button_clicked();


};

} } //_RZNS(MMUI)



#endif

