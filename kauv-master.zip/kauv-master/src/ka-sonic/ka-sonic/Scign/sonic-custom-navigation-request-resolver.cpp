
#include "sonic-custom-navigation-request-resolver.h"


USING_KANS(MoND_UI)


Sonic_Custom_Navigation_Request_Resolver::Sonic_Custom_Navigation_Request_Resolver()
  : navigation_recipient_(nullptr)
{

}

bool Sonic_Custom_Navigation_Request_Resolver::check_navigation(const QUrl& url)
{
 if(url == origin_url_)
 {
  return true;
 }
 if(navigation_recipient_)
 {
  Q_EMIT(navigation_requested(url, navigation_recipient_));
  return false;
 }
 else
 {
  return true;
 }

}
