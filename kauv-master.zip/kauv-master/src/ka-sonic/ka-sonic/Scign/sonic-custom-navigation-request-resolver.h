
#ifndef SONIC_CUSTOM_NAVIGATION_REQUEST_RESOLVER__H
#define SONIC_CUSTOM_NAVIGATION_REQUEST_RESOLVER__H

#include <QObject>

#include <QString>

#include "kans.h"

#include "accessors.h"

#include <QUrl>


namespace KA{ namespace MoND_UI{


class Sonic_Custom_Navigation_Request_Resolver : public QObject
{
 Q_OBJECT

 QObject* navigation_recipient_;

 QUrl origin_url_;

public:

 Sonic_Custom_Navigation_Request_Resolver();

 ACCESSORS(QObject* ,navigation_recipient)
 ACCESSORS(QUrl ,origin_url)


 bool check_navigation(const QUrl& url);

Q_SIGNALS:

 void navigation_requested(const QUrl&, QObject*);



};


} }

#endif
