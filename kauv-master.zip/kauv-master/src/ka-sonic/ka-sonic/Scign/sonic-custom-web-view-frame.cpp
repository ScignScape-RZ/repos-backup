
#include "sonic-custom-web-view-frame.h"

#include "sonic-custom-web-page.h"

//?#include "scign-web-page.h"

//#include "clg-db-antemodel.h";

#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>

#include <QGraphicsRectItem>
#include <QRubberBand>

#include <QPlainTextEdit>
#include <QTextStream>

#include <QTableWidget>

#include <QMessageBox>

#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrlQuery>

#include <QWebEngineProfile>

#include <QMenu>

#include <QHeaderView>

#include <QListWidget>
#include <QPrinter>

//#include "silotypes/ndp-project/ndp-project.h"
//#include "silotypes/ndp-project/ndp-project-initial.h"

#include "styles.h"

#include "sonic-custom-web-view.h"

#include "sonic-custom-navigation-request-resolver.h"


USING_KANS(MoND_UI)



QString Sonic_Custom_Web_View_Frame::load_file(QString path)
{
 QString result;
 QFile file(path);
 if(file.open(QFile::ReadOnly | QIODevice::Text))
 {
  result = file.readAll();
 }
 return result;
}


bool Sonic_Custom_Web_View_Frame::page_mouse_press_event(QMouseEvent* event)
{
 QPoint p = event->pos();


 if (!rubber_band_)
  rubber_band_ = new QRubberBand(QRubberBand::Rectangle, this);

 rubber_band_origin_ = p + custom_web_view_->pos();
 rubber_band_page_origin_ = p;

 rubber_band_->setGeometry(
   QRect( rubber_band_origin_, QSize(2, 2) ) );

 rubber_band_->show();
 return true;
}

bool Sonic_Custom_Web_View_Frame::page_mouse_release_event(QMouseEvent* event)
{
 QWebEnginePage* page = custom_web_view_->page();
 QString jscode = load_file(
   "/extension/medInria/medInria-public-master/mmui/cpp/src/mmui/medinria-mmui/paraviews/test.js"
   );

 rubber_band_page_end_ = event->pos();

 QPoint p = rubber_band_page_end_;// + custom_web_view_->pos();

// QPoint p1 = rubber_band_->rect().topLeft();
// QPoint p2 = rubber_band_->rect().bottomRight();

 int x1, x2, y1, y2;

 if(rubber_band_page_origin_.x() < rubber_band_page_end_.x())
 {
  x1 = rubber_band_page_origin_.x();
  x2 = rubber_band_page_end_.x();
 }
 else
 {
  x1 = rubber_band_page_end_.x();
  x2 = rubber_band_page_origin_.x();
 }

 if(rubber_band_page_origin_.y() < rubber_band_page_end_.y())
 {
  y1 = rubber_band_page_origin_.y();
  y2 = rubber_band_page_end_.y();
 }
 else
 {
  y1 = rubber_band_page_end_.y();
  y2 = rubber_band_page_origin_.y();
 }


 QString jscode_test_a = jscode + QString("elt = document.elementFromPoint(%1, %2); "
                                          "elt.tagName + ' ' + elt.href;")
   .arg(x1)
   .arg(y1)
   .arg(x2)
   .arg(y2);


 QString jscode0 = jscode + QString("elt = document.elementFromPoint(%1, %2); getWordAtPoint(elt, %1, %2, %3, %4)")
   .arg(x1)
   .arg(y1)
   .arg(x2)
   .arg(y2);


 page->runJavaScript(jscode_test_a + ";", [this, p, &page, jscode0] (const QVariant& v)
 {
  QString tn = v.toString();
  qDebug() << "TN: " << tn;
  if(tn.startsWith("a ") || tn.startsWith("A "))
  {
   QString href = tn.mid(2);
   show_href_context_menu(p, href);
  }

  else
  {
   page->runJavaScript(jscode0 + ";", [this, p] (const QVariant& v)
   {
    qDebug() << "P!: " << p;
    QString atr = v.toString();
    qDebug() << "W0: " << atr;
    if(!atr.isEmpty())
    {
     show_selection_menu(p, atr);
    }
    //qDebug() << "W0: " << atr;
   });
  }

 });

   //.arg(x1_).arg(y1_).arg(x1_).arg(y1_);

// QString w1;
// QString w2;


 rubber_band_->hide();


 return true;
}

bool Sonic_Custom_Web_View_Frame::page_mouse_move_event(QMouseEvent* event)
{
 QPoint p = event->pos();


 QPoint pp = p + custom_web_view_->pos();
 if(rubber_band_)
  rubber_band_->setGeometry(QRect(rubber_band_origin_, pp).normalized());
 return true;
}

void Sonic_Custom_Web_View_Frame::show_href_context_menu(QPoint p, QString href)
{
 //qDebug() << "ST: " << search_term;
 QMenu menu;

 //QString origin = current_url();

 menu.addAction(QString("Bookmark Link: %1").arg(href),
   [this, href]
 {
  Q_EMIT(bookmark_link_requested(current_url(), href));
 });

 menu.addAction(QString("Email Link"),
   [this, href]
 {
  Q_EMIT(email_link_requested(current_url(), href));
 });

 menu.addAction(QString("Share Link ..."),
   [this, href]
 {
  Q_EMIT(share_link_requested(current_url(), href));
 });

 menu.exec(mapToGlobal(p));

}

void Sonic_Custom_Web_View_Frame::show_selection_menu(QPoint p, QString search_term)
{
 //qDebug() << "ST: " << search_term;
 QMenu menu;
 menu.addAction(QString("Springer Search: %1").arg(search_term),
   [this, search_term]
 {
  //? restart_search(search_term, "SNOMED");
 });
 menu.addAction(QString("Share/Cite").arg(search_term),
   [this, search_term]
 {
  //? restart_search(search_term, "ICD-10-CM");
 });
 menu.addAction(QString("Bookmark").arg(search_term),
   [this, search_term]
 {
  //restart_search(search_term, "ICD-9-CM");
 });


 //?menu.addAction("Cancel");
 //?
 menu.exec(mapToGlobal(p));
 //?menu.exec(p);
}


void Sonic_Custom_Web_View_Frame::restart_search(QString search_term, QString where)
{
 QString addr = QString(
    "https://apps.nlm.nih.gov/medlineplus/services/mpconnect.cfm");

 QUrl url(addr);

 QNetworkRequest req;

 QUrlQuery urlq;

 if(where == "SNOMED")
 {
  urlq.addQueryItem("mainSearchCriteria.v.cs", "2.16.840.1.113883.6.96");
 }
 else if(where == "ICD-10-CM")
 {
  urlq.addQueryItem("mainSearchCriteria.v.cs", "2.16.840.1.113883.6.96");
 }
 else if(where == "ICD-9-CM")
 {
  urlq.addQueryItem("mainSearchCriteria.v.cs", "2.16.840.1.113883.6.103");
 }

 // SNOMED
  //urlq.addQueryItem("mainSearchCriteria.v.cs", "2.16.840.1.113883.6.96");

 // ICD-10-CM
  // urlq.addQueryItem("mainSearchCriteria.v.cs", "2.16.840.1.113883.6.90");
 // ICD-9-CM
 //urlq.addQueryItem("mainSearchCriteria.v.cs", "2.16.840.1.113883.6.103");



 //  drug ...
 //For RXCUI use:
 //    mainSearchCriteria.v.cs=2.16.840.1.113883.6.88

 //For NDC use:
 //    mainSearchCriteria.v.cs=2.16.840.1.113883.6.69

 //Identify the actual code you are trying to look up. (Preferred for English, Required for Spanish)
 //mainSearchCriteria.v.c=637188
 //Identify the name of the drug with a text string. (Optional for English, Not used for Spanish)
 //mainSearchCriteria.v.dn=Chantix 0.5 MG Oral Tablet


// LAB
// For LOINC use:
 //    mainSearchCriteria.v.cs=2.16.840.1.113883.6.1

// MedlinePlus Connect will also accept:
 //    mainSearchCriteria.v.cs=2.16.840.1.113883.11.79

// Identify the actual code you are trying to look up.
// mainSearchCriteria.v.c=3187-2

 //?Identify the name/title of the lab test. However, this information does not impact the response. mainSearchCriteria.v.dn=Factor IX assay


 //?urlq.addQueryItem("mainSearchCriteria.v.c", "250.33");
 //?urlq.addQueryItem("mainSearchCriteria.v.dn", "Diabetes mellitus with other, type uncontrolled");

 urlq.addQueryItem("mainSearchCriteria.v.dn", search_term);

 urlq.addQueryItem("informationRecipient.languageCode.c", "en");

 url.setQuery(urlq);

 //req.setUrl(url);

 load_new_url(url, url.toString());


 //qDebug() << "ST: " << search_term;
}


//void Sonic_Custom_Web_View_Frame::mousePressEvent(QMouseEvent* event)
//{
// QPoint dragPosition = event->pos();
// if (!rubber_band_)
//     rubber_band_ = new QRubberBand(QRubberBand::Rectangle, this);
// rubber_band_->setGeometry(QRect(dragPosition, QSize()));
// rubber_band_->show();

//}

//void Sonic_Custom_Web_View_Frame::mouseReleaseEvent(QMouseEvent* event)
//{
// if(event->button() == Qt::RightButton)
// {
//  QPoint qp = event->pos();
//  QRectF rect = QRectF(rubber_band_->pos(), rubber_band_->size());

//  qDebug() << "RECT: " << rect;
// }
//}

QString Sonic_Custom_Web_View_Frame::current_url()
{
 return custom_web_view_->url().toString();
}


Sonic_Custom_Web_View_Frame::Sonic_Custom_Web_View_Frame(QString url,
  QWidget* parent)//, QString url, QWN_XMLDB_Configuration* config)
 : QFrame(parent),
   context_menu_rubber_band_(nullptr), rubber_band_(nullptr),
   rubber_band_progression_(0), current_navigation_request_resolver_(nullptr),

   x1_(0), x2_(0), y1_(0), y2_(0)

   //, config_(config)
{
 main_layout_ = new QVBoxLayout();

 custom_web_view_ = new Sonic_Custom_Web_View(this);
 //?custom_web_view_ = new QWebEngineView(this);

 url_label_  = new QLabel("URL", this);
 url_line_edit_ = new QLineEdit(this);

// connect(custom_web_view_, &QWebEngineView::,
//  [this](const QUrl& url)
// {

// });

 connect(custom_web_view_, &QWebEngineView::urlChanged,
  [this](const QUrl& url)
 {
  url_line_edit_->setText(url.toString());
  url_line_edit_->setCursorPosition(0);
 });

 url_layout_ = new QHBoxLayout;
 url_layout_->addWidget(url_label_);
 url_layout_->addWidget(url_line_edit_);

 main_layout_->addWidget(custom_web_view_);
 main_layout_->addLayout(url_layout_);

 QString colorful_button_style_sheet = colorful_button_style_sheet_();
 QString colorful_button_style_sheet_down = colorful_button_style_sheet_down_();

 go_button_ = new QPushButton("Go", this);
 close_button_ = new QPushButton("Close", this);

 go_button_->setStyleSheet(colorful_button_style_sheet);
 close_button_->setStyleSheet(colorful_button_style_sheet);

 go_button_layout_ = new QHBoxLayout;
 go_button_layout_->addStretch();
 go_button_layout_->addWidget(go_button_);
 go_button_layout_->addStretch();

 main_layout_->addLayout(go_button_layout_);

 close_button_layout_ = new QHBoxLayout;
 close_button_layout_->addStretch();
 close_button_layout_->addWidget(close_button_);
 close_button_layout_->addStretch();

 default_profile_ = new QWebEngineProfile;

 connect(default_profile_, SIGNAL(downloadRequested(QWebEngineDownloadItem*)),
   this, SLOT(handle_page_download_requested(QWebEngineDownloadItem*)));

 main_layout_->addLayout(close_button_layout_);

 connect(go_button_, SIGNAL(clicked()), this,
         SLOT(go_button_clicked()));

 connect(close_button_, SIGNAL(clicked()), this,
         SLOT(close_button_clicked()));

 setLayout(main_layout_);

 if(!url.isEmpty())
 {
  load_url(url);
  url_line_edit_->setText(url);
 }

 show();
}


void Sonic_Custom_Web_View_Frame::handle_page_download_finished()
{
 QWebEngineDownloadItem* item = qobject_cast<QWebEngineDownloadItem*>(sender());

 QString mt = item->mimeType();
 QString p = item->path();

 Q_EMIT(page_download_finished(mt, p));

}

void Sonic_Custom_Web_View_Frame::handle_page_download_requested(QWebEngineDownloadItem* item)
{
 //? https://citation-needed.springer.com/v2/references/10.1007/s10606-017-9277-x?format=refman&flavour=citation

// QString url = item->url().toString();
// QString p = item->path();

 QString mt = item->mimeType();

 if(mt == "application/x-research-info-systems")
 {
  item->setPath("/ext_root/fbreader/books/ris");
  item->accept();

  connect(item, SIGNAL(finished()),
    this, SLOT(handle_page_download_finished()));
 }

// qDebug() << "Download URL, Path, Mime Type: " << url << ", " << p << ", " << mt;



 //item->



}

void Sonic_Custom_Web_View_Frame::register_navigation_request_resolver(Sonic_Custom_Navigation_Request_Resolver* scnrr)
{
 current_navigation_request_resolver_ = scnrr;

 Sonic_Custom_Web_Page* swp = qobject_cast<Sonic_Custom_Web_Page*>(custom_web_view_->page());

 if(swp)
 {
  swp->set_navigation_request_resolver(scnrr);
 }

 //custom_web_view_->register_navigation_request_resover(scnrr);
}

void Sonic_Custom_Web_View_Frame::load_url(const QUrl& url)
{
 Sonic_Custom_Web_Page* swp = new Sonic_Custom_Web_Page(this, default_profile_);

 if(current_navigation_request_resolver_)
 {
  swp->set_navigation_request_resolver(current_navigation_request_resolver_);
 }

 custom_web_view_->setPage(swp);
 custom_web_view_->load(url);
}

void Sonic_Custom_Web_View_Frame::load_url(QString url)
{
 Sonic_Custom_Web_Page* swp = new Sonic_Custom_Web_Page(this, default_profile_);
 custom_web_view_->setPage(swp);
 custom_web_view_->load(QUrl(url));
}

void Sonic_Custom_Web_View_Frame::load_new_url(QUrl url, QString url_text)
{
 url_line_edit_->setText(url_text);
 url_line_edit_->setCursorPosition(0);
 custom_web_view_->load(url);
}


void Sonic_Custom_Web_View_Frame::load_local_file(QString path)
{
 QString url = QString("file://%1").arg(path);
 url_line_edit_->setText(url);
 load_url(url);
}


void Sonic_Custom_Web_View_Frame::go_button_clicked()
{
 QString url = url_line_edit_->text();
 custom_web_view_->load(QUrl(url));
}

void Sonic_Custom_Web_View_Frame::close_button_clicked()
{
}

Sonic_Custom_Web_View_Frame::~Sonic_Custom_Web_View_Frame()
{
}


