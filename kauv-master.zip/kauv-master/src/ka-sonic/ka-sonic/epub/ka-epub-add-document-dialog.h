

#ifndef KA_EPUB_ADD_DOCUMENT_DIALOG__H
#define KA_EPUB_ADD_DOCUMENT_DIALOG__H

#include <QObject>

#include <QMetaType>

#include <QList>
#include <QGraphicsScene>
#include <QPoint>

#include <QDialog>
#include <QToolBar>

#include "accessors.h"

//?#include "Scign/sonic-custom-web-view-frame.h"


class QDialogButtonBox;
class QLabel;
class QLineEdit;
class QTabWidget;
class QPlainTextEdit;
class QTextEdit;
class QFrame;
class QHBoxLayout;
class QVBoxLayout;
class QSlider;
class QLineEdit;
class QBoxLayout;
class QButtonGroup;
class QGroupBox;
class QFormLayout;
class QComboBox;
class QDateEdit;

//?USING_KANS(MoND_UI)


class KA_EPub_Add_Document_Dialog : public QDialog
{

Q_OBJECT

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QPushButton* button_proceed_;


 QVBoxLayout* main_layout_;

 QHBoxLayout* unzip_layout_;

 QFormLayout* path_info_layout_;

 void parse_file(QString path);

 QString epub_file_path_;
 QString epub_folder_path_;

 QLineEdit* epub_file_path_line_edit_;
 QLineEdit* epub_folder_path_line_edit_;

 //?QString data_ecl_path_;

 QPushButton* unzip_button_;

public:

 ACCESSORS(QString ,epub_file_path)
 ACCESSORS(QString ,epub_folder_path)

 //?ACCESSORS(QString ,data_ecl_path)


 KA_EPub_Add_Document_Dialog(QString file, QWidget* parent = nullptr);

 ~KA_EPub_Add_Document_Dialog();


Q_SIGNALS:

 void canceled(QDialog*);
 void accepted(QDialog*);
 void unzip_requested();

 //?void proceed_requested(KA_Sonic_FB2_Dialog*);


public Q_SLOTS:

 //void extract_requested();
 void accept();
 void cancel();

 void proceed();

};


#endif  // KA_EPUB_ADD_DOCUMENT_DIALOG__H

