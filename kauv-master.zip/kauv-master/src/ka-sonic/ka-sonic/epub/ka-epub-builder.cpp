
#include "ka-epub-builder.h"

#include "ka-sonic-epub-document.h"

#include <QDebug>


KA_EPub_builder::KA_EPub_builder()
 :  epub_document_(new KA_Sonic_EPub_Document),
    read_state_(Read_State::Initial)
{
}


KA_EPub_builder::KA_EPub_builder(const KA_EPub_builder& rhs)
  :  epub_document_(rhs.epub_document_),
     read_state_(rhs.read_state_)
{

}

KA_EPub_builder::~KA_EPub_builder()
{

}

void KA_EPub_builder::check_construction()
{
 qDebug() << "CC OK";
}


void KA_EPub_builder::absorb_attr(QString attr, QString value)
{

}

void KA_EPub_builder::Tag_title(QString ns, QString str)
{
 epub_document_->metadata().set_title(str);
}

void KA_EPub_builder::Tag_date(QString ns, QString str)
{
 epub_document_->metadata().set_date(str);
}

void KA_EPub_builder::Tag__metadata()
{
 read_state_ = Read_State::Metadata;
}

void KA_EPub_builder::Tag_identifier(QString ns, const QMap<QString, QString>& attrs)
{

}

void KA_EPub_builder::Tag_meta(const QMap<QString, QString>& attrs)
{

}

//void KA_EPub_builder::Tag_title_info(QString str)
//{
// epub_document_->set_book_title(str);
//}

void KA_EPub_builder::Tag_description(QString str)
{
 //?epub_document_->set_description(str);
}

void KA_EPub_builder::Tag_creator(QString ns, QString str)
{
 epub_document_->metadata().set_author(str);
 //?epub_document_->set_author(str);
}

void KA_EPub_builder::Tag_last_name(QString str)
{
 //?epub_document_->set_last_name(str);
}

//void KA_EPub_builder::Tag_book_title(QString str)
//{
// epub_document_->set_book_title(str);
//}

void KA_EPub_builder::Tag_language(QString ns, QString str)
{
 static QMap<QString, QString> language_names {{
   {"en", "English"}
                                               }};

 epub_document_->metadata().set_language(language_names.value(str, str));
}

void KA_EPub_builder::Tag_item(const QMap<QString, QString>& attrs)
{
 epub_document_->add_spine_item(attrs["id"],
   attrs["href"], attrs["media-type"]);
}
