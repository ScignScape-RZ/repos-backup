
#include "ka-epub-metadata-content.h"

KA_EPub_Metadata_Content::KA_EPub_Metadata_Content()
{

}

