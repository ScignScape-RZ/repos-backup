 
#include "ka-epub-spine-item.h"

KA_EPub_Spine_Item::KA_EPub_Spine_Item()
{

}
