
#include "ka-sonic-epub-book-info-dialog.h"


#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>

#include <QGraphicsRectItem>
#include <QRubberBand>

#include <QPlainTextEdit>
#include <QTextStream>

#include <QTableWidget>

#include <QMessageBox>

#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrlQuery>

#include <QMenu>

#include <QHeaderView>

#include <QListWidget>
#include <QPrinter>

//#include "silotypes/ndp-project/ndp-project.h"
//#include "silotypes/ndp-project/ndp-project-initial.h"

#include "styles.h"

#include "ka-sonic-epub-document.h"


//?USING_RZNS(MoND_UI)


KA_Sonic_EPub_Book_Info_Dialog::KA_Sonic_EPub_Book_Info_Dialog
  (KA_Sonic_EPub_Document* main_document, QWidget* parent)
  :  QDialog(parent), main_document_(main_document)
{
 setWindowTitle("EPub Book Info");

 button_box_ = new QDialogButtonBox(this);

 button_ok_ = new QPushButton("OK");
 button_proceed_ = new QPushButton("Proceed");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

 button_proceed_->setDefault(false);
 button_proceed_->setAutoDefault(false);

 button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);


 connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));

 button_ok_->setStyleSheet(button_close_light_style_sheet_());
 button_proceed_->setStyleSheet(button_close_light_style_sheet_());
 button_cancel_->setStyleSheet(button_close_light_style_sheet_());

// QString colorful_button_style_sheet = colorful_button_style_sheet_();
// QString colorful_button_style_sheet_down = colorful_button_style_sheet_down_();

 main_layout_ = new QVBoxLayout;

 title_line_edit_ = new QLineEdit(this);
 author_line_edit_ = new QLineEdit(this);
 language_line_edit_ = new QLineEdit(this);
 date_line_edit_ = new QLineEdit(this);

 main_info_layout_ = new QFormLayout;

 main_info_layout_->addRow("Title:", title_line_edit_);
 main_info_layout_->addRow("Author:", author_line_edit_);
 main_info_layout_->addRow("Language:", language_line_edit_);
 main_info_layout_->addRow("Date:", date_line_edit_);

 if(main_document_)
 {
  KA_EPub_Metadata_Content& metadata = main_document_->metadata();

  title_line_edit_->setText(metadata.title());
  author_line_edit_->setText(metadata.author());

  language_line_edit_->setText(metadata.language());
  date_line_edit_->setText(metadata.date());

 }


 main_layout_->addLayout(main_info_layout_);

 main_layout_->addWidget(button_box_);
 setLayout(main_layout_);


 show();
}



//Sonic_Web_View_Dialog::Sonic_Web_View_Dialog()
// // : parent_(nullptr), antemodel_(nullptr)
//{

//}
//Sonic_Web_View_Dialog::Sonic_Web_View_Dialog(const Sonic_Web_View_Dialog& rhs)
// // : setP(rhs.parent_), antemodel_(rhs.antemodel_)
//{

//}

KA_Sonic_EPub_Book_Info_Dialog::~KA_Sonic_EPub_Book_Info_Dialog()
{
 delete button_ok_;
 delete button_proceed_;
 delete button_cancel_;

// delete url_label_;
// delete name_qle_;
}



void KA_Sonic_EPub_Book_Info_Dialog::cancel()
{
 Q_EMIT(canceled(this));
 Q_EMIT(rejected());
 close();
// close();
}

void KA_Sonic_EPub_Book_Info_Dialog::accept()
{
 Q_EMIT(accepted(this));
// close();
}

