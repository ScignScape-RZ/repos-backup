
#ifndef KA_SONIC_EPUB_BOOK_INFO_DIALOG__H
#define KA_SONIC_EPUB_BOOK_INFO_DIALOG__H


#include <QString>
#include <QMainWindow>

#include <QTextEdit>
//?#include <QWebView>

#include <QWebEngineView>
#include <QLabel>
#include <QPushButton>

#include <QDialog>

#include <QApplication>

#include <QComboBox>

#include "accessors.h"

#include "flags.h"

#include "rzns.h"

#include <QEvent>
#include <QMouseEvent>

//#include "incident-form-dialog.h"

class QPushButton;
class QTextEdit;
class QPlainTextEdit;
class QLineEdit;
class QTabWidget;
class QDialogButtonBox;
class QVBoxLayout;
class QHBoxLayout;
class QCheckBox;
class QFormLayout;
class QSplitter;
class QGridLayout;
class QListWidget;
class QTableWidget;
class QScrollArea;
class QGroupBox;
class QTableWidgetItem;
class QGraphicsRectItem;
class QRubberBand;

class KA_Sonic_EPub_Document;

class KA_Sonic_EPub_Book_Info_Dialog : public QDialog
{
 Q_OBJECT

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QPushButton* button_proceed_;

 QVBoxLayout* main_layout_;

 QFormLayout* main_info_layout_;

// QString author_;
// QString title_;
// QString language_;
// QString date_;

 QLineEdit* author_line_edit_;
 QLineEdit* title_line_edit_;
 QLineEdit* language_line_edit_;
 QLineEdit* date_line_edit_;


 KA_Sonic_EPub_Document* main_document_;

public:

 KA_Sonic_EPub_Book_Info_Dialog(KA_Sonic_EPub_Document* main_document, QWidget* parent = nullptr);

 ~KA_Sonic_EPub_Book_Info_Dialog();


Q_SIGNALS:
 void canceled(QDialog*);
 void accepted(QDialog*);


public Q_SLOTS:
 void accept();
 void cancel();
 //?void proceed();


};

//?} } //_RZNS(MMUI)



#endif

