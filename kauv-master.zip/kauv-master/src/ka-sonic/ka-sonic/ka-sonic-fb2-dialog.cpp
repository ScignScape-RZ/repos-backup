
#include "ka-sonic-fb2-dialog.h"


//?
#include "styles.h"


#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QButtonGroup>
#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>
#include <QComboBox>

#include <QTimer>
#include <QScreen>

#include <QDateEdit>

#include <QLineEdit>
#include <QTextStream>

#include <QPainter>
#include <QPushButton>
#include <QLabel>

#include <QPlainTextEdit>

#include <QTableWidget>
#include <QGraphicsPixmapItem>

#include <QMessageBox>
#include <QDebug>

#include <QGraphicsView>


#include <QHeaderView>

#include <QMenu>
#include <QAction>

#include <QListWidget>
#include <QDateEdit>


#include <QXmlStreamReader>
#include <QXmlStreamEntityResolver>

#include "ka-xml-to-ecl-converter.h"


void KA_Sonic_FB2_Dialog::take_screenshot()
{
 QScreen* screen = QGuiApplication::primaryScreen();
  if (!screen)
      return;
 QApplication::beep();

 //medMainWindow* mainWindow = qobject_cast <medMainWindow *> (parent());


 int target_window_id  = this->winId();

 QTimer::singleShot(10000, [=]
 {
  QPixmap pixmap = screen->grabWindow(target_window_id);

  QString path = "/ext_root/fbreader/screenshots/sonic.png";

  qDebug() << "Saving to path: " << path;
  QFile file(path);
  if(file.open(QIODevice::WriteOnly))
  {
   pixmap.save(&file, "PNG");
  }
 });
}




KA_Sonic_FB2_Dialog::KA_Sonic_FB2_Dialog(QString file, QWidget* parent)
 : QDialog(parent)
{
 KA_XML_To_ECL_Converter x2e;

 x2e.set_xml_file_path(file);

 x2e.set_document_ecl_path(file + ".doc.ecl");
 x2e.set_metadata_ecl_path(file + ".md.ecl");

 x2e.set_document_html_path(file + ".doc.html");

 x2e.set_root_tag_name("FictionBook");
 x2e.set_document_tag_name("body");
 x2e.add_object_tag("FictionBook");

 x2e.run_conversion();

 metadata_ecl_path_ = x2e.metadata_ecl_path();
 document_ecl_path_ = x2e.document_ecl_path();
 document_html_path_ = x2e.document_html_path();

// Q_EMIT(metadata_file_ready(x2e.metadata_ecl_path()));
// Q_EMIT(document_file_ready(x2e.document_ecl_path()));
// Q_EMIT(proceed_requested(this));

 //parse_file(file);

 button_box_ = new QDialogButtonBox(this);

 button_ok_ = new QPushButton("OK");
 button_proceed_ = new QPushButton("Proceed");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

 button_proceed_->setDefault(false);
 button_proceed_->setAutoDefault(false);
 //?button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);


 QString colorful_button_style_sheet = colorful_button_style_sheet_();

 QString colorful_toggle_button_style_sheet = colorful_button_quiet_style_sheet_(); //colorful_toggle_button_style_sheet_();


 QString colorful_button_style_sheet_down = colorful_button_style_sheet_down_();
 QString colorful_button_quiet_style_sheet = colorful_button_quiet_style_sheet_();

 QString tab_style_sheet = tab_style_sheet_();

 QString button_close_style_sheet = //?button_close_style_sheet_();

  " QPushButton:hover {background:rgb(150,240,190);"
  "  border-left: 4px groove rgb(150,240,190); "
  "  border-right: 4px ridge rgb(150,240,190); "
  " }\n "

  " QPushButton { background:rgb(220,220,230); "
  "  border: 2px groove rgb(0,90,50); "
  "  font-family:\"Comic Sans MS\", cursive, sans-serif; "
  "  border-bottom: 2px groove rgb(240,190,150); "
  "  border-top: 2px groove rgb(240,90,150); "
  "  border-radius: 10px; font-weight:600; color:rgb(0, 90, 105); "
  "  padding-left:16px;padding-right:16px;padding-top:2px;padding-bottom:2px; "

//   " border-left: 4px groove rgb(0,190,150);   "
//   " border-right: 4px ridge rgb(240,190,150); "

  " }\n"

  " QPushButton[enabled=false] { color:grey; } "



  " QPushButton:pressed{ color:black; padding:1px; "
  "  border: 1px solid rgb(150,240,190); "
  "  border-bottom: 1px solid #CEF51D; "
  "  border-radius: 0px; "
  "  background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, "
  "   stop: 0 white, stop: 0.1 #C0C0C0, stop: 0.6 #C6CCBC "
  "   stop: 0.8 #A0ECCF, stop: 0.9 darkseagreen,  stop: 1 blue"
  "  ); min-width: 80px; } ";


 QString basic_button_style_sheet = basic_button_style_sheet_();





 button_ok_->setStyleSheet(button_close_style_sheet);
 button_proceed_->setStyleSheet(button_close_style_sheet);
 button_cancel_->setStyleSheet(button_close_style_sheet);


 connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));


 main_tool_bar_ = new QToolBar;


 QString icon_root = "/ext_root/fbreader/FBReader-master/fbreader/data/icons/toolbar/desktop/";

// QString ic = icon_root + "addBook.png";
// QPixmap icon(ic);
// show_preferences_action_ = new QAction(QPixmap(icon_root + "preferences.png"), "Preferences");
// show_reading_action_ = new QAction(QPixmap(icon_root + "showLibrary.png"), "Library");
// show_library_action_ = new QAction(QPixmap(icon_root + "showReading.png"), "Reading");


 add_book_action_ = main_tool_bar_->addAction(QPixmap(icon_root + "addBook.png"), "Add Book", []
 {

 });


 book_info_action_ = main_tool_bar_->addAction(QPixmap(icon_root + "bookInfo.png"), "Book Info", []
 {

 });

 show_preferences_action_ = main_tool_bar_->addAction(QPixmap(icon_root + "preferences.png"), "Preferences", []
 {

 });

 show_library_action_ = main_tool_bar_->addAction(QPixmap(icon_root + "showLibrary.png"), "Library", []
 {

 });

 show_reading_action_ = main_tool_bar_->addAction(QPixmap(icon_root + "showReading.png"), "Reading", []
 {

 });

 show_reading_action_->setToolTip("Show Reading");

 main_tool_bar_->setIconSize(QSize(30, 50));
 main_tool_bar_->setToolButtonStyle( Qt::ToolButtonTextUnderIcon );

 main_tool_bar_->setContextMenuPolicy(Qt::CustomContextMenu);

 connect(main_tool_bar_, &QToolBar::customContextMenuRequested,
        [this](const QPoint& pos)
 {
  QMenu* menu = new QMenu(this);

  QAction* take_screenshot_action = menu->addAction("Take Screenshot");

  connect(take_screenshot_action, &QAction::triggered,
    [this]
  {
   take_screenshot();
   //Q_EMIT( view_item_requested(index) );
  });

  QPoint g = main_tool_bar_->mapToGlobal(pos);

  menu->popup(g);

  //qDebug() << "POS: " << pos;
  //QMenu qm
 } );

 main_layout_ = new QVBoxLayout();

 custom_web_view_frame_ = new Sonic_Custom_Web_View_Frame("", this);

 main_layout_->addWidget(main_tool_bar_);

 custom_pdf_view_frame_ = new QFrame(this);
 html_source_frame_ = new QFrame(this);
 css_frame_ = new QFrame(this);
 lisp_source_frame_ = new QFrame(this);
 xml_source_frame_ = new QFrame(this);


 main_tab_widget_ = new QTabWidget(this);

 main_tab_widget_->addTab(custom_pdf_view_frame_, "PDF");
 main_tab_widget_->addTab(custom_web_view_frame_, "HTML");

 main_tab_widget_->addTab(html_source_frame_, "HTML Source");
 main_tab_widget_->addTab(lisp_source_frame_, "Lisp");
 main_tab_widget_->addTab(css_frame_, "CSS");
 main_tab_widget_->addTab(xml_source_frame_, "XML");

 main_layout_->addWidget(main_tab_widget_);

 custom_web_view_frame_->load_local_file(document_html_path_);

//? main_notebook_ = new QTabWidget(this);
//? main_notebook_->setStyleSheet(tab_style_sheet);
//? main_layout_->addWidget(main_notebook_);

 main_layout_->addWidget(button_box_);

 //?main_layout_->addLayout(clear_button_layout_);

 setLayout(main_layout_);

 show();
}



KA_Sonic_FB2_Dialog::~KA_Sonic_FB2_Dialog()
{
 delete button_ok_;
 delete button_proceed_;
 delete button_cancel_;

// delete url_label_;
// delete name_ qLe_;
}



void KA_Sonic_FB2_Dialog::cancel()
{
 Q_EMIT(rejected());
 Q_EMIT(canceled(this));
 Q_EMIT(rejected());
 close();
//
 close();
}

void KA_Sonic_FB2_Dialog::proceed()
{
 Q_EMIT(proceed_requested(this));
}


void KA_Sonic_FB2_Dialog::accept()
{
 Q_EMIT(accepted(this));
// close();
}



