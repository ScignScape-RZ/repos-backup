
//#ifndef RZ_GENERIC_PARSER__H
//#define RZ_GENERIC_PARSER__H

////#include "rz-parser/rz-regex.h"
////#include "rz-parser/rz-parser.h"

//#include "methodic.h"

//class RZ_Document_Graph;

//struct RZ_Generic_Galaxy
//{
// typedef void tGraph;

//};


//class RZ_Generic_Parser : public RZ_Parser<RZ_Generic_Galaxy>
//{

//public:
// RZ_Generic_Parser(void* v);

//};

////#include "rz-parser/rz-regex.h"
////#include "rz-parser/rz-parser.h"

////#include "rz-text-typedefs.h"

////class RZ_Text_Parser : public RZ_Parser<RZ_Text_Galaxy>
////{
////public:
//// RZ_Text_Parser(RZ_Text_Graph* g);
//// void set_raw_text(QString s);


////};

////typedef RZ_Parser<RZ_Text_Galaxy> RZ_Text_Parser;

//#endif
