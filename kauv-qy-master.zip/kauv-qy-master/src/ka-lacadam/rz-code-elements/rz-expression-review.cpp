
#include "rz-expression-review.h"

#include "rzns.h"


USING_RZNS(GVal)

RZ_Expression_Review::RZ_Expression_Review()
  :  node_(nullptr)
{
}

void RZ_Expression_Review::add_text(QString str)
{
 text_ += str + " ";
}
