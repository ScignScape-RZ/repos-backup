
#include "rz-dynamo-output.h"
#include "rzns.h"

#include "rz-dynamo-block.h"

USING_RZNS(GVal)

RZ_Dynamo_Output::RZ_Dynamo_Output(RZ_Lisp_Graph_Visitor_Dynamo& visitor_dynamo)
  :  visitor_dynamo_(visitor_dynamo), top_level_block_(nullptr)
{
 //?init_function_def_syntax();
}

void RZ_Dynamo_Output::init_function_def_syntax()
{
 //?function_def_syntax_.flags.type_before_symbol = true;
 //?function_def_syntax_.set_argument_default_type("auto");
}

void RZ_Dynamo_Output::init_top_level_block()
{
 top_level_block_ = new RZ_Dynamo_Block();
}


void RZ_Dynamo_Output::write(QTextStream& qts)
{
 if(top_level_block_)
 {
  top_level_block_->scan_top_level(visitor_dynamo_);
  top_level_block_->write(qts);
 }
 //if(caon_ptr<RE_Node> start_node = )
}
