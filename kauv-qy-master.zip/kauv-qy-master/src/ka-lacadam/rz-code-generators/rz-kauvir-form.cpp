
#include "rz-kauvir-form.h"
#include "rz-kauvir-block.h"

#include "rz-graph-core/code/rz-re-block-entry.h"

#include "rz-graph-valuer/scope/rz-lisp-graph-block-info.h"

#include "rzns.h"

USING_RZNS(GVal)

RZ_Kauvir_Form::RZ_Kauvir_Form(caon_ptr<RZ_Kauvir_Form> parent)
  :  parent_(parent), parent_lambda_position_(-1), implicit_added_depth_(0)
{

}

RZ_Kauvir_Form::RZ_Kauvir_Form(caon_ptr<RZ_Kauvir_Block> block)
  :  parent_(nullptr), plene_block_(block), implicit_added_depth_(0)
{

}

void RZ_Kauvir_Form::write_as_statement(QTextStream& qts)
{
 qts << "\n;statement_\n";
 write(qts);
 qts << "\n ;_statement\n";
 //if(caon_ptr<RE_Node> start_node = )
}

void RZ_Kauvir_Form::write(QTextStream& qts)
{
 QString icd = QString(implicit_added_depth_, '(');

 qts << icd;

 if(plene_block_)
 {
  qts << "\n;block_\n";

  if(caon_ptr<RE_Block_Entry> rbe = plene_block_->get_block_entry())
  {
   if(rbe->flags.if_block)
   {
    qts << "(progn \n";
   }
  }
  else
  {
   // so get info plene_block_ mode ...

   switch(plene_block_->block_sequence_mode())
   {
   case RZ_Kauvir_Block::Block_Sequence_Modes::Ghost:
    qts << "(progn\n";
    break;

   default:
    qts << "(lambda (ks)\n";
    break;


   }
  }

  plene_block_->write(qts);
 }
 else
 {
  qts << '(';
 }


 for(QPair<caon_ptr<RZ_Kauvir_Form>, QString> element : inner_elements_)
 {
  if(element.first)
  {
   caon_ptr<RZ_Kauvir_Form> ef = element.first;
   CAON_PTR_DEBUG(RZ_Kauvir_Form ,ef)

   qts << ' ';

   element.first->write(qts);
   qts << ' ';
  }
  else
  {
   qts << element.second << " ";
  }
 }
 if(plene_block_)
 {
  qts << "\n;_block/progn\n";
  qts << ")\n";
 }
 else
 {
  qts << ')';
 }
 //if(caon_ptr<RE_Node> start_node = )
}

void RZ_Kauvir_Form::add_string_token(QString tok)
{
 inner_elements_.push_back({nullptr, tok});
}

void RZ_Kauvir_Form::add_expression(caon_ptr<RZ_Kauvir_Form> form)
{
 inner_elements_.push_back({form, QString()});
}

void RZ_Kauvir_Form::add_nested_block(caon_ptr<RZ_Kauvir_Block> block)
{
 caon_ptr<RZ_Kauvir_Form> form = new RZ_Kauvir_Form(block);
 inner_elements_.push_back({form, QString()});
}

