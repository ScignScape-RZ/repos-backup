
#include "rz-kauvir-output.h"
#include "rzns.h"

#include "rz-code-generators/rz-kauvir-block.h"

USING_RZNS(GVal)

RZ_Kauvir_Output::RZ_Kauvir_Output(RZ_Lisp_Graph_Visitor_Kauvir& visitor_kauvir)
  :  visitor_kauvir_(visitor_kauvir), top_level_block_(nullptr)
{
 //?init_function_def_syntax();
}

void RZ_Kauvir_Output::init_function_def_syntax()
{
 //?function_def_syntax_.flags.type_before_symbol = true;
 //?function_def_syntax_.set_argument_default_type("auto");
}

void RZ_Kauvir_Output::init_top_level_block()
{
 top_level_block_ = new RZ_Kauvir_Block();
}


void RZ_Kauvir_Output::write(QTextStream& qts)
{
 if(top_level_block_)
 {
  top_level_block_->scan_top_level(visitor_kauvir_);
  top_level_block_->write(qts);
 }
 //if(caon_ptr<RE_Node> start_node = )
}
