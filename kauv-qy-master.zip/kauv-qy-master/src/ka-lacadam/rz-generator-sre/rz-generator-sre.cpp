
#include "rz-generator-sre.h"

#include "rz-graph-visit/rz-lisp-graph-visitor.h"
#include "rz-graph-visit/rz-lisp-graph-visitor-run-state.h"

#include "rz-graph-visit/rz-lisp-graph-visitor-clasp.h"


#include "rzns.h"
USING_RZNS(RECore)



RZ_Generator_Sre::RZ_Generator_Sre(RZ_Lisp_Graph_Visitor& visitor)
 : visitor_(visitor), visitor_clasp_(new RZ_Lisp_Graph_Visitor_Clasp(visitor)),
   run_state_(visitor_clasp_->run_state())
{
 //visitor_clasp_ = new RZ_Lisp_Graph_Visitor_Clasp(visitor);
}

void RZ_Generator_Sre::load_sre_token(RZ_SRE_Token& sre_token, caon_ptr<RZ_Clasp_Source_Element>& current_source_element)
{
 current_source_element = visitor_clasp_->get_current_sre_token(sre_token);
}

void RZ_Generator_Sre::advance()
{
 visitor_clasp_->advance();
 //?visitor_.advance();
}

void RZ_Generator_Sre::init()
{
 begin();
 visitor_clasp_->reset();
 //visitor().reset();
}

void RZ_Generator_Sre::begin()
{
 //?visitor().reset();
}


RZ_Read_Table_State RZ_Generator_Sre::read_table_state()
{
 return run_state_.read_table_state();
}

RZ_Read_Table_Post_Advance_State RZ_Generator_Sre::post_advance_state()
{
 return run_state_.post_advance_state();
}



