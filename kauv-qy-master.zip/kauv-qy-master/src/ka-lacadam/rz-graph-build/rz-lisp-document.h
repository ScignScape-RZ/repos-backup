
#ifndef RZ_LISP_DOCUMENT__H
#define RZ_LISP_DOCUMENT__H

#include <QString>
#include <QFile>
#include <QTextStream>
#include <QMap>

#include "rz-graph-core/kernel/document/rz-re-document.h"


#include "accessors.h"

//#include "graph/rz-lisp-graph.h"
//#include "query/rz-lisp-query.h"

#include "rzns.h"

USING_RZNS(RECore)

RZNS_(GBuild)

//class RZ_Lisp_Graph;
//class RZ_Lisp_Parser;
//class RZ_Lisp_Graph_Build;
//class RZ_Lisp_Grammar;


class RZ_Lisp_Document
{
 QString raw_text_;

 //QString path_;

 RE_Document& re_document_;

 // RZ_Lisp_Graph* graph_;
// RZ_Lisp_Parser* parser_;
// RZ_Lisp_Graph_Build* graph_build_;
// RZ_Lisp_Grammar* grammar_;

 QString data_layer_;

// int number_of_lines_;

 QMap<int, QString> comments_by_line_;
 typedef QMap<int, QString> comments_by_line_type;


 //typedef RZ_Lisp_Graph::tNode tNode;
 typedef RE_Node tNode;
// QString generated_code_;

// RZ_Lisp_Query clq;

// void generate_lisp_code(tNode* start_node, QString& code);
// void generate_lisp_sequence(tNode* start_node, QString& code);

public:

 ACCESSORS(QString ,raw_text)
// ACCESSORS(QString ,path)

// ACCESSORS(RZ_Lisp_Graph* ,graph)
// ACCESSORS(RZ_Lisp_Graph_Build* ,graph_build)
// ACCESSORS(RZ_Lisp_Parser* ,parser)
// ACCESSORS(RZ_Lisp_Grammar* ,grammar)

// ACCESSORS(int ,number_of_lines)

 ACCESSORS(QString ,data_layer)


 ACCESSORS__RGET(comments_by_line_type ,comments_by_line)
// ACCESSORS_GET(QString ,generated_code)

 RZ_Lisp_Document(RE_Document& re_document);

// RZ_Lisp_Document();
// void open(QString path);
// void open();
// void parse(int start_position = 0);
// void set_grammar();

 void add_rz_comment(QString comment, int line);

// void generate_lisp_code();




// void set_template_node(tNode* n){}
// void enter_run_mode(tNode& n){}
// void handle_run_script(QTextStream& o, tNode& n){}

};

_RZNS(GBuild)

#endif
