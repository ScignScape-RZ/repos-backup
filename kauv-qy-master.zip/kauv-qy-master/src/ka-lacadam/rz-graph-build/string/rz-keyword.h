#ifndef RZ_KEYWORD__H
#define RZ_KEYWORD__H

#include "rz-typedefs.h"
#include "flags.h"

#include "rz-string.h"

//#include "graph/ctq-script-token.h"

#include <QDebug>


#include "flags.h"
#include "methodic.h"


#include "rzns.h"


RZNS_(GBuild)

class RZ_String;
class RZ_Lisp_Token;

//struct RZ_Script_Token;
//struct RZ_Lisp_Result_Holder;
//struct RZ_Type_Not_Set;
//struct RZ_Core_Valuer;
//struct RZ_Symbol;
//struct RZ_User_Function;
//struct RZ_Run_Type_Value;
//struct RZ_Boolean;

class RZ_Keyword
{
public:

 flags_(1)
  bool is_function_overload_marker:1;
  bool is_file_marker:1;
  bool is_numeric_marker:1;
  bool is_arrow_marker:1;
 _flags

private:

 RZ_String rz_string_;

public:

 RZ_METHODIC_RGET(RZ_String ,rz_string)

 RZ_Keyword(RZ_Lisp_Token* t = nullptr):Flags(0), rz_string_(t){}

 RZ_Keyword(tString s):Flags(0),rz_string_(s){}

 void set_token(RZ_Lisp_Token* t)
 {
  rz_string_.set_token(t);
 }


 tString cut()
 {
  return str().mid(1);
 }

 tString str()
 {
  return rz_string_.to_string();
 }

 tString to_string() const
 {
  return rz_string_.to_string();
 }

 template<typename T>
 friend T& operator<<(T& t, const RZ_Keyword& rhs)
 {
  return t << rhs.to_string();
 }


 friend void operator<<(QDebug lhs, const RZ_Keyword& rhs)
 {
  tString s = rhs.to_string();
  lhs << s;
 }

// operator RZ_String()
// {
//  return rz_string;
// }

// template<typename T>
// friend T& operator<<(T& t, const RZ_Keyword& rhs)
// {
//  t << rhs.
// }


// #include "types/type-operators.h"

// friend bool operator==(const RZ_String& lhs, const RZ_String& rhs)
// {
//  return lhs.to_string() == rhs.to_string();
// }

// operator bool()
// {
//  tString s = to_string();
//  return s.isEmpty() || s.isNull();
// }

// bool operator>(const RZ_String& rhs) const;
// bool operator<(const RZ_String& rhs) const;

//  template<typename T>
//  friend T& operator<<(T& t, const RZ_String& s)
//  {
//   return t << s.to_string();
//  }

//  friend RZ_Lisp_Result_Holder& operator<<(RZ_Lisp_Result_Holder& rh, const RZ_String& s)
//  {
//   rh << s;
//   return rh;
//  }


//  RZ_String operator+(const RZ_String& rhs )
//  {
//   return RZ_String( to_string() + rhs.to_string() );
//  }

//  template<typename T>
//  bool operator>(const T& rhs) const
//  {
//   return false;
//  }

//  template<typename T>
//  bool operator<(const T& rhs) const
//  {
//   return false;
//  }

//  template<typename T>
//  friend bool operator>(const T& lhs, const RZ_String& rhs)
//  {
//   return false;
//  }

//  template<typename T>
//  friend bool operator<(const T& lhs, const RZ_String& rhs)
//  {
//   return false;
//  }


// bool operator>(const RZ_Symbol& rhs) const
// {
//  return false;
// }
// bool operator<(const RZ_Symbol& rhs) const
// {
//  return false;
// }
// bool operator>(const RZ_Type_Not_Set& rhs) const
// {
//  return false;
// }
// bool operator<(const RZ_Type_Not_Set& rhs) const
// {
//  return false;
// }
// bool operator>(const RZ_User_Function& rhs) const
// {
//  return false;
// }
// bool operator<(const RZ_User_Function& rhs) const
// {
//  return false;
// }
// bool operator>(const RZ_Run_Type_Value& rhs) const
// {
//  return false;
// }
// bool operator<(const RZ_Run_Type_Value& rhs) const
// {
//  return false;
// }
// bool operator>(const RZ_Boolean& rhs) const
// {
//  return false;
// }
// bool operator<(const RZ_Boolean& rhs) const
// {
//  return false;
// }


};

_RZNS(GBuild)

#endif
