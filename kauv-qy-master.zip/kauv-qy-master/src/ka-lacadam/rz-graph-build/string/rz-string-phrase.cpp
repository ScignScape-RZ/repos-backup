
#include "rz-string-phrase.h"

#include "ctqns.h"


USING_CTQNS(Lisp)

RZ_String_Phrase::RZ_String_Phrase(QStringList& strings)
 : strings_(strings)
{
}
