#ifndef RZ_STRING_PHRASE__H
#define RZ_STRING_PHRASE__H

//#include "graph/ctq-script-token.h"

#include <QDebug>
#include <QStringList>

#include "flags.h"
#include "methodic.h"


#include "ctqns.h"


CTQNS(Lisp)

class RZ_String;
class RZ_Lisp_Token;

class RZ_String_Phrase
{
 QStringList strings_;

public:

 RZ_METHODIC_RGET(QStringList, strings)

 RZ_String_Phrase(QStringList& strings);

 template<typename T>
 friend T& operator<<(T& t, const RZ_String_Phrase& rhs)
 {
//  return t << rhs.to_string();
 }


 friend void operator<<(QDebug lhs, const RZ_String_Phrase& rhs)
 {
//  tString s = rhs.to_string();
//  lhs << s;
 }

// operator RZ_String()
// {
//  return ctq_string;
// }

// template<typename T>
// friend T& operator<<(T& t, const RZ_Keyword& rhs)
// {
//  t << rhs.
// }


// #include "types/type-operators.h"

// friend bool operator==(const RZ_String& lhs, const RZ_String& rhs)
// {
//  return lhs.to_string() == rhs.to_string();
// }

// operator bool()
// {
//  tString s = to_string();
//  return s.isEmpty() || s.isNull();
// }

// bool operator>(const RZ_String& rhs) const;
// bool operator<(const RZ_String& rhs) const;

//  template<typename T>
//  friend T& operator<<(T& t, const RZ_String& s)
//  {
//   return t << s.to_string();
//  }

//  friend RZ_Lisp_Result_Holder& operator<<(RZ_Lisp_Result_Holder& rh, const RZ_String& s)
//  {
//   rh << s;
//   return rh;
//  }


//  RZ_String operator+(const RZ_String& rhs )
//  {
//   return RZ_String( to_string() + rhs.to_string() );
//  }

//  template<typename T>
//  bool operator>(const T& rhs) const
//  {
//   return false;
//  }

//  template<typename T>
//  bool operator<(const T& rhs) const
//  {
//   return false;
//  }

//  template<typename T>
//  friend bool operator>(const T& lhs, const RZ_String& rhs)
//  {
//   return false;
//  }

//  template<typename T>
//  friend bool operator<(const T& lhs, const RZ_String& rhs)
//  {
//   return false;
//  }


// bool operator>(const RZ_Symbol& rhs) const
// {
//  return false;
// }
// bool operator<(const RZ_Symbol& rhs) const
// {
//  return false;
// }
// bool operator>(const RZ_Type_Not_Set& rhs) const
// {
//  return false;
// }
// bool operator<(const RZ_Type_Not_Set& rhs) const
// {
//  return false;
// }
// bool operator>(const RZ_User_Function& rhs) const
// {
//  return false;
// }
// bool operator<(const RZ_User_Function& rhs) const
// {
//  return false;
// }
// bool operator>(const RZ_Run_Type_Value& rhs) const
// {
//  return false;
// }
// bool operator<(const RZ_Run_Type_Value& rhs) const
// {
//  return false;
// }
// bool operator>(const RZ_Boolean& rhs) const
// {
//  return false;
// }
// bool operator<(const RZ_Boolean& rhs) const
// {
//  return false;
// }


};

END_CTQNS(Lisp)

#endif

