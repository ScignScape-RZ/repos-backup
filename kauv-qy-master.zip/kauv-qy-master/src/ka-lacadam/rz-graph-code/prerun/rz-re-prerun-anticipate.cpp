
#include "rz-re-prerun-anticipate.h"

#include "rz-graph-visit/rz-lisp-graph-visitor.h"

#include "rz-graph-core/kernel/graph/rz-re-graph.h"

USING_RZNS(RECore)
USING_RZNS(GBuild)


RE_Prerun_Anticipate::RE_Prerun_Anticipate(RZ_Lisp_Graph_Visitor& visitor)
 : visitor_(visitor)
{

}

void RE_Prerun_Anticipate::scan(std::function<void(RZ_Dynamo_Output&)> fn)
{
 visitor_.anticipate(fn);
}

//caon_ptr<RZ_Lisp_Graph_Visitor> RE_Prerun_Normalize::scan()
//{
// caon_ptr<RZ_Lisp_Graph_Visitor> result = new RZ_Lisp_Graph_Visitor(&graph_);
// result->normalize();
// return result;
//}




//#include "kernel/graph/rz-re-graph.h"
//#include "kernel/graph/rz-re-node.h"

//#include "kernel/rz-re-root.h"

//#include "token/rz-re-token.h"

//#include "tuple/rz-re-tuple-info.h"

//#include "rzns.h"

//USING_RZNS(RECore)

//RE_Pre_Normal_Lisp::RE_Pre_Normal_Lisp(caon_ptr<RE_Document> document)
// : RE_Lisp_Output(document)
//{

//}


//void RE_Pre_Normal_Lisp::report_token(QTextStream& qts,
// const RE_Token& token)
//{
// if(token.flags.is_symbol_declaration)
// {
//  qts << "(rz-decl " << token.raw_text() << ")";
// }
// else
//  qts << token.get_lisp_out();
//}

//void RE_Pre_Normal_Lisp::report_tuple_info_entry(QTextStream& qts,
// const RE_Tuple_Info& rti)
//{
// qts << '(' << rti.lisp_out() << ' ';
//}

//void RE_Pre_Normal_Lisp::report_tuple_info_leave(QTextStream& qts,
// const RE_Tuple_Info& rti)
//{
// qts << ')';
//}

////void RE_Pre_Normal_Lisp::output_from_node(QTextStream& qts,
//// const RE_Node& node, int indent)
////{
//// //CAON_PTR_DEBUG(RE_Node ,node)

//// QString padding(indent, ' ');
////// qts << "\n" << padding;

//// if(caon_ptr<RE_Token> token = node.re_token())
//// {
////  qts << get_lisp_out(*token);
//// }

//// if(caon_ptr<RE_Call_Entry> rce = node.re_call_entry())
//// {
////  //  qts << get_lisp_out(*token);
//// }

//// if(caon_ptr<RE_Node> next_node = rq_.Run_Call_Sequence(&node))
//// {
////  qts << ' ';
////  output_from_node(qts, *next_node, indent + 1);
////  //qts << ' ';
//// }

//// if(caon_ptr<RE_Node> next_node = rq_.Run_Call_Entry(&node))
//// {
////  qts << "\n" << padding;
////  qts << '(';
////  output_from_node(qts, *next_node, indent + 1);
////  qts << ')';
////  if(caon_ptr<RE_Node> cross_node = rq_.Run_Cross_Continue(next_node))
////  {
////   output_from_node(qts, *cross_node, indent);
////  }
//// }

//// if(caon_ptr<RE_Node> next_node = rq_.Run_Data_Entry(&node))
//// {
////  if(caon_ptr<RE_Tuple_Info> rti = next_node->re_tuple_info())
////  {
////   qts << "\n" << padding << ' ';
////   report_tuple_info_entry(qts, *rti);
////   if(next_node = rq_.Run_Data_Entry(next_node))
////    output_from_node(qts, *next_node, indent + 1);
////   report_tuple_info_leave(qts, *rti);
////  }
////  if(caon_ptr<RE_Node> cross_node = rq_.Run_Cross_Continue(next_node))
////  {
////   output_from_node(qts, *cross_node, indent);
////  }
//// }
////}

