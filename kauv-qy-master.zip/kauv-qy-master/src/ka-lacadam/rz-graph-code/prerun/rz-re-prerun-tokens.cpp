
#include "rz-re-prerun-tokens.h"

#include "rz-graph-token/token/rz-lisp-token.h"

#include "rz-graph-core/token/rz-re-token.h"

USING_RZNS(RECore)
USING_RZNS(GBuild)


RE_Prerun_Tokens::RE_Prerun_Tokens(caon_ptr<RE_Document> document)
 : RE_Lisp_Output(document)
{

}


void RE_Prerun_Tokens::init_token(RE_Token& token)
{
 RZ_Lisp_Token::init_lisp_token(token);
 //init_(token);
}

void RE_Prerun_Tokens::report_token(QTextStream& qts,
 const RE_Token& token)
{
 qts << QString("<<%1>>").arg(token.raw_text());
 //init_(token);
}

// caon_ptr<RZ_Lisp_Token> lisp_token = new
// token.init_lisp_token();
// if(token.flags.is_symbol_declaration)
// {
//  qts << "(rz-decl " << token.raw_text() << ")";
// }
// else
//  qts << token.get_lisp_out();
//}

void RE_Prerun_Tokens::report_tuple_info_entry(QTextStream& qts,
 const RE_Tuple_Info& rti, caon_ptr<RE_Call_Entry> rce_ptr)
{
//? qts << '(' << rti.lisp_out() << ' ';
}

void RE_Prerun_Tokens::report_tuple_info_leave(QTextStream& qts,
 const RE_Tuple_Info& rti, caon_ptr<RE_Call_Entry> rce_ptr)
{
//? qts << ')';
}

void RE_Prerun_Tokens::report_call_entry(QTextStream& qts,
 const RE_Call_Entry& rce)
{

}

void RE_Prerun_Tokens::report_call_leave(QTextStream& qts,
 const RE_Call_Entry& rce)
{

}



//void RE_Pre_Normal_Lisp::output_from_node(QTextStream& qts,
// const RE_Node& node, int indent)
//{
// //CAON_PTR_DEBUG(RE_Node ,node)

// QString padding(indent, ' ');
// // qts << "\n" << padding;

// if(caon_ptr<RE_Token> token = node.re_token())
// {
//  qts << get_lisp_out(*token);
// }

// if(caon_ptr<RE_Call_Entry> rce = node.re_call_entry())
// {
//  //  qts << get_lisp_out(*token);
// }

// if(caon_ptr<RE_Node> next_node = rq_.Run_Call_Sequence(&node))
// {
//  qts << ' ';
//  output_from_node(qts, *next_node, indent + 1);
//  //qts << ' ';
// }

// if(caon_ptr<RE_Node> next_node = rq_.Run_Call_Entry(&node))
// {
//  qts << "\n" << padding;
//  qts << '(';
//  output_from_node(qts, *next_node, indent + 1);
//  qts << ')';
//  if(caon_ptr<RE_Node> cross_node = rq_.Run_Cross_Continue(next_node))
//  {
//   output_from_node(qts, *cross_node, indent);
//  }
// }

// if(caon_ptr<RE_Node> next_node = rq_.Run_Data_Entry(&node))
// {
//  if(caon_ptr<RE_Tuple_Info> rti = next_node->re_tuple_info())
//  {
//   qts << "\n" << padding << ' ';
//   report_tuple_info_entry(qts, *rti);
//   if(next_node = rq_.Run_Data_Entry(next_node))
//    output_from_node(qts, *next_node, indent + 1);
//   report_tuple_info_leave(qts, *rti);
//  }
//  if(caon_ptr<RE_Node> cross_node = rq_.Run_Cross_Continue(next_node))
//  {
//   output_from_node(qts, *cross_node, indent);
//  }
// }
//}

