
#include "rz-ngml-tag-command.h"

#include "rzns.h"

USING_RZNS(NGML)

NGML_Tag_Command::NGML_Tag_Command(QString command_name, QString ns)
 : command_name_(command_name), ns_(ns), Flags(0)
{
}

