
#ifndef RZ_NGML_TAG_COMMAND__H
#define RZ_NGML_TAG_COMMAND__H

#include "accessors.h"
#include "flags.h"


#include <QString>
#include <functional>

 //#include "whitespace/rz-ngml-whitespace-holder.h"

#include "rzns.h"
RZNS_(NGML)


class NGML_Tag_Command  //: public NGML_Whitespace_Holder
{
public:
 flags_(1)
  bool is_block:1;
  bool is_region:1;
 _flags

private:

 QString command_name_;
 QString ns_;
 QString initial_whitespace_;
 QString terminal_whitespace_;

public:

 ACCESSORS(QString ,command_name)
 ACCESSORS(QString ,ns)
// CTQ_METHODIC(QString ,initial_whitespace)

 NGML_Tag_Command(QString command_name, QString ns = QString());

};

_RZNS(NGML)

#endif


