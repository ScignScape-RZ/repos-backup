
#ifndef RZ_NGML_FOLDER__H
#define RZ_NGML_FOLDER__H

#include <QString>

#include <QMap>

#include "methodic.h"

#include "flags.h"


#include "ctqns.h"
CTQNS(RZ)

class NGML_Graph;
class NGML_Parser;
class NGML_Graph_Build;
class NGML_Grammar;
class NGML_Annotation_Tile;

class NGML_Folder
{
 QString local_path_;
 QString output_path_;
 QString input_path_;

 QString latex_path_;
 QString latex_code_;

 QMap<QString, int> user_highlights_;
 QMap<QString, NGML_Annotation_Tile*> annotations_;

public:


 CTQ_METHODIC(QString ,local_path)

 NGML_Folder(QString local_path = QString());
 void convert_all_files();
 void convert_all_files(QString output_path);
 void read_output_path(QString document_file);
 void display_user_highlights();


};

END_CTQNS(RZ)

#endif
