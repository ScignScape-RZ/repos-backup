

#ifndef RZ_RE_GRAMMAR__H
#define RZ_RE_GRAMMAR__H

//#include "rz-parser/rz-regex.h"
//#include "rz-parser/rz-parser.h"
//#include "accessors.h"

#include "relae-graph/relae-grammar.h"

#include "kernel/rz-re-dominion.h"

#include "rzns.h"


RZNS_(RECore)

class RE_Graph;
class RE_Graph_Build;
class RE_Parser;

class RE_Grammar : public Relae_Grammar<RE_Graph, RE_Parser>
{
public:

 RE_Grammar();



 void init(RE_Parser& p, RE_Graph& g,
           RE_Graph_Build& graph_build);


};

_RZNS(RECore)

//#include "rz-parser/rz-regex.h"
//#include "rz-parser/rz-parser.h"

//#include "rz-text-typedefs.h"

//class RZ_Text_Parser : public RZ_Parser<RZ_Text_Galaxy>
//{
//public:
// RZ_Text_Parser(RZ_Text_Graph* g);
// void set_raw_text(QString s);


//};

//typedef RZ_Parser<RZ_Text_Galaxy> RZ_Text_Parser;

#endif
