
#include "rz-re-parser.h"

USING_RZNS(RECore)

RE_Parser::RE_Parser(caon_ptr<RE_Graph> g)
 : Relae_Parser<RE_Galaxy>(g)
{
}

