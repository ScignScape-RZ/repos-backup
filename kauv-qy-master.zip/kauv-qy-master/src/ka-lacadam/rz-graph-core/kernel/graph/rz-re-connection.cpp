
#include "rz-re-connection.h"


#include "rzns.h"
USING_RZNS(RECore)

RE_Connection::RE_Connection(caon_ptr<RE_Node> re_node)
 : re_node_(re_node)
{

}
