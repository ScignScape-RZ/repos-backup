
#include "rz-re-node-proxy.h"

#include "token/rz-re-token.h"

#include "rzns.h"

USING_RZNS(RECore)

RE_Node_Proxy::RE_Node_Proxy(caon_ptr<RE_Node> node)
  : node_(node)
{

}
