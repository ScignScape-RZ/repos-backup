
#ifndef RZ_NGML_TILE__H
#define RZ_NGML_TILE__H

#include "accessors.h"
#include "flags.h"


#include <QString>

#include <functional>

#include "rzns.h"
RZNS_(NGML)


class NGML_Tile
{
public:
 flags_(1)
  bool is_main_command_argument:1;
  bool is_multi_command_argument:1;
  bool is_multi_optional_command_argument:1;
  bool is_multi_mandatory_command_argument:1;
 _flags

private:

 QString raw_text_;
 int starting_line_number_;
 int ending_line_number_;

public:

 ACCESSORS(QString ,raw_text)
 ACCESSORS(int ,starting_line_number)
 ACCESSORS(int ,ending_line_number)

 NGML_Tile(QString raw_text = QString(),
  int starting_line_number = 0, int ending_line_number = 0);

 QString string_value()
 {
  return raw_text();
 }

 QString thumbnail(int length = 4, int ellipsis = 3) const;

};

_RZNS(NGML)

#endif
