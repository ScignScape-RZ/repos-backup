
#include "rz-graph-embed-run-valuer.h"

#include "rz-graph-valuer/valuer/rz-lisp-graph-valuer.h"

//#include "rz-graph-valuer/scope/rz-lisp-graph-user-package.h"
//#include "rz-graph-valuer/scope/rz-lisp-graph-user-class.h"

#include "rz-graph-valuer/vector/rz-lisp-vector.h"

//#include "rz-graph-nglp/document/rz-nglp-ngml-interface.h"
//#include "rz-graph-nglp/document/rz-nglp-lisp-interface.h"

#include <QDebug>

#include <QStringList>


USING_RZNS(GEmbed)

//USING_RZNS(NGLP)



RZ_Graph_Embed_Run_Valuer::RZ_Graph_Embed_Run_Valuer(RZ_Lisp_Graph_Valuer& valuer)
 : valuer_(valuer), current_user_package_(nullptr), default_user_package_(nullptr),
   current_user_class_(nullptr), default_user_class_(nullptr)
{
}


void RZ_Graph_Embed_Run_Valuer::valuer_deferred_callback(QString qs)
{
 valuer_.run_deferred_callback(qs);
}


//void RZ_Graph_Embed_Run_Valuer::nglp_analyze(QString source, RZ_Lisp_Graph_User_Package* pkg)
//{
// if(!pkg)
// {
//  if(default_user_package_)
//   pkg = default_user_package_;
//  else
//   // //  Or an error that there is no pkg for analysis?
//   return;
// }

// NGLP_Lisp_Interface rnli(this);
// NGLP_NGML_Interface rnni(rnli);
// rnni.analyze(source);
//}

