
#include "rz-graph-cpp-token.h"

#include <QStringList>


USING_RZNS(GEmbed)

RZ_Graph_Cpp_Token::RZ_Graph_Cpp_Token(QString raw_text, Basic_Token_Kinds kind)
 : RZ_Graph_Embed_Token(raw_text, kind)
{

}


