//?//
//RZ_LISP_GRAPH_FUNCTION_DECLARE(within, Within, 2, Valuer_N_S_S)

//RZ_LISP_GRAPH_FUNCTION_DECLARE(assume, Assume, 2, Valuer_N_S_S)
//?//

