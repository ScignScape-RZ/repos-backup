
//RZ_LISP_GRAPH_FUNCTION_DECLARE(within, Within, 0, Valuer)

//RZ_LISP_GRAPH_FUNCTION_DECLARE(assume, Assume, 0, Valuer)

