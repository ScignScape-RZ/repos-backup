
#ifndef GRAPH_CALL_TV__H
#define GRAPH_CALL_TV__H

#include "token/rz-lisp-token.h"


#include "rz-graph-valuer/valuer/rz-lisp-graph-valuer.h"

#include "relae-graph/relae-caon-ptr.h"

#include "functions/rz-lisp-graph-function-families.h"

#include "rzns.h"

RZNS_(GRun)

#define RZ_LISP_GRAPH_FUNCTION_DECLARE(str, name, arity, status) name,

RZ_LISP_GRAPH_FUNCTION_CODES_(RZ_Graph_Call_Tv)
 null = 0,
 #include "core-functions-tv.h"
_RZ_LISP_GRAPH_FUNCTION_CODES

#undef RZ_LISP_GRAPH_FUNCTION_DECLARE


_RZNS(GRun)

#endif

