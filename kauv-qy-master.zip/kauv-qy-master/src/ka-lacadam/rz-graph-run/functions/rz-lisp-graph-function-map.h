
#ifndef RZ_LISP_GRAPH_FUNCTION_MAP__H
#define RZ_LISP_GRAPH_FUNCTION_MAP__H

//#include <map>
#include <QMap>

#include "rz-graph-token/valuer/rz-lisp-graph-function-info.h"

//?#include "rz-graph-build/core/rz-core-function-out.h"

#include "functions/rz-lisp-graph-function-families.h"

#include "rz-lisp-graph-core-function-declarations.h"


#include "rzns.h"

USING_RZNS(GRun)

//?
//template<>
//struct RZ_Lisp_Graph_Function_Family_<RZ_Graph_Call_TC>
//{ enum Code {
// null = 0, Package
// } };
////_RZ_LISP_GRAPH_FUNCTION_CODES



#ifdef RZ_LISP_GRAPH_FUNCTION_DECLARE
#undef RZ_LISP_GRAPH_FUNCTION_DECLARE
#endif



//?#define RZ_LISP_GRAPH_FUNCTION_DECLARE(str, name) {#name, {RZ_GCALL_S_(name)}},
//#include "functions/core-functions-s.h"
//#undef RZ_LISP_GRAPH_FUNCTION_DECLARE


//RZ_Lisp_Graph_Function_Family_<RZ_Graph_Call_S>::name
//RZ_GCALL_S_(name)

RZNS_(GRun)


static QMap<QString, RZ_Lisp_Graph_Function_Info> RZ_Lisp_Graph_Function_Code_Map
{{
#define RZ_LISP_GRAPH_FUNCTION_DECLARE(str, name, arity, status) {#name, {RZ_GCALL_S_(name)}},
#include "functions/core-functions-s.h"
#undef RZ_LISP_GRAPH_FUNCTION_DECLARE

#define RZ_LISP_GRAPH_FUNCTION_DECLARE(str, name, arity, status) {#name, {RZ_GCALL_T_(name)}},
#include "functions/core-functions-t.h"
#undef RZ_LISP_GRAPH_FUNCTION_DECLARE

#define RZ_LISP_GRAPH_FUNCTION_DECLARE(str, name, arity, status) {#name, {RZ_GCALL_TC_(name)}},
 #include "functions/core-functions-t-c.h"
#undef RZ_LISP_GRAPH_FUNCTION_DECLARE

#define RZ_LISP_GRAPH_FUNCTION_DECLARE(str, name, arity, status) {#name, {RZ_GCALL_CC_(name)}},
#include "functions/core-functions-c-c.h"
#undef RZ_LISP_GRAPH_FUNCTION_DECLARE

#define RZ_LISP_GRAPH_FUNCTION_DECLARE(str, name, arity, status) {#name, {RZ_GCALL_VV_(name)}},
#include "functions/core-functions-v-v.h"
#undef RZ_LISP_GRAPH_FUNCTION_DECLARE

#define RZ_LISP_GRAPH_FUNCTION_DECLARE(str, name, arity, status) {#name, {RZ_GCALL_C_(name)}},
#include "functions/core-functions-c.h"
#undef RZ_LISP_GRAPH_FUNCTION_DECLARE

#define RZ_LISP_GRAPH_FUNCTION_DECLARE(str, name, arity, status) {#name, {RZ_GCALL_CT_(name)}},
#include "functions/core-functions-c-t.h"
#undef RZ_LISP_GRAPH_FUNCTION_DECLARE

#define RZ_LISP_GRAPH_FUNCTION_DECLARE(str, name, arity, status) {#name, {RZ_GCALL_Tc_(name)}},
#include "functions/core-functions-tc.h"
#undef RZ_LISP_GRAPH_FUNCTION_DECLARE

#define RZ_LISP_GRAPH_FUNCTION_DECLARE(str, name, arity, status) {#name, {RZ_GCALL_Tv_(name)}},
 #include "functions/core-functions-tv.h"
#undef RZ_LISP_GRAPH_FUNCTION_DECLARE

#define RZ_LISP_GRAPH_FUNCTION_DECLARE(str, name, arity, status) {#name, {RZ_GCALL_TV_(name)}},
#include "functions/core-functions-t-v.h"
#undef RZ_LISP_GRAPH_FUNCTION_DECLARE
}};


//?
//static QMap<QString, RZ_Lisp_Graph_Function_Out> RZ_Lisp_Graph_Function_Code_Map
//{{
//#define RZ_LISP_GRAPH_FUNCTION_DECLARE(rz_name, name, arity, flag) {#rz_name, {#name}},
//#include "functions/core-functions-out.h"
//#undef RZ_LISP_GRAPH_FUNCTION_DECLARE
//}};


//?
//static QMap<QString, RZ_GCALL_Core_Function_Out> RZ_GCALL_Core_Function_Valuer_Map
//{{
//#define RZ_LISP_GRAPH_FUNCTION_DECLARE(rz_name, name, arity, flag) {#rz_name, {#name}},
//#include "functions/core-functions-valuer-n.h"
//#include "functions/core-functions-valuer-n-s.h"
//#include "functions/core-functions-valuer-n-t.h"
//#undef RZ_LISP_GRAPH_FUNCTION_DECLARE
//}};


//#define RZ_LISP_GRAPH_FUNCTION_DECLARE(str, name) name,y

_RZNS(GRun)

#endif

////{"+", {RZ_GCALL_CC_(Add)}},
////{"*", {RZ_GCALL_CC_(Multiply)}},
////{"^", {RZ_GCALL_CC_(Exponent)}},
////{"/", {RZ_GCALL_CC_(Divide)}},
////{"%", {RZ_GCALL_CC_(Integer_Divide)}},
////{">", {RZ_GCALL_CC_(Greater_Than)}},
////{">=", {RZ_GCALL_CC_(Greater_Than_Or_Equal)}},
////{"<", {RZ_GCALL_CC_(Less_Than)}},
////{"<=", {RZ_GCALL_CC_(Less_Than_Or_Equal)}},
////{"=?", {RZ_GCALL_CC_(Is_Equal)}},
////{"-", {RZ_GCALL_CC_(Subtract)}},
////{"pr", {RZ_GCALL_C_(Print_Line)}},
////{"prs", {RZ_GCALL_C_(Print_String)}},
////{"if", {RZ_GCALL_CT_(If)}},
////{"elsif", {RZ_GCALL_CT_(Elsif)}},
////{"else", {RZ_GCALL_TV_(Else)}},
////{"while", {RZ_GCALL_CT_(While)}},
////{"my", {RZ_GCALL_TC_(My)}},
////{"ty", {RZ_GCALL_TC_(Ty)}},
////{"->", {RZ_GCALL_S_(Function_Entry)}},
////{"break", {RZ_GCALL_S_(Break)}},
////{"=", {RZ_GCALL_TV_(Set_Equal)}},

