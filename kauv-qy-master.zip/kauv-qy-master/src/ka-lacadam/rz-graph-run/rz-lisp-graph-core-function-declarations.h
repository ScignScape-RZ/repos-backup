#ifndef RZ_LISP_GRAPH_CORE_FUNCTION_DECLARATIONS__H
#define RZ_LISP_GRAPH_CORE_FUNCTION_DECLARATIONS__H

//?#include "functions/rz-lisp-graph-function-families.h"

#include "rzns.h"

#define RZ_GCALL_IMPLEMENT template<> struct RZ_Lisp_Graph_Function_Run

// //?????????
#include "functions/graph-call-s.h"
#include "functions/graph-call-c-c.h"
#include "functions/graph-call-c-t.h"
#include "functions/graph-call-c.h"
#include "functions/graph-call-t-c.h"
#include "functions/graph-call-t-v.h"
#include "functions/graph-call-t.h"
#include "functions/graph-call-tc.h"
#include "functions/graph-call-tv.h"
#include "functions/graph-call-v-t.h"
#include "functions/graph-call-v-v.h"



////RZNS_(GRun)

//#define RZ_TEMP_MACRO_(X) \
// template<> \
// struct RZ_Lisp_Graph_Function_Family_<X> \
// { enum Code { \
//  null = 0, \

//#define _RZ_TEMP_MACRO }; };

//#define RZ_LISP_GRAPH_FUNCTION_DECLARE(str, name, arity, status) name,


////RZ_TEMP_MACRO_(RZ_Graph_Call_S)
//////? #include "functions/core-functions-s.h"
////_RZ_TEMP_MACRO

////RZ_TEMP_MACRO_(RZ_Graph_Call_CC)
//////? #include "functions/core-functions-c-c.h"
////_RZ_TEMP_MACRO

////RZ_TEMP_MACRO_(RZ_Graph_Call_CT)
//////? #include "functions/core-functions-c-t.h"
////_RZ_TEMP_MACRO

////RZ_TEMP_MACRO_(RZ_Graph_Call_C)
//////? #include "functions/core-functions-c.h"
////_RZ_TEMP_MACRO

////RZ_TEMP_MACRO_(RZ_Graph_Call_TC)
//////? #include "functions/core-functions-t-c.h"
////_RZ_TEMP_MACRO

////RZ_TEMP_MACRO_(RZ_Graph_Call_TV)
//////? #include "functions/core-functions-t-v.h"
////_RZ_TEMP_MACRO

////RZ_TEMP_MACRO_(RZ_Graph_Call_T)
//////? #include "functions/core-functions-t.h"
////_RZ_TEMP_MACRO

////RZ_TEMP_MACRO_(RZ_Graph_Call_Tc)
//////? #include "functions/core-functions-tc.h"
////_RZ_TEMP_MACRO



////?
////RZ_TEMP_MACRO_(RZ_Graph_Call_Tv)
//// #include "functions/core-functions-tv.h"
////_RZ_TEMP_MACRO


//#undef RZ_LISP_GRAPH_FUNCTION_DECLARE
//#undef RZ_TEMP_MACRO_
//#undef _RZ_TEMP_MACRO



////_RZNS(GRun)


////?
////#include "functions/core-functions-s.h"
////#include "functions/core-functions-c-c.h"
////#include "functions/core-functions-c-t.h"
////#include "functions/core-functions-c.h"
////#include "functions/core-functions-t-c.h"
////#include "functions/core-functions-t-v.h"
////#include "functions/core-functions-t.h"
////#include "functions/core-functions-tc.h"
////#include "functions/core-functions-tv.h"

////??#include "functions/core-functions-v-t.h"

//// #include "functions/core-functions-v-v.h"

////?

#endif
