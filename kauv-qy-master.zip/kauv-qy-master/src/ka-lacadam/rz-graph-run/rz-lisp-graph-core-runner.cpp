
//?//
//#include "functions/graph-call-c.h"
//#include "functions/graph-call-v-v.h"

//#include "functions/graph-call-s.h"
//#include "functions/graph-call-tc.h"
//#include "functions/graph-call-t.h"

//#include "functions/graph-call-t-c.h"
//?//


//?

#include "rz-lisp-graph-core-runner.h"

#include "rz-lisp-graph-core-runner.templates.h"



//?USING_RZNS(GBuild)
