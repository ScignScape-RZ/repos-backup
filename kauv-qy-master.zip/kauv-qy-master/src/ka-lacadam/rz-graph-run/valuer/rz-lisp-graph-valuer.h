
#ifndef RZ_LISP_GRAPH_VALUER__H
#define RZ_LISP_GRAPH_VALUER__H

#include "methodic.h"

#include "rz/rz-read-table-state.h"

#include "rz-core/rz-lisp/graph/rz-lisp-node.h"
#include "rz-core/rz-lisp/query/rz-lisp-query.h"
#include "rz-core/rz-lisp/rz-lisp-frame.h"
#include "rz-core/rz-lisp/types/run-types.h"

#include "rz-core/rz-lisp/types/rz-type-variety.h"


#include <stack>

#include <map>

#include "ns.h"
#include "ctqns.h"
#include "methodic.h"

//?class RZ_Lisp_Graph;
class RZ_GCALL_Token;


CTQNS(Lisp)

class RZ_Lisp_Graph;
class RZ_Lisp_Node;
class RZ_Lisp_Core_Runner;
class RZ_Type_Object;
class RZ_Lisp_User_Package;


END_CTQNS(Lisp)

USING_CTQNS(Lisp)

class RZ_Lisp_Graph_Visitor;
class RZ_Lisp_Graph_Result_Holder;
class RZ_Lisp_Graph_Core_Function;

class RZ_Lisp_Graph_Valuer
{
 RZ_Lisp_Graph_Visitor* rz_lisp_graph_visitor_;
 RZ_Type_Variety type_variety_;

 RZ_Lisp_Query rlq_;

 std::map<RZ_Lisp_Kernel_Types::Codes, RZ_Type_Object*> type_objects_by_code_;

 typedef RZ_Lisp_Node tNode;

 tNode* the_monotail_;

 void init_type_objects();

public:

 RZ_METHODIC_RGET(RZ_Type_Variety ,type_variety)

 RZ_Lisp_Graph_Valuer(RZ_Lisp_Graph_Visitor* rz_lisp_graph_visitor);

 void redirect_core_function(RZ_Lisp_Graph_Result_Holder& rh,
  QString function_name, tNode* start_node);

 void check_node_type(tNode*& node);
 void check_monotail(tNode*& node);
 void type_numeric_token(RZ_Lisp_Token* tok);
 void type_string_token(RZ_Lisp_Token* tok);
 tNode* check_node_type_with_entry_premise(RZ_Lisp_Query_Token* premise,
  tNode*& node);
 RZ_Type_Object* get_node_type_object(tNode* node);
 void enter_logical_scope(int level, RZ_Lisp_Graph_Result_Holder& rh,
  RZ_Lisp_User_Package& upkg);
 void register_user_package(QString name);



};


#endif
