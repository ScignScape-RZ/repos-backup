
#ifndef RZ_LISP_GRAPH_TYPEDEFS__H
#define RZ_LISP_GRAPH_TYPEDEFS__H

#include "rzns.h"

RZNS_(GBuild)

typedef int tyId;


_RZNS(GBuild)


#endif
