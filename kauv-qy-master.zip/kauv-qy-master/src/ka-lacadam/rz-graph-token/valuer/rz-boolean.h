#ifndef VALUER__RZ_BOOLEAN__H
#define VALUER__RZ_BOOLEAN__H

//?#include "rz-typedefs.h"
#include "flags.h"

//#include "types/rz-core-extension-class.h"

//#include "run/rz-result-holder.h"

//#include "graph/rz-script-token.h"

//struct RZ_Lisp_Token;
//struct RZ_Lisp_Result_Holder;
//struct RZ_Type_Not_Set;
//struct RZ_Core_Valuer;
//struct RZ_Lexical_Symbol;
//struct RZ_Logical_Symbol;
//struct RZ_Functional_Symbol;

//struct RZ_Lisp_Result_Holder;
//struct RZ_Type_Not_Set;
//struct RZ_Lisp_Symbol;
//struct RZ_Vector;
//struct RZ_Map;
//struct RZ_String;
//struct RZ_User_Function;
//struct RZ_Run_Type_Value;
//struct RZ_Core_Extension_Object;


#include "accessors.h"

#include "rzns.h"

RZNS_(GBuild)

class RZ_Boolean
{
 double weight_;

public:

 RZ_Boolean(double w = 0):weight_(w){}


 static RZ_Boolean& from_boolean(bool b)
 {
  return b?trueval():falseval();
 }

 static RZ_Boolean& trueval()
 {
  static RZ_Boolean value = RZ_Boolean(1);
  return value;
 }
 static RZ_Boolean& falseval()
 {
  static RZ_Boolean value = RZ_Boolean(0);
  return value;
 }
 static RZ_Boolean& nullval()
 {
  static RZ_Boolean value = RZ_Boolean(0);
  return value;
 }

 operator bool()
 {
  return weight_ == 1;
 }

//#include "types/type-operators.h"


// template<typename T>
// friend bool operator<(const RZ_Boolean& lhs, const T& rhs)
// {
//  return false;
// }
// template<typename T>
// friend bool operator<(const T& lhs, const RZ_Boolean& rhs)
// {
//  return false;
// }

// template<typename T>
// friend bool operator>(const RZ_Boolean& lhs, const T& rhs)
// {
//  return false;
// }
// template<typename T>
// friend bool operator>(const T& lhs, const RZ_Boolean& rhs)
// {
//  return false;
// }


 template<typename T>
 friend T& operator<<(T& t, const RZ_Boolean& b)
 {
  return t;
 }

// friend RZ_Boolean& operator+(RZ_Type_Not_Set&, RZ_Boolean& b)
// {
//  return b;
// }

// friend RZ_Boolean& operator+(RZ_Boolean& b, RZ_Type_Not_Set&)
// {
//  return b;
// }


};


_RZNS(GBuild)

#endif
