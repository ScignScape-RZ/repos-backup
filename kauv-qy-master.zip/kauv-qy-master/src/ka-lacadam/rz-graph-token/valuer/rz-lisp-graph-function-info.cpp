
//?#define RZ_GCALL_IMPLEMENT template<> struct RZ_Lisp_Graph_Function_Run

#include "rz-lisp-graph-function-info.h"

//?
//#include "rz/run/functions/graph-call-c.h"
//#include "rz/run/functions/graph-call-v-v.h"

//?
//#include "rz/run/functions/graph-call-s.h"
//?#include "rz/run/functions/graph-call-tc.h"
//#include "rz/run/functions/graph-call-t.h"

//#include "rz/run/functions/graph-call-t-c.h"

//?USING_CTQNS(Lisp)

USING_RZNS(GBuild)


void RZ_Lisp_Graph_Function_Info::pre_init()
{
 Core_Function_Family = RZ_Function_Family_Not_Set;
 Core_Function_Code = 0;
}




