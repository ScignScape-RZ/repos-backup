
#include "rz-null-value.h"

USING_RZNS(GBuild)

RZ_Null_Value::RZ_Null_Value(QString description)
 : description_(description)
{}
