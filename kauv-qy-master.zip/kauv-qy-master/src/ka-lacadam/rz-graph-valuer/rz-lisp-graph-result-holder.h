

#ifdef HIDE


#ifndef RZ_LISP_GRAPH_RESULT_HOLDER__H
#define RZ_LISP_GRAPH_RESULT_HOLDER__H

#include "accessors.h"

//?#include "rz/rz-read-table-state.h"


#include <stack>

#include <map>

#include <QTextStream>

#include "ns.h"
#include "rzns.h"

#include "flags.h"

#include "methodic.h"

#include "rz-graph-token/rz-lisp-graph-value-holder.h"

#include <stack>

//?class RZ_Lisp_Graph;
class RZ_GCALL_Token;


RZNS_(GBuild)

class RZ_Lisp_Graph;
class RZ_Lisp_Node;
class RZ_Lisp_Token;
//class RZ_Lisp_Core_Runner;

_RZNS(GBuild)

RZNS_(GEmbed)

class RZ_Graph_Run_Embedder;

_RZNS(GEmbed)


USING_RZNS(GBuild)
USING_RZNS(GEmbed)


RZNS_(GVal)

class RZ_Lisp_Graph_Valuer;

class RZ_Lisp_Graph_Result_Holder
{
public:
 flags_(2)
  bool is_writing:1;
  bool has_external:1;
  bool has_boolean:1;
  bool last_boolean:1;
  bool recur:1;
  bool is_transient_symbol:1;
  bool is_empty:1;
  bool break_loop:1;
  bool continue_statement:1;
  bool continue_proceed:1;
  bool proceed_anticipate_nested_run_call:1;
  bool has_held_value:1;
  bool skip_redirect:1;
 _flags

private:

 typedef RE_Node tNode;
 typedef QTextStream tStringStream;

 caon_ptr<RZ_Lisp_Graph_Valuer> valuer_;

 caon_ptr<tNode> arity_node_;
 caon_ptr<tNode> pass_node_;

 std::stack<caon_ptr<tNode>> current_start_nodes_;

 RZ_Lisp_Graph_Value_Holder value_holder_;

 RZ_Lisp_Node* lead_function_node_;


public:

 ACCESSORS(caon_ptr<tNode> ,arity_node)
 ACCESSORS(caon_ptr<tNode> ,pass_node)
 ACCESSORS__RGET(RZ_Lisp_Graph_Value_Holder ,value_holder)
 ACCESSORS(caon_ptr<RZ_Lisp_Graph_Valuer> ,valuer)

 RZ_Lisp_Graph_Result_Holder(caon_ptr<RZ_Lisp_Graph_Valuer> valuer);

 void clear_continue_proceed()
 {
  flags.continue_proceed = false;
 }


 void hold(tNode& n);
 void unhold();

 caon_ptr<tNode> pull_pass_node();
 void continue_proceed(caon_ptr<tNode> n);

 caon_ptr<RZ_Lisp_Token> function_token();

 caon_ptr<tNode> function_node();
 caon_ptr<tNode> get_lead_function_node(caon_ptr<tNode> current_start_node = nullptr);

 void clear_continue_statement()
 {
  flags.continue_statement = false;
 }

 void mark_continue_statement(tNode& n);
//? void mark_continue_statement();

 caon_ptr<RZ_Lisp_Token> get_lead_function_token();

 void skip_redirect();

//? RZ_Graph_Run_Embedder* embedder();

//?
// void check_redirect(tNode* current_start_node);
// void redirect_to_noop(tNode* current_start_node);

// void redirect(std::initializer_list<QString> args, tNode* function_node = nullptr);
// void redirect(QString function_name, tNode* function_node = nullptr);

// void embed_rename(QString function_name, tNode* function_node);
// void embed_deferred_callback(QString function_name, tNode* function_node);

// void skip_redirect();

//? void redirect(QStringList& qsl);

};

_RZNS(GVal)



#endif


#endif //HIDE
