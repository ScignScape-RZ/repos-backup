
//#include "rz-lisp-graph-value-holder.h"

//#include "types/rz-type-object.h"

//#include "ctqns.h"

//USING_CTQNS(Lisp)

//USING_RZNS(GVal)

//RZ_Lisp_Graph_Value_Holder::RZ_Lisp_Graph_Value_Holder()
// : value_(nullptr),
//   type_object_(nullptr)
//{

//}

//void RZ_Lisp_Graph_Value_Holder::set_typecode(RZ_Run_Types::Enum e)
//{

//}


//int RZ_Lisp_Graph_Value_Holder::typecode()
//{
// return type_object_->id();
//}


//QString RZ_Lisp_Graph_Value_Holder::to_lisp_string() const
//{
// if(type_object_)
// {
//  return type_object_->value_to_lisp_string(value_);
// }
// return QString();

//}



//QString RZ_Lisp_Graph_Value_Holder::to_string() const
//{
// if(type_object_)
// {
//  return type_object_->value_to_string(value_);
// }
// return QString();

//}

////template<typename T>
////T* RZ_Lisp_Graph_Value_Holder::pRetrieve()
////{
//// return pRestore<T>();
////}
