
#include "rz-string-phrase.h"

#include "rzns.h"


USING_RZNS(GVal)

RZ_String_Phrase::RZ_String_Phrase(QStringList& strings)
 : strings_(strings)
{
}
