
#include "rz-lisp-symbol.h"


USING_RZNS(GVal)

RZ_Lisp_Symbol::RZ_Lisp_Symbol(caon_ptr<RE_Node> n)
 : node_(n)
{}

