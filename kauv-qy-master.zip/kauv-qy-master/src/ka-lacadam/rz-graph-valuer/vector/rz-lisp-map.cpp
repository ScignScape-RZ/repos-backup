
//#include "token/rz-script-token.h"
#include "rz-lisp-map.h"

#include "rzns.h"
USING_RZNS(GVal)

RZ_Lisp_Map::RZ_Lisp_Map()
 //: Flags(0), ctq_string_(s)
{}
