
#include "rz-embed-branch-run-plugin.h"
#include "rz-lisp-graph-visitor.h"

#include "rz-graph-run/token/rz-graph-run-token.h"

#include "rz-graph-embed/rz-graph-embed-token.h"

#include "rzns.h"

USING_RZNS(GBuild)


RZ_Embed_Branch_Run_Plugin::RZ_Embed_Branch_Run_Plugin(RZ_Lisp_Graph_Visitor& main_visitor)
 : RZ_Lisp_Graph_Visitor_Run_Plugin(main_visitor), current_embed_arg_position_(0)
{

}


bool RZ_Embed_Branch_Run_Plugin::advance()
{
 switch(run_state_.read_table_state())
 {
 case RZ_Read_Table_State::Expression_Entry:
 case RZ_Read_Table_State::Expression_Sequence:
  //main_visitor_.
  return find_next_token(RZ_Read_Table_State::Expression_Final, RZ_Read_Table_Post_Advance_State::Holds_Token);
 case RZ_Read_Table_State::Expression_Final:
  if(run_state_.flags.on_embed_redirect_leave)
  {
   run_state_.flags.on_embed_redirect_leave = false;
   return false;
//   run_state_.flags.on_embed_redirect_leave = false;
//   // //?
//   run_state_.flags.has_run_plugin = false;
//   break;
  }
  break;

 case RZ_Read_Table_State::Expression_Pre_Entry:
  {
//?   main_visitor_.set_current_node(main_visitor_.next_node());
//?   CAON_EVALUATE_DEBUG(RE_Node ,cn ,main_visitor_.current_node());
   run_state_.set_read_table_state(RZ_Read_Table_State::Expression_Entry);
   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
  }
  break;

 case RZ_Read_Table_State::Expression_Embed_Sequence:
  {
   caon_ptr<RZ_Graph_Embed_Token> rget ;//= //?main_visitor_.current_embed_token();
   if(rget)
   {
    rget->advance_arg(current_embed_arg_position_); //main_visitor_.current_embed_arg_position());
    if(current_embed_arg_position_ == 0) //main_visitor_.current_embed_arg_position() == 0)
    {
     return check_embed_call_entry(*rget);
    }
//    if(rget->entry_node())
//    {
//     CAON_EVALUATE_DEBUG(RE_Node ,en ,rget->entry_node())
//     run_state_.flags.on_embed_redirect_branch = false;
//     run_state_.flags.on_embed_redirect_entry = true;
//     run_state_.set_read_table_state(RZ_Read_Table_State::Expression_Pre_Entry);
//     run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
//     //?main_visitor_.set_current_node(rget->entry_node());
//     main_visitor_.find_next_node_from_entry(*rget->entry_node());
//     return true;
//    }
//    else
//    {
//  //    return false;
//     run_state_.flags.on_embed_redirect_branch = false;
//     // ?
//     run_state_.flags.on_embed_redirect_leave = true;
//     main_visitor_.pop_embed_branch_node();
//     return false;
// //    run_state_.set_read_table_state(state_not_found);
// //    run_state_.set_post_advance_state(post_state_not_found);
//    }
   }
  }
 }
 return true;
}

bool RZ_Embed_Branch_Run_Plugin::check_embed_call_entry(RZ_Graph_Embed_Token& rget)
{
 if(rget.entry_node())
 {
  CAON_EVALUATE_DEBUG(RE_Node ,en ,rget.entry_node())
  run_state_.flags.on_embed_redirect_branch = false;
  run_state_.flags.on_embed_redirect_entry = true;
  run_state_.set_read_table_state(RZ_Read_Table_State::Expression_Pre_Entry);
  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
  //?main_visitor_.set_current_node(rget->entry_node());
  //?main_visitor_.find_next_node_from_entry(*rget.entry_node());
  return true;
 }
 else
 {
//    return false;
  run_state_.flags.on_embed_redirect_branch = false;
  // ?
   //run_state_.flags.on_embed_redirect_leave = true;
  //?main_visitor_.pop_embed_branch_node();
  return false;
//    run_state_.set_read_table_state(state_not_found);
//    run_state_.set_post_advance_state(post_state_not_found);
 }

}



void RZ_Embed_Branch_Run_Plugin::activate()
{
}


void RZ_Embed_Branch_Run_Plugin::deactivate()
{
}

void RZ_Embed_Branch_Run_Plugin::get_current_token(RZ_Graph_Run_Token& rzt)
{
//?
// if(caon_ptr<RZ_Graph_Embed_Token> rget = main_visitor_.current_embed_token())
// {
//  rget->convey(current_embed_arg_position_, rzt);// main_visitor_.current_embed_arg_position(), rzt);
////?  rzt.set_symbol_string_value(rget->string_value(current_embed_arg_position_));
////  return rget->string_value(current_embed_arg_position_);
// }
// else
// {
//  switch(run_state_.read_table_state())
//  {
//  case RZ_Read_Table_State::Expression_Entry:
//  case RZ_Read_Table_State::Expression_Sequence:
//   main_visitor_.current_token_string(rzt);
//   break;
//  default:
//   // //  Error?  ...
//   break;

//  }
// }
}


bool RZ_Embed_Branch_Run_Plugin::find_next_token(RZ_Read_Table_State state_not_found,
 RZ_Read_Table_Post_Advance_State post_state_not_found)
{
//? if(caon_ptr<RE_Node> n = main_visitor_.find_next_token())
// {

// }
// else
  if(run_state_.flags.on_embed_redirect_branch)
 {
  // // what about nested embed redirect...?
  caon_ptr<RZ_Graph_Embed_Token> rget; //? = main_visitor_.current_embed_token();
  if(rget)
   rget->advance_arg(current_embed_arg_position_); // main_visitor_.current_embed_arg_position());
  {
   if(current_embed_arg_position_ == 0) //main_visitor_.current_embed_arg_position() == 0)
   {
    run_state_.flags.on_embed_redirect_branch = false;
    // ?
    // run_state_.flags.on_embed_redirect_leave = true;

//?    main_visitor_.pop_embed_branch_node();

    //  return false;

    //check_embed_call_entry(*rget);

    run_state_.flags.on_embed_redirect_branch = false;
    //?main_visitor_.pop_embed_branch_node();
    run_state_.set_read_table_state(state_not_found);
    run_state_.set_post_advance_state(post_state_not_found);
    return false;
   }
   else
   {
    run_state_.set_read_table_state(RZ_Read_Table_State::Expression_Embed_Sequence);
    run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
   }
  }
 }

 else if(run_state_.flags.on_embed_redirect_entry)
 {
  run_state_.flags.on_embed_redirect_entry = false;
  run_state_.flags.on_embed_redirect_leave = true;
  run_state_.set_read_table_state(RZ_Read_Table_State::Expression_Final);
  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
  //?main_visitor_.pop_embed_branch_node();
//  next_node_ = embed_branch_nodes_.top();
//  current_node_ = embed_branch_nodes_.top();
//  embed_branch_nodes_.pop();
 }
// else
// {
//  run_state_.set_read_table_state(state_not_found);
//  run_state_.set_post_advance_state(post_state_not_found);
// }
 return true;

}
