
#include "rz-lisp-graph-visitor.h"

#include "rzns.h"

USING_RZNS(GBuild)


RZ_Lisp_Graph_Visitor_Run_State::RZ_Lisp_Graph_Visitor_Run_State()
 : Flags(0), read_table_state_(RZ_Read_Table_State::Inactive),
     //block_entry_branch_state_(RZ_Block_Entry_Branch_State::N_A),
    post_advance_state_(RZ_Read_Table_Post_Advance_State::N_A),
    advance_token_state_(RZ_Read_Table_Advance_Token_State::Token_Loaded)
{

}


