
#ifndef RZ_INVOCATION_GRAPH_BUILDER__H
#define RZ_INVOCATION_GRAPH_BUILDER__H


#include "rzns.h"

RZNS_(RECore)

class RZ_Invocation_Graph_Builder
{

};


_RZNS(RECore)


#endif //RZ_INVOCATION_GRAPH_BUILDER__H



