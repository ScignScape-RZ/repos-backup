
#ifndef RZ_INVOCATION_TOKEN__H
#define RZ_INVOCATION_TOKEN__H


#include "rzns.h"

RZNS_(RECore)

class RZ_Invocation_Token
{

};


_RZNS(RECore)


#endif //RZ_INVOCATION_DOCK__H

