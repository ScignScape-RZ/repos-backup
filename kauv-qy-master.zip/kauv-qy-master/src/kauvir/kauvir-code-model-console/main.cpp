
#include "kauvir-code-model/kauvir-code-model.h"

#include "kauvir-code-model/kcm-channel-group.h"

#include "kauvir-code-model/kcm-type-object.h"
#include "kauvir-code-model/kcm-expression.h"
#include "kauvir-code-model/kcm-statement.h"


#include "kauvir-type-system/kauvir-type-object.h"
#include "kauvir-type-system/kauvir-type-system.h"

#include <QTextStream>
#include <QDebug>
#include <QFile>

#include "kans.h"


USING_KANS(KCM)

int main(int argc, char* argv[])
{
 Kauvir_Code_Model kcm;
 Kauvir_Type_System& kts = *kcm.type_system();

 QString kcm_code;

 KCM_File* kcf = kcm.create_and_enter_file("<dynamic>");

 KCM_Channel_Group kcg;
 KCM_Statement* kcs = nullptr;
 KCM_Type_Object* kto = nullptr;
 KCM_Type_Object* ckto = nullptr;
 KCM_Block* kcb = nullptr;
 KCM_Expression* kcx = nullptr;
 int oli = 0;

 //kcg.add_lambda_carrier(new KCM_Type_Object(&kts.type_object__u32()));

 // // fn signature
 kto = kcm.type_object_from_channel_group(kcg);
 oli = kcm.add_overloadable_type_binding("hello", kto);
 kcs = kcm.promote_type_binding_to_statement("hello", oli);
 kcs->set_annotation("extern ");
 kcm.add_statement_to_file(kcs, kcf);

 // // fn body
 kcb = kcm.create_and_enter_block();
 kcm.join_statement_to_block(kcs, kcb);

 // // statement
 kcg.clear_all();
 kcg.add_fuxe_carrier("make_kauvir_thorin_embed_environment");
 kcx = kcm.dissolve_to_nested_expression(kcg);
 kto = kcm.get_kcm_type_by_kauvir_type_object(&kts.type_object__u64());
 kcm.add_type_binding("env", kto);
 kcs = kcm.promote_type_binding_to_statement("env", kcx);
 kcm.add_statement_to_block(kcs, kcb);

 // // statement
 kcg.clear_all();
 kcg.add_fuxe_carrier("kauvir_thorin_init_env");
 kcg.add_lambda_carrier_via_symbol("env");
 kcx = kcm.dissolve_to_nested_expression(kcg);
 kcs = kcm.promote_expression_to_statement(kcx);
 kcm.add_statement_to_block(kcs, kcb);


 // // statement
 kcg.clear_all();
 kcg.add_fuxe_carrier("kauvir_thorin_init_env");
 kcg.add_lambda_carrier_via_literal("\"Kauvir_Thorin_Test_Dialog\"");
 kto = kcm.get_kcm_type_by_kauvir_type_object(&kts.type_object__u64());
 kto = kcm.type_with_array_length(kto, 2);
 kto = kcm.type_with_modifiers(kto, KCM_Type_Object::Modifiers::Pointer);
 kcm.add_type_binding("x", kto);
 kcs = kcm.promote_type_binding_to_statement("x", kcx);
 kcm.add_statement_to_block(kcs, kcb);
 //let x: &[u64 * 2] = make_qt_embed_object(env, "Kauvir_Thorin_Test_Dialog");

 // // statement
 kcg.clear_all();
 kcm.push_kcm_code_floor();
 kcg.add_fuxe_carrier("test_qt");
 kcg.add_lambda_carrier_via_symbol("env");
 kcg.add_lambda_carrier_via_symbol("x");
 kcg.add_lambda_carrier_via_literal("\"qinv_testing_uc\"");
 kcg.add_lambda_carrier_via_literal("3u8");
 kcm.push_reserve_kcm_code_lambda(kcg);
  //? kcg.add_lambda_carrier({nullptr, nullptr}, kcx->kcm_code());
 kcx = kcm.dissolve_to_nested_expression(kcg);
 kcg.clear_all();

 kcm.push_kcm_code_floor();
// kcg.add_fuxe_carrier("test5");
// kcg.add_lambda_carrier_via_literal("59");

 ckto = kcm.get_kcm_type_by_kauvir_type_object(&kts.type_object__u64());
 kcg.add_array_carrier_via_symbol_with_cast("x", ckto);
 kcm.push_reserve_kcm_code_array_with_cast(kcg, ckto);
 kcm.push_reserve_kcm_code_array_with_cast(kcg, ckto);

 kcm_code = kcm.pull_kcm_code();
 kcm.dissolve_to_nested_expression(kcg, kcm_code);
 kcg.clear_all();

 kcm.push_kcm_code_floor();
 kcg.add_fuxe_carrier("carry_u32_rW");
 kcg.add_lambda_carrier_via_literal("13u32");
 kcm_code = kcm.pull_kcm_code();
 ckto = kcm.get_kcm_type_by_kauvir_type_object(&kts.type_object__u64());
 kcm.dissolve_to_nested_expression(kcg, kcm_code);
 kcg.clear_all();
 kcm.pop_kcm_code_floor();

 kcm.push_kcm_code_floor();
 kcg.add_fuxe_carrier("carry_u32_rW");
 kcg.add_lambda_carrier_via_literal("14u32");
 kcm_code = kcm.pull_kcm_code();
 ckto = kcm.get_kcm_type_by_kauvir_type_object(&kts.type_object__u64());
 kcm.dissolve_to_nested_expression(kcg, kcm_code);
 kcg.clear_all();
 kcm.pop_kcm_code_floor();

 kcm.pop_kcm_code_floor();



// ckto = kcm.get_kcm_type_by_kauvir_type_object(&kts.type_object__u64());
// kcg.add_array_carrier_via_symbol_with_cast("x", ckto);

// kcm.push_kcm_code_floor();
// kcg.add_fuxe_carrier("carry_u32_rW");
// kcg.add_lambda_carrier_via_literal("13u32");
// kcx = kcm.dissolve_to_nested_expression(kcg);
// kcm.push_kcm_code(kcx->kcm_code());
// kcg.clear_all();
// kcg.add_fuxe_carrier("carry_u32_rW");
// kcg.add_lambda_carrier_via_literal("14u32");
// kcx = kcm.dissolve_to_nested_expression(kcg);
// kcm.push_kcm_code(kcx->kcm_code());

// kcg.clear_all();
// ckto = kcm.get_kcm_type_by_kauvir_type_object(&kts.type_object__u64());
// kcg.add_array_carrier({nullptr, ckto}, kcm.pull_kcm_code());
// ckto = kcm.get_kcm_type_by_kauvir_type_object(&kts.type_object__u64());
// kcg.add_array_carrier({nullptr, ckto}, kcm.pull_kcm_code());
// kcx = kcm.dissolve_to_nested_expression(kcg);
// kcm.pop_kcm_code_floor();


 kcs = kcm.promote_expression_to_statement(kcx);

//?
 kcm.add_statement_to_block(kcs, kcb);
 kcm.leave_block(kcb);

// kcm.add_statement_to_file(kcs, kcf);


 QString rep;
 QTextStream qts(&rep);
 kcm.report_impala(qts);
 qDebug() << rep;

 QFile qf("/ext_root/kauv/thorin-scripts/t1.txt");
 if(qf.open(QIODevice::WriteOnly))
 {
  QTextStream os(&qf);
  os << rep;
  qf.close();
 }
}



int main2(int argc, char* argv[])
{
 Kauvir_Code_Model kcm;
 Kauvir_Type_System& kts = *kcm.type_system();

 QString kcm_code;

 KCM_File* kcf = kcm.create_and_enter_file("<dynamic>");

 KCM_Channel_Group kcg;
 KCM_Statement* kcs = nullptr;
 KCM_Type_Object* kto = nullptr;
 KCM_Type_Object* ckto = nullptr;
 KCM_Block* kcb = nullptr;
 KCM_Expression* kcx = nullptr;
 int oli = 0;


 kcg.clear_all();

 kcm.push_kcm_code_floor();
 kcg.add_fuxe_carrier("test1");
 //?kcg.add_lambda_carrier_via_kcm_code();
 //kcm_code = kcm.push_reserve_kcm_code();
 //kcg.add_lambda_carrier({nullptr, nullptr}, kcm_code);
 kcg.add_lambda_carrier_via_literal("19");
  // kcm_code = kcm.push_reserve_kcm_code();
  // kcg.add_lambda_carrier({nullptr, nullptr}, kcm_code);
 kcm.push_reserve_kcm_code_lambda(kcg);
 kcm.push_reserve_kcm_code_lambda(kcg);
 kcx = kcm.dissolve_to_nested_expression(kcg);
 kcs = kcm.promote_expression_to_statement(kcx);
 kcg.clear_all();

// kcg.add_fuxe_carrier("test2");
// kcg.add_lambda_carrier_via_literal("29");
// kcm_code = kcm.pull_kcm_code();
// kcm.dissolve_to_nested_expression(kcg, kcm_code);
// kcg.clear_all();

//?
 kcm.push_kcm_code_floor();
 kcg.add_fuxe_carrier("test2");
 kcg.add_lambda_carrier_via_literal("29");
 kcm.push_reserve_kcm_code_lambda(kcg);
 kcm.push_reserve_kcm_code_lambda(kcg);
 kcm_code = kcm.pull_kcm_code();
 kcm.dissolve_to_nested_expression(kcg, kcm_code);
 kcg.clear_all();

//?
 kcm.push_kcm_code_floor();
 kcg.add_fuxe_carrier("test3");
 kcg.add_lambda_carrier_via_literal("39");
 kcm_code = kcm.pull_kcm_code();
 kcm.dissolve_to_nested_expression(kcg, kcm_code);
 kcg.clear_all();
 kcm.pop_kcm_code_floor();
//? kcm.pop_kcm_code_floor();


 kcm.push_kcm_code_floor();
 kcg.add_fuxe_carrier("test4");
 kcg.add_lambda_carrier_via_literal("49");
 //kcm.push_reserve_kcm_code_lambda(kcg);
 kcm_code = kcm.pull_kcm_code();
 kcm.dissolve_to_nested_expression(kcg, kcm_code);
 kcg.clear_all();
 kcm.pop_kcm_code_floor();
 kcm.pop_kcm_code_floor();


 kcm.push_kcm_code_floor();
 kcg.add_fuxe_carrier("test5");
 kcg.add_lambda_carrier_via_literal("59");
 kcm_code = kcm.pull_kcm_code();
 kcm.dissolve_to_nested_expression(kcg, kcm_code);
 kcg.clear_all();
 kcm.pop_kcm_code_floor();


// kcm.pop_kcm_code_floor();
// kcm.pop_kcm_code_floor();


 //kcm.promote_expression_to_statement(kcx);
 //kcm.pop_kcm_code_floor();


// kcg.clear_all();
// kcm.push_kcm_code_floor();
// kcg.add_fuxe_carrier("test2");
// kcg.add_lambda_carrier_via_literal("29u32");
// kcx = kcm.dissolve_to_nested_expression(kcg);
 kcs = kcm.promote_expression_to_statement(kcx);
//? kcm.pop_kcm_code_floor();



//?
// kcm.add_statement_to_block(kcs, kcb);
// kcm.leave_block(kcb);

 kcm.add_statement_to_file(kcs, kcf);


 QString rep;
 QTextStream qts(&rep);
 kcm.report_impala(qts);
 qDebug() << rep;

 QFile qf("/ext_root/kauv/thorin-scripts/t1.txt");
 if(qf.open(QIODevice::WriteOnly))
 {
  QTextStream os(&qf);
  os << rep;
  qf.close();
 }
}



int main8(int argc, char* argv[])
{
 Kauvir_Code_Model kcm;
 Kauvir_Type_System& kts = *kcm.type_system();

 QString kcm_code;

 KCM_File* kcf = kcm.create_and_enter_file("<dynamic>");

 KCM_Channel_Group kcg;
 KCM_Statement* kcs = nullptr;
 KCM_Type_Object* kto = nullptr;
 KCM_Type_Object* ckto = nullptr;
 KCM_Block* kcb = nullptr;
 KCM_Expression* kcx = nullptr;
 int oli = 0;

 kcm.push_kcm_code_floor();
 kcg.add_fuxe_carrier("test_qt");
 kcg.add_lambda_carrier_via_symbol("env");
 kcg.add_lambda_carrier_via_symbol("x");
 ckto = kcm.get_kcm_type_by_kauvir_type_object(&kts.type_object__u64());
 kcm.push_reserve_kcm_code_lambda_with_cast(kcg, ckto);
 kcx = kcm.dissolve_to_nested_expression(kcg);
 kcg.clear_all();

 // nested
 kcm.push_kcm_code_floor();
 kcg.add_fuxe_carrier("test1");
 kcg.add_lambda_carrier_via_literal("1");
 kcm_code = kcm.pull_kcm_code();
 kcm.dissolve_to_nested_expression(kcg, kcm_code);
 kcg.clear_all();
 kcm.pop_kcm_code_floor();
 kcm.pop_kcm_code_floor();

 kcs = kcm.promote_expression_to_statement(kcx);

//?
// kcm.add_statement_to_block(kcs, kcb);
// kcm.leave_block(kcb);

 kcm.add_statement_to_file(kcs, kcf);


 QString rep;
 QTextStream qts(&rep);
 kcm.report_lisp(qts);
 qDebug() << rep;

 QFile qf("/ext_root/kauv/thorin-scripts/t2.txt");
 if(qf.open(QIODevice::WriteOnly))
 {
  QTextStream os(&qf);
  os << rep;
  qf.close();
 }

}


int main7(int argc, char* argv[])
{
 Kauvir_Code_Model kcm;
 Kauvir_Type_System& kts = *kcm.type_system();

 QString kcm_code;

 KCM_File* kcf = kcm.create_and_enter_file("<dynamic>");

 KCM_Channel_Group kcg;
 KCM_Statement* kcs = nullptr;
 KCM_Type_Object* kto = nullptr;
 KCM_Type_Object* ckto = nullptr;
 KCM_Block* kcb = nullptr;
 KCM_Expression* kcx = nullptr;
 int oli = 0;

#ifdef HIDE
 //kcg.add_lambda_carrier(new KCM_Type_Object(&kts.type_object__u32()));

 // // fn signature
 kto = kcm.type_object_from_channel_group(kcg);
 oli = kcm.add_overloadable_type_binding("hello", kto);
 kcs = kcm.promote_type_binding_to_statement("hello", oli);
 kcs->set_annotation("extern ");
 kcm.add_statement_to_file(kcs, kcf);

 // // fn body
 kcb = kcm.create_and_enter_block();
 kcm.join_statement_to_block(kcs, kcb);

 // // statement
 kcg.clear_all();
 kcg.add_fuxe_carrier("make_kauvir_thorin_embed_environment");
 kcx = kcm.dissolve_to_nested_expression(kcg);
 kto = kcm.get_kcm_type_by_kauvir_type_object(&kts.type_object__u64());
 kcm.add_type_binding("env", kto);
 kcs = kcm.promote_type_binding_to_statement("env", kcx);
 kcm.add_statement_to_block(kcs, kcb);

 kcg.clear_all();
 kcg.add_fuxe_carrier("kauvir_thorin_init_env");
 kcg.add_lambda_carrier_via_symbol("env");
 kcx = kcm.dissolve_to_nested_expression(kcg);
 kcs = kcm.promote_expression_to_statement(kcx);
 kcm.add_statement_to_block(kcs, kcb);


 kcg.clear_all();
 kcg.add_fuxe_carrier("kauvir_thorin_init_env");
 kcg.add_lambda_carrier_via_literal("\"Kauvir_Thorin_Test_Dialog\"");
 kto = kcm.get_kcm_type_by_kauvir_type_object(&kts.type_object__u64());
 kto = kcm.type_with_array_length(kto, 2);
 kto = kcm.type_with_modifiers(kto, KCM_Type_Object::Modifiers::Pointer);
 kcm.add_type_binding("x", kto);
 kcs = kcm.promote_type_binding_to_statement("x", kcx);
 kcm.add_statement_to_block(kcs, kcb);
 //let x: &[u64 * 2] = make_qt_embed_object(env, "Kauvir_Thorin_Test_Dialog");
#endif //HIDE


 kcg.clear_all();
 kcm.push_kcm_code_floor();
 kcg.add_fuxe_carrier("test_qt");
 kcg.add_lambda_carrier_via_symbol("env");
 kcg.add_lambda_carrier_via_symbol("x");
 kcg.add_lambda_carrier_via_literal("\"qinv_testing_uc\"");
 kcg.add_lambda_carrier_via_literal("3u8");
 kcm.push_reserve_kcm_code_lambda(kcg);
  //? kcg.add_lambda_carrier({nullptr, nullptr}, kcx->kcm_code());
 kcx = kcm.dissolve_to_nested_expression(kcg);
 kcg.clear_all();

 kcm.push_kcm_code_floor();
// kcg.add_fuxe_carrier("test5");
// kcg.add_lambda_carrier_via_literal("59");

 ckto = kcm.get_kcm_type_by_kauvir_type_object(&kts.type_object__u64());
 kcg.add_array_carrier_via_symbol_with_cast("x", ckto);
 kcm.push_reserve_kcm_code_array_with_cast(kcg, ckto);
 kcm.push_reserve_kcm_code_array_with_cast(kcg, ckto);

 kcm_code = kcm.pull_kcm_code();
 kcm.dissolve_to_nested_expression(kcg, kcm_code);
 kcg.clear_all();

 kcm.push_kcm_code_floor();
 kcg.add_fuxe_carrier("carry_u32_rW");
 kcg.add_lambda_carrier_via_literal("13u32");
 kcm_code = kcm.pull_kcm_code();
 ckto = kcm.get_kcm_type_by_kauvir_type_object(&kts.type_object__u64());
 kcm.dissolve_to_nested_expression(kcg, kcm_code);
 kcg.clear_all();
 kcm.pop_kcm_code_floor();

 kcm.push_kcm_code_floor();
 kcg.add_fuxe_carrier("carry_u32_rW");
 kcg.add_lambda_carrier_via_literal("14u32");
 kcm_code = kcm.pull_kcm_code();
 ckto = kcm.get_kcm_type_by_kauvir_type_object(&kts.type_object__u64());
 kcm.dissolve_to_nested_expression(kcg, kcm_code);
 kcg.clear_all();
 kcm.pop_kcm_code_floor();

 kcm.pop_kcm_code_floor();



// ckto = kcm.get_kcm_type_by_kauvir_type_object(&kts.type_object__u64());
// kcg.add_array_carrier_via_symbol_with_cast("x", ckto);

// kcm.push_kcm_code_floor();
// kcg.add_fuxe_carrier("carry_u32_rW");
// kcg.add_lambda_carrier_via_literal("13u32");
// kcx = kcm.dissolve_to_nested_expression(kcg);
// kcm.push_kcm_code(kcx->kcm_code());
// kcg.clear_all();
// kcg.add_fuxe_carrier("carry_u32_rW");
// kcg.add_lambda_carrier_via_literal("14u32");
// kcx = kcm.dissolve_to_nested_expression(kcg);
// kcm.push_kcm_code(kcx->kcm_code());

// kcg.clear_all();
// ckto = kcm.get_kcm_type_by_kauvir_type_object(&kts.type_object__u64());
// kcg.add_array_carrier({nullptr, ckto}, kcm.pull_kcm_code());
// ckto = kcm.get_kcm_type_by_kauvir_type_object(&kts.type_object__u64());
// kcg.add_array_carrier({nullptr, ckto}, kcm.pull_kcm_code());
// kcx = kcm.dissolve_to_nested_expression(kcg);
// kcm.pop_kcm_code_floor();


 kcs = kcm.promote_expression_to_statement(kcx);

//?
// kcm.add_statement_to_block(kcs, kcb);
// kcm.leave_block(kcb);

 kcm.add_statement_to_file(kcs, kcf);


 QString rep;
 QTextStream qts(&rep);
 kcm.report_lisp(qts);
 qDebug() << rep;

 QFile qf("/ext_root/kauv/thorin-scripts/t2.txt");
 if(qf.open(QIODevice::WriteOnly))
 {
  QTextStream os(&qf);
  os << rep;
  qf.close();
 }
}





//kcm.join_statement_to_expression(kcs1, kcx1);
// kcm.join_statement_to_block(main_kcs, kcb);
// KCM_Statement* kcs1 = kcm.promote_expression_to_statement(kcx1);
//KCM_Channel_Group kcg2;
 //kcg1.add_fuxe_carrier("make_kauvir_thorin_embed_environment");
 //KCM_Expression* kcx1 = kcm.dissolve_to_nested_expression(kcg1);
 //KCM_Statement* kcs1 = kcm.promote_expression_to_statement(kcx1);




// KCM_Channel_Group kcgx;
// kcgx.add_fuxe_carrier("+");
// kcgx.add_lambda_carrier(new KCM_Type_Object(&kts.type_object__u32()), "7");
// kcgx.add_lambda_carrier(new KCM_Type_Object(&kts.type_object__u32()), "8");

// //?kcm.hold_dissolve(0, kcgx);
// KCM_Expression* kcx1 = kcm.dissolve_to_nested_expression(kcgx);

// kcgx.clear_all();
// kcgx.add_fuxe_carrier("+");
// kcgx.add_lambda_carrier(new KCM_Type_Object(&kts.type_object__auto_expr()), kcx1->kcm_code());
// kcgx.add_lambda_carrier(new KCM_Type_Object(&kts.type_object__u32()), "9");

// //kcgx.add_preempt_carrier(new KCM_Type_Object(&kts.type_object__auto_expr()), );

// KCM_Expression* kcx2 = kcm.dissolve_to_nested_expression(kcgx);
// kcgx.clear_all();

// kcgx.add_fuxe_carrier("pr");
// kcgx.add_lambda_carrier(new KCM_Type_Object(&kts.type_object__auto_expr()), kcx2->kcm_code());
// KCM_Expression* kcx3 = kcm.dissolve_to_expression(kcgx);

// KCM_Statement* kcs = kcm.promote_expression_to_statement(kcx3);
// KCM_Block* kcb = kcm.create_and_enter_block();
// kcm.add_statement_to_block(kcs, kcb);
// kcm.leave_block(kcb);

// kcm.join_statement_to_block(main_kcs, kcb);

// kcm.add_statement_to_file(main_kcs, kcf);

// kcg.clear_all();

// QString rep;
// QTextStream qts(&rep);
// kcm.report_lisp(qts);
// qDebug() << rep;

// QFile qf("/ext_root/kauv/thorin-scripts/t1.txt");
// if(qf.open(QIODevice::WriteOnly))
// {
//  QTextStream os(&qf);
//  os << rep;
//  qf.close();
// }






//int main(int argc, char* argv[])
//{
// Kauvir_Code_Model kcm;
// Kauvir_Type_System& kts = *kcm.type_system();

// KCM_File* kcf = kcm.create_and_enter_file("<dynamic>");

// KCM_Channel_Group kcg;

// kcg.add_lambda_carrier(new KCM_Type_Object(&kts.type_object__u32()));
// KCM_Type_Object* kto = kcm.type_object_from_channel_group(kcg);

// int main_oli = kcm.add_overloadable_type_binding("main", kto);
// KCM_Statement* main_kcs = kcm.promote_type_binding_to_statement("main", main_oli);

// KCM_Channel_Group kcgx;
// kcgx.add_fuxe_carrier("+");
// kcgx.add_lambda_carrier(new KCM_Type_Object(&kts.type_object__u32()), "7");
// kcgx.add_lambda_carrier(new KCM_Type_Object(&kts.type_object__u32()), "8");

// //?kcm.hold_dissolve(0, kcgx);
// KCM_Expression* kcx1 = kcm.dissolve_to_nested_expression(kcgx);

// kcgx.clear_all();
// kcgx.add_fuxe_carrier("+");
// kcgx.add_lambda_carrier(new KCM_Type_Object(&kts.type_object__auto_expr()), kcx1->kcm_code());
// kcgx.add_lambda_carrier(new KCM_Type_Object(&kts.type_object__u32()), "9");

// //kcgx.add_preempt_carrier(new KCM_Type_Object(&kts.type_object__auto_expr()), );

// KCM_Expression* kcx2 = kcm.dissolve_to_nested_expression(kcgx);
// kcgx.clear_all();

// kcgx.add_fuxe_carrier("pr");
// kcgx.add_lambda_carrier(new KCM_Type_Object(&kts.type_object__auto_expr()), kcx2->kcm_code());
// KCM_Expression* kcx3 = kcm.dissolve_to_expression(kcgx);

// KCM_Statement* kcs = kcm.promote_expression_to_statement(kcx3);
// KCM_Block* kcb = kcm.create_and_enter_block();
// kcm.add_statement_to_block(kcs, kcb);
// kcm.leave_block(kcb);

// kcm.join_statement_to_block(main_kcs, kcb);

// kcm.add_statement_to_file(main_kcs, kcf);

//// kcm.add_declaration_statement("main", kto);
//// kcm.add_default_type_assignment_statement("main");


// //?kcg.add_lambda_carrier(&kr.type_system().type_object__str());
// //?Kauvir_Channel_Group* kcg = kr.add_declared_function("reset_test_label_text", g1);
// //?kr.add_declared_function("reset_test_label_text", kcg, reinterpret_cast<fn2_type>(
// //?  (void (Kauvir_Test_Dialog::*)(int, QString&))(&Kauvir_Test_Dialog::reset_test_label_text)
// //?  ));


// kcg.clear_all();

// QString rep;
// QTextStream qts(&rep);
// kcm.report_lisp(qts);
// qDebug() << rep;

// QFile qf("/ext_root/kauv/thorin-scripts/t1.txt");
// if(qf.open(QIODevice::WriteOnly))
// {
//  QTextStream os(&qf);
//  os << rep;
//  qf.close();
// }

//}
