
#include "kcm-block.h"

#include "kcm-statement.h"

#include "kcm-report-syntax.h"

#include "kans.h"

USING_KANS(KCM)
USING_KANS(Kauvir)

//KCM_Lexical_Block


KCM_Block::KCM_Block(KCM_Lexical_Scope* lexical_scope)
  :  lexical_scope_(lexical_scope)
{
}

void KCM_Block::add_statement(KCM_Statement* statement)
{
 statements_.push_back(statement);
}

void KCM_Block::report(QTextStream& qts, Kauvir_Code_Model& kcm, KCM_Report_Syntax& kcrs)
{
 if(kcrs.flags.use_block_braces)
 {
  qts << " {\n";
 }
 else
 {
  qts << "\n;; block ;; \n";
 }

 for(KCM_Statement* statement : statements_)
 {
  statement->report(qts, kcm, kcrs, lexical_scope_);
  qts << "\n";
 }

 if(kcrs.flags.use_block_braces)
 {
  qts << " }\n";
 }

}
