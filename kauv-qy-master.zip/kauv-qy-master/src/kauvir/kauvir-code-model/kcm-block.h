
#ifndef KCM_BLOCK__H
#define KCM_BLOCK__H


#include "kans.h"

#include "accessors.h"
#include "flags.h"

#include <QVector>
#include <QTextStream>


KANS_CLASS_DECLARE(Kauvir ,Kauvir_Type_Object)
USING_KANS(Kauvir)



KANS_(KCM)


//
class KCM_Channel_Group;
class KCM_Report_Syntax;

class Kauvir_Code_Model;
//class KCM_Lexical_Symbol;
//
class KCM_Statement;

class KCM_Expression;
class KCM_Statement;
class KCM_Lexical_Scope;

class KCM_Block
{
 QVector<KCM_Statement*> statements_;

 KCM_Lexical_Scope* lexical_scope_;

public:

 KCM_Block(KCM_Lexical_Scope* lexical_scope);

 ACCESSORS(KCM_Lexical_Scope* ,lexical_scope)

 void add_statement(KCM_Statement* statement);

 void report(QTextStream& qts, Kauvir_Code_Model& kcm, KCM_Report_Syntax& kcrs);


};


_KANS(KCM)


#endif //KCM_CARRIER__H
