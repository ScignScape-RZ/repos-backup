
#include "kcm-file.h"

#include "kcm-statement.h"

#include "kans.h"

USING_KANS(KCM)
USING_KANS(Kauvir)

//KCM_Lexical_Block


KCM_File::KCM_File(QString file_name)
  :  file_name_(file_name)
{
}

void KCM_File::add_statement(KCM_Statement* statement)
{
 statements_.push_back(statement);
}

void KCM_File::report(QTextStream& qts, Kauvir_Code_Model& kcm, KCM_Report_Syntax& kcrs)
{
 qts << "\n;; " << file_name_ << " ;; \n\n";

 for(KCM_Statement* statement : statements_)
 {
  statement->report(qts, kcm, kcrs, nullptr);
  qts << "\n";
 }
}

