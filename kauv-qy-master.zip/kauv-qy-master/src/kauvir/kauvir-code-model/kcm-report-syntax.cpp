
#include "kcm-report-syntax.h"

#include "kans.h"

USING_KANS(KCM)
USING_KANS(Kauvir)

//KCM_Lexical_Block


KCM_Report_Syntax::KCM_Report_Syntax()
  :  Flags(0)
{
}

QString KCM_Report_Syntax::get_channel_kind_code(KCM_Channel::Kinds kind)
{
 return channel_kind_codes_.value(kind);
}

