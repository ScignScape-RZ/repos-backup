
#include "kcm-statement.h"

#include "kcm-expression.h"
#include "kauvir-code-model.h"

#include "kcm-block.h"

#include "kans.h"

USING_KANS(KCM)
USING_KANS(Kauvir)

//KCM_Lexical_Block

//KCM_Statement::KCM_Statement(KCM_Expression* expression)
//  :  expression_(expression), nested_block_(nullptr)
//{
//}


KCM_Statement::KCM_Statement(Statement_Kinds statement_kind, KCM_Expression* expression)
 :  statement_kind_(statement_kind), expression_(expression),
   nested_block_(nullptr), bind_qob_(nullptr)
{

}

KCM_Statement::KCM_Statement(Statement_Kinds statement_kind, KCM_Overloadable_Symbol symbol)
 :  statement_kind_(statement_kind), symbol_(symbol),
    expression_(nullptr), nested_block_(nullptr),
    bind_kto_(nullptr), bind_qob_(nullptr)
{

}

KCM_Statement::KCM_Statement(Statement_Kinds statement_kind,
   QString symbol_name, KCM_Expression* expression)
 :  statement_kind_(statement_kind),
    symbol_(KCM_Overloadable_Symbol(symbol_name, 0)),
    expression_(expression),
    nested_block_(nullptr),
    bind_kto_(nullptr), bind_qob_(nullptr)
{

}

KCM_Statement::KCM_Statement(Statement_Kinds statement_kind,
  QString symbol_name, const KCM_Type_Object* kto, QString val)
 :  statement_kind_(statement_kind),
    symbol_(KCM_Overloadable_Symbol(symbol_name, 0)),
    expression_(nullptr),
    nested_block_(nullptr),
    bind_kto_(kto), bind_val_(val), bind_qob_(nullptr)
{

}

KCM_Statement::KCM_Statement(Statement_Kinds statement_kind,
  QString symbol_name, const KCM_Type_Object* kto, QObject* qob)
 :  statement_kind_(statement_kind),
    symbol_(KCM_Overloadable_Symbol(symbol_name, 0)),
    expression_(nullptr),
    nested_block_(nullptr),
    bind_kto_(kto), bind_qob_(qob)
{

}



void KCM_Statement::check_report_nested_block(QTextStream& qts, Kauvir_Code_Model& kcm, KCM_Report_Syntax& kcrs)
{
 if(!nested_block_)
 {
  // // always?
  //?
  if(statement_kind_ == Statement_Kinds::Type_Binding)
  {
   qts << ";";
  }
  return;
 }
 switch(statement_kind_)
 {

 default:
  nested_block_->report(qts, kcm, kcrs);
 }
}


void KCM_Statement::report(QTextStream& qts, Kauvir_Code_Model& kcm,
  KCM_Report_Syntax& kcrs, KCM_Lexical_Scope* scope)
{
 switch(statement_kind_)
 {
 case Statement_Kinds::Promoted_Expression:
  {
   // assume expression_
   expression_->report(qts, kcm, kcrs);
   if(kcrs.flags.use_block_statement_syntax)
   {
    qts << ";\n";
   }
   check_report_nested_block(qts, kcm, kcrs);
  }
 break;
 case Statement_Kinds::Type_Binding_With_Expression:
  {
   if(kcrs.flags.use_statement_annotations)
   {
    qts << annotation_;
   }
   qts << " let ";
   symbol_.report(qts, kcm, kcrs);
   //QString tx =
   kcm.report_type_expression_for_overloadable_symbol(qts, kcrs, symbol_,
     KCM_Channel::Code_Environments::Statement, scope);

   // // different kinds of binding?
   qts << " = ";

   expression_->report(qts, kcm, kcrs);
   if(kcrs.flags.use_block_statement_syntax)
   {
    qts << ";\n";
   }
  }
  break;
 case Statement_Kinds::Type_Binding:
  {
   QString post_annotation;
   if(kcrs.flags.use_statement_annotations)
   {
    int ind = annotation_.indexOf("@@@");
    if(ind != -1)
    {
     qts << annotation_.mid(0, ind);
     post_annotation = annotation_.mid(ind + 3);
    }
   }

   if(kcrs.flags.use_keyword_for_function_types)
   {
    QString fn = kcm.get_function_type_keyword_for_overloadable_symbol(symbol_, scope);
    if(!fn.isEmpty())
    {
     qts << fn << ' ';
    }
   }
   symbol_.report(qts, kcm, kcrs);
   //QString tx =
   kcm.report_type_expression_for_overloadable_symbol(qts, kcrs, symbol_,
     KCM_Channel::Code_Environments::Statement, scope);
   //?qts << tx;
   check_report_nested_block(qts, kcm, kcrs);

   qts << post_annotation;
  }
 break;

 }
}
