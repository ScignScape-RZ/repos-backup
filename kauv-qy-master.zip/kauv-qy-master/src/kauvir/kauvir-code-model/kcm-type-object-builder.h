
#ifndef KCM_TYPE_OBJECT_BUILDER__H
#define KCM_TYPE_OBJECT_BUILDER__H


#include "kans.h"

#include "accessors.h"

#include "kcm-channel-group.h"

#include <QObject>

#include <QString>

//KANS_(Kauvir)

//?
KANS_CLASS_DECLARE(Kauvir ,Kauvir_Thorin_Runtime)
USING_KANS(Kauvir)
USING_KANS(KCM)




class KCM_Type_Object_Builder : public QObject
{
 Q_OBJECT

 //QString raw_text_;


 KCM_Channel_Group scratch_channel_group_;

 Kauvir_Thorin_Runtime* kauvir_thorin_runtime_;


public:

 KCM_Type_Object_Builder(const KCM_Type_Object_Builder& rhs);

 KCM_Type_Object_Builder();


 ACCESSORS(Kauvir_Thorin_Runtime* ,kauvir_thorin_runtime)

 ACCESSORS__CONST_RGET(KCM_Channel_Group ,scratch_channel_group)


 //Kauvir_Type_Object_Builder(QString raw_text);

 //ACCESSORS(QString ,raw_text)

 Q_INVOKABLE void add_cpp_equivalent_type(QString type_name, QString cpp_name = QString());


 Q_INVOKABLE void add_lambda_carrier(QString type_name,
   int effect_protocol = 0, QString symbol_name = QString() );

 Q_INVOKABLE void add_result_carrier(QString type_name,
   int effect_protocol = 0, QString symbol_name = QString() );

 void clear_scratch(QString followup_code);

};

//_KANS(Kauvir)

Q_DECLARE_METATYPE(KCM_Type_Object_Builder)
Q_DECLARE_METATYPE(KCM_Type_Object_Builder*)



#endif
