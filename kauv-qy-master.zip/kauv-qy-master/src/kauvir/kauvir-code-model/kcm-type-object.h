
#ifndef KCM_TYPE_OBJECT__H
#define KCM_TYPE_OBJECT__H


#include "kans.h"

#include "accessors.h"
#include "flags.h"

#include <QVector>
#include <QTextStream>


KANS_CLASS_DECLARE(Kauvir ,Kauvir_Type_Object)
USING_KANS(Kauvir)



KANS_(KCM)


class KCM_Channel_Group;
class Kauvir_Code_Model;
class KCM_Report_Syntax;

//class KCM_Lexical_Symbol;
//class KCM_Lexical_Statement;


class KCM_Type_Object
{
public:

 enum class Modifiers {

  N_A, Pointer, Reference, Const,
  Const_Pointer_To_Const, Const_Pointer,
  Pointer_To_Const, Const_Reference,
  Reference_To_Pointer

 };

private:

 const Kauvir_Type_Object* kauvir_type_object_;
 KCM_Channel_Group* channel_group_;

 int array_length_;
 Modifiers modifier_;

 int qmetatype_ptr_code_;

public:

 KCM_Type_Object(KCM_Channel_Group* channel_group);
 KCM_Type_Object(const Kauvir_Type_Object* kauvir_type_object);
 KCM_Type_Object();


 ACCESSORS(KCM_Channel_Group* ,channel_group)
 ACCESSORS(const Kauvir_Type_Object* ,kauvir_type_object)
 ACCESSORS(int ,array_length)
 ACCESSORS(Modifiers ,modifier)
 ACCESSORS(int ,qmetatype_ptr_code)

 static Modifiers get_modifier_by_string(QString str);

 bool is_string_like() const;
 bool is_lisp_list_like() const;


 void report(QTextStream& qts, Kauvir_Code_Model& kcm, KCM_Report_Syntax& kcrs) const;

 QString token_report(Kauvir_Code_Model& kcm) const;

 KCM_Type_Object* base_clone() const;
};


_KANS(KCM)


#endif //KCM_CARRIER__H
