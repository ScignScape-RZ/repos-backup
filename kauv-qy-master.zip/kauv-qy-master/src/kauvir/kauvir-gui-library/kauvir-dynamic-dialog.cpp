
#include "kauvir-dynamic-dialog.h"

#include <QPushButton>

#include <functional>

#include <QVariant>

#include <QMap>

#include <QDebug>
#include <QMetaMethod>

#include "kauvir-lisp-embed/kauvir-lisp-eval.h"

#include "kauvir-lisp-embed/kauvir-lisp-kargs.h"

#include "kauvir-lisp-each/kauvir-lisp-callback.h"

#include "cl-cxx/object.hpp"


#define SLOT(a) "1"#a

Kauvir_Dynamic_Dialog::Kauvir_Dynamic_Dialog(QWidget* parent)
  :  QDialog(parent), kauvir_lisp_eval_(nullptr)
{
 main_layout_ = new QVBoxLayout;

 main_layout_->setObjectName("layout.main");

 test_label_ = new QLabel("ready ...");

 main_layout_->addWidget(test_label_);

 setLayout(main_layout_);

 show();

}

void Kauvir_Dynamic_Dialog::init_default_button_box()
{
 QDialogButtonBox* button_box = new QDialogButtonBox(this);

 QPushButton* button_ok = new QPushButton("OK", this);
 //button_send_ = new QPushButton("Send", this);
 QPushButton* button_cancel = new QPushButton("Cancel", this);

 button_ok->setDefault(false);
 button_ok->setAutoDefault(false);

// button_send_->setDefault(false);
// button_send_->setAutoDefault(false);

 button_cancel->setDefault(true);

 button_ok->setEnabled(false);

 button_box->addButton(button_ok, QDialogButtonBox::AcceptRole);
  //?button_box->addButton(button_send_, QDialogButtonBox::ApplyRole);
 button_box->addButton(button_cancel, QDialogButtonBox::RejectRole);


 //connect(button_send_, SIGNAL(clicked()), this, SLOT(handle_send()));
 connect(button_box, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box, SIGNAL(rejected()), this, SLOT(cancel()));

 main_layout_->addWidget(button_box);

}

void Kauvir_Dynamic_Dialog::add_layout(QString parent, QString child)
{
 QObject* po = findChild<QObject*>(parent);
 QObject* co = findChild<QObject*>(child);

 QLayout* qlp = qobject_cast<QLayout*>(po);
 QLayout* qlc = qobject_cast<QLayout*>(co);

 qlc->setParent(nullptr);

 qlp->addItem(qlc);

}

Kauvir_Dynamic_Dialog::Kauvir_Dynamic_Dialog(const Kauvir_Dynamic_Dialog& rhs)
  :  Kauvir_Dynamic_Dialog( qobject_cast<QWidget*>(rhs.parent()) )
{
 //kauvir_lisp_eval_ = rhs.kauvir_lisp_eval_;
}



void Kauvir_Dynamic_Dialog::cancel()
{
 Q_EMIT canceled(this);
}

#define TEMP_MACRO(cn) {QMetaType::metaObjectForType(QMetaType::type(#cn "*")), \
   [](){return new cn;} },


QObject* Kauvir_Dynamic_Dialog::make_qobject_from_metaobject(const QMetaObject* qmo)
{
 static QMap<const QMetaObject*, std::function<QObject*()> > static_map {{
   TEMP_MACRO(QPushButton)
   TEMP_MACRO(QDialog)
   TEMP_MACRO(QHBoxLayout)
//   {QMetaType::metaObjectForType(QMetaType::type("QPushButton*")),
//      [](){return new QPushButton;} },
//   {QMetaType::metaObjectForType(QMetaType::type("QDialog*")),
//      [](){return new QDialog;}}
   }};

 if(static_map.contains(qmo))
 {
  return static_map[qmo]();
 }
}

void Kauvir_Dynamic_Dialog::add_child(QString objn, QString layout_name)
{
 QObject* co = findChild<QObject*>(objn);
 QObject* lo = findChild<QObject*>(layout_name);

 QLayout* ql = qobject_cast<QLayout*>(lo);
 QWidget* qw = qobject_cast<QWidget*>(co);

 main_layout_->removeWidget(qw);

 ql->addWidget(qw);

}

void Kauvir_Dynamic_Dialog::set_property(QString objn, QString property_name, QString value)
{
 test_label_->setText("OK...");
 QObject* qob = findChild<QObject*>(objn);
 if(qob)
 {
  qob->setProperty(property_name.toLatin1(), QVariant(value));
 }
}

void Kauvir_Dynamic_Dialog::add_stretch(QString layout_name)
{
 QObject* qob = findChild<QObject*>(layout_name);
 if(qob)
 {
  QBoxLayout* ql = qobject_cast<QBoxLayout*>(qob);
  if(ql)
  {
   ql->addStretch();
  }
 }
}

void Kauvir_Dynamic_Dialog::dynamic_slot()
{
 QObject* qob = sender();

 int ssi = QObject::senderSignalIndex();

 const QMetaObject* qmo = qob->metaObject();

 QMetaMethod qmm = qmo->method(ssi);

 QString qmms = qmm.methodSignature();

 QString cn = qob->objectName();

 Lisp_Callable_Value lcv = lisp_callbacks_.value({cn, ssi});

 if(kauvir_lisp_eval_)
 {
  Kauvir_Lisp_Kargs kargs(this);
  //?  kauvir_lisp_eval_->run_callable_lisp_value(lcv, this);
  kauvir_lisp_eval_->run_callable_lisp_value(lcv, &kargs);
 }
}

void Kauvir_Dynamic_Dialog::import_lisp_eval(void* pv)
{
 import_lisp_eval(static_cast<Kauvir_Lisp_Eval*>(pv));
}

void Kauvir_Dynamic_Dialog::import_lisp_eval(Kauvir_Lisp_Eval* kle)
{
 kauvir_lisp_eval_ = kle;
}

void Kauvir_Dynamic_Dialog::add_connect1(QString objn, void* callable_lisp_value)
{

}

void Kauvir_Dynamic_Dialog::test_connect(QString objn, void* clo)
{
 cl_object co = (cl_object) clo;
 //QString pr =
  //? kauvir_lisp_eval_->run_callable_lisp_value(co, this);
 //qDebug() << pr;
 //cl_object clp = cl_print(co);
}

void Kauvir_Dynamic_Dialog::add_connect(QString objn, QString signal_name,
  Kauvir_Lisp_Callback* klc)
{
 QObject* qob = findChild<QObject*>(objn);
 if(qob)
 {
  const QMetaObject* qmo = qob->metaObject();
  int ios = qmo->indexOfSignal(signal_name.toLatin1());
  if(ios != -1)
  {
   QMetaMethod qmm = qmo->method(ios);
   const QMetaObject* this_qmo = this->metaObject();

   lisp_callbacks_[{objn, ios}] = Lisp_Callable_Value(klc, "Kauvir_Lisp_Callback");

   int this_ios = this_qmo->indexOfSlot("dynamic_slot()");
   QMetaMethod this_qmm = this_qmo->method(this_ios);

   connect(qob, qmm, this, this_qmm);
  }

 }
}



void Kauvir_Dynamic_Dialog::add_connect(QString objn, QString signal_name, QString lisp_code)
{
 QObject* qob = findChild<QObject*>(objn);
 if(qob)
 {
  const QMetaObject* qmo = qob->metaObject();
  int ios = qmo->indexOfSignal(signal_name.toLatin1());
  if(ios != -1)
  {
   QMetaMethod qmm = qmo->method(ios);
   const QMetaObject* this_qmo = this->metaObject();

   lisp_callbacks_[{objn, ios}] = Lisp_Callable_Value(lisp_code);

   int this_ios = this_qmo->indexOfSlot("dynamic_slot()");
   QMetaMethod this_qmm = this_qmo->method(this_ios);

   connect(qob, qmm, this, this_qmm);
  }

 }
}


void Kauvir_Dynamic_Dialog::new_layout(QString class_name, QString objn)
{
 class_name.append('*');
 int qmetatype_id = QMetaType::type(class_name.toLatin1());
 if (qmetatype_id != 0)
 {
  const QMetaObject* qmo = QMetaType::metaObjectForType(qmetatype_id);

  //QObject* qo = make_qobject_from_metaobject(qmo);//Q_ARG(QObject* ,this));
  QString cn = QString::fromLatin1(qmo->className());

  QObject* qo = make_qobject_from_metaobject(qmo);//Q_ARG(QObject* ,this));

  qo->setObjectName(objn);

  qo->setParent(main_layout_);

 }
}

void Kauvir_Dynamic_Dialog::new_child(QString class_name, QString objn)
{
 class_name.append('*');
 int qmetatype_id = QMetaType::type(class_name.toLatin1());
 if (qmetatype_id != 0)
 {
  const QMetaObject* qmo = QMetaType::metaObjectForType(qmetatype_id);

  QString cn = QString::fromLatin1(qmo->className());

  QObject* qo = make_qobject_from_metaobject(qmo);//Q_ARG(QObject* ,this));
  //void* pv = QMetaType::create(id);
  QWidget* qw = static_cast<QWidget*>(qo);

  qw->setObjectName(objn);

  main_layout_->addWidget(qw);
 }
}

Kauvir_Dynamic_Dialog::~Kauvir_Dynamic_Dialog()
{

}
