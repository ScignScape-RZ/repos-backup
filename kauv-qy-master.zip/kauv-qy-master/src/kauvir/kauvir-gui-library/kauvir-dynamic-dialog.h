
#ifndef KAUVIR_DYNAMIC_DIALOG__H
#define KAUVIR_DYNAMIC_DIALOG__H

#include <QDialog>
#include <QVBoxLayout>
#include <QPushButton>
#include <QDialogButtonBox>
#include <QLabel>
#include <QMap>
#include <QPair>


#include <QStringList>

#include "kauvir-type-system/kauvir-universal-class.h"

//
//?#include "kauvir-lisp-embed/kauvir-lisp-callable-value.h"

KANS_CLASS_DECLARE(Kauvir ,Kauvir_Lisp_Eval)
KANS_CLASS_DECLARE(Kauvir ,Kauvir_Lisp_Callback)


USING_KANS(Kauvir)


//?class Kauvir_Lisp_Callback;

class Kauvir_Dynamic_Dialog : public QDialog, public Kauvir_Universal_Class
{
 Q_OBJECT

 QVBoxLayout* main_layout_;

 QMap<QPair<QString, int>, Lisp_Callable_Value> lisp_callbacks_;

 Kauvir_Lisp_Eval* kauvir_lisp_eval_;


 QLabel* test_label_;

 //QMap<QLayout*,


public:

 Kauvir_Dynamic_Dialog(QWidget* parent = nullptr);

 Kauvir_Dynamic_Dialog(const Kauvir_Dynamic_Dialog& rhs);

 ~Kauvir_Dynamic_Dialog();

 void import_lisp_eval(Kauvir_Lisp_Eval* kle);


 Q_INVOKABLE void import_lisp_eval(void* pv);

 Q_INVOKABLE void init_default_button_box();

 Q_INVOKABLE void new_child(QString class_name, QString objn);

 Q_INVOKABLE void add_child(QString objn, QString layout_name);

 Q_INVOKABLE void add_stretch(QString layout_name);

 Q_INVOKABLE void set_property(QString objn, QString property_name, QString value);

 Q_INVOKABLE void new_layout(QString class_name, QString objn);

 Q_INVOKABLE void add_layout(QString parent, QString child);

 Q_INVOKABLE void add_connect(QString objn, QString signal_name, QString lisp_code);

 Q_INVOKABLE void add_connect(QString objn, QString signal_name,
   Kauvir_Lisp_Callback* klc);

 Q_INVOKABLE void add_connect1(QString objn, void* callable_lisp_value);

 Q_INVOKABLE void test_connect(QString objn, void* clo);

 static QObject* make_qobject_from_metaobject(const QMetaObject* qmo);

public Q_SLOTS:

 void cancel();

 void dynamic_slot();

Q_SIGNALS:

 void canceled(QDialog*);
 void accepted();



};


Q_DECLARE_METATYPE(Kauvir_Dynamic_Dialog)
Q_DECLARE_METATYPE(Kauvir_Dynamic_Dialog*)

#endif
