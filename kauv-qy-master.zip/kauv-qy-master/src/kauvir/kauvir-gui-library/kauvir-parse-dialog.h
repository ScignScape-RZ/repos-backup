
#ifndef KAUVIR_PARSE_DIALOG__H
#define KAUVIR_PARSE_DIALOG__H


#include <QString>
#include <QMainWindow>

#include <QTextEdit>
//?#include <QWebView>

#include <QLabel>
#include <QPushButton>

#include <QDialog>

#include <QApplication>

#include <QComboBox>

#include "accessors.h"

#include "flags.h"

#include <QEvent>
#include <QMouseEvent>

#include "kauvir-type-system/kauvir-universal-class.h"


class QPushButton;
class QTextEdit;
class QPlainTextEdit;
class QLineEdit;
class QTabWidget;
class QDialogButtonBox;
class QVBoxLayout;
class QHBoxLayout;
class QCheckBox;
class QFormLayout;
class QSplitter;
class QGridLayout;
class QListWidget;
class QTableWidget;
class QScrollArea;
class QGroupBox;
class QTableWidgetItem;
class QGraphicsRectItem;
class QRubberBand;

class QGraphicsItem;
class QGraphicsView;
class QGraphicsScene;
class QGraphicsTextItem;


struct Sentence_Analysis_Package
{
 QList<QGraphicsTextItem*> items;
 QMap<QString, QGraphicsTextItem*> items_map;
 QStringList word_list;
 QStringList types_list;
};

class Kauvir_Parse_Dialog : public QDialog, public Kauvir_Universal_Class
{
 Q_OBJECT

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QPushButton* button_proceed_;

 QLabel* url_label_;
 QLineEdit* url_line_edit_;


// QMediaPlayer* media_player_;
// QGraphicsVideoItem* video_item_;

 QGraphicsScene* graphics_scene_;
 QGraphicsView* graphics_view_;

 QHBoxLayout* central_layout_;

 QFormLayout* lexical_info_layout_;

 Sentence_Analysis_Package* current_sentence_analysis_package_;

// graphicsView->scene()->addItem(item);
// graphicsView->show();

// player->setMedia(QUrl("http://example.com/myclip4.ogv"));
// player->play();

// QHBoxLayout* navigation_layout_;
// QPushButton* navigation_rewind_button_;
// QPushButton* navigation_pause_button_;
// QPushButton* navigation_forward_button_;

 QHBoxLayout* url_layout_;
 QVBoxLayout* main_layout_;

 Q_INVOKABLE void parse_sentence(QString sentence);


// void add_link_marking(QString left, QString right,
//   qreal left_offset, qreal right_offset,
//   QString label, QPen& qpen,
//   qreal height,
//   QMap<QString, QGraphicsTextItem*>& items_map);


 Q_INVOKABLE void parse_types(QString lex);//, QStringList& types);

public:

 Kauvir_Parse_Dialog(QWidget* parent = nullptr);

 Kauvir_Parse_Dialog(const Kauvir_Parse_Dialog& rhs);


 ~Kauvir_Parse_Dialog();


Q_SIGNALS:

 void canceled(QDialog*);
 void accepted(QDialog*);


public Q_SLOTS:
 void accept();
 void cancel();
 //?void proceed();

// void go_button_clicked();
// void close_button_clicked();


};


Q_DECLARE_METATYPE(Kauvir_Parse_Dialog)
Q_DECLARE_METATYPE(Kauvir_Parse_Dialog*)



#endif

