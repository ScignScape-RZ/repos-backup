
#include "kauvir-test-dialog.h"

#include <QDebug>


Kauvir_Test_Dialog::Kauvir_Test_Dialog(QWidget* parent)
  :  QDialog(parent)
{
 main_layout_ = new QVBoxLayout;

 button_box_ = new QDialogButtonBox(this);

 test_label_ = new QLabel("Text ...", this);

 button_ok_ = new QPushButton("OK");
 button_send_ = new QPushButton("Send");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

 button_send_->setDefault(false);
 button_send_->setAutoDefault(false);

 button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_send_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);


 connect(button_send_, SIGNAL(clicked()), this, SLOT(handle_send()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));

 main_layout_->addWidget(button_box_);

 setLayout(main_layout_);

 show();

}


Kauvir_Test_Dialog::Kauvir_Test_Dialog(const Kauvir_Test_Dialog& rhs)
  :  Kauvir_Test_Dialog( qobject_cast<QWidget*>(rhs.parent()) )
{

}

int Kauvir_Test_Dialog::qinv_nums_ret(int n1, int n2)
{
 qDebug() << "Nums: " << (n1 + n2);
 return n1 + n2;
}

void Kauvir_Test_Dialog::qinv_nums(int n1, int n2)
{
 qDebug() << "Nums: " << (n1 + n2);
}

void Kauvir_Test_Dialog::qinv_num_str(int n1, QString n2)
{
 qDebug() << "Num: " << n1;
 qDebug() << "Str: " << n2;
}

void Kauvir_Test_Dialog::qinv_str(QString n2)
{
 qDebug() << "Str: " << n2;
}

void Kauvir_Test_Dialog::qinv_num(int n1)
{
 qDebug() << "Num: " << n1;
}

void Kauvir_Test_Dialog::reset_test_label_text(QString* text)
{
 test_label_->setText(*text);
}

void Kauvir_Test_Dialog::qinv_noarg_uc()
{
 test_label_->setText("No ARG UC");
}


void Kauvir_Test_Dialog::qinv_noarg()
{
 test_label_->setText("No ARG");
}

void Kauvir_Test_Dialog::reset_test_label_text(int text, QString& t1)
{
 test_label_->setText(QString::number(text) + ", " + t1);
 //?++text;
}

void Kauvir_Test_Dialog::qinv_test(int text, int add, QString t1)
{
 test_label_->setText(QString::number(text + add) + ", " + t1);
}

void Kauvir_Test_Dialog::qinv_test(int text, QString& t1)
{
 test_label_->setText(QString::number(text) + ", " + t1);
}

void Kauvir_Test_Dialog::qinv_test(QString t1)
{
 test_label_->setText(t1);
}

void Kauvir_Test_Dialog::reset_test_label_text_ref(quint64& text, QString& t1)
{
 test_label_->setText(QString::number(text) + ", " + t1);
 //?++text;
}


void Kauvir_Test_Dialog::set_test_label_text(QString& text)
{
 test_label_->setText(text);
}


void Kauvir_Test_Dialog::cancel()
{
 Q_EMIT canceled(this);

}


Kauvir_Test_Dialog::~Kauvir_Test_Dialog()
{

}
