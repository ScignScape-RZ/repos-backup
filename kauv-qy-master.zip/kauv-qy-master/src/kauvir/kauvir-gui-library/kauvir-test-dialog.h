
#ifndef KAUVIR_TEST_DIALOG__H
#define KAUVIR_TEST_DIALOG__H

#include <QDialog>
#include <QVBoxLayout>
#include <QPushButton>
#include <QDialogButtonBox>
#include <QLabel>

#include <QStringList>

#include "kauvir-type-system/kauvir-universal-class.h"


class Kauvir_Test_Dialog : public QDialog, public Kauvir_Universal_Class
{
 Q_OBJECT

 QVBoxLayout* main_layout_;

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QPushButton* button_send_;

 QLabel* test_label_;


public:

 Kauvir_Test_Dialog(QWidget* parent = nullptr);

 Kauvir_Test_Dialog(const Kauvir_Test_Dialog& rhs);

 ~Kauvir_Test_Dialog();

//?
 void reset_test_label_text(QString* text);

 //?

  void reset_test_label_text(int text, QString& t1);

  void reset_test_label_text_ref(quint64& text, QString& t1);

  void qinv_noarg_uc();


   Q_INVOKABLE void qinv_noarg();

   //? void reset_test_label_text(int& text, QString& t1);

  Q_INVOKABLE void qinv_nums(int n1, int n2);
  Q_INVOKABLE void qinv_num_str(int n1, QString n2);

  Q_INVOKABLE int qinv_nums_ret(int n1, int n2);

  Q_INVOKABLE void qinv_num(int n1);
  Q_INVOKABLE void qinv_str(QString n2);

 Q_INVOKABLE void qinv_test(int text, int add, QString t1);
 Q_INVOKABLE void qinv_test(int text, QString& t1);
 Q_INVOKABLE void qinv_test(QString t1);

  void set_test_label_text(QString& text);

public Q_SLOTS:

 void cancel();

Q_SIGNALS:

 void canceled(QDialog*);
 void accepted();



};


Q_DECLARE_METATYPE(Kauvir_Test_Dialog)
Q_DECLARE_METATYPE(Kauvir_Test_Dialog*)

#endif
