
#include "kauvir-image-view-dialog.h"

#include "styles.h"


#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QTimer>
#include <QScreen>

#include <QButtonGroup>
#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>
#include <QComboBox>

#include <QDateEdit>

#include <QLineEdit>
#include <QTextStream>

#include <QPainter>
#include <QPushButton>
#include <QLabel>

#include <QPlainTextEdit>

#include <QTableWidget>
#include <QGraphicsPixmapItem>

#include <QMessageBox>
#include <QDebug>

#include <QGraphicsView>


#include <QHeaderView>

#include <QMenu>
#include <QAction>

#include <QListWidget>
#include <QDateEdit>



Kauvir_Image_View_Dialog::Kauvir_Image_View_Dialog(QString file_path, QWidget* parent)
  : QDialog(parent) //, file_path_(file_path)
{
 //?arrow_factory_ = new MMUI_Arrow_Factory;

 button_box_ = new QDialogButtonBox(this);

 button_ok_ = new QPushButton("OK");
 button_proceed_ = new QPushButton("Proceed");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

 button_proceed_->setDefault(false);
 button_proceed_->setAutoDefault(false);
 //?button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);

 button_ok_->setStyleSheet(basic_button_style_sheet_());
 button_proceed_->setStyleSheet(basic_button_style_sheet_());
 button_cancel_->setStyleSheet(basic_button_style_sheet_());


 connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));

 button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);


 main_layout_ = new QVBoxLayout;

 image_view_ = new Kauvir_Image_View(file_path, this);

 connect(image_view_, SIGNAL(screenshot_requested()),
   this, SLOT(take_screenshot()));

 image_view_layout_ = new QHBoxLayout;

 //?
 //
 image_view_layout_->addStretch();

 //image_view_layout_->addSpacing(50);

 image_view_layout_->addWidget(image_view_);
 //?
 image_view_layout_->addStretch();

 main_layout_->addLayout(image_view_layout_);

 //test_slider_ = new ctkRangeSlider(Qt::Horizontal, this);
//? test_slider_->setMinimum(0);
//? test_slider_->setMaximum(100);

 //test_slider_->s

// connect(test_button_, &QPushButton::clicked,
//         [this]
// {
//  image_view_->image_resize(100, 100);
// }
// );

 //?main_layout_->addWidget(test_slider_);

 main_layout_->addWidget(button_box_);

// connect(this, &QDialog::resize, []()
// {

// });


 //?main_layout_->addLayout(clear_button_layout_);

 setLayout(main_layout_);

 show();
}

void Kauvir_Image_View_Dialog::resizeEvent(QResizeEvent* ev)
{
 QSize qsz = ev->size();

 int w = qsz.width();
 int h = qsz.height();

 image_view_->image_resize(w - 30, h - 120);
}

void Kauvir_Image_View_Dialog::take_screenshot()
{
 QScreen* screen = QGuiApplication::primaryScreen();
  if (!screen)
      return;
 QApplication::beep();

 //medMainWindow* mainWindow = qobject_cast <medMainWindow *> (parent());


 int target_window_id  = this->winId();

 QTimer::singleShot(10000, [=]
 {
  QPixmap pixmap = screen->grabWindow(target_window_id);

  QString path = "/ext_root/kauv/screenshots/imvd.png";

  qDebug() << "Saving to path: " << path;
  QFile file(path);
  if(file.open(QIODevice::WriteOnly))
  {
   pixmap.save(&file, "PNG");
  }
 });

}

void Kauvir_Image_View_Dialog::accept()
{

}

void Kauvir_Image_View_Dialog::cancel()
{

}

Kauvir_Image_View_Dialog::~Kauvir_Image_View_Dialog()
{

}


