
#ifndef KAUVIR_WSI_IMAGE_VIEW_DIALOG__H
#define KAUVIR_WSI_IMAGE_VIEW_DIALOG__H

#include <QObject>

#include <QMetaType>

#include <QList>
#include <QGraphicsScene>
#include <QPoint>

#include <QDialog>

//?#include "MoND-UI/controls/single-edit-combo-box.h"

#include "accessors.h"

#include "subwindows/range-slider.h"

#include "subwindows/kauvir-image-view.h"

#include "subwindows/nav-protocols/nav-image-multisize-panel.h"
#include "subwindows/nav-protocols/nav-geometric-2d-panel.h"


class QDialogButtonBox;
class QLabel;
class QLineEdit;
class QTabWidget;
class QPlainTextEdit;
class QTextEdit;
class QFrame;
class QHBoxLayout;
class QVBoxLayout;
class QGridLayout;
class QSlider;
class QLineEdit;
class QBoxLayout;
class QButtonGroup;
class QGroupBox;
class QFormLayout;
class QComboBox;
class QDateEdit;
class QScrollArea;

//QSNS_(ScignStage)
//?namespace QScign { namespace ScignStage {

class Kauvir_WSI_Image_View_Dialog : public QDialog
{

 Q_OBJECT

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QPushButton* button_proceed_;


 QVBoxLayout* main_layout_;
 QHBoxLayout* image_view_layout_;


 Kauvir_Image_View* image_view_;

 NAV_Geometric2D_Panel* nav_panel_;

 //?ctkRangeSlider* test_slider_;

 void resizeEvent(QResizeEvent* ev) override;


public:


 Kauvir_WSI_Image_View_Dialog(QString file_path, QWidget* parent = nullptr);

 ~Kauvir_WSI_Image_View_Dialog();


Q_SIGNALS:

 void canceled(QDialog*);
 void accepted(QDialog*);


public Q_SLOTS:

 void accept();
 void cancel();
 void take_screenshot();

};


#endif  // KAUVIR_WSI_IMAGE_VIEW_DIALOG__H
