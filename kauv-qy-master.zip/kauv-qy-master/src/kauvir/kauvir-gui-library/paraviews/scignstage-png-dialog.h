
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)



#ifndef SCIGNSTAGE_PNG_DIALOG__H
#define SCIGNSTAGE_PNG_DIALOG__H

#include <QObject>

#include <QMetaType>

#include <QList>
#include <QGraphicsScene>
#include <QPoint>

#include <QDialog>

//?#include "MoND-UI/controls/single-edit-combo-box.h"

#include "accessors.h"
#include "qsns.h"

class QDialogButtonBox;
class QLabel;
class QLineEdit;
class QTabWidget;
class QPlainTextEdit;
class QTextEdit;
class QFrame;
class QHBoxLayout;
class QVBoxLayout;
class QGridLayout;
class QSlider;
class QLineEdit;
class QBoxLayout;
class QButtonGroup;
class QGroupBox;
class QFormLayout;
class QComboBox;
class QDateEdit;
class QScrollArea;

QSNS_(ScignStage)
//?namespace QScign { namespace ScignStage {

class ScignStage_PNG_Dialog : public QDialog
{

 Q_OBJECT

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QPushButton* button_proceed_;


 QVBoxLayout* main_layout_;

 QHBoxLayout* image_layout_;

 QLabel* image_label_;

 QPixmap* image_pixmap_;

 QPixmap* scrolled_image_pixmap_;

 //QGraphicsScene *scene
 QGraphicsView* scrolled_image_view_;
 QGraphicsScene* scrolled_image_scene_;
 QGraphicsPixmapItem* scrolled_image_pixmap_item_;

 QFormLayout* info_form_layout_;
 QHBoxLayout* info_form_position_layout_;

 QMap<QString, QString> image_property_data_;

 QString file_path_;
 void parse_image_info();

 //?QScrollArea* image_scroll_area_;

public:


 ScignStage_PNG_Dialog(QString file_path, QWidget* parent = nullptr);

 ~ScignStage_PNG_Dialog();


Q_SIGNALS:

 void canceled(QDialog*);
 void accepted(QDialog*);


public Q_SLOTS:

 void accept();
 void cancel();

};

_QSNS(ScignStage)

#endif  // SCIGNSTAGE_PNG_DIALOG__H
