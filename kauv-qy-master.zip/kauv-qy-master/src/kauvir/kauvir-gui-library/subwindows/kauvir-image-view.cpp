
#include "kauvir-image-view.h"

#include <QPushButton>

#include <QButtonGroup>

#include <functional>

#include <QVariant>

#include <QEvent>

#include <QMap>

#include <QDebug>
#include <QMetaMethod>

#include <QGraphicsPixmapItem>

//?#include "kauvir-lisp-embed/kauvir-lisp-eval.h"

#include "changeImage.h"

//?#include "cl-cxx/object.hpp"
//?
#define SLOT(a) "1"#a

Kauvir_Image_View::Kauvir_Image_View(QString file_path, QWidget* parent)
  :  QWidget(parent), zoom_rate_(8), handle_zoom_ok_(false)
{
 main_layout_ = new QVBoxLayout;

 image_layout_ = new QHBoxLayout;

// image_label_ = new QLabel("Image ...", this);
// image_pixmap_ = new QPixmap(QPixmap(file_path).scaledToHeight(100));
// image_label_->setPixmap(*image_pixmap_);

 scrolled_image_pixmap_ = new QPixmap(file_path);

 int sipw = scrolled_image_pixmap_->width();
 int siph = scrolled_image_pixmap_->height();


 scrolled_image_view_ = new QGraphicsView(this);
 scrolled_image_scene_ = new QGraphicsScene(this);
  //?scrolled_image_label_ = new QLabel("Scrolled Image ...", this);
  //?scrolled_image_label_->setPixmap(*scrolled_image_pixmap_);

 scrolled_image_view_->setScene(scrolled_image_scene_);

 background_rectangle_ = scrolled_image_scene_->addRect(0, 0, sipw * 2, siph * 2);
 background_rectangle_center_x_ = background_rectangle_->boundingRect().x() +
   (background_rectangle_->boundingRect().width() / 2);
 background_rectangle_center_y_ = background_rectangle_->boundingRect().y() +
   (background_rectangle_->boundingRect().height() / 2);

 scrolled_image_pixmap_item_ = scrolled_image_scene_->addPixmap(*scrolled_image_pixmap_);
 scrolled_image_pixmap_item_->setPos(0,0);

 scrolled_image_pixmap_item_->setFlags(QGraphicsItem::ItemIsMovable);




//? scrolled_image_view_->resize(300, 300);

//? scrolled_image_view_->setFixedHeight(300);
//? scrolled_image_view_->setFixedWidth(500);

//? image_scroll_area_ = new QScrollArea(this);
//? image_scroll_area_->setWidget(scrolled_image_view_);

 //image_scroll_area_->setGeometry(0, 0, 300, 100);

//? image_scroll_area_->setFixedHeight(100);
//? image_scroll_area_->setFixedWidth(200);

 //image_pixmap_->setDevicePixelRatio(0.5);

 //?image_layout_->addWidget(image_label_);
 //?image_layout_->addWidget(image_scroll_area_);

//? image_layout_->addStretch();

 image_layout_->addWidget(scrolled_image_view_);


//? image_layout_->addStretch();

 main_layout_->addLayout(image_layout_);

 zoom_slider_ = new ctkRangeSlider(Qt::Horizontal, this);

 connect(zoom_slider_, SIGNAL(minimumValueChanged(int)), this,
   SLOT(handle_zoom_minimum_value_changed(int)));

 connect(zoom_slider_, SIGNAL(maximumValueChanged(int)), this,
   SLOT(handle_zoom_maximum_value_changed(int)));

// test_slider_ = new QSlider(Qt::Horizontal, this);

// connect(test_slider_, SIGNAL(valueChanged(int)), this,
//   SLOT(handle_windowing_value_changed(int)));

 main_layout_->addWidget(zoom_slider_);
 //main_layout_->addWidget(test_slider_);

 contrast_button_group_layout_ = new QHBoxLayout;

 contrast_button_group_ = new QButtonGroup(this);

 contrasts_ = QVector<int> {
   {50,100,150,200}
                         };

 contrast_button_group_->setExclusive(true);

 contrast_button_group_layout_->addStretch();
 for(int c : contrasts_)
 {
  QPushButton* b = new QPushButton(QString::number(c), this);
  contrast_button_group_layout_->addWidget(b);
  contrast_button_group_->addButton(b);
 }
 contrast_button_group_layout_->addStretch();

 connect(contrast_button_group_, SIGNAL(buttonClicked(int)),
   this, SLOT(handle_contrast_button_clicked(int)) );

 main_layout_->addLayout(contrast_button_group_layout_);

 //?
 direct_adjust_zoom(40);
 //scrolled_image_pixmap_item_->setScale(2);

 recenter_image();

 zoom_slider_->setMinimumValue(40);
 zoom_slider_->setMaximumValue(40);

 original_scrolled_image_pixmap_ = scrolled_image_pixmap_;

 //?grabGesture(Qt::PinchGesture);

// Qt::TapGesture	1	A Tap gesture.
// Qt::TapAndHoldGesture	2	A Tap-And-Hold (Long-Tap) gesture.
// Qt::PanGesture	3	A Pan gesture.
// Qt::PinchGesture	4	A Pinch gesture.
// Qt::SwipeGesture

 setLayout(main_layout_);

 handle_zoom_ok_ = true;

}


void Kauvir_Image_View::handle_contrast_button_clicked(int id)
{
 if(id == -2)
 {
  Q_EMIT screenshot_requested();
 }
 else
 {
  int index = -id -2;
  qDebug() << "index: " << index;
  int contrast = contrasts_[index];
  reset_image_contrast(contrast);
 }
}


void Kauvir_Image_View::recenter_image()
{
 int w = scrolled_image_pixmap_item_->boundingRect().width() *
   scrolled_image_pixmap_item_->scale();
 int h = scrolled_image_pixmap_item_->boundingRect().height() *
   scrolled_image_pixmap_item_->scale();

 int new_left = background_rectangle_center_x_ - (w/2);
 int new_top = background_rectangle_center_y_ - (h/2);

 scrolled_image_pixmap_item_->setPos(new_left, new_top);


}


bool Kauvir_Image_View::event(QEvent* evt)
{
 if(evt->type() == QEvent::Gesture)
 {
  qDebug() << "ttt";
  return false;
 }
 else
 {
  return this->QWidget::event(evt);
 }
}


void Kauvir_Image_View::image_resize(int w, int h)
{
 scrolled_image_view_->resize(w, h);
}

void Kauvir_Image_View::reset_image_contrast(int amount)
{
 QPixmap* qpm = pixmaps_by_contrast_measure_.value(amount);

 if(!qpm) //pixmaps_by_contrast_measure_.contains(amount))
 {
  qpm = new QPixmap(transmationImage::changeContrast(*original_scrolled_image_pixmap_, amount));
  pixmaps_by_contrast_measure_.insert(amount, qpm);
 }

 scrolled_image_pixmap_item_->setPixmap(*qpm);

}


void Kauvir_Image_View::handle_windowing_value_changed(int val)
{
 if( (val % 5) == 0 )
 {
  reset_image_contrast(25 + val);
 }
}

void Kauvir_Image_View::direct_adjust_zoom(int z)
{
 qreal vr = (qreal)z / 10;

 qreal adj_ratio = vr * (2.0/5.0);

 scrolled_image_pixmap_item_->setScale(adj_ratio);

}


void Kauvir_Image_View::adjust_zoom(int z)
{
 //  v == 50  r == 3
 //  v == 1   r == 1/10

 // v / 10

 if(handle_zoom_ok_)
 {
  direct_adjust_zoom(z);

  recenter_image();

//  qreal vr = (qreal)z / 10;
//  qreal adj_ratio = vr;
//  qreal w1 = scrolled_image_pixmap_item_->boundingRect().width();
//  qreal h1 = scrolled_image_pixmap_item_->boundingRect().height();
//  scrolled_image_pixmap_item_->setScale(adj_ratio);
//  qreal w2 = scrolled_image_pixmap_item_->boundingRect().width();
//  qreal h2 = scrolled_image_pixmap_item_->boundingRect().height();

//  if(w2 > w1)
//  {
//   qreal woffset = (w2 - w1)/2;
//   qreal hoffset = (h2 - h1)/2;
//   scrolled_image_pixmap_item_->setPos(scrolled_image_pixmap_item_->pos().x() - woffset,
//     scrolled_image_pixmap_item_->pos().y() - hoffset );
//   //scrolled_image_view_->set
//  }
//  else
//  {
//   qreal woffset = (w1 - w2)/2;
//   qreal hoffset = (h1 - h2)/2;
//   scrolled_image_pixmap_item_->setPos(scrolled_image_pixmap_item_->pos().x() + woffset,
//     scrolled_image_pixmap_item_->pos().y() + hoffset );
//  }
 }
}

void Kauvir_Image_View::handle_zoom_minimum_value_changed(int val)
{
 zoom_slider_->setMaximumValue(100 - val);

 if(val > 0)
 {
  adjust_zoom(val);
 }


 //qDebug() << "min " << val;
}

void Kauvir_Image_View::handle_zoom_maximum_value_changed(int val)
{
 zoom_slider_->setMinimumValue(100 - val);

 if(val > 0)
 {
  adjust_zoom(100 - val);
 }
}

