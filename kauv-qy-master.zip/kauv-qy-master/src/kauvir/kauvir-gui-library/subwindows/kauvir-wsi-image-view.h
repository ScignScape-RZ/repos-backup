
#ifndef KAUVIR_IMAGE_VIEW__H
#define KAUVIR_IMAGE_VIEW__H

#include <QDialog>
#include <QVBoxLayout>
#include <QPushButton>
#include <QDialogButtonBox>
#include <QLabel>
#include <QMap>
#include <QPair>


#include <QStringList>

#include <QImage>
#include <QGraphicsView>
#include <QGraphicsScene>

//USING_KANS(Kauvir)

#include "subwindows/range-slider.h"


class Kauvir_Image_View : public QWidget //, public Kauvir_Universal_Class
{
 Q_OBJECT

 QVBoxLayout* main_layout_;

 QHBoxLayout* image_layout_;

// QLabel* image_label_;
// QPixmap* image_pixmap_;

 QPixmap* scrolled_image_pixmap_;

 QPixmap* original_scrolled_image_pixmap_;

 QMap<int, QPixmap*> pixmaps_by_contrast_measure_;

 //QGraphicsScene *scene
 QGraphicsView* scrolled_image_view_;
 QGraphicsScene* scrolled_image_scene_;
 QGraphicsPixmapItem* scrolled_image_pixmap_item_;

 //?
 ctkRangeSlider* zoom_slider_;

 //QSlider* test_slider_;

 QButtonGroup* contrast_button_group_;// = new QButtonGroup

 QHBoxLayout* contrast_button_group_layout_;

 void adjust_zoom(int z);

 void direct_adjust_zoom(int z);

 //QPushButton* test_button_;

 QString file_path_;

 int zoom_rate_;

 bool handle_zoom_ok_;

 QGraphicsRectItem* background_rectangle_;

 int background_rectangle_center_x_;
 int background_rectangle_center_y_;

 QVector<int> contrasts_;

 void recenter_image();

 void reset_image_contrast(int amount);

public:

 Kauvir_Image_View(QString file_path, QWidget* parent = nullptr);

 void image_resize(int w, int h);

 bool event(QEvent* evt) override;

public Q_SLOTS:

 void handle_zoom_minimum_value_changed(int val);
 void handle_zoom_maximum_value_changed(int val);

 void handle_windowing_value_changed(int val);

 void handle_contrast_button_clicked(int id);

};


#endif
