
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)



#include "nav-image-multisize-panel.h"

#include "styles.h"

#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QSlider>
#include <QButtonGroup>
#include <QGroupBox>

//USING_QSNS(ScignStage)

NAV_Image_Multisize_Panel::NAV_Image_Multisize_Panel(QWidget* parent)
  :  QFrame(parent), old_zoom_slider_value_(1)
{
 main_layout_ = new QVBoxLayout;
 navigation_layout_ = new QHBoxLayout;

 zoom_row_column_layout_ = new QVBoxLayout;
 row_column_layout_ = new QHBoxLayout;

 row_label_ = new QLabel("Row:", this);
 row_line_edit_ = new QLineEdit(this);
 row_line_edit_->setPlaceholderText("?");
 row_line_edit_->setMaximumWidth(30);

 column_label_ = new QLabel("Column:", this);
 column_line_edit_ = new QLineEdit(this);
 column_line_edit_->setPlaceholderText("?");
 column_line_edit_->setMaximumWidth(30);

 row_column_layout_->addWidget(row_label_);
 row_column_layout_->addWidget(row_line_edit_);

 row_column_layout_->addWidget(column_label_);
 row_column_layout_->addWidget(column_line_edit_);

 navigation_layout_ = new QHBoxLayout;
 sort_series_layout_ = new QVBoxLayout;

 zoom_row_column_layout_ = new QVBoxLayout;

 zoom_layout_ = new QHBoxLayout;

 zoom_row_column_layout_->addLayout(row_column_layout_);

 tile_larger_button_ = new QPushButton(this);
 tile_smaller_button_ = new QPushButton(this);
 tile_previous_group_button_ = new QPushButton(this);
 tile_next_group_button_ = new QPushButton(this);


 tile_larger_button_->setIcon(QIcon(DEFAULT_ICON_FOLDER "/Human-go-up.svg"));
 tile_smaller_button_->setIcon(QIcon(DEFAULT_ICON_FOLDER "/Human-go-down.svg"));

 tile_previous_group_button_->setIcon(QIcon(DEFAULT_ICON_FOLDER "/Human-go-previous.svg"));
 tile_next_group_button_->setIcon(QIcon(DEFAULT_ICON_FOLDER "/Human-go-next.svg"));

 connect(tile_larger_button_, SIGNAL(clicked()),
   this, SIGNAL(multisize_larger_requested()));

 connect(tile_smaller_button_, SIGNAL(clicked()),
   this, SIGNAL(multisize_smaller_requested()));

 connect(tile_previous_group_button_, SIGNAL(clicked()),
   this, SIGNAL(previous_group_requested()));

 connect(tile_next_group_button_, SIGNAL(clicked()),
   this, SIGNAL(next_group_requested()));


 navigation_buttons_previous_next_layout_ = new QHBoxLayout;

 navigation_buttons_previous_next_layout_->addWidget(tile_previous_group_button_);
 navigation_buttons_previous_next_layout_->addWidget(tile_next_group_button_);


 navigation_buttons_layout_ = new QGridLayout;

 navigation_buttons_layout_->addWidget(tile_larger_button_, 0, 0);
 navigation_buttons_layout_->addWidget(tile_smaller_button_, 1, 0);

 navigation_layout_->addLayout(navigation_buttons_layout_);

 navigation_layout_->addStretch();

 navigation_layout_->addLayout(navigation_buttons_previous_next_layout_);

 navigation_layout_->addStretch();

 QLabel* zoom_label = new QLabel("Image Zoom:", this);

 zoom_layout_->addWidget(zoom_label);

 zoom_slider_ = new QSlider(Qt::Horizontal, this);


 connect(zoom_slider_, SIGNAL(valueChanged(int)), this,
   SLOT(zoom_slider_value_changed(int)));



 QString s1 = QString("%1").arg(QChar(5184));
 zoom_in_button_ = new QPushButton(s1, this);
 zoom_in_button_->setStyleSheet("QPushButton{font-size: 12pt;"
                                "font-weight: bold;"
                                "color: brown;}");
// zoom_in_button_->setFont(zif);
 zoom_in_button_->setMaximumWidth(25);
 zoom_in_button_->setMaximumHeight(15);


 QString s2 = QString("%1").arg(QChar(5189));
 zoom_out_button_ = new QPushButton(s2, this);
 zoom_out_button_->setStyleSheet("QPushButton{font-size: 12pt;"
                                "font-weight: bold; padding:0px; "
                                "color: brown;}");
 zoom_out_button_->setMaximumWidth(25);
 zoom_out_button_->setMaximumHeight(15);

 connect(zoom_in_button_, SIGNAL(pressed()), this, SIGNAL(zoom_in_requested()));
 connect(zoom_out_button_, SIGNAL(pressed()), this, SIGNAL(zoom_out_requested()));

 zoom_layout_->addStretch();

 zoom_layout_->addWidget(zoom_slider_);
 zoom_layout_->addItem(new QSpacerItem(15, 1));

 zoom_layout_->addWidget(zoom_out_button_);
 zoom_layout_->addItem(new QSpacerItem(5, 1));

 zoom_layout_->addWidget(zoom_in_button_);

 zoom_layout_->addItem(new QSpacerItem(16, 1));

 zoom_layout_->addStretch();

 zoom_row_column_layout_->addLayout(zoom_layout_);


 navigation_layout_->addLayout(zoom_row_column_layout_);

 navigation_layout_->addStretch();


 main_layout_->addLayout(navigation_layout_);



 setLayout(main_layout_);


}

NAV_Image_Multisize_Panel::~NAV_Image_Multisize_Panel()
{

}

void NAV_Image_Multisize_Panel::set_row_text(int r)
{
 row_line_edit_->setText(QString::number(r));
}

void NAV_Image_Multisize_Panel::set_column_text(int c)
{
 column_line_edit_->setText(QString::number(c));
}

void NAV_Image_Multisize_Panel::zoom_slider_value_changed(int val)
{
 int diff = val - old_zoom_slider_value_;
 old_zoom_slider_value_ = val;
 int max = zoom_slider_->maximum();
 //int current = val;

 qreal ratio = 1 + ((qreal)diff)/((qreal)max);

 //?
 //main_pixmap_item_->setScale(main_pixmap_item_->scale() * ratio);

 Q_EMIT(scale_ratio_change_requested(ratio));

}

void NAV_Image_Multisize_Panel::set_row_and_column_text(int r, int c)
{
 set_row_text(r);
 set_column_text(c);
}


