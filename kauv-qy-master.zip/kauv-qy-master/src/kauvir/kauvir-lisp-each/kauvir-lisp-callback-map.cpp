
#include "kauvir-lisp-callback-map.h"

#include "kans.h"

USING_KANS(Kauvir)

Kauvir_Lisp_Callback_Map::Kauvir_Lisp_Callback_Map()
{

}

void Kauvir_Lisp_Callback_Map::add_callback(QString key, Kauvir_Lisp_Callback& cb)
{
 callbacks_.insert(key, cb);
}

Kauvir_Lisp_Callback* Kauvir_Lisp_Callback_Map::get_callback(QString key)
{
 auto it = callbacks_.find(key);
 return it.operator ->();
 //RZ_QClasp_Callback* result = callbacks_.find(key);
}
