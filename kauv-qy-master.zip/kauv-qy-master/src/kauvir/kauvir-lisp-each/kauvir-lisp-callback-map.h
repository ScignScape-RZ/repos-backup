
#ifndef KAUVIR_LISP_CALLBACK_MAP__H
#define KAUVIR_LISP_CALLBACK_MAP__H

#include "rzns.h"

#include "accessors.h"

#include "kauvir-lisp-callback.h"

#include <functional>

#include <QString>
#include <QMap>

KANS_(Kauvir)


class Kauvir_Lisp_Callback_Map
{
 QMap<QString, Kauvir_Lisp_Callback> callbacks_;

public:

 Kauvir_Lisp_Callback_Map();

 void add_callback(QString key, Kauvir_Lisp_Callback& cb);

 Kauvir_Lisp_Callback* get_callback(QString key);
};


_KANS(Kauvir)


#endif
