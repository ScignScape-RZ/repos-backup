
#include "kauvir-lisp-callback.h"

#include "kans.h"



USING_KANS(Kauvir)


Kauvir_Lisp_Callback::Kauvir_Lisp_Callback(void* lisp_function_pointer)
 : lisp_function_pointer_(lisp_function_pointer), status_(Status::N_A)
{

// core::Function_sp fn = fn_symbol->symbolFunction().asOrNull<core::Function_O>();
// //?core::General_sp a1 = arg_list.takeFirst();
// core::T_sp fn_result = core::eval::funcall(fn, arg_list[0], arg_list[1]);
// core::T_sp& retval_tsp = reinterpret_cast<core::T_sp&>(*result);
// retval_tsp = fn_result;


}

bool Kauvir_Lisp_Callback::needs_init()
{
 return status_ == Status::Marked_Async;
}

bool Kauvir_Lisp_Callback::async()
{
 return status_ == Status::Async;
}

void Kauvir_Lisp_Callback::check_set_async()
{
 if(status_ == Status::Marked_Async)
 {
  status_ = Status::Async;
 }
}


void Kauvir_Lisp_Callback::run_function(QString class_name, void* pv)
{
 callback_(lisp_function_pointer_, class_name, pv);
}

void Kauvir_Lisp_Callback::mark_async()
{
 status_ = Status::Marked_Async;
}


