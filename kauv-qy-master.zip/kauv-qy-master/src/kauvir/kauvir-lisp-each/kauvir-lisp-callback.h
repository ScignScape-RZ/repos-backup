
#ifndef KAUVIR_LISP_CALLBACK__H
#define KAUVIR_LISP_CALLBACK__H

#include "kans.h"

#include "accessors.h"

#include <functional>

#include <QString>

KANS_(Kauvir)


class Kauvir_Lisp_Callback
{
 enum class Status {
  N_A, Normal, Async, Marked_Async
 };

 //?
 void* lisp_function_pointer_;

 //std::function<void (void*, QString, void*)> callback_;

 typedef std::function<void (void*, QString, void*)> callback_type;

 callback_type callback_;

 QString test_str_;

 Status status_;

public:

 ACCESSORS(void* ,lisp_function_pointer)
 ACCESSORS(callback_type ,callback)

 ACCESSORS(QString ,test_str)

 Kauvir_Lisp_Callback(void* lisp_function_pointer);

 void run_function(QString class_name, void* pv);

 void mark_async();
 void check_set_async();

 bool needs_init();
 bool async();
 //?RZ_QClasp_Callback* clone();


};


_KANS(Kauvir)


#endif  //   KAUVIR_LISP_CALLBACK__H
