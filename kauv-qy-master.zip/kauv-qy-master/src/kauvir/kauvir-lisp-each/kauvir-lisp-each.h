
#ifndef KAUVIR_LISP_EACH__H
#define KAUVIR_LISP_EACH__H

#include "kans.h"

#include "accessors.h"

#include <functional>

#include <QString>

KANS_(Kauvir)


class Kauvir_Lisp_Each
{
 void* lisp_function_pointer_;

 //std::function<void (void*, QString, void*)> callback_;

 typedef std::function<void (void*, QString, void*)> callback_type;

 callback_type callback_;

 QString test_str_;

public:

 ACCESSORS(void* ,lisp_function_pointer)
 ACCESSORS(callback_type ,callback)

 ACCESSORS(QString ,test_str)

 Kauvir_Lisp_Each(void* lisp_function_pointer);

 void run_function(QString class_name, void* pv);



};


_KANS(Kauvir)


#endif
