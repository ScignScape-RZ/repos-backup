
//#include <QCoreApplication>

//
#include <QApplication>

//#include <QDebug>

//
#include "kauvir-lisp-embed/kauvir-lisp-embed-environment.h"
#include "kauvir-lisp-embed/kauvir-lisp-eval.h"

//?#include "kauvir-lisp-each/kauvir-lisp-each.h"

#include "kauvir-runtime/kauvir-runtime.h"

#include "kauvir-gui-library/kauvir-test-dialog.h"
#include "kauvir-gui-library/kauvir-parse-dialog.h"
#include "kauvir-gui-library/kauvir-dynamic-dialog.h"

#include "kans.h"

#include "kauvir-type-system/kauvir-universal-class.h"

#include <functional>
#include <QDebug>

USING_KANS(Kauvir)

//?#include <iostream>

#include "kauvir-gui-library/paraviews/kauvir-image-view-dialog.h"

#include "kauvir-gui-library/paraviews/kauvir-wsi-image-view-dialog.h"

//Q_DECLARE_METATYPE(QPushButton)
Q_DECLARE_METATYPE(QPushButton*)


int main(int argc, char* argv[])
{
 QApplication qapp(argc, argv);
 // qapp.aboutQt();

 Kauvir_WSI_Image_View_Dialog* dlg =
   new Kauvir_WSI_Image_View_Dialog("/ext_root/QScign/assets/alexapath files/alexapath files/r34c57.jpg");


 dlg->exec();


}

int main1(int argc, char* argv[])
{
 QApplication qapp(argc, argv);
 // qapp.aboutQt();

 //QCoreApplication qapp(argc, argv);

 qRegisterMetaType<Kauvir_Test_Dialog>();
 qRegisterMetaType<Kauvir_Test_Dialog*>();

 qRegisterMetaType<Kauvir_Parse_Dialog>();
 qRegisterMetaType<Kauvir_Parse_Dialog*>();

 qRegisterMetaType<Kauvir_Dynamic_Dialog>();
 qRegisterMetaType<Kauvir_Dynamic_Dialog*>();


 qRegisterMetaType<Kauvir_Type_Object_Builder>();
 qRegisterMetaType<Kauvir_Type_Object_Builder*>();

 //?qRegisterMetaType<QPushButton>();
 qRegisterMetaType<QPushButton*>();

 qRegisterMetaType<QVBoxLayout*>();
 qRegisterMetaType<QHBoxLayout*>();





 Kauvir_Lisp_Embed_Environment env(argc, argv);
 Kauvir_Lisp_Eval kle(&env);

 Kauvir_Runtime kr(*kle.get_type_system(), *kle.get_type_object_builder());

 kle.set_kauvir_runtime(&kr);

 Kauvir_Channel_Group g1;

 //?
 //?g1.add_lambda_carrier(&kr.type_system().type_object__str());
 //?
 g1.add_sigma_carrier(kle.kauvir_lisp_runtime()->find_type_object("Kauvir_Test_Dialog"));

 {
  g1.add_lambda_carrier(&kr.type_system().type_object__u32());
  g1.add_lambda_carrier(&kr.type_system().type_object__str());
  Kauvir_Channel_Group* kcg = kr.add_declared_function("reset_test_label_text", g1);
  kr.add_declared_function("reset_test_label_text", kcg, reinterpret_cast<fn2_type>(
    (void (Kauvir_Test_Dialog::*)(int, QString&))(&Kauvir_Test_Dialog::reset_test_label_text)
    ));
  g1.clear_all_but_sigma();
 }

 {
  g1.add_lambda_carrier(&kr.type_system().type_object__u32(),
    Kauvir_Carrier::Effect_Protocols::Write_Mandated);
  g1.add_lambda_carrier(&kr.type_system().type_object__str());
  Kauvir_Channel_Group* kcg = kr.add_declared_function("reset_test_label_text_ref", g1);
  kr.add_declared_function("reset_test_label_text_ref", kcg,
    reinterpret_cast<fn2_type>(
      (void (Kauvir_Test_Dialog::*)(quint64&, QString&))(&Kauvir_Test_Dialog::reset_test_label_text_ref)
    ));
  g1.clear_all_but_sigma();
 }

 {
  g1.add_lambda_carrier(&kr.type_system().type_object__str());
  Kauvir_Channel_Group* kcg = kr.add_declared_function("set_test_label_text", g1);
  kr.add_declared_function("set_test_label_text", kcg, reinterpret_cast<fn1_type>(
    (void (Kauvir_Test_Dialog::*)(QString&))(&Kauvir_Test_Dialog::set_test_label_text)
    ));
  g1.clear_all_but_sigma();
 }

 {
  Kauvir_Channel_Group* kcg = kr.add_declared_function("qinv_noarg_uc", g1);
  kr.add_declared_function("qinv_noarg_uc", kcg, reinterpret_cast<fn0_type>(
    (void (Kauvir_Test_Dialog::*)())(&Kauvir_Test_Dialog::qinv_noarg_uc)
    ));
  g1.clear_all_but_sigma();
 }


 {

  Kauvir_Channel_Group* kcg = kr.add_declared_function("exec", g1);

  kr.add_declared_function("exec", kcg, reinterpret_cast<fn0_type>
   (&Kauvir_Test_Dialog::exec));

 }




 kle.prepare_callbacks();
// env.set_quicklisp_location("/home/nlevisrael/quicklisp/setup.lisp");
// kle.eval_quicklisp_setup();

//?
 kle.eval_script_file("/ext_root/kauv/lisp/t2.cl");
 //?kle.eval_script_file("/ext_root/kauv/rz/t3.rz.lisp");

}





//class T_Class
//{
// int x_;
// int y_;

//public:

// T_Class(int x, int y);

// void print(QString* z);

// void pr(int z);

//};

//T_Class::T_Class(int x, int y)
//  :  x_(x), y_(y)
//{

//}

//void test(int* x, QString* y)
//{
// qDebug() << "X: " << *x << " Y: " << *y;
//}

//void T_Class::print(QString* z)
//{
// qDebug() << "X: " << x_ << " Y: " << y_ << " Z: " << *z;
//}

//void T_Class::pr(int z)
//{
// qDebug() << "X: " << x_ << " Y: " << y_ << " Z: " << z;
//}

//int main2(int argc, char* argv[])
//{
// int x = 8;
// int y = 7;
// QString z = "OK";

// T_Class tcl(x, y);

// typedef void(T_Class::*fn_type)(QString*);

// typedef void(T_Class::*fn1_type)(void*);

// fn_type fn = &T_Class::print;

// fn1_type& fn1 = reinterpret_cast<fn1_type&>(fn);


// (tcl.*fn1)(&z);

//}

//// typedef std::function<void(int*, QString*)> fn_type;

//// fn_type fn = &test;

//// void* vx = &x;
//// void* vy = &y;

//// typedef std::function<void(void*, void*)> fn1_type;

//// fn1_type& fn1 = reinterpret_cast<fn1_type&>(fn);



// //fn1(vx, vy);

////}



