
#include "kauvir-carrier.h"

#include "kans.h"

USING_KANS(Kauvir)

//Kauvir_Lexical_Block

Kauvir_Carrier::Kauvir_Carrier(const Kauvir_Type_Object* type_object,
  Effect_Protocols ep, QString symbol)
  : Flags(0), type_object_(type_object), symbol_(symbol)
{
 switch(ep)
 {
 case Effect_Protocols::Write_Mandated:
  flags.write_mandated = true;
  break;

 case Effect_Protocols::Write_Disallowed:
  flags.write_disallowed = true;
  break;

 case Effect_Protocols::Read_Disallowed:
  flags.read_disallowed = true;
  break;

 case Effect_Protocols::Read_Mandated:
  flags.read_mandated = true;
  break;

 default:
  break;

 }

}

//bool operator <(const Kauvir_Carrier& lhs, const Kauvir_Carrier& rhs)
//{
// return lhs.type_object() < rhs.type_object();
//}
