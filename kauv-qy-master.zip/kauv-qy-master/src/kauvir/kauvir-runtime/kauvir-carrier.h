
#ifndef KAUVIR_CARRIER__H
#define KAUVIR_CARRIER__H


#include "kans.h"

#include "accessors.h"
#include "flags.h"

#include <QVector>

KANS_(Kauvir)


class Kauvir_Type_Object;

//class Kauvir_Lexical_Symbol;
//class Kauvir_Lexical_Statement;


class Kauvir_Carrier
{

public:

 flags_(1)

  bool non_opaque:1;
  bool read_disallowed:1;
  bool read_mandated:1;
  bool write_disallowed:1;
  bool write_mandated:1;

 _flags


 enum Effect_Protocols {
  Unrestricted, Read_Disallowed,
  Read_Mandated, Write_Disallowed,
  Write_Mandated
 };

private:

 const Kauvir_Type_Object* type_object_;
 QString symbol_;

public:

 Kauvir_Carrier(const Kauvir_Type_Object* type_object = nullptr,
   Effect_Protocols ep = Effect_Protocols::Unrestricted, QString symbol = QString());

 ACCESSORS(const Kauvir_Type_Object* ,type_object)

 friend bool operator <(const Kauvir_Carrier& lhs, const Kauvir_Carrier& rhs)
 {
  return lhs.type_object() < rhs.type_object();
 }


};


_KANS(Kauvir)


#endif //RZ_INVOCATION_BLOCK__H
