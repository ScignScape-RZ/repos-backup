
#include "kauvir-channel-group.h"

#include "kans.h"

USING_KANS(Kauvir)

//Kauvir_Lexical_Block

Kauvir_Channel_Group::Kauvir_Channel_Group()
{
 set_kinds();
}

Kauvir_Channel_Group::Kauvir_Channel_Group(const Kauvir_Channel_Group& rhs)
{
 lambda_ = rhs.lambda();
}

//bool operator<(const Kauvir_Channel_Group& lhs, const Kauvir_Channel_Group& rhs)
//{
// if(lhs.sigma() < rhs.sigma())
//  return true;
// if(lhs.lambda() < rhs.lambda())
//  return true;
// if(lhs.capture() < rhs.capture())
//  return true;
// if(lhs.gamma() < rhs.gamma())
//  return true;
// return false;
//}

void Kauvir_Channel_Group::set_kinds()
{
 lambda_.set_kind(Kauvir_Channel::Kinds::Lambda);
 sigma_.set_kind(Kauvir_Channel::Kinds::Sigma);
 capture_.set_kind(Kauvir_Channel::Kinds::Capture);
 gamma_.set_kind(Kauvir_Channel::Kinds::Gamma);
 result_.set_kind(Kauvir_Channel::Kinds::Result);
}

void Kauvir_Channel_Group::clear_all_but_sigma()
{
 lambda_ = Kauvir_Channel();
 capture_ = Kauvir_Channel();
 gamma_ = Kauvir_Channel();
 result_ = Kauvir_Channel();
 set_kinds();
}

void Kauvir_Channel_Group::clear()
{
 lambda_ = Kauvir_Channel();
 sigma_ = Kauvir_Channel();
 capture_ = Kauvir_Channel();
 gamma_ = Kauvir_Channel();
 result_ = Kauvir_Channel();
 set_kinds();
}

void Kauvir_Channel_Group::add_result_carrier(const Kauvir_Type_Object* type_object,
  Kauvir_Carrier::Effect_Protocols ep, QString symbol_name)
{
 result_.add_carrier(type_object, ep, symbol_name);
}


void Kauvir_Channel_Group::add_lambda_carrier(const Kauvir_Type_Object* type_object,
  Kauvir_Carrier::Effect_Protocols ep, QString symbol_name)
{
 lambda_.add_carrier(type_object, ep, symbol_name);
}

void Kauvir_Channel_Group::add_sigma_carrier(const Kauvir_Type_Object* type_object,
  Kauvir_Carrier::Effect_Protocols ep, QString symbol_name)
{
 sigma_.add_carrier(type_object, ep, symbol_name);
}

void Kauvir_Channel_Group::add_capture_carrier(const Kauvir_Type_Object* type_object,
  Kauvir_Carrier::Effect_Protocols ep, QString symbol_name)
{
 capture_.add_carrier(type_object, ep, symbol_name);
}

void Kauvir_Channel_Group::add_gamma_carrier(const Kauvir_Type_Object* type_object,
  Kauvir_Carrier::Effect_Protocols ep, QString symbol_name)
{
 gamma_.add_carrier(type_object, ep, symbol_name);
}
