
#ifndef KAUVIR_CHANNEL_GROUP__H
#define KAUVIR_CHANNEL_GROUP__H


#include "kans.h"

#include "accessors.h"

#include "kauvir-channel.h"

#include <QVector>

KANS_(Kauvir)


class Kauvir_Type_Object;

class Kauvir_Channel_Group
{
 Kauvir_Channel lambda_;
 Kauvir_Channel sigma_;

 Kauvir_Channel capture_;
 Kauvir_Channel gamma_;

 Kauvir_Channel result_;

 void set_kinds();

public:

 Kauvir_Channel_Group();

 Kauvir_Channel_Group(const Kauvir_Channel_Group& rhs);

 friend bool operator<(const Kauvir_Channel_Group& lhs, const Kauvir_Channel_Group& rhs)
 {
  if(lhs.sigma() < rhs.sigma())
   return true;
  if(lhs.lambda() < rhs.lambda())
   return true;
  if(lhs.capture() < rhs.capture())
   return true;
  if(lhs.gamma() < rhs.gamma())
   return true;
  if(lhs.result() < rhs.result())
   return true;
  return false;
 }


 ACCESSORS__RGET(Kauvir_Channel ,lambda)
 ACCESSORS__RGET(Kauvir_Channel ,sigma)

 ACCESSORS__RGET(Kauvir_Channel ,capture)
 ACCESSORS__RGET(Kauvir_Channel ,gamma)

 ACCESSORS__RGET(Kauvir_Channel ,result)


 ACCESSORS__CONST_RGET(Kauvir_Channel ,lambda)
 ACCESSORS__CONST_RGET(Kauvir_Channel ,sigma)

 ACCESSORS__CONST_RGET(Kauvir_Channel ,capture)
 ACCESSORS__CONST_RGET(Kauvir_Channel ,gamma)

 ACCESSORS__CONST_RGET(Kauvir_Channel ,result)


 void add_lambda_carrier(const Kauvir_Type_Object* type_object,
   Kauvir_Carrier::Effect_Protocols ep = Kauvir_Carrier::Effect_Protocols::Unrestricted,
   QString symbol_name = QString());


 void add_sigma_carrier(const Kauvir_Type_Object* type_object,
   Kauvir_Carrier::Effect_Protocols ep = Kauvir_Carrier::Effect_Protocols::Unrestricted,
                        QString symbol_name = QString());

 void add_capture_carrier(const Kauvir_Type_Object* type_object,
   Kauvir_Carrier::Effect_Protocols ep = Kauvir_Carrier::Effect_Protocols::Unrestricted,
                          QString symbol_name = QString());

 void add_gamma_carrier(const Kauvir_Type_Object* type_object,
   Kauvir_Carrier::Effect_Protocols ep = Kauvir_Carrier::Effect_Protocols::Unrestricted,
                        QString symbol_name = QString());

 void add_result_carrier(const Kauvir_Type_Object* type_object,
                         Kauvir_Carrier::Effect_Protocols ep = Kauvir_Carrier::Effect_Protocols::Unrestricted,
                                              QString symbol_name = QString());

 void clear();

 void clear_all_but_sigma();



};


_KANS(Kauvir)


#endif // KAUVIR_CHANNEL_GROUP__H
