
#include "kauvir-channel.h"

#include "kans.h"

USING_KANS(Kauvir)

//Kauvir_Lexical_Block

Kauvir_Channel::Kauvir_Channel()
  : kind_(Kinds::N_A)
{

}

//bool operator <(const Kauvir_Channel& lhs, const Kauvir_Channel& rhs)
//{
// return lhs.carriers() < rhs.carriers();
// //if(lhs.carriers().size())
//}


void Kauvir_Channel::get_carrier_at_position(int position, Kauvir_Carrier& result)
{
 if(position < carriers_.size())
 {
  result = carriers_.value(position);
 }
}

const Kauvir_Type_Object* Kauvir_Channel::type_object_at_position(int position)
{
 if(position < carriers_.size())
 {
  return carriers_.value(position).type_object();
 }
 return nullptr;
}


void Kauvir_Channel::add_carrier(const Kauvir_Type_Object* type_object,
  Kauvir_Carrier::Effect_Protocols ep, QString symbol)
{
 carriers_.push_back(Kauvir_Carrier(type_object, ep, symbol));
}
