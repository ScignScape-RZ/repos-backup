
#ifndef KAUVIR_CHANNEL__H
#define KAUVIR_CHANNEL__H


#include "kans.h"

#include "accessors.h"

#include "kauvir-carrier.h"

#include <QVector>

KANS_(Kauvir)


//class Kauvir_Lexical_Symbol;
//
//class Kauvir_Carrier;

class Kauvir_Type_Object;

class Kauvir_Channel
{

public:

 enum class Kinds {
  N_A, Lambda, Sigma, Capture, Gamma, Result, Error

 };

private:

 Kinds kind_;

 QVector<Kauvir_Carrier> carriers_;

public:

 Kauvir_Channel();

 friend bool operator <(const Kauvir_Channel& lhs, const Kauvir_Channel& rhs)
 {
  return lhs.carriers() < rhs.carriers();
 }

 ACCESSORS(Kinds ,kind)
 ACCESSORS__RGET(QVector<Kauvir_Carrier> ,carriers)
 ACCESSORS__CONST_RGET(QVector<Kauvir_Carrier> ,carriers)

 void get_carrier_at_position(int position, Kauvir_Carrier& result);

 const Kauvir_Type_Object* type_object_at_position(int position);

 void add_carrier(const Kauvir_Type_Object* type_object,
   Kauvir_Carrier::Effect_Protocols ep = Kauvir_Carrier::Effect_Protocols::Unrestricted,
   QString symbol = QString());




};


_KANS(Kauvir)


#endif //RZ_INVOCATION_BLOCK__H
