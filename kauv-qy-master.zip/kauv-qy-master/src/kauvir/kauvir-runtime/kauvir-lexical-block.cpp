
#include "kauvir-lexical-block.h"

#include "kans.h"

USING_KANS(Kauvir)

//Kauvir_Lexical_Block
