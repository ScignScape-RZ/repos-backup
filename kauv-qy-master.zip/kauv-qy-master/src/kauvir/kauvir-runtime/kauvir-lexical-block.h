
#ifndef KAUVIR_LEXICAL_BLOCK__H
#define KAUVIR_LEXICAL_BLOCK__H


#include "kans.h"

#include "accessors.h"

#include <QVector>

KANS_(Kauvir)


class Kauvir_Lexical_Symbol;
class Kauvir_Lexical_Statement;


class Kauvir_Lexical_Block
{
 QVector<Kauvir_Lexical_Symbol*> symbols_;
 QVector<Kauvir_Lexical_Statement*> statements_;

public:

 ACCESSORS(QVector<Kauvir_Lexical_Symbol*> ,symbols)
 ACCESSORS(QVector<Kauvir_Lexical_Statement*> ,statements)




};


_KANS(Kauvir)


#endif //RZ_INVOCATION_BLOCK__H
