
#include "kauvir-lexical-scope.h"

#include "kauvir-scoped-value-proxy.h"

#include "kauvir-type-system/kauvir-type-object.h"

#include "kauvir-lisp-embed/kauvir-lisp-kargs.h"

#include "kans.h"

#include <QMetaType>

USING_KANS(Kauvir)

Kauvir_Lexical_Scope::Kauvir_Lexical_Scope(Kauvir_Lexical_Scope* parent_scope, Kauvir_Lisp_Kargs* kargs)
  :  parent_scope_(parent_scope), kargs_(kargs)
{

}

Kauvir_Scoped_Value_Proxy* Kauvir_Lexical_Scope::add_value(QString name, const Kauvir_Type_Object* type_object)
{
 Kauvir_Scoped_Value_Proxy* result = new Kauvir_Scoped_Value_Proxy(type_object);
 proxies_.insert(name, result);
}

void* Kauvir_Lexical_Scope::raw_value_for_symbol_name(QString name)
{
 Kauvir_Scoped_Value_Proxy* ksvp = proxies_.value(name);
 if(ksvp)
 {
  return ksvp->raw_value();
 }
 return nullptr;
}

const Kauvir_Type_Object* Kauvir_Lexical_Scope::type_object_for_symbol_name(QString name)
{
 Kauvir_Scoped_Value_Proxy* ksvp = proxies_.value(name);
 if(ksvp)
 {
  const Kauvir_Type_Object* tobj = ksvp->type_object();
  return tobj;
 }
 return nullptr;
}

const QMetaObject* Kauvir_Lexical_Scope::meta_object_for_symbol_name(QString name, QObject*& obj)
{
 const QMetaObject* result = nullptr;
 Kauvir_Scoped_Value_Proxy* ksvp = proxies_.value(name);
 if(ksvp)
 {
  const Kauvir_Type_Object* tobj = ksvp->type_object();
  if(result = tobj->pqmo())
  {
   obj = static_cast<QObject*>( ksvp->raw_value() );
  }
 }
 return result;
}


Kauvir_Scoped_Value_Proxy* Kauvir_Lexical_Scope::init_function_scope_value(QString name, QString code)
{
 Kauvir_Scoped_Value_Proxy* ksvp = proxies_.value(name);
 if(ksvp)
 {
  const Kauvir_Type_Object* tobj = ksvp->type_object();

  if(code.startsWith('S'))
  {
   int index = code.mid(1).toInt();
   if(index == 1)
   {
    ksvp->set_raw_value(kargs_->qobject_sigma());
   }
  }
  else if(code.startsWith('L'))
  {
   int index = code.mid(1).toInt();
   kargs_->init_raw_value(name.prepend("l,"), index);
   //void* pv = kargs_->lambda_value_at_index(index);
   //ksvp->set_raw_value(pv);
  }
 }
 return ksvp;
}


void Kauvir_Lexical_Scope::default_init_value(QString name)
{
 Kauvir_Scoped_Value_Proxy* ksvp = proxies_.value(name);
 if(ksvp)
 {
  const Kauvir_Type_Object* tobj = ksvp->type_object();
  if(tobj->pqmo())
  {
   int id = QMetaType::type(tobj->pqmo()->className());
   if (id != QMetaType::UnknownType)
   {
    void* obj_pv = QMetaType::create(id);
    QObject* obj = static_cast<QObject*>(obj_pv);
    ksvp->set_raw_value(obj);
//    const QMetaObject* qmo = obj->metaObject();

//    QString method_name = "exec";
//    qmo->invokeMethod(obj, method_name.toLatin1());
//
   }

  }


 }
}



//Kauvir_Lexical_Block
