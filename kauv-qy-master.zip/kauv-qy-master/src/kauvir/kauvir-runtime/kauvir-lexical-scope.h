
#ifndef KAUVIR_LEXICAL_SCOPE__H
#define KAUVIR_LEXICAL_SCOPE__H


#include "kans.h"

#include "accessors.h"

#include <QMap>

class QObject;

KANS_(Kauvir)


//class Kauvir_Lexical_Symbol;
//class Kauvir_Lexical_Statement;

class Kauvir_Scoped_Value_Proxy;
class Kauvir_Type_Object;
class Kauvir_Lisp_Kargs;

class Kauvir_Lexical_Scope
{
 Kauvir_Lexical_Scope* parent_scope_;

 QMap<QString, Kauvir_Scoped_Value_Proxy*> proxies_;
 typedef QMap<QString, Kauvir_Scoped_Value_Proxy*> proxies_type;

 Kauvir_Lisp_Kargs* kargs_;

public:

 Kauvir_Lexical_Scope(Kauvir_Lexical_Scope* parent_scope, Kauvir_Lisp_Kargs* kargs);


 ACCESSORS(proxies_type ,proxies)
 ACCESSORS(Kauvir_Lexical_Scope* ,parent_scope)

 Kauvir_Scoped_Value_Proxy* add_value(QString name, const Kauvir_Type_Object* type_object);
 void default_init_value(QString name);

 const Kauvir_Type_Object* type_object_for_symbol_name(QString name);

 const QMetaObject* meta_object_for_symbol_name(QString name, QObject*& obj);

 void* raw_value_for_symbol_name(QString name);

 Kauvir_Scoped_Value_Proxy* init_function_scope_value(QString name, QString code);

};



_KANS(Kauvir)


#endif //RZ_INVOCATION_BLOCK__H
