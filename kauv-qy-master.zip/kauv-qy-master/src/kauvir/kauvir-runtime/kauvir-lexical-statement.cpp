
#include "kauvir-lexical-statement.h"

#include "kans.h"

USING_KANS(Kauvir)

//Kauvir_Lexical_Block
