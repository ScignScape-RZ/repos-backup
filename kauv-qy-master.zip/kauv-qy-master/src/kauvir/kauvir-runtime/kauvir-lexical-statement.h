
#ifndef KAUVIR_LEXICAL_STATEMENT__H
#define KAUVIR_LEXICAL_STATEMENT__H


#include "kans.h"

#include "accessors.h"

#include <QVector>

KANS_(Kauvir)


//class Kauvir_Lexical_Symbol;
//class Kauvir_Lexical_Statement;


class Kauvir_Lexical_Statement
{

public:



};


_KANS(Kauvir)


#endif //RZ_INVOCATION_BLOCK__H
