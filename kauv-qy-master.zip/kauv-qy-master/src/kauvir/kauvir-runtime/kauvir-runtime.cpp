 

#include "kauvir-runtime.h"

#include "kauvir-nl-lexicon/kauvir-nl-lexicon.h"

#include "kauvir-type-object-builder.h"

#include "kans.h"

#include <QQueue>

USING_KANS(Kauvir)


Kauvir_Runtime::Kauvir_Runtime(Kauvir_Type_System& type_system, Kauvir_Type_Object_Builder& type_object_builder)
  :  type_system_(type_system),
     type_object_builder_(type_object_builder),
     nl_lexicon_(nullptr)
{
 type_object_builder_.set_kauvir_runtime(this);
}


Kauvir_Type_Object* Kauvir_Runtime::check_register_type_object(QString type_name, QString cpp_name,
  QVariant::Type qvt, int qmetatype_code)
{
 Kauvir_Type_Object* result = types_.value(type_name);
 if(!result)
 {
  result = new Kauvir_Type_Object(type_name);
  types_.insert(type_name, result);
 }
 result->check_register_variant_and_metatype_info(qvt, qmetatype_code);
 return result;
}


void Kauvir_Runtime::check_init_nl_lexicon()
{
 if(!nl_lexicon_)
 {
  nl_lexicon_ = new Kauvir_NL_Lexicon();
 }
}


Kauvir_Channel_Group* Kauvir_Runtime::find_channel_group(const Kauvir_Channel_Group& channels)
{
 if(group_pointers_.contains(channels))
 {
  return group_pointers_.value(channels);
 }
 Kauvir_Channel_Group* result = new Kauvir_Channel_Group(channels);
 group_pointers_[channels] = result;
 return result;
}

Kauvir_Type_Object* Kauvir_Runtime::type_object_builder_complete(QString followup_code)
{
 const Kauvir_Channel_Group& channels = type_object_builder_.scratch_channel_group();
 Kauvir_Channel_Group* kcg = find_channel_group(channels);
 Kauvir_Type_Object* result = new Kauvir_Type_Object(kcg);
 //Kauvir_Type_Object* result =
 type_object_builder_.clear_scratch(followup_code);
 return result;
}

Kauvir_Channel_Group* Kauvir_Runtime::add_declared_function(QString name, const Kauvir_Channel_Group& channels)
{
 Kauvir_Channel_Group* result = find_channel_group(channels);
 declared_functions_.insertMulti(name, result);
 return result;
}

//template<typename FN_type>
//void Kauvir_Runtime::add_declared_function(QString name, Kauvir_Channel_Group* kcg, FN_type fn)
//{
// declared_functions_generic_.insert(name, {kcg, (fng_type)fn});
//}


//void Kauvir_Runtime::add_declared_function(QString name, Kauvir_Channel_Group* kcg, fn0_type fn)
//{
// declared_functions_0_.insert(name, {kcg, fn});
// declared_functions_generic_.insert(name, {kcg, (fng_type)fn});
//}


//void Kauvir_Runtime::add_declared_function(QString name, Kauvir_Channel_Group* kcg, fn1_type fn)
//{
// declared_functions_1_.insert(name, {kcg, fn});
// declared_functions_generic_.insert(name, {kcg, (fng_type)fn});
//}

//void Kauvir_Runtime::add_declared_function(QString name, Kauvir_Channel_Group* kcg, fn2_type fn)
//{
// declared_functions_2_.insert(name, {kcg, fn});
// declared_functions_generic_.insert(name, {kcg, (fng_type)fn});
//}

//void Kauvir_Runtime::add_declared_function(QString name, Kauvir_Channel_Group* kcg, fn3_type fn)
//{
// declared_functions_3_.insert(name, {kcg, fn});
// declared_functions_generic_.insert(name, {kcg, (fng_type)fn});
//}

fn1_type Kauvir_Runtime::find_declared_function_1(QString name, Kauvir_Channel_Group* kcg)
{
 for(QPair<Kauvir_Channel_Group*, fng_type> pr : declared_functions_generic_.values(name))
 {
  if(pr.first == kcg)
    return (fn1_type)(pr.second);
 }


// for(QPair<Kauvir_Channel_Group*, fn1_type> pr : declared_functions_1_.values(name))
// {
//  if(pr.first == kcg)
//    return pr.second;
// }
 return nullptr;
 //return declared_functions_1_.value(name, nullptr);
}


fn2_type Kauvir_Runtime::find_declared_function_2(QString name, Kauvir_Channel_Group* kcg)
{
 for(QPair<Kauvir_Channel_Group*, fng_type> pr : declared_functions_generic_.values(name))
 {
  if(pr.first == kcg)
    return (fn2_type)(pr.second);
 }
 return nullptr;
}


fn0_type Kauvir_Runtime::find_declared_function_0(QString name, Kauvir_Channel_Group* kcg)
{
 for(QPair<Kauvir_Channel_Group*, fng_type> pr : declared_functions_generic_.values(name))
 {
  if(pr.first == kcg)
    return (fn0_type)(pr.second);
 }


// for(QPair<Kauvir_Channel_Group*, fn0_type> pr : declared_functions_0_.values(name))
// {
//  if(pr.first == kcg)
//    return pr.second;
// }
 return nullptr;
}



Kauvir_Type_Object* Kauvir_Runtime::get_type_object_by_type_name(QString name)
{
 return types_.value(name);
}


Kauvir_Type_Object* Kauvir_Runtime::process_type_declaration(QString type_name, QString type_expression)
{
 Kauvir_Type_Object* result = new Kauvir_Type_Object(type_name);
 if(type_expression.contains("..->"))
 {
  result->parse_simplified_signature(type_expression, *this);
 }
}


Kauvir_Channel_Group* Kauvir_Runtime::check_invocation(QString sn, QQueue<Kauvir_Carrier>& lambda_carrier)
{
 if(declared_functions_.contains(sn))
 {
  QList<Kauvir_Channel_Group*> groups = declared_functions_.values(sn);

  for(Kauvir_Channel_Group* g : groups)
  {
   int i = 0;

   const Kauvir_Channel& ch = g->lambda();
   const QVector<Kauvir_Carrier>& carriers = ch.carriers();

   int size = carriers.size();

   Kauvir_Channel_Group* result = g;

   for(const Kauvir_Carrier& c : lambda_carrier)
   {
    if(i < size)
    {
     const Kauvir_Carrier& kc = carriers[i];
     ++i;
     if(c.type_object() == &type_system_.type_object__opaque_lisp_value())
     {
      continue;
     }
     if(kc.type_object() != c.type_object())
     {
      result = nullptr;
      break;
     }
    }
   }
   if(result)
   {
    return result;
   }

  }

  //declared_functions_.v

 }
 return nullptr;
}
