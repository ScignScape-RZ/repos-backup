#ifndef KAUVIR_RUNTIME__H
#define KAUVIR_RUNTIME__H


#include "kans.h"

#include "accessors.h"

#include "kauvir-channel-group.h"

#include "kauvir-type-system/kauvir-type-system.h"
#include "kauvir-type-system/kauvir-universal-class.h"


#include <QString>
#include <QMultiMap>

class Kauvir_Type_Object_Builder;

KANS_(Kauvir)

class Kauvir_NL_Lexicon;


class Kauvir_Runtime
{
 QMultiMap<QString, Kauvir_Channel_Group*> declared_functions_;

 QMap<QString, Kauvir_Type_Object*> types_;

 QMap<Kauvir_Channel_Group, Kauvir_Channel_Group*> group_pointers_;
 Kauvir_Channel_Group* find_channel_group(const Kauvir_Channel_Group& channels);


// QMultiMap<QString, QPair<Kauvir_Channel_Group*, fn0_type>> declared_functions_0_;
// QMultiMap<QString, QPair<Kauvir_Channel_Group*, fn1_type>> declared_functions_1_;
// QMultiMap<QString, QPair<Kauvir_Channel_Group*, fn2_type>> declared_functions_2_;
// QMultiMap<QString, QPair<Kauvir_Channel_Group*, fn3_type>> declared_functions_3_;

 QMultiMap<QString, QPair<Kauvir_Channel_Group*, fng_type>> declared_functions_generic_;

 QMultiMap<QString, QString> declared_types_;

 Kauvir_Type_System& type_system_;
 Kauvir_Type_Object_Builder& type_object_builder_;

 Kauvir_NL_Lexicon* nl_lexicon_;


 void check_init_nl_lexicon();

public:

 Kauvir_Runtime(Kauvir_Type_System& type_system, Kauvir_Type_Object_Builder& type_object_builder);

 ACCESSORS__GET(Kauvir_Type_System& ,type_system)
 ACCESSORS__GET(Kauvir_Type_Object_Builder& ,type_object_builder)

 Kauvir_Type_Object* get_type_object_by_type_name(QString name);

 Kauvir_Channel_Group* check_invocation(QString sn, QQueue<Kauvir_Carrier>& lambda_carrier);

 Kauvir_Channel_Group* add_declared_function(QString name, const Kauvir_Channel_Group& channels);

 Kauvir_Type_Object* type_object_builder_complete(QString followup_code = QString());

 template<typename FN_type>
 void add_declared_function(QString name, Kauvir_Channel_Group* kcg, FN_type fn)
 {
  declared_functions_generic_.insert(name, {kcg, (fng_type)fn});
 }

 Kauvir_Type_Object* process_type_declaration(QString type_name, QString type_expression);


 Kauvir_Type_Object* check_register_type_object(QString type_name, QString cpp_name,
   QVariant::Type qvt, int qmetatype_code);

// void add_declared_function(QString name, Kauvir_Channel_Group* kcg, fn1_type fn);
// void add_declared_function(QString name, Kauvir_Channel_Group* kcg, fn2_type fn);
// void add_declared_function(QString name, Kauvir_Channel_Group* kcg, fn3_type fn);

 fn2_type find_declared_function_2(QString name, Kauvir_Channel_Group* kcg);
 fn1_type find_declared_function_1(QString name, Kauvir_Channel_Group* kcg);
 fn0_type find_declared_function_0(QString name, Kauvir_Channel_Group* kcg);


};

_KANS(Kauvir)


#endif
