
#include "kauvir-scoped-value-proxy.h"

#include "kans.h"

USING_KANS(Kauvir)

Kauvir_Scoped_Value_Proxy::Kauvir_Scoped_Value_Proxy(const Kauvir_Type_Object* type_object)
  :  type_object_(type_object), raw_value_(nullptr)
{

}



//Kauvir_Lexical_Block
