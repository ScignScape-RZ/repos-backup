
#ifndef KAUVIR_SCOPED_VALUE_PROXY__H
#define KAUVIR_SCOPED_VALUE_PROXY__H


#include "kans.h"

#include "accessors.h"

#include <QVector>

KANS_(Kauvir)


//class Kauvir_Lexical_Symbol;
//
class Kauvir_Type_Object;

class Kauvir_Scoped_Value_Proxy
{
 void* raw_value_;
 const Kauvir_Type_Object* type_object_;


public:

 Kauvir_Scoped_Value_Proxy(const Kauvir_Type_Object* type_object = nullptr);


 ACCESSORS(void* ,raw_value)
 ACCESSORS(const Kauvir_Type_Object* ,type_object)


};


_KANS(Kauvir)


#endif //RZ_INVOCATION_BLOCK__H
