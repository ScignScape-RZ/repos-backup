 

#include "kauvir-string.h"

#include "kans.h"

USING_KANS(Kauvir)


Kauvir_String::Kauvir_String(QString raw_text)
  : raw_text_(raw_text)
{

}

