#ifndef KAUVIR_STRING__H
#define KAUVIR_STRING__H


#include "kans.h"

#include "accessors.h"

#include <QString>

KANS_(Kauvir)


class Kauvir_String
{
 QString raw_text_;


public:

 Kauvir_String(QString raw_text);

 ACCESSORS(QString ,raw_text)



};

_KANS(Kauvir)


#endif
