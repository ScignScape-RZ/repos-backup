 

#include "kauvir-type-object-builder.h"

#include "kauvir-runtime.h"

#include "kans.h"

#include <QDebug>

//USING_KANS(Kauvir)

Kauvir_Type_Object_Builder::Kauvir_Type_Object_Builder(const Kauvir_Type_Object_Builder& rhs)
 : kauvir_runtime_(rhs.kauvir_runtime_)
{

}


Kauvir_Type_Object_Builder::Kauvir_Type_Object_Builder()
 : kauvir_runtime_(nullptr)
{

}

void Kauvir_Type_Object_Builder::add_cpp_equivalent_type(QString type_name, QString cpp_name)
{
 if(cpp_name.isEmpty())
 {
  QVariant::Type qvt = QVariant::nameToType(type_name.toLatin1());
  int qmt_code = QMetaType::type(type_name.toLatin1());
  kauvir_runtime_->check_register_type_object(type_name, type_name, qvt, qmt_code);
 }
 else
 {
  QVariant::Type qvt = QVariant::nameToType(cpp_name.toLatin1());
  int qmt_code = QMetaType::type(cpp_name.toLatin1());
  kauvir_runtime_->check_register_type_object(type_name, type_name, qvt, qmt_code);
 }
}

void Kauvir_Type_Object_Builder::add_lambda_carrier(QString type_name,
  int effect_protocol, QString symbol_name)
{
 Kauvir_Carrier::Effect_Protocols ep = (Kauvir_Carrier::Effect_Protocols) effect_protocol;
 Kauvir_Type_Object* tob = kauvir_runtime_->get_type_object_by_type_name(type_name);
 if(tob)
 {
  scratch_channel_group_.add_lambda_carrier(tob, ep, symbol_name);
 }
 //qDebug() << "add la....";
}

void Kauvir_Type_Object_Builder::clear_scratch(QString followup_code)
{
 if(followup_code.contains('S'))
 {
  scratch_channel_group_.clear_all_but_sigma();
 }
 else
 {
  scratch_channel_group_.clear();
 }
}

void Kauvir_Type_Object_Builder::add_result_carrier(QString type_name,
  int effect_protocol, QString symbol_name)
{
 Kauvir_Carrier::Effect_Protocols ep = (Kauvir_Carrier::Effect_Protocols) effect_protocol;
 Kauvir_Type_Object* tob = kauvir_runtime_->get_type_object_by_type_name(type_name);
 if(tob)
 {
  scratch_channel_group_.add_result_carrier(tob, ep, symbol_name);
 }
 //qDebug() << "add la....";
}

