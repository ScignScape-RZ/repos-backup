
#include "kauvir-type-attribution-context.h"

#include "kans.h"

USING_KANS(Kauvir)


Kauvir_Type_Attribution_Context::Kauvir_Type_Attribution_Context(QString name)
  :  name_(name)
{

}

