
#ifndef KAUVIR_TYPE_ATTRIBUTION_CONTEXT__H
#define KAUVIR_TYPE_ATTRIBUTION_CONTEXT__H


#include "kans.h"

#include "accessors.h"

#include <QVector>

KANS_(Kauvir)


//class Kauvir_Lexical_Symbol;
//class Kauvir_Lexical_Statement;


class Kauvir_Type_Attribution_Context
{
 QString name_;

public:

 Kauvir_Type_Attribution_Context(QString name);


 ACCESSORS(QString ,name)


};


_KANS(Kauvir)


#endif  // KAUVIR_TYPE_ATTRIBUTION_CONTEXT__H

