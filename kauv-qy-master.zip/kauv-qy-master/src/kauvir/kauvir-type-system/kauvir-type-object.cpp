
#include "kauvir-type-object.h"

#include "kans.h"


#include "kauvir-runtime/kauvir-channel-group.h"

//?#include "kauvir-runtime/kauvir-runtime.h"

#include <QRegularExpression>

USING_KANS(Kauvir)


Kauvir_Type_Object::Kauvir_Type_Object(QString name)
  :  name_(name), qmo_(nullptr), pqmo_(nullptr),
     fn_doc_info_(nullptr), signature_(nullptr),
     qvariant_type_(QVariant::Invalid), qmetatype_code_(0)
{

}

Kauvir_Type_Object::Kauvir_Type_Object(Kauvir_Channel_Group* signature)
 :  qmo_(nullptr), pqmo_(nullptr),
    fn_doc_info_(nullptr), signature_(signature),
    qvariant_type_(QVariant::Invalid), qmetatype_code_(0)
{

}


void Kauvir_Type_Object::check_register_variant_and_metatype_info(QVariant::Type qvt, int qmetatype_code)
{
 qvariant_type_ = qvt;
 qmetatype_code_ = qmetatype_code;
}

void Kauvir_Type_Object::parse_simplified_signature(QString rep, Kauvir_Runtime& runtime)
{
#ifdef SUPPORT_NL_LEXICON
 QRegularExpression rx("[\\w:*]+|\\.+->");

 int pos = 0;

 bool lambda_flag = false;
 bool result_flag = false;

 QString result_string;
 QStringList lambda_strings;

 while(pos < rep.length())
 {
  if(!signature_)
  {
   signature_ = new Kauvir_Channel_Group;
  }

  QRegularExpressionMatch rxm = rx.match(rep, pos);
  if(!rxm.hasMatch())
   break;
  QString qs = rxm.captured();
  pos += qs.length();
  if(qs == ".->")
  {
   lambda_flag = true;
  }
  else if(qs == "..->")
  {
   result_flag = true;
  }
  else if(result_flag)
  {
   Kauvir_Type_Object* kto = runtime.get_type_object_by_type_name(qs);
   signature_->add_result_carrier(kto);
   //result_string = qs;
  }
  else if(lambda_flag)
  {
   lambda_flag = false;

   Kauvir_Type_Object* kto = runtime.get_type_object_by_type_name(qs);
   signature_->add_lambda_carrier(kto);

   //lambda_strings.push_back(qs);
  }
  else
  {
   Kauvir_Type_Object* kto = runtime.get_type_object_by_type_name(qs);
   signature_->add_lambda_carrier(kto);
   //lambda_strings.push_back(qs);
  }
 }
#endif //def SUPPORT_NL_LEXICON
}

