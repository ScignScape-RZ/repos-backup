
#include "kcm-lisp-eval.h"
#include "kcm-lisp-runtime.h"
#include "kcm-lisp-embed-environment.h"-

#include "kcm-lisp-runtime-argument.h"

#include "rz-dynamo/rz-dynamo-generator/rz-dynamo-generator.h"
#include "rz-dynamo/rz-dynamo-generator/cloudynamo-interface.h"
#include "rz-dynamo/rz-dynamo-generator/rz-citation-generator.h"

#include "kauvir-code-model/kcm-channel-bridge.h"
#include "CmdLog/kcm-command-runtime/kcm-command-runtime-router.h"




#include <QDebug>

USING_KANS(KCL)

KCM_Lisp_Eval::KCM_Lisp_Eval(KCM_Lisp_Embed_Environment* env)
  :  env_(env), kcm_lisp_runtime_(new KCM_Lisp_Runtime)
{

}

KCM_Lisp_Eval::KCM_Lisp_Eval(KCM_Lisp_Embed_Environment* env, QTextStream& qts)
 :  env_(env), kcm_lisp_runtime_(new KCM_Lisp_Runtime(qts))
{

}



void KCM_Lisp_Eval::minimal_eval(QString eval_text)
{
 cl_cxx_backend::eval_string(eval_text.toLatin1().data());
}

KCM_Lisp_Eval::make_kcm_channel_bridge_fn_type KCM_Lisp_Eval::get_make_kcm_channel_bridge_fn_type(
  make_kcm_channel_bridge_fn_type fn)
{
 static make_kcm_channel_bridge_fn_type result = nullptr;
 if(fn)
 {
  result = fn;
 }
 return result;
}

void KCM_Lisp_Eval::run_source_function(KCM_Command_Runtime_Router& kcrr, quint64 qclo)
{
 cl_object clo = (cl_object) qclo;
 cl_object isf = cl_functionp(clo);
 if(isf != ECL_NIL)
 {
  //.KCM_Channel_Bridge* bridge = new KCM_Channel_Bridge(kcrr.get_channel_group());
  KCM_Channel_Bridge* bridge = get_make_kcm_channel_bridge_fn_type()(kcrr);

  //?Kauvir_Lisp_Kargs* kargs = new Kauvir_Lisp_Kargs(requester);
  //?if(kargs)
  //?{   cl_object clo_ks = cl_cxx_backend::make_foreign_data(kargs);

   cl_object clo_ks = cl_cxx_backend::make_foreign_data(bridge);
   cl_funcall(2, clo, clo_ks);
  //?}
 }
}


void KCM_Lisp_Eval::define_callback(cl_cxx_backend::callback_t cb,
 QString package_name, QString symbol_name, void* argument)
{
 package_name = package_name.toUpper();
 symbol_name = symbol_name.toUpper();
 cl_object obj = cl_cxx_backend::symbol(package_name.toLatin1().data(), symbol_name.toLatin1().data());
 cl_cxx_backend::define_function(obj, cb, argument);
}

void KCM_Lisp_Eval::test_callback(cl_cxx_backend::callback_t cb)
{
 cl_cxx_backend::eval_string("(COMMON-LISP-USER::TEST-CB)");
}


//KCM_Type_System* KCM_Lisp_Eval::get_type_system()
//{
// return kcm_lisp_runtime_->get_type_system();
//}

void KCM_Lisp_Eval::cl_arglist_to_strings(int size, int offset, cl_cxx_backend::cl_arglist arglist,
  QStringList& strings)
{
 for(int i = offset; i < size; ++i)
 {
  cl_object clo = cl_cxx_backend::nth_arg(arglist, i + 1);
  QString str = cl_object_to_qstring(clo);
//  if(SYMBOLP(clo))
//  {
//   flags.push_back(str);
//  }
//  else
//  {
   strings.push_back(str);
//  }
 }
}

void KCM_Lisp_Eval::cl_arglist_to_ms_tokens(int size, int offset, cl_cxx_backend::cl_arglist arglist,
  QList<MS_Token>& tokens)
{
 for(int i = offset; i < size; ++i)
 {
  cl_object clo = cl_cxx_backend::nth_arg(arglist, i + 1);
  QString str = cl_object_to_qstring(clo);
  if(SYMBOLP(clo))
  {
   MS_Token mst = MS_Token::decode(str);
   if(mst.kind != MS_Token_Kinds::Skip_Token)
   {
    tokens.push_back(mst);
   }
  }
  else if(str.startsWith('"'))
  {
   tokens.push_back({MS_Token_Kinds::String_Literal, str});
//   str[0] = '$';
//   str.chop(1);
//   strings.push_back(str);
  }
  else
  {
   tokens.push_back({MS_Token_Kinds::Generic, str});
   //strings.push_back(str.prepend('@'));
  }
 }
}

void KCM_Lisp_Eval::cl_arglist_to_tagged_strings(int size, int offset,
  cl_cxx_backend::cl_arglist arglist,
  QStringList& strings)
{
 for(int i = offset; i < size; ++i)
 {
  cl_object clo = cl_cxx_backend::nth_arg(arglist, i + 1);
  QString str = cl_object_to_qstring(clo);
//  if(QUOTEDP(clo))
//  {
//   strings.push_back(str.prepend('&'));
//  }
//  else
  if(SYMBOLP(clo))
  {
   if(str.startsWith(':'))
   {
    strings.push_back(str.prepend('@'));
   }
   else
   {
    strings.push_back(str.prepend('&'));
   }
  }
  else if(str.startsWith('"'))
  {
   str[0] = '$';
   str.chop(1);
   strings.push_back(str);
  }
  else
  {
   strings.push_back(str.prepend('@'));
  }
 }
}


void KCM_Lisp_Eval::cl_arglist_to_flagged_strings(int size, int offset,
  cl_cxx_backend::cl_arglist arglist,
  QStringList& flags, QStringList& strings)
{
 for(int i = offset; i < size; ++i)
 {
  cl_object clo = cl_cxx_backend::nth_arg(arglist, i + 1);
  QString str = cl_object_to_qstring(clo);
  if(SYMBOLP(clo))
  {
   flags.push_back(str);
  }
  else
  {
   strings.push_back(str);
  }
 }
}

QString KCM_Lisp_Eval::cl_arglist_to_opaque_arguments(cl_cxx_backend::cl_arglist arglist,
  QVector<KCM_Lisp_Runtime_Argument>& klras)
{
 QString result;
 cl_object clo1 = cl_cxx_backend::nth_arg(arglist, 2);
 if(SYMBOLP(clo1))
 {
  result = cl_arglist_to_qstring(arglist, 2);
 }
 for(int i = 2; i < klras.size(); ++i)
 {
  cl_object clo = cl_cxx_backend::nth_arg(arglist, i + 1);
  KCM_Lisp_Runtime_Argument& klra = klras[i];
  klra.set_opaque_lisp_value( (quint64) clo);
 }
 return result;
}

quint64 KCM_Lisp_Eval::encode_encoded_value_to_cl_object(const KCM_Type_Object* kto, QString val)
{
 // // once again there are probably other options ...

 if(kto->is_string_like())
 {
  cl_object clo = qstring_to_cl_object(val);
  return (quint64) clo;
 }
 else
 {
  quint32 v = val.toInt();
  return (quint64) ecl_make_fixnum(v);
 }

}

quint64 KCM_Lisp_Eval::encode_value_to_cl_object(const KCM_Type_Object* kto, void* val)
{
 // // once again there are probably other options ...

 if(kto->is_string_like())
 {
  QString* qs = (QString*) val;
  cl_object clo = qstring_to_cl_object(*qs);
  return (quint64) clo;
 }
 else
 {
  quint32 v = *(quint32*)(val);
  return (quint64) ecl_make_fixnum(v);
 }
}

void* KCM_Lisp_Eval::opaque_lisp_value_to_pVoid(Opaque_Lisp_Value olv)
{
 cl_object clo = (cl_object) olv.value;
 return ecl_foreign_data_pointer_safe(clo);
}

void KCM_Lisp_Eval::run_held_lisp_list(quint64 lisp_val, quint64& mem)
{
 cl_object result = cl_eval( (cl_object) lisp_val);
 quint32 value = ecl_to_fixnum(result);
 mem = value;
}

void KCM_Lisp_Eval::parse_opaque_lisp_value(Opaque_Lisp_Value olv,
  Opaque_Lisp_Value_Types& olvt, QString& encoded_value)
{
 cl_object clo = (cl_object) olv.value;
 cl_type clt = ecl_t_of(clo);
 if( (clt == t_base_string) || (clt == t_string) )
 {
  std::string str = cl_cxx::from_cl_object<std::string>(clo);
  olvt = Opaque_Lisp_Value_Types::Str;
  encoded_value = QString::fromStdString(str);
 }
 else if(clt == t_fixnum)
 {
  quint32 value = ecl_to_fixnum(clo);
  olvt = Opaque_Lisp_Value_Types::Fixnum_U32;
  encoded_value = QString::number(value);
 }
 else if(clt == t_list)
 {
  olvt = Opaque_Lisp_Value_Types::Held_List;
  //?encoded_value = this->get_key_for_storing(clt);
 }
 else if(clt == t_foreign)
 {
  //?klra.set_pVoid(ecl_foreign_data_pointer_safe(clo));
 }
 else
 {
  //?klra.set_cl_object( (quint64) clo);
 }
}

void KCM_Lisp_Eval::cl_arglist_to_arguments(cl_cxx_backend::cl_arglist arglist,
  QVector<KCM_Lisp_Runtime_Argument>& klras)
{
 for(int i = 1; i < klras.size(); ++i)
 {
  cl_object clo = cl_cxx_backend::nth_arg(arglist, i + 1);
  KCM_Lisp_Runtime_Argument& klra = klras[i];

  cl_type clt = ecl_t_of(clo);
  if(clt == t_base_string)
  {
   std::string str = cl_cxx::from_cl_object<std::string>(clo);
   klra.set_string(QString::fromStdString(str));
  }
  else if(clt == t_fixnum)
  {
   quint64 n = ecl_to_fixnum(clo);
   klra.set_cl_object(n);
  }
  else if(clt == t_string)
  {
   std::string str = cl_cxx::from_cl_object<std::string>(clo);
   klra.set_string(QString::fromStdString(str));
  }
  else if(clt == t_foreign)
  {
   klra.set_pVoid(ecl_foreign_data_pointer_safe(clo));
  }
  else
  {
   klra.set_cl_object( (quint64) clo);
  }
 }
}

//   define_callback(
//    [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
//    {
//     KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
//     RZ_Citation_Generator* rcg = runtime->rcg();
//     int size = arglist->frame.size;
////?
////     if(size > 0)
////     {
//      QStringList tokens;
//      cl_arglist_to_strings(size, 0, arglist, tokens);
//      if(rcg)
//      {
//       rcg->enter_citation(tokens);
//      }
////?     }
//     return ECL_NIL;
//    }, "CX", "citation_", pass_on);


void KCM_Lisp_Eval::prepare_dynamo_callbacks(void** pass_on)
{

 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   RZ_Dynamo_Generator* rdg = runtime->rdg();
   if(rdg)
   {
    rdg->write_file_start();
   }


//   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);
//   int size = arglist->frame.size;
//   QStringList kw_flags;
//   QStringList strings;
//   if(size > 0)
//   {
//    cl_object sym = cl_cxx_backend::nth_arg(arglist, 1);
//    QString sn = cl_object_to_qstring(sym);
//    cl_arglist_to_flagged_strings(size, 1, arglist, kw_flags, strings);
//    QString result;
//    if(rdg)
//    {
//     result = rdg->get_type_representation(sn, kw_flags, strings);
//     //std::string rs = result.toStdString();
//     return cl_cxx::to_cl_object<const std::string&>(result.toStdString());
//    }
//   }
//   //?qDebug() << "ARGS: " << args[0].str;
   return ECL_NIL;
  }, "KB", "WRITE-FILE-START", pass_on);


 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   RZ_Dynamo_Generator* rdg = runtime->rdg();
   if(rdg)
   {
    rdg->write_file_end();
   }


//   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);
//   int size = arglist->frame.size;
//   QStringList kw_flags;
//   QStringList strings;
//   if(size > 0)
//   {
//    cl_object sym = cl_cxx_backend::nth_arg(arglist, 1);
//    QString sn = cl_object_to_qstring(sym);
//    cl_arglist_to_flagged_strings(size, 1, arglist, kw_flags, strings);
//    QString result;
//    if(rdg)
//    {
//     result = rdg->get_type_representation(sn, kw_flags, strings);
//     //std::string rs = result.toStdString();
//     return cl_cxx::to_cl_object<const std::string&>(result.toStdString());
//    }
//   }
//   //?qDebug() << "ARGS: " << args[0].str;
   return ECL_NIL;
  }, "KB", "WRITE-FILE-END", pass_on);



 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   RZ_Dynamo_Generator* rdg = runtime->rdg();

   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);
   int size = arglist->frame.size;
   if(size > 0)
   {
    QList<MS_Token> tokens;
    cl_arglist_to_ms_tokens(size, 0, arglist, tokens);
    QString sn = tokens.at(0).raw_text;
    QString tn = tokens.at(1).raw_text;
    if(rdg)
    {
     if(tn == ":fdef")
     {
      rdg->write_function_type_binding_statement(sn, tokens);
     }
     else
     {
      rdg->write_qreg_type_binding_statement(tn, sn);
     }
    }
   }
   return ECL_NIL;
  }, "KB", "WRITE-QREG-TYPE-BINDING-STATEMENT", pass_on);


 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   RZ_Dynamo_Generator* rdg = runtime->rdg();

   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);
   int size = arglist->frame.size;
   if(size > 0)
   {
    cl_object sym = cl_cxx_backend::nth_arg(arglist, 1);
    MS_Token mst = cl_object_to_ms_token(sym);
    // QString sn = cl_object_to_qstring(sym);
    if(rdg)
    {
     rdg->write_promote_type_binding_expression(mst);
    }
   }
   return ECL_NIL;
  }, "KB", "WRITE-PROMOTE-TYPE-BINDING-EXPRESSION", pass_on);


 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   RZ_Dynamo_Generator* rdg = runtime->rdg();

   if(rdg)
   {
    rdg->write_cmd_eval();
   }
   return ECL_NIL;
  }, "KB", "WRITE-CMD-EVAL", pass_on);



 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   RZ_Dynamo_Generator* rdg = runtime->rdg();

   if(rdg)
   {
    rdg->write_statement_clear();
   }
   return ECL_NIL;
  }, "KB", "WRITE-STATEMENT-CLEAR", pass_on);


 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   RZ_Dynamo_Generator* rdg = runtime->rdg();

   if(rdg)
   {
    rdg->write_promote_expression();
   }
   return ECL_NIL;
  }, "KB", "WRITE-PROMOTE-EXPRESSION", pass_on);



 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   RZ_Dynamo_Generator* rdg = runtime->rdg();

   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);
   int size = arglist->frame.size;
   if(size > 0)
   {
    QList<MS_Token> tokens;
    cl_arglist_to_ms_tokens(size, 0, arglist, tokens);
//    QStringList strings;
//    cl_arglist_to_tagged_strings(size, 0, arglist, strings);
    if(rdg)
    {
     rdg->write_s0_expression(tokens);
    }
   }
   return ECL_NIL;
  }, "KB", "WRITE-S0-EXPRESSION", pass_on);

#define BASIC_DEFINE_CALLBACK(x, y) \
 define_callback( \
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object \
  { \
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]); \
   RZ_Dynamo_Generator* rdg = runtime->rdg(); \
   int size = arglist->frame.size; \
   if(size > 0) \
   { \
    QList<MS_Token> tokens; \
    cl_arglist_to_ms_tokens(size, 0, arglist, tokens); \
    if(rdg) \
    { \
     rdg->y(tokens); \
    } \
   } \
   return ECL_NIL; \
  }, "KB", #x, pass_on); \


#define BASIC_DEFINE_NULLARY_CALLBACK(x, y) \
 define_callback( \
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object \
  { \
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]); \
   RZ_Dynamo_Generator* rdg = runtime->rdg(); \
   int size = arglist->frame.size; \
   if(rdg) \
   { \
    rdg->y(); \
   } \
   return ECL_NIL; \
  }, "KB", #x, pass_on); \


BASIC_DEFINE_CALLBACK(if-without-elsif, if_without_elsif)
BASIC_DEFINE_CALLBACK(if-with-else, if_with_else)
BASIC_DEFINE_CALLBACK(if-with-elsif, if_with_elsif)
BASIC_DEFINE_NULLARY_CALLBACK(push-nested-form-group, push_nested_form_group)
BASIC_DEFINE_NULLARY_CALLBACK(pull-nested-form-group, pull_nested_form_group)
BASIC_DEFINE_CALLBACK(enter-nested-form, enter_nested_form)
BASIC_DEFINE_CALLBACK(enter-secondary-nested-form, enter_secondary_nested_form)

BASIC_DEFINE_CALLBACK(nested-form-body, nested_form_body)

BASIC_DEFINE_CALLBACK(write-qpr, write_qpr)

BASIC_DEFINE_NULLARY_CALLBACK(write-enter-plene-block, write_enter_plene_block)
BASIC_DEFINE_NULLARY_CALLBACK(write-leave-plene-block, write_leave_plene_block)

BASIC_DEFINE_NULLARY_CALLBACK(write-enter-plebod, write_enter_plebod)

BASIC_DEFINE_NULLARY_CALLBACK(write-plene-block, write_plene_block)
BASIC_DEFINE_NULLARY_CALLBACK(write-enter-scope, write_enter_scope)
BASIC_DEFINE_NULLARY_CALLBACK(write-leave-scope, write_leave_scope)
BASIC_DEFINE_NULLARY_CALLBACK(leave-nested-form, leave_nested_form)
BASIC_DEFINE_NULLARY_CALLBACK(leave-secondary-nested-form, leave_secondary_nested_form)


BASIC_DEFINE_CALLBACK(write-plebod-symbol-declare-with-type ,write_plebod_symbol_declare_with_type)
BASIC_DEFINE_CALLBACK(write-plebod-symbol-init-with-type ,write_plebod_symbol_init_with_type)

BASIC_DEFINE_CALLBACK(write-anon-fdef, write_anon_fdef)

BASIC_DEFINE_CALLBACK(write-overloadable-fdef, write_overloadable_fdef)

BASIC_DEFINE_CALLBACK(prepare-expression, prepare_expression)
BASIC_DEFINE_CALLBACK(symbol-init-via-type, symbol_init_via_type)


 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   RZ_Dynamo_Generator* rdg = runtime->rdg();
   int size = arglist->frame.size;
   if(size > 0)
   {
    QList<MS_Token> tokens;
    cl_arglist_to_ms_tokens(size, 0, arglist, tokens);
    if(rdg)
    {
     rdg->write_s0_expression(tokens);
    }
   }
   return ECL_NIL;
  }, "KB", "WRITE-S0-EXPRESSION", pass_on);


//define_callback(
// [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
// {
//  KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
//  RZ_Dynamo_Generator* rdg = runtime->rdg();
//  if(rdg)
//  {
//    rdg->leave_nested_form();
//  }
//  return ECL_NIL;
// }, "KB", "LEAVE-NESTED-FORM", pass_on);



 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   RZ_Dynamo_Generator* rdg = runtime->rdg();

   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);
   int size = arglist->frame.size;
   if(size > 0)
   {
    QList<MS_Token> tokens;
    cl_arglist_to_ms_tokens(size, 0, arglist, tokens);
//    QStringList strings;
//    cl_arglist_to_tagged_strings(size, 0, arglist, strings);
    if(rdg)
    {
     rdg->write_assignment_initialization_via_token(tokens);
    }
   }
   return ECL_NIL;
  }, "KB", "WRITE-ASSIGNMENT-INITIALIZATION-VIA-TOKEN", pass_on);


 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   RZ_Dynamo_Generator* rdg = runtime->rdg();

   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);
   int size = arglist->frame.size;
   if(size > 0)
   {
//    QStringList strings;
//    cl_arglist_to_tagged_strings(size, 0, arglist, strings);
    QList<MS_Token> tokens;
    cl_arglist_to_ms_tokens(size, 0, arglist, tokens);

    if(rdg)
    {
     rdg->write_s1_expression(tokens);
    }
   }
   return ECL_NIL;
  }, "KB", "WRITE-S1-EXPRESSION", pass_on);




// ///////////////////////////////



 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   //?QList<Kauvir_Lisp_Argument> args;

   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);
   int size = arglist->frame.size;

   if(size > 0)
   {
   }
   return ECL_NIL;
   //RZ_Lisp_Eval* pRle = reinterpret_cast<RZ_Lisp_Eval*>( ((void**) pass_on)[1]);
  }, "KB", "_FC", pass_on);

 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);
   int size = arglist->frame.size;

   if(size > 0)
   {
    cl_object result = cl_cxx_backend::nth_arg(arglist, 1);
    if(SYMBOLP(result))
    {
     QString sn = cl_arglist_to_qstring(arglist, 1);

     switch(size)
     {
     case 1:
      //?runtime->forward_tob_call(sn); break;
      break;
     case 2:
      {
       QString arg1 = cl_arglist_to_qstring(arglist, 2);
       //?runtime->forward_tob_call(sn, arg1); break;
      }
      break;
     case 3:
      {
       QString arg1 = cl_arglist_to_qstring(arglist, 2);
       QString arg2 = cl_arglist_to_qstring(arglist, 3);
       //?runtime->forward_tob_call(sn, arg1, arg2); break;
      }
      break;
     }
    }
   }
   //qDebug() << "ARGS: " << args[0].str();
   return ECL_NIL;
   //RZ_Lisp_Eval* pRle = reinterpret_cast<RZ_Lisp_Eval*>( ((void**) pass_on)[1]);
  }, "KB", "tob", pass_on);

 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);
   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);

   int size = arglist->frame.size;

   if(size == 1)
   {
    //cl_object tn = cl_cxx_backend::nth_arg(arglist, 1);
    QString sn = cl_arglist_to_qstring(arglist, 1);
//?   const Kauvir_Type_Object* tobj = runtime->find_type_object(sn);
//    if(tobj)
//    {
//     void* pv = const_cast<void*>(reinterpret_cast<const void*>(tobj));
//     cl_object cl_result = cl_cxx_backend::make_foreign_data(pv);
//     return cl_result;
//    }
   }
   //?qDebug() << "ARGS: " << args[0].str;
   return ECL_NIL;
  }, "KB", "KT", pass_on);

 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);
   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);

   int size = arglist->frame.size;

   QString followup_code;

   if(size > 1)
   {
    cl_object sym = cl_cxx_backend::nth_arg(arglist, 1);
    followup_code = cl_arglist_to_qstring(arglist, 1);
   }

//?   Kauvir_Type_Object* tob = reval->kauvir_runtime()->type_object_builder_complete(followup_code);// Kauvir_Channel_Group
//   return cl_cxx_backend::make_foreign_data(tob);

  }, "KB", "tobc", pass_on);

 //return cl_cxx_backend::make_foreign_data(pair_result);

 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   RZ_Dynamo_Generator* rdg = runtime->rdg();

   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);

   int size = arglist->frame.size;

   QStringList kw_flags;
   QStringList strings;

   if(size > 0)
   {
    cl_object sym = cl_cxx_backend::nth_arg(arglist, 1);
    QString sn = cl_object_to_qstring(sym);
    cl_arglist_to_flagged_strings(size, 1, arglist, kw_flags, strings);
    QString result;
    if(rdg)
    {
     result = rdg->get_type_representation(sn, kw_flags, strings);
     //std::string rs = result.toStdString();
     return cl_cxx::to_cl_object<const std::string&>(result.toStdString());
    }
   }
   //?qDebug() << "ARGS: " << args[0].str;
   return ECL_NIL;
  }, "KB", "TR", pass_on);



 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   RZ_Dynamo_Generator* rdg = runtime->rdg();

   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);

   int size = arglist->frame.size;

   QStringList kw_flags;
   QStringList strings;

   if(size > 1)
   {
    cl_object sym = cl_cxx_backend::nth_arg(arglist, 1);
    QString sn = cl_object_to_qstring(sym);
    cl_arglist_to_flagged_strings(size, 1, arglist, kw_flags, strings);
    if(rdg)
    {
     rdg->parse_sd(sn, kw_flags, strings);
    }
   }
   //?qDebug() << "ARGS: " << args[0].str;
   return ECL_NIL;
  }, "KB", "SD", pass_on);


 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   RZ_Dynamo_Generator* rdg = runtime->rdg();

   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);

   int size = arglist->frame.size;

   QStringList kw_flags;
   QStringList strings;

   if(size > 1)
   {
    cl_object sym = cl_cxx_backend::nth_arg(arglist, 1);
    QString sn = cl_object_to_qstring(sym);

    cl_object sym1 = cl_cxx_backend::nth_arg(arglist, 2);
    QString sn1 = cl_object_to_qstring(sym1);

    if(rdg)
    {
     rdg->parse_si(sn, sn1);
    }
   }
   else if(size == 1)
   {
    cl_object sym = cl_cxx_backend::nth_arg(arglist, 1);
    QString sn = cl_object_to_qstring(sym);
    if(rdg)
    {
     rdg->hold_si(sn);
    }
   }
   //?qDebug() << "ARGS: " << args[0].str;
   return ECL_NIL;
  }, "KB", "SI", pass_on);


 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   RZ_Dynamo_Generator* rdg = runtime->rdg();

   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);

   int size = arglist->frame.size;

   QStringList kw_flags;
   QStringList strings;

   if(size > 1)
   {
    cl_object sym = cl_cxx_backend::nth_arg(arglist, 1);
    QString sn = cl_object_to_qstring(sym);

    cl_object sym1 = cl_cxx_backend::nth_arg(arglist, 2);
    QString sn1 = cl_object_to_qstring(sym1);

    if(rdg)
    {
     rdg->parse_sa_entry(sn, sn1);
    }
   }
   //?qDebug() << "ARGS: " << args[0].str;
   return ECL_NIL;
  }, "KB", "SA_", pass_on);


 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   RZ_Dynamo_Generator* rdg = runtime->rdg();

   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);

   int size = arglist->frame.size;

   QStringList kw_flags;
   QStringList strings;

   if(rdg)
   {
    rdg->sa_leave();
   }
   //?qDebug() << "ARGS: " << args[0].str;
   return ECL_NIL;
  }, "KB", "_SA", pass_on);



 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   RZ_Dynamo_Generator* rdg = runtime->rdg();

   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);

   int size = arglist->frame.size;

   QStringList kw_flags;
   QStringList strings;

   if(size > 1)
   {
    cl_object sym = cl_cxx_backend::nth_arg(arglist, 1);
    QString sn = cl_object_to_qstring(sym);
    cl_arglist_to_flagged_strings(size, 1, arglist, kw_flags, strings);
    if(rdg)
    {
     rdg->parse_sx(sn, kw_flags, strings);
    }
   }
   //?qDebug() << "ARGS: " << args[0].str;
   return ECL_NIL;
  }, "KB", "SX", pass_on);


 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);
   RZ_Dynamo_Generator* rdg = runtime->rdg();
   //?cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);
   int size = arglist->frame.size;
   QStringList kw_flags;
   QStringList strings;
   if(size > 0)
   {
    cl_object sym = cl_cxx_backend::nth_arg(arglist, 1);
    QString sn = cl_object_to_qstring(sym);
    //cl_arglist_to_flagged_strings(size, 1, arglist, kw_flags, strings);
    if(rdg)
    {
     rdg->write_fuxe_carrier(sn);
    }
   }
   return ECL_NIL;
  }, "KB", "FC", pass_on);


 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);
   RZ_Dynamo_Generator* rdg = runtime->rdg();
   //?cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);
   int size = arglist->frame.size;
   //?QStringList kw_flags;
   //?QStringList strings;
   if(size > 0)
   {
    //?cl_object sym = cl_cxx_backend::nth_arg(arglist, 1);
    //QString sn = cl_object_to_qstring(sym);
    QStringList strs;
    cl_arglist_to_strings(size, 0, arglist, strs);
    //cl_arglist_to_flagged_strings(size, 1, arglist, kw_flags, strings);
    if(rdg)
    {
     rdg->write_s1_call(strs);
    }
   }
   return ECL_NIL;
  }, "KB", "S1C", pass_on);


 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);
   RZ_Dynamo_Generator* rdg = runtime->rdg();
   //?cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);
   int size = arglist->frame.size;
   QStringList kw_flags;
   QStringList strings;
   if(size > 0)
   {
    cl_object sym = cl_cxx_backend::nth_arg(arglist, 1);
    QString sn = cl_object_to_qstring(sym);
    //cl_arglist_to_flagged_strings(size, 1, arglist, kw_flags, strings);
    if(rdg)
    {
     rdg->write_lambda_literal_carrier(sn);
    }
   }
   return ECL_NIL;
  }, "KB", "LL", pass_on);



 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   RZ_Dynamo_Generator* rdg = runtime->rdg();

   rdg->enter_fn_body();
   return ECL_NIL;
  }, "KB", "FB_", pass_on);

 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   RZ_Dynamo_Generator* rdg = runtime->rdg();

   rdg->leave_fn_body();
   return ECL_NIL;
  }, "KB", "_FB", pass_on);


 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   RZ_Dynamo_Generator* rdg = runtime->rdg();

   rdg->enter_statement();
   return ECL_NIL;
  }, "KB", "ST_", pass_on);

 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   RZ_Dynamo_Generator* rdg = runtime->rdg();

   rdg->leave_statement();
   return ECL_NIL;
  }, "KB", "_ST", pass_on);


 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);
   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);

   int size = arglist->frame.size;

   QString code;

   if(size == 1)
   {
    cl_object sym = cl_cxx_backend::nth_arg(arglist, 1);
    //if(SYMBOLP(sym))
    //{
     code = cl_arglist_to_qstring(arglist, 1);
     //cl_object type_cl_object = cl_cxx_backend::nth_arg(arglist, 2);
    //}
   }
   //?qDebug() << "ARGS: " << args[0].str;
   return ECL_NIL;
  }, "KB", "HP", pass_on);


 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);
   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);

   int size = arglist->frame.size;

   if(size > 0)
   {
    cl_object sym = cl_cxx_backend::nth_arg(arglist, 1);
    if(SYMBOLP(sym))
    {
     QString sn = cl_arglist_to_qstring(arglist, 1);
     if(size == 1)
     {
//      QObject* qob;
//      const QMetaObject* qmo = runtime->current_lexical_scope()->meta_object_for_symbol_name(sn, qob);
//      if(qob)
//      {
//       qmo->invokeMethod(qob, "import_lisp_eval", Q_ARG(void* ,reval));
//      }
     }
    }
   }
   //?qDebug() << "ARGS: " << args[0].str;
   return ECL_NIL;
  }, "KB", "SR", pass_on);


 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);
   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);

   int size = arglist->frame.size;

   if(size > 0)
   {
    cl_object sym = cl_cxx_backend::nth_arg(arglist, 1);
    if(SYMBOLP(sym))
    {
     QString type_name = cl_arglist_to_qstring(arglist, 1);
     QString type_expression = cl_arglist_to_qstring(arglist, 2);
//?     reval->kauvir_runtime()->process_type_declaration(type_name, type_expression);
    }
   }
   //?qDebug() << "ARGS: " << args[0].str;
   return ECL_NIL;
  }, "KB", "TD", pass_on);

 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);

   if(runtime->rdg())
   {
    runtime->rdg()->enter_scope();
    return ECL_NIL;
   }

   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   //?Kauvir_Lisp_Kargs* kargs;
   int size = arglist->frame.size;
   if(size == 1)
   {
    cl_object cl_arg = cl_cxx_backend::nth_arg(arglist, 1);
    void* pv = ecl_foreign_data_pointer_safe(cl_arg);
    //?kargs = static_cast<Kauvir_Lisp_Kargs*>(pv);
   }
   else
   {
    //?kargs = nullptr;
   }
   //?runtime->enter_scope(kargs);
   return ECL_NIL;
  }, "KB", "ES", pass_on);

 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   int size = arglist->frame.size;

   if(size == 2)
   {
    cl_object sym = cl_cxx_backend::nth_arg(arglist, 1);
    if(SYMBOLP(sym))
    {
     QString sn = cl_arglist_to_qstring(arglist, 1);
     cl_object sym1 = cl_cxx_backend::nth_arg(arglist, 2);
     if(SYMBOLP(sym1))
     {
      QString sn1 = cl_arglist_to_qstring(arglist, 2);
//      Kauvir_Scoped_Value_Proxy* result =
//        runtime->current_lexical_scope()->init_function_scope_value(sn, sn1);
   //?   if(result)
   //?   {
//       void* result_pv = const_cast<void*>(reinterpret_cast<const void*>(result));
//       cl_object cl_result = cl_cxx_backend::make_foreign_data(result_pv);
//       return cl_result;
    //?  }
     }
    }
   }
   //runtime->enter_scope();
   return ECL_NIL;
  }, "KB", "SC", pass_on);

 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   int size = arglist->frame.size;

   if(size == 2)
   {
//    Kauvir_Lisp_Kargs* kla = static_cast<Kauvir_Lisp_Kargs*>(ecl_foreign_data_pointer_safe(cl_cxx_backend::nth_arg(arglist, 1)));
//    if(kla)
//    {
//     cl_object sym = cl_cxx_backend::nth_arg(arglist, 2);
//     if(SYMBOLP(sym))
//     {
//      QString sn = cl_arglist_to_qstring(arglist, 2);
//      Kauvir_Scoped_Value_Proxy* result = kla->get_value_from_symbol_code(sn);
//      QString* str = (QString*) result->raw_value();
//      if(result)
//      {
//       void* result_pv = const_cast<void*>(reinterpret_cast<const void*>(result));
//       cl_object cl_result = cl_cxx_backend::make_foreign_data(result_pv);
//       return cl_result;
//      }
//     }
//   }
   }
   //runtime->enter_scope();
   return ECL_NIL;
  }, "KB", "SV", pass_on);

 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   int size = arglist->frame.size;

   if(size == 2)
   {
//    Kauvir_Lisp_Kargs* kla = static_cast<Kauvir_Lisp_Kargs*>(ecl_foreign_data_pointer_safe(cl_cxx_backend::nth_arg(arglist, 1)));
//    if(kla)
//    {
//     cl_object sym = cl_cxx_backend::nth_arg(arglist, 2);
//     if(SYMBOLP(sym))
//     {
//      QString sn = cl_arglist_to_qstring(arglist, 2);
//      Kauvir_Scoped_Value_Proxy* result = kla->get_value_from_symbol_code(sn);
//      if(result)
//      {
//       QString* str = static_cast<QString*>(result->raw_value());
//       cl_object cl_result = make_base_string_copy(str->toStdString().c_str());
//       return cl_result;
//      }
//     }
//    }
   }
   //runtime->enter_scope();
   return ECL_NIL;
  }, "KB", "SVS", pass_on);


 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   if(runtime->rdg())
   {
    runtime->rdg()->leave_scope();
    return ECL_NIL;
   }


//   Kauvir_Lisp_Kargs* kargs;
//   int size = arglist->frame.size;
//   if(size == 1)
//   {
//    cl_object cl_arg = cl_cxx_backend::nth_arg(arglist, 1);
//    void* pv = ecl_foreign_data_pointer_safe(cl_arg);
//    kargs = static_cast<Kauvir_Lisp_Kargs*>(pv);
//   }
//   else
//   {
//    kargs = nullptr;
//   }

//   runtime->leave_scope(kargs);
   return ECL_NIL;
  }, "KB", "LS", pass_on);



 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);
   int size = arglist->frame.size;
   if(size == 3)
   {
    cl_object lambda_pos = cl_cxx_backend::nth_arg(arglist, 1);
    quint64 fixnum = ecl_to_fixnum(lambda_pos);

    QString access;
    cl_object access_sym = cl_cxx_backend::nth_arg(arglist, 2);
    if(SYMBOLP(access_sym))
    {
     access = cl_arglist_to_qstring(arglist, 2);
    }

    cl_object result = cl_cxx_backend::nth_arg(arglist, 3);
    //?runtime->insert_lambda_type__string(fixnum, access);
    return result;
   }
   else
   {
    return ECL_NIL;
   }
  }, "KL", "STR", pass_on);


 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);
   int size = arglist->frame.size;

   if(size == 3)
   {
    cl_object lambda_pos = cl_cxx_backend::nth_arg(arglist, 1);

    QString access;
    cl_object access_sym = cl_cxx_backend::nth_arg(arglist, 2);
    if(SYMBOLP(access_sym))
    {
     access = cl_arglist_to_qstring(arglist, 2);
    }

    quint64 fixnum = ecl_to_fixnum(lambda_pos);

    cl_object quoted = cl_cxx_backend::nth_arg(arglist, 3);

    //quoted->

    //?runtime->insert_lambda_type__callable_lisp_value(fixnum, access);
    return quoted;
   }
   else
   {
    return ECL_NIL;
   }
  }, "KA", "CLQ", pass_on);

 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);
   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);

   int size = arglist->frame.size;

   if(size > 0)
   {
    QString symbol_name = cl_arglist_to_qstring(arglist, 1);
    quint64 result = runtime->bridge().get_value_of_symbol(symbol_name);
    return (cl_object) result;
   }
   return ECL_NIL;
  }, "KA", "VOF", pass_on);

 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);
   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);

   int size = arglist->frame.size;

   if(size > 0)
   {
    QString symbol_name = cl_arglist_to_qstring(arglist, 1);
    quint64 result = runtime->bridge().get_value_of_symbol(symbol_name);
    return (cl_object) result;
   }
   return ECL_NIL;
  }, "KA", "UNHOLD", pass_on);


 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);
   int size = arglist->frame.size;

   if(size == 3)
   {
    cl_object lambda_pos = cl_cxx_backend::nth_arg(arglist, 1);

    QString access;
    cl_object access_sym = cl_cxx_backend::nth_arg(arglist, 2);
    if(SYMBOLP(access_sym))
    {
     access = cl_arglist_to_qstring(arglist, 2);
    }

    quint64 fixnum = ecl_to_fixnum(lambda_pos);

    //  just a plain cl_object or ...?
//?
//    cl_object lisp_function = cl_cxx_backend::nth_arg(arglist, 3);

//    cl_object* save_cl = new cl_object;
//    *save_cl = lisp_function;
//    Kauvir_Lisp_Callback* klc = new Kauvir_Lisp_Callback(save_cl);

//    if(access.contains('a'))
//    {
//     klc->mark_async();
//    }
//    cl_object clo_klc = cl_cxx_backend::make_foreign_data(klc);
//    runtime->insert_lambda_type__callable_lisp_value(fixnum, access);
//    return clo_klc;
   }
   else
   {
    return ECL_NIL;
   }
  }, "KA", "CLF", pass_on);



 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);
   int size = arglist->frame.size;

   if(size == 2)
   {
    cl_object lambda = cl_cxx_backend::nth_arg(arglist, 1);
    QString fname = cl_arglist_to_qstring(arglist, 2);
    runtime->bridge().kcm_finalize_fdef((quint64) lambda, fname);

    //quint64 fixnum = ecl_to_fixnum(lambda);
   }
   else
   {
    return ECL_NIL;
   }
  }, "KA", "FINALIZE-FDEF", pass_on);
}


void KCM_Lisp_Eval::prepare_callbacks()
{
 void** pass_on = (void**) malloc(2 * sizeof(void*));

 pass_on[0] = kcm_lisp_runtime_;
 pass_on[1] = this;

 cl_cxx_backend::eval_string("(DEFPACKAGE \"KM\")");

 cl_cxx_backend::eval_string("(DEFPACKAGE \"KA\")");
 cl_cxx_backend::eval_string("(DEFPACKAGE \"KB\")");
 cl_cxx_backend::eval_string("(DEFPACKAGE \"KI\")");
 cl_cxx_backend::eval_string("(DEFPACKAGE \"KL\")");
 cl_cxx_backend::eval_string("(DEFPACKAGE \"KG\")");
 cl_cxx_backend::eval_string("(DEFPACKAGE \"KC\")");
 cl_cxx_backend::eval_string("(DEFPACKAGE \"CY\")");
 cl_cxx_backend::eval_string("(DEFPACKAGE \"CX\")");

 prepare_dynamo_callbacks(pass_on);

 prepare_cy_callbacks(pass_on);


// define_callback(
//  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
//  {
//   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
//   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

//   //?QList<Kauvir_Lisp_Argument> args;

//   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);
//   int size = arglist->frame.size;

//   if(size > 0)
//   {
//    cl_object result = cl_cxx_backend::nth_arg(arglist, 1);
//    if(SYMBOLP(result))
//    {
//     QString sn = cl_arglist_to_qstring(arglist, 1);

//     QString fn = reval->parse_arglist_to_queues(arglist);

//     Kauvir_Channel_Group* kcg = reval->kauvir_runtime()->check_invocation(fn, runtime->lambda_queue());

//     if(kcg)
//     {
//      reval->proceed_with_invocation(runtime, fn, kcg, arglist);
//      //?QString fn = reval->KCM_Lisp_Runtime()->current_function_name();
//     }
//     else
//     {
//      reval->check_qobject_call(runtime, fn, arglist);
//     }

//     reval->clear_queues();
//     //si_coerce_to_base_string()
//     //cl_object sn = result->symbol.name;
//    }

//   }

//   return ECL_NIL;
//   //RZ_Lisp_Eval* pRle = reinterpret_cast<RZ_Lisp_Eval*>( ((void**) pass_on)[1]);
//  }, "KA", "FC", pass_on);


 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
//   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
//   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);
//   QList<Kauvir_Lisp_Argument> args;

//   cl_arglist_to_qstrings(args, arglist);
//   cl_object cl_result = ECL_NIL;

//   qDebug() << "ARGS: " << args[0].str();
//   return ECL_NIL;
   //RZ_Lisp_Eval* pRle = reinterpret_cast<RZ_Lisp_Eval*>( ((void**) pass_on)[1]);
  }, "KA", "QDEBUG", pass_on);


 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
 {
  KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
  KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

  //?cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);

  int size = arglist->frame.size;

  if(size > 0)
  {
   cl_object sym = cl_cxx_backend::nth_arg(arglist, 1);

   if(SYMBOLP(sym))
   {
    QString sn = cl_arglist_to_qstring(arglist, 1);

    QVector<KCM_Lisp_Runtime_Argument> klras;
    klras.resize(size);

    if(sn.startsWith('_'))
    {
     QString kw = reval->cl_arglist_to_opaque_arguments(arglist, klras);
     klras[1].set_string(kw);
    }
    else
    {
     reval->cl_arglist_to_arguments(arglist, klras);
    }
    runtime->kcm_call(sn, klras);
    const KCM_Lisp_Runtime_Argument& klra = klras[0];
    switch(klra.get_kind())
    {
    case KCM_Lisp_Runtime_Argument::Kinds::Cl_Object:
     return (cl_object) klra.cl_object();
    case KCM_Lisp_Runtime_Argument::Kinds::String:
     return make_base_string_copy(klra.string().toStdString().c_str());
    case KCM_Lisp_Runtime_Argument::Kinds::PVoid:
     return cl_cxx_backend::make_foreign_data(klra.pVoid());
    default:
     return ECL_NIL;
    }

//    qDebug() << sn;
//    quint64 call_result = 0;
//    switch(size)
//    {
//    case 1:
//     break;
//    case 2:
//    case 3:
//    case 4:
//     {

//      cl_object arg0 = cl_cxx_backend::nth_arg(arglist, 2);

//      runtime->kcm_call(sn, call_result, (quint64) arg0);
//      break;
//     }
//    }
//
//    if(size == 1)
//    {
//     runtime->current_lexical_scope()->default_init_value(sn);
//    }

   }
  }
 }, "KA", "KC", pass_on);


 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);
   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);

   int size = arglist->frame.size;

   QString followup_code;

   if(size > 1)
   {
    cl_object sym = cl_cxx_backend::nth_arg(arglist, 1);
    followup_code = cl_arglist_to_qstring(arglist, 1);
   }

//?   Kauvir_Type_Object* tob = reval->kcm_runtime()->type_object_builder_complete(followup_code);// Kauvir_Channel_Group
//?   return cl_cxx_backend::make_foreign_data(tob);

  }, "KA", "tobc", pass_on);


// define_callback(
//  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
//  {
//   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
//   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

////   Kauvir_Lisp_Kargs* kargs;
////   int size = arglist->frame.size;
////   if(size == 1)
////   {
////    cl_object cl_arg = cl_cxx_backend::nth_arg(arglist, 1);
////    void* pv = ecl_foreign_data_pointer_safe(cl_arg);
////    kargs = static_cast<Kauvir_Lisp_Kargs*>(pv);
////   }
////   else
////   {
////    kargs = nullptr;
////   }

////   runtime->enter_scope(kargs);
//   return ECL_NIL;
//  }, "KA", "ES", pass_on);



// define_callback(
//  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
//  {
//   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
//   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

////   Kauvir_Lisp_Kargs* kargs;
////   int size = arglist->frame.size;
////   if(size == 1)
////   {
////    cl_object cl_arg = cl_cxx_backend::nth_arg(arglist, 1);
////    void* pv = ecl_foreign_data_pointer_safe(cl_arg);
////    kargs = static_cast<Kauvir_Lisp_Kargs*>(pv);
////   }
////   else
////   {
////    kargs = nullptr;
////   }

////   runtime->leave_scope(kargs);
//   return ECL_NIL;
//  }, "KA", "LS", pass_on);



 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);
   int size = arglist->frame.size;
   if(size == 3)
   {
    cl_object lambda_pos = cl_cxx_backend::nth_arg(arglist, 1);
    quint64 fixnum = ecl_to_fixnum(lambda_pos);

    QString access;
    cl_object access_sym = cl_cxx_backend::nth_arg(arglist, 2);
    if(SYMBOLP(access_sym))
    {
     access = cl_arglist_to_qstring(arglist, 2);
    }

    cl_object result = cl_cxx_backend::nth_arg(arglist, 3);

    //runtime->insert_lambda_type__string(fixnum, access);
    return result;
   }
   else
   {
    return ECL_NIL;
   }
  }, "KL", "STR", pass_on);


 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);
   int size = arglist->frame.size;

   if(size == 3)
   {
    cl_object lambda_pos = cl_cxx_backend::nth_arg(arglist, 1);

    QString access;
    cl_object access_sym = cl_cxx_backend::nth_arg(arglist, 2);
    if(SYMBOLP(access_sym))
    {
     access = cl_arglist_to_qstring(arglist, 2);
    }

    quint64 fixnum = ecl_to_fixnum(lambda_pos);

    cl_object quoted = cl_cxx_backend::nth_arg(arglist, 3);

    //quoted->

    //runtime->insert_lambda_type__callable_lisp_value(fixnum, access);
    return quoted;
   }
   else
   {
    return ECL_NIL;
   }
  }, "KA", "CLQ", pass_on);

 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);
   int size = arglist->frame.size;

   if(size == 3)
   {
    cl_object lambda_pos = cl_cxx_backend::nth_arg(arglist, 1);

    QString access;
    cl_object access_sym = cl_cxx_backend::nth_arg(arglist, 2);
    if(SYMBOLP(access_sym))
    {
     access = cl_arglist_to_qstring(arglist, 2);
    }

    quint64 fixnum = ecl_to_fixnum(lambda_pos);

    //  just a plain cl_object or ...?
    cl_object lisp_function = cl_cxx_backend::nth_arg(arglist, 3);

    cl_object* save_cl = new cl_object;
    *save_cl = lisp_function;

//    Kauvir_Lisp_Callback* klc = new Kauvir_Lisp_Callback(save_cl);

//    if(access.contains('a'))
//    {
//     klc->mark_async();
//    }

    //?cl_object clo_klc = cl_cxx_backend::make_foreign_data(klc);



    //quoted->

//    runtime->insert_lambda_type__callable_lisp_value(fixnum, access);
    //?return clo_klc;
   }
   else
   {
    return ECL_NIL;
   }
  }, "KA", "CLF", pass_on);


}

QString KCM_Lisp_Eval::get_string_rep(cl_object clo)
{
 cl_object clp = cl_print(1, clo);
 QString result = cl_object_to_qstring(clp);
 return result;
}


void KCM_Lisp_Eval::eval_script_file(QString file_name, int load_depth, QString top_file)
{
 QFile file(file_name);

 if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
  return;
 QString eval_text = file.readAll();

 eval_text.prepend("(progn\n");
 eval_text.append("\n\n);progn\n");

 QFileInfo fi(file_name);
 QDir default_dir = fi.absoluteDir();

 if(top_file.isEmpty())
  top_file = file_name;

 QString result = eval_string(eval_text);


 //QString fe = eval(eval_text, "", file_name, load_depth, top_file, &default_dir);
}

void KCM_Lisp_Eval::eval_file(QString file_name, int load_depth, QString top_file)
{
 QFile file(file_name);

 if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
  return;
 QString eval_text = file.readAll();

 QFileInfo fi(file_name);
 QDir default_dir = fi.absoluteDir();

 if(top_file.isEmpty())
  top_file = file_name;

 QString result = eval_string(eval_text);

// return sr;

//? QString fe = eval(eval_text, "", file_name, load_depth, top_file, &default_dir);

}


QString KCM_Lisp_Eval::eval_string(QString eval_text)
{
 QString result;
 cl_object result_cl = cl_cxx_backend::eval_string(eval_text.toLatin1().data());
 result_cl = si_coerce_to_base_string(result_cl);
 unsigned char * cc = result_cl->base_string.self;

 for(unsigned char* c = cc; *c != 0; ++c)
 {
  QChar qc = QChar::fromLatin1(*c);
  result += qc;
 }
 return result;
}

QString KCM_Lisp_Eval::cl_arglist_to_qstring(cl_cxx_backend::cl_arglist arglist)
{
 QString result;
 cl_object result_cl = cl_cxx_backend::nth_arg(arglist, 1);
 result_cl = si_coerce_to_base_string(result_cl);
 unsigned char * cc = result_cl->base_string.self;

 for(unsigned char* c = cc; *c != 0; ++c)
 {
  QChar qc = QChar::fromLatin1(*c);
  result += qc;
 }
 return result;
}

MS_Token KCM_Lisp_Eval::cl_object_to_ms_token(cl_object clo)
{
 QString str = cl_object_to_qstring(clo);
 return MS_Token::decode(str);
}

cl_object KCM_Lisp_Eval::qstring_to_cl_object(QString qs)
{
 std::string sstr = qs.toStdString();
 return cl_cxx::to_cl_object<const std::string&>(sstr);
}

QString KCM_Lisp_Eval::cl_object_to_qstring(cl_object clo)
{
 QString result;
 clo = si_coerce_to_base_string(clo);
 unsigned char * cc = clo->base_string.self;

 for(unsigned char* c = cc; *c != 0; ++c)
 {
  QChar qc = QChar::fromLatin1(*c);
  result += qc;
 }
 return result;
}

QString KCM_Lisp_Eval::cl_arglist_to_qstring(cl_cxx_backend::cl_arglist arglist, int index)
{
 QString result;
 cl_object result_cl = cl_cxx_backend::nth_arg(arglist, index);
 result_cl = si_coerce_to_base_string(result_cl);
 unsigned char * cc = result_cl->base_string.self;

 for(unsigned char* c = cc; *c != 0; ++c)
 {
  QChar qc = QChar::fromLatin1(*c);
  result += qc;
 }
 return result;
}

//QString KCM_Lisp_Eval::cl_object_to_qstring(cl_object clo)
//{
// QString result;
// cl_object result_cl = si_coerce_to_base_string(clo);
// unsigned char * cc = result_cl->base_string.self;

// for(unsigned char* c = cc; *c != 0; ++c)
// {
//  QChar qc = QChar::fromLatin1(*c);
//  result += qc;
// }
// return result;
//}


void KCM_Lisp_Eval::prepare_cy_callbacks(void** pass_on)
{
 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   //?QList<Kauvir_Lisp_Argument> args;

   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);
   int size = arglist->frame.size;

   QString result;


   ClouDynamo_Interface* cyi = runtime->cyi();

   if(cyi)
   {
    result = cyi->get_confirmation();
    //std::string rs = result.toStdString();
    return cl_cxx::to_cl_object<const std::string&>(result.toStdString());
   }

   return ECL_NIL;
   //RZ_Lisp_Eval* pRle = reinterpret_cast<RZ_Lisp_Eval*>( ((void**) pass_on)[1]);
  }, "CY", "TEST-LISP-RESPONSE", pass_on);


 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   //?QList<Kauvir_Lisp_Argument> args;

   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);
   int size = arglist->frame.size;

   QString result;

   ClouDynamo_Interface* cyi = runtime->cyi();

   cl_object sym = cl_cxx_backend::nth_arg(arglist, 1);
   QString sn = cl_object_to_qstring(sym);

   QString code;
   if(size > 1)
   {
    code = cl_arglist_to_qstring(arglist, 2);
   }

   if(cyi)
   {
    QString result;
    cyi->run_command(sn, code, result);
    result.prepend("<i>Command Result:</i>\n<br>");
    return cl_cxx::to_cl_object<const std::string&>(result.toStdString());
   }

   return ECL_NIL;
   //RZ_Lisp_Eval* pRle = reinterpret_cast<RZ_Lisp_Eval*>( ((void**) pass_on)[1]);
  }, "CY", "CMD", pass_on);


 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   //?QList<Kauvir_Lisp_Argument> args;

   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);
   int size = arglist->frame.size;

   QString result = reval->env()->process_name();
   return cl_cxx::to_cl_object<const std::string&>(result.toStdString());
   ClouDynamo_Interface* cyi = runtime->cyi();

   if(cyi)
   {
    //?return cl_cxx::to_cl_object<const std::string&>(result.toStdString());
   }

   return ECL_NIL;
   //RZ_Lisp_Eval* pRle = reinterpret_cast<RZ_Lisp_Eval*>( ((void**) pass_on)[1]);
  }, "CY", "CHECK-PROCESS-NAME", pass_on);


 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   //?QList<Kauvir_Lisp_Argument> args;

   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);
   int size = arglist->frame.size;

   QString result;
   if(reval->embed_callback())
   {
    QStringList qsl;
    reval->embed_callback()("CHECK-CODE-LOG", result, qsl, QString());
   }
   return cl_cxx::to_cl_object<const std::string&>(result.toStdString());
  }, "CY", "CHECK-CODE-LOG", pass_on);

 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   //?QList<Kauvir_Lisp_Argument> args;

   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);
   int size = arglist->frame.size;

   cl_object sym = cl_cxx_backend::nth_arg(arglist, 1);
   QString sn = cl_object_to_qstring(sym);

   QString result;
   if(reval->embed_callback())
   {
    QStringList qsl;
    reval->embed_callback()(sn, result, qsl, QString());
   }
   return cl_cxx::to_cl_object<const std::string&>(result.toStdString());
  }, "CY", "RUN-EMBED-CB", pass_on);

 define_callback(
  [](void* pass_on, cl_cxx_backend::cl_arglist arglist) -> cl_object
  {
   KCM_Lisp_Runtime* runtime = reinterpret_cast<KCM_Lisp_Runtime*>( ((void**) pass_on)[0]);
   KCM_Lisp_Eval* reval = reinterpret_cast<KCM_Lisp_Eval*>( ((void**) pass_on)[1]);

   //?QList<Kauvir_Lisp_Argument> args;

   cl_object result_size = cl_cxx_backend::nth_arg(arglist, 0);
   int size = arglist->frame.size;

   cl_object sym = cl_cxx_backend::nth_arg(arglist, 1);
   QString sn = cl_object_to_qstring(sym);

   QStringList kw_flags;
   QStringList strings;
   cl_arglist_to_flagged_strings(size, 1, arglist, kw_flags, strings);

   QString result;
   if(reval->embed_callback())
   {
    reval->embed_callback()(sn, result, strings, kw_flags.join(""));
   }
   return cl_cxx::to_cl_object<const std::string&>(result.toStdString());
  }, "CY", "CB", pass_on);


}


