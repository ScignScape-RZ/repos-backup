 
#include "kcm-lisp-bridge/kcm-lisp-bridge.h"
#include "kcm-lisp-bridge/kcm-lisp-embed-environment.h"
#include "kcm-lisp-bridge/kcm-lisp-eval.h"


#include <QCoreApplication>

USING_KANS(KCM)
USING_KANS(KCL)

int main(int argc, char* argv[])
{
 QCoreApplication qapp(argc, argv);

 qRegisterMetaType<KCM_Lisp_Bridge>();
 qRegisterMetaType<KCM_Lisp_Bridge*>();

 KCM_Lisp_Embed_Environment env(argc, argv);
 KCM_Lisp_Eval kle(&env);

 kle.prepare_callbacks();
 //kle.eval_script_file("/ext_root/kauv/lisp-thorin/t1.cl");

 //kle.eval_script_file("/ext_root/kauv/rz-dynamo/t1.dynamo.lisp");
 kle.eval_script_file("/ext_root/kauv/cloudynamo/t1.cl");

 return 0;
}
