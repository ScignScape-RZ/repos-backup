
#ifndef RZ_DYNAMO_BASIC_FUNCTIONS__H
#define RZ_DYNAMO_BASIC_FUNCTIONS__H


#include "accessors.h"

#include "kans.h"

#include <QString>
#include <QStringList>

#include <QMap>

class QTextStream;

KANS_CLASS_DECLARE(KCM ,Kauvir_Code_Model)

USING_KANS(KCM)

KANS_(Dynamo)

void init_basic_functions_kci(Kauvir_Code_Model& kcm);

void* envv(void* kind);
void* insert_envv(void* kind, void* test);

void prs(QString str);
void prn(int num);
int let_num(int num);
QString let_str(QString str);


void prfn(int num);

_KANS(Dynamo)

#endif
