
#include "cloudynamo-interface.h"


#include <QTextStream>

#include <QDebug>
#include <QProcess>
#include <QNetworkRequest>
#include <QNetworkAccessManager>
#include <QNetworkReply>

#include <QEventLoop>

USING_KANS(Dynamo)

ClouDynamo_Interface::ClouDynamo_Interface()
  :  qnam_(nullptr)
{

}

ClouDynamo_Interface::Commands ClouDynamo_Interface::parse_command(QString cmd)
{
 static QMap<QString, Commands> static_map {{
   {"launch-meshlab", Commands::Launch_Meshlab},
   {"send-meshlab", Commands::Send_Meshlab},
   {"check-meshlab-process", Commands::Check_Meshlab_Process},
  }};

 return static_map.value(cmd);
}

QString ClouDynamo_Interface::get_confirmation()
{
 return "<b>ClouDynamo Interface Responding ...<b>";
}

void ClouDynamo_Interface::run_command(QString cmd, QString code, QString& result)
{
 Commands run_cmd = parse_command(cmd);

 switch(run_cmd)
 {
 case Commands::Launch_Meshlab:
  launch_meshlab();
  result = "Process Started ...";
  break;
 case Commands::Send_Meshlab:
  result = send_meshlab(code);
  break;
 case Commands::Check_Meshlab_Process:
  result = check_meshlab_process(code);
  break;
 default:
  result = "Command not recognized: ";
  result += cmd;
  break;
 }
}

QString ClouDynamo_Interface::check_meshlab_process(QString code)
{
 check_init_qnam();
 int port = 32036;
 QString addr = QString("http://localhost:%1/").arg(port);//.arg(url);

 QNetworkRequest req;

 req.setUrl( QUrl(addr) );
 req.setHeader(QNetworkRequest::ContentTypeHeader, "text/plain");

 QByteArray qba = "(cy::check-process-name)";
 qba.append("<<//>>");


 QNetworkReply* reply = qnam_->post(req, qba);

 QEventLoop qel;

 QString result;

 QObject::connect(reply, &QNetworkReply::finished,
  [this, reply, &qel, &result]()
 {
  result = QString::fromLatin1( reply->readAll() );
  if(result.isEmpty())
  {
   result = "Process not found.";
  }
  qDebug() << "Result: " << result;
  reply->deleteLater();
  qel.exit();
 });

 qel.exec();

 return result;
}

void ClouDynamo_Interface::check_init_qnam()
{
 if(!qnam_)
 {
  qnam_ = new QNetworkAccessManager;
 }
}


QString ClouDynamo_Interface::send_meshlab(QString code)
{
 check_init_qnam();
 int port = 32036;

 //QString addr = QString("http://%1").arg(url);
 QString addr = QString("http://localhost:%1/").arg(port);//.arg(url);

 QNetworkRequest req;

 req.setUrl( QUrl(addr) );
 req.setHeader(QNetworkRequest::ContentTypeHeader, "text/plain");

 QByteArray qba = code.toLatin1();
 qba.append("<<//>>");


 QNetworkReply* reply = qnam_->post(req, qba);

 QEventLoop qel;

 QString result;

 QObject::connect(reply, &QNetworkReply::finished,
  [this, reply, &qel, &result]()
 {
  result = QString::fromLatin1( reply->readAll() );
  qDebug() << "Result: " << result;
  reply->deleteLater();
  qel.exit();
 });

 qel.exec();

 return result;

}


void ClouDynamo_Interface::launch_meshlab()
{
 QProcess* process = new QProcess();

 //?
 //QString program = "/ext_root/MeshLab/meshlab/build-meshlab_full-Desktop_Qt_5_9_0_GCC_64bit-Debug/meshlab/meshlab";

 QString program = "/ext_root/kauv/cloudynamo/run-meshlab.sh";

 QString err_file = "/ext_root/kauv/cloudynamo/t1.err";

 //
 //qDebug() << "Folder: " << folder << ", Module " << ll_file;

 //? process->setArguments({"-filetype=obj", ll_file});
 process->setStandardErrorFile(err_file);
 process->setProgram(program);
 //?process->start(program, {folder});
 process->start();

}
