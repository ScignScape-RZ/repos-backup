
#ifndef CLOUDYNAMO_INTERFACE__H
#define CLOUDYNAMO_INTERFACE__H


#include "accessors.h"

#include "kans.h"

#include <QString>
#include <QStringList>
#include <QNetworkAccessManager>

#include <QMap>

class QTextStream;

KANS_(Dynamo)

class ClouDynamo_Interface
{
 enum class Commands {
  N_A, Launch_Meshlab, Send_Meshlab, Check_Meshlab_Process
 };

 Commands parse_command(QString cmd);

 QNetworkAccessManager* qnam_;

 void check_init_qnam();

public:


 ClouDynamo_Interface();

 QString get_confirmation();

 void run_command(QString cmd, QString code, QString& result);
 void launch_meshlab();
 QString send_meshlab(QString code);
 QString check_meshlab_process(QString code);

};


_KANS(Dynamo)

#endif
