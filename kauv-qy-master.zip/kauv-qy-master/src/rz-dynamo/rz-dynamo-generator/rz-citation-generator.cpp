
#include "rz-citation-generator.h"

#include "rz-citation-package.h"


#include <QTextStream>
#include <QDebug>
#include <QDataStream>

#include "rz-dynamo-nested-acc.h"

#include "textio.h"
#include "base32.h"


USING_KANS(Dynamo)


RZ_Citation_Generator::RZ_Citation_Generator()
  :  current_citation_(nullptr)
{
 reset_acc();
}

void RZ_Citation_Generator::reset_acc()
{
 current_acc_ = &general_acc_;
}

void RZ_Citation_Generator::enter_author(QStringList& tokens)
{
 current_acc_ = &current_author_;
}

void RZ_Citation_Generator::leave_author(QStringList& tokens)
{
 authors_.push_back(current_author_);
 current_author_.clear();
 reset_acc();
}

void RZ_Citation_Generator::write_raw(QStringList& tokens)
{
 current_acc_->append('$');
 current_acc_->append(tokens.first());
}

void RZ_Citation_Generator::write_tex(QStringList& tokens)
{
 current_acc_->append('%');
 current_acc_->append(tokens.first());
}

void RZ_Citation_Generator::write_xml(QStringList& tokens)
{
 current_acc_->append('@');
 current_acc_->append(tokens.first());
}

//void RZ_Citation_Generator::write_name(QStringList& tokens)
//{
//}
//void RZ_Citation_Generator::write_iname(QStringList& tokens)
//{
//}
//void RZ_Citation_Generator::write_sname(QStringList& tokens)
//{
//}


void RZ_Citation_Generator::enter_title(QStringList& tokens)
{
 current_acc_ = &current_title_;
}

void RZ_Citation_Generator::leave_title(QStringList& tokens)
{
 //?current_title_.clear();
 reset_acc();
}

void RZ_Citation_Generator::enter_local_path(QStringList& tokens)
{
 current_acc_ = &current_local_path_;
}

void RZ_Citation_Generator::leave_local_path(QStringList& tokens)
{
 reset_acc();
}

void RZ_Citation_Generator::enter_url(QStringList& tokens)
{
 current_acc_ = &current_url_;
}

void RZ_Citation_Generator::leave_url(QStringList& tokens)
{
 reset_acc();
}



void RZ_Citation_Generator::enter_citation(QStringList& tokens)
{
 current_citation_ = new RZ_Citation_Package;
}

void RZ_Citation_Generator::leave_citation(QStringList& tokens)
{
 complete_citation();
 citations_.push_back(current_citation_);
 current_citation_ = nullptr;
 authors_.clear();
 current_title_.clear();
 current_local_path_.clear();
 current_url_.clear();
}

void RZ_Citation_Generator::complete_citation()
{
 for(QString author : authors_)
 {
  current_citation_->add_author(author);
 }
 current_citation_->set_main_title(current_title_);
 current_citation_->set_local_path(current_local_path_);
 current_citation_->set_url(current_url_);
}

void operator>>(QDataStream& qds, RZ_Citation_Package*& citation)
{
 citation = new RZ_Citation_Package;
 citation->load_from_binary(qds);
 //?citation.load_from_binary(qds);
}

void RZ_Citation_Generator::load_base32(QStringList& tokens)
{
 QString path = tokens.first();
 QString text;
 KA::TextIO::load_file(path, text);
 if(text.isEmpty())
 {
  return;
 }
 QByteArray qba;
 KA::Base32::decode_qstring(text, qba);
 QDataStream qds(qba);
 qds >> citations_;
}

void RZ_Citation_Generator::load_binary(QStringList& tokens)
{
 QString path = tokens.first();

 QFile infile(path);
 if (!infile.open(QIODevice::ReadOnly))
   return;
 QDataStream instream(&infile);

 instream >> citations_;

 infile.close();
}

void operator<<(QDataStream& qds, RZ_Citation_Package* citation)
{
 citation->write_binary(qds);
}

void RZ_Citation_Generator::write_binary(QStringList& tokens)
{
 QString path = tokens.first();

 QFile outfile(path);
 if (!outfile.open(QIODevice::WriteOnly | QIODevice::Text))
   return;
 QDataStream outstream(&outfile);
 outstream << citations_;

// for(RZ_Citation_Package* rcp : citations_)
// {
//  rcp->write_binary(outstream);
// }

 outfile.close();
}

void RZ_Citation_Generator::write_base32(QStringList& tokens)
{
 QString path = tokens.first();

 QByteArray qba;
 QDataStream qds(&qba, QIODevice::WriteOnly);
 qds << citations_;
 QString text;
 KA::Base32::encode_qba(qba, text);
 KA::TextIO::save_file(path, text);
}


void RZ_Citation_Generator::write_summary(QStringList& tokens)
{
 QString path = tokens.first();

 QFile outfile(path);
 if (!outfile.open(QIODevice::WriteOnly | QIODevice::Text))
   return;
 QTextStream outstream(&outfile);

 for(RZ_Citation_Package* rcp : citations_)
 {
  outstream << '\n';
  rcp->write_summary(outstream);
  outstream << "\n\n+-+-+-+\n";
 }

 outfile.close();
}





