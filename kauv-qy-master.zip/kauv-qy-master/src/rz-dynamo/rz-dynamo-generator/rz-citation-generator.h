
#ifndef RZ_CITATION_GENERATOR__H
#define RZ_CITATION_GENERATOR__H


#include "accessors.h"

#include "multistep-token.h"

#include "kans.h"

#include <QString>
#include <QStringList>
#include <QStack>
#include <QPair>

class QTextStream;


KANS_(Dynamo)


class RZ_Citation_Package;


class RZ_Citation_Generator
{
 QStringList authors_;
 QString current_author_;
 QString current_title_;
 QString current_url_;
 QString current_local_path_;

 QString general_acc_;

 QString* current_acc_;

 QList<RZ_Citation_Package*> citations_;

 RZ_Citation_Package* current_citation_;

 void reset_acc();

public:


 RZ_Citation_Generator();

 void enter_author(QStringList& tokens);
 void leave_author(QStringList& tokens);

// void write_name(QStringList& tokens);
// void write_iname(QStringList& tokens);
// void write_sname(QStringList& tokens);
//? void write_aname(QStringList& tokens);

 void write_raw(QStringList& tokens);
 void write_tex(QStringList& tokens);
 void write_xml(QStringList& tokens);

 void enter_title(QStringList& tokens);
 void leave_title(QStringList& tokens);

 void enter_url(QStringList& tokens);
 void leave_url(QStringList& tokens);

 void enter_local_path(QStringList& tokens);
 void leave_local_path(QStringList& tokens);

 void enter_citation(QStringList& tokens);
 void leave_citation(QStringList& tokens);

 void write_summary(QStringList& tokens);

 void write_binary(QStringList& tokens);
 void load_binary(QStringList& tokens);

 void write_base32(QStringList& tokens);
 void load_base32(QStringList& tokens);

 void complete_citation();


};


_KANS(Dynamo)

#endif
