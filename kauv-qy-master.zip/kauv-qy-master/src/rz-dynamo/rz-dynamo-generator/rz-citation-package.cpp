
#include "rz-citation-package.h"


#include <QTextStream>
#include <QDebug>
#include <QDataStream>

USING_KANS(Dynamo)

RZ_Citation_Package::RZ_Citation_Package()
{

}

void RZ_Citation_Package::add_author(QString name)
{
 RZ_Citation_Author author;
 author.set_name(name);
 authors_.push_back(author);
}

QString RZ_Citation_Author::write_compact()
{
 return name_.mid(1);
}

QString RZ_Citation_Title::write_compact()
{
 if(subtitle_.isEmpty())
 {
  return title_.mid(1);
 }
 else
 {
  return title_.mid(1) + ": " + subtitle_.mid(1);
 }
}

QString RZ_Citation_Volume::write_compact()
{
 return title_.mid(1) + ": " + subtitle_.mid(1);
}

QString RZ_Citation_Package::main_title()
{
 return title_.title();
}

QString RZ_Citation_Package::subtitle()
{
 return title_.subtitle();
}

void RZ_Citation_Package::set_main_title(QString str)
{
 title_.set_title(str);
}

void RZ_Citation_Package::set_subtitle(QString str)
{
 title_.set_subtitle(str);
}

void operator<<(QDataStream& qds, const RZ_Citation_Author& author)
{
 qds << author.name();
 qds << author.sc_name();
 qds << author.ref();
}

void operator>>(QDataStream& qds, RZ_Citation_Author& author)
{
 QString name, sc_name, ref;
 qds >> name; qds >> sc_name; qds >> ref;
 author.set_name(name);
 author.set_sc_name(sc_name);
 author.set_ref(ref);
}

void operator<<(QDataStream& qds, const RZ_Citation_Title& title)
{
 qds << title.title();
 qds << title.subtitle();
 qds << title.ref();
}

void operator>>(QDataStream& qds, RZ_Citation_Title& title)
{
 QString _title, subtitle, ref;
 qds >> _title; qds >> subtitle; qds >> ref;
 title.set_title(_title);
 title.set_subtitle(subtitle);
 title.set_ref(ref);
}


void operator<<(QDataStream& qds, const RZ_Citation_Volume& volume)
{
 //quint32 k = (quint32) volume.kind();
 qds << (quint8) volume.kind();
 qds << volume.title();
 qds << volume.subtitle();
 qds << volume.ref();
}

void operator>>(QDataStream& qds, RZ_Citation_Volume& volume)
{
 quint8 k;
 qds >> k;
 QString _title, subtitle, ref;
 qds >> _title; qds >> subtitle; qds >> ref;

 volume.set_kind( (RZ_Citation_Volume::Kind) k);

 volume.set_title(_title);
 volume.set_subtitle(subtitle);
 volume.set_ref(ref);
}


void RZ_Citation_Package::write_binary(QDataStream& qds)
{
 qds << authors_;
 qds << title_;
 qds << primary_volume_;
 qds << secondary_volume_;
 qds << url_;
 qds << local_path_;
 qds << numbers_;
 qds << date_;
}

void RZ_Citation_Package::load_from_binary(QDataStream& qds)
{
 qds >> authors_;
 qds >> title_;
 qds >> primary_volume_;
 qds >> secondary_volume_;
 qds >> url_;
 qds >> local_path_;
 qds >> numbers_;
 qds >> date_;
}


void RZ_Citation_Package::write_summary(QTextStream& outstream)
{
 for(RZ_Citation_Author& author : authors_)
 {
  outstream << "Author: " << author.write_compact();
  outstream << '\n';
 }
 outstream << "\nTitle: "  << title_.write_compact();
 if(primary_volume_)
 {
  outstream << "\nIn: "  << primary_volume_.write_compact();
  if(secondary_volume_)
  {
   outstream << "\nIn: "  << secondary_volume_.write_compact();
  }
 }
 if(!url_.isEmpty())
 {
  outstream << "\nUrl: "  << url_.mid(1);
 }
 if(!local_path_.isEmpty())
 {
  outstream << "\nLocal: "  << local_path_.mid(1);
 }
}

