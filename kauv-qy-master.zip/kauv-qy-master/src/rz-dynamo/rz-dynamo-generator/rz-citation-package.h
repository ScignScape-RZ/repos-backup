
#ifndef RZ_CITATION_PACKAGE__H
#define RZ_CITATION_PACKAGE__H


#include "accessors.h"

#include "multistep-token.h"

#include "kans.h"

#include <QString>
#include <QStringList>
#include <QStack>
#include <QPair>
#include <QDate>

class QTextStream;

KANS_(Dynamo)

class RZ_Citation_Author
{
 QString name_;
 QString sc_name_;
 QString ref_;

public:

 RZ_Citation_Author() {}

 ACCESSORS(QString ,name)
 ACCESSORS(QString ,sc_name)
 ACCESSORS(QString ,ref)

 QString write_compact();
};

class RZ_Citation_Title
{
 QString title_;
 QString subtitle_;
 QString ref_;

public:

 RZ_Citation_Title() {}

 ACCESSORS(QString ,title)
 ACCESSORS(QString ,subtitle)
 ACCESSORS(QString ,ref)

 QString write_compact();

};

class RZ_Citation_Volume
{
public:

 enum class Kind {
  N_A, Journal, Series, Anthology
 };

 QString title_;
 QString subtitle_;
 Kind kind_;
 QString ref_;

public:

 RZ_Citation_Volume(): kind_(Kind::N_A) {}

 operator bool()
 {
  return kind_ != Kind::N_A;
 }

 ACCESSORS(QString ,title)
 ACCESSORS(QString ,subtitle)
 ACCESSORS(Kind ,kind)
 ACCESSORS(QString ,ref)

 QString write_compact();

};



class RZ_Citation_Package
{
 QList<RZ_Citation_Author> authors_;
 RZ_Citation_Title title_;
 RZ_Citation_Volume primary_volume_;
 RZ_Citation_Volume secondary_volume_;
 QString url_;
 QString local_path_;

 QStringList numbers_;

 QDate date_;



public:


 RZ_Citation_Package();

 ACCESSORS__RGET(QList<RZ_Citation_Author> ,authors)
 ACCESSORS__RGET(RZ_Citation_Title ,title)
 ACCESSORS__RGET(RZ_Citation_Volume ,primary_volume)
 ACCESSORS__RGET(RZ_Citation_Volume ,secondary_volume)

 ACCESSORS__RGET(QStringList ,numbers)

 ACCESSORS(QDate ,date)
 ACCESSORS(QString ,url)
 ACCESSORS(QString ,local_path)


 QString main_title();
 QString subtitle();

 void set_main_title(QString str);
 void set_subtitle(QString str);

 void add_author(QString name);

 void write_summary(QTextStream& outstream);

 void write_binary(QDataStream& qds);
 void load_from_binary(QDataStream& qds);

};


_KANS(Dynamo)

#endif
