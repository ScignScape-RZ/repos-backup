


#include "CmdLog/kcm-command-package/kcm-command-package.h"
#include "CmdLog/kcm-command-log/kcm-command-log.h"
#include "kauvir/kauvir-code-model/kauvir-code-model.h"

//#include "cy-mesh/cy-mesh-extensions/qlispconsole-dialog.h"
//#include "cy-mesh/cy-mesh-extensions/qlispconsole.h"

#include "kauvir/kcm-lisp-bridge/kcm-lisp-bridge.h"
#include "kauvir/kcm-lisp-bridge/kcm-lisp-embed-environment.h"
#include "kauvir/kcm-lisp-bridge/kcm-lisp-eval.h"
#include "kauvir/kcm-lisp-bridge/kcm-lisp-runtime.h"

#include "CmdLog/kcm-command-runtime/kcm-command-runtime-table.h"

#include "kcm-runtime-eval/kcm-scopes/kcm-scope-system.h"

#include "kcm-runtime-eval/basic-functions/rz-dynamo-basic-functions.h"

#include "kcm-runtime-eval/kcm-direct-eval/kcm-direct-eval.h"

#include "kcm-runtime-eval/fn-doc/fn-doc.h"
#include "kcm-runtime-eval/kcm-env/kcm-env.h"

#include <QApplication>

#include <QDebug>


USING_KANS(KCM)
USING_KANS(KCL)





//void* envv(void* kind, void* test = nullptr)
//{
// static QMap<QString, void*> hold;
// QString* k = reinterpret_cast<QString*>(kind);
// qDebug() << *k;
// if(test)
// {
//  hold[*k] = test;
// }
// return hold.value(*k);
//}

//void prs(QString str)
//{
// qDebug() << str;
//}

//void prn(int num)
//{
// qDebug() << num;
//}

//int numv(int num)
//{
// return num;
//}

//QString strv(QString str)
//{
// return str;
//}

int main(int argc, char **argv)
{
 QApplication qapp(argc, argv);

 qRegisterMetaType<KCM_Lisp_Bridge>();
 qRegisterMetaType<KCM_Lisp_Bridge*>();

 qRegisterMetaType<Fn_Doc>();
 qRegisterMetaType<Fn_Doc*>();


 KCM_Lisp_Embed_Environment env(argc, argv);
 KCM_Lisp_Eval kle(&env);

 kle.prepare_callbacks();

 KCM_Lisp_Eval::get_make_kcm_channel_bridge_fn_type(&make_kcm_channel_bridge);

 KCM_Lisp_Runtime* lisp_runtime = kle.kcm_lisp_runtime();
 KCM_Lisp_Bridge& bridge = lisp_runtime->bridge();
 Kauvir_Code_Model& kcm = bridge.kcm();

 kcm.set_direct_eval_fn(&kcm_direct_eval);
 kcm.set_make_kcm_command_package_from_channel_group_fn(&make_kcm_command_package_from_channel_group);
 kcm.set_make_kcm_command_package_fn(&make_kcm_command_package);

 Kauvir_Type_System* type_system = kcm.type_system();

 //?Kauvir_Test_Dialog* ktd = new Kauvir_Test_Dialog;
 //?kcm.create_and_register_type_object("Kauvir_Test_Dialog");
 //?kcm.create_and_register_type_object("Kauvir_Test_Dialog*");
 //?QString ktd_typename = "Kauvir_Test_Dialog";
 //?envv(&ktd_typename, ktd);

 kcm.create_and_register_type_object("Fn_Doc");
 kcm.create_and_register_type_object("Fn_Doc*");

 //kcm.

// Fn_Doc* fnd = new Fn_Doc;
// QString fnd_typename = "Fn_Doc*";
// insert_envv(&fnd_typename, fnd);

 KCM_Env* kenv = new KCM_Env(&kcm);
 QString kenv_typename = "KCM_Env*";
 insert_envv(&kenv_typename, kenv);



// kcm.create_and_register_type_object("Inventory_DB_Manager");
// kcm.create_and_register_type_object("Inventory_DB_Manager*");
// QString dbm_typename = "Inventory_DB_Manager";
// envv(&dbm_typename, dbm);

 KCM_Command_Runtime_Table table(*type_system);
 kcm.set_table(&table);

 KCM_Scope_System scopes;
 kcm.set_scope_system(&scopes);

 kcm.init_scope_system();

 kenv->set_scopes(&scopes);

 kenv->set_report_channel_group_fn([](Kauvir_Code_Model* kcm, KCM_Channel_Group* kcg)
 {
  QString qs;
  QTextStream qts(&qs);

  kcg->report(qts, *kcm, kcm->detailed_report_synax(),
    KCM_Channel::Code_Environments::Statement);

  qDebug() << qs;
  //    kenv_->kcm()->detailed_report_synax(),
  //    KCM_Channel::Code_Environments::Statement);
 });

 init_basic_functions_kci(kcm);

// KCM_Channel_Group g1;

// {
//  g1.add_lambda_carrier(
//    {kcm.get_kcm_type_by_kauvir_type_object( &type_system->type_object__str() ), nullptr},
//     QString()
//    );
//  KCM_Channel_Group* kcg = table.add_s0_declared_function("pr", g1);
//  table.add_s0_declared_function("prs", kcg, reinterpret_cast<s0_fn1_p_type>
//                              (&prs));
//  g1.clear_all();
// }

// {
//  g1.add_lambda_carrier(
//    {kcm.get_kcm_type_by_kauvir_type_object( &type_system->type_object__u32() ), nullptr},
//     QString()
//    );
//  KCM_Channel_Group* kcg = table.add_s0_declared_function("prn", g1);
//  table.add_s0_declared_function("prn", kcg, reinterpret_cast<s0_fn1_p_type>
//                              (&prn));
//  g1.clear_all();
// }

// {
//  g1.add_result_carrier(
//    {kcm.get_kcm_type_by_kauvir_type_object( &type_system->type_object__u32() ), nullptr},
//     QString()
//    );
//  g1.add_lambda_carrier(
//    {kcm.get_kcm_type_by_kauvir_type_object( &type_system->type_object__u32() ), nullptr},
//     QString()
//    );
//  KCM_Channel_Group* kcg = table.add_s0_declared_function("numv", g1);
//  table.add_s0_declared_function("numv", kcg, reinterpret_cast<s0_fn1_p_type>
//                              (&numv));
//  g1.clear_all();
// }


 kle.eval_script_file(RZ_DIR "/t1.rz.dyn.cl");

}


//{
// const KCM_Type_Object* kto = kcm.get_kcm_type_by_type_name("Inventory_DB_Manager*");
// g1.add_sigma_carrier({kto, nullptr},QString());
// KCM_Channel_Group* kcg = table.add_s1_declared_function("check_open_db",
//   g1);
// table.add_s1_declared_function("check_open_db", kcg, reinterpret_cast<_s1_fng_type>
//                             (&Inventory_DB_Manager::check_open_db));
// g1.clear_all();
//}

//{
// const KCM_Type_Object* kto = kcm.get_kcm_type_by_type_name("Inventory_DB_Manager*");
// g1.add_sigma_carrier({kto, nullptr},QString());
// kto = kcm.get_kcm_type_by_kauvir_type_object(&type_system->type_object__u32());
// g1.add_lambda_carrier({kto, nullptr},QString());
// KCM_Channel_Group* kcg = table.add_s1_declared_function("report_item_by_id",
//   g1);
// table.add_s1_declared_function("report_item_by_id", kcg, reinterpret_cast<_s1_fng_type>
//                             (&Inventory_DB_Manager::report_item_by_id));
// g1.clear_all();
//}

//{
// const KCM_Type_Object* kto = kcm.get_kcm_type_by_type_name("Inventory_DB_Manager*");
// g1.add_sigma_carrier({kto, nullptr},QString());
// kto = kcm.get_kcm_type_by_kauvir_type_object(&type_system->type_object__str());
// g1.add_lambda_carrier({kto, nullptr},QString());
// KCM_Channel_Group* kcg = table.add_s1_declared_function("report_str",
//   g1);
// table.add_s1_declared_function("report_str", kcg, reinterpret_cast<_s1_fng_type>
//                             (&Inventory_DB_Manager::report_str));
// g1.clear_all();
//}


