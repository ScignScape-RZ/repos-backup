
//           Copyright Nathaniel Christen 2018.
//  Distributed under the Boost Software License, Version 1.0.
//     (See accompanying file LICENSE_1_0.txt or copy at
//           http://www.boost.org/LICENSE_1_0.txt)


#include "kauvir-phaon/kph-command-package.h"

#include "kauvir-code-model/kauvir-code-model.h"
#include "kauvir-code-model/kcm-channel-group.h"
#include "kcm-runtime-eval/kcm-scopes/kcm-scope-system.h"


#include "PhaonLib/phaon-namespace.h"
#include "PhaonLib/phaon-class.h"
#include "PhaonLib/phaon-function.h"
#include "PhaonLib/phaon-symbol-scope.h"

#include "relae-graph/relae-graph/relae-caon-ptr.h"

#include "test-functions.h"

#include "PhaonLib/phaon-channel-group-table.h"
#include "PhaonLib/phaon-runner.h"

#include "kcm-runtime-eval/kcm-direct-eval/kcm-direct-eval.h"

#include "kauvir-runtime/kcm-command-package/kcm-command-package.h"


#include "kans.h"

USING_KANS(KCM)
USING_KANS(Phaon)
USING_KANS(PhaonLib)
USING_KANS(KCM)


int main(int argc, char* argv[])
{
 Phaon_Namespace phn("TestNS");
 Phaon_Class phc("Test_Class", &phn);

 Kauvir_Code_Model kcm;
 KCM_Scope_System scopes;
 kcm.set_scope_system(&scopes);
 kcm.init_scope_system();

 Kauvir_Type_System* type_system = kcm.type_system();
 Phaon_Channel_Group_Table table(*type_system);

 Phaon_Symbol_Scope pss;

 init_test_functions(kcm, table, pss);

 kcm.set_direct_eval_fn(&kcm_direct_eval);

 KPH_Command_Package khp;
 khp.parse_from_file( DEFAULT_KPF_FOLDER "/t1.kph" );

 KCM_Channel_Group kcg(kcm.channel_names());

 khp.init_channel_group(kcm, kcg);

 KCM_Command_Package kcp(kcg);

 kcm.direct_eval(&kcp, nullptr);

// Phaon_Runner phr;
// phr.run_by_name(pss, "test_0_ss");



 return 0;
}
