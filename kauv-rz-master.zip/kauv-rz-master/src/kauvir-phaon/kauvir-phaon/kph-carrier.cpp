

#include "kph-carrier.h"


#include <QDebug>

USING_KANS(Phaon)

KPH_Carrier::KPH_Carrier()
  :  pos_(0), expref_(0)
{

}


