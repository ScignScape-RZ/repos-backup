

#include "kph-channel.h"


#include <QDebug>

USING_KANS(Phaon)

KPH_Channel::KPH_Channel()
{

}
