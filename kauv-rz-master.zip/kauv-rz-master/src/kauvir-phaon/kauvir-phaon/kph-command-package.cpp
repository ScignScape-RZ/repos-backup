

#include "kph-command-package.h"

#include "kph-carrier.h"

#include "kauvir-code-model/kcm-channel-group.h"


#include "textio.h"

#include <QDebug>

USING_KANS(Phaon)
USING_KANS(TextIO)
USING_KANS(KCM)

KPH_Command_Package::KPH_Command_Package()
  :  fn_code_(0)
{

}


void KPH_Command_Package::init_channel_group(Kauvir_Code_Model& kcm,
  KCM_Channel_Group& kcg)
{
 kcg.init_channel_counts(channel_counts_);
 kcg.add_fuxe_carrier(fn_name_);
 for(KPH_Carrier* kpc : carriers_)
 {
  kcg.init_carrier(kcm, kpc->channel_name(), kpc->pos(),
    kpc->type_name(), kpc->value_as_ptr(), kpc->symref());
 }
}


void KPH_Command_Package::parse_from_string(const QString& qs)
{
 QStringList qsl = qs.split("\n.\n");
 parse_from_string_list(qsl);
}

void KPH_Command_Package::parse_from_file(const QString& path)
{
 QString qs = load_file(path);
 parse_from_string(qs);
}

void KPH_Command_Package::check_channel_count_maximum(QString key, int max)
{
 if(channel_counts_[key] < max)
   channel_counts_[key] = max;
}

void KPH_Command_Package::parse_from_string_list(const QStringList& qsl)
{
 QMap<int, QString> channel_names;
 int current_expression_code = 0;

 for(QString qs : qsl)
 {
  switch(qs[0].toLatin1())
  {
  case '-' : break; // comment
  case ';' : // channel name
   {
    int index = qs.indexOf(':');
    QString channel_name = qs.mid(1, index - 1);
    int code = qs.mid(index + 1).toInt();
    channel_names[code] = channel_name;
   }
   break;
  case '#' : // expression
   {
    current_expression_code = qs.mid(1).toInt();
   }
   break;
  case '@' : // type name
   {
    int index = qs.indexOf(':');
    QString type_name = qs.mid(1, index - 1);
    int index1 = qs.indexOf(':', index + 1);
    QString mode = qs.mid(index, index1 - index - 1);
    int code = qs.mid(index1 + 1).toInt();
    type_names_[code] = {type_name, mode};
   }
   break;
  case '&' : // fn name
   {
    int index = qs.indexOf(':');
    fn_code_ = qs.mid(1, index - 1).toInt();
    fn_name_ = qs.mid(index + 1);
   }
   break;
  case '+' : // pins
   {
    pins_.push_back(qs.mid(1));
   }
   break;
  default : // carrier
   {
    int index = qs.indexOf(':');
    int channel = qs.left(index).toInt();
    int index1 = qs.indexOf(':', index + 1);
    int typec = qs.mid(index + 1, index1 - index - 1).toInt();
    int index2 = qs.indexOf(':', index1 + 1);
    QString mode = qs.mid(index1 + 1, index2 - index1 - 1);
    int index3 = qs.indexOf(':', index2 + 1);
    int pos = qs.mid(index2 + 1, index3 - index2 - 1).toInt();
    int index4 = qs.indexOf(':', index3 + 1);
    QString kw = qs.mid(index4 + 1, index4 - index3 - 1);
    int index5 = qs.indexOf(':', index4 + 1);
    int expref = qs.mid(index5 + 1, index5 - index4 - 1).toInt();
    int index6 = qs.indexOf(':', index5 + 1);
    QString symref = qs.mid(index5 + 1, index6 - index5 - 1);
    QString value = qs.mid(index6 + 1);
    KPH_Carrier* kpc = new KPH_Carrier;
    kpc->set_channel_name(channel_names[channel]);
    kpc->set_carrier_mode(mode);
    kpc->set_type_name(type_names_[typec].first);
    kpc->set_type_mode(type_names_[typec].second);
    kpc->set_pos(pos);
    kpc->set_key(kw);
    kpc->set_expref(expref);
    kpc->set_symref(symref);
    kpc->set_value(value);
    check_channel_count_maximum(kpc->channel_name(), pos);
    carriers_.push_back(kpc);
   }
   break;
  }
 }
}

