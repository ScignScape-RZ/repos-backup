
//           Copyright Nathaniel Christen 2018.
//  Distributed under the Boost Software License, Version 1.0.
//     (See accompanying file LICENSE_1_0.txt or copy at
//           http://www.boost.org/LICENSE_1_0.txt)


#include "PhaonLib/phaon-namespace.h"
#include "PhaonLib/phaon-class.h"
#include "PhaonLib/phaon-function.h"
#include "PhaonLib/phaon-symbol-scope.h"

#include "relae-graph/relae-graph/relae-caon-ptr.h"


#include "kauvir-code-model/kauvir-code-model.h"
#include "kauvir-code-model/kcm-channel-group.h"

#include "kauvir-runtime/kcm-command-runtime/kcm-command-runtime-table.h"
#include "kcm-runtime-eval/kcm-scopes/kcm-scope-system.h"

#include "test-functions.h"

#include "PhaonLib/phaon-channel-group-table.h"
#include "PhaonLib/phaon-runner.h"

#include "kans.h"

#include <QDebug>

USING_KANS(KCM)

USING_KANS(PhaonLib)


void tfn()
{
 qDebug() << "TFN: Ok";
}


int main(int argc, char* argv[])
{
 Phaon_Namespace phn("TestNS");
 Phaon_Class phc("Test_Class", &phn);

 Kauvir_Code_Model kcm;
 Kauvir_Type_System* type_system = kcm.type_system();

 Phaon_Channel_Group_Table table(*type_system);

 Phaon_Symbol_Scope pss;

 KCM_Scope_System scopes;
 kcm.set_scope_system(&scopes);

 kcm.init_scope_system();

 init_test_functions(kcm, table, pss);

 Phaon_Runner phr;
 phr.run_by_name(pss, "test_s_ss");


}


// Phaon_Function phf(&tfn);

//// caon_ptr<Phaon_Base_Function> phf = pbf.as_caon_ptr();

// phf.base_run();

// QString str = "running ...";

// caon_ptr<QString> qs(&str);

// //phf.augment(qs);

// phf.descriptive_base_run();

// qDebug() << "PHC: " << phc.name();

// return 0;
//}
