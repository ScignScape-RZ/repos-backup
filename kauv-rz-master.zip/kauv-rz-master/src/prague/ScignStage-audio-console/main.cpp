
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)


#include <QApplication>
#include <QGraphicsView>

#include <QList>
#include <QDebug>

#include <QMessageBox>

#include <QMenu>

#include <QGraphicsItem>

#include <QScreen>
#include <QTimer>
#include <QTime>

#include <QImage>

#include <QApplication>
#include <QDesktopWidget>

#include <QFileDialog>

#include "ScignStage-audio/scignstage-audio-dialog.h"

#include "ScignStage-audio/xpdf-bridge.h"

#include "pri.h"

#include "prague/assessment-scores.h"
#include "prague/test-series-folder.h"
#include "prague/test-series.h"

#include "kans.h"

#include <QThread>

//#include "ScignStage-g2d/scignstage-g2d-dialog.h"
//#include "ScignStage-wsi/scignstage-wsi-dialog.h"

USING_QSNS(ScignStage)



int main(int argc, char **argv)
{
 QApplication qapp(argc, argv);

 Test_Series_Folder tsf("C:/repos/kauv-rz/ling/ijst/SubjectiveSpeechQualityMeasurement/samples");

 Test_Series ts;
 tsf.read_files(ts);

#ifdef USING_XPDF
 XPDF_Bridge xpdf_bridge(argc, argv);
 ScignStage_Audio_Dialog dlg (&xpdf_bridge, &ts, &ts);
#else
 ScignStage_Audio_Dialog dlg (nullptr, &ts, &ts);
#endif

#ifdef HIDE
 dlg.connect(&dlg, &ScignStage_WSI_Dialog::open_folder_requested,
   [&dlg]()
 {

  QString str = QFileDialog::getExistingDirectory(nullptr, "Select Image Folder",
    DEFAULT_FOLDER);

  dlg.open_folder(str);

 });


 dlg.connect(&dlg, &ScignStage_WSI_Dialog::take_screenshot_requested,
   [&dlg]()
 {
//  qDebug() << "SS";

  QScreen* screen = QGuiApplication::primaryScreen();
//   if (const QWindow* window = windowHandle())
//       screen = window->screen();
   if (!screen)
       return;

   //if (delaySpinBox->value() != 0)
   QApplication::beep();

   int target_window_id  = dlg.winId();

   QTimer::singleShot(10000, [=]
   {
    QPixmap pixmap = screen->grabWindow(target_window_id );
    QString path = ROOT_DIR "/screenshots/ScignStage-wsi.png";

    qDebug() << "Saving to path: " << path;

    QFile file(path);
    if(file.open(QIODevice::WriteOnly))
    {
     pixmap.save(&file, "PNG");
    }

   });


 });

#endif // def HIDE

 dlg.show();

 qapp.exec();

}
