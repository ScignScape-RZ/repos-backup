
//          Copyright Nathaniel Christen 2017.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)


#ifndef XPDF_BRIDGE__H
#define XPDF_BRIDGE__H

#include <QObject>

#include "qsns.h"


//QSNS_(ScignStage)
//?namespace QScign { namespace ScignStage {


class Xpdf_Component;

class XPDF_Bridge : public QObject
{
 Q_OBJECT

 Xpdf_Component* xpdf_component_;
 int argc_;
 char** argv_;

public:

 XPDF_Bridge(int argc, char** argv);

 void init();

 bool is_ready();

 void take_message(QString msg);


Q_SIGNALS:

 void xpdf_is_ready();


};

//_QSNS(ScignStage)

#endif  // XPDF_BRIDGE__H
