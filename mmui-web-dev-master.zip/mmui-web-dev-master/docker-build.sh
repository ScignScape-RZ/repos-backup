trap 'echo "# $BASH_COMMAND"' DEBUG
docker build --no-cache=true -t mmui-caf ./mmui-docker-caf
 
