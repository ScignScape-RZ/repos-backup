trap 'echo "# $BASH_COMMAND"' DEBUG 
docker push axiatropicsemantics/mmui-caf
