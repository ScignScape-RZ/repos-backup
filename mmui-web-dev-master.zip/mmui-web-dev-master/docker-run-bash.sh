trap 'echo "# $BASH_COMMAND"' DEBUG 
docker run -p 127.0.0.1:11236:1726 -it -v /ext_root/openshift-oc3/mmui/app-deploy-data:/usr/src/app-deploy-data -u root mmui-caf /bin/sh
