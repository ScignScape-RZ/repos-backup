trap 'echo "# $BASH_COMMAND"' DEBUG 
docker run -p 127.0.0.1:13138:13139 -p 127.0.0.1:1727:1727  -it -v /ext_root/openshift-oc3/mmui/app-deploy-data:/usr/src/app-deploy-data3a mmui-caf
