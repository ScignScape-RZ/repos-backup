trap 'echo "# $BASH_COMMAND"' DEBUG 
docker tag mmui-caf axiatropicsemantics/mmui-caf
