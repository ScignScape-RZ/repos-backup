
#ifndef HANDLER_BASE__H
#define HANDLER_BASE__H

#include "../accessors.h"


#include <QDebug>

////? #define nullptr 0
//#include "../eidheim/server_http.hpp"
//#include "../eidheim/server_https.hpp"

//#include <string>
//#include <memory>


#include <QString>

#include "qhttpserverrequest.hpp"
#include "qhttpserverresponse.hpp"


//typedef SimpleWeb::Server<SimpleWeb::HTTP> HttpServer;
//typedef SimpleWeb::Server<SimpleWeb::HTTPS> HttpsServer;


//namespace HttpServer
//{
// class Response;
// class Request;
//}

class Handler_Base
{
protected:

 QString file_root_;

public:

 Handler_Base();

 virtual QString operator()(
   qhttp::server::QHttpRequest* request,
         qhttp::server::QHttpResponse* response,
         const QRegularExpressionMatch& rxm, QByteArray& qba) = 0;


 ACCESSORS(QString ,file_root)

};





#endif
