 
#include "mmui-general-form-handler.h"

#include "mmui-caf-response-builder.h"

#include "data/mmui-caf-data-manager.h"

#include <QString>

#include <QRegExp>
#include <QMetaType>

//#include "../silo-types/mmui-site-contributor-form-handler.h"


//#include "~/app-root/data/qt-everywhere-opensource-src-4.6.4/include/QString"


MMUI_General_Form_Handler::MMUI_General_Form_Handler(MMUI_CAF_Response_Builder& pcrb,
  MMUI_CAF_Data_Manager& pcdm) :
  Handler_Base(), pcrb_(pcrb), pcdm_(pcdm)
{

}


//void MMUI_General_Form_Handler::operator()(std::shared_ptr<HttpsServer::Response> response, std::shared_ptr<HttpsServer::Request> request)
//{
// //? qDebug() << "Entered HTTPS handler ...";


// boost::smatch request_regex_match = request->path_match;

// MMUI_CAF_Data_Manager* pdm = request->data_manager();

// const QMultiMap<QString, QString>& form_data = request->form_data();

// QString resp;

// process(request_regex_match, pdm, form_data, resp);


// //? qDebug() << "RESP: " << resp;

// *response << "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=UTF-8; Content-Length: "
//   << resp.length() << ";\r\n\r\n" << resp.toStdString();


//}


QString MMUI_General_Form_Handler::operator()(
  qhttp::server::QHttpRequest* request,
        qhttp::server::QHttpResponse* response,
        const QRegularExpressionMatch& rxm, QByteArray& qba

//  std::shared_ptr<HttpServer::Response> response,
//  std::shared_ptr<HttpServer::Request> request

                                          )
{
 QString cap = rxm.captured("path");

 QMultiMap<QString, QString> form_data;

 pcrb_.parse_form_data(form_data, *request); //request->collectedData(), request);

 //QString q_content = QString::fromLatin1( request->collectedData() ); //.constData().

 QString result;// = q_content; //site_manager.receive_update_file(q_content);

 process(rxm,
         form_data, result);


 return result;

// *response << "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=UTF-8; Content-Length: "
//   << resp.length() << ";\r\n\r\n" << resp.toStdString();


}


//void MMUI_General_Form_Handler::process(boost::smatch& request_regex_match,
//  MMUI_CAF_Data_Manager* pdm,
//  const QMultiMap<QString, QString>& form_data, QString& response)


void MMUI_General_Form_Handler::process(const QRegularExpressionMatch& request_regex_match, //,
                                       //MMUI_CAF_Data_Manager* pdm,
             const QMultiMap<QString, QString>& form_data, QString& response)
{
 //?std::string m1 = request_regex_match.captured(1); // request_regex_match[1];

 QString qm1 = request_regex_match.captured(1);

 //QString::fromStdString(m1);


 //  convert x-y format to X_Y
 QRegExp rx ("((?:\\W+)|^)(\\w+)");
 rx.setMinimal(true);

 int s = -1;
 while((s = rx.indexIn(qm1, s+1)) >= 0)
 {
  QString r0 = rx.cap(0);
  QString r1 = rx.cap(1);
  QString r2 = rx.cap(2);

  QString r = QString(rx.cap(1).length(), '_');
  r += rx.cap(2).toUpper();
  qm1.replace(s, rx.cap(0).length(), r);
  s+= rx.cap(1).length();
 }

 qm1 += "_Form_Handler";

 if(qm1.startsWith("Ptn"))
 {
  qm1.replace(1, 2, "TN");
 }
 else
 {
  qm1.prepend("MMUI_");
 }

 int id = QMetaType::type(qm1.toLatin1());
  //?int type_id1 = QMetaType::type("MMUI_Site_Contributor_Form_Handler");

 if(id != QMetaType::UnknownType)
 {
  qDebug() << "Matched type: " << qm1 << " -- with id " << id;
  QString resp; //? = "OBJ: ";

  QString invoke_result;
  void* pv = QMetaType::create(id);

  if(pv)
  {
   //?QObject* o = qmo1->newInstance();

   //?
   QObject* o = static_cast<QObject*>(pv);

   const QMetaObject* qmo = o->metaObject();


   //?

   bool ok1 = qmo->invokeMethod(o, "absorb_form_data",
    QArgument<const QMultiMap<QString, QString>&>("const QMultiMap<QString, QString>&", form_data)
   );

   bool ok = qmo->invokeMethod(o, "get_web_response",
    Q_RETURN_ARG(QString, invoke_result),
    QArgument<MMUI_CAF_Data_Manager&>("MMUI_CAF_Data_Manager&", pcdm_));


   //? qDebug() << "Invoke Result: " << invoke_result;

  }


  resp += invoke_result;

  //? qDebug() << "resp: " << resp;

  response += resp;

  //? qDebug() << "response: " << response;


 }
}

