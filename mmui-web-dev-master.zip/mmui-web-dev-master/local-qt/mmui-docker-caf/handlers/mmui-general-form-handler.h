
#ifndef MMUI_GENERAL_FORM_HANDLER__H
#define MMUI_GENERAL_FORM_HANDLER__H

#include "handler-base.h"

class MMUI_CAF_Response_Builder;
class MMUI_CAF_Data_Manager;

class MMUI_General_Form_Handler : public Handler_Base
{

 MMUI_CAF_Response_Builder& pcrb_;
 MMUI_CAF_Data_Manager& pcdm_;


public:

 MMUI_General_Form_Handler(MMUI_CAF_Response_Builder& pcrb, MMUI_CAF_Data_Manager& pcdm);

 QString operator()(
   qhttp::server::QHttpRequest* request,
         qhttp::server::QHttpResponse* response,
         const QRegularExpressionMatch& rxm, QByteArray& qba ); //  override;

 //?void operator()(std::shared_ptr<HttpsServer::Response> response, std::shared_ptr<HttpsServer::Request> request);

 void process(const QRegularExpressionMatch& request_regex_match,
              //MMUI_CAF_Data_Manager* pdm, //, MMUI_CAF_Data_Manager* pdm,
              const QMultiMap<QString, QString>& form_data, QString& response);

};



#endif
