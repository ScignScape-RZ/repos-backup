 
//#include "qclient-query-request-handler.h"

////?#include "../http-request.h"

//#include <QString>

//#include <QMetaType>

//#ifdef OPENSHIFT_DEPLOY
// #include <iostream>
//#endif

////#include "~/app-root/data/qt-everywhere-opensource-src-4.6.4/include/QString"

//QString uc_first(QString str);


//QClient_Query_Request_Handler::QClient_Query_Request_Handler() : Handler_Base()
//{

//}

//void QClient_Query_Request_Handler::operator()(std::shared_ptr<HttpServer::Response> response,
//  std::shared_ptr<HttpServer::Request> request)
//{
// std::stringstream ss;

//  //? ss << "REQ: <br>";

// //for(std::unordered_multimap<std::string, std::string, ihash, iequal_to>::const_iterator
// // for(auto it = request->header.begin(); it != request->header.end(); ++it)
// // {
// //  ss << it->first << ": " << it->second << std::endl;
// // }

//#ifdef OPENSHIFT_DEPLOY
// QUrl qurl = request->qurl();
// QString v = uc_first(qurl.queryItemValue("silo"));

// std::cout << "v = " << v.toStdString() << std::endl;

//#else
// QUrlQuery qurl_query = request->qurl_query();
// QString v = uc_first(qurl_query.queryItemValue("silo"));
//#endif

// if(v.startsWith("MMUI"))
// {
//  v.replace(1, 2, "TN");
// }

// v += "_Request_Handler";


// QString cl = v + "*";

// int id = QMetaType::type(v.toLatin1());
// int id_with_ptr = QMetaType::type(cl.toLatin1());

// QString resp; //? = "OBJ: ";

// QString invoke_result;
//#ifdef OPENSHIFT_DEPLOY
//  void* pv = QMetaType::construct(id);
//#else
//  void* pv = QMetaType::create(id);
//#endif

// if(pv)
// {
//  QObject* o = static_cast<QObject*>(pv);

//  const QMetaObject* qmo = o->metaObject();

////  Q_ARG(Argument<QUrlQuery>("PVC_Data_Manager*", qurl_query));


//#ifdef OPENSHIFT_DEPLOY
//  bool ok = qmo->invokeMethod(o, "absorb_url_query",
//   Q_ARG(QUrl, qurl));
//#else
//  bool ok = qmo->invokeMethod(o, "absorb_url_query",
//   Q_ARG(QUrlQuery, qurl_query));
//#endif



////? QArgument<QUrlQuery*>("QUrlQuery*", &qurl_query));

////?   Q_ARG(QUrlQuery&, qurl_query));

//  bool ok1 = qmo->invokeMethod(o, "get_web_response",
//   Q_RETURN_ARG(QString, invoke_result),
//   QArgument<MMUI_CAF_Data_Manager*>("MMUI_CAF_Data_Manager*", request->data_manager()));

////  if(ok)
////  {
////   resp += "OK";
////  }
////  else
////  {
////   resp += "nOK";
////  }


// }


// resp += invoke_result;


// ss << resp.toStdString();

//  //?ss << v.toStdString();

// std::string rc = ss.str();

// QString qrc = QString::fromStdString(rc);

// *response << "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=UTF-8; Content-Length: "
//   << rc.length() << ";\r\n\r\n" << rc;

////? auto content=request->content.string();
// //request->content.string() is a convenience function for:
// //stringstream ss;
// //ss << request->content.rdbuf();
// //string content=ss.str();

////? *response << "HTTP/1.1 200 OK\r\nContent-Length: " << content.length() << "\r\n\r\n" << content;


//}

