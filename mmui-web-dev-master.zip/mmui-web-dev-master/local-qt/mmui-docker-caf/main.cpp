
#include "qhttpserver.hpp"
#include "qhttpserverconnection.hpp"
#include "qhttpserverrequest.hpp"
#include "qhttpserverresponse.hpp"

#include <QtCore/QCoreApplication>
#include <QDateTime>
#include <QLocale>

#include <QFileInfo>

#include "handlers/mmui-general-form-handler.h"

#include "data/mmui-caf-data-manager.h"

//?
#include "unixcatcher.hpp"

#include "mmui-caf-response.h"
#include "mmui-caf-response-builder.h"


#include "silo-types/mmui-site-contributor/mmui-register-site-contributor-form-handler.h"

#include "mmui-caf-site-manager/ptn-site-manager.h"

#include "qwhite/qwhite-database.h"
#include "qwhite/qwhite-column.h"
#include "qwhite/qwhite-column-set.h"



namespace {
///////////////////////////////////////////////////////////////////////////////
using namespace qhttp::server;

/** connection class for gathering incoming chunks of data from HTTP client.
 * @warning please note that the incoming request instance is the parent of
 * this QObject instance. Thus this class will be deleted automatically.
 * */
class ClientHandler : public QObject
{
public:
    explicit ClientHandler(quint64 id, QHttpRequest* req, QHttpResponse* res,
      MMUI_CAF_Response_Builder& response_builder)
        : QObject(req /* as parent*/), iconnectionId(id),
          response_builder_(response_builder)
 {

        qDebug("connection #%llu ..." , id);

        // automatically collect http body(data) upto 1KB
        //?
        //?req->collectData(1024);
        //?
        req->collectData(8*1024*1024);

//        req->onData([](QByteArray qba)
//        {
//         qDebug() << "QBA: " << qba;
//        });

        // when all the incoming data are gathered, send some response to client.
        req->onEnd([this, req, res]() {

            qDebug("  connection (#%llu): request from %s:%d\n  method: %s url: %s",
                   iconnectionId,
                   req->remoteAddress().toUtf8().constData(),
                   req->remotePort(),
                   qhttp::Stringify::toString(req->method()),
                   qPrintable(req->url().toString())
                   );

            if ( req->collectedData().size() > 0 )
                qDebug("  body (#%llu): %s",
                        iconnectionId,
                        req->collectedData().constData()
                        );

            MMUI_CAF_Response pcr(response_builder_);

            //?res->end(message());

            QByteArray qba;
            QString message = pcr.get_response(req, res, qba);
//                QString("Hello World\n  packet count = %1\n  time = %2\n")
//                .arg(iconnectionId)
//                .arg(QLocale::c().toString(QDateTime::currentDateTime(),
//                                           "yyyy-MM-dd hh:mm:ss")
//                );

            if(qba.isEmpty())
            {
             res->setStatusCode(qhttp::ESTATUS_OK);
             res->addHeaderValue("content-length", message.size());
             res->end(message.toUtf8());
            }
            else
            {
             res->setStatusCode(qhttp::ESTATUS_OK);
             res->addHeaderValue("content-length", qba.size());
             res->addHeaderValue("content-type", message);
             res->end(qba);
            }

            if ( req->headers().keyHasValue("command", "quit") ) {
                qDebug("\n\na quit has been requested!\n");
                QCoreApplication::instance()->quit();
            }
        });
    }

    virtual ~ClientHandler() {
//        qDebug("  ~ClientHandler(#%llu): I've being called automatically!",
//                iconnectionId
//                );
    }

protected:
    quint64    iconnectionId;
    MMUI_CAF_Response_Builder& response_builder_;
};

///////////////////////////////////////////////////////////////////////////////
} // namespace anon
///////////////////////////////////////////////////////////////////////////////

int main(int argc, char ** argv)
{
    QCoreApplication app(argc, argv);

#if defined(Q_OS_UNIX)
    catchUnixSignals({SIGQUIT, SIGINT, SIGTERM, SIGHUP});
#endif

    qRegisterMetaType<MMUI_Register_Site_Contributor_Form_Handler>();
    qRegisterMetaType<MMUI_Register_Site_Contributor_Form_Handler*>();



    QWhite_Database* qwdb = nullptr; // = new QWhite_Database

//    QWhite_Database qwdb("100", LOCAL__MMUI_CAF_DATA_BASE_PATH "/whitedb/databases/test/test-100.wdb");
//    qwdb.create();



    // dumb (trivial) connection counter
    quint64 iconnectionCounter = 0;

    QString portOrUnixSocket("13139"); // default: TCP port 13139

//    if ( argc > 1 )
//        portOrUnixSocket = argv[1];

    QHttpServer server(&app);

    MMUI_CAF_Response_Builder pcrb;
    RZ::RZSite::PTN_Site_Manager site_manager;

    if(argc > 1)
    {
     qDebug() << "Setting Web Root Path: /usr/src/app-deploy-root/web/mmui/public";

     site_manager.set_web_root_path(DOCKER__MMUI_CAF_WEB_ROOT_PATH);
     site_manager.set_data_root_path(DOCKER__MMUI_CAF_DATA_ROOT_PATH);


     //server.set_web_root_path("/usr/src/app-deploy-root/web/mmui/public");

     pcrb.set_data_base_path(DOCKER__MMUI_CAF_DATA_BASE_PATH);
     pcrb.set_web_base_path(DOCKER__MMUI_CAF_WEB_BASE_PATH);
     pcrb.set_partials_base_path(DOCKER__MMUI_CAF_PARTIALS_BASE_PATH);
     pcrb.set_pics_base_path(DOCKER__MMUI_CAF_PICS_BASE_PATH);
     pcrb.set_css_base_path(DOCKER__MMUI_CAF_CSS_BASE_PATH);
     pcrb.set_khif_base_path(DOCKER__MMUI_CAF_KHIF_BASE_PATH);
     pcrb.set_ngml_base_path(DOCKER__MMUI_CAF_NGML_BASE_PATH);
     pcrb.set_pdf_base_path(DOCKER__MMUI_CAF_PDF_BASE_PATH);

     QString crt_file;
     QString key_file;

     QString volume = "/usr/src/persistent-deploy-volume";
     QFile file(volume);
     if(file.exists())
     {
      //site_manager.set_data_base_path(volume);
      pcrb.set_data_base_path(volume);
      crt_file = "/usr/src/app-deploy-root/ssl-keys/server.crt";
      key_file = "/usr/src/app-deploy-root/ssl-keys/server.key";
     }
     else
     {//?
   #ifdef ARUKAS_DEPLOY
      QString drp = "/usr/src/app-deploy-root/app/data/deploy";
      qDebug() << "Setting data root path: " << drp;
      server.set_data_root_path(drp.toStdString());

      site_manager.set_data_root_path(drp);


   #else
      pcrb.set_data_base_path("/usr/src/app-deploy-data");

      //?site_manager.set_data_base_path("/usr/src/app-deploy-data");
   #endif
      qDebug() << "Setting crt and key files: " << "/usr/src/app-deploy-root/ssl-keys/server.crt"
               << " " << "/usr/src/app-deploy-root/ssl-keys/server.key";
      crt_file = "/usr/src/app-deploy-root/ssl-keys/server.crt";
      key_file = "/usr/src/app-deploy-root/ssl-keys/server.key";
     }
    }
    else
    {
     site_manager.set_web_root_path(LOCAL__MMUI_CAF_WEB_ROOT_PATH);
     site_manager.set_data_root_path(LOCAL__MMUI_CAF_DATA_ROOT_PATH);

     pcrb.set_data_base_path(LOCAL__MMUI_CAF_DATA_BASE_PATH);
     pcrb.set_web_base_path(LOCAL__MMUI_CAF_WEB_BASE_PATH);
     pcrb.set_partials_base_path(LOCAL__MMUI_CAF_PARTIALS_BASE_PATH);
     pcrb.set_pics_base_path(LOCAL__MMUI_CAF_PICS_BASE_PATH);
     pcrb.set_css_base_path(LOCAL__MMUI_CAF_CSS_BASE_PATH);
     pcrb.set_khif_base_path(LOCAL__MMUI_CAF_KHIF_BASE_PATH);
     pcrb.set_ngml_base_path(LOCAL__MMUI_CAF_NGML_BASE_PATH);
     pcrb.set_pdf_base_path(LOCAL__MMUI_CAF_PDF_BASE_PATH);
    }


//    pcrb["/test"]["GET"] =  [&pcrb](QHttpRequest* request,
//      QHttpResponse* response,
//      const QRegularExpressionMatch& rxm)
//    {
//     return "HTTP/1.1 200 OK\r\nContent-Type: text/html; "
//      "charset=UTF-8; Content-Length: 2"
//      "\r\n\r\nOK";
//    };

    MMUI_CAF_Data_Manager pcdm;

    MMUI_General_Form_Handler general_form_handler(pcrb, pcdm);

    //QWhite_Database*
//?
//    qwdb = new QWhite_Database(
//     "13139", LOCAL__MMUI_CAF_DATA_BASE_PATH "/whitedb/databases/test/test-13139.wdb"
//    );
//    pcdm.init_database(qwdb);


    pcrb["/form/(?<path>[\\w./-]*)"]["POST"] = general_form_handler;

//      [&pcrb](QHttpRequest* request,
//      QHttpResponse* response,
//      const QRegularExpressionMatch& rxm, QByteArray& qba)
//    {
//     QString cap = rxm.captured("path");

//     QMultiMap<QString, QString> form_data;

//     pcrb.parse_form_data(form_data, *request); //request->collectedData(), request);

//     //QString q_content = QString::fromLatin1( request->collectedData() ); //.constData().

//     QString result;// = q_content; //site_manager.receive_update_file(q_content);
//     //result.prepend("Update Result: ");
//     return result;
//    };


    pcrb["^/up__check-database/(?<which>[\\w.-]+)$"]["GET"] = [&site_manager, qwdb](QHttpRequest* request,
              QHttpResponse* response,
              const QRegularExpressionMatch& rxm, QByteArray& qba)
    {
     //QString q_content = QString::fromLatin1( request->collectedData() ); //.constData().
     //QString resp = site_manager.receive_create_file(q_content);

     QString cap = rxm.captured("which");
     QString result;

     if(cap == "create")
     {
      QWhite_Database* qwdb = new QWhite_Database(
       "13139", LOCAL__MMUI_CAF_DATA_BASE_PATH "/whitedb/databases/test/test-13139.wdb"
      );
      qwdb->create();
      result = "Created.";
     }
     else if(qwdb)
     {
      result = qwdb->check_data(cap);
     }
     else
     {
      result = "Null Database.";
     }
     result.prepend("Update Result: ");
     return result;
    };



    pcrb["\\A/\\Z"]["GET"] = [&pcrb](QHttpRequest* request,
      QHttpResponse* response,
      const QRegularExpressionMatch& rxm, QByteArray& qba)
    {
     QString path = pcrb.resolve_web_path("index.html");
     return pcrb.read_file(path);
    };

    pcrb["/web/(?<path>[\\w./-]*)"]["GET"] = [&pcrb](QHttpRequest* request,
      QHttpResponse* response,
      const QRegularExpressionMatch& rxm, QByteArray& qba)
    {
     QString cap = rxm.captured("path");

     if(cap.endsWith("-r"))
     {
      QString which_link = request->url().toString();
      if(which_link.endsWith('='))
      {
       int i = which_link.indexOf('?');
       QString wl = which_link.mid(i + 1, which_link.size() - i - 2);
       //which_link.chop(1);
       cap.replace(cap.size() - 2, 2, wl);
      }
     }
     else if(cap.isEmpty())
     {
      cap = "index.html";
     }
     QString path = pcrb.resolve_web_path(cap);

     if(path.endsWith('?'))
     {
      path.chop(1);
     }

     QString complete_partials_result;

     if(path.endsWith(".html"))
     {
      QString temp_path = pcrb.complete_partials(complete_partials_result, path, pcrb.partials_base_path());
      if(!temp_path.isEmpty())
      {
       path = temp_path;
      }
     }

     QString result;

     if(!complete_partials_result.isEmpty())
     {
      result = complete_partials_result;
     }
     else
     {
      result = pcrb.read_file(path);
     }
     return result;
    };

    pcrb["/(?<rcode>\\w+)__(?<group>\\w+)/(?<path>[\\w./-]*)"]["GET"] = [&pcrb](QHttpRequest* request,
      QHttpResponse* response,
      const QRegularExpressionMatch& rxm, QByteArray& qba)
    {
     QString rcap = rxm.captured("rcode");
     QString gcap = rxm.captured("group");
     QString cap = rxm.captured("path");

     QString suffix;

     QString path = pcrb.resolve_path(gcap, cap, suffix);

     QString code;
     if(pcrb.get_content_type(rcap, code))
     {
      pcrb.read_binary_file(path, qba);
      return code;
     }
     else
     {
      return pcrb.read_file(path);
     }
    };


    pcrb["/(?<group>\\w+)/(?<path>[\\w./-]*)"]["GET"] = [&pcrb](QHttpRequest* request,
      QHttpResponse* response,
      const QRegularExpressionMatch& rxm, QByteArray& qba)
    {
     QString gcap = rxm.captured("group");
     QString cap = rxm.captured("path");

     QString suffix;

     QString path = pcrb.resolve_path(gcap, cap, suffix);

     if(!suffix.isEmpty())
     {
      gcap = suffix;
     }

     QString code;

     if(pcrb.get_content_type(gcap, code))
     {
      //qDebug() << "Binary: gcap= " << gcap << " code= " << code << " path= " << path;

      pcrb.read_binary_file(path, qba);
      return code;
     }
     else
     {
      return pcrb.read_file(path);
     }
    };



    pcrb["/ok(?<num>\\d+)"]["GET"] = [](QHttpRequest* request,
      QHttpResponse* response,
      const QRegularExpressionMatch& rxm, QByteArray& qba)
    {
     QString aa = rxm.captured("num");
     return QString(R"__(
      <b><i>OK ... %1</i></b>
      )__").arg(aa);
    };

    pcrb["^/up__edit$"]["POST"] = [&site_manager](QHttpRequest* request,
            QHttpResponse* response,
            const QRegularExpressionMatch& rxm, QByteArray& qba)
    {
     QString q_content = QString::fromLatin1( request->collectedData() ); //.constData().

     if(q_content.isEmpty())
     {
      QString resp = "No post body sent.  Aborted.";
      return resp;
     }

     QString resp = site_manager.receive_update_file(q_content);
     resp.prepend("Update Result: ");
     return resp;
    };

    pcrb["^/up__check-test$"]["POST"] = [&site_manager](QHttpRequest* request,
            QHttpResponse* response,
            const QRegularExpressionMatch& rxm, QByteArray& qba)
    {
     QString q_content = QString::fromLatin1( request->collectedData() ); //.constData().

     //QString resp = site_manager.receive_update_file(q_content);
     q_content.prepend("Check Test Result: ");
     return q_content;
    };


    pcrb["^/up__create$"]["POST"]=[&site_manager](QHttpRequest* request,
              QHttpResponse* response,
              const QRegularExpressionMatch& rxm, QByteArray& qba)
    {
     //Retrieve string:
     QString q_content = QString::fromLatin1( request->collectedData() ); //.constData().

     QString resp = site_manager.receive_create_file(q_content);

     // QString q_content = QString::fromStdString(request->content.string());
     resp.prepend("Update Result: ");
     //request->content.string() is a convenience function for:
     return resp; //*response << "HTTP/1.1 200 OK\r\nContent-Length: " << resp.length() << "\r\n\r\n" << resp.toStdString();
    };

    pcrb["^/up__create-folder$"]["POST"]=[&site_manager](QHttpRequest* request,
                QHttpResponse* response,
                const QRegularExpressionMatch& rxm, QByteArray& qba)
    {
     //Retrieve string:
     QString q_content = QString::fromLatin1( request->collectedData() ); //.constData().

     QString resp = site_manager.receive_create_folder(q_content);

     // QString q_content = QString::fromStdString(request->content.string());
     resp.prepend("Update Result: ");
     //request->content.string() is a convenience function for:
     return resp; //*response << "HTTP/1.1 200 OK\r\nContent-Length: " << resp.length() << "\r\n\r\n" << resp.toStdString();
    };


    pcrb["^/up__get-file-last-modified$"]["POST"]=[&site_manager](QHttpRequest* request,
                  QHttpResponse* response,
                  const QRegularExpressionMatch& rxm, QByteArray& qba)
    {
     //Retrieve string:
     QString q_content = QString::fromLatin1( request->collectedData() ); //.constData().

     QString resp = site_manager.receive_get_file_last_modified(q_content);

     return resp; //*response << "HTTP/1.1 200 OK\r\nContent-Length: " << resp.length() << "\r\n\r\n" << resp.toStdString();
    };


    pcrb["^/up__get-encoded-folder-contents$"]["POST"]=[&site_manager](QHttpRequest* request,
                    QHttpResponse* response,
                    const QRegularExpressionMatch& rxm, QByteArray& qba)
    {
     //Retrieve string:
     QString q_content = QString::fromLatin1( request->collectedData() ); //.constData().

     QString resp = site_manager.receive_get_folder_contents(q_content);

     return resp; //*response << "HTTP/1.1 200 OK\r\nContent-Length: " << resp.length() << "\r\n\r\n" << resp.toStdString();
    };





//?
//    pcrb.set_html_base_path(MMUI_HTML_BASE_PATH);
//    pcrb.set_raw_base_path(MMUI_RAW_BASE_PATH);
//    pcrb.set_text_base_path(MMUI_TEXT_BASE_PATH);
//    pcrb.set_ngml_base_path(MMUI_NGML_BASE_PATH);
//    pcrb.set_khif_base_path(MMUI_KHIF_BASE_PATH);

    qDebug() << "As of: " << QDateTime::currentDateTime().toString();
    qDebug() << "Listening on port: " <<  portOrUnixSocket;


    server.listen(portOrUnixSocket, [&](QHttpRequest* req, QHttpResponse* res){
        new ClientHandler(++iconnectionCounter, req, res, pcrb);
        // this ClientHandler object will be deleted automatically when:
        // socket disconnects (automatically after data has been sent to the client)
        //     -> QHttpConnection destroys
        //         -> QHttpRequest destroys -> ClientHandler destroys
        //         -> QHttpResponse destroys
        // all by parent-child model of QObject.
    });

    if ( !server.isListening() ) {
        fprintf(stderr, "can not listen on %s!\n", qPrintable(portOrUnixSocket));
        return -1;
    }

    app.exec();
}

