
#include "mmui-caf-request-parser.h"


string_list split(const std::string & s, const std::string & delim,
                  bool keep_empty)
{
 string_list result;
 std::string::const_iterator substart = s.begin(), subend = substart;
 while (true)
 {
  subend = std::search(substart, s.end(), delim.begin(), delim.end());
  std::string temp(substart, subend);
  if (keep_empty || !temp.empty())
  {
   result.push_back(temp);
  }
  if (subend == s.end())
  {
   break;
  }
  substart = subend + delim.size();
 }
 return result;
}

void map_pairs(const std::string& s, const std::string& elemDelim,
               const std::string& pairDelim, QMultiMap<QString, QString>& result)
{
 using namespace map_pairs_helper;

 int sl = s.length();

 QString qs = QString::fromStdString(s);

 string_list words;
 words = split(s, elemDelim, false);
 std::for_each(words.begin(), words.end(),
               ParsePairsFunc(pairDelim, result));
}

namespace ParseWebData {
namespace ParseMultipartFormData {

void sanitize_parts(string_list& parts)
{
 string_list::iterator iter = parts.begin();
 while (iter != parts.end()) {

  QString p = QString::fromStdString(*iter);

  if ((*iter).find("--\r\n") == 0) { // If part starts with --\r\n - it is last boundary. remove
   iter = parts.erase(iter);
   continue;
  }

  if ((*iter).find("\r\n") == 0) { // Due to split command all parts starts with empty line. Remove it
   (*iter).erase(0, 2);
  }
  if ((*iter).rfind("\r\n") == (*iter).length() - 2) { // Due to split command all parts ends with CRLF. Remove it
   (*iter).erase((*iter).rfind("\r\n"), 2);
  }
  ++iter;
 }
}

} }

