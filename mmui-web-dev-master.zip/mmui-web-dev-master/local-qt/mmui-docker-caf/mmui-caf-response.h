
#ifndef MMUI_CAF_RESPONSE__H
#define MMUI_CAF_RESPONSE__H

#include <QString>


#include "qhttpserverrequest.hpp"
#include "qhttpserverresponse.hpp"


//?class QHttpRequest;

class MMUI_CAF_Response_Builder;

class MMUI_CAF_Response
{
 QString text_;

 const MMUI_CAF_Response_Builder& response_builder_;

public:

 MMUI_CAF_Response(const MMUI_CAF_Response_Builder& response_builder);

 QString get_response(qhttp::server::QHttpRequest* request,
   qhttp::server::QHttpResponse* response, QByteArray& qba);

};


#endif
