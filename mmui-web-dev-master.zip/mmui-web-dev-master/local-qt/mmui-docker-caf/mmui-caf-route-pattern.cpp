
#include "mmui-caf-route-pattern.h"

MMUI_CAF_Route_Pattern::MMUI_CAF_Route_Pattern(QRegularExpression regex,
  QString m, Function_type f)
  : rx(regex), method(m), fn(f)
{

}
