
#ifndef MMUI_CAF_ROUTE_PATTERN__H
#define MMUI_CAF_ROUTE_PATTERN__H

#include <QString>


#include "qhttpserverrequest.hpp"
#include "qhttpserverresponse.hpp"

#include <QRegularExpression>

#include <functional>

#include <accessors.h>

struct MMUI_CAF_Route_Pattern
{
 typedef std::function<QString (qhttp::server::QHttpRequest* request,
   qhttp::server::QHttpResponse* response,
   const QRegularExpressionMatch& rxm, QByteArray& qba)> Function_type;

 QRegularExpression rx;
 QString method;
 Function_type fn;

 QString rx_debug;

 MMUI_CAF_Route_Pattern(QRegularExpression regex,
   QString m, Function_type f);


};


#endif
