
#include "mmui-register-site-contributor-form-handler.h"
#include "mmui-site-contributor.h"
#include "mmui-site-contributor-silo.h"

#include <QDebug>

//?
#include "data/mmui-caf-data-manager.h"

#ifdef OPENSHIFT_DEPLOY
#define nullptr 0
#endif

MMUI_Register_Site_Contributor_Form_Handler::MMUI_Register_Site_Contributor_Form_Handler(QMultiMap<QString, QString>& fields) : silo_(nullptr)
{
 absorb_form_data(fields);
 //?message_ = fields.value("message");
}

void MMUI_Register_Site_Contributor_Form_Handler::absorb_form_data(const QMultiMap<QString, QString>& fields)
{
 //?
 //? qDebug() << "New suggestion: " << fields;


 record_.set_full_name(fields.value("contributor-full-name"));
 record_.set_username(fields.value("contributor-username"));
 record_.set_password(fields.value("contributor-password"));

 //?record_.set_recommendation_link(fields.value("recommendation-link"));

 //?QStringList qsl = fields.values("summary-flag");
 //?record_.absorb_flags(qsl);

 //?ukey_ = MMUI_Site_Contributor_Silo::make_ukey(sender_email_, contact_name_);



 //return message_.replace("\n", "<br>");
}

QString MMUI_Register_Site_Contributor_Form_Handler::get_web_response(MMUI_CAF_Data_Manager& data_manager)
{
 QString result;

 //?
 //? qDebug() << "get_web_response";


 silo_ = data_manager.MMUI_Site_Contributor_silo();

 int record_uid = silo_->new_uid();

 MMUI_Site_Contributor* pscr = silo_->confirm_joinee_from_record(record_, record_uid);

 if(pscr)
 {
  QWhite_Database* qwdb = data_manager.qwhite_db();
  QWhite_Column_Set qwcs(*qwdb);
  QByteArray qba;
  record_.supply_data(qba, qwcs);
  quint32 record_index;
  qwdb->add_record("@Patient", "Default@Patient", qba, record_index);
 }


#ifdef HIDE

 int record_uid = silo_->new_uid();

 MMUI_Site_Contributor* pscr = silo_->confirm_joinee_from_record(record_, record_uid);

 QString result;

 if(pscr)
 {
  //? qDebug() << "Contact ok";


  int call_result_1 = data_manager.check_save_silo_record_count(*silo_);
  if(call_result_1 == QUnQLite_Callback_Parser::All_Ok
     || call_result_1 == QUnQLite_Callback_Parser::All_Up_To_Date)
  {
   int call_result_2 = data_manager.save_new_silo_joinee(*silo_, *pscr, record_);
   if(call_result_2 == QUnQLite_Callback_Parser::All_Ok)
   {
    result = QString("<html><head></head><body>"
     "\n<br><br>Thanks for submitting your suggestion.  To review: "
     "\n<a style='position:relative;top:-1em;margin-left:5em;font-size:10pt' href='/'>HOME</a>"
     "\n <ul><li>Recommendation: %1</li>"
     "\n     <li>Message: %2</li>"
     "\n     <li>Description: %3</li>"
     "\n     <li>Quick Summary: %4</li>"

     "\n </ul></body></html>"
    )
      .arg(record_.full_name())
      .arg(record_.username())
      .arg(record_.password());
   }
   else
   {
    result = "Error at save";
   }
  }
  else
  {
   result = "Error at silo update";
  }
 }
 else
 {
  result = "Error at object create";
 }
#endif
 return result;
}


MMUI_Register_Site_Contributor_Form_Handler::MMUI_Register_Site_Contributor_Form_Handler(const MMUI_Register_Site_Contributor_Form_Handler& rhs) //: QObject()
{
 record_ = rhs.record_;
}

//MMUI_Register_Site_Contributor_Form_Handler::~MMUI_Register_Site_Contributor_Form_Handler()
//{

//}
