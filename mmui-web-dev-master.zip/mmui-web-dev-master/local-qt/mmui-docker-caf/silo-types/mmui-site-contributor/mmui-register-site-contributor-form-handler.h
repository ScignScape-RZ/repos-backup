
#ifndef MMUI_REGISTER_SITE_CONTRIBUTOR_FORM_HANDLER__H
#define MMUI_REGISTER_SITE_CONTRIBUTOR_FORM_HANDLER__H

#include <QString>

#include <QMultiMap>

#include <QMetaType>

#include <QObject>

#include "accessors.h"

#include "mmui-site-contributor-record.h"


typedef QMultiMap<QString, QString> QMMap;

class MMUI_Site_Contributor_Silo;

class MMUI_CAF_Data_Manager;

class MMUI_Register_Site_Contributor_Form_Handler : public QObject
{
 Q_OBJECT

 MMUI_Site_Contributor_Record record_;

 MMUI_Site_Contributor_Silo* silo_;

 //?int uid_;

public:

 //?ACCESSORS(int ,uid)

 MMUI_Register_Site_Contributor_Form_Handler(QMultiMap<QString, QString>& fields);

 Q_INVOKABLE MMUI_Register_Site_Contributor_Form_Handler(){}


 Q_INVOKABLE void absorb_form_data(const QMultiMap<QString, QString>& fields);

 Q_INVOKABLE QString get_web_response(MMUI_CAF_Data_Manager& data_manager);

 Q_INVOKABLE MMUI_Register_Site_Contributor_Form_Handler(const MMUI_Register_Site_Contributor_Form_Handler& rhs);


};

Q_DECLARE_METATYPE(MMUI_Register_Site_Contributor_Form_Handler*)
Q_DECLARE_METATYPE(MMUI_Register_Site_Contributor_Form_Handler)


#endif
