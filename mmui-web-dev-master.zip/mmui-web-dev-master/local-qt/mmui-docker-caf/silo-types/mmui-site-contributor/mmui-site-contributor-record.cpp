
#include "mmui-site-contributor-record.h"

#include <QRegExp>

#include <QSharedPointer>
#include <QByteArray>
#include <QIODevice>
#include <QDataStream>

#include "qwhite/qwhite-column-set.h"


MMUI_Site_Contributor_Record::MMUI_Site_Contributor_Record()
 : uid_(0) //?, Flags(0)
{

}


QString MMUI_Site_Contributor_Record::quick_summary()
{
 QString result;

// if(flags.code_library)
//  result += "Code Library, ";
// if(flags.github)
//  result += "Github, ";
// if(flags.docker)
//  result += "Docker, ";
// if(flags.binary_application)
//  result += "Binary Application, ";
// if(flags.other_repository)
//  result += "Other Repository, ";
// if(flags.web_site)
//  result += "Web Site, ";
// if(flags.api)
//  result += "API, ";
// if(flags.other_data_source)
//  result += "Data Source, ";
// if(flags.online_aggregator)
//  result += "Online Aggregator, ";
// if(flags.other_publication)
//  result += "Other Publication, ";

// if(result.endsWith(", "))
//  result.chop(2);

 return result;
}


void MMUI_Site_Contributor_Record::absorb_data(QByteArray& qba, QWhite_Column_Set& columns)
{
 QDataStream qds(&qba, QIODevice::ReadOnly);

 qds >> uid_;
//? qds >> Flags;

 qds >> columns("MMUI_Site_Contributor_Record::Full_Name")(full_name_);
 qds >> columns("MMUI_Site_Contributor_Record::Username")(username_);
 qds >> columns("MMUI_Site_Contributor_Record::Password")(password_);
}

void MMUI_Site_Contributor_Record::supply_data(QByteArray& qba, QWhite_Column_Set& columns) const
{
 QDataStream qds(&qba, QIODevice::WriteOnly);

 qds << uid_;

 qds << columns["MMUI_Site_Contributor_Record::Full_Name"](full_name_);
 qds << columns["MMUI_Site_Contributor_Record::Username"](username_);
 qds << columns["MMUI_Site_Contributor_Record::Password"](password_);
}

#ifdef HIDE
void MMUI_Site_Contributor_Record::absorb_flags(const QStringList& qsl)
{
 for(QString qs : qsl)
 {
  Flags_Enum fe = parse_flags(qs);
  switch(fe)
  {
  default:
  case Flags_Enum::N_A: break;

  case Flags_Enum::Code_Library: flags.code_library = true; break;
  case Flags_Enum::Github: flags.github = true; break;
  case Flags_Enum::Docker: flags.docker = true; break;
  case Flags_Enum::Binary_Application: flags.binary_application = true; break;
  case Flags_Enum::Other_Repository: flags.other_repository = true; break;
  case Flags_Enum::Web_Site: flags.web_site = true; break;
  case Flags_Enum::Api: flags.api = true; break;
  case Flags_Enum::Other_Data_Source: flags.other_data_source = true; break;
  case Flags_Enum::Online_Aggregator: flags.online_aggregator = true; break;
  case Flags_Enum::Other_Publication: flags.other_publication = true; break;

  }

 }
}
#endif
