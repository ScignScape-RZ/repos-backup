

#ifndef MMUI_PUBLICITY_CONTACT_RECORD__H
#define MMUI_PUBLICITY_CONTACT_RECORD__H

#include <QString>
#include <QMap>

#include "accessors.h"
#include "flags.h"

class QWhite_Column_Set;


class MMUI_Site_Contributor_Record
{
// flags_(2)
//  bool code_library:1;
//  bool github:1;
//  bool docker:1;
//  bool binary_application:1;
//  bool other_repository:1;
//  bool web_site:1;
//  bool api:1;
//  bool other_data_source:1;
//  bool online_aggregator:1;
//  bool other_publication:1;
// _flags

// enum class Flags_Enum
// {
//  N_A,
//  Code_Library,
//  Github,
//  Docker,
//  Binary_Application,
//  Other_Repository,
//  Web_Site,
//  Api,
//  Other_Data_Source,
//  Online_Aggregator,
//  Other_Publication,
// };

// Flags_Enum parse_flags(QString qs)
// {
//  static QMap<QString, Flags_Enum> static_map {{
//    {"code-library" ,Flags_Enum::Code_Library},
//    {"github" ,Flags_Enum::Github},
//    {"docker", Flags_Enum::Docker},
//    {"binary", Flags_Enum::Binary_Application},
//    {"other-repository", Flags_Enum::Other_Repository},
//    {"web-site", Flags_Enum::Web_Site},
//    {"API", Flags_Enum::Api},
//    {"other-data-source", Flags_Enum::Other_Data_Source},
//    {"online-aggregator", Flags_Enum::Online_Aggregator},
//    {"other-publication", Flags_Enum::Other_Publication},
//  }};

//  return static_map.value(qs, Flags_Enum::N_A);
// }


 int uid_;

 QString full_name_;
 QString username_;
 QString password_;

public:

 MMUI_Site_Contributor_Record();

 ACCESSORS(int ,uid)

 ACCESSORS(QString ,full_name)
 ACCESSORS(QString ,username)
 ACCESSORS(QString ,password)

// typedef FLAGS_TYPE(2) FLAGS_type;

// FLAGS_type flags_enc() const
// {
//  return Flags;
// }

 void absorb_data(QByteArray& qba, QWhite_Column_Set& columns);
 void supply_data(QByteArray& qba, QWhite_Column_Set& columns) const;

//? void absorb_flags(const QStringList& qsl);

 QString quick_summary();


};


#endif
