
#include "mmui-site-contributor-request-handler.h"
#include "mmui-site-contributor.h"
#include "mmui-site-contributor-silo.h"

#include "data/mmui-caf-data-manager.h"

#include <QDomDocument>
#include <QDomElement>

#include <QRegExp>


#ifdef OPENSHIFT_DEPLOY
#include <iostream>
#endif

#ifdef OPENSHIFT_DEPLOY
#define nullptr 0
#endif


#ifdef OPENSHIFT_DEPLOY
void MMUI_Site_Contributor_Request_Handler::absorb_url_query(QUrl qurl)
#else
void MMUI_Site_Contributor_Request_Handler::absorb_url_query(QUrlQuery qurl_query)
#endif
{
 //? action_ = uc_first(qurl_query.queryItemValue("action"));

#ifdef OPENSHIFT_DEPLOY
 action_name_ = qurl.queryItemValue("action").replace('-', '_');
 url_key_ = qurl.queryItemValue("url-key");

 std::cout << "AN: " << action_name_.toStdString() << std::endl;

#else
 action_name_ = qurl_query.queryItemValue("action").replace('-', '_');
 url_key_ = qurl_query.queryItemValue("url-key");
#endif

 fix_action();
 switch(action_)
 {
 case Actions::Get_Records:
 #ifdef OPENSHIFT_DEPLOY
  ref_number_ = qurl.queryItemValue("start").toInt();
  second_number_ = qurl.queryItemValue("end").toInt();
 #else
  ref_number_ = qurl_query.queryItemValue("start").toInt();
  second_number_ = qurl_query.queryItemValue("end").toInt();
 #endif
 default: break;
 }


}

QString uc_first(QString str)
{
 QString result = str;

 QRegExp rx ("((?:\\W+)|^)(\\w+)");
 rx.setMinimal(true);

 int s = -1;
 while((s = rx.indexIn(result, s+1)) >= 0)
 {
  QString r0 = rx.cap(0);
  QString r1 = rx.cap(1);
  QString r2 = rx.cap(2);

  QString r = QString(rx.cap(1).length(), '_');
  r += rx.cap(2).toUpper();
  result.replace(s, rx.cap(0).length(), r);
  s+= rx.cap(1).length();
 }

 return result;
}

QString MMUI_Site_Contributor_Request_Handler::get_web_response(MMUI_CAF_Data_Manager* data_manager)
{
 silo_ = data_manager->MMUI_Site_Contributor_silo();

 QString result;

 switch(action_)
 {
 case Actions::Get_Count:
  {
   QDomDocument doc("result");
   QDomElement root = doc.createElement("result");
   root.setAttribute("url-key", url_key_);
   doc.appendChild(root);

   QDomElement rc = doc.createElement("record-count");
   root.appendChild(rc);

   QDomText t = doc.createTextNode(QString::number(silo_->record_count()));
   rc.appendChild(t);

   result = doc.toString();
  }
  break;

 case Actions::Get_Records:
  {
   QDomDocument doc; //?("results");
   QDomElement root = doc.createElement("results");
   root.setAttribute("url-key", url_key_);
   doc.appendChild(root);

   for(int i = ref_number_; i <= second_number_; ++i)
   {
    MMUI_Site_Contributor_Record record;
    record.set_uid(i);
    data_manager->load_silo_joinee(*silo_, record);
    MMUI_Site_Contributor mmui;
    mmui.absorb_record(record);

    QDomElement el = doc.createElement("mmui-recommendation");
    root.appendChild(el);

    QDomElement el1 = doc.createElement("uid");
    el.appendChild(el1);
    QDomText t1 = doc.createTextNode(QString::number(mmui.uid()));
    el1.appendChild(t1);

    QDomElement el2 = doc.createElement("full-name");
    el.appendChild(el2);
    QDomText t2 = doc.createTextNode(mmui.full_name());
    el2.appendChild(t2);

    QDomElement el3 = doc.createElement("username");
    el.appendChild(el3);
    QDomText t3 = doc.createTextNode(mmui.username());
    el3.appendChild(t3);

    QDomElement el4 = doc.createElement("password");
    el.appendChild(el4);
    QDomText t4 = doc.createTextNode(mmui.password());
    el4.appendChild(t4);

//    QDomElement el5 = doc.createElement("description");
//    el.appendChild(el5);
//    QDomText t5 = doc.createTextNode(mmui.description());
//    el5.appendChild(t5);

//    QDomElement el6 = doc.createElement("flags-enc");
//    el.appendChild(el6);
//    QDomText t6 = doc.createTextNode(QString::number(mmui.Flags));
//    el6.appendChild(t6);

//    QDomElement el7 = doc.createElement("summary");
//    el.appendChild(el7);
//    QDomText t7 = doc.createTextNode(mmui.quick_summary());
//    el7.appendChild(t7);

   }
   result = doc.toString();
  }
  break;
 }
 return result;
}

//? result += QString("Sile Count: %1; type name: %2; act: %3")
//?   .arg(silo_->record_count()).arg(silo_->type_name()).arg(action_);

// int record_uid = silo_->new_uid();

// MMUI_Recommendation* contact = silo_->confirm_joinee_from_record(record_, record_uid);

// QString result;

// if(contact)
// {
//  int call_result_1 = data_manager->check_save_silo_record_count(*silo_);
//  if(call_result_1 == QUnQLite_Callback_Parser::All_Ok
//     || call_result_1 == QUnQLite_Callback_Parser::All_Up_To_Date)
//  {
//   int call_result_2 = data_manager->save_new_silo_joinee(*silo_, *contact, record_);
//   if(call_result_2 == QUnQLite_Callback_Parser::All_Ok)
//   {
//    result = QString("\n<br>Msg: %1 <br>Sem: %2 <br>CN: %3  <br>UK: %4 ")
//      .arg(record_.message()).arg(record_.referrer_email())
//      .arg(record_.potential_contact_name()).arg(record_uid);
//   }
//   else
//   {
//    result = "Error at save";
//   }
//  }
//  else
//  {
//   result = "Error at silo update";
//  }
// }
// else
// {
//  result = "Error at object create";
// }



MMUI_Site_Contributor_Request_Handler::MMUI_Site_Contributor_Request_Handler()
 : ref_number_(0), second_number_(0)
{

}

MMUI_Site_Contributor_Request_Handler::MMUI_Site_Contributor_Request_Handler(const MMUI_Site_Contributor_Request_Handler& rhs) //: QObject()
 : ref_number_(rhs.ref_number_), second_number_(rhs.second_number_), url_key_(rhs.url_key_)
{
 //? record_ = rhs.record_;
}

//MMUI_Site_Contributor_Form_Handler::~MMUI_Site_Contributor_Form_Handler()
//{

//}
