
#ifndef MMUI_Site_Contributor_REQUEST_HANDLER__H
#define MMUI_Site_Contributor_REQUEST_HANDLER__H

#include <QString>

#include <QMultiMap>
#include <QMetaType>
#include <QObject>

#ifdef OPENSHIFT_DEPLOY
#include <QUrl>
#else
#include <QUrlQuery>
#endif

#include "accessors.h"

#include "mmui-site-contributor-record.h"

QString uc_first(QString str);


typedef QMultiMap<QString, QString> QMMap;

class MMUI_Site_Contributor_Silo;

class MMUI_CAF_Data_Manager;

class MMUI_Site_Contributor_Request_Handler : public QObject
{
 Q_OBJECT

 QString url_key_;

  // /?MMUI_Site_Contributor_Record record_;

 MMUI_Site_Contributor_Silo* silo_;

 QString action_name_;

 int ref_number_;
 int second_number_;

 enum class Actions {

  N_A, Get_Count, Get_Records

 };

 Actions action_;

 Actions parse_action(QString key)
 {
 #ifdef OPENSHIFT_DEPLOY
  if(key == "get_count")
   return Actions::Get_Count;
  if(key == "get_records")
   return Actions::Get_Records;
  return Actions::N_A;

 #else
  static QMap<QString, Actions> static_map {{
   { "get_count", Actions::Get_Count },
   { "get_records", Actions::Get_Records },
  }};
  return static_map.value(key, Actions::N_A);
 #endif
 }

 void fix_action()
 {
  action_ = parse_action(action_name_);
 }

public:


//? MMUI_Site_Contributor_Request_Handler(QString url, QMultiMap<QString, QString>& fields);

 Q_INVOKABLE MMUI_Site_Contributor_Request_Handler();


 Q_INVOKABLE QString get_web_response(MMUI_CAF_Data_Manager* data_manager);

#ifdef OPENSHIFT_DEPLOY
 Q_INVOKABLE void absorb_url_query(QUrl qurl);
#else
 Q_INVOKABLE void absorb_url_query(QUrlQuery qurl_query);
#endif

 Q_INVOKABLE MMUI_Site_Contributor_Request_Handler(const MMUI_Site_Contributor_Request_Handler& rhs);


};

Q_DECLARE_METATYPE(MMUI_Site_Contributor_Request_Handler*)
Q_DECLARE_METATYPE(MMUI_Site_Contributor_Request_Handler)


#endif
