
#include "mmui-site-contributor-silo.h"

#include "mmui-site-contributor-record.h"
#include "mmui-site-contributor.h"

#include <QRegExp>

MMUI_Site_Contributor_Silo::MMUI_Site_Contributor_Silo(int record_count, int type_id, QString type_name)
 : record_count_(record_count),
   last_saved_record_count_(record_count), type_id_(type_id), type_name_(type_name)
{

}

QString MMUI_Site_Contributor_Silo::make_ukey(QString referrer_email, QString potential_contact_name)
{
 QString result = referrer_email.replace(QRegExp("\\s+"), "");
 result += "@@" + potential_contact_name.replace(QRegExp("\\s+"), "");
 return result;
}

int MMUI_Site_Contributor_Silo::new_uid()
{
 return ++record_count_;
}


int MMUI_Site_Contributor_Silo::check_save_record_count()
{
 if(last_saved_record_count_ != record_count_)
 {
  last_saved_record_count_ = record_count_;
  return record_count_;
 }
 else
 {
  return 0;
 }

}


MMUI_Site_Contributor* MMUI_Site_Contributor_Silo::confirm_joinee_from_record
 (MMUI_Site_Contributor_Record& record, int uid)
{
 record.set_uid(uid);

 MMUI_Site_Contributor* result = new MMUI_Site_Contributor;
 result->absorb_record(record);

 return result;
// if(record_count_ != last_saved_record_count_)
// {
//  save_record_count();
// }

}

