

#ifndef MMUI_PUBLICITY_CONTACT_SILO__H
#define MMUI_PUBLICITY_CONTACT_SILO__H

#include <QString>

#include "accessors.h"

class MMUI_Site_Contributor_Record;
class MMUI_Site_Contributor;
//?class PCV_Data_Manager;

class MMUI_Site_Contributor_Silo
{
 int record_count_;
 int type_id_;
 int last_saved_record_count_;

 QString type_name_;

public:

 ACCESSORS(int ,record_count)
 ACCESSORS(QString ,type_name)
 ACCESSORS(int ,type_id)

 typedef MMUI_Site_Contributor Joinee_type;

 MMUI_Site_Contributor_Silo(int record_count, int type_id, QString type_name);

 int new_uid();


 static QString make_ukey(QString referrer_email, QString potential_contact_name);

 MMUI_Site_Contributor* confirm_joinee_from_record
  (MMUI_Site_Contributor_Record& record, int uid);

 int check_save_record_count();

};


#endif
