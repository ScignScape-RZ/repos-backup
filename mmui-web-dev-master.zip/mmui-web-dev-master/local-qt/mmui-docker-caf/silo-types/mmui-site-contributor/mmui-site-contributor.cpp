
#include "mmui-site-contributor.h"

#include "mmui-site-contributor-record.h"

MMUI_Site_Contributor::MMUI_Site_Contributor() //?: Flags(0)
{

}

QString MMUI_Site_Contributor::quick_summary()
{
 QString result;

// if(flags.code_library)
//  result += "Code Library, ";
// if(flags.github)
//  result += "Github, ";
// if(flags.docker)
//  result += "Docker, ";
// if(flags.binary_application)
//  result += "Binary Application, ";
// if(flags.other_repository)
//  result += "Other Repository, ";
// if(flags.web_site)
//  result += "Web Site, ";
// if(flags.api)
//  result += "API, ";
// if(flags.other_data_source)
//  result += "Data Source, ";
// if(flags.online_aggregator)
//  result += "Online Aggregator, ";
// if(flags.other_publication)
//  result += "Other Publication, ";

// if(result.endsWith(", "))
//  result.chop(2);

 return result;
}


void MMUI_Site_Contributor::absorb_record(const MMUI_Site_Contributor_Record& record)
{
 uid_ = record.uid();
 full_name_ = record.full_name();
 username_ = record.username();
 password_ = record.password();
}
