
#ifndef MMUI_SITE_CONTRIBUTOR__H
#define MMUI_SITE_CONTRIBUTOR__H

#include <QString>

#include "accessors.h"
#include "flags.h"

class MMUI_Site_Contributor_Record;

class MMUI_Site_Contributor
{
public:

// flags_(2)
//  bool code_library:1;
//  bool github:1;
//  bool docker:1;
//  bool binary_application:1;
//  bool other_repository:1;
//  bool web_site:1;
//  bool api:1;
//  bool other_data_source:1;
//  bool online_aggregator:1;
//  bool other_publication:1;
// _flags

//private:

// //?QString ukey_;

 int uid_;

 QString full_name_;
 QString username_;
 QString password_;

public:

 MMUI_Site_Contributor();


 ACCESSORS(int ,uid)
 ACCESSORS(QString ,full_name)
 ACCESSORS(QString ,username)
 ACCESSORS(QString ,password)

 QString quick_summary();

 void absorb_record(const MMUI_Site_Contributor_Record& record);

};


#endif
