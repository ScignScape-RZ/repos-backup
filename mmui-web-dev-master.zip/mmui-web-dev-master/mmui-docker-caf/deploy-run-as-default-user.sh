trap 'echo "# $BASH_COMMAND"' DEBUG 
id
sudo -u defaultUser ./deploy-run.sh
