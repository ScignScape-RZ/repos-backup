trap 'echo "# $BASH_COMMAND"' DEBUG
id
chown -R defaultUser:users /usr/src/app-deploy-root/app/data/deploy
chown -R defaultUser:users /usr/src/app-deploy-root/web/mmui/public/
chown -R defaultUser:users /usr/src/app-deploy-root/web/mmui/partials/
chmod -R a=rwx /usr/src/app-deploy-root/app/data/deploy
sudo -u defaultUser ./deploy-run.sh
