
trap 'echo "# $BASH_COMMAND"' DEBUG 
 #?idex
export LD_LIBRARY_PATH=/ext_root/openshift-oc3/mmui/mmui-docker-image/deploy-libs:/ext_root/openshift-oc3/mmui/mmui-docker-image/deploy-libs/xcb:/ext_root/openshift-oc3/mmui/mmui-docker-image/deploy-libs/qt-5-8-0:/ext_root/openshift-oc3/mmui/mmui-docker-image/deploy-libs/qt-5-8-0/qt
/ext_root/openshift-oc3/mmui/mmui-docker-image/deploy-libs/qt-5-8-0/mmui-docker-image -m

 
