trap 'echo "# $BASH_COMMAND"' DEBUG 
 #?idex
id
export LD_LIBRARY_PATH=/usr/src/app-deploy-root/deploy-libs:/usr/src/app-deploy-root/deploy-libs/xcb:/usr/src/app-deploy-root/deploy-libs/qt-5-8-0:/usr/src/app-deploy-root/deploy-libs/qt-5-8-0/qt:$LD_LIBRARY_PATH
/usr/src/app-deploy-root/deploy-libs/qt-5-8-0/mmui-docker-caf -m

