trap 'echo "# $BASH_COMMAND"' DEBUG 
chown defaultUser:users -R /usr/src/app-deploy-data
chmod -R a=rwx /usr/src/app-deploy-data
su defaultUser
