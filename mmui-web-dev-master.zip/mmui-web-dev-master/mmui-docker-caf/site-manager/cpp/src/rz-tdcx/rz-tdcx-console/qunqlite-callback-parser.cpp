
#include "qunqlite-callback-parser.h"

#include <QDebug>
#include <QUrl>
#include <QSharedPointer>


QUnQLite_Callback_Parser::QUnQLite_Callback_Parser()
{

}

int QUnQLite_Callback_Parser::run_query(QString message, int arglength, void* data)
{
 switch( parse_query(message) )
 {
  #define TEMP_MACRO(name) \
   case name: return run_##name(message, arglength, data); break;
  #include "qunqlite-callback-parser.queries.h"
  #undef TEMP_MACRO

 default:  return 0;

 }

}


#define EXTRACT_STRING_ARGS_2(pVoid, arg1, arg2) \
 arg1 = *reinterpret_cast<QString*>( \
  reinterpret_cast<void**>(pVoid)[0]); \
 arg2 = *reinterpret_cast<QString*>( \
  reinterpret_cast<void**>(pVoid)[1]); \

#define EXTRACT_TYPED_ARGS_2__vr(pVoid, type1 ,arg1, type2 ,arg2) \
 type1 arg1 = *reinterpret_cast<type1*>( \
  reinterpret_cast<void**>(pVoid)[0]); \
 type2& arg2 = *reinterpret_cast<type2*>( \
  reinterpret_cast<void**>(pVoid)[0]); \


#define EXTRACT_TYPED_ARGS_1(pVoid, type1 ,arg1) \
 type1 arg1 = *reinterpret_cast<type1*>( \
  reinterpret_cast<void**>(pVoid)[0]); \


#define EXTRACT_TYPED_ARGS_2(pVoid, type1 ,arg1, type2, arg2) \
 type1& arg1 = *reinterpret_cast<type1*>( \
  reinterpret_cast<void**>(pVoid)[0]); \
 type2& arg2 = *reinterpret_cast<type2*>( \
  reinterpret_cast<void**>(pVoid)[1]); \


int QUnQLite_Callback_Parser::load_generic_data(void* data)
{
 EXTRACT_TYPED_ARGS_2(data, QString ,uid,
  QSharedPointer<QByteArray> ,qba)
 qunqlite_.fetch(uid, qba);
 return 0;
}


int QUnQLite_Callback_Parser::save_generic_data(void* data)
{
 EXTRACT_TYPED_ARGS_2(data, QString ,unique_id,
  //QByteArray ,qba)
  QSharedPointer<QByteArray> ,qba)
// QByteArray* test = qba.data();
 bool store_result = qunqlite_.store(unique_id, qba);

 if(store_result)
 {
  if(qunqlite_.commit())
   return 0;
  return 1;
 }
 else
  qDebug() << "Store failed";
 return 1;

}



//int QUnQLite_Callback_Parser::run_Index_Str_Str(QString message, int arglength, void* data)
//{
// EXTRACT_TYPED_ARGS_2(data, const QString ,s1, const QString ,s2)
// bool store_result = qunqlite_.store(s1, s2);

// if(store_result)
// {
//  if(qunqlite_.commit())
//   return All_Ok;
//  return Commit_Problem;
// }
// else
//  return Store_Problem;
//}


//int QUnQLite_Callback_Parser::run_Retrieve_Str_Str(QString message, int arglength, void* data)
//{
// EXTRACT_TYPED_ARGS_2(data, const QString ,s1, QString ,s2)
// bool retrieve_result = qunqlite_.fetch(s1, s2);

// if(retrieve_result)
//  return All_Ok;
// else
//  return Retrieve_Problem;
//}

//int QUnQLite_Callback_Parser::run_DB_Save_Resource(QString message, int arglength, void* data)
//{
//// EXTRACT_TYPED_ARGS_1(data, QSharedPointer<QByteArray> ,qba)
//// QByteArray* test = qba.data();

// return Not_Implemented;
//}



int QUnQLite_Callback_Parser::run_Test_Cursor(QString message, int arglength, void* data)
{
 QUnQLiteCursor* cr = qunqlite_.cursor();

// if(cr->first()) do

 if(cr->first()) do
 {
  QByteArray k = cr->key();
  QByteArray v = cr->value();
  qDebug() << "Key: " << k << "Value: " << v;
 }
 while(cr->next());
 return All_Ok;
}


int QUnQLite_Callback_Parser::run_DB_Create_Or_Open(QString message, int arglength, void* data)
{
 EXTRACT_STRING_ARGS_2(data, data_root_path_, database_file_name_)

 qDebug() << data_root_path_;
 qDebug() << database_file_name_;

 QString database_path = data_root_path_ + "/" + database_file_name_;
 if(qunqlite_.open(database_path, QUnQLite::Create))
 {
  if(qunqlite_.commit())
   return All_Ok;
 }
 return Database_Create_Problem;
}


int QUnQLite_Callback_Parser::run_DB_Store(QString message, int arglength, void* data)
{
 return save_generic_data(data);
}


int QUnQLite_Callback_Parser::run_DB_Load(QString message, int arglength, void* data)
{
 return load_generic_data(data);
}

int QUnQLite_Callback_Parser::run_DB_Create(QString message, int arglength, void* data)
{
 return Not_Implemented;
}

int QUnQLite_Callback_Parser::run_DB_Open(QString message, int arglength, void* data)
{
 return Not_Implemented;
}


//int QUnQLite_Callback_Parser::run_DB_Load_Resource(QString message, int arglength, void* data)
//{
// return Not_Implemented;
//}

//int QUnQLite_Callback_Parser::run_DB_Load_Application_State(QString message, int arglength, void* data)
//{
// return load_generic_data(data);
//}

//int QUnQLite_Callback_Parser::run_DB_Load_Application_Comment_State(QString message, int arglength, void* data)
//{
// return load_generic_data(data);
//}

//int QUnQLite_Callback_Parser::run_DB_Load_Dialog_Data(QString message, int arglength, void* data)
//{
// return load_generic_data(data);
//}

//int QUnQLite_Callback_Parser::run_DB_Load_Comment_Data(QString message, int arglength, void* data)
//{
// return load_generic_data(data);
//}

//int QUnQLite_Callback_Parser::run_DB_Load_User_Data(QString message, int arglength, void* data)
//{
// return load_generic_data(data);
//}


//int QUnQLite_Callback_Parser::run_DB_Save_Application_State(QString message, int arglength, void* data)
//{
// return save_generic_data(data);
//}

//int QUnQLite_Callback_Parser::run_DB_Save_Application_Comment_State(QString message, int arglength, void* data)
//{
// return save_generic_data(data);
//}

//int QUnQLite_Callback_Parser::run_DB_Save_Dialog_Data(QString message, int arglength, void* data)
//{
// return save_generic_data(data);
//}

//int QUnQLite_Callback_Parser::run_DB_Save_Comment_Data(QString message, int arglength, void* data)
//{
// return save_generic_data(data);
//}

//int QUnQLite_Callback_Parser::run_DB_Save_User_Data(QString message, int arglength, void* data)
//{
// return save_generic_data(data);
//}

