
#include "test-type.h"

#include <QDataStream>


Test_Type::to_exchange(QByteArray& qba) const
{
 QDataStream qds(&qba, QIODevice::WriteOnly);
 qds << (quint8) x;

// int s = qba.size();
// qba.prepend(QByteArray(2 - s, 0));

 QByteArray yba;
 QDataStream yds(&yba, QIODevice::WriteOnly);
 yds << y;
 qba.insert(1, yba.mid(1));
 qds.skipRawData(3);
 //qds.writeBytes(yba.mid(1).data(), 3);// << yba.mid(1).data();
 qds << (quint8) z;
}

Test_Type::from_exchange(const QByteArray& qba)
{
// QDataStream ds(qba);
// quint16 _x;
// ds >> _x;
// x = _x;
 x = (quint8) qba[0];

 z = qba[4];

 QByteArray yba = qba.mid(1, 3);
 yba.insert(0, (char) 0);
 yba[0] = 0;
 QDataStream yds(yba);

 yds >> y;
}

