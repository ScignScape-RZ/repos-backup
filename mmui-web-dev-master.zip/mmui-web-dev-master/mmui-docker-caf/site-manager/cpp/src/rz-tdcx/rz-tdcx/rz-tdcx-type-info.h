
#ifndef RZ_TDCX_TYPE_INFO__H
#define RZ_TDCX_TYPE_INFO__H

#include <QString>

enum class TDCX_Storage_Modes
{
 Pure_Value, Pure_Ref, Byte_Array, Mixed
};

struct TDCX_Pure_Value_Storage
{
 static TDCX_Storage_Modes get_Storage_Mode()
 {
  return TDCX_Storage_Modes::Pure_Value;
 }
};

struct TDCX_Pure_Ref_Storage
{
 static TDCX_Storage_Modes get_Storage_Mode()
 {
  return TDCX_Storage_Modes::Pure_Ref;
 }
};

struct TDCX_Byte_Array_Storage
{
 static TDCX_Storage_Modes get_Storage_Mode()
 {
  return TDCX_Storage_Modes::Byte_Array;
 }
};

struct TDCX_Mixed_Storage
{
 static TDCX_Storage_Modes get_Storage_Mode()
 {
  return TDCX_Storage_Modes::Mixed;
 }
};

template<typename T>
struct TDCX_Type_Info;


template<typename T>
QString TDCX_Get_QString_Type_Name()
{
 return TDCX_Type_Info<T>::get_QString_Type_Name();
}

template<typename T>
int TDCX_Get_Type_Code()
{
 return TDCX_Type_Info<T>::get_Type_Code();
}

template<typename T, typename DESTINATION_Type>
void TDCX_Set_Storage_Mode(DESTINATION_Type& d)
{
 d.set_storage_mode(TDCX_Type_Info<T>::get_Storage_Mode());
}

#endif
