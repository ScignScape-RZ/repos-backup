
#ifndef RZ_TDCX_TYPED_ARRAY_DOCUMENT__H
#define RZ_TDCX_TYPED_ARRAY_DOCUMENT__H

#include <cstdint>

#include "rz-tdcx-typed-array.h"

#include <QByteArray>
#include <QList>
#include <QSharedPointer>

#include "rzns.h"

#include "accessors.h"

RZNS_(TransDCX)

class TDCX_Typed_Array;
class TDCX_Storing_Profile;

class TDCX_Typed_Array_Document
{
 QList<QSharedPointer<TDCX_Typed_Array>> typed_arrays_;

 typedef std::int32_t u32;
 typedef std::int64_t u64;

public:

 TDCX_Typed_Array_Document();
 u32 add_typed_array(QSharedPointer<TDCX_Typed_Array> ta);
 void encode(const TDCX_Typed_Array& ta, QByteArray& qba);

 QString encode();
 void encode(const TDCX_Typed_Array& ta, QString& code, QQuaternion* qq = nullptr);

 QString quaternion_encode();

 struct Unused_Store_Caller
 {
  template<typename T>
  void set_current_typed_array(T& t)
  {}

  template<typename T>
  void release_current_typed_array(T& t)
  {}
 };

 template<typename T, typename CALLER_Type = Unused_Store_Caller>
 u32 store(QString key, u32 typecode, const T& t, TDCX_Storing_Profile& profile, CALLER_Type* caller = nullptr)
 {
  QSharedPointer<TDCX_Typed_Array> ta = QSharedPointer<TDCX_Typed_Array>(new TDCX_Typed_Array(profile));
  ta->init_lengths_with_typecode(typecode);
  TDCX_Set_Storage_Mode<T>(*ta);
  TDCX_Storage_Modes sm = TDCX_Type_Info<T>::get_Storage_Mode();
  switch(sm)
  {
  case TDCX_Storage_Modes::Byte_Array:
   {
    QByteArray qba;
    TDCX_To_QByteArray(t, qba, caller);
    ta->store_direct_value(qba);
    break;
   }
  case TDCX_Storage_Modes::Pure_Ref:
   {
    caller->set_current_typed_array(ta);
    QByteArray qba;
    TDCX_To_QByteArray(t, qba, caller);
    ta->store_direct_value(qba);
    caller->release_current_typed_array(ta);
    break;
   }
  }
  return add_typed_array(ta);
 }

 template<typename T, typename CALLER_Type = Unused_Store_Caller>
 u32 store(const T& t, TDCX_Storing_Profile& profile, CALLER_Type* caller = nullptr)
 {
  QString str = TDCX_Get_QString_Type_Name<T>();
  u32 typecode = TDCX_Get_Type_Code<T>();
  u32 result = store(str, typecode, t, profile, caller);
  return result;
 }

};


_RZNS(TransDCX)



#endif

