
#ifndef DOWNPULL_DATA_RECEIVER__H
#define DOWNPULL_DATA_RECEIVER__H

#include <QObject>

#include <QNetworkAccessManager>

class Downpull_Request_Manager;

class Downpull_Data_Receiver : public QObject
{
 Q_OBJECT

 Downpull_Request_Manager* drm_;

 QMap<QString, QString> url_key_by_host_;
 QMap<QString, QString> xml_text_by_host_;
 QMap<QString, int> response_count_by_host_;

 QString result_text_;
 QString report_file_;

 void check_for_completion(QString host);

public:

 Downpull_Data_Receiver(Downpull_Request_Manager* drm,
   QString report_file, QMap<QString, QString>& hosts);

 void get_xml_response(QNetworkAccessManager& qnam, QString host);

Q_SIGNALS:

 void all_records_received_and_saved();

public Q_SLOTS:

 void handle_host_count_received(QString host, int count);

 void handle_host_records_received(QString host, QString text, int count);


};


#endif

