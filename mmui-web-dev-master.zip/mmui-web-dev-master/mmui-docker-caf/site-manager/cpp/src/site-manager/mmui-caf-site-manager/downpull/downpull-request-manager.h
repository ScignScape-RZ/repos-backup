#ifndef DOWNPULL_REQUEST_MANAGER__H
#define DOWNPULL_REQUEST_MANAGER__H

#include <QObject>

#include <QNetworkAccessManager>

class Downpull_Request_Manager : public QObject
{
 Q_OBJECT

 QNetworkAccessManager* qnam_;

public:

 Downpull_Request_Manager(QNetworkAccessManager* qnam);

 void get_xml_count_response(QString host, QString url_key, QString silo);
 void get_xml_records_response(QString host, QString url_key, QString silo,
   int start, int end);


Q_SIGNALS:

 // // This may avoid issues with XML Patterns lib are resolved
  //   void host_count_xml_received(QString host, QString xml);

 void host_count_received(QString host, int count);
 void host_records_received(QString host, QString text, int count);



};


#endif
