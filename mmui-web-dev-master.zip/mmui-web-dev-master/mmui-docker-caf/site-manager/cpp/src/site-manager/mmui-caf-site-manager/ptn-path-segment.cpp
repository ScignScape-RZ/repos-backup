
#include "ptn-path-segment.h"

#include <QDataStream>

USING_RZNS(RZSite)


PTN_Path_Segment::PTN_Path_Segment(QString local_path, Segment_Roles segment_role)
 : local_path_ (local_path), segment_role_(segment_role)
{

}


//void RZ::RZSite::operator<<(QDataStream& qds, const PTN_Path_Segment& pps)
//{
// qds << (quint8) pps.segment_role();
// qds << pps.local_path();
//}

//void RZ::RZSite::operator>>(QDataStream& qds, PTN_Path_Segment& pps)
//{
// quint8 sr;
// qds >> sr;
// pps.set_segment_role( (PTN_Path_Segment::Segment_Roles) sr);
// QString lp;
// qds >> lp;
// pps.set_local_path(lp);
//}


void PTN_Path_Segment::to_qbytearray(QByteArray& qba) const
{
 QDataStream qds(&qba, QIODevice::WriteOnly);
 qds << (quint8) segment_role_;
 qds << local_path_;
}

void PTN_Path_Segment::from_qbytearray(const QByteArray& qba)
{
 QDataStream qds(qba);
 quint8 sr;
 qds >> sr;
 segment_role_ = (Segment_Roles) sr;
 qds >> local_path_;
}

QString PTN_Path_Segment::to_string(const QMap<PTN_Path_Segment::Segment_Roles, QString>& substitutions) const
{
 return local_to_string(substitutions.value(segment_role_, local_path_));
}

QString PTN_Path_Segment::local_to_string(QString path) const
{
 switch(segment_role_)
 {
 default:
 case Segment_Roles::N_A:
 case Segment_Roles::File_Generic:
  return path;

 case Segment_Roles::Web_Root:
 case Segment_Roles::Data_Root:
 case Segment_Roles::Folder_Generic:
  return path + "/";
 }
}

QString PTN_Path_Segment::local_to_string() const
{
 return local_to_string(local_path_);
}
