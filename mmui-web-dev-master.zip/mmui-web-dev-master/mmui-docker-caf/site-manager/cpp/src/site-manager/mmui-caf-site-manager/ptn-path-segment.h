
#ifndef PTN_PATH_SEGMENT__H
#define PTN_PATH_SEGMENT__H

#include <QString>

#include <QByteArray>
#include <QMap>

#include <QDataStream>

#include "rzns.h"
#include "accessors.h"

RZNS_(RZSite)


class PTN_Path_Segment
{
public:

 enum class Segment_Roles {

  N_A, Web_Root, Data_Root, Folder_Generic, File_Generic

 };

private:

 Segment_Roles segment_role_;
 QString local_path_;

public:

 ACCESSORS(QString ,local_path)
 ACCESSORS(Segment_Roles ,segment_role)

 PTN_Path_Segment(QString local_path = QString(), Segment_Roles segment_role = Segment_Roles::N_A);

 QString local_to_string() const;
 QString to_string(const QMap<PTN_Path_Segment::Segment_Roles, QString>& substitutions) const;

 QString local_to_string(QString path) const;

 void to_qbytearray(QByteArray& qba) const;
 void from_qbytearray(const QByteArray& qba);

 friend void operator<<(QDataStream& qds, PTN_Path_Segment& pps)
 {
  qds << (quint8) pps.segment_role();
  qds << pps.local_path();
 }

 friend void operator>>(QDataStream& qds, PTN_Path_Segment& pps)
 {
  quint8 sr;
  qds >> sr;
  pps.set_segment_role( (PTN_Path_Segment::Segment_Roles) sr);
  QString lp;
  qds >> lp;
  pps.set_local_path(lp);
 }


};


_RZNS(RZSite)


#endif
