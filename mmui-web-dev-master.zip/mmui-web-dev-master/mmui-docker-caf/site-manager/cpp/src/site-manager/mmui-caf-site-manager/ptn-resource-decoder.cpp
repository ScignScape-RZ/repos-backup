
#include "ptn-resource-decoder.h"

#include "rzns.h"

USING_RZNS(RZSite)

PTN_Resource_Decoder::PTN_Resource_Decoder()
{


}

//void PTN_Resource_Encoder::do_encode(QString &result)
//{
// tad.store(pfr, profile);
// QString encode = tad.encode();
//}
