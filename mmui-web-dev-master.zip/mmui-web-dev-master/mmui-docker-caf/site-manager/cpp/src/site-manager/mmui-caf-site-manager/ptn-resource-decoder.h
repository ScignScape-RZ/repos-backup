
#ifndef PTN_RESOURCE_DECODER__H
#define PTN_RESOURCE_DECODER__H

#include <QString>

#include "rzns.h"

#include "accessors.h"

#include "rz-tdcx/rz-tdcx/rz-tdcx-typed-array.h"
#include "rz-tdcx/rz-tdcx/rz-tdcx-typed-array-document.h"
#include "rz-tdcx/rz-tdcx/rz-tdcx-typed-array-decoder.h"

RZNS_(RZSite)


class PTN_Resource_Decoder
{

 TDCX_Storing_Profile profile_;
 TDCX_Typed_Array_Document tad_;

public:

 PTN_Resource_Decoder();

 template<typename T>
 QSharedPointer<T> do_decode(const QString& code)
 {
  TDCX_Typed_Array_Decoder dcr(code);

  dcr.decode();

  QVector<QSharedPointer<T>> values;
  dcr.reload(values);

  if(values.isEmpty())
  {
   return QSharedPointer<T>(nullptr);
  }
  return values[0];

 }

};


_RZNS(RZSite)


#endif
