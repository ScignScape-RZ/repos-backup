
#include "ptn-resource-encoder.h"

#include "rzns.h"

USING_RZNS(RZSite)

PTN_Resource_Encoder::PTN_Resource_Encoder()
{


}

//void PTN_Resource_Encoder::do_encode(QString &result)
//{
// tad.store(pfr, profile);
// QString encode = tad.encode();
//}
