
#ifndef PTN_SITE_CONTRIBUTOR__H
#define PTN_SITE_CONTRIBUTOR__H

#include <QString>

#include <QNetworkAccessManager>

#include "rzns.h"

#include "accessors.h"

#include <functional>

RZNS_(RZSite)


class PTN_Site_Contributor
{
 QString full_name_;
 QString user_name_;
 QString password_;


public:

 PTN_Site_Contributor();

 ACCESSORS(QString ,full_name)
 ACCESSORS(QString ,user_name)
 ACCESSORS(QString ,password)

};


_RZNS(RZSite)


#endif
