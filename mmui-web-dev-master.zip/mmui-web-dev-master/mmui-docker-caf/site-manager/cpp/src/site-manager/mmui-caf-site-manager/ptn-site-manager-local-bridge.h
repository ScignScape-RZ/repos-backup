
#ifndef PTN_SITE_MANAGER_LOCAL_BRIDGE__H
#define PTN_SITE_MANAGER_LOCAL_BRIDGE__H

#include <QString>

#include <QNetworkAccessManager>

#include "ptn-path-resource.h"

#include "ptn-site-request.h"

#include "rzns.h"

#include "accessors.h"

#include <functional>

RZNS_(RZSite)

class PTN_Path_Resource;
class PTN_Folder_Resource;
class PTN_Site_Request;

class PTN_Site_Manager_Local_Bridge
{
protected:

 PTN_Path_Resource web_root_folder_path_resource_;
 PTN_Path_Resource current_folder_path_resource_;
 PTN_Path_Resource current_file_path_resource_;

 QString host_;
 int port_;
 QString scheme_;

 QString silo_query_route_base_;
 QMultiMap<QString, int> secondary_hosts_;

 void check_set_secondary_scheme(PTN_Site_Request& psr);
 void check_set_scheme(PTN_Site_Request& psr);

 quint64 get_file_encode_string(QString& string_result);
 void get_path_encode_string(QString& result);

 //?PTN_Site_Manager_Local_Bridge();

 //?PTN_Site_Manager_Local_Bridge(const PTN_Site_Manager_Bridge& rhs);

public:

 PTN_Site_Manager_Local_Bridge();

 ACCESSORS(QString ,host)
 ACCESSORS(int ,port)
 ACCESSORS(QString ,scheme)

 void add_secondary_host(QString h);
 void add_secondary_host(QString h, int host);

 void get_current_folder_resource(PTN_Folder_Resource& pfr);

 void set_web_root_folder(QString str);
 void set_current_file_relative(QString str);
 void set_current_folder_relative(QString str);

 void enter_current_folder_relative(QString str);
 void leave_current_folder_relative();

 void check_file_update_needed(std::function<void()> fn);

 QString get_silo_response(QString silo_name, QString report_file);

 QString send_get_folder_contents();

 QString send_create_folder();
 QString send_create_file();

 QString send_check_test()
 {
   PTN_Site_Request psr(host_, port_);
   QString result = psr.send_check_test();
   return result;
 }

 QString send_update(std::function<void(QString)> fn = nullptr, bool create = false);
 QString send_update(bool create);

 void send_update(QMap<QString, std::function<void(QString)> > fns);


 QString send_info_test(std::function<void(QString)> fn = nullptr);

 void send_info_test(QMap<QString, std::function<void(QString)> > fns);

 //QString send_update(QNetworkReply** repl);

 //QNetworkReply* send_update_with_reply();

 //void send_update_no_reply(std::function<void(QString)> fn = nullptr);

 QSharedPointer<PTN_Folder_Resource> get_remote_folder_as_resource();

};


_RZNS(RZSite)


#endif
