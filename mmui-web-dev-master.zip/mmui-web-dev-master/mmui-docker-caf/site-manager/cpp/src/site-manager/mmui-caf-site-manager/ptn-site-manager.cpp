
#include "ptn-site-manager.h"

#include "ptn-resource-decoder.h"
#include "ptn-resource-encoder.h"

#include "ptn-file-resource.h"
#include "ptn-folder-resource.h"

#include "rzns.h"

#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>

#include <QFile>
#include <QFileInfo>
#include <QDir>

#include <QEventLoop>

#include <QBuffer>


USING_RZNS(RZSite)


template<>
struct TDCX_Type_Info<PTN_File_Resource> : TDCX_Byte_Array_Storage //?: TDCX_Pure_Value_Storage
{
 static QString get_QString_Type_Name(){ return "PTN_File_Resource"; }
 static int get_Type_Code(){ return 1; }
};

template<>
struct TDCX_Type_Info<PTN_Folder_Resource> : TDCX_Byte_Array_Storage //?: TDCX_Pure_Value_Storage
{
 static QString get_QString_Type_Name(){ return "PTN_Folder_Resource"; }
 static int get_Type_Code(){ return 2; }
};


PTN_Site_Manager::PTN_Site_Manager()
{


}

QString PTN_Site_Manager::path_in_site_context(const PTN_Path_Resource& ppr)
{
 return ppr.complete_path({
  {PTN_Path_Segment::Segment_Roles::Web_Root, web_root_path_},
  {PTN_Path_Segment::Segment_Roles::Data_Root, data_root_path_},
 });
}

QString PTN_Site_Manager::save_file(QString path, QString contents)
{
 QFile outfile(path);
 if(outfile.open(QIODevice::WriteOnly))
 {
  QTextStream outstream(&outfile);
  outstream << contents;
  outfile.close();
  return QString();
 }
 else
 {
  return outfile.errorString();
 }
}

QString PTN_Site_Manager::decode_file_resource(QString code)
{
 PTN_Resource_Decoder prdec;
 QSharedPointer<PTN_File_Resource> pfr = prdec.do_decode<PTN_File_Resource>(code);
 QString path = path_in_site_context(pfr->path_resource());
 return path;
}

QSharedPointer<PTN_Folder_Resource> PTN_Site_Manager::decode_folder_resource(QString code)
{
 PTN_Resource_Decoder prdec;
 QSharedPointer<PTN_Folder_Resource> result = prdec.do_decode<PTN_Folder_Resource>(code);
 return result;
}

QString PTN_Site_Manager::decode_file_resource(QString code, QString& contents)
{
 PTN_Resource_Decoder prdec;

 QSharedPointer<PTN_File_Resource> pfr = prdec.do_decode<PTN_File_Resource>(code);

 QString path = path_in_site_context(pfr->path_resource());

 contents = pfr->contents_to_latin1qstring();
 return path;
}

QString PTN_Site_Manager::receive_create_folder(QString code)
{
 QSharedPointer<PTN_Folder_Resource> pfr = decode_folder_resource(code);
 PTN_Path_Resource ppr = pfr->path_resource();
 QString path =  path_in_site_context(ppr);
 if(path.isEmpty())
 {
  return QString("Folder path was not valid; aborting.");
 }
 else
 {
  QDir dir(path);
  if (dir.exists())
  {
   return QString("Folder already exists; aborting: %1").arg(path);
  }
  else
  {
   if(dir.mkpath("."))
   {
    return QString("Folder successfully created: %1").arg(path);
   }
   else
   {
    return QString("Folder was not created: %1").arg(path);
   }
  }
 }

}

QString PTN_Site_Manager::receive_create_file(QString code)
{
 QString contents;
 QString path = decode_file_resource(code, contents);
 QString result = save_file(path, contents);
 if(result.isEmpty())
 {
  return QString("File successfully created: %1").arg(path);
 }
 else
 {
  return QString("File not created: %1").arg(result);
 }
}

QString PTN_Site_Manager::receive_get_folder_contents(QString code)
{
 QSharedPointer<PTN_Folder_Resource> pfr = decode_folder_resource(code);
// pfr->into_site_context({ {PTN_Path_Segment::Segment_Roles::Web_Root, web_root_path_},
//  {PTN_Path_Segment::Segment_Roles::Data_Root, data_root_path_}, });
 QString result;
 pfr->read_contained({{PTN_Path_Segment::Segment_Roles::Web_Root, web_root_path_},
  {PTN_Path_Segment::Segment_Roles::Data_Root, data_root_path_}});
 PTN_Resource_Encoder prenc;
 prenc.do_encode(*pfr, result);
 return result;
}


QString PTN_Site_Manager::receive_get_file_last_modified(QString code)
{
 QString path = decode_file_resource(code);
 QFile qf(path);
 QFileInfo qfi(qf);
 QDateTime qdt = qfi.lastModified();
 return QString::number(qdt.toMSecsSinceEpoch());
}

QString PTN_Site_Manager::receive_update_file(QString code)
{
 QString contents;
 QString path = decode_file_resource(code, contents);

 qDebug() << "Preparing to save on path: " << path;

 QString result = save_file(path, contents);
 if(result.isEmpty())
 {
  return QString("File successfully saved: %1").arg(path);
 }
 else
 {
  return QString("File not saved: %1").arg(result);
 }
}

