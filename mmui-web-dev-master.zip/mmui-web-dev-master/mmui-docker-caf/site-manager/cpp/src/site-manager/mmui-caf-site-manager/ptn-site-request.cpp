
#include "ptn-site-request.h"

#include "downpull/downpull-data-receiver.h"
#include "downpull/downpull-request-manager.h"

#include "rzns.h"

#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>

#include <QEventLoop>

#include <QBuffer>


USING_RZNS(RZSite)

PTN_Site_Request:: PTN_Site_Request(QString host, quint64 port)
 : host_(host), port_(port)
{


}




void PTN_Site_Request::send_request_async(QString code, QString route, QString mode)
{
 QNetworkRequest req;
 QUrl url;
 if(scheme_.isEmpty())
  url.setScheme("http");
 else
  url.setScheme(scheme_);
 url.setHost(host_);
 url.setPath(route);
 if(port_)
  url.setPort(port_);
   //?QString test = url.toString();
 req.setUrl(url);
 req.setHeader(QNetworkRequest::ContentTypeHeader, "raw");
 if(mode == "post")
  qnam_.post(req, code.toLatin1());
 else if(mode == "get")
  qnam_.get(req);
}


QString PTN_Site_Request::send_request(QString code, QString route, QString mode)
{
 QNetworkRequest req;
 QUrl url;
 if(scheme_.isEmpty())
  url.setScheme("http");
 else
  url.setScheme(scheme_);
 url.setHost(host_);
 url.setPath(route);
 if(port_)
  url.setPort(port_);
 req.setUrl(url);
 req.setHeader(QNetworkRequest::ContentTypeHeader, "raw");
 QNetworkReply* reply;

 if(mode == "post")
  reply = qnam_.post(req, code.toLatin1());
 else if(mode == "get")
  reply = qnam_.get(req);

 QEventLoop qel;
 QString result;

 QObject::connect(reply, &QNetworkReply::finished, [reply, &qel, &result]
 {
  result = reply->readAll();
  qel.quit();
 });
 qel.exec();
 return result;
}

//QString PTN_Site_Request::send_check_test()
//{
// return send_request("", "/up__check-test");
//}


QString PTN_Site_Request::send_get_folder_contents(QString code)
{
 return send_request(code, "/up__get-encoded-folder-contents");
}

QString PTN_Site_Request::send_get_file_last_modified(QString code)
{
 return send_request(code, "/up__get-file-last-modified");
}

QString PTN_Site_Request::send_new_file(QString code)
{
 return send_request(code, "/up__create");
}

QString PTN_Site_Request::send_new_folder(QString code)
{
 return send_request(code, "/up__create-folder");
}

QString PTN_Site_Request::send_edit(QString code)
{
 return send_request(code, "/up__edit");
}

void PTN_Site_Request::send_edit_async(QString code)
{
 send_request_async(code, "/up__edit");
}

QString PTN_Site_Request::send_info_test(QString code)
{
 return send_request(code, "/info", "get");
}

void PTN_Site_Request::send_info_test_async(QString code)
{
 send_request_async(code, "/info", "get");
}

QString PTN_Site_Request::send_downpull_request(QString report_file, QString silo, QMap<QString, QString>& hosts)
{
 Downpull_Request_Manager* drm = new Downpull_Request_Manager(&qnam_);
 Downpull_Data_Receiver* ddr = new Downpull_Data_Receiver(drm, report_file, hosts);

 QEventLoop qel;
 QString result;

 QObject::connect(ddr, &Downpull_Data_Receiver::all_records_received_and_saved,
  [&qel, &result]
 {
  result = "OK";
  qel.exit();
  //qapp->exit();
 });

 QObject::connect(drm, SIGNAL(host_count_received(QString, int)),
  ddr, SLOT(handle_host_count_received(QString, int)) );

 QObject::connect(drm, SIGNAL(host_records_received(QString, QString, int)),
  ddr, SLOT(handle_host_records_received(QString, QString, int)) );

 QMapIterator<QString, QString> it(hosts);
 while(it.hasNext())
 {
  it.next();
  QString h = it.key();
  QString url_key = it.value();
  drm->get_xml_count_response(h, url_key, silo);
 }

 qel.exec();
 return result;
}

//void PTN_Resource_Encoder::do_encode(QString &result)
//{
// tad.store(pfr, profile);
// QString encode = tad.encode();
//}
