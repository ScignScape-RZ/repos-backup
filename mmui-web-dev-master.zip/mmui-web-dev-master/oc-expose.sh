trap 'echo "# $BASH_COMMAND"' DEBUG 
/ext_root/openshift-oc3/openshift-origin-client-tools-v3.6.0-alpha.2-3c221d5-linux-64bit/oc expose dc/mmui-caf --port=13139
