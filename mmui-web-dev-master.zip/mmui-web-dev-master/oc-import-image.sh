trap 'echo "# $BASH_COMMAND"' DEBUG 
  #/ext_root/openshift-oc3/openshift-origin-client-tools-v3.6.0-alpha.2-3c221d5-linux-64bit/oc import-image docker.io/axiatropicsemantics/mmui-dev-oc3
oc import-image docker.io/axiatropicsemantics/mmui-caf
