trap 'echo "# $BASH_COMMAND"' DEBUG  
 #/ext_root/openshift-oc3/openshift-origin-client-tools-v3.6.0-alpha.2-3c221d5-linux-64bit/oc 
oc login https://api.starter-us-west-2.openshift.com --token=tGPWBw_8fhxwwyXIMXfbHRl03WknG_kSR8fvAdcLXUo
