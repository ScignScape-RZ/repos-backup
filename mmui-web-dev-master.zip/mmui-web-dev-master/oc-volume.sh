trap 'echo "# $BASH_COMMAND"' DEBUG 
/ext_root/openshift-oc3/openshift-origin-client-tools-v3.6.0-alpha.2-3c221d5-linux-64bit/oc volume dc/mmui-caf --add --name=mmui-caf-prime --type=persistentVolumeClaim --overwrite --claim-size=200M --mount-path=/usr/src/persistent-deploy-volume
