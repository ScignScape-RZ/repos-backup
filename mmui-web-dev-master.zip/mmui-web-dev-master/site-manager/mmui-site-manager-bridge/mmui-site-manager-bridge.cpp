
#include "mmui-site-manager-bridge.h"

#include "ptn-path-segment.h"

#include "ptn-path-resource.h"

#include "ptn-file-resource.h"

#include "ptn-resource-encoder.h"
#include "ptn-resource-decoder.h"
//?
#include "ptn-site-request.h"

//#include "rz-tdcx/rz-tdcx/rz-tdcx-bridge.h"
//#include "rz-tdcx/rz-tdcx/rz-tdcx-typed-array.h"
//#include "rz-tdcx/rz-tdcx/rz-tdcx-typed-array-document.h"
//#include "rz-tdcx/rz-tdcx/rz-tdcx-typed-array-decoder.h"

#include "rz-qclasp-each/rz-qclasp-callback.h"
#include "rz-qclasp-each/rz-qclasp-callback-map.h"

#include "mmui-site-manager-date-time.h"

#include "ptn-folder-resource.h"

#include <QtEndian>

#include <QtGlobal>
#include <QtCore>
//#include <qtendian.h>

#include <QDebug>

#include <QNetworkRequest>
#include <QNetworkReply>

USING_RZNS(RZSite)
USING_RZNS(RZClasp)


//template<>
//struct TDCX_Type_Info<PTN_File_Resource> : TDCX_Byte_Array_Storage //?: TDCX_Pure_Value_Storage
//{
// static QString get_QString_Type_Name(){ return "PTN_File_Resource"; }
// static int get_Type_Code(){ return 1; }
//};

template<>
struct TDCX_Type_Info<PTN_File_Resource> : TDCX_Byte_Array_Storage //?: TDCX_Pure_Value_Storage
{
 static QString get_QString_Type_Name(){ return "PTN_File_Resource"; }
 static int get_Type_Code(){ return 1; }
};


template<>
struct TDCX_Type_Info<PTN_Folder_Resource> : TDCX_Byte_Array_Storage //?: TDCX_Pure_Value_Storage
{
 static QString get_QString_Type_Name(){ return "PTN_Folder_Resource"; }
 static int get_Type_Code(){ return 2; }
};


// //  Why is this not being found?
//PTN_Path_Resource::PTN_Path_Resource()
//{

//}

MMUI_Site_Manager_Bridge::MMUI_Site_Manager_Bridge()
 : current_event_loop_(nullptr)
// : port_(0)
{

}

MMUI_Site_Manager_Bridge::MMUI_Site_Manager_Bridge(const MMUI_Site_Manager_Bridge& rhs)
 : PTN_Site_Manager_Local_Bridge(rhs), current_event_loop_(rhs.current_event_loop_)
{

}


void MMUI_Site_Manager_Bridge::set_web_root_folder(QString str)
{
 web_root_folder_path_resource_.reset_segments(PTN_Path_Segment(str,
   PTN_Path_Segment::Segment_Roles::Web_Root));

 //local_bridge_.web_root_folder_path_resource()
}

void MMUI_Site_Manager_Bridge::check_file_update_needed(RZ_QClasp_Callback* cb)
{
 return this->PTN_Site_Manager_Local_Bridge::check_file_update_needed([cb]
 {
  cb->run_function("void", nullptr);
 }
 );
}

void MMUI_Site_Manager_Bridge::set_current_file_relative(QString str)
{
 this->PTN_Site_Manager_Local_Bridge::set_current_file_relative(str);
}

void MMUI_Site_Manager_Bridge::set_current_folder_relative(QString str)
{
 this->PTN_Site_Manager_Local_Bridge::set_current_folder_relative(str);
}


void MMUI_Site_Manager_Bridge::get_current_folder_resource(PTN_Folder_Resource& pfr)
{
 pfr.set_path_resource(current_folder_path_resource_);
}


void MMUI_Site_Manager_Bridge::set_host(QString h)
{
 host_ = h;
}

void MMUI_Site_Manager_Bridge::set_port(int p)
{
 port_ = p;
}

void MMUI_Site_Manager_Bridge::set_scheme(QString sch)
{
 scheme_ = sch;
}

void MMUI_Site_Manager_Bridge::add_secondary_host(QString h, int port)
{
 this->PTN_Site_Manager_Local_Bridge::add_secondary_host(h, port);
}

MMUI_Site_Manager_Folder_Bridge* MMUI_Site_Manager_Bridge::get_remote_folder_as_bridge_resource()
{
 QSharedPointer<PTN_Folder_Resource> pfr = get_remote_folder_as_resource();
 MMUI_Site_Manager_Folder_Bridge* result = new MMUI_Site_Manager_Folder_Bridge(pfr);
 return result;
}


void MMUI_Site_Manager_Bridge::read_file(RZ_QClasp_Callback* cb)
{
 PTN_File_Resource pfr(current_file_path_resource_);
 pfr.load_contents();
 QString arg = pfr.contents_to_latin1qstring();
 cb->run_function("QString", &arg);
}

void MMUI_Site_Manager_Bridge::enter_event_loop()
{
 if(!current_event_loop_)
  current_event_loop_ = new QEventLoop;
 current_event_loop_->exec();
}

void MMUI_Site_Manager_Bridge::leave_event_loop()
{
 if(current_event_loop_)
 {
  if(current_event_loop_->isRunning())
  {
   current_event_loop_->exit();
  }
 }
}

void MMUI_Site_Manager_Bridge::send_update_async(RZ_QClasp_Callback* cb)
{
 this->PTN_Site_Manager_Local_Bridge::send_update([this, cb](QString result)
   {
    run_callback(cb, "QString", &result);
   });
}

void MMUI_Site_Manager_Bridge::send_update(RZ_QClasp_Callback_Map* cbm)
{
 RZ_QClasp_Callback* scb =  cbm->get_callback("-on-success");
 if(scb->async())
 {
  RZ_QClasp_Callback* fcb =  cbm->get_callback("-on-fail");
  QMap<QString, std::function<void(QString)> > fns;
  fns["finished"] = [this, scb](QString result)
  {
   run_callback(scb, "QString", &result);
  };
  fns["error"] = [this, fcb](QString result)
  {
   run_callback(fcb, "QString", &result);
  };
  this->PTN_Site_Manager_Local_Bridge::send_update(fns);
 }
 else
 {
  send_update(scb);
 }
}


void MMUI_Site_Manager_Bridge::send_info_test(RZ_QClasp_Callback_Map* cbm)
{
 RZ_QClasp_Callback* scb =  cbm->get_callback("-on-success");
 if(scb->async())
 {
  RZ_QClasp_Callback* fcb =  cbm->get_callback("-on-fail");

  QMap<QString, std::function<void(QString)> > fns;
  fns["finished"] = [this, scb](QString result)
  {
   run_callback(scb, "QString", &result);
  };

  fns["error"] = [this, fcb](QString result)
  {
   run_callback(fcb, "QString", &result);
  };
  this->PTN_Site_Manager_Local_Bridge::send_info_test(fns);
 }
 else
 {
  QString result = send_info_test();
  if(result.isEmpty())
  {
   RZ_QClasp_Callback* cb = cbm->get_callback("-on-fail");
   run_callback(cb, "QString", &result);
  }
  else
  {
   scb = cbm->get_callback("-on-success");
   run_callback(scb, "QString", &result);
  }
 }
}

void MMUI_Site_Manager_Bridge::send_info_test(RZ_QClasp_Callback* cb)
{
 QString result = send_info_test();
 run_callback(cb, "QString", &result);
}

QString MMUI_Site_Manager_Bridge::send_info_test()
{
 return this->PTN_Site_Manager_Local_Bridge::send_info_test();
}

void MMUI_Site_Manager_Bridge::send_update(RZ_QClasp_Callback* cb)
{
 if(cb->async())
  send_update_async(cb);
 else
 {
  QString result = send_update();
  cb->run_function("QString", &result);
 }
}

void MMUI_Site_Manager_Bridge::run_callback(void* cbpv, QString class_name, void* pv)
{
 RZ_QClasp_Callback* cb = reinterpret_cast<RZ_QClasp_Callback*>(cbpv);
 cb->run_function(class_name, pv);
}

void MMUI_Site_Manager_Bridge::check_file_update_needed(std::function<void()> fn)
{
 return this->PTN_Site_Manager_Local_Bridge::check_file_update_needed(fn);
}


QString MMUI_Site_Manager_Bridge::send_update()
{
 return this->PTN_Site_Manager_Local_Bridge::send_update();
// QString encode;
// get_file_encode_string(encode);

// PTN_Site_Request psr(host_, port_);
// if(!scheme_.isEmpty())
// {
//  psr.set_scheme(scheme_);
// }

// QString result = psr.send_edit(encode);
// return result;
}

QString MMUI_Site_Manager_Bridge::send_new_folder()
{
 QString result = this->PTN_Site_Manager_Local_Bridge::send_create_folder();
 return result;
}

QString MMUI_Site_Manager_Bridge::send_new_file()
{
 QString encode;
 get_file_encode_string(encode);

 PTN_Site_Request psr(host_, port_);
 if(!scheme_.isEmpty())
 {
  psr.set_scheme(scheme_);
 }

 QString result = psr.send_new_file(encode);
 return result;
}

void MMUI_Site_Manager_Bridge::send_new_file(RZ_QClasp_Callback* cb)
{
 QString result = send_new_file();
 cb->run_function("QString", &result);
}

void MMUI_Site_Manager_Bridge::check_file_last_modified(RZ_QClasp_Callback* cb)
{
 PTN_File_Resource pfr(current_file_path_resource_);
 QDateTime qdt;
 pfr.get_last_modified(qdt);
 MMUI_Site_Manager_Date_Time pdt(qdt);
 cb->run_function("MMUI_Site_Manager_Date_Time", &pdt);
}

void MMUI_Site_Manager_Bridge::enter_current_folder_relative(QString str)
{
 this->PTN_Site_Manager_Local_Bridge::enter_current_folder_relative(str);
}

void MMUI_Site_Manager_Bridge::leave_current_folder_relative()
{
 this->PTN_Site_Manager_Local_Bridge::leave_current_folder_relative();
}

QString MMUI_Site_Manager_Bridge::get_current_local_path()
{
 PTN_Folder_Resource pfr;
 get_current_folder_resource(pfr);
 return pfr.complete_local_path();
}

void MMUI_Site_Manager_Bridge::get_xml_silo_data(QString silo, QString report_file,
  RZ_QClasp_Callback* cb)
{
 QString result = get_silo_response(silo, report_file);
 cb->run_function("QString", &result);
}

void MMUI_Site_Manager_Bridge::check_remote_file_last_modified(RZ_QClasp_Callback* cb)
{
 QString encode;
 get_path_encode_string(encode);

 PTN_Site_Request psr(host_, port_);
 if(!scheme_.isEmpty())
 {
  psr.set_scheme(scheme_);
 }

 QString result = psr.send_get_file_last_modified(encode);
 QDateTime qdt;
 if(!result.isEmpty())
 {
  qint64 ms = result.toLongLong();
  qdt.setMSecsSinceEpoch(ms);
 }
 MMUI_Site_Manager_Date_Time pdt(qdt);
 cb->run_function("MMUI_Site_Manager_Date_Time", &pdt);
}


