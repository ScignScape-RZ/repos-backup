
#ifndef MMUI_SITE_MANAGER_BRIDGE__H
#define MMUI_SITE_MANAGER_BRIDGE__H

#include <QObject>

#include "ptn-path-resource.h"

#include "ptn-site-manager-local-bridge.h"

#include "mmui-site-manager-folder-bridge.h"

#include "rzns.h"

#include "accessors.h"

class QEventLoop;

RZNS_CLASS_DECLARE(RZClasp ,RZ_QClasp_Callback)
RZNS_CLASS_DECLARE(RZClasp ,RZ_QClasp_Callback_Map)
RZNS_CLASS_DECLARE(RZSite ,PTN_Folder_Resource)

USING_RZNS(RZClasp)
USING_RZNS(RZSite)


class MMUI_Site_Manager_Bridge : public QObject,
  public PTN_Site_Manager_Local_Bridge
{
 Q_OBJECT

 QEventLoop* current_event_loop_;

public:

 MMUI_Site_Manager_Bridge();

 MMUI_Site_Manager_Bridge(const MMUI_Site_Manager_Bridge& rhs);

 void get_current_folder_resource(PTN_Folder_Resource& pfr);


 Q_INVOKABLE void set_web_root_folder(QString str);
 Q_INVOKABLE void set_current_file_relative(QString str);
 Q_INVOKABLE void set_current_folder_relative(QString str);

 Q_INVOKABLE void check_file_update_needed(RZ_QClasp_Callback* cb);
 Q_INVOKABLE void enter_current_folder_relative(QString str);
 Q_INVOKABLE void leave_current_folder_relative();

 void check_file_update_needed(std::function<void()> fn);


 Q_INVOKABLE void set_host(QString h);
 Q_INVOKABLE void set_port(int p);

 Q_INVOKABLE void set_scheme(QString sch);
 Q_INVOKABLE QString send_update();
 Q_INVOKABLE QString send_new_file();
 Q_INVOKABLE QString send_new_folder();

 Q_INVOKABLE void send_new_file(RZ_QClasp_Callback* cb);

 //?Q_INVOKABLE void send_new_folder(RZ_QClasp_Callback* cb);

 Q_INVOKABLE void send_info_test(RZ_QClasp_Callback_Map* cbm);

 Q_INVOKABLE void send_info_test(RZ_QClasp_Callback* cb);

 QString send_info_test();

 Q_INVOKABLE void send_update(RZ_QClasp_Callback_Map* cbm);

 Q_INVOKABLE void send_update(RZ_QClasp_Callback* cb);

 Q_INVOKABLE void send_update_async(RZ_QClasp_Callback* cb);

 Q_INVOKABLE void read_file(RZ_QClasp_Callback* cb);

 Q_INVOKABLE void add_secondary_host(QString h, int port);

 Q_INVOKABLE void check_file_last_modified(RZ_QClasp_Callback* cb);
 Q_INVOKABLE void check_remote_file_last_modified(RZ_QClasp_Callback* cb);

 Q_INVOKABLE QString get_current_local_path();

 Q_INVOKABLE void get_xml_silo_data(QString silo, QString report_file, RZ_QClasp_Callback* cb);

 Q_INVOKABLE MMUI_Site_Manager_Folder_Bridge* get_remote_folder_as_bridge_resource();

 Q_INVOKABLE void run_callback(void* cbpv, QString class_name, void* pv);

 Q_INVOKABLE void enter_event_loop();
 Q_INVOKABLE void leave_event_loop();

};

Q_DECLARE_METATYPE(MMUI_Site_Manager_Bridge)
Q_DECLARE_METATYPE(MMUI_Site_Manager_Bridge*)


#endif
