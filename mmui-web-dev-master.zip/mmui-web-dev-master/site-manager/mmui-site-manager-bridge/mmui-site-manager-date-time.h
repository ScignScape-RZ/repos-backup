
#ifndef MMUI_SITE_MANAGER_DATE_TIME__H
#define MMUI_SITE_MANAGER_DATE_TIME__H

#include <QObject>
#include <QDateTime>

#include "ptn-path-resource.h"

#include "rzns.h"

#include "accessors.h"

RZNS_CLASS_DECLARE(RZClasp ,RZ_QClasp_Callback)

USING_RZNS(RZClasp)
USING_RZNS(RZSite)


class MMUI_Site_Manager_Date_Time : public QObject
{
 Q_OBJECT

 QDateTime qdt_;


public:

 MMUI_Site_Manager_Date_Time();
 MMUI_Site_Manager_Date_Time(QDateTime qdt);
 MMUI_Site_Manager_Date_Time(const MMUI_Site_Manager_Date_Time& rhs);

 Q_INVOKABLE QString to_str();
 Q_INVOKABLE void test();

 static QString get_french_republican_date_time(QDate qdt, int offset = 0);
 static QString get_french_republican_date_time();

};

Q_DECLARE_METATYPE(MMUI_Site_Manager_Date_Time)
Q_DECLARE_METATYPE(MMUI_Site_Manager_Date_Time*)


#endif
