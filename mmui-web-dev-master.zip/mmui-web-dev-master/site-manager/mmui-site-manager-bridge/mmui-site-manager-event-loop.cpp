
#include "mmui-site-manager-event-loop.h"


#include "rz-qclasp-each/rz-qclasp-callback.h"

#include <QDebug>

USING_RZNS(RZSite)
USING_RZNS(RZClasp)

MMUI_Site_Manager_Event_Loop::MMUI_Site_Manager_Event_Loop()
 : current_event_loop_(nullptr)
{

}

MMUI_Site_Manager_Event_Loop::MMUI_Site_Manager_Event_Loop(const MMUI_Site_Manager_Event_Loop& rhs)
 : current_event_loop_(rhs.current_event_loop_)
{

}


void MMUI_Site_Manager_Event_Loop::enter()
{
 if(!current_event_loop_)
  current_event_loop_ = new QEventLoop;
 current_event_loop_->exec();
}

void MMUI_Site_Manager_Event_Loop::leave()
{
 if(current_event_loop_)
 {
  if(current_event_loop_->isRunning())
  {
   current_event_loop_->exit();
  }
 }
}
