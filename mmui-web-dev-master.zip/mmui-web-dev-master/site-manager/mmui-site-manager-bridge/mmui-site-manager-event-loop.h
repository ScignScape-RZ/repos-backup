
#ifndef MMUI_SITE_MANAGER_EVENT_LOOP__H
#define MMUI_SITE_MANAGER_EVENT_LOOP__H

#include <QObject>
#include <QEventLoop>

#include "ptn-path-resource.h"

#include "rzns.h"

#include "accessors.h"

RZNS_CLASS_DECLARE(RZClasp ,RZ_QClasp_Callback)

USING_RZNS(RZClasp)
USING_RZNS(RZSite)


class MMUI_Site_Manager_Event_Loop : public QObject
{
 Q_OBJECT

 QEventLoop* current_event_loop_;


public:

 MMUI_Site_Manager_Event_Loop();
 MMUI_Site_Manager_Event_Loop(const MMUI_Site_Manager_Event_Loop& rhs);

 Q_INVOKABLE void enter();
 Q_INVOKABLE void leave();

};

Q_DECLARE_METATYPE(MMUI_Site_Manager_Event_Loop)
Q_DECLARE_METATYPE(MMUI_Site_Manager_Event_Loop*)


#endif
