
#ifndef MMUI_SITE_MANAGER_FILE_BRIDGE__H
#define MMUI_SITE_MANAGER_FILE_BRIDGE__H

#include <QObject>
#include <QDateTime>

#include <QSharedPointer>

#include "ptn-path-resource.h"


#include "rzns.h"

#include "accessors.h"

RZNS_CLASS_DECLARE(RZClasp ,RZ_QClasp_Each)
RZNS_CLASS_DECLARE(RZClasp ,RZ_QClasp_Callback)
RZNS_CLASS_DECLARE(RZSite ,PTN_File_Resource)

USING_RZNS(RZClasp)
USING_RZNS(RZSite)


class MMUI_Site_Manager_File_Bridge : public QObject
{
 Q_OBJECT

 QSharedPointer<PTN_File_Resource> file_resource_;

public:

 MMUI_Site_Manager_File_Bridge();
 MMUI_Site_Manager_File_Bridge(QSharedPointer<PTN_File_Resource> file_resource);
 MMUI_Site_Manager_File_Bridge(const MMUI_Site_Manager_File_Bridge& rhs);

 Q_INVOKABLE QString complete_local_path();
 Q_INVOKABLE QString file_name();

};

Q_DECLARE_METATYPE(MMUI_Site_Manager_File_Bridge)
Q_DECLARE_METATYPE(MMUI_Site_Manager_File_Bridge*)


#endif
