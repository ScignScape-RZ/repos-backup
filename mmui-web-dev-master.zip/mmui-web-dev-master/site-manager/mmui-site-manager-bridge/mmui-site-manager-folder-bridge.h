
#ifndef MMUI_SITE_MANAGER_FOLDER_BRIDGE__H
#define MMUI_SITE_MANAGER_FOLDER_BRIDGE__H

#include <QObject>
#include <QDateTime>

#include <QSharedPointer>

#include "ptn-path-resource.h"

#include "mmui-site-manager-file-bridge.h"

#include "rzns.h"

#include "accessors.h"

RZNS_CLASS_DECLARE(RZClasp ,RZ_QClasp_Each)
RZNS_CLASS_DECLARE(RZClasp ,RZ_QClasp_Callback)
RZNS_CLASS_DECLARE(RZSite ,PTN_Folder_Resource)

USING_RZNS(RZClasp)
USING_RZNS(RZSite)

class MMUI_Site_Manager_File_Bridge;

class MMUI_Site_Manager_Folder_Bridge : public QObject
{
 Q_OBJECT

 QSharedPointer<PTN_Folder_Resource> folder_resource_;

public:

 MMUI_Site_Manager_Folder_Bridge();
 MMUI_Site_Manager_Folder_Bridge(QSharedPointer<PTN_Folder_Resource> folder_resource);
 MMUI_Site_Manager_Folder_Bridge(const MMUI_Site_Manager_Folder_Bridge& rhs);

 QStringList contained_files();
 QStringList contained_folders();

 Q_INVOKABLE QString file_list_summary();

 Q_INVOKABLE QString folder_name();
 Q_INVOKABLE QString complete_local_path();

 Q_INVOKABLE void each(RZ_QClasp_Each* ecb);

 Q_INVOKABLE void each_file(RZ_QClasp_Callback* cb);
 Q_INVOKABLE void each_folder(RZ_QClasp_Callback* cb);

 Q_INVOKABLE QString compare_info(MMUI_Site_Manager_File_Bridge* fib);

//? Q_INVOKABLE void ea(RZ_QClasp_Callback* ecb);

// Q_INVOKABLE QString to_str();
// Q_INVOKABLE void test();


};

Q_DECLARE_METATYPE(MMUI_Site_Manager_Folder_Bridge)
Q_DECLARE_METATYPE(MMUI_Site_Manager_Folder_Bridge*)


#endif
