


#include "ptn-path-segment.h"

#include "ptn-path-resource.h"

#include "ptn-file-resource.h"

#include "ptn-resource-encoder.h"
#include "ptn-resource-decoder.h"
#include "ptn-site-request.h"

#include "ptn-folder-resource.h"

#include "ptn-site-manager-local-bridge.h"

//#include "mmui-site-manager-bridge.h"

//#include "mmui-site-manager-folder-bridge.h"

#include <QDebug>

#include <QCoreApplication>

#include <QMap>
#include <map>

//USING_RZNS(RZClasp)

USING_RZNS(RZSite)

template<>
struct TDCX_Type_Info<PTN_File_Resource> : TDCX_Byte_Array_Storage //?: TDCX_Pure_Value_Storage
{
 static QString get_QString_Type_Name(){ return "PTN_File_Resource"; }
 static int get_Type_Code(){ return 1; }
};


template<>
struct TDCX_Type_Info<PTN_Folder_Resource> : TDCX_Byte_Array_Storage //?: TDCX_Pure_Value_Storage
{
 static QString get_QString_Type_Name(){ return "PTN_Folder_Resource"; }
 static int get_Type_Code(){ return 2; }
};


int main(int argc, char *argv[])
{
 QCoreApplication app(argc, argv);

 PTN_Site_Manager_Local_Bridge psmlb;

 psmlb.set_web_root_folder("/ext_root/openshift-oc3/mmui-caf-local/web");


 //?
 //psmlb.set_current_folder_relative("mmui/public/pics");
 //?
 //psmlb.set_current_folder_relative("mmui/partials/styles");

 psmlb.set_current_folder_relative("mmui/public/main-info-pages");

 psmlb.set_port(13139);
 psmlb.set_host("localhost");

 //?
 //psmlb.set_host("caf-mmui-dev.7e14.starter-us-west-2.openshiftapps.com");

 //?
 //
 QString file_name = "mmui.html";
 //
 //QString file_name = "mmui.html";

 psmlb.set_current_file_relative(file_name);

// QEventLoop qel;


 //QString res = psmlb.send_create_folder(); //?psmlb.send_update();


 QString res = psmlb.send_update();


 qDebug() << "RES:" << res;

//?
// psmb.send_update_async([&qel](QString result)
// {
//  qDebug() << "RR: " << result;
//  qel.quit();
// } );

// qel.exec();
 return 0;

}


