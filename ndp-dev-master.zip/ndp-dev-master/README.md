# ndp-dev

Basically scratch work.  Similar to CharmTorque.
