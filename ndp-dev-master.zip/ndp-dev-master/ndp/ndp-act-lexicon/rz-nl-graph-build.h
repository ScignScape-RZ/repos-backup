
#ifndef NL_GRAPH_BUILD__H
#define NL_GRAPH_BUILD__H

#include "accessors.h"
#include "flags.h"


//#include "kernel/graph/rz-re-node.h"
//#include "kernel/query/rz-re-query.h"

//?
#include "rz-nl-link-pair.h"

#include "rz-nl-node.h"

#include <QList>
#include <QStack>
#include <QMap>
#include <QVector>

#include "rzns.h"


#include <QMap>

RZNS_CLASS_DECLARE(NL ,NL_Lexicon)
RZNS_CLASS_DECLARE(NL ,NL_Lexclass)
RZNS_CLASS_DECLARE(NL ,NL_Link_Pair_Cluster)

USING_RZNS(NL)


RZNS_(NL)

class RE_Graph_Build;


class NL_Dock_Matrix
{
 QVector< QVector<const NL_Link_Pair*> > matrix_;

public:

 NL_Dock_Matrix(int rewind_depth = 1);

 void resize(int rewind, int size);
 void place_link_pair(int rewind, int lambda_position, const NL_Link_Pair* lp);
 NL_Node* node_at(int rewind, int lambda_position) const;
 const NL_Link_Pair* pair_at(int rewind, int lambda_position) const;
 int rewind_depth() const;
 int arity_at_rewind(int rewind) const;
};

class NL_Graph_Build
{
// RE_Frame& fr_;
// const RE_Query& rq_;

 enum class Pair_Comparison {
  Not_Compatible, Compatible_Source_To_Source,
  Compatible_Source_To_Target,
  Compatible_Target_To_Source
 };

 NL_Node* current_node_;
 NL_Node* start_node_;

 NL_Lexicon* nl_lexicon_;

 QMap<int, const NL_Link_Pair*> pair_map_;
 typedef QMap<int, const NL_Link_Pair*> pair_map_type;

 int pair_count_;

 int target_word_length_;

 //caon_ptr<RE_Graph_Build> graph_build_;

 //QSet<QString> graph_code_set_;

 QMap<NL_Lexclass*, QVector<NL_Node* > > nodes_by_lexclass_;

 void check_forward_link_pairs(NL_Node* start_node, QSet<NL_Link_Pair>& link_pairs, int& link_pair_index);

 void check_lamdba_matches(NL_Node* potential_source_node, NL_Node* potential_target_node,
   NL_Lexclass* source_lexclass_with_lambda,
   int offset, int profile_position, NL_Lexclass* potential_target_lexclass,
   QSet<NL_Link_Pair>& link_pairs, int& link_pair_index, int rewind = 0);

 void prepare_graph_code_list(NL_Node* sentence_root_node, const QSet<NL_Link_Pair>& link_pairs);

 const NL_Link_Pair* prepare_code_string(NL_Link_Pair_Cluster& lpc, QString& result_string);

 const NL_Link_Pair* prepare_code_string1(NL_Link_Pair_Cluster& lpc, QString& result_string);

 void prepare_docks(NL_Link_Pair_Cluster& lpc, QMap<NL_Node*, const NL_Link_Pair*>& index, QMap<NL_Node*, NL_Dock_Matrix>& mmap);

 const NL_Link_Pair* prepare_code_string(NL_Link_Pair_Cluster& lpc,
   NL_Node* start_node,
   QString& result_string, const QMap<NL_Node*, const NL_Link_Pair*>& index,
   const QMap<NL_Node*, NL_Dock_Matrix>& docks);


public:
 typedef std::function<int(NL_Link_Pair_Cluster& lpc)> cluster_indexing_function_type;
 typedef std::function<void(NL_Link_Pair_Cluster& lpc)> cluster_activation_function_type;
 typedef std::function<void(NL_Link_Pair_Cluster& lpc)> cluster_maximal_function_type;

private:
 cluster_indexing_function_type cluster_indexing_function_;
 cluster_activation_function_type cluster_activation_function_;
 cluster_maximal_function_type cluster_maximal_function_;

public:

 NL_Graph_Build(NL_Lexicon* nl_lexicon);

 ACCESSORS(NL_Node* ,current_node)
 ACCESSORS(NL_Node* ,start_node)
 ACCESSORS(pair_map_type ,pair_map)

 ACCESSORS(NL_Lexicon* ,nl_lexicon)

 ACCESSORS(cluster_indexing_function_type ,cluster_indexing_function)
 ACCESSORS(cluster_activation_function_type ,cluster_activation_function)
 ACCESSORS(cluster_maximal_function_type ,cluster_maximal_function)


 QString prepare_code_string(NL_Link_Pair_Cluster& lpc);

 void add_word(NL_Node* node);

 void add_punctuation(NL_Node* node);

 void parse_sentence(QSet<NL_Link_Pair>& link_pairs, NL_Node* punctuation_node);

 void parse_sentence(QSet<NL_Link_Pair>& link_pairs, QString sentence);

 void prepare_link_pair_clusters(
   const QSet<NL_Link_Pair>& link_pairs, QSet<NL_Link_Pair_Cluster*>& link_pair_clusters);

 void test_chain_against_pairs(NL_Link_Pair_Cluster& lpc, std::function<void(int)> continuation);
 int test_chain_against_pair(NL_Link_Pair_Cluster& lpc, const NL_Link_Pair* pr, int i);
 void test_pair_against_pairs(NL_Link_Pair_Cluster& lpc, const NL_Link_Pair* pr, int i);
 Pair_Comparison test_pair_against_pair(const NL_Link_Pair* pr, const NL_Link_Pair* jpr);

 void merge_pair_to_chain_Source_To_Source(NL_Link_Pair_Cluster& lpc, const NL_Link_Pair* pr,
   const NL_Link_Pair* jpr, int pos);
 void merge_pair_to_chain_Source_To_Target(NL_Link_Pair_Cluster& lpc, const NL_Link_Pair* pr,
   const NL_Link_Pair* jpr, int pos);
 void merge_pair_to_chain_Target_To_Source(NL_Link_Pair_Cluster& lpc, const NL_Link_Pair* pr,
   const NL_Link_Pair* jpr, int pos);

 void check_cluster_activation(NL_Link_Pair_Cluster& lpc);

};


_RZNS(RECore)

#endif

