
#include "rz-nl-lexclass-vector.h"

#include "rz-nl-lexclass.h"

#include "rz-nl-lexicon.h"

USING_RZNS(NL)


NL_Lexclass_Vector::NL_Lexclass_Vector():
  QVector<NL_Lexclass*>()
{
}

