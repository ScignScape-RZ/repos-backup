
#ifndef NL_LEXENTRY__H
#define NL_LEXENTRY__H

#include "rzns.h"

#include <functional>

#include <QString>

#include <QMap>

#include "accessors.h"

#include "rz-nl-lexclass.h"

#include "rz-nl-lexclass-vector.h"

RZNS_(NL)

class NL_Lexentry
{
 QString lexword_;

 NL_Lexclass_Vector lexclasses_;

public:

 NL_Lexentry(QString lexword, NL_Lexclass* lexclass);

 NL_Lexentry();

 ACCESSORS__GET(NL_Lexclass_Vector ,lexclasses)

 void add_lexclass(NL_Lexclass* lexclass);

};

_RZNS(Chat)



#endif
