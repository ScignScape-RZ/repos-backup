
#ifndef NL_LINK_PAIR_CLUSTER__H
#define NL_LINK_PAIR_CLUSTER__H

#include "rzns.h"

#include <functional>

#include <QSet>

#include <QString>
#include <QBitArray>
#include <QMap>
#include <QVector>

#include "accessors.h"

//#include "rz-core/rz-relae/relae-caon-ptr.h"
//#include "rz-core/rz-relae/relae-node-ptr.h"

#include <QList>

//RZNS_CLASS_DECLARE(RECore ,NL_Node)
//USING_RZNS(RECore)


RZNS_(NL)

class NL_Lexicon;
class NL_Lexclass;
class NL_Link_Pair;
class NL_Node;

class NL_Link_Pair_Cluster
{
 int local_index_;

 QList<const NL_Link_Pair*> linkpairs_;
 QList<signed int> depth_change_;

 QMap<NL_Node*, QMap<int, int> > node_arity_;
 QMap<QString, QMap<int, int> > node_arity__labels_;

 typedef QMap<NL_Node*, QMap<int, int> > node_arity_type;
 typedef QMap<QString, QMap<int, int> > node_arity__labels_type;

 int cluster_size_;

 QString debug_;

 QBitArray inclusion_mask_;

public:

 ACCESSORS(int ,local_index)

 ACCESSORS(QList<const NL_Link_Pair*> ,linkpairs)
 ACCESSORS(QList<signed int> ,depth_change)

 ACCESSORS__GET(node_arity_type ,node_arity)
 ACCESSORS__GET(node_arity__labels_type ,node_arity__labels)


 ACCESSORS(int ,cluster_size)

 NL_Link_Pair_Cluster(int local_index, int inclusion_mask_length);

 int implicit_word_length();

 bool has_pair(const NL_Link_Pair* const jpr);

 void clone_from(const NL_Link_Pair_Cluster& rhs);

 void append_link_pair_at_position(const NL_Link_Pair* pr, int pos, signed int dc);
 void prepend_link_pair_at_position(const NL_Link_Pair* pr, int pos, signed int dc);

 void append_link_pair(const NL_Link_Pair* pr);

 friend bool operator <(const NL_Link_Pair_Cluster& lhs, const NL_Link_Pair_Cluster& rhs)
 {
  return lhs.local_index_ < rhs.local_index_;
 }

 friend bool operator ==(const NL_Link_Pair_Cluster& lhs, const NL_Link_Pair_Cluster& rhs)
 {
//  if(lhs.source_node() == rhs.source_node() &&
//     lhs.target_node() == rhs.target_node() &&
//     lhs.lambda_position() == rhs.lambda_position() &&
//     lhs.profile_position() == rhs.profile_position()
//     )
//   return true;

  if(lhs.linkpairs_ == rhs.linkpairs_ && lhs.depth_change_ == rhs.depth_change_)
   return true;

  return lhs.local_index_ == rhs.local_index_;
 }

 void find_source_node_positions(NL_Node* source_node,
   QVector<QPair<int, const NL_Link_Pair*> >& positions) const;


 int find_pair_position(const NL_Link_Pair* pr) const;

 const NL_Link_Pair* find_source_target_duplicate(const NL_Link_Pair* pr) const;
 const NL_Link_Pair* match_pair_with_regent(NL_Node* node) const;

 QString short_summary() const;

 void increase_node_arity(NL_Node* node, int rewind_level);
 int get_node_arity(NL_Node* node, int rewind_level);

 bool has_node_arity(NL_Node* node);

 void increase_node_arity__labels(QString n, int rewind_level);

};

inline int qHash(const NL_Link_Pair_Cluster& lhs)
{
 return lhs.local_index();
}

_RZNS(Chat)



#endif
