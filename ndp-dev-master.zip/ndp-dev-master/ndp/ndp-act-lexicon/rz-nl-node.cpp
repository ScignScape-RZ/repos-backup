
#include "rz-nl-node.h"
#include "rz-nl-sentence.h"

USING_RZNS(NL)

NL_Node::NL_Node(NL_Sentence* nl_sentence)
 :
   text_punctuation_(nullptr),
   nl_token_(nullptr),
   nl_continue_(nullptr),
   nl_sentence_(nl_sentence)
{
}

NL_Node::NL_Node(NL_Token* nl_token)
 :
   text_punctuation_(nullptr),
   nl_token_(nl_token),
   nl_continue_(nullptr),
   nl_sentence_(nullptr)
{
 label_ = nl_token->raw_text();
}

NL_Node::NL_Node(NL_Text_Punctuation*  ntp)
 :
   text_punctuation_(ntp),
   nl_token_(nullptr),
   nl_continue_(nullptr),
   nl_sentence_(nullptr)
{

}

QString NL_Node::raw_text()
{
 if(nl_token_)
 {
  return nl_token_->raw_text();
 }
 return QString();
}


