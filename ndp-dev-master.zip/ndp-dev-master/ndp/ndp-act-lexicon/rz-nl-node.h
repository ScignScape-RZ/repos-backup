
#ifndef NL_NODE__H
#define NL_NODE__H

#include "rzns.h"

#include <functional>

#include <QString>

#include <QMap>
#include <QVector>

#include "accessors.h"

//#include "rz-core/rz-relae/relae-caon-ptr.h"
//#include "rz-core/rz-relae/relae-node-ptr.h"


//?RZNS_CLASS_DECLARE(Text ,RZ_Text_Punctuation)

//RZNS_CLASS_DECLARE(RECore ,NL_Node)
//USING_RZNS(RECore)


RZNS_(NL)

class NL_Lexentry;

class NL_Text_Punctuation
{
public:

 bool marks_sentence_end()
 {
  return true;
 }


};


//* pun
class NL_Token
{
 NL_Lexentry* lexentry_;

 QString raw_text_;

public:

 NL_Token(QString raw_text) : raw_text_(raw_text) {}


 ACCESSORS(NL_Lexentry* ,lexentry)
 ACCESSORS(QString ,raw_text)

};



class NL_Sentence; //* nls

class NL_Node
{

 NL_Text_Punctuation* text_punctuation_;
 QString label_;
 NL_Token* nl_token_;

 NL_Node* nl_continue_;

 NL_Sentence* nl_sentence_;

public:

 NL_Node(NL_Sentence* nl_sentence);
 NL_Node(NL_Token* nl_token);
 NL_Node(NL_Text_Punctuation*  ntp);


 ACCESSORS(NL_Text_Punctuation* ,text_punctuation)
 ACCESSORS(NL_Token* ,nl_token)
 ACCESSORS(QString ,label)
 ACCESSORS(NL_Node* ,nl_continue)
 ACCESSORS(NL_Sentence* ,nl_sentence)

 QString raw_text();

};

_RZNS(NL)



#endif

