
#include "rz-nl-sentence.h"

USING_RZNS(NL)

NL_Sentence::NL_Sentence(NL_Node* punctuation_node)
 : punctuation_node_(punctuation_node)
{
}

