

#include "caf/all.hpp"

#include "rz-nl-graph-build.h"
#include "rz-nl-lexicon.h"

#include "rz-nl-link-pair-cluster.h"

#include <QSet>

#include "rzns.h"


#include <QDebug>

#include <QEventLoop>

//#include "rz-chat/rz-chat-client/rz-chat-client.h"
//#include "rz-nl/rz-nl-lexicon/rz-nl-lexicon.h"
//#include "rz-clasp/rz-clasp-bridge/rz-clasp-bridge.h"
//#include "rz-re-core/rz-graph-core/kernel/document/rz-re-document.h"

#include <iostream>

USING_RZNS(NL)
//USING_RZNS(RZClasp)
//USING_RZNS(RECore)



#include <QString>
#include <QDebug>

using std::endl;
using std::string;

using namespace caf;

using add_atom = atom_constant<atom("add")>;
using multiply_atom = atom_constant<atom("multiply")>;

void hello_world(event_based_actor* self, const actor& buddy)
{
 // send "Hello World!" to our buddy ...
 self->request(buddy, std::chrono::seconds(10), "Hello World!").then(
    // ... wait up to 10s for a response ...
    [=](const string& what) {
  // ... and print it
  aout(self) << what << endl;
 }
 );
}

void test(event_based_actor* self, const actor& buddy)
{
  atom_value a1 = atom("add");
  atom_value a2 = atom("multiply");

 self->request(buddy, std::chrono::seconds(10),
                atom("add"), 12, 1, 3).then(
    // ... wait up to 10s for a response ...
    [=](const int what) {
  QString str = QString("VAL: %1").arg(what);
  qDebug() << "STR: " << str;
  // ... and print it
  aout(self) << str.toStdString() << endl;
 }
 );
}




behavior
test_chain_against_pairs(event_based_actor* self)
{
 return
 {
//  [=](NL_Link_Pair_Cluster* lpc, NL_Graph_Build* gb)
//  {
//   gb->test_chain_against_pairs(*lpc,
//    [=]
//    {

//    }
//   );
//   //QVector<int> indices = QVector<int>::fromList(gb.pair_map().keys());
//  },
  [=](size_t v_lpc, size_t v_gb)
  {
   NL_Link_Pair_Cluster* lpc = reinterpret_cast<NL_Link_Pair_Cluster*>(v_lpc);
   NL_Graph_Build* gb = reinterpret_cast<NL_Graph_Build*>(v_gb);
   gb->test_chain_against_pairs(*lpc,
    [=] (int total)
    {
     //qDebug() << "Total " << total << " for " << lpc->short_summary();
    });
  }
 };
}


void buddy_test_chain_against_pairs(event_based_actor* self,
  const actor& buddy, NL_Link_Pair_Cluster* lpc, NL_Graph_Build* gb)//, NL_Graph_Build* gb) //, NL_Link_Pair_Cluster& lpc, NL_Graph_Build& gb)
{
 //NL_Link_Pair_Cluster lpc;
 size_t vlpc = reinterpret_cast<size_t>(lpc);
 size_t vgb = reinterpret_cast<size_t>(gb);

 self->request(buddy, std::chrono::seconds(10), vlpc, vgb).then(
    // ... wait up to 10s for a response ...
    [=]() {
  // ... and print it
   //?aout(self) << "what" << endl;
 }
 );

}



void form_link_chains(actor_system& system, NL_Graph_Build& gb, QSet<NL_Link_Pair>& link_pairs)
{
 QSet<NL_Link_Pair_Cluster*> link_pair_clusters;
 gb.prepare_link_pair_clusters(link_pairs, link_pair_clusters);
 //QVector<int> indices = QVector<int>::fromList(gb.pair_map().keys());

 int cluster_index = 0;
 gb.set_cluster_indexing_function(
   [&cluster_index](NL_Link_Pair_Cluster& lpc) -> int
  {
   lpc.set_local_index(++cluster_index);
   return cluster_index;
  }
 );

 gb.set_cluster_activation_function(
   [&system, &gb](NL_Link_Pair_Cluster& lpc)
  {
//   NL_Graph_Build* pgb = &gb;
   actor test_chain_against_pairs_actor = system.spawn(&test_chain_against_pairs);
   //test_chain_against_pairs_actor.
   system.spawn(buddy_test_chain_against_pairs, test_chain_against_pairs_actor, &lpc, &gb);
//   test_chain_against_pairs_actor.request();
//   event_based_actor* self = &test_chain_against_pairs_actor;
//   self->request();
  }
 );

 gb.set_cluster_maximal_function(
   [&system, &gb](NL_Link_Pair_Cluster& lpc)
  {
   QString s1 = gb.prepare_code_string(lpc);
   if(!s1.isEmpty())
   {
    qDebug() << "Max for " << lpc.short_summary();
    qDebug() << s1;
   }
  }
 );


 for(NL_Link_Pair_Cluster* lpc : link_pair_clusters)
 {
  gb.cluster_activation_function()(*lpc);
  //auto test_chain_against_pairs_actor = system.spawn(&test_chain_against_pairs);

 }

 QEventLoop qel;
 qel.exec();
}

void compile_nl(actor_system& system, QString sentence, //file_name,
                NL_Lexicon& nll)
{
 NL_Graph_Build* gb = new NL_Graph_Build(&nll);

 QSet<NL_Link_Pair> link_pairs;

 gb->parse_sentence(link_pairs, sentence);

 form_link_chains(system, *gb, link_pairs);

// gb->set_nl_lexicon(&nll);
// RE_Document* doc = new RE_Document(file_name);
// doc->set_nl_lexicon(&nll);
// doc->parse();
}


int main(int argc, char* argv[])
{
 actor_system_config cfg;
 actor_system system{cfg};

 QString lex_file = "/home/nlevisrael/rz-dev/nl/lexicon.txt";

 //QString nl_file = "/home/nlevisrael/rz-dev/nl/nl.txt";

 QString nl_sentence = "The dog is there";

 NL_Lexicon nll(lex_file);

 compile_nl(system, nl_sentence, nll);

 return 0;

}

int main1()
{
// atom_value a1 = atom("add");
// atom_value a2 = atom("multiply");


 // our CAF environment
 actor_system_config cfg;
 actor_system system{cfg};

// auto x1_actor = system.spawn(&x1);
// system.spawn(&test, x1_actor);

// // create a new actor that calls ’mirror()’
// auto mirror_actor = system.spawn(&mirror);
// // create another actor that calls ’hello_world(mirror_actor)’;
// system.spawn(hello_world, mirror_actor);
// // system will wait until both actors are destroyed before leaving main
}
