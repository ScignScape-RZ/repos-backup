
#include "ndp-application-state.h"

#include<QDateTime>

#include "ndp-antemodel.h"



USING_RZNS(NDP)

NDP_Application_State::NDP_Application_State(NDP_Antemodel* ante_model)
 : ante_model_(ante_model), when_last_saved_(nullptr)//, number_of_users_(0)
{

}

void NDP_Application_State::add_saved_xml(QString url, QString xml)
{
 saved_xml_by_url_[url] = xml;
}

QString NDP_Application_State::get_saved_xml(QString url)
{
 return saved_xml_by_url_.value(url);
}

void NDP_Application_State::add_saved_web_page(QString url, NDP_Document_Web_Page* wp)
{
 //?stored_web_state_.add_saved_web_page(url, wp, QDateTime::currentDateTime());
 //?saved_web_pages_[url] = wp;
}

void NDP_Application_State::init_when_last_saved(QDateTime qdt)
{
 if(when_last_saved_)
 {
  *when_last_saved_ = qdt;
 }
 else
  when_last_saved_ = new QDateTime(qdt);
}

void NDP_Application_State::declare_saved_now()
{
 init_when_last_saved(QDateTime::currentDateTime());
}

QString NDP_Application_State::get_last_saved_string()
{
 if(when_last_saved_)
  return when_last_saved_->toString();
 return QString();
}

void NDP_Application_State::absorb_data(QByteArray& qba)
{
 QDataStream qds(&qba, QIODevice::ReadOnly);
 qint64 wls;
 qds >> wls;// >> number_of_users_;
 init_when_last_saved(QDateTime::fromMSecsSinceEpoch(wls));

 qds >> saved_xml_by_url_;

}

void NDP_Application_State::supply_data(QByteArray& qba)
{
 QDataStream qds(&qba, QIODevice::WriteOnly);
 qint64 wls = when_last_saved_? when_last_saved_->toMSecsSinceEpoch() : 0;
 qds << wls;// << number_of_users_;

 qds << saved_xml_by_url_;
}



