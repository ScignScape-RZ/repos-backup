
#ifndef NDP_DATA_MANAGER__H
#define NDP_DATA_MANAGER__H


#include <QString>
#include <QMainWindow>
#include <QUrl>

#include <functional>

#include "accessors.h"

#include "flags.h"

#include "qunqlite-callback-parser.h"

#include "rzns.h"

RZNS_(GUI)

 class RZ_Email_Message;

_RZNS(GUI)

USING_RZNS(GUI)


RZNS_(NDP)
//namespace RZ{ namespace NDP{

class NDP_Data_Object_Bridge;
class NDP_Resource;
class NDP_Dialog;
class NDP_Comment;
class NDP__Comment_db;
class NDP__Comment_data;
class NDP__User_db;
class NDP__User_data;
class NDP_Application_State;

class NDP_Stored_Web_State;

class NDP_Application_Comment_State;
class NDP_Antemodel;
class NDP_User;

class NDP_Document_Web_Page;

class NDP_Document_XML;
class NDP_Document_Container;


class NDP_Data_Object_Bridge;

class NDP_Event;
class NDP_Project;
class NDP_Project_Initial;
class NDP_Project_Silo;
class NDP_Project_Record;

class NDP_Data_Manager  //?: NDP_Data_Callback_Manager
{
 NDP_Data_Object_Bridge* data_object_bridge_;

 typedef std::function<int(QString message, int arglength, void* data)> allobase_callback_type;
 typedef std::function<int(QString message, QString key, QString value, QString* ref)> index_callback_type;
 typedef std::function<QString()> error_callback_type;

 allobase_callback_type allobase_callback_;
 index_callback_type index_callback_;
 error_callback_type error_callback_;

 int current_type_id_count_;

 NDP_Project_Silo* ndp_project_silo_;

 void check_current_comment_data();
 void check_current_user_data();



public:

 ACCESSORS(allobase_callback_type ,allobase_callback)
 ACCESSORS(index_callback_type ,index_callback)
 ACCESSORS(error_callback_type ,error_callback)

 ACCESSORS(NDP_Project_Silo* ,ndp_project_silo)


 NDP_Data_Manager();


 template<typename Silo_type, typename Record_type>
 int save_new_silo_joinee(Silo_type& st, Record_type& rt)
 {
  QSharedPointer<QByteArray> qba(new QByteArray);
  rt.supply_data(*qba);
  QString key = QString("%1-%2").arg(st.type_id()).arg(rt.uid());
  void* args[2] = {&key, &qba};
  return callback("DB_Save_Generic_Data", 2, args);
 }

 template<typename Silo_type, typename Record_type>
 int load_silo_joinee(Silo_type& st, Record_type& rt)
 {
  QSharedPointer<QByteArray> qba(new QByteArray);
  QString key = QString("%1-%2").arg(st.type_id()).arg(rt.uid());
  void* args[2] = {&key, &qba};
  int call_result = callback("DB_Load_Generic_Data", 2, args);
  if(call_result == QUnQLite_Callback_Parser::All_Ok)
  {
   rt.absorb_data(*qba);
  }
  return call_result;
 }


 void init_dialog_db(QString data_root, QString file_name);
 void load_global_dialog_data();
 void save_current_dialog();

 int load_all_events(QList<NDP_Event*>& events);
 NDP_Event* load_event_by_date(QDate date);
 int save_event(QString code, NDP_Event* event);
 NDP_Event* load_event(QString code);

 NDP_Project* load_project(QString code);
 QString get_project_code(QString name, QString local_folder);

 void save_project_code(QString name, QString local_folder,
   int type_id, int uid);

 bool save_project(const NDP_Project& project);

 void save_project_code(NDP_Project_Record& pror);

 QString check_project_code(NDP_Project_Record& pror);

 template<typename Silo_type>
 int check_save_silo_record_count(Silo_type& st)
 {
  if(int new_record_count = st.check_save_record_count() )
  {
   return save_silo_record_count(st.type_name(), new_record_count);
  }
  else
  {
   return QUnQLite_Callback_Parser::All_Up_To_Date;
  }
 }

 void save_last_email(RZ_Email_Message& rem);
 void load_last_email(RZ_Email_Message& rem);
 void load_project_list(QList<NDP_Project_Record*>& projects);
 NDP_Project_Record* load_project(int uid);

 void callback_commit();


// void save_stored_web_page(QString indicator, NDP_Document_Web_Page*);
// void save_stored_web_page(NDP_Document_Web_Page* wp);
// NDP_User* load_user(NDP_User* user);
// void save_user(NDP_User* user, NDP_Application_State& qda);
// NDP_Document_Web_Page* load_stored_web_page(QString indicator);

 int init_db(QString data_root, QString file_name);

 void init_silos();
 int init_type_id_count();
 int save_type_id_count();
 int get_silo_record_count(QString type_name);
 int save_silo_record_count(QString type_name, int value);
 int get_type_id(QString type_name);
 int save_type_id(QString type_name, int value);


 void load_application_state(NDP_Application_State& qda);
 void save_application_state(NDP_Application_State& qda);

 void save_document_container_state(NDP_Document_Container& qdc);
 void load_document_container_state(NDP_Document_Container& qdc);

 QString get_last_error_code();
 QString get_db_path_value();
 QString get_db_last_open_value();
 QString get_db_string_value(QString key);


 int callback(QString message, int arglength, void* data);

 int callback(QString message, QString key, QString value);

 int callback(QString message, QString key, QString value, QString* ref);

 // int callback(QString message, void* data);
// int callback(QString message);


};

_RZNS(NDP)
//} } //_RZNS(NDP)

#endif
