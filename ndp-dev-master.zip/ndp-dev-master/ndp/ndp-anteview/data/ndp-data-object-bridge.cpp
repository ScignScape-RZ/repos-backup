
#include "ndp-data-object-bridge.h"



USING_RZNS(NDP)

NDP_Data_Object_Bridge::NDP_Data_Object_Bridge()
{

}

RZNS_(NDP)

#ifdef HIDE

template<>
void CLG_DB_Data_Object_Bridge::init_object
 <CLG_DB_Dialog, CLG_DB__Dialog_data>
 (CLG_DB_Dialog& obj, CLG_DB__Dialog_data& data)
{
 obj.Flags = data.Flags;
 obj.set_unique_id(data.unique_id());
 obj.set_internal_title(data.internal_title());
 obj.set_number_of_comments(data.number_of_comments());
// if(data.flags.is_local_file)
 obj.ref_url() = QUrl(data.ref_url());
// else

}


template<>
void CLG_DB_Data_Object_Bridge::init_data
 <CLG_DB_Dialog, CLG_DB__Dialog_data>
 (CLG_DB_Dialog& obj, CLG_DB__Dialog_data& data)
{
 data.Flags = obj.Flags;
 data.set_unique_id(obj.unique_id());
 data.set_internal_title(obj.internal_title());
 data.set_number_of_comments(obj.number_of_comments());
 data.set_ref_url(obj.ref_url().toString());
}



template<>
void CLG_DB_Data_Object_Bridge::init_paleo_object
 <CLG_DB_Dialog>(CLG_DB_Dialog& obj)
{
 obj.flags.is_not_registered = true;
}



template<>
void CLG_DB_Data_Object_Bridge::init_data
 <CLG_DB_Comment, CLG_DB__Comment_data>
 (CLG_DB_Comment& obj, CLG_DB__Comment_data& data)
{
 data.Flags = obj.Flags;
 data.set_unique_id(obj.unique_id());
 data.set_formats(obj.get_formats_string());
 data.set_raw_text(obj.raw_text());
}


template<>
void CLG_DB_Data_Object_Bridge::init_object
 <CLG_DB_Comment, CLG_DB__Comment_data>
 (CLG_DB_Comment& obj, CLG_DB__Comment_data& data)
{
 obj.Flags = data.Flags;
 obj.set_unique_id(data.unique_id());
 obj.parse_formats(data.formats());
 obj.set_raw_text(data.raw_text());
}

template<>
void CLG_DB_Data_Object_Bridge::init_paleo_object
 (CLG_DB_Comment& obj)
{
}


template<>
void CLG_DB_Data_Object_Bridge::init_object
 <CLG_DB_User, CLG_DB__User_data>
 (CLG_DB_User& obj, CLG_DB__User_data& data)
{
 obj.Flags = data.Flags;
 obj.set_unique_id(data.unique_id());
 obj.set_username(data.username());
 obj.set_password(data.password());
 obj.set_first_name(data.first_name());
 obj.set_last_name(data.last_name());
}

template<>
void CLG_DB_Data_Object_Bridge::init_data
 <CLG_DB_User, CLG_DB__User_data>
 (CLG_DB_User& obj, CLG_DB__User_data& data)
{
 data.Flags = obj.Flags;
 data.set_unique_id(obj.unique_id());
 data.set_username(obj.username());
 data.set_password(obj.password());
 data.set_first_name(obj.first_name());
 data.set_last_name(obj.last_name());
 data.set_template_uid(obj.get_template_uid());
}


#endif // HIDE

_RZNS(NDP)
