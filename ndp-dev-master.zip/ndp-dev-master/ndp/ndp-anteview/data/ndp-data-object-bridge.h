
#ifndef NDP_DATA_OBJECT_BRIDGE__H
#define NDP_DATA_OBJECT_BRIDGE__H


#include <QString>
#include <QMainWindow>
#include <QUrl>

#include <functional>

#include "accessors.h"

#include "flags.h"


#include "rzns.h"

RZNS_(NDP)
//namespace RZ{ namespace CLG{


class NDP_Data_Object_Bridge
{
public:

 NDP_Data_Object_Bridge();

 template<typename OBJECT_Type, typename DATA_Type>
 void init_object(OBJECT_Type& obj, DATA_Type& data);

 template<typename OBJECT_Type>
 void init_paleo_object(OBJECT_Type& obj);

 template<typename OBJECT_Type, typename DATA_Type>
 void init_data(OBJECT_Type& obj, DATA_Type& data);

};

_RZNS(NDP)
//} } //_RZNS(CLG)

#endif
