
#include "event-calendar-widget.h"

//#include "C:/Qt_mgw/src/qt-everywhere-opensource-src-5.6.0/qtbase/include/QtWidgets/qcalendarwidget.h"
//#include "C:/Qt_mgw/src/qt-everywhere-opensource-src-5.6.0/qtbase/src/widgets/widgets/qcalendarwidget.cpp"

//#include "calendar-widget/calendar-widget.cpp"

#include <QPainter>
#include <QDebug>

#include <QTableView>

Event_Calendar_Widget::Event_Calendar_Widget(QWidget* parent)
 : QCalendarWidget(parent)
{
 table_view_ = findChild<QTableView*>();


 if(table_view_)
 {
  table_view_->setContextMenuPolicy(Qt::CustomContextMenu);

  connect(table_view_, &QTableView::customContextMenuRequested,
    [this](QPoint p)
  {
   handle_context_menu(p);
  });
 }

 item_model_ = static_cast<QAbstractItemModel*>(findChild<QAbstractItemModel*>());

//   for(int i = 1; i < 7; ++i)
//   {
//    table_view_->setColumnWidth(i, 200);
//   }

//   for(int i = 1; i < 5; ++i)
//   {
//    table_view_->setRowHeight(i, 200);
//   }

//   table_view_->resizeColumnsToContents();

}

void Event_Calendar_Widget::handle_context_menu(QPoint p)
{
 int rh = table_view_->rowHeight(0);
 p -= QPoint(0, rh);
 QModelIndex qmi = table_view_->indexAt(p);

 int c = qmi.column();
 int r = qmi.row();

 QVariant v = item_model_->data(qmi);

 int day = v.toInt();

 int month_offset = 0;

 //qDebug() << "\nDAY: " << day << "\nCOL: " << c << "\nROW: " << r;

 if(day < 8)
 {
  if(r > 2)
   ++month_offset;
 }
 else if(day > 23)
 {
  if(r == 1)
   --month_offset;
 }

 int ms = monthShown() + month_offset;
 int ys = yearShown();

 QDate d(ys, ms, day);



 Q_EMIT context_menu_requested(d, mapToGlobal(p));

 //qDebug( ) << d.toString();

 //qDebug() << QString("%1, %2").arg(p.rx()).arg(p.ry());
}


//void Concert_Calendar_Widget::mousePressEvent(QMouseEvent *event)
//{
// if(event->button() == Qt::RightButton)
// {
//  qDebug() << "RB";
// }
// else
// {
//  qDebug() << "KB";

//  QCalendarWidget::mousePressEvent(event);
// }
//}

void Event_Calendar_Widget::paintCell(QPainter* painter, const QRect& rect, const QDate& date ) const
{
 if(date.year() == 2017 && date.month() == 4 && date.day() == 12)
 {
  QPixmap pixmap("/home/nlevisrael/NDP/habs.svg");
  //pixmap.from



  QRect r = rect;
  //QRect br;
  painter->save();

  //?
  r.adjust(3, 2, 0, 2);

  //?r.adjust(0, br.height() //10 //br.height()
  //        , 0, 0);

  //
  //painter->drawText(r, Qt::TextSingleLine, "Go HABS!", &r);
  QBrush qbr(QColor("yellow"));

  QRect r1 = rect;
  r1.adjust(2, 3, 0, 1);

  painter->fillRect(r1, qbr);

  painter->drawPixmap(r, pixmap);

  painter->restore();

 }
 else
 {
  QRect r = rect;
  r.adjust(0, 0, 5, 5);
  this->QCalendarWidget::paintCell(painter, r, date);
 }
}


// // //


//void QCalendarWidgetPrivate::_q_slotShowDate(const QDate &date)
//{
////    updateCurrentPage(date);
//}

//void QCalendarWidgetPrivate::_q_slotChangeDate(const QDate &date)
//{
////    _q_slotChangeDate(date, true);
//}

//void QCalendarWidgetPrivate::_q_slotChangeDate(const QDate &date, bool changeMonth)
//{
////    QDate oldDate = m_model->m_date;
////    m_model->setDate(date);
////    QDate newDate = m_model->m_date;
////    if (changeMonth)
////        showMonth(newDate.year(), newDate.month());
////    if (oldDate != newDate) {
////        update();
////        Q_Q(QCalendarWidget);
////        m_navigator->setDate(newDate);
////        emit q->selectionChanged();
////    }
//}

//void QCalendarWidgetPrivate::_q_editingFinished()
//{
////    Q_Q(QCalendarWidget);
////    emit q->activated(m_model->m_date);
//}

//void QCalendarWidgetPrivate::_q_prevMonthClicked()
//{
////    QDate currentDate = getCurrentDate().addMonths(-1);
////    updateCurrentPage(currentDate);
//}

//void QCalendarWidgetPrivate::_q_nextMonthClicked()
//{
////    QDate currentDate = getCurrentDate().addMonths(1);
////    updateCurrentPage(currentDate);
//}

//void QCalendarWidgetPrivate::_q_yearEditingFinished()
//{
////    Q_Q(QCalendarWidget);
////    yearButton->setText(yearEdit->text());
////    yearEdit->hide();
////    q->setFocusPolicy(oldFocusPolicy);
////    qApp->removeEventFilter(q);
////    spaceHolder->changeSize(0, 0);
////    yearButton->show();
////    QDate currentDate = getCurrentDate();
////    currentDate = currentDate.addYears(yearEdit->text().toInt() - currentDate.year());
////    updateCurrentPage(currentDate);
//}

//void QCalendarWidgetPrivate::_q_yearClicked()
//{
////    Q_Q(QCalendarWidget);
////    //show the spinbox on top of the button
////    yearEdit->setGeometry(yearButton->x(), yearButton->y(),
////                          yearEdit->sizeHint().width(), yearButton->height());
////    spaceHolder->changeSize(yearButton->width(), 0);
////    yearButton->hide();
////    oldFocusPolicy = q->focusPolicy();
////    q->setFocusPolicy(Qt::NoFocus);
////    yearEdit->show();
////    qApp->installEventFilter(q);
////    yearEdit->raise();
////    yearEdit->selectAll();
////    yearEdit->setFocus(Qt::MouseFocusReason);
//}

//void QCalendarWidgetPrivate::_q_monthChanged(QAction *act)
//{
////    monthButton->setText(act->text());
////    QDate currentDate = getCurrentDate();
////    QDate newDate = currentDate.addMonths(act->data().toInt()-currentDate.month());
////    updateCurrentPage(newDate);
//}
