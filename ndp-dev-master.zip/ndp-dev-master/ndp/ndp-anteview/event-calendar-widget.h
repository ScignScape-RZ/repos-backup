
#ifndef EVENT_CALENDAR_WIDGET__H
#define EVENT_CALENDAR_WIDGET__H

#include <QCalendarWidget>

//#include "C:/Qt_mgw/src/qt-everywhere-opensource-src-5.6.0/qtbase/include/QtWidgets/qcalendarwidget.h"

//#include "calendar-widget/calendar-widget.h"

#include <QTableView>

class Event_Calendar_Widget : public QCalendarWidget
{
 Q_OBJECT

 QTableView* table_view_;
 QAbstractItemModel* item_model_;

public:
 Event_Calendar_Widget(QWidget* parent = nullptr);
 void paintCell(QPainter* painter, const QRect& rect,
   const QDate& date) const;

// void mousePressEvent(QMouseEvent* event);

Q_SIGNALS:
 void context_menu_requested(QDate, QPoint);

public Q_SLOTS:
 void handle_context_menu(QPoint p);

};


#endif
