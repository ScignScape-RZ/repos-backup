
#ifndef NDP_ANTEMODEL__H
#define NDP_ANTEMODEL__H


#include <QString>
#include <QMainWindow>

#include <QUrl>
#include <QMap>

#include "accessors.h"

#include "flags.h"

#include "rzns.h"

RZNS_CLASS_DECLARE(GUI ,RZ_Email_Message)
USING_RZNS(GUI)

class PTN_Site_Manager_Bridge;

RZNS_CLASS_DECLARE(RZClasp ,RZ_QClasp_Eval)
RZNS_CLASS_DECLARE(RZClasp ,RZ_QClasp_Bridge)
USING_RZNS(RZClasp)

RZNS_(NDP)

//?class NDP_Resource;
class NDP_Data_Manager;
class NDP_Application_State;
class NDP_Project;
class NDP_Project_Record;


class NDP_Antemodel
{
 NDP_Data_Manager* data_manager_;

 NDP_Application_State* application_state_;

 QMap<QString, QString> substitutions_;

 QString current_rz_source_;
 QString current_substituted_rz_source_;

 RZ_QClasp_Eval* clasp_eval_;
 RZ_QClasp_Bridge* clasp_bridge_;

 typedef QMap<QString, QString> substitutions_type;

public:

 NDP_Antemodel(NDP_Data_Manager* data_manager);

 ACCESSORS__RGET(substitutions_type ,substitutions)

 ACCESSORS(QString ,current_rz_source)
 ACCESSORS(QString ,current_substituted_rz_source)

 void check_reset_rz_source();

 void save_last_email(RZ_Email_Message* rem);
 void load_last_email(RZ_Email_Message* rem);

 void load_project_list(QList<NDP_Project_Record*>& projects);

 void save_application_state();

 static void parse_string_plex(QString code, QMap<QString, QString>& result);


};

_RZNS(NDP)

#endif
