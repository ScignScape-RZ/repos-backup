
#include "ndp-anteview.h"

#include <QVector4D>
#include <QVector3D>
#include <QQuaternion>

#include <QBitArray>

#include <QNetworkRequest>
#include <QNetworkReply>

#include <QUrlQuery>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>

#include <QTimer>

//#include <QXmlQuery>
//#include <QXmlFormatter>
//#include <QXmlResultItems>
//#include <QtPrintSupport/QPrinter>

#include "application/pdf-document-widget.h"

#include "paraviews/intake-form-outline-dialog.h"

#include "paraviews/view-encodings-dialog.h"

#include "paraviews/accuweather-api-dialog.h"
#include "paraviews/blood-availability-dialog.h"
#include "paraviews/blood-availability-dialog-chart.h"


#include "paraviews/cloud-save-dialog.h"
#include "paraviews/cloud-open-dialog.h"

#include "paraviews/new-project-dialog.h"
#include "paraviews/view-web-page-dialog.h"
#include "paraviews/view-ocr-dialog.h"
#include "paraviews/view-rz-dialog.h"
#include "paraviews/view-rz-run-output-dialog.h"
#include "paraviews/view-pdf-dialog.h"
#include "paraviews/view-ocr-fields-dialog.h"

#include "paraviews/view-gecode-demo-dialog.h"

#include "paraviews/intake/intake-pain-history-dialog.h"
#include "paraviews/intake/intake-form-intro-dialog.h"
#include "paraviews/intake/intake-medical-history-dialog.h"
#include "paraviews/intake/intake-treatment-history-dialog.h"

#include "silotypes/ndp-project/ndp-project-initial.h"
#include "silotypes/ndp-project/ndp-project-record.h"
#include "silotypes/ndp-project/ndp-project-silo.h"
#include "silotypes/ndp-project/ndp-project.h"

#include "rz-gui-library/rz-send-email-dialog/rz-send-email-dialog.h"
#include "rz-gui-library/rz-send-email-dialog/rz-email-message.h"
#include "rz-gui-library/rz-send-email-dialog/rz-email-message-handler.h"

#include "rz-gui-library/rz-screenshot-dialog/rz-screenshot-dialog.h"

#include "ndp-tdcx-typed-array-document.h"
#include "ndp-tdcx-typed-array-decoder.h"
#include "ndp-tdcx-typed-array.h"
#include "ndp-tdcx-type-info.h"


USING_RZNS(GUI)
USING_RZNS(TransDCX)


#include "ndp-application.h"

#include "ndp-main-editor.h"

#include "data/ndp-data-manager.h"

#include <QDebug>
#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QMenuBar>
#include <QStringList>
#include <QMessageBox>

#include <QGroupBox>
//#include <QNetworkAccessManager>

#include <QScrollArea>
#include <QFileDialog>

#include <QDesktopServices>

#include <QBuffer>

#include <QRegularExpression>
#include <QRegularExpressionMatch>

//#include <QNetworkAccessManager>
//#include <QNetworkRequest>
//#include <QNetworkReply>

#include <QComboBox>
#include <QSpinBox>

#include <QJsonValue>

#include <QSharedPointer>

//#include "xml/json-to-xml.h"
//#include "paraviews/edit-event-dialog.h"
//#include "paraviews/edit-artist-dialog.h"
//#include "paraviews/show-artist-list-dialog.h"
//#include "paraviews/show-author-list-dialog.h"

//#include "paraviews/show-preferences-dialog.h"
//#include "paraviews/show-transactions-dialog.h"

#include "paraviews/refugee-info-dialog.h"
#include "paraviews/pregnancy-info-dialog.h"

//#include "paraviews/rz-chat-dialog.h"


//#include "application/pdf-document-widget.h"

#include "ndp-antemodel.h"

#include "paraviews/view-derm-dialog.h"


//#include "rz-gui-library/rz-send-email-dialog/rz-send-email-dialog.h"
//#include "rz-gui-library/rz-send-email-dialog/rz-email-message.h"
//#include "rz-gui-library/rz-send-email-dialog/rz-email-message-handler.h"

//#include "rz-gui-library/rz-screenshot-dialog/rz-screenshot-dialog.h"

//?USING_RZNS(GUI)

//?#include <QWebFrame>

//?#include <QwwRichTextButton>


//#define SIGNAL(X) SIGNAL(X)
//#define SLOT(X) SLOT(X)

USING_RZNS(NDP)

class Test_Type
{
public:

 QMap<QString, QByteArray> themap;

 void to_qbytearray(QByteArray& qba) const;
 void from_qbytearray(const QByteArray& qba);
};

void Test_Type::to_qbytearray(QByteArray& qba) const
{
 QDataStream qds(&qba, QIODevice::WriteOnly);
 qds << themap;
}

void Test_Type::from_qbytearray(const QByteArray& qba)
{
 QDataStream qds(qba);
 qds >> themap;
}

template<>
struct TDCX_Type_Info<Test_Type> : TDCX_Byte_Array_Storage
{
 static QString get_QString_Type_Name(){ return "Test_Type"; }
 static int get_Type_Code(){ return 1; }
};

//template<>
//void TDCX_To_QByteArray<Test_Type>(const Test_Type& tt, QByteArray& qba)
//{
// //?
// tt.to_exchange(qba);
//// QDataStream qds(&qba, QIODevice::WriteOnly);
//// qds << qmbda;
//}

//template<>
//void TDCX_From_QByteArray<Test_Type>(Test_Type& tt, const QByteArray& qba)
//{
// tt.from_exchange(qba);
//// QDataStream qds(qba);
//// qds >> qmbda;
//}



NDP_Anteview::NDP_Anteview(NDP_Application* app, QWidget* parent)
 : QMainWindow(parent), app_(app), model_(nullptr), outline_dialog_(nullptr),
   current_project_(nullptr), potential_current_project_record_(nullptr),
   data_manager_(app->data_manager()) //, qnam_(nullptr)
    //current_document_info_(nullptr)
{

 qRegisterMetaType<RZ::NDP::Intake_Pain_History_Dialog*>();
 qRegisterMetaType<RZ::NDP::Intake_Pain_History_Dialog>();

 qRegisterMetaType<RZ::NDP::Intake_Form_Intro_Dialog*>();
 qRegisterMetaType<RZ::NDP::Intake_Form_Intro_Dialog>();

// qRegisterMetaType<RZ::NDP::View_Web_Page_Dialog*>();
// qRegisterMetaType<RZ::NDP::View_Web_Page_Dialog>();

 qRegisterMetaType<RZ::NDP::Intake_Medical_History_Dialog*>();
 qRegisterMetaType<RZ::NDP::Intake_Medical_History_Dialog>();

 qRegisterMetaType<RZ::NDP::Intake_Treatment_History_Dialog*>();
 qRegisterMetaType<RZ::NDP::Intake_Treatment_History_Dialog>();

//  qRegisterMetaType<RZ::CLG::CLG_NYT_Article*>();
//  qRegisterMetaType<RZ::CLG::CLG_NYT_Article>();

//  qRegisterMetaType<RZ::CLG::CLG_NYT_Concept*>();
//  qRegisterMetaType<RZ::CLG::CLG_NYT_Concept>();
}

void NDP_Anteview::init()
{
 rz_print_results_text_edit_ = nullptr;

 app_->set_print_callback([this](QString str)
 {
  if(rz_print_results_text_edit_)
  {
   QString rt = rz_print_results_text_edit_->document()->toPlainText();
   rt += str;
   rz_print_results_text_edit_->document()->setPlainText(rt);
  }
 });

 model_ = new NDP_Antemodel(data_manager_);

 menubar_ = new QMenuBar(this);

 QMenu* forms_menu =  menubar_->addMenu("Forms");

 QAction* outline_action = forms_menu->addAction("Outline");

 connect(outline_action, SIGNAL(triggered()),
   this, SLOT(outline_action_requested()));


 QAction* view_encodings_action = forms_menu->addAction("View Encodings");

 connect(view_encodings_action, SIGNAL(triggered()),
   this, SLOT(view_encodings_action_requested()));


 menubar_->addSeparator();

// QMenu* projects_menu =  menubar_->addMenu("Projects");
// QAction* new_project = projects_menu->addAction("New");
// connect(new_project, SIGNAL(triggered()),
//   this, SLOT(new_project_requested()));
// QAction* edit_current_project = projects_menu->addAction("Edit Current Project");
// connect(edit_current_project, SIGNAL(triggered()),
//   this, SLOT(edit_current_project_requested()));
// QAction* load_existing_project = projects_menu->addAction("Open Project");
// connect(load_existing_project, SIGNAL(triggered()),
//   this, SLOT(load_existing_project_requested()));

// QMenu* rz_menu =  menubar_->addMenu("R/Z");
// QAction* open_rz = rz_menu->addAction("Open");
// connect(open_rz, SIGNAL(triggered()),
//   this, SLOT(handle_open_rz()));
// QAction* view_rz_substitutions = rz_menu->addAction("View Substitutions");
// connect(view_rz_substitutions, SIGNAL(triggered()),
//   this, SLOT(handle_view_rz_substitutions()));


 QMenu* web_menu =  menubar_->addMenu("Web");

 QAction* load_page_in_window = web_menu->addAction("Load Page in Window");
 connect(load_page_in_window, SIGNAL(triggered()),
   this, SLOT(view_web_page_dialog_requested()));


 //QAction* view_ocr_dialog =
 web_menu->addAction("View OCR Dialog", this,
   SLOT(view_ocr_dialog_requested()) );
// connect(load_page_in_window, SIGNAL(triggered()),
//   this, SLOT(view_web_page_dialog_requested()));

 web_menu->addAction("View GeCoDE Demo", this,
   SLOT(view_gecode_demo_requested()) );


 QAction* pdf_dialog = web_menu->addAction("PDF Dialog");

 connect(pdf_dialog, SIGNAL(triggered()),
   this, SLOT(pdf_dialog_requested()));



 QAction* screenshot = web_menu->addAction("Screenshot");

 connect(screenshot, SIGNAL(triggered()),
   this, SLOT(screenshot_dialog_requested()));

 QAction* take_screenshot_action = web_menu->addAction("Take Screenshot");

 connect(take_screenshot_action, SIGNAL(triggered()),
   this, SIGNAL(take_screenshot_requested()));


 web_menu->addAction("Derm", this, SLOT(derm_requested()));

 QAction* accuweather_api_action = web_menu->addAction("Accuweather API");

 connect(accuweather_api_action, SIGNAL(triggered()),
   this, SLOT(launch_accuweather_api_action_requested()));


 QAction* blood_availability_api_action = web_menu->addAction("Blood Availability API");

 connect(blood_availability_api_action, SIGNAL(triggered()),
   this, SLOT(launch_blood_availability_api_requested()));

 QAction* blood_availability_api_action_chart = web_menu->addAction("Blood Availability API Chart");

 connect(blood_availability_api_action_chart, SIGNAL(triggered()),
   this, SLOT(launch_blood_availability_api_requested_chart()));


 QAction* refugee_info_action = web_menu->addAction("Refugee Info");

 connect(refugee_info_action, SIGNAL(triggered()),
   this, SLOT(launch_refugee_info_requested()));


 QAction* pregnancy_info_action = web_menu->addAction("Pregnancy Info");

 connect(pregnancy_info_action, SIGNAL(triggered()),
   this, SLOT(launch_pregnancy_info_requested()));


 menubar_->addSeparator();
 menubar_->addAction("Language");
 menubar_->addAction("Help");
 menubar_->addAction("About");

 setMenuBar(menubar_);

 centerview_ = new NDP_Centerview(this);
//? centerview_->init(last_saved_string);
 centerview_->init("");



 controls_dock_widget_ = new QDockWidget(this);
 controls_dock_widget_->setObjectName(QString::fromUtf8("controlsDockWidget"));
 controls_dock_widget_->setEnabled(true);
 controls_dock_widget_->setFloating(false);
 controls_dock_widget_->setFeatures(QDockWidget::AllDockWidgetFeatures);
 controls_dock_widget_->setAllowedAreas(Qt::BottomDockWidgetArea|Qt::TopDockWidgetArea);
 QWidget* dockWidgetContents = new QWidget();
 dockWidgetContents->setObjectName(QString::fromUtf8("dockWidgetContents"));

 QVBoxLayout* vboxLayout = new QVBoxLayout(dockWidgetContents);

 top_layout_ = new QHBoxLayout;

 top_layout_->setContentsMargins(0, 0, 0, 0);

  //?add_new_webview_tab(general_welcome_, "Welcome");


 //add_new_webview_tab(comment_summary_, "Comments...");

//? document_info_tabview_ = new Document_Info_Tabview(this);

  QFrame* top_frame = new QFrame(this);
  top_frame->setLayout(top_layout_);

  QString style_sheet =
    "QFrame {padding:0px;margin0px}"
    ;

  top_frame->setStyleSheet(style_sheet);

  top_frame->setContentsMargins(3, 0, 3, 0);

  top_frame->setFrameStyle(QFrame::Box | QFrame::Sunken);

  top_frame->setBackgroundRole(QPalette::ToolTipText);
  top_frame->setAutoFillBackground(true);
  top_frame->setLineWidth(1);
  top_frame->setMidLineWidth(8);


 vboxLayout->addWidget(top_frame);

 QHBoxLayout* hboxLayout = new QHBoxLayout(); // dockWidgetContents);
 hboxLayout->setObjectName(QString::fromUtf8("hboxLayout"));
 hboxLayout->setContentsMargins(4, 0, 4, 0);
 QSpacerItem* horizontalSpacer = new QSpacerItem(20, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

 hboxLayout->addItem(horizontalSpacer);

 QHBoxLayout* _2 = new QHBoxLayout();
 _2->setObjectName(QString::fromUtf8("_2"));

 page_label_ = new QLabel(dockWidgetContents);
 page_label_->setObjectName(QString::fromUtf8("page_label_"));

 _2->addWidget(page_label_);

 page_spin_box_ = new QSpinBox(dockWidgetContents);
 page_spin_box_->setObjectName(QString::fromUtf8("page_spin_box_"));
 page_spin_box_->setEnabled(false);

 _2->addWidget(page_spin_box_);


 hboxLayout->addLayout(_2);

 QSpacerItem* horizontalSpacer_2 = new QSpacerItem(20, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

 hboxLayout->addItem(horizontalSpacer_2);

 QHBoxLayout* _3 = new QHBoxLayout();
 _3->setObjectName(QString::fromUtf8("_3"));

 search_label_ = new QLabel(dockWidgetContents);
 search_label_->setObjectName(QString::fromUtf8("search_label_"));
 search_label_->setTextFormat(Qt::AutoText);

 _3->addWidget(search_label_);

 search_line_edit_ = new QLineEdit(dockWidgetContents);
 search_line_edit_->setObjectName(QString::fromUtf8("search_line_edit_"));
 search_line_edit_->setEnabled(false);

 _3->addWidget(search_line_edit_);

 search_combo_box_ = new QComboBox(dockWidgetContents);
 search_combo_box_->setObjectName(QString::fromUtf8("search_combo_box_"));
 search_combo_box_->setEnabled(false);

 _3->addWidget(search_combo_box_);

 find_button_ = new QPushButton(dockWidgetContents);
 find_button_->setObjectName(QString::fromUtf8("find_button_"));
 find_button_->setEnabled(false);

 _3->addWidget(find_button_);

 clear_button_ = new QPushButton(dockWidgetContents);
 clear_button_->setObjectName(QString::fromUtf8("clear_button_"));
 clear_button_->setEnabled(false);

 _3->addWidget(clear_button_);


 hboxLayout->addLayout(_3);

 QSpacerItem* spacerItem = new QSpacerItem(20, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

 hboxLayout->addItem(spacerItem);

 scale_label_ = new QLabel(dockWidgetContents);
 scale_label_->setObjectName(QString::fromUtf8("label"));

 hboxLayout->addWidget(scale_label_);

 scale_combo_box_ = new QComboBox(dockWidgetContents);
 scale_combo_box_->setObjectName(QString::fromUtf8("scale_combo_box_"));
 scale_combo_box_->setEnabled(true);

 hboxLayout->addWidget(scale_combo_box_);

 QSpacerItem* horizontalSpacer_3 = new QSpacerItem(20, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

 hboxLayout->addItem(horizontalSpacer_3);

 vboxLayout->addLayout(hboxLayout);

 dockWidgetContents->setLayout(vboxLayout);

 controls_dock_widget_->setWidget(dockWidgetContents);
 this->addDockWidget(static_cast<Qt::DockWidgetArea>(4), controls_dock_widget_);



 connect(page_spin_box_, SIGNAL(valueChanged(int)),
         centerview_->pdf_document(), SLOT(setPage(int)));

 connect(centerview_->pdf_document(), SIGNAL(pageChanged(int)),
         page_spin_box_, SLOT(setValue(int)));

 connect(scale_combo_box_, SIGNAL(currentIndexChanged(int)),
         centerview_, SLOT(scale_document(int)));


 connect(centerview_, SIGNAL(activate_screenshot()),
         this, SLOT(activate_screenshot_requested()));


// connect(documentWidget, SIGNAL(textSelected(const QString &)),
//         this, SLOT(showSelectedText(const QString &)));

//?
// connect(search_line_edit_, SIGNAL(returnPressed()), this, SLOT(searchDocument()));
// connect(find_button_, SIGNAL(clicked()), this, SLOT(searchDocument()));

 connect(clear_button_, SIGNAL(clicked()), centerview_->pdf_document(), SLOT(setPage()));

 connect(centerview_->pdf_document(), SIGNAL(search_action_triggered(QString)),
         this, SLOT( activate_topic_search(QString) //activate_api_search(QString)
                     )

         );

 connect(centerview_->pdf_document(), SIGNAL(api_search_action_triggered(QString)),
         this, SLOT( activate_api_search(QString)
                     )

         );

 QObject::connect(clear_button_, SIGNAL(clicked()), search_line_edit_, SLOT(clear()));


 connect(centerview_, SIGNAL(button_open_pdf_requested()),
  this, SLOT(handle_open_pdf()));

 connect(centerview_, SIGNAL(button_open_rz_requested()),
  this, SLOT(handle_open_rz()));

 connect(centerview_, SIGNAL(button_run_rz_requested()),
  this, SLOT(handle_run_rz()));


 connect(centerview_, SIGNAL(button_open_html_requested()),
  this, SLOT(handle_open_html()));


 connect(centerview_, SIGNAL(button_open_ngml_requested()),
  this, SLOT(handle_open_ngml()));

// connect(centerview_, SIGNAL(button_convert_ngml_requested()),
//  this, SLOT(handle_convert_ngml()));


 connect(centerview_, SIGNAL(button_convert_ngml_requested()),
  this, SLOT(handle_convert_ngml()));


 connect(centerview_, SIGNAL(button_open_project_requested()),
  this, SLOT(handle_open_project()));

 connect(centerview_, SIGNAL(button_preview_project_requested()),
  this, SLOT(handle_preview_project()));


 connect(centerview_, SIGNAL(button_save_all_requested()),
  this, SLOT(handle_save_all()));


 scale_combo_box_->setCurrentIndex(3);

 retranslate_ui(this);

 setCentralWidget(centerview_);

 init_line_buttons();
}

void NDP_Anteview::delete_dialog(QDialog* dlg)
{
 dlg->close();
 dlg->deleteLater();
}



void NDP_Anteview::launch_blood_availability_api_requested_chart()
{
 Blood_Availability_Dialog_Chart* dlg = new Blood_Availability_Dialog_Chart(this);

 //?current_dialog_ = dlg;

 connect(dlg, SIGNAL(canceled(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));

 dlg->show();


}



void NDP_Anteview::launch_blood_availability_api_requested()
{
 Blood_Availability_Dialog* dlg = new Blood_Availability_Dialog(this);

 //?current_dialog_ = dlg;

 connect(dlg, SIGNAL(canceled(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));

 dlg->show();


}

void NDP_Anteview::launch_pregnancy_info_requested()
{
 Pregnancy_Info_Dialog* dlg = new Pregnancy_Info_Dialog(this);

 connect(dlg, SIGNAL(canceled(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));

 dlg->show();

}



void NDP_Anteview::launch_refugee_info_requested()
{
 Refugee_Info_Dialog* dlg = new Refugee_Info_Dialog(this);

 connect(dlg, SIGNAL(canceled(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));

 dlg->show();


}


void NDP_Anteview::launch_accuweather_api_action_requested()
{
 Accuweather_Api_Dialog* dlg = new Accuweather_Api_Dialog(this);

 connect(dlg, SIGNAL(canceled(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));

 dlg->show();

}




void NDP_Anteview::view_encodings_action_requested()
{
 View_Encodings_Dialog* dlg = new View_Encodings_Dialog(this);

 connect(dlg, SIGNAL(canceled(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));

 dlg->show();

}


void NDP_Anteview::outline_action_requested()
{
 outline_dialog_ = new Intake_Form_Outline_Dialog(this);

 connect(outline_dialog_, SIGNAL(canceled(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));

 connect(outline_dialog_, SIGNAL(secondary_dialog_class_requested(QDialog*, QString)),
   this, SLOT(run_secondary_dialog(QDialog*, QString)));

 connect(outline_dialog_, SIGNAL(secondary_dialog_class_requested_right(QDialog*, QString)),
   this, SLOT(run_secondary_dialog_right(QDialog*, QString)));




 QPoint xy = centerview_->get_main_notebook_widget_top_left_point();

 outline_dialog_->move(xy); //xy.x(), xy.y());

 outline_dialog_->show();

}

void NDP_Anteview::derm_requested()
{
 View_Derm_Dialog* dlg = new View_Derm_Dialog(this);

 connect(dlg, SIGNAL(canceled(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));

 dlg->show();
}


void NDP_Anteview::cloud_open_overall_form()
{
 Cloud_Open_Dialog* dlg = new Cloud_Open_Dialog(this, "http://localhost:1726/ndp-test-open");

 connect(dlg, SIGNAL(canceled(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));

 connect(this, SIGNAL(cloud_open_result_posted(QString)),
   dlg, SLOT(receive_cloud_open_result_posted(QString)));


 connect(dlg, SIGNAL(open_requested(QString, QString)),
   this, SLOT(cloud_open(QString, QString)));

 dlg->show();

}




void NDP_Anteview::cloud_save_overall_form()
{
 Cloud_Save_Dialog* dlg = new Cloud_Save_Dialog(this, "http://localhost:1726/ndp-test");

 connect(dlg, SIGNAL(canceled(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));

 connect(this, SIGNAL(cloud_save_result_posted(QString)),
   dlg, SLOT(receive_cloud_save_result_posted(QString)));


 connect(dlg, SIGNAL(save_requested(QString, QString)),
   this, SLOT(cloud_save(QString, QString)));

 dlg->show();

}

void NDP_Anteview::cloud_open(QString url, QString key)
{
 QNetworkAccessManager* qnam = new QNetworkAccessManager;

 //QString addr = QString("http://%1").arg(url);
 QString addr = url; //QString("http://localhost:1726/ndp-test-open");//.arg(url);

 QUrl aurl(addr);
// QUrlQuery urlq;
// urlq.addQueryItem("key", key);
// aurl.setQuery(urlq);


 QNetworkRequest req;

//? qDebug() << "Host: " << host << "URL: " << url.toString();

 req.setUrl(aurl);
 req.setHeader(QNetworkRequest::ContentTypeHeader, "raw");


 QNetworkReply* reply = qnam->post(req, key.toLatin1());

 QObject::connect(reply, &QNetworkReply::finished,
  [this, reply]()
 {
  QString text = QString::fromLatin1( reply->readAll() );
  confirm_cloud_open(text);
  reply->deleteLater();
  Q_EMIT(cloud_save_result_posted(text));
 });
}

void NDP_Anteview::cloud_save(QString url, QString key)
{
 QNetworkAccessManager* qnam = new QNetworkAccessManager;

 //QString addr = QString("http://%1").arg(url);
 QString addr = url; //QString("http://localhost:1726/ndp-test");//.arg(url);

 QUrl aurl(addr);
// QUrlQuery urlq;
// urlq.addQueryItem("key", key);
// aurl.setQuery(urlq);

 QString enc;
 QString qqenc;
 QMap<QString, QByteArray> qbas;

 get_overall_form_data(enc, qqenc, qbas);

 enc.prepend(key + "\n\n\n");

 QNetworkRequest req;

//? qDebug() << "Host: " << host << "URL: " << url.toString();

 req.setUrl(aurl);
 req.setHeader(QNetworkRequest::ContentTypeHeader, "raw");


 QNetworkReply* reply = qnam->post(req, enc.toLatin1());

 QObject::connect(reply, &QNetworkReply::finished,
  [this, reply]()
 {
  QString text = QString::fromLatin1( reply->readAll() );
  qDebug() << "TEXT: " << text;
  reply->deleteLater();
  Q_EMIT(cloud_save_result_posted(text));
 });
}

//void NDP_Anteview::cloud_open_overall_form()
//{

//}

void NDP_Anteview::save_overall_form()
{
 QString enc;
 QString qqenc;
 QMap<QString, QByteArray> qbas;

 get_overall_form_data(enc, qqenc, qbas);

 QString path = QFileDialog::getSaveFileName(this, "Select File (to save complete form)", DEMO_DIR);
 QFile file (path);
 file.open(QIODevice::WriteOnly);
 QDataStream outstream(&file);

 outstream << qbas;
 file.close();


 QFile file1 (path + ".enc.txt");
 file1.open(QIODevice::WriteOnly);
 QTextStream outstream1(&file1);

 outstream1 << enc;
 file1.close();

 QFile file2 (path + ".qenc.txt");
 file2.open(QIODevice::WriteOnly);
 QTextStream outstream2(&file2);

 outstream2 << qqenc;
 file2.close();


}

void NDP_Anteview::get_overall_form_data(QString& enc, QString& qqenc,
  QMap<QString, QByteArray>& qbas)
{
 QMapIterator<QString, QDialog*> it(active_secondary_dialogs_);

 while(it.hasNext())
 {
  it.next();

  QString dname = it.key();
  QDialog* dia = it.value();

  //qDebug() << "DN: " << dname;

  QByteArray& qba = qbas[dname];
  if(dname == "RZ::NDP::Intake_Treatment_History_Dialog")
  {
   RZ::NDP::Intake_Treatment_History_Dialog* d = qobject_cast<RZ::NDP::Intake_Treatment_History_Dialog*>(dia);
   if(d)
   {
    d->write_state_to(qba);
   }
  }
  else if(dname == "RZ::NDP::Intake_Pain_History_Dialog")
  {
   RZ::NDP::Intake_Pain_History_Dialog* d = qobject_cast<RZ::NDP::Intake_Pain_History_Dialog*>(dia);
   if(d)
   {
    d->write_state_to(qba);
   }
  }

  //   RZ::NDP::Intake_Treatment_History_Dialog
  //   RZ::NDP::Intake_Pain_History_Dialog

 }


 typedef std::uint32_t u32;

 TDCX_Storing_Profile profile( (Bitsize) 40 );
 TDCX_Typed_Array_Document tad;

 Test_Type tt;
 tt.themap = qbas;

 tad.store(tt, profile);

 //?QString encode = tad.encode();

 tad.set_quaternion_encode_string("nathaniellevisrael1973zz");

 enc = tad.quaternion_encode(qqenc);

 //?qDebug() << "ENC: " << encode;

#ifdef HIDE
 QFile file3 (path + ".v1.txt");
 file3.open(QIODevice::WriteOnly);
 QTextStream outstream3(&file3);

 int i = 0;
 for(quint64 uv : tad.uvals)
 {
  ++i;
  outstream3 << QString("%1: %2\n").arg(i).arg(uv);
 }

 file3.close();

 QFile file4 (path + ".v2.txt");
 file4.open(QIODevice::WriteOnly);
 QTextStream outstream4(&file4);

 i = 0;
 for(quint64 quv : tad.qquvals)
 {
  ++i;
  outstream4 << QString("%1: %2\n").arg(i).arg(quv);
 }

 file4.close();

 QVector<quint64> vals;
 TDCX_Typed_Array_Decoder::decode_to_numeric_values(encode, vals);

 QVector<QVector3D> qvals;

 QVector<quint64> uvals;
 QVector<QString> ustr;

 for(int i = 0; i < vals.length(); ++i)
 {
  quint64 v = vals[i];

  // v is actually 5 bytes
  // 14 bits each
  quint64 mm1 = (2^14) - 1;
  quint64 mask1 = 0b11111111111111;
  quint64 mask2 = mask1 << 14;

  quint64 mask_1 = 0b111111111111;
  quint64 mask3 = mask_1 << 28;

  //QBitArray qbita1(42);
  //qbita1.

  QString qv = QString::number(v, 2);
  ustr.push_back(qv);

  QString qm1 = QString::number(mm1, 2);

  QString m1 = QString::number(mask1, 2);
  QString m2 = QString::number(mask2, 2);
  QString m3 = QString::number(mask3, 2);

  quint64  _u1 = (v & mask3);
  quint64  _u2 = (v & mask2);
  quint64  _u3 = (v & mask1);

  QString _um1 = QString::number(_u1, 2);
  QString _um2 = QString::number(_u2, 2);
  QString _um3 = QString::number(_u3, 2);

  quint16  u1 = _u1 >> 28;
  quint16  u2 = _u2 >> 14;
  quint16  u3 = _u3;

  QString _uq1 = QString::number(u1, 2);
  QString _uq2 = QString::number(u2, 2);
  QString _uq3 = QString::number(u3, 2);

  QString um1 = QString::number(u1, 2);
  QString um2 = QString::number(u2, 2);
  QString um3 = QString::number(u3, 2);

  float u1f = (float) u1;
  //memcpy(&u1f, &u1, sf);
  float u2f = (float) u2;
  //memcpy(&u2f, &u2, sf);
  float u3f = (float) u3;
  //memcpy(&u3f, &u3, sf);


  quint64 u = (((quint64)u1) << 28) + (((quint64)u2) << 14) + (quint64)u3;

  QString quu = QString::number(u, 2);

  qvals.push_back({u1f, u2f, u3f});

  uvals.push_back(u);
 }

 QByteArray code("nathaniellevisrael1973zz");

 QVector4D code_vecs {0, 0, 0, 0};

 for(int i = 0; i < 20; i += 5)
 {
  bool ok = false;
  int x = code.mid(i, 5).toInt(&ok, 32);
  float f = (float) x;
  code_vecs[i/5] = f;
 }

 QQuaternion qq(code_vecs);

// QQuaternion qq { 2.0f, 1.0f, 0.0f, 0.0f};

 qq.normalize();


 QVector<QVector3D> qqvals;
 for(QVector3D& qval : qvals)
 {
  QVector3D rotated = qq.rotatedVector(qval);
  qqvals.push_back(rotated);
//  QVector3D test1 {0, 0, 0};
//  float s = qq.scalar();
//  qq.setScalar(-s);
//  QVector3D result1 = qq.rotatedVector(result);
 }

 QFile vfile (path + ".vals1.txt");
 vfile.open(QIODevice::WriteOnly);
 QTextStream voutstream(&vfile);

 int i = 0;
 for(quint64 v : vals)
 {
  ++i;
  voutstream << QString("\n%1: %2").arg(i).arg(v);
  voutstream << QString("\n %1= %2").arg(i).arg(uvals[i - 1]);
  voutstream << QString("\n  %1? %2").arg(i).arg(ustr[i - 1]);
   }

 voutstream << QString("\n\n qq: {%1, %2, %3, %4} \n\n").arg(qq.x()).arg(qq.y()).arg(qq.z()).arg(qq.scalar());
 voutstream << "\n\n qqvals=== \n\n";

 i = 0;
 for(QVector3D& v : qqvals)
 {
  ++i;
  voutstream << QString("\n%1: {%2, %3, %4}").arg(i).arg(v.x()).arg(v.y()).arg(v.z());
 }


 voutstream << "\n\n qvals=== \n\n";
 i = 0;
 for(QVector3D& v : qvals)
 {
  ++i;
  voutstream << QString("\n%1: {%2, %3, %4}").arg(i).arg(v.x()).arg(v.y()).arg(v.z());
  voutstream << QString("\n %1= {%2, %3, %4}").arg(i).arg((quint32)v.x()).arg((quint32)v.y()).arg((quint32)v.z());
 }

 vfile.close();



 QFile qqfile (path + ".qenc.txt");
 qqfile.open(QIODevice::WriteOnly);
 QDataStream qqoutstream(&qqfile);

 int vl = qvals.length();

 qqoutstream << vl;
 qqoutstream << qq;

 qqoutstream << qvals;

 qqoutstream << qqvals;
 qqfile.close();


// dcr.decode();

// QVector<QSharedPointer<Test_Type>> values;
// dcr.reload(values);

#endif// HIDE

}

void NDP_Anteview::load_overall_form(QMap<QString, QByteArray>& qbas)
{
 if(!outline_dialog_)
 {
  outline_action_requested();
 }
 QMapIterator<QString, QByteArray> it(qbas);

 while(it.hasNext())
 {
  it.next();
  QString dname = it.key();
  const QByteArray& qba = it.value();

  if(dname == "RZ::NDP::Intake_Treatment_History_Dialog")
  {
   //?
   run_secondary_dialog(outline_dialog_, dname);
   QDialog* dia = active_secondary_dialogs_[dname];
   RZ::NDP::Intake_Treatment_History_Dialog* d = qobject_cast<RZ::NDP::Intake_Treatment_History_Dialog*>(dia);
   if(d)
   {
    d->read_state_from(qba);
   }
  }

  if(dname == "RZ::NDP::Intake_Pain_History_Dialog")
  {
   //?
   run_secondary_dialog(outline_dialog_, dname);
   QDialog* dia = active_secondary_dialogs_[dname];
   RZ::NDP::Intake_Pain_History_Dialog* d = qobject_cast<RZ::NDP::Intake_Pain_History_Dialog*>(dia);
   if(d)
   {
    d->read_state_from(qba);
   }
  }

 }
}

void NDP_Anteview::confirm_cloud_open(QString text)
{
 TDCX_Typed_Array_Decoder tar(text);
 tar.decode();

 QVector<QSharedPointer<Test_Type>> values;
 tar.reload(values);
 QMap<QString, QByteArray>& qbas = values.first()->themap;
 load_overall_form(qbas);
}



void NDP_Anteview::load_overall_form()
{
 QString path = QFileDialog::getOpenFileName(this, "Reload Form from ... (Select File)", DEMO_DIR);
 QFile file (path);
 if(file.open(QIODevice::ReadOnly))
 {
  if(path.endsWith(".enc.txt"))
  {
   QTextStream qts(&file);
   QString encode;
   qts >> encode;
   qDebug() << encode;
   TDCX_Typed_Array_Decoder tar(encode);
   tar.decode();

   QVector<QSharedPointer<Test_Type>> values;
   tar.reload(values);
   QMap<QString, QByteArray>& qbas = values.first()->themap;
   load_overall_form(qbas);
  }
  else if(path.endsWith(".qenc.txt"))
  {
   QTextStream qts(&file);
   QString encode;
   qts >> encode;
   qDebug() << encode;
   TDCX_Typed_Array_Decoder tar(encode);
   tar.set_quaternion_encode_string("nathaniellevisrael1973zz");
   tar.quaternion_decode();
   QVector<QSharedPointer<Test_Type>> values;
   tar.reload(values);
   QMap<QString, QByteArray>& qbas = values.first()->themap;
   load_overall_form(qbas);

#ifdef HIDE
   QDataStream qds(&file);

   int vl;
   QQuaternion qq;
   qds >> vl;
   qds >> qq;

   QVector<QVector3D> qvals;
   qds >> qvals;


   //?qq.normalize();

   QQuaternion qq1 = qq;

   float s = qq.scalar();
   qq.setScalar(-s);

   QVector<QVector3D> qqvals;

   qds >> qqvals;

   QVector<QVector3D> vals;
   for(QVector3D& qqval : qqvals)
   {
    QVector3D val = qq.rotatedVector(qqval);
    //?QVector3D val = qq.rotatedVector(qqval);
    vals.push_back(val);
   }

   //?vals.resize(vl);

   // vals will actually have 5 bytes
   QVector<quint64> val64s;
   for(int i = 0; i < qvals.length(); ++i)
   {
    float u1f = vals[i].x();

    quint16 u1ff = qRound(u1f);
     //?memcpy(&u1ff, &u1f, sf);
    float u2f = vals[i].y();
    quint16 u2ff = qRound(u2f);
     //?memcpy(&u2ff, &u2f, sf);
    float u3f = vals[i].z();
    quint16 u3ff = qRound(u3f);
     //?memcpy(&u3ff, &u3f, sf);

    quint64 u = ( ((quint64)u1ff) << 28) + (((quint64)u2ff) << 14) + u3ff;
    val64s.push_back(u);
   }

   QFile vfile (path + ".vals2.txt");
   vfile.open(QIODevice::WriteOnly);

   QTextStream voutstream(&vfile);

   int i = 0;
   for(quint64 v : val64s)
   {
    ++i;
    voutstream << QString("\n%1: %2").arg(i).arg(v);
   }

   voutstream << QString("\n\n qq: {%1, %2, %3, %4} \n\n").arg(qq.x()).arg(qq.y()).arg(qq.z()).arg(qq.scalar());
   voutstream << QString("\n\n qq1: {%1, %2, %3, %4} \n\n").arg(qq1.x()).arg(qq1.y()).arg(qq1.z()).arg(qq1.scalar());

   voutstream << "\n\n qqvals=== \n\n";

   i = 0;
   for(QVector3D& v : qqvals)
   {
    ++i;
    voutstream << QString("\n%1: {%2, %3, %4}").arg(i).arg(v.x()).arg(v.y()).arg(v.z());
   }

   voutstream << "\n\n qvals=== \n\n";
   i = 0;
   for(QVector3D& v : qvals)
   {
    ++i;
    voutstream << QString("\n%1: {%2, %3, %4}").arg(i).arg(v.x()).arg(v.y()).arg(v.z());
    voutstream << QString("\n %1= {%2, %3, %4}").arg(i).arg((quint32)v.x()).arg((quint32)v.y()).arg((quint32)v.z());
   }

   voutstream << "\n\n vals=== \n\n";
   i = 0;
   for(QVector3D& v : vals)
   {
    ++i;
    voutstream << QString("\n%1: {%2, %3, %4}").arg(i).arg(v.x()).arg(v.y()).arg(v.z());
    voutstream << QString("\n %1= {%2, %3, %4}").arg(i).arg((quint32)v.x()).arg((quint32)v.y()).arg((quint32)v.z());
   }

   vfile.close();




//   qDebug() << encode;
//   TDCX_Typed_Array_Decoder tar(encode);
//   tar.decode();
//   QVector<QSharedPointer<Test_Type>> values;
//   tar.reload(values);
//   QMap<QString, QByteArray>& qbas = values.first()->themap;
//   load_overall_form(qbas);
#endif// HIDE
  }
  else
  {
   QDataStream qds(&file);
   QMap<QString, QByteArray> qbas;
   //  QByteArray qba;
   qds >> qbas;
   load_overall_form(qbas);
  }
  file.close();
 }
}


void NDP_Anteview::run_secondary_dialog(QDialog* parent, QString cl)
{
 QDialog* dlg = run_secondary_dialog_left_or_right(parent, cl);
 last_launched_dialog_ = dlg;
}

void NDP_Anteview::run_secondary_dialog_right(QDialog* parent, QString cl)
{
 QDialog* dlg = run_secondary_dialog_left_or_right(parent, cl);
 if(last_launched_dialog_)
 {
  last_launched_dialog_->setWindowState((last_launched_dialog_->windowState() & ~Qt::WindowMinimized)
          | Qt::WindowActive);
 }

 QPoint np(dlg->rect().left() + 200, dlg->rect().top() - 4);
 dlg->move(mapToGlobal(np));

}

QDialog* NDP_Anteview::run_secondary_dialog_left_or_right(QDialog* parent, QString cl)
{
 QDialog* result = nullptr;
 int type_id = QMetaType::type(cl.toLatin1());
 int type_id1 = QMetaType::type(QString(cl + "*").toLatin1());
 if(type_id != QMetaType::UnknownType)
 {
  const QMetaObject* qmo1 = QMetaType::metaObjectForType(type_id1);
  qDebug() << qmo1->className();

  const QMetaObject* qmo = QMetaType::metaObjectForType(type_id);
//  qDebug() << qmo->className();

  void* pv = QMetaType::create(type_id);

  int x = parent->x() + parent->frameSize().width(); //parent->width() + 20;
  int y = parent->y();

  if(pv)
  {
   result = reinterpret_cast<QDialog*>( pv );

   active_secondary_dialogs_[cl] = result;

   result->move(x, y);

   result->show();
  }
 }
 return result;
}

void NDP_Anteview::screenshot_dialog_requested()
{
 RZ_Screenshot_Dialog* dlg = new RZ_Screenshot_Dialog(this);

 connect(dlg, SIGNAL(canceled(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));

 connect(this, &NDP_Anteview::take_screenshot_requested,
   [dlg]
 {
  QTimer::singleShot(10000, dlg, SLOT(take_screen_shot()));
 });

//   dlg, SLOT(take_screen_shot()));

 //?SIGNAL(send_email_requested(RZ_Screenshot_Dialog*, const QPixmap&)),

 connect(dlg, &RZ_Screenshot_Dialog::send_email_requested,
   [this](RZ_Screenshot_Dialog* dlg, const QPixmap& pm)
   {
    send_email_dialog_requested(&pm);
   }
  );



}

void NDP_Anteview::activate_screenshot_requested()
{
 qDebug() << "ASR";
 QTimer::singleShot(20000, this, [this]
 {
    QScreen *screen = QGuiApplication::primaryScreen();
    if (const QWindow *window = windowHandle())
        screen = window->screen();
    if (!screen)
    {
     return;
    }

    QPixmap screenshot_pixmap = screen->grabWindow(this->winId());
    send_email_dialog_requested(&screenshot_pixmap);
  });
}

void NDP_Anteview::send_email_dialog_requested(const QPixmap* const pixmap)
{
 RZ_Email_Message rem;

 model_->load_last_email(&rem);

 RZ_Send_Email_Dialog* dlg = new RZ_Send_Email_Dialog(this, rem, pixmap);

 QString path = "/home/nlevisrael/NDP/screenshots/__FILE__.jpeg";
 pixmap->save(path, "jpeg", 100);


 connect(dlg, SIGNAL(canceled(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));

 connect(dlg, &RZ_Send_Email_Dialog::send_requested,  //?SIGNAL(send_requested(RZ_Send_Email_Dialog*, RZ_Email_Message*)),
  [this](RZ_Send_Email_Dialog* dlg, RZ_Email_Message* rem)
 {
  RZ_Email_Message_Handler remh(rem);

  QString s = remh.to_string();
  QMessageBox::information(this, "?", s);

  remh.do_send([this, dlg](RZ_Email_Message_Handler::Send_Result sr)
   {
    dlg->convey_send_result(sr);
   });

  model_->save_last_email(rem);


  //?QString s = remh.to_string();
  //?QMessageBox::information(this, "?", s);
 });

 dlg->exec();
}


void NDP_Anteview::handle_view_rz_substitutions()
{
 QString src = centerview_->main_rz_source_text_edit()->document()->toPlainText();

 View_RZ_Dialog* dlg = new View_RZ_Dialog(this, model_, src);
 connect(dlg, SIGNAL(canceled(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));

 dlg->exec();



}


void NDP_Anteview::view_gecode_demo_requested()
{
 View_Gecode_Demo_Dialog* dlg = new View_Gecode_Demo_Dialog(this);
 connect(dlg, SIGNAL(canceled(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));
 connect(dlg, SIGNAL(accepted(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));
 dlg->show();

}


void NDP_Anteview::handle_show_pdf_conversions_requested(QList<OCR_Field>* conversions, View_PDF_Dialog* pdlg)
{
 View_OCR_Fields_Dialog* dlg = new View_OCR_Fields_Dialog(this,
   *conversions); //, nullptr);
 connect(dlg, SIGNAL(canceled(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));
 connect(dlg, SIGNAL(accepted(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));

//  QString summary;
//  QMapIterator<QString, QString> it1(conversions);
//  while(it1.hasNext())
//  {
//   it1.next();
//   summary += "\n" + it1.key() + ": " + it1.value();
//  }
//  QMessageBox::information(this, "Summary:", summary);

 dlg->show();

}

void NDP_Anteview::pdf_dialog_requested()
{
 View_PDF_Dialog* dlg = new View_PDF_Dialog(this,
  DEMO_DIR "/medicalrec.pdf"
     //  "/home/nlevisrael/NDP/pain-management-center-new-patient-history-2012.pdf"
     ); //, nullptr);
 connect(dlg, SIGNAL(canceled(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));
 connect(dlg, SIGNAL(accepted(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));


 connect(dlg, SIGNAL(show_conversions_requested(QList<OCR_Field>*, View_PDF_Dialog*)),
   this, SLOT(handle_show_pdf_conversions_requested(QList<OCR_Field>*, View_PDF_Dialog*)));


 dlg->show();
}

void NDP_Anteview::view_ocr_dialog_requested()
{
 View_OCR_Dialog* dlg = new View_OCR_Dialog(this, nullptr);
 connect(dlg, SIGNAL(canceled(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));

 dlg->exec();
}


void NDP_Anteview::view_web_page_dialog_requested()
{
 View_Web_Page_Dialog* dlg = new View_Web_Page_Dialog(this, nullptr);
 connect(dlg, SIGNAL(canceled(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));

 dlg->exec();


}

//void NDP_Anteview::edit_current_project_requested()
//{
// New_Project_Dialog* dlg = new New_Project_Dialog(
//    New_Project_Dialog::Editing_Mode::Create_New, this, nullptr //model_
//                                                  );

// connect(dlg, SIGNAL(proceed_requested(QDialog*, QMap<QString,QString>)),
//   this, SLOT(handle_dialog_proceed_requested(QDialog*, QMap<QString,QString>)));

// connect(dlg, SIGNAL(canceled(QDialog*)),
//   this, SLOT(delete_dialog(QDialog*)));


// connect(this, SIGNAL(new_project_confirmed(QDialog*,  NDP_Project&)),
//   dlg, SLOT(handle_new_project_confirmed(QDialog*,  NDP_Project&)));

// connect(this, SIGNAL(project_already_exists(QDialog*,  NDP_Project_Initial&)),
//   dlg, SLOT(handle_project_already_exists(QDialog*,  NDP_Project_Initial&)));


// dlg->exec();
//}

void NDP_Anteview::confirm_switch_to_existing_project(QDialog* dlg)
{
//?
// if(New_Project_Dialog* ndlg = qobject_cast<New_Project_Dialog*>(dlg) )
// {
//  if(ndlg->edits().isEmpty())
//  {
//   dlg->close();
//   return;
//  }
// }
 if(current_project_)
 {
  // anything to do here?"
 }
 current_project_ = new NDP_Project(data_manager_);
 current_project_->absorb_record(*potential_current_project_record_);
   //?Q_EMIT(project_record_updated(current_project_, record) ...
 confirm_current_project_model_substitutions();
 dlg->close();
}

void NDP_Anteview::confirm_current_project_model_substitutions()
{
 model_->substitutions()["PROJECT_LOCAL_FOLDER"] = current_project_->local_folder();
 model_->substitutions()["PROJECT_NAME"] = current_project_->name();
 model_->substitutions()["PROJECT_LOCAL_PORT"] = QString::number(current_project_->local_port());
 model_->substitutions()["PROJECT_DOCKER_PORT"] = QString::number(current_project_->docker_port());
 model_->check_reset_rz_source();
}

void NDP_Anteview::potential_switch_to_existing_project(NDP_Project_Record* record)
{
 potential_current_project_record_ = record;
}


void NDP_Anteview::load_existing_project_requested()
{
 New_Project_Dialog* dlg = new New_Project_Dialog(
    New_Project_Dialog::Editing_Mode::Select_Existing, this, model_
                                                  );


 connect(dlg, SIGNAL(selected_project_changed(NDP_Project_Record*)),
   this, SLOT(potential_switch_to_existing_project(NDP_Project_Record*)));

 connect(dlg, SIGNAL(proceed_requested(QDialog*, NDP_Project_Record*, QMap<QString,QString>)),
   this, SLOT(handle_dialog_proceed_requested(QDialog*, NDP_Project_Record*, QMap<QString,QString>)));

 connect(dlg, SIGNAL(canceled(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));

 connect(dlg, SIGNAL(accepted(QDialog*)),
   this, SLOT(confirm_switch_to_existing_project(QDialog*)));

 dlg->exec();
}


void NDP_Anteview::new_project_requested()
{

 New_Project_Dialog* dlg = new New_Project_Dialog(
    New_Project_Dialog::Editing_Mode::Create_New, this, nullptr //model_
                                                  );

 connect(dlg, SIGNAL(proceed_requested(QDialog*, NDP_Project_Record*, QMap<QString,QString>)),
   this, SLOT(handle_dialog_proceed_requested(QDialog*, NDP_Project_Record*, QMap<QString,QString>)));

 connect(dlg, SIGNAL(canceled(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));

 //?
 connect(dlg, SIGNAL(accepted(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));

 connect(this, SIGNAL(new_project_confirmed(QDialog*,  NDP_Project&)),
   dlg, SLOT(handle_new_project_confirmed(QDialog*,  NDP_Project&)));

 connect(this, SIGNAL(project_already_exists(QDialog*,  NDP_Project_Initial&)),
   dlg, SLOT(handle_project_already_exists(QDialog*,  NDP_Project_Initial&)));


 dlg->exec();
}

void NDP_Anteview::edit_current_project_requested()
{

 if(!current_project_)
 {
  QMessageBox::information(this, "No Project Selected", "Please create or select a project to edit");
  return;
 }

 New_Project_Dialog* dlg = new New_Project_Dialog(
    New_Project_Dialog::Editing_Mode::Edit_Existing, this, model_, current_project_
                                                  );

 connect(dlg, SIGNAL(proceed_requested(QDialog*, NDP_Project_Record*, QMap<QString,QString>)),
   this, SLOT(handle_project_edit_dialog_proceed_requested(QDialog*, NDP_Project_Record*, QMap<QString,QString>)));

 connect(dlg, SIGNAL(canceled(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));


 //?
 connect(dlg, SIGNAL(accepted(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));


 connect(this, SIGNAL(save_project_confirmed(QDialog*,  NDP_Project&)),
   dlg, SLOT(handle_save_project_confirmed(QDialog*,  NDP_Project&)));

 connect(this, SIGNAL(save_project_failed(QDialog*,  NDP_Project&)),
   dlg, SLOT(handle_save_project_failed(QDialog*,  NDP_Project&)));

 dlg->exec();
}

void NDP_Anteview::handle_project_edit_dialog_proceed_requested(QDialog* dlg,
  NDP_Project_Record* project_record_, QMap<QString,QString> params)
{
 if(!current_project_)
 {
  // init new current project?
 }
 current_project_->absorb_record(*project_record_);
 bool ok = data_manager_->save_project(*current_project_);

 if(ok)
 {
  confirm_current_project_model_substitutions();
  Q_EMIT(save_project_confirmed(dlg, *current_project_));

 }
 else
 {
  Q_EMIT(save_project_failed(dlg, *current_project_));
 }

}

void NDP_Anteview::handle_dialog_proceed_requested(QDialog* dlg,
  NDP_Project_Record* project_record_, QMap<QString,QString> params)
{
 if(project_record_)
 {

  // editing an existing? ...
 }
 QSharedPointer<NDP_Project_Initial> proi{ new NDP_Project_Initial(data_manager_) };

 proi->absorb_string_map(params);

 QString code = data_manager_->check_project_code(*proi->record());

 if(code.isEmpty())
 {
  NDP_Project_Silo* silo = data_manager_->ndp_project_silo();
  int record_uid = silo->new_uid();
  NDP_Project* project = silo->confirm_joinee_from_record(*proi->record(), record_uid);
  if(project)
  {
   int call_result_1 = data_manager_->check_save_silo_record_count(*silo);
   if(call_result_1 == QUnQLite_Callback_Parser::All_Ok
      || call_result_1 == QUnQLite_Callback_Parser::All_Up_To_Date)
   {
    int call_result_2 = data_manager_->save_new_silo_joinee(*silo, *project);
    if(call_result_2 == QUnQLite_Callback_Parser::All_Ok)
    {
     data_manager_->save_project_code(*project);
     Q_EMIT(new_project_confirmed(dlg, *project));
    }
    //     data_manager_->save_project(*project);
    //     data_manager_->save_project_code(*project);
   }
  }


  //code = data_manager_->new_project_code(*proi);
  //NDP_Project* pro = data_manag

  // { "name", name_line_edit_->text() },er_->
 }
 else
 {
  Q_EMIT(project_already_exists(dlg, *proi));
 }
// { "local-folder", local_folder_line_edit_->text() },
// { "remote-address", remote_address_line_edit_->text() },
// { "description", description_ },
// { "secondary-addresses", local_folder_line_edit_->text() }

}


QString NDP_Anteview::read_file(QString path)
{
 QString result;
 QFile file(path);
 if(file.open(QIODevice::ReadOnly | QIODevice::Text))
 {
  QTextStream in_stream(&file);
  result = in_stream.readAll();
 }
 return result;
}


void NDP_Anteview::handle_open_rz()
{
 QString file = QFileDialog::getOpenFileName(this, "Open R/Z File",
   DEFAULT_RZ_DIR, "R/Z Files (*.rz)");

 if(!file.isEmpty())
 {
  bool ok = centerview_->read_file(file, centerview_->main_rz_source_text_edit());
  if(ok)
  {
   centerview_->set_current_main_tab(centerview_->main_rz_source_text_edit());
   model_->set_current_rz_source(centerview_->main_rz_source_text_edit()->document()->toPlainText());
   model_->check_reset_rz_source();
  }
 }
}

void NDP_Anteview::handle_run_rz()
{
 QString src = model_->current_substituted_rz_source();

 View_RZ_Run_Output_Dialog* dlg = new View_RZ_Run_Output_Dialog(this, src);

 rz_print_results_text_edit_ = dlg->main_text();

 connect(dlg, SIGNAL(canceled(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));

 connect(dlg, SIGNAL(accepted(QDialog*)),
   this, SLOT(delete_dialog(QDialog*)));

 QString clasp = app_->run_rz(src);
 dlg->reset_clasp_code(clasp);

}

void NDP_Anteview::handle_open_html()
{
 QString file = QFileDialog::getOpenFileName(this, "Open HTML File",
   "/home/nlevisrael", "HTML Files (*.rz, *.htm, *.html)");

 if(!file.isEmpty())
 {
  centerview_->browse_file(file);
//  bool ok = centerview_->read_file(file, centerview_->main_rz_source_text_edit());
//  if(ok)
//  {
//   centerview_->set_current_main_tab(centerview_->main_rz_source_text_edit());
//  }
 }

}


void NDP_Anteview::handle_open_ngml()
{

}
void NDP_Anteview::handle_convert_ngml()
{

}


void NDP_Anteview::handle_open_project()
{
 load_existing_project_requested();
}

void NDP_Anteview::handle_preview_project()
{

}

void NDP_Anteview::handle_save_all()
{

}


void NDP_Anteview::handle_open_pdf()
{
 QString file = QFileDialog::getOpenFileName(this, "Open PDF File",
   "/home/nlevisrael", "PDF Files (*.pdf)");

 if(!file.isEmpty())
 {
  centerview_->load_pdf_file(file);

  search_line_edit_->setEnabled(true);
  search_combo_box_->setEnabled(true);
  find_button_->setEnabled(true);
  clear_button_->setEnabled(true);
  scale_combo_box_->setEnabled(true);
  page_spin_box_->setEnabled(true);
  page_spin_box_->setMinimum(1);
  page_spin_box_->setMaximum(centerview_->pdf_document()->document()->numPages());
  page_spin_box_->setValue(1);

 }
}


#define QUUTF8


void NDP_Anteview::retranslate_ui(QMainWindow* MainWindow)
{
//    MainWindow->setWindowTitle(QApplication::translate("MainWindow", "PDF Viewer", 0 QUUTF8));
//    openAction->setText(QApplication::translate("MainWindow", "&Open...", 0 QUUTF8));
//    openAction->setShortcut(QApplication::translate("MainWindow", "Ctrl+O", 0 QUUTF8));
//    exitAction->setText(QApplication::translate("MainWindow", "E&xit", 0 QUUTF8));
//    exitAction->setShortcut(QApplication::translate("MainWindow", "Ctrl+Q", 0 QUUTF8));
//    increaseScaleAction->setText(QApplication::translate("MainWindow", "&Increase Scale", 0 QUUTF8));
//    increaseScaleAction->setShortcut(QApplication::translate("MainWindow", "Ctrl++", 0 QUUTF8));
//    decreaseScaleAction->setText(QApplication::translate("MainWindow", "&Decrease Scale", 0 QUUTF8));
//    decreaseScaleAction->setShortcut(QApplication::translate("MainWindow", "Ctrl+-", 0 QUUTF8));
//    documentControlsAction->setText(QApplication::translate("MainWindow", "&Document Controls", 0 QUUTF8));
//    selectedTextAction->setText(QApplication::translate("MainWindow", "&Selected Text", 0 QUUTF8));
//    menu_File->setTitle(QApplication::translate("MainWindow", "&File", 0 QUUTF8));
//    menu_Windows->setTitle(QApplication::translate("MainWindow", "&Windows", 0 QUUTF8));
//    controlsDockWidget->setWindowTitle(QApplication::translate("MainWindow", "Document Controls", 0 QUUTF8));
    page_label_->setText(QApplication::translate("CLG_DB_Anteview", "Page:", 0 QUUTF8));
    search_label_->setText(QApplication::translate("MainWindow", "Search for:", 0 QUUTF8));
    search_combo_box_->clear();
    search_combo_box_->insertItems(0, QStringList()
     << QApplication::translate("MainWindow", "Forwards", 0 QUUTF8)
     << QApplication::translate("MainWindow", "Backwards", 0 QUUTF8)
    );
    find_button_->setText(QApplication::translate("MainWindow", "Find", 0 QUUTF8));
    clear_button_->setText(QApplication::translate("MainWindow", "Clear", 0 QUUTF8));
    scale_label_->setText(QApplication::translate("MainWindow", "Scale PDF Document:", 0 QUUTF8));
    scale_combo_box_->clear();
    scale_combo_box_->insertItems(0, QStringList()
     << QApplication::translate("MainWindow", "25%", 0 QUUTF8)
     << QApplication::translate("MainWindow", "50%", 0 QUUTF8)
     << QApplication::translate("MainWindow", "75%", 0 QUUTF8)
     << QApplication::translate("MainWindow", "100%", 0 QUUTF8)
     << QApplication::translate("MainWindow", "125%", 0 QUUTF8)
     << QApplication::translate("MainWindow", "150%", 0 QUUTF8)
     << QApplication::translate("MainWindow", "200%", 0 QUUTF8)
     << QApplication::translate("MainWindow", "300%", 0 QUUTF8)
     << QApplication::translate("MainWindow", "400%", 0 QUUTF8)
    );
    scale_combo_box_->setCurrentIndex(3);

     //selectionDockWidget->setWindowTitle(QApplication::translate("MainWindow", "Selected Text", 0 QUUTF8));
} // retranslateUi



void NDP_Anteview::init_line_buttons()
{
 centerview_->init_line_buttons();

 top_layout_->addWidget(centerview_->button_save_form());
 top_layout_->addWidget(centerview_->button_open_form());
 top_layout_->addStretch();

 connect(centerview_->button_save_form(), SIGNAL(clicked()),
  this, SLOT(save_overall_form()));

 connect(centerview_->button_cloud_save_form(), SIGNAL(clicked()),
  this, SLOT(cloud_save_overall_form()));

 connect(centerview_->button_cloud_open_form(), SIGNAL(clicked()),
  this, SLOT(cloud_open_overall_form()));

 connect(centerview_->button_open_form(), SIGNAL(clicked()),
  this, SLOT(load_overall_form()));

 connect(centerview_->button_cloud_open_form(), SIGNAL(clicked()),
  this, SLOT(cloud_open_overall_form()));


 top_layout_->addWidget(centerview_->button_cloud_save_form());
 top_layout_->addWidget(centerview_->button_cloud_open_form());
 top_layout_->addStretch();

 top_layout_->addWidget(centerview_->button_submit_form());
 top_layout_->addWidget(centerview_->button_share_form());
 top_layout_->addStretch();

 top_layout_->addWidget(centerview_->button_help());
 top_layout_->addWidget(centerview_->button_remote_help());
 top_layout_->addStretch();


// QGroupBox* box6 = new QGroupBox("Application", this);
// QHBoxLayout* boxl6 = new QHBoxLayout;
// boxl6->addWidget(centerview_->button_save_all());
// boxl6->addWidget(centerview_->button_close());
// box6->setLayout(boxl6);
// top_layout_->addWidget(box6);
// top_layout_->addWidget(centerview_->button_save_all());

 top_layout_->addWidget(centerview_->button_close());


 //?
 connect(centerview_->button_close(), SIGNAL(clicked()),
  this, SLOT(close()));


}

