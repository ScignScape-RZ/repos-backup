
#ifndef NDP_ANTEVIEW__H
#define NDP_ANTEVIEW__H


#include <QString>
#include <QMainWindow>

#include <QTextEdit>
//?#include <QWebView>
#include <QLabel>
#include <QPushButton>

#include <QHBoxLayout>

#include <QTimer>
#include <QWindow>
#include <QScreen>

#include "paraviews/view-ocr-fields-dialog.h"

#include "paraviews/intake-form-outline-dialog.h"

#include <QDockWidget>


#include <QDate>
#include <QSpinBox>
#include <QComboBox>

//#include "paraviews/load-url-dialog.h"

#include "ndp-centerview.h"

#include "accessors.h"

#include "flags.h"

#include "rzns.h"

//RZNS_(NDP)
namespace RZ{ namespace NDP{

class NDP_Application;
class NDP_Antemodel;
class NDP_Resource;
class NDP_Centerview;
//?
class Dialog_Properties_Dialog;
class NDP_Data_Manager;
//?
//class NDP_Data_HTML;
//class NDP_Web_Page;
//class NDP_User;
//class User_Register_Dialog;
//class Personal_Template_Dialog_Box;
//class Load_Url_Dialog;
//class Store_Url_Dialog;
//class Run_XQuery_Dialog;
//class Configure_XQuery_Dialog;
//class Load_XML_Dialog;
//class HTML_Visuals_Dialog;
//class Review_Stored_Web_Pages_Dialog;
//class XML_Perspectives_Dialog;
//class NYT_API_Dialog;
//class Enigma_Api_Dialog;
//class Vaers_API_Dialog;

class NDP_Project_Record;

class Shopping_Cart_Demo_Dialog;


class CLG_Named_Entity_Map;
class CLG_Document_Info;

class NDP_Project;
class NDP_Project_Initial;

class Edit_Event_Dialog;
class View_PDF_Dialog;


class NDP_Anteview : public QMainWindow
{
 Q_OBJECT

 enum Wait_State {
  Not_Waiting, Waiting_On_Login_For_Personal_Template
 };

 enum class Http_Content_Types {
  N_A, JSON, XML
 };

 Http_Content_Types parse_content_type_from_string(QString str)
 {
  static QMap<QString, Http_Content_Types> static_map {{
   {"application/json", Http_Content_Types::JSON},
   {"application/xml", Http_Content_Types::XML},

  }};

  return static_map.value(str, Http_Content_Types::N_A);
 }

 NDP_Application* app_;

 NDP_Antemodel* model_;
 NDP_Data_Manager* data_manager_;
// NDP_Data_HTML* data_html_;

 QMenuBar* menubar_;
 QMenu* lisp_menu_;
 QMenu* html_menu_;

 NDP_Centerview* centerview_;

 QDockWidget* controls_dock_widget_;
 QSpinBox* page_spin_box_;
 QLineEdit* search_line_edit_;
 QLabel* search_label_;
 QLabel* page_label_;
 QLabel* scale_label_;
 QComboBox* scale_combo_box_;
 QComboBox* search_combo_box_;
 QPushButton* find_button_;
 QPushButton* clear_button_;

 QHBoxLayout* top_layout_;

 QString read_file(QString path);

 NDP_Project* current_project_;
 NDP_Project_Record* potential_current_project_record_;

 QTextEdit* rz_print_results_text_edit_;

 QMap<QString, QDialog*> active_secondary_dialogs_;

 Intake_Form_Outline_Dialog* outline_dialog_;

 QDialog* last_launched_dialog_;

 //RZ_Screenshot_Dialog* take_screenshot_action_;

 void confirm_current_project_model_substitutions();
 void load_overall_form(QMap<QString, QByteArray>& qbas);
 void get_overall_form_data(QString& enc, QString& qqenc,
   QMap<QString, QByteArray>& qbas);




public:

 NDP_Anteview(NDP_Application* app, QWidget* parent = nullptr);

 void init();

 void retranslate_ui(QMainWindow* MainWindow);

 void confirm_cloud_open(QString text);

 void init_line_buttons();

 QDialog* run_secondary_dialog_left_or_right(QDialog* parent, QString cl);

Q_SIGNALS:

 void new_project_confirmed(QDialog*,  NDP_Project&);
 void project_already_exists(QDialog*,  NDP_Project_Initial&);
 void save_project_confirmed(QDialog*,  NDP_Project&);
 void save_project_failed(QDialog*,  NDP_Project&);
 void take_screenshot_requested();

 void cloud_save_result_posted(QString text);

public Q_SLOTS:

 void save_overall_form();
 void cloud_save_overall_form();
 void cloud_open_overall_form();

 void cloud_save(QString, QString);
 void cloud_open(QString, QString);

 void handle_open_pdf();
 void handle_open_rz();
 void handle_run_rz();
 void handle_view_rz_substitutions();

 void launch_accuweather_api_action_requested();
 void launch_blood_availability_api_requested();
 void launch_blood_availability_api_requested_chart();
 void launch_refugee_info_requested();
 void launch_pregnancy_info_requested();

 void run_secondary_dialog_right(QDialog* parent, QString cl);
 void run_secondary_dialog(QDialog* parent, QString cl);

 void load_overall_form();

 void view_encodings_action_requested();


 void derm_requested();

 void handle_show_pdf_conversions_requested(
   QList<OCR_Field>* conversions, View_PDF_Dialog* pdlg);

 void handle_open_html();
 void handle_open_ngml();
 void handle_convert_ngml();
 void handle_open_project();
 void handle_preview_project();
 void handle_save_all();
 void view_web_page_dialog_requested();
 void view_ocr_dialog_requested();
 void view_gecode_demo_requested();

 void screenshot_dialog_requested();
 void activate_screenshot_requested();

 void outline_action_requested();

 void new_project_requested();

 void edit_current_project_requested();
 void load_existing_project_requested();

 void pdf_dialog_requested();

 void send_email_dialog_requested(const QPixmap* const pixmap = nullptr);

 void handle_dialog_proceed_requested(QDialog* dlg,
   NDP_Project_Record* project_record_, QMap<QString,QString> params);

 void handle_project_edit_dialog_proceed_requested(QDialog* dlg,
   NDP_Project_Record* project_record_, QMap<QString,QString> params);


 void potential_switch_to_existing_project(NDP_Project_Record*);
 void confirm_switch_to_existing_project(QDialog* dlg);
 void delete_dialog(QDialog* dlg);


};

} } //_RZNS(NDP)

#endif
