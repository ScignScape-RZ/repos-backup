
#include "ndp-centerview.h"

#include <QPrinter>

#include <QWebEngineContextMenuData>

#include <QGroupBox>
#include <QTabBar>

//?#include <QWebHitTestResult>

//?#include <QWebElement>

#define NO_CAON

//?
//#include "rz-ngml/kernel/document/rz-ngml-document.h"
//#include "rz-ngml/output/rz-ngml-output-html.h"
//#include "rz-ngml/output/rz-ngml-output-latex.h"
//#include "rz-ngml/output/rz-ngml-output-khif.h"
//#include "rz-ngml/output/rz-ngml-output-xml.h"

#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDebug>
#include <QCheckBox>
//#include <QWebFrame>
#include <QMessageBox>


//#include <QNetworkAccessManager>
//#include <QNetworkRequest>
//#include <QNetworkReply>

#include <QRegularExpression>

//#include <QHostAddress>

#include "application/pdf-document-widget.h"
#include "application/ndp-web-page.h"

USING_RZNS(NDP)
//?USING_RZNS(NGML)


NDP_Centerview::NDP_Centerview(QWidget* parent)
{

}

//void NDP_Centerview::run_load_started(QString url)
//{
// //?Q_EMIT(url_load_started(url));
//}

//?
//void NDP_Centerview::run_load_finished(bool ok)
//{
// if(ok)
// {
//  if(true) //current_loaded_url_ != central_web_view_->url().toString())
//  {
//   current_loaded_url_ = central_web_view_->url().toString();
//   current_url_edit_->setText(current_loaded_url_);
//   show_current_page_html(central_web_view_);
//   Q_EMIT(url_load_finished(central_web_view_));
//  }
// }
//}

void NDP_Centerview::init_line_buttons()
{
// QString smaller_button_style_sheet = "{}";
// QString smaller_button_style_sheet = "padding-left: 1px; padding-right: 1px;"
//                                      "padding-top: 1px; padding-bottom: 1px;";



 QString left_style_sheet = "QPushButton:hover {background:rgb(150,190,240);"
                       " border-left: 4px groove rgb(150,190,240); "
                       " border-right: 4px ridge rgb(150,190,240); "
                       "}\n"
  "QPushButton{ padding:1px;  border: 2px solid rgb(150,190,240); "
  "  border-bottom: 1px solid #1DF5CE; "
  " border-radius: 8px; "
  " background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, "
   //"  stop: 0 white, stop: 1 #C0C0C0, stop: 2 #BCC6CC, stop: 3 teal"
  "  stop: 0 white, stop: 0.1 #C0C0C0, stop: 0.6 #BCC6CC, stop: 0.8 #A0CFEC, stop: 0.9 darkcyan,  stop: 1 teal"

  "); min-width: 80px; }";

//? setStyleSheet(style_sheet);



 QString alt_style_sheet = "QPushButton:hover {background:rgb(50,190,140);"
                       " border-left: 4px groove rgb(50,190,140); "
                       " border-right: 4px ridge rgb(50,190,140); "
                       "}\n"
  "QPushButton{ padding:0px;  padding-bottom:0px; padding-left:-10px; padding-right:-10px;margin-top:2px;"
   "border: 1px outset rgb(190,250,240); "
   "border-left: 1px outset rgba(50,190,140,0.2); "
   "border-right: 1px inset rgba(50,190,140,0.2); "
   "border-bottom: 1px inset pink; "
    //"  border-bottom: 1px solid black; "
   "font-size:9pt; "
  " border-radius: 5px; "
  " background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, "
  "  stop: 0 white, stop: 0.1 #C0C0C0, stop: 0.6 #C6CCBC, stop: 0.9 #CFECA0, stop: 1 darkmagenta "

  "); min-width: 80px; }"
   "";



 button_save_form_ = new QPushButton(tr("Save Form"), this);
 QPixmap button_save_form_pixmap("/home/nlevisrael/NDP/Dicon/qtdcm-2.0.2/Resources/save.svg");
 button_save_form_->setIcon(button_save_form_pixmap);
 button_save_form_->setStyleSheet(left_style_sheet);

 button_open_form_  =  new QPushButton(tr("Open Form"), this);
 QPixmap button_open_form_pixmap("/home/nlevisrael/NDP/Dicon/qtdcm-2.0.2/Resources/folder.svg");
 button_open_form_->setIcon(button_open_form_pixmap);
 button_open_form_->setStyleSheet(left_style_sheet);

 button_cloud_save_form_  =  new QPushButton(tr("Cloud Save"), this);
 QPixmap button_cloud_save_form_pixmap("/home/nlevisrael/NDP/Dicon/qtdcm-2.0.2/Resources/echo.png");
 button_cloud_save_form_->setIcon(button_cloud_save_form_pixmap);
 button_cloud_save_form_->setStyleSheet(left_style_sheet);

 button_cloud_open_form_  =  new QPushButton(tr("Cloud Open"), this);
 QPixmap button_cloud_open_form_pixmap("/home/nlevisrael/NDP/Dicon/qtdcm-2.0.2/Resources/package.svg");
 button_cloud_open_form_->setIcon(button_cloud_open_form_pixmap);
 button_cloud_open_form_->setStyleSheet(left_style_sheet);

 button_submit_form_  =  new QPushButton(tr("Submit Form"), this);
 QPixmap button_submit_form_pixmap("/home/nlevisrael/NDP/Dicon/qtdcm-2.0.2/Resources/finished.svg");
 button_submit_form_->setIcon(button_submit_form_pixmap);
 button_submit_form_->setStyleSheet(left_style_sheet);

 button_share_form_ =  new QPushButton(tr("Share Form"), this);
 QPixmap button_share_form_pixmap("/home/nlevisrael/NDP/Dicon/qtdcm-2.0.2/Resources/notes.svg");
 button_share_form_->setIcon(button_share_form_pixmap);
 button_share_form_->setStyleSheet(left_style_sheet);

 button_help_ =  new QPushButton(tr("Help"), this);
 QPixmap button_help_pixmap("/home/nlevisrael/NDP/Dicon/qtdcm-2.0.2/Resources/initial.svg");
 button_help_->setIcon(button_help_pixmap);
 button_help_->setStyleSheet(left_style_sheet);

 button_remote_help_ =  new QPushButton(tr("Remote Help"), this);
 QPixmap button_remote_help_pixmap("/home/nlevisrael/NDP/Dicon/qtdcm-2.0.2/Resources/star.svg");
 button_remote_help_->setIcon(button_remote_help_pixmap);
 button_remote_help_->setStyleSheet(left_style_sheet);

// button_open_ngml_ =  new QPushButton(tr("Open"), this);
// button_convert_ngml_ =  new QPushButton(tr("Convert"), this);
// button_save_all_ =  new QPushButton(tr("Save All"), this);
 button_close_ = new QPushButton(tr("Exit"));
 QPixmap button_close_pixmap("/home/nlevisrael/NDP/Dicon/qtdcm-2.0.2/Resources/pending.svg");
 button_close_->setIcon(button_close_pixmap);

// button_save_all_->setStyleSheet(left_style_sheet);
 button_close_->setStyleSheet(left_style_sheet);


// button_close_->setDefault(true);


// button_open_rz_->setStyleSheet(smaller_button_style_sheet);
// button_run_rz_->setStyleSheet(smaller_button_style_sheet);
// button_open_ngml_->setStyleSheet(smaller_button_style_sheet);
// button_open_html_->setStyleSheet(smaller_button_style_sheet);
// button_convert_ngml_->setStyleSheet(smaller_button_style_sheet);
// button_open_project_->setStyleSheet(smaller_button_style_sheet);
// button_preview_project_->setStyleSheet(smaller_button_style_sheet);
// button_save_all_->setStyleSheet(smaller_button_style_sheet);
// button_close_->setStyleSheet(smaller_button_style_sheet);
// connect(button_open_pdf_, SIGNAL(clicked()),
//   this, SLOT(button_open_pdf_clicked()));

// connect(button_open_rz_, SIGNAL(clicked()),
//   this, SLOT(button_open_rz_clicked()));

// connect(button_run_rz_, SIGNAL(clicked()),
//   this, SLOT(button_run_rz_clicked()));

// connect(button_open_ngml_, SIGNAL(clicked()),
//   this, SLOT(button_run_ngml_clicked()));

// connect(button_convert_ngml_, SIGNAL(clicked()),
//   this, SLOT(button_convert_ngml_clicked()));

// connect(button_open_html_, SIGNAL(clicked()),
//   this, SLOT(button_open_html_clicked()));

// connect(button_open_project_, SIGNAL(clicked()),
//   this, SLOT(button_open_project_clicked()));

// connect(button_preview_project_, SIGNAL(clicked()),
//   this, SLOT(button_preview_project_clicked()));

// connect(button_save_all_, SIGNAL(clicked()),
//   this, SLOT(button_save_all_clicked()));
}

void NDP_Centerview::button_open_pdf_clicked()
{
 Q_EMIT(button_open_pdf_requested());
}

void NDP_Centerview::button_open_rz_clicked()
{
 Q_EMIT(button_open_rz_requested());
}

void NDP_Centerview::button_run_rz_clicked()
{
 Q_EMIT(button_run_rz_requested());
}


//void NDP_Centerview::button_open_rz_clicked()
//{
// Q_EMIT(button_open_rz_requested());
//}

//void NDP_Centerview::button_run_rz_clicked()
//{
// Q_EMIT(button_run_rz_requested());
//}

void NDP_Centerview::button_open_ngml_clicked()
{
 Q_EMIT(button_open_ngml_requested());
}

void NDP_Centerview::button_convert_ngml_clicked()
{
 Q_EMIT(button_convert_ngml_requested());
}

void NDP_Centerview::button_open_html_clicked()
{
 Q_EMIT(button_open_html_requested());
}

void NDP_Centerview::button_open_project_clicked()
{
 Q_EMIT(button_open_project_requested());
}

void NDP_Centerview::button_preview_project_clicked()
{
 Q_EMIT(button_preview_project_requested());
}

void NDP_Centerview::button_save_all_clicked()
{
 Q_EMIT(button_save_all_requested());
}

void NDP_Centerview::init(QString info)
{
//? info_strings_["last-saved"] = info;

 QVBoxLayout* main_layout = new QVBoxLayout();


// QString style_sheet = "QPushButton:hover {background:rgb(150,190,240);"
//                       " border-left: 4px groove rgb(150,190,240); "
//                       " border-right: 4px ridge rgb(150,190,240); "
//                       "}\n"
//  "QPushButton{ padding:4px;  border: 2px solid rgb(150,190,240); "
//  "  border-bottom: 1px solid #1DF5CE; "
//  " border-radius: 6px; "
//  " background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, "
//   //"  stop: 0 white, stop: 1 #C0C0C0, stop: 2 #BCC6CC, stop: 3 teal"
//  "  stop: 0 white, stop: 0.1 #C0C0C0, stop: 0.6 #BCC6CC, stop: 0.8 #A0CFEC, stop: 0.9 darkcyan,  stop: 1 teal"

//  "); min-width: 80px; }";

////  "QPushButton:hover {border:solid red 4px}\n";
//                       //"QPushButton:hover {border:groove rgb(20,90,40) 4px}\n";



////                       "QPushButton#pushButton:pressed {background:rgb(100,100,200)}\n"
////                       "QPushButton#pushButton:hover {background:rgb(190,240,250)}\n";


// setStyleSheet(style_sheet);

// button_convert_xml_->setStyleSheet(style_sheet);
// button_load_xml_->setStyleSheet(style_sheet);
// button_xml_visualize_->setStyleSheet(style_sheet);
// button_run_xquery_->setStyleSheet(style_sheet);
// button_close_->setStyleSheet(style_sheet);
// button_edit_event_->setStyleSheet(style_sheet);
// button_edit_artist_->setStyleSheet(style_sheet);



// top_layout->setContentsMargins(0, 0, 0, 0);

 main_notebook_ = new QTabWidget(this);

  //?add_new_webview_tab(general_welcome_, "Welcome");


 //add_new_webview_tab(comment_summary_, "Comments...");

//? document_info_tabview_ = new Document_Info_Tabview(this);

 pdf_document_ = new PDF_Document_Widget(this);

 QFrame* qf = new QFrame(this);

 QVBoxLayout* pdf_document_vbox = new QVBoxLayout;
 pdf_document_vbox->addWidget(pdf_document_);
 qf->setLayout(pdf_document_vbox);

 QScrollArea* pdf_document_scroll_area = new QScrollArea(this);

 pdf_document_scroll_area->setWidget(qf);

 pdf_document_->set_surrounding_scroll_area(pdf_document_scroll_area);

 qf->setMinimumSize(300, 300);

 pdf_document_vbox->setSizeConstraint(QLayout::SetFixedSize);

 central_web_view_ = new QWebEngineView(this);
 local_web_view_ = new QWebEngineView(this);

 central_web_view_->setContextMenuPolicy(Qt::CustomContextMenu);

 connect(central_web_view_, SIGNAL(customContextMenuRequested(QPoint)),
   this, SLOT(central_web_view_context_menu(QPoint)));


 main_notebook_->addTab(local_web_view_, "Welcome");
 main_notebook_->addTab(central_web_view_, "Web");

 //pdf_document_scroll_area->setP

 main_notebook_->addTab(pdf_document_scroll_area, "PDF");
 add_new_text_edit_tab(main_html_source_text_edit_, "HTML Source");
 add_new_text_edit_tab(main_rz_source_text_edit_, "R/Z");
 add_new_text_edit_tab(main_ngml_source_text_edit_, "NGML");
 history_web_view_ = new QWebEngineView(this);
 history_web_view_->setContextMenuPolicy(Qt::CustomContextMenu);
 connect(history_web_view_, SIGNAL(customContextMenuRequested(QPoint)),
   this, SLOT(history_web_view_menu(QPoint)));
 main_notebook_->addTab(history_web_view_, "History");

 QString tab_style_sheet = "QTabBar::tab {"
     "background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,"
     "                            stop: 0 #E1E1E1, stop: 0.4 #DDDDDD,"
     "                            stop: 0.5 #D8D8D8, stop: 1.0 #D3D3D3);"
     "border: 2px solid #C4C4C3;"
     "border-bottom-color: #C2C7CB; /* same as the pane color */"
     "border-top-left-radius: 4px;"
     "border-top-right-radius: 4px;"
     "min-width: 8ex;"
     "padding: 2px;"
     "}"

     "QTabBar::tab:selected, QTabBar::tab:hover {"
     "background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,"
     "                            stop: 0 #fafafa, stop: 0.4 #f4f4f4,"
     "                            stop: 0.5 #e7e7e7, stop: 1.0 #fafafa);"
     "border-color: #5BAB9B;"
     "border-bottom-color: #C2C7CB; /* same as pane color */"
     "}"

     "QTabBar::tab:hover { border-color: #ABABCB; }"

     "QTabBar::tab:selected {"
     "border-color: #1B9B9B;"
     "border-bottom-color: #C2C7CB; /* same as pane color */"
     "}"

     "QTabBar::tab:!selected {"
     "margin-top: 2px; /* make non-selected tabs look smaller */"
     "}"

     "QTabBar::tab::disabled {"
       "width: 0; height: 0; margin: 0; padding: 0; border: none;"
       "}"

   ;


 main_notebook_->setStyleSheet(tab_style_sheet);

 for(int i = 2; i < main_notebook_->count(); ++i)
 {
  main_notebook_->setTabEnabled(i, false);
 }

 //add_new_text_edit_tab(history_web_view_, "History");


  xml_text_edit_ = nullptr;
//?
   //add_new_text_edit_tab(xml_text_edit_, "XML");

 //
//?
// document_container_text_edit_ = new QTextBrowser(this);
// document_container_text_edit_->setOpenExternalLinks(false);
// document_container_text_edit_->setOpenLinks(false);
// main_notebook_->addTab(document_container_text_edit_, "Documents");
// connect(document_container_text_edit_, SIGNAL(anchorClicked(const QUrl&)),
//   this, SLOT(document_container_link_clicked(const QUrl&)));

// main_notebook_->addTab(document_container_text_edit_, "Documents");
// connect(document_container_text_edit_, SIGNAL(linkClicked(const QUrl&)),
 //  this, SLOT(document_container_link_clicked(const QUrl&)));


// main_notebook_->addTab(document_info_tabview_, "NL Info");


   xquery_results_text_edit_ = nullptr;
//?
    //add_new_text_browser_tab(xquery_results_text_edit_, "XQuery Result");
//? add_new_text_edit_tab(main_html_source_text_edit_, "HTML Source");
//?

// add_new_text_edit_tab(main_html_source_text_edit_, "HTML Source");

   main_html_text_browser_ = nullptr;

//?
// add_new_text_browser_tab(main_html_text_browser_, "HTML");
// QString html = read_file("/home/nlevisrael/rz-dev/clg/html/blookster/demo.htm");
// main_html_text_browser_->setHtml(html);
// main_html_text_browser_->setSearchPaths({"/home/nlevisrael/rz-dev/clg/html/blookster"});

 //? main_html_text_browser_->setOpenExternalLinks(true);


 connect(main_notebook_, SIGNAL(currentChanged(int)), this,
  SLOT(notebook_tab_selected(int)));


//?
// QFrame* top_frame = new QFrame(this);
// top_frame->setLayout(top_layout);

// main_layout->addWidget(top_frame);

// QFrame* left_frame = new QFrame(this);
// QVBoxLayout* left_layout = new QVBoxLayout();
// QHBoxLayout* left_top_layout = new QHBoxLayout();

// left_layout->setMargin(0);
// left_layout->setContentsMargins(QMargins(0,0,0,0));
// left_layout->setSpacing(0);
// main_split->addWidget(main_notebook_);
// main_split->setSizes({300, 300});
 //left_frame
// main_layout->addWidget(main_split);

 main_layout->addWidget(main_notebook_);


// central_web_view_->load(QUrl::fromLocalFile("C:/sdc/t1.htm"));

 setLayout(main_layout);
// show();

 //? init_line_buttons();
  //?central_web_view_->setUrl(QUrl::fromLocalFile("/home/nlevisrael/rz-dev/clg/html/blookster/demo.htm"));

 //? browse_html(QUrl::fromLocalFile("/home/nlevisrael/rz-dev/clg/html/blookster/demo.htm"));
}

QPoint NDP_Centerview::get_main_notebook_widget_top_left_point()
{
 QPoint p0 = main_notebook_->widget(0)->pos();
 int y = main_notebook_->tabBar()->tabRect(0).height();

 //int y = main_notebook_->tabShape().height();
 QPoint p = main_notebook_->widget(0)->mapToGlobal(
    QPoint(p0.x(), p0.y() + y));
 return p; //mapToGlobal(p);
// return main_notebook_->widget(0)->mapToGlobal(QPoint(0, 0))
//   + QPoint(0, main_notebook_->tabShape().height()()

            //tabShape().height());

 //return QPoint(main_notebook_->x(), main_notebook_->y());
}


#ifdef HIDE
void NDP_Centerview::central_web_view_context_menu(QPoint p)
{
 QWebEnginePage* qwp = central_web_view_->page();
 QString jscode = QString("document.elementFromPoint(%1, %2).getAttribute(\"clg-id\");").arg(p.x()).arg(p.y());

 qwp->runJavaScript(jscode + ";", [this, p] (const QVariant& v)
  {
   QString atr = v.toString();
   qDebug() << "ATR: " << atr;

   QRegularExpression rx("([\\w-]+)-(\\d+)\\Z");

   QRegularExpressionMatch rxm = rx.match(atr);

   if(rxm.hasMatch())
   {
    QString kind  = rxm.captured(1);
    int index = rxm.captured(2).toInt(); //? - 1;

    qDebug() << kind;
    qDebug() << index;


    if(kind.startsWith("item"))
    {

     QMenu* menu = new QMenu(this);

     QAction* view_item_action = menu->addAction("View Item");

     connect(view_item_action, &QAction::triggered,
       [this, index] { Q_EMIT( view_item_requested(index) ); });

     menu->addAction("Search in Cart");
     menu->addAction("Add to Cart");
     menu->addAction("Bookmark");

     QPoint g = central_web_view_->mapToGlobal(p);

     menu->popup(g);


    }
    else
    {
     if(index == 1)
     {
      Q_EMIT activate_screenshot();
     }
     QString info = music_info_[kind][index - 1];

     QString label = music_context_menu_labels_[kind];

     QString base = QString("%1 (%2)").arg(info).arg(label);

     //QMessageBox::information(this, "?", base);

     QMenu* menu = new QMenu(this);

     //menu->addAction(QString("About %1:".arg(base));
     menu->addAction(base + ": Prior Orders");

     if(kind == "artist-name")
     {
      menu->addAction(base + ": Concerts");
      menu->addAction(base + ": Band History");
      menu->addAction(base + ": Recent News");
     }
     menu->addAction(base + ": Music Critic Reviews");

     QPoint g = central_web_view_->mapToGlobal(p);

     menu->popup(g);
    }
   }
  } );

}
#endif

void NDP_Centerview::load_pdf_file(QString file_name)
{
 //?
 pdf_document_->setDocument(file_name);
}

void NDP_Centerview::scale_document(int index)
{
 static QVector<qreal> scale_factors {0.25, 0.5, 0.75,
   1., 1.25, 1.5, 2., 3., 4.};
// if(pdf_document_->document())
// {
//  pdf_document_->setScale(scale_factors.value(index, 3));
// }
}

void NDP_Centerview::set_xquery_results(QString results)
{
 if(!xquery_results_text_edit_)
  add_new_text_browser_tab(xquery_results_text_edit_, "XQuery Results");
 xquery_results_text_edit_->setPlainText(results);
 main_notebook_->setCurrentWidget(xquery_results_text_edit_);
}

void NDP_Centerview::open_xml_tab()
{
 main_notebook_->setCurrentWidget(xml_text_edit_);
}

void NDP_Centerview::set_current_url(QString url)
{
 current_loaded_url_ = url;
 //?current_url_edit_->setText(url);
}


#ifdef HIDE
void NDP_Centerview::button_xml_visualize_clicked()
{
 QTcpSocket* tcpSocket = new QTcpSocket();

 tcpSocket->connectToHost(QHostAddress::LocalHost, 24141);

 QObject::connect(tcpSocket, &QTcpSocket::readyRead, [=]
 {
  QString s = QString::fromLatin1(tcpSocket->readAll());
  qDebug() << "Received: " << s;
  tcpSocket->disconnectFromHost();
  tcpSocket->deleteLater();
  this->setWindowState(Qt::WindowMinimized);
  //QMessageBox::information(nullptr, "OK", s);
 });

 QObject::connect(tcpSocket, &QTcpSocket::connected, [tcpSocket, this] ()
 {
  QString path;
  //? QString path = current_document_container_->current_local_file_path();
  tcpSocket->write(path.toLatin1());
  tcpSocket->disconnectFromHost();
  tcpSocket->deleteLater();
  this->parentWidget()->setWindowState(Qt::WindowMinimized);
 });

 QObject::connect(tcpSocket,
  static_cast<void (QTcpSocket::*)(QAbstractSocket::SocketError)>
  (&QAbstractSocket::error),
  [tcpSocket](QAbstractSocket::SocketError)
 {
  //QMessageBox::information(nullptr, "Error:", tcpSocket->errorString());
  qDebug()<< "ERROR " << tcpSocket->errorString();
  //  socket->deleteLater();
 });

 //?QMessageBox::information(nullptr, "Waiting", "Waiting");
}
#endif

void NDP_Centerview::central_web_view_scroll(int amount)
{
 central_web_view_scroll_area_->scroll(amount, 0);
}


void NDP_Centerview::show_saved_xml(QString xml)
{
 xml_text_edit_->setPlainText(xml);
}

void NDP_Centerview::set_main_xml(QString xml)
{
 if(!xml_text_edit_)
  add_new_text_edit_tab(xml_text_edit_, "XML");
 xml_text_edit_->setPlainText(xml);
}

void NDP_Centerview::set_main_html(QString html)
{
 if(!main_html_text_browser_)
 {
  add_new_text_browser_tab(main_html_text_browser_, "HTML");
  main_html_text_browser_->setOpenExternalLinks(true);
 }
 main_html_text_browser_->setHtml(html);
 main_notebook_->setCurrentWidget(main_html_text_browser_);
}

void NDP_Centerview::browse_file(QString file)
{
 browse_html(file.prepend("file://"));
}


void NDP_Centerview::browse_html(QUrl url)
{

// static QString html =
//       "<html><head></head><body>"

//       "<center><object style='align:center;width:98%;position:relative;left:2px;"
//       "top:35px;height:300px;background:lightgrey' type='application/x-qt-plugin' "
//       "classid='PDF_Document_Widget' name='pdf-document'></object></center>"
//       "</body></html>"
//   ;

//?
// NDP_Web_Page* twp = new NDP_Web_Page(this);
// central_web_view_->setPage(twp);

// PDF_Document_Widget* pdw = twp->get_inner_control<PDF_Document_Widget>("pdf-document");

// if(pdw)
//  pdw->setDocument("C:/qxcd/h2p/output-bl.pdf");
// QCheckBox* qcb = wp->get_inner_control<QCheckBox>(QString("personal-template"));
// qcb->setChecked(true);

 //?
 central_web_view_->load(url);

// QString file_name = "C:/qxcd/h2p/output-bl.pdf";
// load_pdf_file(file_name);

//?#ifdef HIDE
 connect( central_web_view_, &QWebEngineView::loadFinished, [this](bool)
  {
//   QPrinter printer(QPrinter::HighResolution);
//   printer.setPageSize(QPrinter::A4Plus);
//   printer.setOutputFormat(QPrinter::PdfFormat);
   QString file_name = "/home/nlevisrael/rz-dev/output-bl.pdf";
//   printer.setOutputFileName(file_name);
    //? central_web_view_->page()->print(&printer);

   central_web_view_->page()->toHtml([this](QString s)
   {
    main_html_source_text_edit_->setPlainText(s);
   });


   central_web_view_->page()->printToPdf([this, file_name](const QByteArray& qba)
    {
     save_binary_file(file_name, qba);

     load_pdf_file(file_name);

    }
   );

  });
//?#endif //HIDE

}



void NDP_Centerview::set_central_web_view_url_label(QString url)
{
 //? current_url_edit_->setText(url);
}


#ifdef HIDE
QString NDP_Centerview::show_current_page_xml(QWebView* qwv,
  QString base_path, QString path, bool light, bool preload)
{
 QString result;

 QString document_file = path;

 QString contents;
 if(preload)
 {
  contents = html_text_edit_->document()->toPlainText();
  save_file(path, contents);
 }
 else
 {
  contents = read_file(path);
 }

 QString xml_path;
 if(light)
 {
  xml_path = base_path + ".light.xml";
 }
 else
 {
  xml_path = base_path + ".xml";
 }

 NGML_Document::clean_html(contents);
 document_file += ".clean";
 save_file(document_file, contents);


 qint64 size = 0;

 QFile test_file(document_file);
 if (test_file.open(QIODevice::ReadOnly))
 {
  size = test_file.size();  //when file does open.
  test_file.close();
 }

 if(!light)
 {
  if(size > 128000)
  {
   QMessageBox::critical(this, "File Size Exceeded",
    QString("The HTML clean operation failed to yield a "
     "file within the 128k size limit: actual size %1").arg(size) );
   return result;
  }
 }
 if(size == 0)
 {
  QMessageBox::critical(this, "No valid HTML",
   QString("After HTML clean there was no remaining XML content "
    "that can be used for Natural Language Processing."));
  return result;
 }


 NGML_Document doc;
 doc.set_parsing_mode(NGML_Parsing_Modes::HTML);

 if(light)
  doc.use_light_xml();

 doc.load_and_parse(document_file);

 doc.save_word_count();
 doc.save_word_stream();
 doc.save_hrefs();
 doc.save_quotes();

 if(light)
 {
  doc.save_light_xml();
  document_file += ".light.xml";

   //?QMessageBox::information(this, "Light", document_file);

  read_file(document_file, xml_text_edit_, result);
  save_to_local_file_path(xml_path);
  load_word_count_and_stream(path + ".clean");
  main_notebook_->setCurrentWidget(xml_text_edit_);
  result = xml_text_edit_->toPlainText();
  return result;
 }

 NGML_Output_Xml nox(doc);
 nox.export_xml();

 document_file += ".xml";

 read_file(document_file, xml_text_edit_);
 save_to_local_file_path(xml_path);
 load_word_count_and_stream(path + ".clean");
 main_notebook_->setCurrentWidget(xml_text_edit_);
 result = xml_text_edit_->toPlainText();
 return result;
}
#endif // HIDE


void NDP_Centerview::save_to_local_file_path(QString xml_path)
{
 QString text = xml_text_edit_->toPlainText();
 QRegularExpression rx("&(\\w+);");
 text.replace(rx, "\\1");
 save_file(xml_path, text);

}


QString NDP_Centerview::load_file(QString path)
{
 QString result;
 QFile file(path);
 if(file.open(QFile::ReadOnly | QIODevice::Text))
 {
  result = file.readAll();
 }
 return result;
}


void NDP_Centerview::save_binary_file(QString path, const QByteArray& contents)
{
 QFile file(path);
 if(file.open(QIODevice::WriteOnly))
 {
  QDataStream out(&file);
  out << contents; //.toLatin1();
 }
 //?out << contents; //.toLatin1();
}


void NDP_Centerview::save_file(QString path, QString contents)
{
 QFile file(path);
 if(file.open(QIODevice::WriteOnly | QIODevice::Text))
 {
  QTextStream out(&file);
  out << contents;
 }
}

bool NDP_Centerview::read_file(QString path, QPlainTextEdit* qpte)
{
 QFile file(path);
 if(file.open(QIODevice::ReadOnly | QIODevice::Text))
 {
  QTextStream in_stream(&file);
  QString result = in_stream.readAll();
  qpte->setPlainText(result);
  return true;
 }
 return false;
}

void NDP_Centerview::read_file(QString path, QPlainTextEdit* qpte, QString& result)
{
 QFile file(path);
 if(file.open(QIODevice::ReadOnly | QIODevice::Text))
 {
  QTextStream in_stream(&file);
  QString result = in_stream.readAll();
  qpte->setPlainText(result);
 }
}

void NDP_Centerview::set_current_main_tab(QWidget* qw)
{
 main_notebook_->setCurrentWidget(qw);
}


QString NDP_Centerview::read_file(QString path)
{
 QString result;
 QFile file(path);
 if(file.open(QIODevice::ReadOnly | QIODevice::Text))
 {
  QTextStream in_stream(&file);
  result = in_stream.readAll();
 }
 return result;
}


QString NDP_Centerview::get_xquery_results()
{
 return xquery_results_text_edit_->toPlainText();
}

//?
//void NDP_Centerview::add_new_webview_tab(QWebView*& qwv, QString tab_text)
//{
// qwv = new QWebView(this);
// main_notebook_->addTab(qwv, tab_text);
//}

void NDP_Centerview::add_new_text_edit_tab(QTextEdit*& qte, QString tab_text)
{
 qte = new QTextEdit(this);
 main_notebook_->addTab(qte, tab_text);
}

void NDP_Centerview::add_new_text_edit_tab(QPlainTextEdit*& qte, QString tab_text)
{
 qte = new QPlainTextEdit(this);
 main_notebook_->addTab(qte, tab_text);
}

//void NDP_Centerview::add_new_text_edit_tab(QTextBrowser*& qte, QString tab_text)
//{
// qte = new QTextBrowser(this);
// main_notebook_->addTab(qte, tab_text);
//}

void NDP_Centerview::add_new_text_browser_tab(QTextBrowser*& qtb, QString tab_text)
{
 qtb = new QTextBrowser(this);
 main_notebook_->addTab(qtb, tab_text);
}

//QString NDP_Center::read_file(QString path)
//{
// QString result;
// QFile file(path);
// if(file.open(QIODevice::ReadOnly | QIODevice::Text))
// {
//  QTextStream in_stream(&file);
//  result = in_stream.readAll();
// }
// return result;
//}


//void NDP_Centerview::button_open_pdf_clicked()
//{
// Q_EMIT(button_open_pdf_requested());
//}


#ifdef HIDE
void NDP_Centerview::notebook_tab_selected(int tab_index)
{
 QWidget* qw = main_notebook_->widget(tab_index);
// if(qw == html_text_edit_)
// {
//    //? show_current_page_html();
//  //QMessageBox::information(this, "xxx", "ttt");
// }
//?
// if(qw == comment_previewer_)
// {
//  NDP_Web_Page* web_page = static_cast<NDP_Web_Page*>(comment_editor_->page());
//  NDP_Main_Editor* main_editor = web_page->main_editor();

//  Q_EMIT(comment_preview_notetab_selected(web_page, main_editor, comment_previewer_));
// }
}

void NDP_Centerview::run_load_url_clicked()
{
 Q_EMIT(run_load_url());
}

void NDP_Centerview::run_store_url_clicked()
{
 Q_EMIT(run_store_url());
}

void NDP_Centerview::run_xquery_clicked()
{
 Q_EMIT(run_xquery());
}


void NDP_Centerview::button_load_xml_clicked()
{
 Q_EMIT(load_xml_requested());
}

void NDP_Centerview::button_load_visuals_clicked()
{
 //?Q_EMIT(load_visuals_requested());
}

void NDP_Centerview::button_edit_event_clicked()
{
 Q_EMIT(edit_event_requested());
}

void NDP_Centerview::button_edit_artist_clicked()
{
 Q_EMIT(edit_artist_requested());
}

void NDP_Centerview::button_edit_author_clicked()
{
 Q_EMIT(edit_author_requested());
}


void NDP_Centerview::button_open_pdf_clicked()
{
 Q_EMIT(button_open_pdf_requested());
}


//void NDP_Centerview::configure_xquery_clicked()
//{
// Q_EMIT(configure_xquery());
//}
#endif
