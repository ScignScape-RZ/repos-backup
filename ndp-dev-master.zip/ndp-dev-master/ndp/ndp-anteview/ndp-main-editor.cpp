
//#include "ndp-main-editor.h"


//#include <QApplication>

//#include <QHBoxLayout>
//#include <QVBoxLayout>

//#include <QDebug>
//#include <QComboBox>
//#include <QFormLayout>

////?#include "controls/ndp-explained-combo-box.h"


//USING_RZNS(NDP)

//NDP_Main_Editor::NDP_Main_Editor(QWidget* parent)
//{
// init();
//}

//NDP_Main_Editor::NDP_Main_Editor(QWidget* parent,
// NDP_Main_Editor* prior)
//{
// init();
// set_contents(prior->get_contents());
// set_save_format(prior->get_save_format_index());
// set_send_format(prior->get_send_format_index());
// set_write_format(prior->get_write_format_index());
//}



//void NDP_Main_Editor::init()
//{
// main_text_edit_ = new QTextEdit(this);

//// main_text_edit_->setMinimumWidth(500);

// write_as_ = new NDP_Explained_Combo_Box(this,
//  "Write comments in this format, which may be converted when sharing", 80
//  );
// save_as_ = new NDP_Explained_Combo_Box(this,
//  "Format for storing comments in the database (may be dialog-specific)", 80
//  );
// send_as_ = new NDP_Explained_Combo_Box(this,
//  "Format for converting comments, including for external dialog engines", 80
//  );

// main_layout_ = new QVBoxLayout();
// combo_box_layout_ = new QFormLayout();

// combo_box_layout_->setFormAlignment(Qt::AlignBottom);

//// combo_box_layout_->setVerticalSpacing(0);

// init_markup_choices(write_as_);
// init_markup_choices(save_as_);
// init_markup_choices(send_as_);

// combo_box_layout_->addRow("Write As:", write_as_);
// combo_box_layout_->addRow("Save As:", save_as_);
// combo_box_layout_->addRow("Send As:", send_as_);


// main_layout_->addWidget(main_text_edit_);
// main_layout_->addLayout(combo_box_layout_);
// setLayout(main_layout_);
//}


//void NDP_Main_Editor::init_markup_choices(NDP_Explained_Combo_Box* box)
//{
// box->add_item("DMXL");
// box->add_item("HTML");
// box->add_item("XML");
// box->add_item("Plain Text");
// box->add_item("Khi-Forms");
//}


//void NDP_Main_Editor::set_contents(QString contents)
//{
// main_text_edit_->setPlainText(contents);
//}


//QString NDP_Main_Editor::get_contents()
//{
// return main_text_edit_->toPlainText();
//}


//QString NDP_Main_Editor::get_write_format()
//{
// return write_as_->current_text();
//}

//QString NDP_Main_Editor::get_send_format()
//{
// return send_as_->current_text();
//}

//QString NDP_Main_Editor::get_save_format()
//{
// return save_as_->current_text();
//}

//int NDP_Main_Editor::get_write_format_index()
//{
// return write_as_->current_index();
//}

//int NDP_Main_Editor::get_send_format_index()
//{
// return send_as_->current_index();
//}

//int NDP_Main_Editor::get_save_format_index()
//{
// return save_as_->current_index();
//}

//void NDP_Main_Editor::set_save_format(int i)
//{
// save_as_->set_current_index(i);
//}

//void NDP_Main_Editor::set_send_format(int i)
//{
// send_as_->set_current_index(i);
//}

//void NDP_Main_Editor::set_write_format(int i)
//{
// write_as_->set_current_index(i);
//}
