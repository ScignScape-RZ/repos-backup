
//#ifndef NDP_MAIN_EDITOR__H
//#define NDP_MAIN_EDITOR__H


//#include <QString>
//#include <QMainWindow>

//#include <QTextEdit>
////?#include <QWebView>
////?#include <QWebPage>
//#include <QLabel>
//#include <QPushButton>

//#include "accessors.h"

//#include "flags.h"

//#include "rzns.h"

//class QPushButton;
//class QTextEdit;
//class QTabWidget;
//class QComboBox;
//class QVBoxLayout;
//class QFormLayout;

////RZNS_(QWN)
//namespace RZ{ namespace QWN{

//class QWN_DB_Application;
//class QWN_DB_Antemodel;
//class QWN_DB_Resource;
//class QWN_DB_Main_Editor;
//class QWN_DB_Explained_Combo_Box;

//class QWN_DB_Main_Editor : public QWidget
//{
// Q_OBJECT

// QTextEdit* main_text_edit_;

// QWN_DB_Explained_Combo_Box* write_as_;
// QWN_DB_Explained_Combo_Box* save_as_;
// QWN_DB_Explained_Combo_Box* send_as_;

// QVBoxLayout* main_layout_;
// QFormLayout* combo_box_layout_;

// void init_markup_choices(QWN_DB_Explained_Combo_Box* box);

//public:

// void init();

// QWN_DB_Main_Editor(QWidget* parent);
// QWN_DB_Main_Editor(QWidget* parent, QWN_DB_Main_Editor* prior);

// QString get_contents();
// QString get_write_format();
// QString get_send_format();
// QString get_save_format();
// int get_write_format_index();
// int get_send_format_index();
// int get_save_format_index();

// void set_save_format(int i);
// void set_send_format(int i);
// void set_write_format(int i);


// void set_contents(QString contents);
//};

//} } //_RZNS(NDP)

//#endif
