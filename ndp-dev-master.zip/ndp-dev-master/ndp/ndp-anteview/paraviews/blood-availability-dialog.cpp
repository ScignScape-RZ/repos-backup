
#include "blood-availability-dialog.h"

//#include "clg-db-antemodel.h";

//?
//#include <QPieSeries>
//#include <QPieSlice>
//#include <QtCharts>

#include <QApplication>

#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>

#include <QPlainTextEdit>
#include <QTextStream>

#include <QTableWidget>

#include <QMessageBox>

#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrlQuery>

#include <QHeaderView>

#include <QListWidget>

//#include "silotypes/ndp-project/ndp-project.h"
//#include "silotypes/ndp-project/ndp-project-initial.h"

USING_RZNS(NDP)

Blood_Availability_Dialog::Blood_Availability_Dialog(QWidget* parent) //, NDP_Antemodel* antemodel)//, QString url, QWN_XMLDB_Configuration* config)
 : QDialog(parent) //, antemodel_(antemodel)//, config_(config)
{

 button_box_ = new QDialogButtonBox(this);

 button_ok_ = new QPushButton("OK");
 button_proceed_ = new QPushButton("Proceed");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

 button_proceed_->setDefault(false);
 button_proceed_->setAutoDefault(false);

 button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);


 connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));

 main_layout_ = new QVBoxLayout();

 main_text_edit_ = new QPlainTextEdit(this);
 //?main_web_engine_view_ = new QWebEngineView(this);

 main_notebook_ = new QTabWidget(this);



 url_label_  = new QLabel("URL", this);
 url_line_edit_ = new QLineEdit(this);

 location_label_  = new QLabel("Location", this);
 location_line_edit_ = new QLineEdit(this);
 location_line_edit_->setPlaceholderText("Geographic Location");

 url_layout_ = new QHBoxLayout;
 url_layout_->addWidget(url_label_);
 url_layout_->addWidget(url_line_edit_);

 location_layout_ = new QHBoxLayout;
 location_layout_->addWidget(location_label_);
 location_layout_->addWidget(location_line_edit_);

 main_notebook_->addTab(main_text_edit_, "Source");


 main_table_frame_ = new QFrame(this);
 main_table_grid_layout_ = new QGridLayout;
 main_table_frame_->setLayout(main_table_grid_layout_);

 main_notebook_->addTab(main_table_frame_, "Result");


 //? main_notebook_->addTab(main_web_engine_view_, "Web");

 main_layout_->addWidget(main_notebook_);

 main_layout_->addLayout(location_layout_);
 main_layout_->addLayout(url_layout_);



 QString colorful_button_style_sheet =
   "QPushButton:hover {background:rgb(240,190,150);"
   " border-left: 4px groove rgb(240,190,150); "
   " border-right: 4px ridge rgb(240,190,150); "
   "}\n"
   "QPushButton{ padding:1px;  border: 2px solid rgb(240,190,150); "
   "  border-bottom: 1px solid #CEF51D; "
   " border-radius: 6px; "
   " background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, "
   "  stop: 0 white, stop: 0.1 #C0C0C0, stop: 0.6 #CC"
   "C6BC, stop: 0.8 #ECCFA0, stop: 0.9 darkred,  stop: 1 brown"
   "); min-width: 80px; }";



 QString colorful_button_style_sheet_down =
   "QPushButton {background:rgb(190,190,230);padding-left:20;padding-right:20;padding-top:0;padding-bottom:0;"
   " border-left: 4px groove rgb(240,190,150); "
   " border-right: 4px ridge rgb(240,190,150); "
   "}\n";


 load_button_ = new QPushButton("Load", this);
 // close_button_ = new QPushButton("Close", this);

 load_button_->setStyleSheet(colorful_button_style_sheet);
 // close_button_->setStyleSheet(colorful_button_style_sheet);

 load_button_layout_ = new QHBoxLayout;
 load_button_layout_->addStretch();
 load_button_layout_->addWidget(load_button_);
 load_button_layout_->addStretch();


 cache_button_ = new QPushButton("Cached", this);
 cache_button_layout_ = new QHBoxLayout;
 cache_button_layout_->addStretch();
 cache_button_layout_->addWidget(cache_button_);
 cache_button_layout_->addStretch();

 main_layout_->addLayout(load_button_layout_);
 main_layout_->addLayout(cache_button_layout_);

 // close_button_layout_ = new QHBoxLayout;
 // close_button_layout_->addStretch();
 // close_button_layout_->addWidget(close_button_);
 // close_button_layout_->addStretch();

 // main_layout_->addLayout(close_button_layout_);

 connect(load_button_, SIGNAL(clicked()), this,
         SLOT(load_button_clicked()));

 connect(cache_button_, SIGNAL(clicked()), this,
         SLOT(cache_button_clicked()));



 main_layout_->addWidget(button_box_);

 setLayout(main_layout_);

 show();
}


//void View_Web_Page_Dialog::load_url(QString url)
//{
// web_engine_view_->load(QUrl(url));
//}

//void View_Web_Page_Dialog::load_local_file(QString path)
//{
// QString url = QString("file://%1").arg(path);
// url_line_edit_->setText(url);
// load_url(url);
//}

void Blood_Availability_Dialog::cache_button_clicked()
{
 QUrl qurl = QUrl::fromLocalFile("/home/nlevisrael/NDP/AccuWeather.html");
 //?main_web_engine_view_->load(qurl);

 main_text_edit_->setPlainText(
    "[{\"LocalObservationDateTime\":\"2017-04-06T22:25:00-04:00\",\"EpochTime\":1491531900,\"WeatherText\""
    ":\"Rain\",\"WeatherIcon\":18,\"IsDayTime\":false,\"Temperature\":{\"Metric\":{\"Value\":4.2,"
    "\"Unit\":\"C\",\"UnitType\":17},\"Imperial\":{\"Value\":40.0,\"Unit\":\"F\""
    "\"UnitType\":18}},\"MobileLink\":\"http://m.accuweather.com/en/us/brooklyn-ny/13775/current-weather/2083952?lang=en-us\""
    ",\"Link\":\"http://www.accuweather.com/en/us/brooklyn-ny/13775/current-weather/2083952?lang=en-us\"}]");
 //?main_notebook_->setCurrentWidget(main_web_engine_view_);
}

void Blood_Availability_Dialog::load_button_clicked()
{
 QString addr = QString("http://openbloodstocks.herokuapp.com/records?authority=%1bloodservice")
   .arg(location_line_edit_->text());

 QUrl qurl(addr);
 // "http://api.accuweather.com/locations/v1/search?q=san&apikey={your key}"
 get_api_response(qurl, [this](QString text)
 {
  QJsonDocument qjd = QJsonDocument::fromJson(text.toLatin1());
  QJsonObject qjo;
  QJsonArray qja;
  if(!qjd.isNull())
  {
   if(qjd.isObject())
   {
    qDebug() << "Object";
   }
   else if(qjd.isArray())
   {
    qDebug() << "Array";
    qja = qjd.array();
    for(int row = 0; row < qja.size(); ++row)
    {
     QJsonValue qjv = qja.at(row);
     QJsonObject qjo1 = qjv.toObject();

     QJsonValue blood_type_jv = qjo1.value("blood_type_id");
     int blood_type = blood_type_jv.toInt();

     QJsonValue days_remaining_jv = qjo1.value("days_remaining");
     double days_remaining = days_remaining_jv.toDouble();

     QSlider* days_remaining_slider = new QSlider(this);
     days_remaining_slider->setMinimum(0);
     days_remaining_slider->setMaximum(14);
     days_remaining_slider->setValue(days_remaining * 2);

     QJsonValue created_at_jv = qjo1.value("created_at");
     QString created_at_qs = created_at_jv.toString();

     int iof = created_at_qs.indexOf('T');
     created_at_qs = created_at_qs.left(iof);
     qDebug() << "CAQ: " << created_at_qs;

     QDate dt1 = QDate::currentDate();
     dt1 = dt1.addDays(-2);
     created_at_qs = dt1.toString();

     QDate date = QDate::fromString(created_at_qs);

     QLabel* blood_type_label = new QLabel("Blood Type:", this);
     QLabel* days_remaining_label = new QLabel("Days Remaining:", this);
     QLabel* date_label = new QLabel("as of", this);

     static QStringList blood_type_codes {{
       "O Pos", "O Neg", "A Pos", "A Neg",
       "B Pos", "B Neg", "AB Pos", "AB Neg",
                                          }};
     QString blood_type_code = blood_type_codes[blood_type - 1];
     QString days_remaining_code = QString::number(days_remaining);
     QString date_code = date.toString("M/d");

     QLabel* blood_type_show = new QLabel(blood_type_code, this);
     QLabel* days_remaining_show = new QLabel(days_remaining_code, this);
     QLabel* date_show = new QLabel(date_code, this);

     date_label->setStyleSheet("QLabel { color : #191970; }");

     //?main_table_grid_layout_->addWidget(blood_type_label, row, 0);
     main_table_grid_layout_->addWidget(blood_type_show, row, 0);
     main_table_grid_layout_->addWidget(date_label, row, 1);

     main_table_grid_layout_->addWidget(date_show, row, 2);

     days_remaining_slider->setOrientation(Qt::Horizontal);

     //main_table_grid_layout_->addWidget(days_remaining_label, row, 3);
     main_table_grid_layout_->addWidget(days_remaining_show, row, 3);
     main_table_grid_layout_->addWidget(days_remaining_slider, row, 4);

    }
    main_table_grid_layout_->setColumnStretch(0, 0);
    main_table_grid_layout_->setColumnStretch(1, 0);
    main_table_grid_layout_->setColumnStretch(2, 0);
    main_table_grid_layout_->setColumnStretch(3, 0);
    main_table_grid_layout_->setColumnStretch(4, 1);
   }
  }
 });
}

void Blood_Availability_Dialog::get_api_response(QUrl qurl, std::function<void(QString)> cb)
{

 // API key: 	imC01OmhDgqx1cDhYEjY1oAA1GWXXpb9
 QNetworkAccessManager* qnam = new QNetworkAccessManager;

 // QUrl qurl(addr);
 // QUrlQuery urlq;
 // urlq.addQueryItem("key", key);
 // aurl.setQuery(urlq);


 QNetworkRequest req;

 //? qDebug() << "Host: " << host << "URL: " << url.toString();

 req.setUrl(qurl);

 url_line_edit_->setText(qurl.toString());

 QString res = "[{\"id\":3273,\"blood_type_id\":5,\"days_remaining\":5.5,\"authority\":\"welshbloodservice\",\"created_at\":\"2014-10-09T19:33:20.028Z\"},{\"id\":3274,\"blood_type_id\":6,\"days_remaining\":3.0,\"authority\":\"welshbloodservice\",\"created_at\":\"2014-10-09T19:33:20.059Z\"},{\"id\":3275,\"blood_type_id\":1,\"days_remaining\":6.0,\"authority\":\"welshbloodservice\",\"created_at\":\"2014-10-09T19:33:20.067Z\"},{\"id\":3276,\"blood_type_id\":2,\"days_remaining\":6.0,\"authority\":\"welshbloodservice\",\"created_at\":\"2014-10-09T19:33:20.077Z\"},{\"id\":3277,\"blood_type_id\":3,\"days_remaining\":4.5,\"authority\":\"welshbloodservice\",\"created_at\":\"2014-10-09T19:33:20.085Z\"},{\"id\":3278,\"blood_type_id\":4,\"days_remaining\":1.5,\"authority\":\"welshbloodservice\",\"created_at\":\"2014-10-09T19:33:20.102Z\"},{\"id\":3279,\"blood_type_id\":7,\"days_remaining\":4.5,\"authority\":\"welshbloodservice\",\"created_at\":\"2014-10-09T19:33:20.112Z\"},{\"id\":3280,\"blood_type_id\":8,\"days_remaining\":3.0,\"authority\":\"welshbloodservice\",\"created_at\":\"2014-10-09T19:33:20.118Z\"}]";

 cb(res);
// QNetworkReply* reply = qnam->get(req);



// QObject::connect(reply, &QNetworkReply::finished,
//                  [this, reply, cb]()
// {
//  QString text = QString::fromLatin1( reply->readAll() );

//  cb(text);
//  //main_text_edit_->setPlainText(text);
//  reply->deleteLater();
// });

}

//View_Web_Page_Dialog::View_Web_Page_Dialog()
// // : parent_(nullptr), antemodel_(nullptr)
//{

//}
//View_Web_Page_Dialog::View_Web_Page_Dialog(const View_Web_Page_Dialog& rhs)
// // : setP(rhs.parent_), antemodel_(rhs.antemodel_)
//{

//}

Blood_Availability_Dialog::~Blood_Availability_Dialog()
{
 delete button_ok_;
 delete button_proceed_;
 delete button_cancel_;

 // delete url_label_;
 // delete name_qle_;
}



void Blood_Availability_Dialog::cancel()
{
 Q_EMIT(canceled(this));
 // close();
}

void Blood_Availability_Dialog::accept()
{
 Q_EMIT(accepted(this));
 // close();
}
