
#include "intake-form-outline-dialog.h"

//#include "clg-db-antemodel.h";

#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>

#include <QButtonGroup>

#include <QPlainTextEdit>
#include <QTextStream>

#include <QTableWidget>

#include <QMessageBox>

#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrlQuery>

#include <QHeaderView>

#include <QListWidget>

#include "silotypes/ndp-project/ndp-project.h"
#include "silotypes/ndp-project/ndp-project-initial.h"

USING_RZNS(NDP)

Intake_Form_Outline_Dialog::Intake_Form_Outline_Dialog(QWidget* parent)
//, QString url, QWN_XMLDB_Configuration* config)
 : QDialog(parent)//?, antemodel_(antemodel)//, config_(config)
{

 button_box_ = new QDialogButtonBox(this);

 button_ok_ = new QPushButton("OK");
 button_proceed_ = new QPushButton("Proceed");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

 button_proceed_->setDefault(false);
 button_proceed_->setAutoDefault(false);

 button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);


 connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));

 main_layout_ = new QVBoxLayout();

 main_layout_->setMargin(0);
 main_layout_->setSpacing(0);


 heading_label_ = new QLabel(this);

 heading_label_->setText("Form Outline");

 setStyleSheet("QLabel{font-weight:900}");

 second_heading_label_ = new QLabel(this);
 second_heading_label_->setText("Click on a \nsubheading\n to continue");

 second_heading_label_->setAlignment(Qt::AlignCenter);
 heading_label_->setAlignment(Qt::AlignCenter);

 second_heading_label_->setStyleSheet("QLabel{margin-top:10px;padding-top:3px;"
                                      "padding-bottom:3px;margin-bottom:2px;border-top: 3px ridge pink;}");


 main_layout_->addWidget(heading_label_);
 main_layout_->addWidget(second_heading_label_);

 main_button_group_ = new QButtonGroup(this);

 QString button_style_sheet = "QPushButton{color:red;font-weight:900;font-style:italic}";

 connect(main_button_group_, SIGNAL(buttonClicked(int)),
   this, SLOT(main_button_group_button_clicked(int)));

 select_intro_button_ = new QPushButton("Introduction", this);
 select_patient_information_button_= new QPushButton("Patient Information", this);


 select_intro_button_->setVisible(false);


 // chief complaint ...
// select_pain_history_button_= new QPushButton("Pain History", this);
 select_pain_history_button_= new QPushButton("Chief Complaint", this);

  // select_insurance_button_= new QPushButton("Insurance", this);
  // select_insurance_button_->setCheckable(true);
  // select_pain_history_button_= new QPushButton("Insurance", this);

  // select_pain_description_button_= new QPushButton("Pain Description", this);
 select_pain_description_button_= new QPushButton("Review of Symptoms", this);


 select_treatment_history_button_= new QPushButton("Treatment History", this);
 select_medical_history_button_= new QPushButton("Medical History", this);
  // select_review_of_symptoms_button_= new QPushButton("Review of Symptoms", this);

 select_review_of_symptoms_button_ = new QPushButton("Current Medications", this);

 select_family_history_button_ = new QPushButton("Family History", this);


 main_layout_->addWidget(select_intro_button_);
 main_layout_->addWidget(select_patient_information_button_);
 main_layout_->addWidget(select_pain_history_button_);
// main_layout_->addWidget(select_insurance_button_);
 main_layout_->addWidget(select_pain_description_button_);
 main_layout_->addWidget(select_treatment_history_button_);
 main_layout_->addWidget(select_medical_history_button_);
 main_layout_->addWidget(select_review_of_symptoms_button_);
 main_layout_->addWidget(select_family_history_button_);



 main_button_group_->addButton(select_intro_button_);
 main_button_group_->addButton(select_patient_information_button_);
 main_button_group_->addButton(select_pain_history_button_);
 main_button_group_->addButton(select_pain_description_button_);
 main_button_group_->addButton(select_treatment_history_button_);
 main_button_group_->addButton(select_medical_history_button_);
 main_button_group_->addButton(select_review_of_symptoms_button_);
 main_button_group_->addButton(select_family_history_button_);



 for(auto a : main_button_group_->buttons())
 {
  a->setStyleSheet(button_style_sheet);
  a->setCheckable(true);
 }

 main_layout_->addStretch();

// main_notebook_ = new QTabWidget(this);
// main_text_ = new QTextEdit();
// rz_source_ = new QTextEdit();
// clasp_source_ = new QTextEdit();
// rz_source_->document()->setPlainText(rz);
// clasp_source_->document()->setPlainText(cl);
// clasp_source_ = new QTextEdit(this);

// main_notebook_->addTab(main_text_, "Output");
// main_notebook_->addTab(rz_source_, "R/Z");
// main_notebook_->addTab(clasp_source_, "CL");

// main_layout_->addWidget(main_notebook_);
// //?main_layout_->addLayout(url_layout_);

 QString colorful_button_style_sheet =
  "QPushButton:hover {background:rgb(240,190,150);"
  " border-left: 4px groove rgb(240,190,150); "
  " border-right: 4px ridge rgb(240,190,150); "
  "}\n"
  "QPushButton{ padding:1px;  border: 2px solid rgb(240,190,150); "
  "  border-bottom: 1px solid #CEF51D; "
  " border-radius: 6px; "
  " background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, "
  "  stop: 0 white, stop: 0.1 #C0C0C0, stop: 0.6 #CC"
  "C6BC, stop: 0.8 #ECCFA0, stop: 0.9 darkred,  stop: 1 brown"
  "); min-width: 80px; }";



 QString colorful_button_style_sheet_down =
  "QPushButton {background:rgb(190,190,230);padding-left:20;padding-right:20;padding-top:0;padding-bottom:0;"
  " border-left: 4px groove rgb(240,190,150); "
  " border-right: 4px ridge rgb(240,190,150); "
  "}\n";


// button_close_->setStyleSheet(colorful_button_style_sheet);

// clear_button_ = new QPushButton("Clear", this);
// clear_button_->setStyleSheet(colorful_button_style_sheet);
// clear_button_layout_ = new QHBoxLayout;
// clear_button_layout_->addStretch();
// clear_button_layout_->addWidget(clear_button_);
// clear_button_layout_->addStretch();

// main_layout_->addLayout(clear_button_layout_);

 secondary_dialog_classes_ = QStringList {
  "RZ::NDP::Intake_Form_Intro_Dialog",
  "RZ::NDP::Intake_Patient_History_Dialog",
  "RZ::NDP::Intake_Pain_History_Dialog",
  "RZ::NDP::Insurance",
  "RZ::NDP::Intake_Treatment_History_Dialog",
  "RZ::NDP::Intake_Medical_History_Dialog",
  "RZ::NDP::Intake_Medical_History_Dialog",
  "RZ::NDP::Intake_Medical_History_Dialog",
  "RZ::NDP::Intake_Medical_History_Dialog",
 };


 main_layout_->addWidget(button_box_);

 setContextMenuPolicy(Qt::CustomContextMenu);

 connect(this, &QTableView::customContextMenuRequested,
   [this](QPoint p)
 {
  handle_context_menu(p);
 });


 button_box_->setVisible(false);


 setLayout(main_layout_);

 show();
}

void Intake_Form_Outline_Dialog::main_button_group_button_clicked(int index)
{
 int cid = -(index + 2);
 QString cl = secondary_dialog_classes_[cid];
 Q_EMIT(secondary_dialog_class_requested(this, cl));
}

void Intake_Form_Outline_Dialog::handle_context_menu(QPoint p)
{
 QWidget* qw = childAt(p);

 QPushButton* btn = qobject_cast<QPushButton*>(qw);

 int index = main_button_group_->id(btn);
 int cid = -(index + 2);
 if(cid >= 0)
 {
  QString cl = secondary_dialog_classes_[cid];
  Q_EMIT(secondary_dialog_class_requested_right(this, cl));
 }
}


//void Intake_Form_Outline_Dialog::reset_clasp_code(QString src)
//{
// qDebug() << "XXXXX" << src;
// clasp_source_->document()->setPlainText(src);
// //?clasp_source_->repaint();
// clasp_source_->update();
//}


//void Intake_Form_Outline_Dialog::clear_button_clicked()
//{
// main_text_->clear();
//}



Intake_Form_Outline_Dialog::~Intake_Form_Outline_Dialog()
{
 delete button_ok_;
 delete button_proceed_;
 delete button_cancel_;

// delete url_label_;
// delete name_qle_;
}



void Intake_Form_Outline_Dialog::cancel()
{
 Q_EMIT(canceled(this));
// close();
}

void Intake_Form_Outline_Dialog::accept()
{
 Q_EMIT(accepted(this));
// close();
}
