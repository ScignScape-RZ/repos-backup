
#ifndef INTAKE_FORM_OUTLINE_DIALOG__H
#define INTAKE_FORM_OUTLINE_DIALOG__H


#include <QString>
#include <QMainWindow>

#include <QTextEdit>
//?#include <QWebView>

#include <QWebEngineView>
#include <QLabel>
#include <QPushButton>

#include <QDialog>

#include <QComboBox>

#include "accessors.h"

#include "flags.h"

#include "rzns.h"

//#include "incident-form-dialog.h"

class QPushButton;
class QTextEdit;
class QPlainTextEdit;
class QLineEdit;
class QTabWidget;
class QDialogButtonBox;
class QVBoxLayout;
class QHBoxLayout;
class QCheckBox;
class QFormLayout;
class QSplitter;
class QGridLayout;
class QListWidget;
class QTableWidget;
class QScrollArea;
class QGroupBox;
class QTableWidgetItem;

//RZNS_(QWN)
namespace RZ{ namespace NDP{


class NDP_Antemodel;
class NDP_Project;
class NDP_Project_Initial;


class Intake_Form_Outline_Dialog : public QDialog
{
 Q_OBJECT

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QPushButton* button_proceed_;

 QLabel* heading_label_;
 QLabel* second_heading_label_;

 QButtonGroup* main_button_group_;

 QPushButton* select_intro_button_;
 QPushButton* select_patient_information_button_;
 QPushButton* select_pain_history_button_;
 QPushButton* select_pain_description_button_;
 QPushButton* select_treatment_history_button_;
 QPushButton* select_medical_history_button_;
 QPushButton* select_review_of_symptoms_button_;
 QPushButton* select_family_history_button_;

 //QPushButton* select_insurance_button_;



 QStringList secondary_dialog_classes_;


// QLabel* url_label_;
// QLineEdit* url_line_edit_;
// QTabWidget* main_notebook_;
// QTextEdit* main_text_;
// QTextEdit* clasp_source_;
// QTextEdit* rz_source_;

 QVBoxLayout* main_layout_;
//? NDP_Antemodel* antemodel_;


// QHBoxLayout* clear_button_layout_;
// QPushButton* clear_button_;

 void read_file(QString path, QPlainTextEdit* qpte);

public:

 Intake_Form_Outline_Dialog(QWidget* parent); //?, NDP_Antemodel* antemodel);
 ~Intake_Form_Outline_Dialog();

 void reset_clasp_code(QString src);



// ACCESSORS(QTextEdit* ,main_text)


Q_SIGNALS:
 void canceled(QDialog*);
 void accepted(QDialog*);

 void secondary_dialog_class_requested(QDialog*, QString class_name);
 void secondary_dialog_class_requested_right(QDialog*, QString class_name);

public Q_SLOTS:
 void accept();
 void cancel();

 void main_button_group_button_clicked(int index);
 void handle_context_menu(QPoint p);

 //?void proceed();

// void clear_button_clicked();

};

} } //_RZNS(NDP)


#endif
