
#include "intake-form-intro-dialog.h"

//#include "clg-db-antemodel.h";

#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>

#include <QPlainTextEdit>
#include <QTextStream>

#include <QTableWidget>

#include <QMessageBox>

#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrlQuery>

#include <QHeaderView>

#include <QListWidget>

#include "silotypes/ndp-project/ndp-project.h"
#include "silotypes/ndp-project/ndp-project-initial.h"

#include "ndp-antemodel.h"


USING_RZNS(NDP)

Intake_Form_Intro_Dialog::Intake_Form_Intro_Dialog(QWidget* parent) :
  View_PDF_Dialog(parent, "/home/nlevisrael/NDP/pdf/intro.pdf")
{
}

Intake_Form_Intro_Dialog::Intake_Form_Intro_Dialog(const Intake_Form_Intro_Dialog& rhs)
 : View_PDF_Dialog(qobject_cast<QWidget*>(rhs.parent()), rhs.pdf_file_path())
{

}

Intake_Form_Intro_Dialog::~Intake_Form_Intro_Dialog()
{
 //?View_PDF_Dialog::~View_PDF_Dialog();
}
