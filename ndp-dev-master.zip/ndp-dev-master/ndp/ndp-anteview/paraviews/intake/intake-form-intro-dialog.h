
#ifndef INTAKE_FORM_INTRO_DIALOG__H
#define INTAKE_FORM_INTRO_DIALOG__H

#include "../view-pdf-dialog.h"

#include <QString>
#include <QMainWindow>

#include <QTextEdit>
//?#include <QWebView>

#include <QWebEngineView>
#include <QLabel>
#include <QPushButton>

#include <QDialog>
#include <QSpinBox>
#include <QComboBox>

#include "accessors.h"

#include "flags.h"

#include "rzns.h"

class PDF_Document_Widget;

//#include "incident-form-dialog.h"

class QPushButton;
class QTextEdit;
class QPlainTextEdit;
class QLineEdit;
class QTabWidget;
class QDialogButtonBox;
class QVBoxLayout;
class QHBoxLayout;
class QCheckBox;
class QFormLayout;
class QSplitter;
class QGridLayout;
class QListWidget;
class QTableWidget;
class QScrollArea;
class QGroupBox;
class QTableWidgetItem;

//RZNS_(QWN)
namespace RZ{ namespace NDP{


class NDP_Antemodel;
class NDP_Project;
class NDP_Project_Initial;


class Intake_Form_Intro_Dialog: public View_PDF_Dialog
{
 Q_OBJECT


public:

 Intake_Form_Intro_Dialog(QWidget* parent = nullptr); //, NDP_Antemodel* antemodel);

 Intake_Form_Intro_Dialog(const Intake_Form_Intro_Dialog& rhs);

 ~Intake_Form_Intro_Dialog();

};

} } //_RZNS(NDP)


Q_DECLARE_METATYPE(RZ::NDP::Intake_Form_Intro_Dialog*)
Q_DECLARE_METATYPE(RZ::NDP::Intake_Form_Intro_Dialog)


#endif
