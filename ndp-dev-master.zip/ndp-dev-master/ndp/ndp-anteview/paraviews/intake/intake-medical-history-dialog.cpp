
#include "intake-medical-history-dialog.h"

//#include "clg-db-antemodel.h";

#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>

#include <QPlainTextEdit>
#include <QTextStream>

#include <QTableWidget>

#include <QMessageBox>

#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrlQuery>

#include <QHeaderView>

#include <QListWidget>

#include "silotypes/ndp-project/ndp-project.h"
#include "silotypes/ndp-project/ndp-project-initial.h"

#include "ndp-antemodel.h"


USING_RZNS(NDP)

Intake_Medical_History_Dialog::Intake_Medical_History_Dialog(QWidget* parent) :
  View_Web_Page_Dialog(parent, nullptr) //"/home/nlevisrael/NDP/pdf/intro.pdf")
{
 load_local_file("/home/nlevisrael/NDP/slides/medical-history.html");
}

Intake_Medical_History_Dialog::Intake_Medical_History_Dialog(const Intake_Medical_History_Dialog& rhs)
 : View_Web_Page_Dialog(qobject_cast<QWidget*>(rhs.parent()), nullptr)
{
 load_local_file("/home/nlevisrael/NDP/slides/medical-history.html");
}

Intake_Medical_History_Dialog::~Intake_Medical_History_Dialog()
{
 //?View_Web_Page_Dialog::~View_Web_Page_Dialog();
}
