
#ifndef INTAKE_MEDICAL_HISTORY_DIALOG__H
#define INTAKE_MEDICAL_HISTORY_DIALOG__H

#include "../view-web-page-dialog.h"

#include <QString>
#include <QMainWindow>

#include <QTextEdit>
//?#include <QWebView>

#include <QWebEngineView>
#include <QLabel>
#include <QPushButton>

#include <QDialog>
#include <QSpinBox>
#include <QComboBox>

#include "accessors.h"

#include "flags.h"

#include "rzns.h"

class PDF_Document_Widget;

//#include "incident-form-dialog.h"

class QPushButton;
class QTextEdit;
class QPlainTextEdit;
class QLineEdit;
class QTabWidget;
class QDialogButtonBox;
class QVBoxLayout;
class QHBoxLayout;
class QCheckBox;
class QFormLayout;
class QSplitter;
class QGridLayout;
class QListWidget;
class QTableWidget;
class QScrollArea;
class QGroupBox;
class QTableWidgetItem;

//RZNS_(QWN)
namespace RZ{ namespace NDP{


class NDP_Antemodel;
class NDP_Project;
class NDP_Project_Initial;


class Intake_Medical_History_Dialog: public View_Web_Page_Dialog
{
 Q_OBJECT


public:

 Intake_Medical_History_Dialog(QWidget* parent = nullptr); //, NDP_Antemodel* antemodel);

 Intake_Medical_History_Dialog(const Intake_Medical_History_Dialog& rhs);

 ~Intake_Medical_History_Dialog();

};

} } //_RZNS(NDP)


Q_DECLARE_METATYPE(RZ::NDP::Intake_Medical_History_Dialog*)
Q_DECLARE_METATYPE(RZ::NDP::Intake_Medical_History_Dialog)


#endif
