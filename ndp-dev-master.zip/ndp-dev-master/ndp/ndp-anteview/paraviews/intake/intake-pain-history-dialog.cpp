
#include "intake-pain-history-dialog.h"

#include "../view-svg-dialog.h"

//#include "clg-db-antemodel.h";

#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>

#include <QButtonGroup>

#include <QPlainTextEdit>
#include <QTextStream>

#include <QTableWidget>

#include <QMessageBox>

#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrlQuery>

#include <QHeaderView>

#include <QListWidget>

#include "silotypes/ndp-project/ndp-project.h"
#include "silotypes/ndp-project/ndp-project-initial.h"

#include "paraviews/text-edit-dialog.h"

USING_RZNS(NDP)

Intake_Pain_History_Dialog::Intake_Pain_History_Dialog(QWidget* parent)
//, QString url, QWN_XMLDB_Configuration* config)
 : QDialog(parent), view_svg_dialog_(nullptr)//?, antemodel_(antemodel)//, config_(config)
{

 button_box_ = new QDialogButtonBox(this);

// button_ok_ = new QPushButton("OK");
// button_proceed_ = new QPushButton("Proceed");
// button_cancel_ = new QPushButton("Cancel");
 button_close_ = new QPushButton("Close");

// button_ok_->setDefault(false);
// button_ok_->setAutoDefault(false);
// button_proceed_->setDefault(false);
// button_proceed_->setAutoDefault(false);
// button_cancel_->setDefault(true);
// button_ok_->setEnabled(false);
// button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
// button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
// button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);
 button_box_->addButton(button_close_, QDialogButtonBox::ApplyRole);


// connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));
 connect(button_box_, SIGNAL(applied()), this, SLOT(apply()));

 main_layout_ = new QVBoxLayout();

 QString colorful_button_style_sheet =
  "QPushButton:hover {background:rgb(240,190,150);"
  " border-left: 4px groove rgb(240,190,150); "
  " border-right: 4px ridge rgb(240,190,150); "
  "}\n"
  "QPushButton{ padding:1px;  border: 2px solid rgb(240,190,150); "
  "  border-bottom: 1px solid #CEF51D; "
  " border-radius: 6px; "
  " background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, "
  "  stop: 0 white, stop: 0.1 #C0C0C0, stop: 0.6 #CC"
  "C6BC, stop: 0.8 #ECCFA0, stop: 0.9 darkred,  stop: 1 brown"
  "); min-width: 80px; }";



 QString colorful_button_style_sheet_down =
  "QPushButton {background:rgb(190,190,230);padding-left:20;padding-right:20;padding-top:0;padding-bottom:0;"
  " border-left: 4px groove rgb(240,190,150); "
  " border-right: 4px ridge rgb(240,190,150); "
  "}\n";


 QString button_close_style_sheet =
  "QPushButton:hover {background:rgb(150,240,190);"
  " border-left: 4px groove rgb(150,240,190); "
  " border-right: 4px ridge rgb(150,240,190); "
  "}\n"
  "QPushButton{ padding:1px;  border: 1px solid rgb(150,240,190);"
  "  border-bottom: 1px solid #CEF51D; "
  " border-radius: 0px; "
  " background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, "
  "  stop: 0 white, stop: 0.1 #C0C0C0, stop: 0.6 #C6CCBC "
  "  stop: 0.8 #A0ECCF, stop: 0.9 darkseagreen,  stop: 1 blue"
  "); min-width: 80px; }";




 button_close_->setStyleSheet(button_close_style_sheet);



 QString alt_style_sheet = "QPushButton:hover {background:rgb(50,190,140);"
                       " border-left: 4px groove rgb(50,190,140); "
                       " border-right: 4px ridge rgb(50,190,140); "
                       "}\n"
  "QPushButton{ padding:0px;  padding-bottom:0px; padding-left:-10px; padding-right:-10px;margin-top:2px;"
   "border: 1px outset rgb(190,250,240); "
   "border-left: 1px outset rgba(50,190,140,0.2); "
   "border-right: 1px inset rgba(50,190,140,0.2); "
   "border-bottom: 1px inset pink; "
    //"  border-bottom: 1px solid black; "
   "font-size:9pt; "
  " border-radius: 5px; "
  " background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, "
  "  stop: 0 white, stop: 0.1 #C0C0C0, stop: 0.6 #C6CCBC, stop: 0.9 #CFECA0, stop: 1 darkmagenta "

  "); min-width: 80px; }"
   "";

 undo_redo_layout_ = new QHBoxLayout;
 undo_button_ = new QPushButton("Undo", this);
 redo_button_ = new QPushButton("Redo", this);
 undo_redo_layout_->addStretch();
 undo_redo_layout_->addWidget(undo_button_);

 QSpacerItem* qs = new QSpacerItem(10, 1, QSizePolicy::Minimum, QSizePolicy::Fixed);
 undo_redo_layout_->addSpacerItem(qs);

 undo_button_->setStyleSheet(colorful_button_style_sheet);
 undo_redo_layout_->addWidget(redo_button_);
 redo_button_->setStyleSheet(colorful_button_style_sheet);
 undo_redo_layout_->addStretch();

 main_layout_->addLayout(undo_redo_layout_);

 descriptions_layout_ = new QFormLayout;

 chief_complaint_layout_ = new QHBoxLayout;
 chief_complaint_line_edit_ = new QLineEdit(this);
 chief_complaint_button_ = new QPushButton("Edit", this);
 chief_complaint_button_->setStyleSheet(alt_style_sheet);
 chief_complaint_layout_->addWidget(chief_complaint_line_edit_);
 chief_complaint_layout_->addWidget(chief_complaint_button_);

 connect(chief_complaint_button_, &QPushButton::pressed, [this]
 {
  launch_edit(*chief_complaint_line_edit_, chief_complaint_);
 });

 radiate_layout_ = new QHBoxLayout;
 radiate_line_edit_ = new QLineEdit(this);
 radiate_button_ = new QPushButton("Edit", this);
 radiate_button_->setStyleSheet(alt_style_sheet);
 radiate_layout_->addWidget(radiate_line_edit_);
 radiate_layout_->addWidget(radiate_button_);

 connect(radiate_button_, &QPushButton::pressed, [this]
 {
  launch_edit(*radiate_line_edit_, radiate_);
 });

 additional_areas_layout_ = new QHBoxLayout;
 additional_areas_line_edit_ = new QLineEdit(this);
 additional_areas_button_ = new QPushButton("Edit", this);
 additional_areas_button_->setStyleSheet(alt_style_sheet);
 additional_areas_layout_->addWidget(additional_areas_line_edit_);
 additional_areas_layout_->addWidget(additional_areas_button_);
 connect(additional_areas_button_, &QPushButton::pressed, [this]
 {
  launch_edit(*additional_areas_line_edit_, additional_areas_);
 });


 descriptions_layout_->addRow("Chief Complaint (reason for your visit today)", chief_complaint_layout_);
 descriptions_layout_->addRow("Does this pain radiate?  If so where?", radiate_layout_);
 descriptions_layout_->addRow("Please list any additional areas of pain", additional_areas_layout_);

 complete_edits_[chief_complaint_line_edit_] = QString("");
 complete_edits_[radiate_line_edit_] = QString("");
 complete_edits_[additional_areas_line_edit_] = QString("");


//?
// main_layout_->setMargin(0);
// main_layout_->setSpacing(0);


 diagram_button_ = new QPushButton("Diagram", this);
 diagram_layout_ = new QHBoxLayout;
 diagram_layout_->addWidget(diagram_button_);
 diagram_label_ = new QLabel("This opens a diagram so you can mark areas of pain", this);
 diagram_layout_->addWidget(diagram_label_);
 diagram_button_->setStyleSheet(colorful_button_style_sheet);

 connect(diagram_button_, SIGNAL(clicked(bool)), this,
   SLOT(diagram_button_clicked(bool)));

 descriptions_layout_->addRow("Open Diagram", diagram_layout_);

 main_layout_->addLayout(descriptions_layout_);




// main_button_group_ = new QButtonGroup(this);
// select_intro_button_ = new QPushButton("Introduction", this);
// select_intro_button_->setCheckable(true);
// select_insurance_button_= new QPushButton("Insurance", this);
// select_insurance_button_->setCheckable(true);
// main_layout_->addWidget(select_intro_button_);
// main_layout_->addWidget(select_insurance_button_);
// main_button_group_->addButton(select_intro_button_);
// main_button_group_->addButton(select_insurance_button_);


 main_layout_->addStretch();

// main_notebook_ = new QTabWidget(this);
// main_text_ = new QTextEdit();
// rz_source_ = new QTextEdit();
// clasp_source_ = new QTextEdit();
// rz_source_->document()->setPlainText(rz);
// clasp_source_->document()->setPlainText(cl);
// clasp_source_ = new QTextEdit(this);

// main_notebook_->addTab(main_text_, "Output");
// main_notebook_->addTab(rz_source_, "R/Z");
// main_notebook_->addTab(clasp_source_, "CL");

// main_layout_->addWidget(main_notebook_);
// //?main_layout_->addLayout(url_layout_);


// clear_button_ = new QPushButton("Clear", this);
// clear_button_->setStyleSheet(colorful_button_style_sheet);
// clear_button_layout_ = new QHBoxLayout;
// clear_button_layout_->addStretch();
// clear_button_layout_->addWidget(clear_button_);
// clear_button_layout_->addStretch();

// main_layout_->addLayout(clear_button_layout_);


 main_layout_->addWidget(button_box_);

 setLayout(main_layout_);

 show();
}


void Intake_Pain_History_Dialog::diagram_button_clicked(bool)
{
 view_svg_dialog_  = new View_SVG_Dialog(this);
 view_svg_dialog_->show();
}


void Intake_Pain_History_Dialog::launch_edit(QLineEdit& le, QString& s)
{
 QString txt = le.text();
 if(!txt.isEmpty())
 {
  if(!complete_edits_.contains(&le))
  {
   complete_edits_[&le] = txt;
  }
 }

 Text_Edit_Dialog* dlg = new Text_Edit_Dialog(this, complete_edits_[&le]);
 connect(dlg, &Text_Edit_Dialog::proceed_with_text, [this, &le, &s](QDialog* d, QString text)
 {
  chief_complaint_history_.push_back(s);
  s = text;
  complete_edits_[&le] = text;
  le.setText(s.left(20) + "...");
 });
}

void Intake_Pain_History_Dialog::write_state_to(QByteArray& qba)
{
 QDataStream qds(&qba, QIODevice::WriteOnly);
 QMapIterator<QLineEdit*, QString> it(complete_edits_);
 while(it.hasNext())
 {
  it.next();
  QLineEdit* qle = it.key();
  QString val = it.value();
  if(val.isEmpty())
  {
   QString qlet = qle->text();
   if(!qlet.isEmpty())
   {
    complete_edits_[qle] = qlet;
   }
  }
 }
 qds << complete_edits_[chief_complaint_line_edit_];
 qds << complete_edits_[radiate_line_edit_];
 qds << complete_edits_[additional_areas_line_edit_];
 if(view_svg_dialog_)
 {
  QByteArray qba1;
  view_svg_dialog_->get_all_scene_data(qba1);
  qds << qba1;
 }
}

void Intake_Pain_History_Dialog::read_state_from(const QByteArray& qba)
{
 QDataStream qds(qba);
 QString ccle;
 qds >> ccle;
 complete_edits_[chief_complaint_line_edit_] = ccle;
 chief_complaint_line_edit_->setText(ccle);
 qds >> complete_edits_[radiate_line_edit_];
 radiate_line_edit_->setText(complete_edits_[radiate_line_edit_]);
 qds >> complete_edits_[additional_areas_line_edit_];
 additional_areas_line_edit_->setText(complete_edits_[additional_areas_line_edit_]);
 QByteArray qba1;
 qds >> qba1;
 if(!qba1.isEmpty())
 {
  view_svg_dialog_  = new View_SVG_Dialog(this);
  view_svg_dialog_ ->load_all_scene_data(qba1);
  view_svg_dialog_->show();
 }
}



Intake_Pain_History_Dialog::Intake_Pain_History_Dialog(const Intake_Pain_History_Dialog& rhs)
{
 QWidget* p = qobject_cast<QWidget*>( rhs.parent() );
 setParent( p );
}


//void Intake_Form_Outline_Dialog::reset_clasp_code(QString src)
//{
// qDebug() << "XXXXX" << src;
// clasp_source_->document()->setPlainText(src);
// //?clasp_source_->repaint();
// clasp_source_->update();
//}


//void Intake_Form_Outline_Dialog::clear_button_clicked()
//{
// main_text_->clear();
//}



Intake_Pain_History_Dialog::~Intake_Pain_History_Dialog()
{
// delete button_ok_;
// delete button_proceed_;
// delete button_cancel_;

 delete button_close_;

// delete url_label_;
// delete name_qle_;
}



void Intake_Pain_History_Dialog::cancel()
{
 Q_EMIT(canceled(this));
// close();
}

void Intake_Pain_History_Dialog::accept()
{
 Q_EMIT(accepted(this));
// close();
}

void Intake_Pain_History_Dialog::apply()
{
 Q_EMIT(applied(this));
// close();
}

