
#ifndef INTAKE_TREATMENT_HISTORY_DIALOG__H
#define INTAKE_TREATMENT_HISTORY_DIALOG__H


#include <QString>
#include <QMainWindow>

#include <QTextEdit>
//?#include <QWebView>
#include <QLabel>
#include <QPushButton>
#include <QLineEdit>
#include <QDialog>

#include <QComboBox>
#include <QDateEdit>

#include "accessors.h"

#include "flags.h"

#include "rzns.h"

#include "event-calendar-widget.h"

//#include "incident-form-dialog.h"

class QPushButton;
class QTextEdit;
class QPlainTextEdit;
class QLineEdit;
class QTabWidget;
class QDialogButtonBox;
class QVBoxLayout;
class QHBoxLayout;
class QCheckBox;
class QFormLayout;
class QSplitter;
class QGridLayout;
class QListWidget;
class QTableWidget;
class QScrollArea;
class QGroupBox;
class QTableWidgetItem;


class Event_Calendar_Widget;

//RZNS_(QWN)
namespace RZ{ namespace NDP{


//?class CLG_DB_Antemodel;

class Test_Line_Edit;
class Test_Label;

struct Surgery_Row
{
 QTableWidgetItem* surgery_index;
 //?QTableWidgetItem* observer_year;
 QTableWidgetItem* surgery_description;
 QTableWidgetItem* surgery_options;

 QLabel* index;
 //?QLineEdit* year;
 Test_Line_Edit* description;

 QFrame* options_frame;
 QVBoxLayout* options_layout;
 QHBoxLayout* options_cut_layout;
 QHBoxLayout* options_label_layout;

 QLabel* options;
 QPushButton* cut;

 Surgery_Row* next_row;
// CLG_DB_Artist* artist;
// CLG_DB_Author* author;

 //QPushButton* cut_button = new QPushButton(QChar(0xD7), cut_frame);

 Surgery_Row(QWidget* parent = nullptr);
};


//class Test_Event_Filter : public QObject
//{
// Q_OBJECT

//protected:
//  bool eventFilter(QObject *obj, QEvent *event);

//public:

// Test_Event_Filter(QWidget* parent);

//};


class Test_Line_Edit : public QLineEdit
{
 Q_OBJECT

 QDialog* containing_dialog_;
 QTableWidget* containing_table_widget_;

public:

 Test_Line_Edit(QWidget* parent);

 ACCESSORS(QDialog* ,containing_dialog)
 ACCESSORS(QTableWidget* ,containing_table_widget)

 void dragEnterEvent(QDragEnterEvent *e) override;
 void dropEvent(QDropEvent *e) override;
};


class Test_Label : public QLineEdit
{
 Q_OBJECT

 QDialog* containing_dialog_;

public:

 Test_Label(QWidget* parent);

 ACCESSORS(QDialog* ,containing_dialog)

 void dragLeaveEvent(QDragLeaveEvent *e) override;
};


class Intake_Treatment_History_Dialog: public QDialog
{
 Q_OBJECT

 QString move_string_;

 //Test_Event_Filter* tef;

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QPushButton* button_proceed_;

// QLabel* api_choice_label_;
// QComboBox* api_choice_combo_box_;

 QLabel* referring_doctor_name_label_;
 QLineEdit* referring_doctor_name_line_edit_;

// QLabel* gender_label_;
// QComboBox* gender_combo_box_;

// QLabel* state_label_;
// QComboBox* state_combo_box_;

// QLabel* symptoms_label_;

// QHBoxLayout* symptoms_buttons_;
// QPushButton* symptoms_pictures_button_;
// QPushButton* symptoms_activities_button_;
// // QPushButton* symptoms_list_button_;


// QHBoxLayout* description_text_layout_;
// QLabel* description_text_label_;
// QPushButton* description_text_button_;

// QLabel* name_of_primary_care_provider_label_;
// QLineEdit* name_of_primary_care_provider_line_edit_;

// QLabel* most_recent_visit_label_;
// QHBoxLayout* most_recent_visit_layout_;
// QLineEdit* most_recent_visit_line_edit_;
// QPushButton* most_recent_visit_button_;


//? QListWidget* symptoms_list_box_;

// QComboBox* symptoms_combo_box_;

 QLabel* referring_doctor_kind_label_;
 QComboBox* referring_doctor_kind_combo_box_;


 QLabel* referring_date_label_;
 QDateEdit* referring_date_edit_;

 Event_Calendar_Widget* referring_date_calendar_widget_;

// QFrame* calendar_frame_;
// QHBoxLayout* calendar_layout_;
// QPushButton* calendar_push_button_;

 QTableWidget* surgeries_table_widget_;

 QVBoxLayout* surgeries_group_layout_;
 QScrollArea* surgeries_scroll_area_;
 QGroupBox* surgeries_group_;

 QPushButton* button_more_surgeries_;
 QHBoxLayout* button_more_surgeries_layout_;

 int current_surgeries_row_;
 int deleted_surgeries_row_count_;

//? QFrame* observers_frame_;

// QLabel* manufacturer_label_;
// QComboBox* manufacturer_combo_box_;

// QLabel* serious_label_;
// QCheckBox* serious_check_box_;

// QLabel* recovered_label_;
// QCheckBox* recovered_check_box_;

 QFormLayout* top_layout_;
 QFormLayout* mid_layout_;

// QLabel* url_label_;
// QTextEdit* url_text_edit_;

// QLabel* query_file_label_;
// QLineEdit* query_file_line_edit_;

// QPlainTextEdit* query_template_text_;
// QPushButton* select_query_template_file_;

 QVBoxLayout* main_layout_;
 QHBoxLayout* query_file_layout_;

 QString current_query_file_path_;
 QString current_request_url_;

 //CLG_DB_Antemodel* antemodel_;

 Surgery_Row* current_max_surgery_row_;

 QDate last_context_date_;

 //?QWN_XMLDB_Configuration* config_;

 void read_file(QString path, QPlainTextEdit* qpte);

 void add_surgery_row(Surgery_Row* prior_row);


// QFormLayout* checkbox_layout_;
// QCheckBox* convert_mhix_ckb_;
// QCheckBox* convert_xml_ckb_;
// QCheckBox* save_file_ckb_;
// QCheckBox* auto_save_file_ckb_;
// QCheckBox* save_bookmark_ckb_;

// void init_checkboxes(QFormLayout& qfl);

public:

 ACCESSORS(QString ,move_string)


 Intake_Treatment_History_Dialog(QWidget* parent = nullptr);//, QString url, QWN_XMLDB_Configuration* config);
 Intake_Treatment_History_Dialog(const Intake_Treatment_History_Dialog& rhs);

 void write_state_to(QByteArray& qba);
 void read_state_from(const QByteArray& qba);


 ~Intake_Treatment_History_Dialog();

 void activate_search(QString text);


Q_SIGNALS:
 void accepted(Intake_Treatment_History_Dialog*);
 void canceled(QDialog*);
 void proceed_requested(Intake_Treatment_History_Dialog*, QString, QString);
 void load_event_by_date_requested(Intake_Treatment_History_Dialog*, QDate);

public Q_SLOTS:
 void accept();
 void cancel();
 void proceed();

 void surgeries_table_widget_cell_entered(int row, int col);
 void surgeries_table_widget_item_entered(QTableWidgetItem* item);

 void button_more_surgeries_clicked();

 void calendar_button_clicked();

 void select_query_template_file_clicked();
 void set_query_file_from_api_choice(int);
 void named_entity_line_edit_editing_finished();

 void handle_referring_calendar_context_menu_requested(QDate,QPoint);

 void load_appointment_by_date();
 void notify_event_not_found(QDate date);

};

} } //_RZNS(NDP)

Q_DECLARE_METATYPE(RZ::NDP::Intake_Treatment_History_Dialog*)
Q_DECLARE_METATYPE(RZ::NDP::Intake_Treatment_History_Dialog)

#endif
