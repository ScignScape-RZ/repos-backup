
#include "pain-edit-dialog.h"

//#include "clg-db-antemodel.h";

#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>

#include <QComboBox>

#include <QPlainTextEdit>
#include <QTextStream>

#include <QTableWidget>

#include <QMessageBox>

#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrlQuery>

#include <QHeaderView>

#include <QListWidget>

#include "silotypes/ndp-project/ndp-project.h"
#include "silotypes/ndp-project/ndp-project-initial.h"

#include "ndp-antemodel.h"


USING_RZNS(NDP)

Pain_Edit_Dialog::Pain_Edit_Dialog(QWidget* parent, QString code)
   //, QString url, QWN_XMLDB_Configuration* config)
 : QDialog(parent), given_code_(code), current_code_(code) //, antemodel_(antemodel)//, config_(config)
{

 button_box_ = new QDialogButtonBox(this);

 button_ok_ = new QPushButton("OK");
 button_proceed_ = new QPushButton("Proceed");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

// button_proceed_->setDefault(false);
// button_proceed_->setAutoDefault(false);

 button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);


 connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));

 main_layout_ = new QFormLayout();

 pain_constancy_label_ = new QLabel("Pain Constancy", this);

 pain_constancy_label_->setToolTip("Describe the frequency of this pain: Occasional, Intermittent, or Constant");

 pain_constancy_combo_box_ = new QComboBox(this);
 pain_constancy_combo_box_->addItem("Occasional (O)");
 pain_constancy_combo_box_->addItem("Intermittent (I)");
 pain_constancy_combo_box_->addItem("Constant (C)");

 QString constancy = code.left(1);
 QString pl = code.mid(2);

 if(constancy == "O")
  pain_constancy_combo_box_->setCurrentIndex(0);
 else if(constancy == "I")
  pain_constancy_combo_box_->setCurrentIndex(1);
 else
  pain_constancy_combo_box_->setCurrentIndex(2);

 pain_intensity_label_ = new QLabel("Pain Intensity", this);
 pain_intensity_label_->setToolTip("Indicate the intensity of this pain (0-10); defaults to 5");

 pain_intensity_combo_box_ = new QComboBox(this);
 pain_intensity_combo_box_->addItem("0");
 pain_intensity_combo_box_->addItem("1");
 pain_intensity_combo_box_->addItem("2");
 pain_intensity_combo_box_->addItem("3");
 pain_intensity_combo_box_->addItem("4");
 pain_intensity_combo_box_->addItem("5");
 pain_intensity_combo_box_->addItem("6");
 pain_intensity_combo_box_->addItem("7");
 pain_intensity_combo_box_->addItem("8");
 pain_intensity_combo_box_->addItem("9");
 pain_intensity_combo_box_->addItem("10");

 pain_intensity_combo_box_->setEditable(true);

 int pain_level = pl.toInt();
 pain_intensity_combo_box_->setCurrentIndex(pain_level);



 connect(pain_intensity_combo_box_, SIGNAL(currentIndexChanged(int)),
         this, SLOT(pain_intensity_combo_box_index_changed(int)));

 connect(pain_intensity_combo_box_, SIGNAL(currentTextChanged(QString)),
         this, SLOT(pain_intensity_combo_box_text_changed(QString)));

 connect(pain_constancy_combo_box_, SIGNAL(currentIndexChanged(int)),
         this, SLOT(pain_constancy_combo_box_index_changed(int)));

 main_layout_->addRow(pain_constancy_label_, pain_constancy_combo_box_);
 main_layout_->addRow(pain_intensity_label_, pain_intensity_combo_box_);

// result_label_ = new QLabel(this);

// main_layout_->insertRow(-1, result_label_);

 QString colorful_button_style_sheet =
  "QPushButton:hover {background:rgb(240,190,150);"
  " border-left: 4px groove rgb(240,190,150); "
  " border-right: 4px ridge rgb(240,190,150); "
  "}\n"
  "QPushButton{ padding:1px;  border: 2px solid rgb(240,190,150); "
  "  border-bottom: 1px solid #CEF51D; "
  " border-radius: 6px; "
  " background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, "
  "  stop: 0 white, stop: 0.1 #C0C0C0, stop: 0.6 #CC"
  "C6BC, stop: 0.8 #ECCFA0, stop: 0.9 darkred,  stop: 1 brown"
  "); min-width: 80px; }";



 QString colorful_button_style_sheet_down =
  "QPushButton {background:rgb(190,190,230);padding-left:20;padding-right:20;padding-top:0;padding-bottom:0;"
  " border-left: 4px groove rgb(240,190,150); "
  " border-right: 4px ridge rgb(240,190,150); "
  "}\n";


// show_button_ = new QPushButton("Show Substituted Source", this);
// show_button_->setCheckable(true);
// show_button_layout_ = new QHBoxLayout;
// show_button_layout_->addStretch();
// show_button_layout_->addWidget(show_button_);
// show_button_layout_->addStretch();
// main_layout_->addLayout(show_button_layout_);
// connect(show_button_, SIGNAL(toggled(bool)), this,
//         SLOT(show_button_toggled(bool)));


 main_layout_->addWidget(button_box_);

 setLayout(main_layout_);

 show();
}


void Pain_Edit_Dialog::pain_intensity_combo_box_index_changed(int index)
{
 current_code_ = current_code_.left(2);
 current_code_ += QString::number(index);
 if(current_code_ != given_code_)
 {
  button_proceed_->setEnabled(true);
  button_cancel_->setEnabled(true);
  button_ok_->setEnabled(false);
 }
}

void Pain_Edit_Dialog::pain_constancy_combo_box_index_changed(int index)
{

}

void Pain_Edit_Dialog::pain_constancy_combo_box_text_changed(QString text)
{

}


Pain_Edit_Dialog::~Pain_Edit_Dialog()
{
 delete button_ok_;
 delete button_proceed_;
 delete button_cancel_;

// delete url_label_;
// delete name_qle_;
}



void Pain_Edit_Dialog::cancel()
{
 Q_EMIT(canceled(this));
 close();
}

void Pain_Edit_Dialog::proceed()
{
 button_cancel_->setEnabled(false);
 button_ok_->setEnabled(true);
 button_proceed_->setEnabled(false);

 Q_EMIT(proceed_requested(current_code_));

//?
// Q_EMIT(open_requested(url_line_edit_->text(), key_line_edit_->text()));
// close();
}

void Pain_Edit_Dialog::accept()
{
 //Q_EMIT(proceed_with_text(this, main_text_edit_->document()->toPlainText()));
 close();
}
