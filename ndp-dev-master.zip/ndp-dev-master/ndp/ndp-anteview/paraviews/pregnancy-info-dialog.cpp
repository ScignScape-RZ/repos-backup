
#include "pregnancy-info-dialog.h"



#include <QApplication>

#include <QMenu>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>

#include <QPlainTextEdit>
#include <QTextStream>

#include <QTableWidget>

#include <QMessageBox>

#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrlQuery>

#include <QHeaderView>

#include <QListWidget>


USING_RZNS(NDP)

//bool Test_Event_Filter::eventFilter(QObject *obj, QEvent *event)
//{
// //?qDebug() << "OBJ: " << obj->objectName();
// return false;
//}

//Test_Event_Filter::Test_Event_Filter(QWidget* parent)
// : QObject(parent)
//{

//}

Pregnancy_Info_Dialog::Pregnancy_Info_Dialog(const Pregnancy_Info_Dialog& rhs)
 //: parent(rhs.parent())
 : deleted_languages_row_count_(0), current_max_language_row_(nullptr)
{
}

void Pregnancy_Info_Dialog::write_state_to(QByteArray& qba)
{
 QDataStream qds(&qba, QIODevice::WriteOnly);
 qds << refugee_name_line_edit_->text();
 qds << refugee_kind_combo_box_->currentIndex();
 qds << registration_date_edit_->date();

 int rc = languages_table_widget_->rowCount();
 qds << rc;

 for(int i = 0; i < rc; ++i)
 {
  QWidget* twi = languages_table_widget_->cellWidget(i, 1);
  Test_Line_Edit* tle = qobject_cast<Test_Line_Edit*>(twi);
  qds << tle->text();
 }

}

void Pregnancy_Info_Dialog::read_state_from(const QByteArray& qba)
{
 QDataStream qds(qba);

 QString rd;
 qds >> rd;
 refugee_name_line_edit_->setText(rd);

 int ci;
 qds >> ci;
 refugee_kind_combo_box_->setCurrentIndex(ci);

 QDate dt;
 qds >> dt;
 registration_date_edit_->setDate(dt);

 int rc;
 qds >> rc;

 for(int i = 0; i < rc; ++i)
 {
  QString text;
  qds >> text;
  if(i > 0)
  {
   add_language_row(current_max_language_row_);
  }
  QWidget* twi = languages_table_widget_->cellWidget(i, 1);
  Test_Line_Edit* tle = qobject_cast<Test_Line_Edit*>(twi);
  tle->setText(text);
 }

 languages_table_widget_->setMaximumHeight(30 * rc);

}

Pregnancy_Info_Dialog::Pregnancy_Info_Dialog(QWidget* parent)//, QString url, QWN_XMLDB_Configuration* config)
 : QDialog(parent), deleted_languages_row_count_(0),
   current_max_language_row_(nullptr)//, antemodel_(antemodel)//, config_(config)
{
 //?tef = new Test_Event_Filter(this);


 button_box_ = new QDialogButtonBox(this);

 //?url_label_ = new QLabel(this);
  //?url_label_->setText(url);

// name_qle_ = new QLineEdit(this);

 button_ok_ = new QPushButton("OK");
 button_proceed_ = new QPushButton("Proceed");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

 button_proceed_->setDefault(false);
 button_proceed_->setAutoDefault(false);

 button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);


 connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));

 main_layout_ = new QVBoxLayout();

 top_layout_ = new QFormLayout();

// refugee_name_label_ = new QLabel("Name:", this);
// refugee_name_line_edit_ = new QLineEdit(this);

 name_age_layout_ = new QHBoxLayout;

 number_weeks_label_ = new QLabel("Number of Weeks Pregnant:", this);
 number_weeks_combo_box_ = new QComboBox(this);
 number_weeks_combo_box_->addItem("Not Sure", "N/S");
 for(int i = 1; i <= 40; ++i)
 {
  number_weeks_combo_box_->addItem(QString::number(i));
 }
 number_weeks_combo_box_->setEditable(true);

// number_weeks_combo_box_->addItem("Refugee", "R");
// number_weeks_combo_box_->addItem("Asylum-seeker", "AS");
// number_weeks_combo_box_->addItem("Returned Refugee", "RR");
// number_weeks_combo_box_->addItem("Internally Displaced", "IDP");
// number_weeks_combo_box_->addItem("Returned Internally Displaced", "RIDP");
// refugee_kind_combo_box_->addItem("Stateless Mandate", "SM");
// refugee_kind_combo_box_->addItem("Other", "O");

 refugee_name_label_ = new QLabel("Name:", this);
 refugee_name_line_edit_ = new QLineEdit(this);

 refugee_age_label_ = new QLabel("Age:", this);
 refugee_age_line_edit_ = new QLineEdit(this);

//?
 refugee_age_line_edit_->setMaximumWidth(20);

 name_age_layout_->addStretch();

 name_age_layout_->addWidget(refugee_age_label_);
 name_age_layout_->addWidget(refugee_age_line_edit_);

 name_age_layout_->addStretch();

 name_age_layout_->addWidget(number_weeks_label_);
 name_age_layout_->addWidget(number_weeks_combo_box_);

 name_age_layout_->addStretch();


 refugee_kind_label_ = new QLabel("Refugee Classification:", this);
 refugee_kind_combo_box_ = new QComboBox(this);
 refugee_kind_combo_box_->addItem("Refugee", "R");
 refugee_kind_combo_box_->addItem("Asylum-seeker", "AS");
 refugee_kind_combo_box_->addItem("Returned Refugee", "RR");
 refugee_kind_combo_box_->addItem("Internally Displaced", "IDP");
 refugee_kind_combo_box_->addItem("Returned Internally Displaced", "RIDP");
 refugee_kind_combo_box_->addItem("Stateless Mandate", "SM");
 refugee_kind_combo_box_->addItem("Other", "O");

 refugee_kind_combo_box_->setEditable(true);
 refugee_kind_combo_box_->setToolTip("Refugee Classification (see UNHCR guidelines)");


 top_layout_->addRow(refugee_name_label_, refugee_name_line_edit_);

 //?top_layout_->addRow(refugee_name_label_, refugee_name_line_edit_);
 top_layout_->insertRow(-1, name_age_layout_);

 top_layout_->addRow(refugee_kind_label_, refugee_kind_combo_box_);

 registration_date_label_  = new QLabel("Date of Registration", this);
 registration_date_label_->setToolTip("Enter date when this refugee is first processed by your organization");
 registration_date_edit_ = new QDateEdit(this);
 registration_date_edit_->setToolTip("Enter date when this refugee is first processed by your organization");

 registration_date_edit_->setCalendarPopup(true);
 registration_date_edit_->setDate(QDate::currentDate());

 registration_date_calendar_widget_ = new Event_Calendar_Widget(this);
 registration_date_edit_->setCalendarWidget(registration_date_calendar_widget_);

// connect(registration_date_calendar_widget_, SIGNAL(clicked(const QDate)),
//   this, SLOT(registration_date_clicked(const QDate)));

// connect(registration_date_calendar_widget_, SIGNAL(activated(QDate)),
//   this, SLOT(registration_date_activated(const QDate)));

 connect(registration_date_calendar_widget_, SIGNAL(context_menu_requested(QDate,QPoint)),
   this, SLOT(handle_registration_calendar_context_menu_requested(QDate,QPoint)));



 QString colorful_button_quiet_style_sheet =
  "QPushButton:hover {background:rgb(150,240,190);"
  " border-left: 4px groove rgb(150,240,190); "
  " border-right: 4px ridge rgb(150,240,190); "
  "}\n"
  "QPushButton:checked {background:rgb(200,10,100);"
  " border-left: 4px groove rgb(200,10,100); "
  " border-right: 4px ridge rgb(200,10,100); "
  "}\n"
  "QPushButton{ padding:1px;  border: 1px solid rgb(150,240,190);"
  "  border-bottom: 1px solid #CEF51D; "
  " border-radius: 0px; "
  " background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, "
  "  stop: 0 white, stop: 0.1 #C0C0C0, stop: 0.6 #C6CCBC "
  "  stop: 0.8 #A0ECCF, stop: 0.9 darkseagreen,  stop: 1 blue"
  "); min-width: 80px; }";


 QString colorful_button_style_sheet =
  "QPushButton:hover {background:rgb(240,190,150);"
  " border-left: 4px groove rgb(240,190,150); "
  " border-right: 4px ridge rgb(240,190,150); "
  "}\n"
  "QPushButton{ padding:4px;  border: 2px solid rgb(240,190,150); "
  "  border-bottom: 1px solid #CEF51D; "
  " border-radius: 6px; "
  " background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, "
  "  stop: 0 white, stop: 0.1 #C0C0C0, stop: 0.6 #CC"
  "C6BC, stop: 0.8 #ECCFA0, stop: 0.9 darkred,  stop: 1 brown"
  "); min-width: 80px; }";



 QString colorful_button_style_sheet_down =
  "QPushButton {background:rgb(190,190,230);padding-left:20;padding-right:20;padding-top:0;padding-bottom:0;"
  " border-left: 4px groove rgb(240,190,150); "
  " border-right: 4px ridge rgb(240,190,150); "
  "}\n";


 QFrame* line01 = new QFrame(this);
     line01->setGeometry(QRect(320, 150, 118, 3));
     line01->setFrameShape(QFrame::HLine);
     line01->setFrameShadow(QFrame::Raised);
 QFrame* line02 = new QFrame(this);
         line02->setGeometry(QRect(320, 150, 118, 1));
         line02->setFrameShape(QFrame::HLine);
         line02->setFrameShadow(QFrame::Sunken);

 line01->setStyleSheet("QFrame{background:rgba(255,200,200,0.7)}");
 line02->setStyleSheet("QFrame{background:rgba(255,200,200,0.7)}");


// calendar_frame_ = new QFrame(this);
// calendar_layout_ = new QHBoxLayout;
// calendar_push_button_ = new QPushButton("Calendar", this);
// calendar_push_button_->setStyleSheet(colorful_button_style_sheet);
// //?calendar_push_button_->setStyleSheet(colorful_button_quiet_style_sheet);
// connect(calendar_push_button_, SIGNAL(clicked()), this,
//   SLOT(calendar_button_clicked()));
// calendar_layout_->addStretch();
// calendar_layout_->addWidget(calendar_push_button_);
// calendar_layout_->addStretch();
// calendar_frame_->setLayout(calendar_layout_);

 top_layout_->insertRow(-1, line01);

 top_layout_->addRow(registration_date_label_, registration_date_edit_);

 //?top_layout_->insertRow(-1, calendar_frame_);
 top_layout_->insertRow(-1, line02);

// top_layout_->addRow(state_label_, state_combo_box_);


// name_of_primary_care_provider_label_ = new QLabel("Name of Primary Care Provider", this);
// name_of_primary_care_provider_line_edit_ = new QLineEdit(this);
// top_layout_->addRow(name_of_primary_care_provider_label_, name_of_primary_care_provider_line_edit_);

// most_recent_visit_label_ = new QLabel("Last Visit to PCP", this);
// most_recent_visit_layout_ = new QHBoxLayout;
// most_recent_visit_line_edit_ = new QLineEdit(this);
// most_recent_visit_button_ = new QPushButton("Calendar");

// most_recent_visit_button_->setStyleSheet(colorful_button_style_sheet);
// most_recent_visit_layout_->addWidget(most_recent_visit_line_edit_);
// most_recent_visit_layout_->addWidget(most_recent_visit_button_);
// top_layout_->addRow(most_recent_visit_label_, most_recent_visit_layout_);



// symptoms_label_ = new QLabel("Describe your Symptoms", this);

// symptoms_buttons_ = new QHBoxLayout;
// symptoms_pictures_button_ = new QPushButton("Pictures", this);
// symptoms_activities_button_ = new QPushButton("Activities", this);
////? symptoms_list_button_ = new QPushButton("Check List", this);

// symptoms_pictures_button_->setStyleSheet(colorful_button_style_sheet);
// symptoms_activities_button_->setStyleSheet(colorful_button_style_sheet);
// //? symptoms_list_button_->setStyleSheet(colorful_button_style_sheet);

// symptoms_buttons_->addStretch();
// symptoms_buttons_->addWidget(symptoms_pictures_button_);
// symptoms_buttons_->addStretch();
// symptoms_buttons_->addWidget(symptoms_activities_button_);
// symptoms_buttons_->addStretch();
// // symptoms_buttons_->addWidget(symptoms_list_button_);
// // symptoms_buttons_->addStretch();

// symptoms_text_ = new QHBoxLayout;


// description_text_label_ = new QLabel("Describe the incident (opens a text entry area):", this);
// description_text_button_ = new QPushButton("Describe", this);
// description_text_button_->setStyleSheet(colorful_button_style_sheet);

// QFont font = description_text_button_->font();
// font.setPointSize(9);
// description_text_button_->setFont(font);

// description_text_layout_ = new QHBoxLayout;

// //?
// description_text_layout_->addStretch();
// description_text_layout_->addWidget(description_text_label_);
// //?symptoms_text_->addStretch();
// description_text_layout_->addWidget(description_text_button_);
//////? symptoms_text_->addStretch();


// QFrame* line1 = new QFrame(this);
//     line1->setGeometry(QRect(320, 150, 118, 3));
//     line1->setFrameShape(QFrame::HLine);
//     line1->setFrameShadow(QFrame::Raised);
// QFrame* line2 = new QFrame(this);
//         line2->setGeometry(QRect(320, 150, 118, 1));
//         line2->setFrameShape(QFrame::HLine);
//         line2->setFrameShadow(QFrame::Sunken);
// //line2->setB
// line1->setStyleSheet("QFrame{background:rgba(255,200,200,0.7)}");
// line2->setStyleSheet("QFrame{background:rgba(255,200,200,0.7)}");

// top_layout_->insertRow(-1, line1);
// //top_layout_->addRow(description_label_, symptoms_buttons_);
// top_layout_->insertRow(-1, description_text_layout_);
// top_layout_->insertRow(-1, line2);



 mid_layout_ = new QFormLayout;

//? mid_layout_->addRow(most_recent_visit_label_, most_recent_visit_layout_);


//? symptoms_list_box_ = new QListWidget(this);
//? top_layout_->insertRow(-1, symptoms_list_box_);


 languages_table_widget_ = new QTableWidget(this);
 languages_table_widget_->setColumnCount(3);
 languages_table_widget_->setRowCount(0);

 languages_table_widget_->verticalHeader()->setVisible(false);
 languages_table_widget_->horizontalHeader()->setVisible(false);

 languages_table_widget_->horizontalHeader()->setStretchLastSection(true);

 //?languages_frame_ = new QFrame(this);
 languages_group_ = new QGroupBox("List Refugee's Languages ...", this);
 languages_scroll_area_ = new QScrollArea(this);

 languages_group_layout_ = new QVBoxLayout;

 //languages_group_layout_->addLayout(languages_layout_);
 languages_group_layout_->addWidget(languages_table_widget_);

 //languages_group_->setMinimumHeight(200);

// connect(languages_table_widget_, SIGNAL(cellDoubleClicked(int,int)),
//   this, SLOT(languages_table_widget_cell_double_clicked(int,int)));

 connect(languages_table_widget_, SIGNAL(cellEntered(int,int)),
   this, SLOT(languages_table_widget_cell_entered(int,int)));

 connect(languages_table_widget_, SIGNAL(itemEntered(QTableWidgetItem*)),
   this, SLOT(languages_table_widget_item_entered(QTableWidgetItem*)));

//?
 languages_table_widget_->setMouseTracking(true);

 languages_table_widget_->setContextMenuPolicy(Qt::ActionsContextMenu);

 //connect(artist_clear_fields_action, SIGNAL(triggered()), this, SLOT(artist_clear_fields_action_triggered()));
 //?DEFAULT_CONNECT_(artist_clear_fields_action ,triggered)


 languages_table_widget_->horizontalHeader()->setSectionResizeMode(1, QHeaderView::Stretch);
 //?languages_table_widget_->horizontalHeader()->setSectionResizeMode(2, QHeaderView::Fixed);

 //languages_table_widget_->horizontalHeader()->setStretchLastSection(false);

 languages_table_widget_->verticalHeader()->setStretchLastSection(false);
 languages_table_widget_->resizeRowsToContents();
 //languages_table_widget_->verticalHeader()->setStretchLastSection(true);
 languages_table_widget_->setSizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);

 button_more_languages_ = new QPushButton("Add Row...", this);

//? button_more_languages_->setStyleSheet(colorful_button_style_sheet);
 button_more_languages_->setStyleSheet(colorful_button_quiet_style_sheet);

 languages_table_widget_->setRowHeight(0, 30);
 languages_table_widget_->setMaximumHeight(30);

 languages_table_widget_->setAcceptDrops(true);
 languages_table_widget_->setDragEnabled(true);
 languages_table_widget_->setDragDropOverwriteMode(true);
 languages_table_widget_->setDragDropMode(QAbstractItemView::DragDrop);
 languages_table_widget_->setDefaultDropAction(Qt::CopyAction);

 connect(languages_table_widget_, SIGNAL(cellEntered(int,int)),
   this, SLOT(languages_table_widget_cell_entered(int, int)));


 //languages_table_widget_->setColumnWidth(2, 20);

 connect(button_more_languages_, SIGNAL(clicked()),
   this, SLOT(button_more_languages_clicked()));

//? DEFAULT_CONNECT(button_more_languages_ ,clicked)


 button_more_languages_layout_ = new QHBoxLayout;

 button_more_languages_layout_->addStretch();

 button_more_languages_layout_->addWidget(button_more_languages_);
 button_more_languages_layout_->addStretch();

 languages_group_layout_->addLayout(button_more_languages_layout_);

 languages_group_->setLayout(languages_group_layout_);

 languages_scroll_area_->setWidget(languages_group_);

 languages_scroll_area_->setWidgetResizable(true);

 // //  set from 150 to 180 for a screen shot ...
 languages_scroll_area_->setMinimumHeight(180);

 languages_scroll_area_->setFrameShape(QFrame::Panel);

 languages_scroll_area_->setFrameShadow(QFrame::Raised);

 //languages_scroll_area_->setStyleSheet("border-color:solid cyan 1px;");

 mid_layout_->insertRow(-1, languages_scroll_area_);

//? main_layout_->addWidget(languages_scroll_area_);


// query_file_label_ = new QLabel("Query File: ");
// query_file_line_edit_ = new QLineEdit();
// top_layout_->addRow(query_file_label_, query_file_line_edit_);


 main_layout_->addLayout(top_layout_);
 main_layout_->addStretch();


 check_boxes_layout_ = new QGridLayout;

 QLabel* risk_factors = new QLabel("Risk Factors:");

 check_boxes_layout_->addWidget(risk_factors, 0, 0, 1, 4);


 //l1_ = new QLabel("L1");

 cb_low_bmi_ = new QCheckBox("Low BMI (< 20 kg/m2)", this);
 cb_high_blood_pressure_ = new QCheckBox("High Blood Pressure (> 140/90)", this);
 cb_hiv_positive_ = new QCheckBox("HIV Positive", this);
 cb_iron_deficiency_ = new QCheckBox("Iron Deficiency", this);
 cb_gestational_diabetes_ = new QCheckBox("Gestational Diabetes", this);
 cb_history_of_preclampsia_ = new QCheckBox("History of Preclampsia", this);
 cb_pcos_ = new QCheckBox("Polycystic Ovary Syndrome (PCOS)", this);
 cb_prior_csection_ = new QCheckBox("Prior C-Section", this);

 check_boxes_layout_->addWidget(cb_low_bmi_, 1, 1);
 check_boxes_layout_->addWidget(cb_high_blood_pressure_, 1, 2);

 check_boxes_layout_->addWidget(cb_hiv_positive_, 1, 3);
 check_boxes_layout_->addWidget(cb_iron_deficiency_, 1, 4);


 check_boxes_layout_->addWidget(cb_gestational_diabetes_, 2, 1);
 check_boxes_layout_->addWidget(cb_history_of_preclampsia_, 2, 2);

 check_boxes_layout_->addWidget(cb_pcos_, 2, 3);
 check_boxes_layout_->addWidget(cb_prior_csection_, 2, 4);


 main_layout_->addLayout(check_boxes_layout_);

 QFrame* line03 = new QFrame(this);
     line03->setGeometry(QRect(320, 150, 118, 3));
     line03->setFrameShape(QFrame::HLine);
     line03->setFrameShadow(QFrame::Raised);
// QFrame* line02 = new QFrame(this);
//         line02->setGeometry(QRect(320, 150, 118, 1));
//         line02->setFrameShape(QFrame::HLine);
//         line02->setFrameShadow(QFrame::Sunken);

 line03->setStyleSheet("QFrame{background:rgba(255,200,200,0.7)}");
// line02->setStyleSheet("QFrame{background:rgba(255,200,200,0.7)}");

 main_layout_->addWidget(line03);

 main_layout_->addStretch();

 main_layout_->addLayout(mid_layout_);
 main_layout_->addStretch();

 main_layout_->addWidget(button_box_);

 setLayout(main_layout_);

 set_query_file_from_api_choice(0);

 add_language_row(nullptr);

 connect(this, &Pregnancy_Info_Dialog::load_event_by_date_requested,
   [](Pregnancy_Info_Dialog* _this, QDate qd)
  {
   _this->notify_event_not_found(qd);
  });

// // connect(api_choice_combo_box_, SIGNAL(currentIndexChanged(int)),
//  this, SLOT(set_query_file_from_api_choice(int)));

 show();
}

void Pregnancy_Info_Dialog::handle_registration_calendar_context_menu_requested
  (QDate qd, QPoint qp)
{

 last_context_date_ = qd;

 QMenu* m = new QMenu(this);
 QAction* a = m->addAction("Check Appointments ...");

 connect(a, SIGNAL(triggered()), this, SLOT(load_appointment_by_date()));

 m->exec(qp);

}

void Pregnancy_Info_Dialog::load_appointment_by_date()
{
 if(last_context_date_.isValid())
 {
  Q_EMIT(load_event_by_date_requested(this, last_context_date_));
 }

}


void Pregnancy_Info_Dialog::notify_event_not_found(QDate date)
{
 QMessageBox::information(this, "No Events found",
   QString("No events found for this date: %1").arg(date.toString()));
}


void Pregnancy_Info_Dialog::calendar_button_clicked()
{

}


void Pregnancy_Info_Dialog::activate_search(QString text)
{
// named_entity_line_edit_->setText(text);
// QString ch = api_choice_combo_box_->currentData().toString();
// current_request_url_ = antemodel_->get_request_url_from_api_name(ch, text);
// url_text_edit_->setText(current_request_url_);
}

void Pregnancy_Info_Dialog::named_entity_line_edit_editing_finished()
{
// QString new_text = named_entity_line_edit_->text();
// if(new_text.isEmpty())
// {
//  url_text_edit_->setText("");
// }
// else
// {
//  QString ch = api_choice_combo_box_->currentData().toString();
//  current_request_url_ = antemodel_->get_request_url_from_api_name(ch, new_text);
//  url_text_edit_->setText(current_request_url_);
// }
}

void Pregnancy_Info_Dialog::set_query_file_from_api_choice(int)
{
// QString ch = api_choice_combo_box_->currentData().toString();
// current_query_file_path_ = antemodel_->get_query_file_path_from_api_name(ch);
// query_file_line_edit_->setText(current_query_file_path_);

// named_entity_line_edit_editing_finished();
}


void Pregnancy_Info_Dialog::select_query_template_file_clicked()
{
// QString path = QFileDialog::getOpenFileName(this, "Select template file");
// if(!path.isEmpty())
// {
//  query_template_file_->setText(path);
// }
// read_file(path, query_template_text_);
}

void Pregnancy_Info_Dialog::read_file(QString path, QPlainTextEdit* qpte)
{
 QFile file(path);
 if(file.open(QIODevice::ReadOnly | QIODevice::Text))
 {
  QTextStream in_stream(&file);
  QString result = in_stream.readAll();
  qpte->setPlainText(result);
 }
}

PLanguage_Row::PLanguage_Row(QWidget* parent)
  :
   language_index(new QTableWidgetItem),
   language_description(new QTableWidgetItem),
   language_options(new QTableWidgetItem),
   index(new QLabel(parent)),
   description(new Test_Line_Edit(parent)),
   options_frame(new QFrame(parent)),

//?   options(new QLabel("Options...", options_frame)),
   options(new QLabel("...", options_frame)),
   cut(new QPushButton(QChar(0xD7), options_frame)),
   options_layout(new QVBoxLayout),
   options_label_layout(new QHBoxLayout),
   options_cut_layout(new QHBoxLayout),
   next_row(nullptr)
{
 options_cut_layout->addStretch();
 options_cut_layout->addWidget(cut);
 options_label_layout->addStretch();
 options_label_layout->addWidget(options);
 options_label_layout->addStretch();

 options_cut_layout->setSpacing(0);
 options_cut_layout->setMargin(0);

 options_layout->setSpacing(0);
 options_layout->setMargin(0);
 options_label_layout->setSpacing(0);
 options_label_layout->setMargin(0);


 options_layout->addLayout(options_cut_layout);
 options_layout->addLayout(options_label_layout);


 options_label_layout->setContentsMargins(0, 0, 0, 0);

 options_layout->setContentsMargins(0, 0, 0, 0);
 options_cut_layout->setContentsMargins(0, 0, 0, 0);

 options_frame->setLayout(options_layout);

 //options_frame->setStyleSheet("border:solid red 3px;");


 QString ss = //"QFrame{background: red; margin:0px;padding:0px}"
   "QPushButton{margin:0px;padding:0px;border:none;"
   "background-color:qlineargradient(x1:0,y1:0,x2:0,y2:1,"
                                          "stop:0#eaebfe,stop:1#76878a);"
   //"background-color:pink;"
   "}"
   "QPushButton:hover{background: white; margin:0px;padding:0px;border:none}"
   "QFrame{background: lavender; margin:0px;padding:0px;}"
   "QLabel:hover{background: pink; margin:0px;padding:0px}"
   ;
 options_frame->setStyleSheet(ss);

 //?options_frame->setMaximumWidth(20);

// twi_code->setFlags(Qt::ItemIsEditable | Qt::ItemIsEnabled);
// twi_name->setFlags(Qt::ItemIsEditable | Qt::ItemIsEnabled);
 //artists_table_widget_->setEditTriggers(QAbstractItemView::AllEditTriggers);


}

void Pregnancy_Info_Dialog::button_more_languages_clicked()
{
// if(current_artist_entry_row_ != -1)
// {
//  QMessageBox::information(this, "Add one artist at a time",
//    "Use the current empty fields to provide artist information");
//  return;
// }
 add_language_row(current_max_language_row_); //nullptr);

 languages_table_widget_->setMaximumHeight(
   languages_table_widget_->maximumHeight() + languages_table_widget_->rowHeight(0));

 languages_table_widget_->setMinimumHeight(
   languages_table_widget_->maximumHeight() + 2);

}

void Pregnancy_Info_Dialog::languages_table_widget_item_entered(QTableWidgetItem* item)
{
 //qDebug() << "Item:" << item->row() << item->column();
}

void Pregnancy_Info_Dialog::languages_table_widget_cell_entered(int row, int col)
{
 if(col == 1)
 {
  QTableWidgetItem* twi = languages_table_widget_->item(row, col);
  QLineEdit* le = qobject_cast<QLineEdit*>( languages_table_widget_->cellWidget(row, col));
  if(le)
   le->setText("???");
 }

}


void Pregnancy_Info_Dialog::add_language_row(PLanguage_Row* prior_row)
{
 PLanguage_Row* row = new PLanguage_Row(this);
 row->description->set_containing_table_widget(languages_table_widget_);
 row->description->set_containing_dialog(this);
//? row->index->set_containing_dialog(this);

 if(prior_row)
  prior_row->next_row = row;

 int row_count = languages_table_widget_->rowCount();

 row->index->setText(QString::number(row_count + 1));
 //?row->index->setMaximumWidth(7);

 //?
 row->index->setStyleSheet("QLabel{font-weight:600;"
                           "font-family: Tahoma;font-style: normal;"
                           "}"
                           ); //ont-size:11pt;font-face:tahoma}");

 row->language_index->setBackgroundColor(QColor::fromRgb(240,220,240));
// row->index->setBackgroundRole(QPalette::AlternateBase);

 languages_table_widget_->setRowCount(row_count + 1);

 current_max_language_row_ = row;


 //?current_artist_entry_row_ = row_count;
 //?row->cut->setMaximumWidth(50);

 connect(row->cut, &QPushButton::clicked,
         [this, row, row_count]
 {
//  if(row_count == 0 && tda_by_row_.size() <= 1)
//  {
//   //?artist_clear_fields(0);
//   return;
//  }
  languages_table_widget_->setMaximumHeight
    (languages_table_widget_->maximumHeight() - languages_table_widget_->rowHeight(row_count));

  if(current_languages_row_ > row_count)
   --current_languages_row_;
  languages_table_widget_->setMinimumHeight
    (languages_table_widget_->maximumHeight());

  int rc = languages_table_widget_->rowCount();

  languages_table_widget_->removeRow(row_count);
  ++deleted_languages_row_count_;

  PLanguage_Row* temp_current_row = row->next_row;


  // setDragDropMode(QtGui.QAbstractItemView.InternalMove)
  for(int i = row_count; i < rc; ++i)
  {
   if(!temp_current_row)
    break;
   if(i == 0)
   {
    temp_current_row->description->setPlaceholderText("Language Name ...");
   }
   temp_current_row->index->setText(QString::number(i + 1));
   current_max_language_row_ = temp_current_row;
   temp_current_row = temp_current_row->next_row;

  }

//   languages_table_widget_->takeItem()
//   languages_table_widget_->setItem(i, 0, temp_current_row->language_index);
//   languages_table_widget_->setItem(i, 1, temp_current_row->language_description);
//   languages_table_widget_->setItem(i, 2, temp_current_row->language_options);

//   languages_table_widget_->setCellWidget(i, 0, temp_current_row->index);
//   languages_table_widget_->setCellWidget(i, 1, temp_current_row->description);
//   languages_table_widget_->setCellWidget(i, 2, temp_current_row->options_frame);

//   temp_current_row = temp_current_row->next_row;
//  }


//  languages_table_widget_->update();
//  int ra = languages_table_widget_->rowAt(row_count - 1)
  //rowAt(row_count-1);
//  if(row->artist)
//  {
////?   tda_by_row_.removeOne(row->artist);
//  }
 });


 languages_table_widget_->setItem(row_count, 0, row->language_index);
 languages_table_widget_->setItem(row_count, 1, row->language_description);
 languages_table_widget_->setItem(row_count, 2, row->language_options);
// languages_table_widget_->setItem(row_count, 1, row->year);
// languages_table_widget_->setItem(row_count, 2, row->description);
// languages_table_widget_->setItem(row_count, 3, row->twi_options);


 languages_table_widget_->setCellWidget(row_count, 0, row->index);
//?//?
 languages_table_widget_->setCellWidget(row_count, 1, row->description);
 languages_table_widget_->setCellWidget(row_count, 2, row->options_frame);

// row->description->setDragEnabled(true);
// row->description->setAcceptDrops(true);
// row->language_description->setFlags(row->language_description->flags() | Qt::ItemIsDropEnabled);

 //languages_table_widget_->setColumnWidth(2, 40);

 //languages_table_widget_->horizontalHeader()->resizeSection(2, 40);
 //languages_table_widget_->setColumnWidth(2, 40);

 languages_table_widget_->horizontalHeader()->setStretchLastSection(false);
 //languages_table_widget_->setSectionResizeMode(1, QHeaderView::Stretch);
 //languages_table_widget_->setColumnWidth(0, 20);

 languages_table_widget_->setColumnWidth(2, row->options_frame->width() + 3);

 languages_table_widget_->setColumnWidth(0, row->index->width() + 3);

// languages_table_widget_->setDragDropMode(QAbstractItemView::InternalMove);
// languages_table_widget_->setDragDropOverwriteMode(true);
// languages_table_widget_->setDragEnabled(true);



 //row->options_frame->setMaximumWidth(30);

 //?languages_table_widget_->horizontalHeader()->setFixedWidth(20);

//?
 if(row_count == 0)
 {
  row->description->setPlaceholderText("Language Name ...");
 }

// if(tda)
// {
//  QString c = tda->code();
//  QString n = tda->name();
//  row->code->setText(c);
//  row->name->setText(n);
//  row->artist = tda;
// }

 //?languages_layout_->addRow(new_artist_code, new_artist_name);

 //languages_group_->update();

 //update();

}




Pregnancy_Info_Dialog::~Pregnancy_Info_Dialog()
{
 delete button_ok_;
 delete button_proceed_;
 delete button_cancel_;

// delete url_label_;
// delete name_qle_;
}



void Pregnancy_Info_Dialog::proceed()
{
 button_ok_->setEnabled(true);
  //button_cancel_->setEnabled(false);
 button_proceed_->setEnabled(false);

}


void Pregnancy_Info_Dialog::cancel()
{
 Q_EMIT(canceled(this));
// close();
}

void Pregnancy_Info_Dialog::accept()
{
 Q_EMIT(accepted(this));
// close();
}
