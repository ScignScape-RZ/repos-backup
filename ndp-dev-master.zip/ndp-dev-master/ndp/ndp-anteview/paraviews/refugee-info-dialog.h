
#ifndef REFUGEE_INFO_DIALOG__H
#define REFUGEE_INFO_DIALOG__H


#include <QString>
#include <QMainWindow>

#include <QTextEdit>
//?#include <QWebView>
#include <QLabel>
#include <QPushButton>
#include <QLineEdit>
#include <QDialog>

#include <QComboBox>
#include <QDateEdit>

#include "accessors.h"

#include "flags.h"

#include "rzns.h"

#include "event-calendar-widget.h"

#include "intake/intake-treatment-history-dialog.h"

//#include "incident-form-dialog.h"

class QPushButton;
class QTextEdit;
class QPlainTextEdit;
class QLineEdit;
class QTabWidget;
class QDialogButtonBox;
class QVBoxLayout;
class QHBoxLayout;
class QCheckBox;
class QFormLayout;
class QSplitter;
class QGridLayout;
class QListWidget;
class QTableWidget;
class QScrollArea;
class QGroupBox;
class QTableWidgetItem;


class Event_Calendar_Widget;

//RZNS_(QWN)
namespace RZ{ namespace NDP{


//?class CLG_DB_Antemodel;

class Test_Line_Edit;
class Test_Label;

struct Language_Row
{
 QTableWidgetItem* language_index;
 //?QTableWidgetItem* observer_year;
 QTableWidgetItem* language_description;
 QTableWidgetItem* language_options;

 QLabel* index;
 //?QLineEdit* year;
 Test_Line_Edit* description;

 QFrame* options_frame;
 QVBoxLayout* options_layout;
 QHBoxLayout* options_cut_layout;
 QHBoxLayout* options_label_layout;

 QLabel* options;
 QPushButton* cut;

 Language_Row* next_row;
// CLG_DB_Artist* artist;
// CLG_DB_Author* author;

 //QPushButton* cut_button = new QPushButton(QChar(0xD7), cut_frame);

 Language_Row(QWidget* parent = nullptr);
};


//class Test_Event_Filter : public QObject
//{
// Q_OBJECT

//protected:
//  bool eventFilter(QObject *obj, QEvent *event);

//public:

// Test_Event_Filter(QWidget* parent);

//};

#ifdef HIDE
class Test_Line_Edit : public QLineEdit
{
 Q_OBJECT

 QDialog* containing_dialog_;
 QTableWidget* containing_table_widget_;

public:

 Test_Line_Edit(QWidget* parent);

 ACCESSORS(QDialog* ,containing_dialog)
 ACCESSORS(QTableWidget* ,containing_table_widget)

 void dragEnterEvent(QDragEnterEvent *e) override;
 void dropEvent(QDropEvent *e) override;
};


class Test_Label : public QLineEdit
{
 Q_OBJECT

 QDialog* containing_dialog_;

public:

 Test_Label(QWidget* parent);

 ACCESSORS(QDialog* ,containing_dialog)

 void dragLeaveEvent(QDragLeaveEvent *e) override;
};
#endif

class Refugee_Info_Dialog: public QDialog
{
 Q_OBJECT

 QString move_string_;

 //Test_Event_Filter* tef;

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QPushButton* button_proceed_;

// QLabel* api_choice_label_;
// QComboBox* api_choice_combo_box_;

 QLabel* refugee_name_label_;
 QLineEdit* refugee_name_line_edit_;

 QLabel* refugee_age_label_;
 QLineEdit* refugee_age_line_edit_;

// QLabel* gender_label_;
// QComboBox* gender_combo_box_;

// QLabel* state_label_;
// QComboBox* state_combo_box_;

// QLabel* symptoms_label_;

// QHBoxLayout* symptoms_buttons_;
// QPushButton* symptoms_pictures_button_;
// QPushButton* symptoms_activities_button_;
// // QPushButton* symptoms_list_button_;


// QHBoxLayout* description_text_layout_;
// QLabel* description_text_label_;
// QPushButton* description_text_button_;

// QLabel* name_of_primary_care_provider_label_;
// QLineEdit* name_of_primary_care_provider_line_edit_;

// QLabel* most_recent_visit_label_;
// QHBoxLayout* most_recent_visit_layout_;
// QLineEdit* most_recent_visit_line_edit_;
// QPushButton* most_recent_visit_button_;


//? QListWidget* symptoms_list_box_;

// QComboBox* symptoms_combo_box_;

 QLabel* refugee_kind_label_;
 QComboBox* refugee_kind_combo_box_;


 QLabel* registration_date_label_;
 QDateEdit* registration_date_edit_;

 Event_Calendar_Widget* registration_date_calendar_widget_;

// QFrame* calendar_frame_;
// QHBoxLayout* calendar_layout_;
// QPushButton* calendar_push_button_;

 QTableWidget* languages_table_widget_;

 QVBoxLayout* languages_group_layout_;
 QScrollArea* languages_scroll_area_;
 QGroupBox* languages_group_;

 QPushButton* button_more_languages_;
 QHBoxLayout* button_more_languages_layout_;

 int current_languages_row_;
 int deleted_languages_row_count_;

//? QFrame* observers_frame_;

// QLabel* manufacturer_label_;
// QComboBox* manufacturer_combo_box_;

// QLabel* serious_label_;
// QCheckBox* serious_check_box_;

// QLabel* recovered_label_;
// QCheckBox* recovered_check_box_;

 QFormLayout* top_layout_;
 QFormLayout* mid_layout_;

// QLabel* url_label_;
// QTextEdit* url_text_edit_;

// QLabel* query_file_label_;
// QLineEdit* query_file_line_edit_;

// QPlainTextEdit* query_template_text_;
// QPushButton* select_query_template_file_;

 QVBoxLayout* main_layout_;
 QHBoxLayout* query_file_layout_;

 QString current_query_file_path_;
 QString current_request_url_;

 //CLG_DB_Antemodel* antemodel_;

 Language_Row* current_max_language_row_;

 QDate last_context_date_;

 //?QWN_XMLDB_Configuration* config_;

 void read_file(QString path, QPlainTextEdit* qpte);

 void add_language_row(Language_Row* prior_row);


 QHBoxLayout* name_age_layout_;
// QFormLayout* checkbox_layout_;
// QCheckBox* convert_mhix_ckb_;
// QCheckBox* convert_xml_ckb_;
// QCheckBox* save_file_ckb_;
// QCheckBox* auto_save_file_ckb_;
// QCheckBox* save_bookmark_ckb_;

// void init_checkboxes(QFormLayout& qfl);

public:

 ACCESSORS(QString ,move_string)


 Refugee_Info_Dialog(QWidget* parent = nullptr);//, QString url, QWN_XMLDB_Configuration* config);
 Refugee_Info_Dialog(const Refugee_Info_Dialog& rhs);

 void write_state_to(QByteArray& qba);
 void read_state_from(const QByteArray& qba);


 ~Refugee_Info_Dialog();

 void activate_search(QString text);


Q_SIGNALS:
 void accepted(Refugee_Info_Dialog*);
 void canceled(QDialog*);
 void proceed_requested(Refugee_Info_Dialog*, QString, QString);
 void load_event_by_date_requested(Refugee_Info_Dialog*, QDate);

public Q_SLOTS:
 void accept();
 void cancel();
 void proceed();

 void languages_table_widget_cell_entered(int row, int col);
 void languages_table_widget_item_entered(QTableWidgetItem* item);

 void button_more_languages_clicked();

 void calendar_button_clicked();

 void select_query_template_file_clicked();
 void set_query_file_from_api_choice(int);
 void named_entity_line_edit_editing_finished();

 void handle_registration_calendar_context_menu_requested(QDate,QPoint);

 void load_appointment_by_date();
 void notify_event_not_found(QDate date);

};

} } //_RZNS(NDP)

Q_DECLARE_METATYPE(RZ::NDP::Refugee_Info_Dialog*)
Q_DECLARE_METATYPE(RZ::NDP::Refugee_Info_Dialog)

#endif
