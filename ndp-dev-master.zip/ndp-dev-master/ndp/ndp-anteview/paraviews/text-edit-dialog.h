
#ifndef TEXT_EDIT_DIALOG__H
#define TEXT_EDIT_DIALOG__H


#include <QString>
#include <QMainWindow>

#include <QTextEdit>
//?#include <QWebView>

#include <QWebEngineView>
#include <QLabel>
#include <QPushButton>

#include <QDialog>

#include <QComboBox>

#include "accessors.h"

#include "flags.h"

#include "rzns.h"

//#include "incident-form-dialog.h"

class QPushButton;
class QTextEdit;
class QPlainTextEdit;
class QLineEdit;
class QTabWidget;
class QDialogButtonBox;
class QVBoxLayout;
class QHBoxLayout;
class QCheckBox;
class QFormLayout;
class QSplitter;
class QGridLayout;
class QListWidget;
class QTableWidget;
class QScrollArea;
class QGroupBox;
class QTableWidgetItem;

//RZNS_(QWN)
namespace RZ{ namespace NDP{


class NDP_Antemodel;
class NDP_Project;
class NDP_Project_Initial;


class Text_Edit_Dialog : public QDialog
{
 Q_OBJECT

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QPushButton* button_proceed_;

 QString prior_text_;

 //QFormLayout* substitutions_layout_;

 //QWebEngineView* web_engine_view_;
 QPlainTextEdit* main_text_edit_;

 //QHBoxLayout* url_layout_;
 QVBoxLayout* main_layout_;
 //NDP_Antemodel* antemodel_;
 //QHBoxLayout* show_button_layout_;
 //QPushButton* show_button_;

 //void read_file(QString path, QPlainTextEdit* qpte);

public:

 Text_Edit_Dialog(QWidget* parent, QString prior_text);
 ~Text_Edit_Dialog();

 void activate_search(QString text);


Q_SIGNALS:
 void canceled(QDialog*);
 void accepted(QDialog*);

 void proceed_with_text(QDialog*, QString);

public Q_SLOTS:

 void main_text_changed();
 void accept();
 void cancel();
 //?
 void proceed();

// void show_button_toggled(bool);

};

} } //_RZNS(NDP)


#endif
