
#include "view-derm-dialog.h"

//#include "clg-db-antemodel.h";

#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>

#include <QPlainTextEdit>
#include <QTextStream>
#include <QSlider>

#include <QtSvg>

#include <QTableWidget>

#include <QMessageBox>

#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrlQuery>

#include <QHeaderView>

#include <QListWidget>


USING_RZNS(NDP)


void View_Derm_Dialog::render_to_button(QPushButton* btn, QGraphicsEllipseItem* el)
{
 QGraphicsEllipseItem* el1 = new QGraphicsEllipseItem(el->rect());
 el1->setPen(el->pen());
 el1->setBrush(el->brush());
 QRect rect(0, 0, 40, 40);
 QPixmap* qpm = new QPixmap(rect.size());
 qpm->fill(Qt::transparent);
 QPainter painter(qpm);
 scratch_scene_->render(&painter, QRectF(0, 0, 40, 40), QRectF(0, 0, 40, 40));
 btn->setIcon(QIcon(*qpm));
 btn->setMaximumWidth(40);
 btn->setMaximumHeight(40);
 ellipses_[btn] = el1;
 connect(btn, SIGNAL(pressed()), this, SLOT(graphics_button_clicked()));
}


void View_Derm_Dialog::render_to_button(QPushButton* btn, QPolygonF& poly)
{
 QRect rect(0, 0, 40, 40);
 QPixmap* qpm = new QPixmap(rect.size());
 qpm->fill(Qt::transparent);
 QPainter painter(qpm);
 scratch_scene_->render(&painter, QRectF(0, 0, 40, 40), QRectF(0, 0, 40, 40));
 btn->setIcon(QIcon(*qpm));
 btn->setMaximumWidth(40);
 btn->setMaximumHeight(40);
 polys_[btn] = poly;
 connect(btn, SIGNAL(pressed()), this, SLOT(graphics_button_clicked()));
}

void View_Derm_Dialog::render_to_button(QPushButton* btn,
  QGraphicsSvgItem* item, QGraphicsSvgItem* scratch_item,
  QBoxLayout* layout, qreal x_offset,
  qreal y_offset, qreal reenlage_factor,
  QString text, qreal rotate)
{
 //btn->setText(QString("\n%1").arg(text));
 QLabel* label = new QLabel(text, this);
 label->setMinimumWidth(40);
 label->setAlignment(Qt::AlignCenter);

 label->setStyleSheet("QLabel {margin-bottom:10px;}");


 QRectF rf = item->boundingRect();
 //QRect r = rf.toAlignedRect();

 qreal xsf = 40/rf.width();
 qreal ysf = 55/rf.height();


 QRect r = item->boundingRect().toAlignedRect();


//? item->setScale(0.05);

 int mult = 10;

 QGraphicsScene scratch_scene;

 //?scratch_scene_->setSceneRect(0, 0, 0, 0);

 //QRect rect(0, 0, 55 * mult, 40 * mult);

 QRect rect(scratch_item->boundingRect().toAlignedRect());

//? qDebug() << "RECT: " << rect;

 if(rotate != 0)
 {
  qDebug() << "rotate ...";
  QTransform qtr;
  qtr.translate(rect.height()/2.0,
                rect.width()/2.0);
  qtr.rotate(rotate);

  if(rotate == 90 || rotate == -90)
   rect = rect.transposed();

  qtr.translate(-rect.height()/2.0 ,
                -rect.width()/2.0);
  //?
  scratch_item->setTransform(qtr);

 }


 QRect rect1(scratch_item->boundingRect().toAlignedRect());

//? qDebug() << "RECT1: " << rect1;


 scratch_scene.addItem(scratch_item);

 QRectF srect = scratch_scene.sceneRect();// (scratch_item->boundingRect().toAlignedRect());

//? qDebug() << srect;


//  QRect rect(0, 0, 455, 1024);

//? qDebug() << rect;




// int x_adj = x_offset;
// int y_adj = y_offset;


 QRectF srect_adj;
//   = QRectF(x_adj, y_adj,
//   srect.width() - x_adj, srect.height() - y_adj);

// if(y_offset != 0)
// {
  //x_adj = 10;
  srect_adj = QRectF(x_offset, 0,
    srect.width() - (2 * x_offset), srect.height() - y_offset);
// }


// if(rotate > 0)
// {
//  srect_adj = QRectF(x_offset, 0,
//    srect.width() - (2 * x_offset), srect.height() - 100);
//  //rect = QRect(0, 0, 1024, 749);
// }


 QPixmap* qpm = new QPixmap(rect.size());
 qpm->fill(Qt::transparent);
 QPainter painter(qpm);

 scratch_scene.render(&painter, rect, srect_adj); //QRectF(0, 0, 40, 55)); //srect_adj); //QRectF(0, 0, 56, 5)); //srect); //, rect, rect); //, rect, rect) ; //QRectF(0, 0, 40 * mult, 55 * mult),

   //QRectF(x_offset, y_offset, 40 * mult, 55 * mult));
 btn->setIcon(QIcon(*qpm));
 //btn->setIconSize(qpm->size());

//? qDebug() << "W: " << qpm->width();
//? qDebug() << "H: " << qpm->height();

 btn->setStyleSheet("QPushButton{padding:0px;margin:0px;}");

// btn->setMinimumWidth(40);
// btn->setMinimumHeight(55);
// btn->setMaximumWidth(40);
// btn->setMaximumHeight(55);
 layout->addWidget(btn);

 layout->addWidget(label);
 layout->addStretch();

 //polys_[btn] = poly;
 //connect(btn, SIGNAL(pressed()), this, SLOT(graphics_button_clicked()));

 //?  scratch_scene_->clear();


// QRect view_rect = QRect(-40, 0, 100, 100);
// item->renderer()->setViewBox(view_rect);

//         self.srenderer.setViewBox(svgRect)
//         self.svgSecond.setPos(self.centerx-10, self.centery-1)

 if(xsf < ysf)
 {
  item->setScale(reenlage_factor * xsf);
 }
 else
 {
  item->setScale(reenlage_factor * ysf);
 }


 svg_scene_->addItem(item);
 item->setVisible(false);

 connect(btn, &QPushButton::pressed, [this, item, label]
 {
  if(current_svg_item_)
  {
   for(QGraphicsItem* item : current_svg_specific_items_[current_svg_item_])
   {
    item->setVisible(false);
   }
   current_svg_item_->setVisible(false);
  }
  else
  {
   enable_graphics_buttons();
  }
  if(current_svg_label_)
   current_svg_label_->setStyleSheet("QLabel { background-color : none; margin-bottom:10px;}");
  item->setVisible(true);
  label->setStyleSheet("QLabel { background-color : salmon; margin-bottom:10px;}");
  current_svg_item_ = item;
  for(QGraphicsItem* item : current_svg_specific_items_[current_svg_item_])
  {
   item->setVisible(true);
  }
  current_svg_label_ = label;
 });

}






void View_Derm_Dialog::construct_octagon(QPolygonF& poly, float center_x, float center_y,
  float scale_factor, float x_offset, float y_offset, float width)
{
 poly
   << QPointF(center_x - scale_factor * x_offset, center_y + width)
   << QPointF(center_x - scale_factor * x_offset, center_y - width)

   << QPointF(center_x - width, center_y - scale_factor * y_offset)
   << QPointF(center_x + width, center_y - scale_factor * y_offset)

   << QPointF(center_x + scale_factor * x_offset, center_y - width)
   << QPointF(center_x + scale_factor * x_offset, center_y + width)

   << QPointF(center_x + width, center_y + scale_factor * y_offset)
   << QPointF(center_x - width, center_y + scale_factor * y_offset)
      ;

}


void View_Derm_Dialog::construct_deco_plus(QPolygonF& poly, float center_x, float center_y,
  float scale_factor, float offset, float width, float deco_offset)
{
 poly
   << QPointF(center_x - scale_factor * offset, center_y - scale_factor * width)
   << QPointF(center_x - scale_factor * deco_offset, center_y - scale_factor * width)
   << QPointF(center_x - scale_factor * width, center_y - scale_factor * deco_offset)

   << QPointF(center_x - scale_factor * width, center_y - scale_factor * offset)
   << QPointF(center_x + scale_factor * width, center_y - scale_factor * offset)

   << QPointF(center_x + scale_factor * width, center_y - scale_factor * deco_offset)
   << QPointF(center_x + scale_factor * deco_offset, center_y - scale_factor * width)
   << QPointF(center_x + scale_factor * offset, center_y - scale_factor * width)


   << QPointF(center_x + scale_factor * offset, center_y + scale_factor * width)
   << QPointF(center_x + scale_factor * deco_offset, center_y + scale_factor * width)
   << QPointF(center_x + scale_factor * width, center_y + scale_factor * deco_offset)


   << QPointF(center_x + scale_factor * width, center_y + scale_factor * width)
   << QPointF(center_x + scale_factor * width, center_y + scale_factor * offset)

   << QPointF(center_x - scale_factor * width, center_y + scale_factor * offset)
   << QPointF(center_x - scale_factor * width, center_y + scale_factor * deco_offset)
   << QPointF(center_x - scale_factor * deco_offset, center_y + scale_factor * width)

   << QPointF(center_x - scale_factor * offset, center_y + scale_factor * width)
   << QPointF(center_x - scale_factor * offset, center_y - scale_factor * width)
      ;

}


void View_Derm_Dialog::construct_plus(QPolygonF& poly, float center_x, float center_y,
  float scale_factor, float offset, float width)
{
 poly
   << QPointF(center_x - scale_factor * offset, center_y - scale_factor * width)
   << QPointF(center_x - scale_factor * width, center_y - scale_factor * width)

   << QPointF(center_x - scale_factor * width, center_y - scale_factor * offset)
   << QPointF(center_x + scale_factor * width, center_y - scale_factor * offset)

   << QPointF(center_x + scale_factor * width, center_y - scale_factor * width)
   << QPointF(center_x + scale_factor * offset, center_y - scale_factor * width)

   << QPointF(center_x + scale_factor * offset, center_y + scale_factor * width)
   << QPointF(center_x + scale_factor * width, center_y + scale_factor * width)

   << QPointF(center_x + scale_factor * width, center_y + scale_factor * width)
   << QPointF(center_x + scale_factor * width, center_y + scale_factor * offset)

   << QPointF(center_x - scale_factor * width, center_y + scale_factor * offset)
   << QPointF(center_x - scale_factor * width, center_y + scale_factor * width)

   << QPointF(center_x - scale_factor * offset, center_y + scale_factor * width)
   << QPointF(center_x - scale_factor * offset, center_y - scale_factor * width)
      ;

}


void View_Derm_Dialog::construct_triangle_up(QPolygonF& poly, float center_x, float center_y,
  float scale_factor, float width, float height, float y_offset)
{
 poly
   << QPointF(center_x - scale_factor * width/2, center_y + scale_factor * y_offset)
   << QPointF(center_x + scale_factor * width/2, center_y + scale_factor * y_offset)
   << QPointF(center_x, center_y - scale_factor * height);

}


void View_Derm_Dialog::construct_triangle_down(QPolygonF& poly, float center_x, float center_y,
  float scale_factor, float width, float height, float y_offset)
{
 poly
   << QPointF(center_x - scale_factor * width/2, center_y - scale_factor * height)
   << QPointF(center_x + scale_factor * width/2, center_y - scale_factor * height)
   << QPointF(center_x, center_y + scale_factor * y_offset);

}



View_Derm_Dialog::View_Derm_Dialog(QWidget* parent)
 //, QString url, QWN_XMLDB_Configuration* config)
 : QDialog(parent), current_svg_item_(nullptr),
   current_svg_label_(nullptr), old_zoom_slider_value_(1)
   //?, antemodel_(antemodel)//, config_(config)
{

 button_box_ = new QDialogButtonBox(this);

 button_ok_ = new QPushButton("OK");
 button_proceed_ = new QPushButton("Proceed");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

 button_proceed_->setDefault(false);
 button_proceed_->setAutoDefault(false);

 button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);


 connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));

 main_layout_ = new QVBoxLayout();

 main_notebook_ = new QTabWidget(this);

 QPen qpen(QColor("yellow"));
 qpen.setWidth(2);
 QBrush qbr(QColor("red"));

 svg_view_ = new QGraphicsView(this);
 svg_source_ = new QTextEdit(this);
 instructions_ = new QTextEdit(this);
 languages_ = new QTextEdit(this);
 svg_scene_ = new QGraphicsScene(this);

 svg_view_->setContextMenuPolicy(Qt::CustomContextMenu);
 connect(svg_view_, SIGNAL(customContextMenuRequested(const QPoint&)),
   this, SLOT(show_svg_view_context_menu(const QPoint&)));

 scratch_scene_ = new QGraphicsScene(this);

 star_button_ = new QPushButton(this);
 ellipse_button_ = new QPushButton(this);
 diamond_button_ = new QPushButton(this);

 int center_x = 20;
 int center_y = 20;
 int scale_factor = 1;
 int radius = 15;
 int width = 10;

 QPolygonF poly1;
 poly1
     << QPointF(center_x - scale_factor * radius, center_y)
     << QPointF(center_x, center_y - scale_factor * radius)
     << QPointF(center_x + scale_factor * radius, center_y)
     << QPointF(center_x, center_y + scale_factor * radius)
    ;

   QPolygonF spoly;
   spoly
     << QPointF(center_x - scale_factor * width, center_y - scale_factor * width)
     << QPointF(center_x + scale_factor * width, center_y - scale_factor * width)
     << QPointF(center_x + scale_factor * width, center_y + scale_factor * width)
     << QPointF(center_x - scale_factor * width, center_y + scale_factor * width)

        ;

   QPolygonF poly = poly1.united(spoly);

   //scratch_scene_->addPolygon(poly1, qpen, qbr);
   scratch_scene_->addPolygon(poly, qpen, qbr);

 render_to_button(star_button_, poly);

 scratch_scene_->clear();

 QGraphicsEllipseItem* el = scratch_scene_->addEllipse(2, 2, 35, 35, qpen, qbr);

// QPolygonF epoly;
// epoly
//   << QPointF(center_x - scale_factor * width, center_y - scale_factor * width)
//   << QPointF(center_x + scale_factor * width, center_y - scale_factor * width)
//   << QPointF(center_x + scale_factor * width, center_y + scale_factor * width)
//   << QPointF(center_x - scale_factor * width, center_y + scale_factor * width)
//      ;

 render_to_button(ellipse_button_, el);
 scratch_scene_->clear();


 QPolygonF dpoly;
 radius = 15;
 dpoly
   << QPointF(center_x - scale_factor * radius, center_y)
   << QPointF(center_x, center_y - scale_factor * radius)
   << QPointF(center_x + scale_factor * radius, center_y)
   << QPointF(center_x, center_y + scale_factor * radius);
      ;

 scratch_scene_->addPolygon(dpoly, qpen, qbr);

 render_to_button(diamond_button_, dpoly);
 scratch_scene_->clear();

 {
  QPolygonF ppoly;
  width = 8;
  float offset = 1;
  float scale_factor = 5;
  construct_plus(ppoly, center_x, center_y, scale_factor, offset, width);
  scratch_scene_->addPolygon(ppoly, qpen, qbr);

  plus_button_ = new QPushButton(this);

  render_to_button(plus_button_, ppoly);
  scratch_scene_->clear();
 }


 {
  QPolygonF cppoly;
  width = 15;
  float offset = 10;
  construct_plus(cppoly, center_x, center_y, scale_factor, offset, width);
  scratch_scene_->addPolygon(cppoly, qpen, qbr);

  cross_plus_button_ = new QPushButton(this);

  render_to_button(cross_plus_button_, cppoly);
  scratch_scene_->clear();
 }

 {
  float offset = 4;
  float width = 1;
  float deco_offset = 3;
  float scale_factor = 4;

  QPolygonF dppoly;
  construct_plus(dppoly, center_x, center_y, scale_factor, offset, width);
  scratch_scene_->addPolygon(dppoly, qpen, qbr);

  deco_plus_button_ = new QPushButton(this);

  render_to_button(deco_plus_button_, dppoly);
  scratch_scene_->clear();
 }

 {
  float scale_factor = 5;
  float x_offset = 4;
  float y_offset = 4;
  float width = 8;

  QPolygonF opoly;
  construct_octagon(opoly, center_x, center_y, scale_factor, x_offset, y_offset, width);
  scratch_scene_->addPolygon(opoly, qpen, qbr);

  octagon_button_ = new QPushButton(this);

  render_to_button(octagon_button_, opoly);
  scratch_scene_->clear();
 }


 {
  float offset = 4;
  float width = 1;
  float deco_offset = 3;
  float scale_factor = 4;

  QPolygonF dpoly;
  construct_deco_plus(dpoly, center_x, center_y, scale_factor, offset, width, deco_offset);
  scratch_scene_->addPolygon(dpoly, qpen, qbr);

  deco_button_ = new QPushButton(this);

  render_to_button(deco_button_, dpoly);
  scratch_scene_->clear();
 }

 {
  float scale_factor = 4;
  float x_offset = 8;
  float y_offset = 4;
  float width = 2;

//  float x_offset = 6;
//  float y_offset = 8;

  QPolygonF sopoly;
  construct_octagon(sopoly, center_x, center_y, scale_factor, x_offset, y_offset, width);
  scratch_scene_->addPolygon(sopoly, qpen, qbr);

  skewed_octagon_button_ = new QPushButton(this);

  render_to_button(skewed_octagon_button_, sopoly);
  scratch_scene_->clear();
 }


 {
  float scale_factor = 4;
  float x_offset = 4;
  float y_offset = 8;
  float width = 2;

//  float x_offset = 6;
//  float y_offset = 8;

  QPolygonF vopoly;
  construct_octagon(vopoly, center_x, center_y, scale_factor, x_offset, y_offset, width);
  scratch_scene_->addPolygon(vopoly, qpen, qbr);

  vertical_octagon_button_ = new QPushButton(this);

  render_to_button(vertical_octagon_button_, vopoly);
  scratch_scene_->clear();
 }


 {
  float width = 4;
  float offset = 3;
  float deco_offset = 2;
  float scale_factor = 4;

  QPolygonF stppoly;
  construct_deco_plus(stppoly, center_x, center_y, scale_factor, offset, width, deco_offset);
  scratch_scene_->addPolygon(stppoly, qpen, qbr);

  skewed_tight_plus_button_ = new QPushButton(this);

  render_to_button(skewed_tight_plus_button_, stppoly);
  scratch_scene_->clear();

 }


 {
  float width = 3;
  float offset = 4;
  float deco_offset = 2;
  float scale_factor = 4;

  QPolygonF tppoly;
  construct_deco_plus(tppoly, center_x, center_y, scale_factor, offset, width, deco_offset);
  scratch_scene_->addPolygon(tppoly, qpen, qbr);

  tight_plus_button_ = new QPushButton(this);

  render_to_button(tight_plus_button_, tppoly);
  scratch_scene_->clear();

 }

 {
  float width = 8;
  float height = 4;
  float offset = 3;
  float scale_factor = 4;

  QPolygonF tdpoly;
  construct_triangle_down(tdpoly, center_x, center_y, scale_factor, width, height, offset);
  scratch_scene_->addPolygon(tdpoly, qpen, qbr);

  triangle_down_button_ = new QPushButton(this);

  render_to_button(triangle_down_button_, tdpoly);
  scratch_scene_->clear();
 }

 {
  float width = 8;
  float height = 4;
  float offset = 3;
  float scale_factor = 4;

  QPolygonF tupoly;
  construct_triangle_up(tupoly, center_x, center_y, scale_factor, width, height, offset);
  scratch_scene_->addPolygon(tupoly, qpen, qbr);

  triangle_up_button_ = new QPushButton(this);

  render_to_button(triangle_up_button_, tupoly);
  scratch_scene_->clear();
 }


 //?
 svg_view_->setScene(svg_scene_);
 //svg_view_->setScene(scratch_scene_);

 front_svg_item_ = new QGraphicsSvgItem("/home/nlevisrael/NDP/svg/male-body-medium-slate-blue-silhouette.svg");
 front_scratch_svg_item_ = new QGraphicsSvgItem("/home/nlevisrael/NDP/svg/male-body-medium-slate-blue-silhouette.svg");
// front_scratch_svg_item_->setScale(0.125);

// QTransform qtr1;
// qtr1.translate(0, 380);
// front_scratch_svg_item_->setTransform(qtr1);

 back_svg_item_ = new QGraphicsSvgItem("/home/nlevisrael/NDP/svg/male-body-medium-slate-blue-silhouette.svg");
 back_scratch_svg_item_ = new QGraphicsSvgItem("/home/nlevisrael/NDP/svg/male-body-medium-slate-blue-silhouette.svg");
// back_scratch_svg_item_->setScale(0.125);

 left_foot_svg_item_ = new QGraphicsSvgItem("/home/nlevisrael/NDP/svg/foot-medium-slate-blue-silhouette.svg");
 left_foot_scratch_svg_item_ = new QGraphicsSvgItem("/home/nlevisrael/NDP/svg/foot-medium-slate-blue-silhouette.svg");
// left_foot_scratch_svg_item_->setScale(0.125);

 right_foot_svg_item_ = new QGraphicsSvgItem("/home/nlevisrael/NDP/svg/foot-medium-slate-blue-silhouette.svg");
 right_foot_scratch_svg_item_ = new QGraphicsSvgItem("/home/nlevisrael/NDP/svg/foot-medium-slate-blue-silhouette.svg");
// right_foot_scratch_svg_item_->setScale(0.125);

 horizontal_flip_transform(right_foot_svg_item_, 100);
 horizontal_flip_transform_alt(right_foot_scratch_svg_item_, -600);
//  right_foot_svg_item_->setTransform(QTransform::fromScale(-1, 1));

 left_leg_svg_item_ = new QGraphicsSvgItem("/home/nlevisrael/NDP/svg/leg-medium-slate-blue-silhouette.svg");
 left_leg_scratch_svg_item_ = new QGraphicsSvgItem("/home/nlevisrael/NDP/svg/leg-medium-slate-blue-silhouette.svg");
// left_leg_scratch_svg_item_->setScale(0.125);

// QTransform qtr;
//// qtr.translate(left_leg_scratch_svg_item_->boundingRect().width()/2.0,
////               left_leg_scratch_svg_item_->boundingRect().height()/2.0);
// qtr.rotate(90);
//// qtr.translate(-left_leg_scratch_svg_item_->boundingRect().width()/2.0 ,
////               -left_leg_scratch_svg_item_->boundingRect().height()/2.0);
// left_leg_scratch_svg_item_->setTransform(qtr);


 right_leg_svg_item_ = new QGraphicsSvgItem("/home/nlevisrael/NDP/svg/leg-medium-slate-blue-silhouette.svg");
 right_leg_scratch_svg_item_ = new QGraphicsSvgItem("/home/nlevisrael/NDP/svg/leg-medium-slate-blue-silhouette.svg");
// right_leg_scratch_svg_item_->setScale(0.125);

 horizontal_flip_transform(left_leg_svg_item_, -40);
//? horizontal_flip_transform_alt(right_leg_scratch_svg_item_, 0);
//  vertical_flip_transform_alt(left_leg_scratch_svg_item_, 300);
//  right_leg_svg_item_->setTransform(QTransform::fromScale(-1, 1));

 left_face_svg_item_ = new QGraphicsSvgItem("/home/nlevisrael/NDP/svg/side-of-face-medium-slate-blue-silhouette.svg");
 left_face_scratch_svg_item_ = new QGraphicsSvgItem("/home/nlevisrael/NDP/svg/side-of-face-medium-slate-blue-silhouette.svg");
// left_face_scratch_svg_item_->setScale(0.125);

 right_face_svg_item_ = new QGraphicsSvgItem("/home/nlevisrael/NDP/svg/side-of-face-medium-slate-blue-silhouette.svg");
 right_face_scratch_svg_item_ = new QGraphicsSvgItem("/home/nlevisrael/NDP/svg/side-of-face-medium-slate-blue-silhouette.svg");
// right_face_scratch_svg_item_->setScale(0.125);

 horizontal_flip_transform(right_face_svg_item_);
 horizontal_flip_transform_alt(right_face_scratch_svg_item_, -300);

// int w = right_face_svg_item_->boundingRect().width()/2;
// qDebug() << w;

// QTransform qtr = QTransform::fromScale(-1, 1);

// qDebug() << qtr;

// right_face_svg_item_->setTransformOriginPoint(-w/2, 0);
// right_face_svg_item_->setTransform(QTransform::fromScale(-1, 1));

 hands_svg_item_ = new QGraphicsSvgItem("/home/nlevisrael/NDP/svg/hands-medium-slate-blue-silhouette.svg");
 hands_scratch_svg_item_ = new QGraphicsSvgItem("/home/nlevisrael/NDP/svg/hands-medium-slate-blue-silhouette.svg");
// hands_scratch_svg_item_->setScale(0.125);

 //front_svg_item_->setScale(0.5);

 //back_svg_item_->setScale(0.5);



 front_svg_item_button_ = new QPushButton(this);

 back_svg_item_button_ = new QPushButton(this);
 left_foot_svg_item_button_ = new QPushButton(this);
 right_foot_svg_item_button_ = new QPushButton(this);
 left_leg_svg_item_button_ = new QPushButton(this);
 right_leg_svg_item_button_ = new QPushButton(this);
 left_face_svg_item_button_ = new QPushButton(this);
 right_face_svg_item_button_ = new QPushButton(this);
 hands_svg_item_button_ = new QPushButton(this);

 silhouettes_buttons_layout_ = new QVBoxLayout;

 silhouettes_buttons_layout_->setMargin(0);
 silhouettes_buttons_layout_->setSpacing(0);

 qreal x_offset = 0;
 qreal y_offset = 0;
 qreal reenlarge_factor = 4;
 render_to_button(front_svg_item_button_, front_svg_item_, front_scratch_svg_item_,
   silhouettes_buttons_layout_, 80, 360, 6, "Front");

 render_to_button(back_svg_item_button_, back_svg_item_, back_scratch_svg_item_,
   silhouettes_buttons_layout_, 80, 360, 6, "Back");

 render_to_button(left_foot_svg_item_button_, left_foot_svg_item_, left_foot_scratch_svg_item_,
   silhouettes_buttons_layout_, x_offset, y_offset,  reenlarge_factor, "Left Foot"); //reenlarge_factor);

 render_to_button(right_foot_svg_item_button_, right_foot_svg_item_, right_foot_scratch_svg_item_,
   silhouettes_buttons_layout_, x_offset, y_offset, reenlarge_factor, "Right Foot");

 render_to_button(left_leg_svg_item_button_, left_leg_svg_item_, left_leg_scratch_svg_item_,
   silhouettes_buttons_layout_, x_offset, 100, 5, "Left Leg", -90);

 render_to_button(right_leg_svg_item_button_, right_leg_svg_item_, right_leg_scratch_svg_item_,
   silhouettes_buttons_layout_, x_offset, y_offset, 5, "Right Leg");

 render_to_button(left_face_svg_item_button_, left_face_svg_item_, left_face_scratch_svg_item_,
   silhouettes_buttons_layout_, x_offset, y_offset, reenlarge_factor, "Left Face");

 render_to_button(right_face_svg_item_button_, right_face_svg_item_, right_face_scratch_svg_item_,
   silhouettes_buttons_layout_, x_offset, y_offset, reenlarge_factor, "Right Face");

 render_to_button(hands_svg_item_button_, hands_svg_item_, hands_scratch_svg_item_,
   silhouettes_buttons_layout_, x_offset, y_offset, 5, "Hands");

 // scratch_scene_->addItem(front_svg_item_);
 // scratch_scene_->clear();
// scratch_scene_->addItem(back_svg_item_);
// scratch_scene_->clear();
// scratch_scene_->addItem(left_foot_svg_item_);
// scratch_scene_->clear();
// scratch_scene_->addItem(right_foot_svg_item_);
// scratch_scene_->clear();
// scratch_scene_->addItem(left_leg_svg_item_);
// scratch_scene_->clear();
// scratch_scene_->addItem(right_leg_svg_item_);
// scratch_scene_->clear();
// scratch_scene_->addItem(left_face_svg_item_);
// scratch_scene_->clear();
// scratch_scene_->addItem(right_face_svg_item_);
// scratch_scene_->clear();
// scratch_scene_->addItem(hands_svg_item_);
// scratch_scene_->clear();
// int tl_x = 0;
// int tl_y = 0;
// front_svg_item_->setPos(tl_x, tl_y);
// tl_x += 100;
// back_svg_item_->setPos(tl_x, tl_y);
// tl_x += 100;
// left_foot_svg_item_->setPos(tl_x, tl_y);
// tl_x += 100;
// left_foot_svg_item_->setPos(tl_x, tl_y);
// tl_x += 100;
// left_face_svg_item_->setPos(tl_x, tl_y);
// tl_x += 100;
// left_face_svg_item_->setPos(tl_x, tl_y);
// tl_x += 100;
// left_leg_svg_item_->setPos(tl_x, tl_y);
// tl_x += 100;
// left_leg_svg_item_->setPos(tl_x, tl_y);
// tl_x += 100;
 //hands_svg_item_->setPos(tl_x, tl_y);
// tl_x += 100;

 // svg_item_->setScale(1.5);

// QGraphicsItem* item = svg_scene_->addEllipse(10, 10, 10, 10, qpen, qbr);
// item->setFlag(QGraphicsItem::ItemIsSelectable);
// item->setFlag(QGraphicsItem::ItemIsMovable);


 //svg_view_->fitInView(svg_item_, Qt::KeepAspectRatio);

 graphics_layout_ = new QHBoxLayout;
 graphics_buttons_layout_ = new QVBoxLayout;

 graphics_layout_->addLayout(silhouettes_buttons_layout_);
 graphics_layout_->addWidget(svg_view_);
 graphics_layout_->addLayout(graphics_buttons_layout_);


 graphics_buttons_layout_->addWidget(vertical_octagon_button_);
 moles_label_ = new QLabel("Moles", this);
 add_graphics_button_text_and_line(moles_label_);
 vertical_octagon_button_->setEnabled(false);


 graphics_buttons_layout_->addWidget(ellipse_button_);
 lesions_label_ = new QLabel("Lesions", this);
 add_graphics_button_text_and_line(lesions_label_);
 ellipse_button_->setEnabled(false);

// graphics_buttons_layout_->addWidget(diamond_button_);

 graphics_buttons_layout_->addWidget(diamond_button_);
 eczema_label_ = new QLabel("Eczema", this);
 add_graphics_button_text_and_line(eczema_label_);
 diamond_button_->setEnabled(false);


 graphics_buttons_layout_->addWidget(cross_plus_button_);
 fungus_label_ = new QLabel("Fungus", this);
 add_graphics_button_text_and_line(fungus_label_);
 cross_plus_button_->setEnabled(false);

 graphics_buttons_layout_->addWidget(octagon_button_);
 dematitus_label_ = new QLabel("Dermatitus", this);
 add_graphics_button_text_and_line(dematitus_label_);
 octagon_button_->setEnabled(false);


 graphics_buttons_layout_->addWidget(skewed_octagon_button_);
 warts_label_ = new QLabel("Warts", this);
 add_graphics_button_text_and_line(warts_label_);
 skewed_octagon_button_->setEnabled(false);



 //ellipse_button_->setVisible(false);
 //cross_plus_button_->setVisible(false);
 //diamond_button_->setVisible(false);
 triangle_up_button_->setVisible(false);
 triangle_down_button_->setVisible(false);
 plus_button_->setVisible(false);
 star_button_->setVisible(false);
 skewed_tight_plus_button_->setVisible(false);
 //octagon_button_->setVisible(false);


 //?deco_plus_button_->setVisible(false);
 //skewed_octagon_button_->setVisible(false);
 //vertical_octagon_button_->setVisible(false);
//?
 deco_button_->setVisible(false);
 //octagon_button_->setVisible(false);

// skewed_tight_plus_button_->setVisible(false);
 tight_plus_button_->setVisible(false);
 plus_button_->setVisible(false);
 //cross_plus_button_->setVisible(false);
 deco_plus_button_->setVisible(false);


// graphics_buttons_layout_->addWidget(triangle_up_button_);
// graphics_buttons_layout_->addWidget(cross_plus_button_);
// graphics_buttons_layout_->addWidget(deco_plus_button_);
// graphics_buttons_layout_->addWidget(skewed_octagon_button_);
// graphics_buttons_layout_->addWidget(vertical_octagon_button_);
// graphics_buttons_layout_->addWidget(deco_button_);
// graphics_buttons_layout_->addWidget(octagon_button_);

// graphics_buttons_layout_->addWidget(skewed_tight_plus_button_);
// graphics_buttons_layout_->addWidget(tight_plus_button_);


// line01->setStyleSheet("QFrame{background:rgba(255,200,200,0.7);}");
// line02->setStyleSheet("QFrame{background:rgba(255,200,200,0.7);}");

// QFont f = more_shapes_label_->font();
// f.setPointSize(7);
// more_shapes_label_->setFont(f);
// edit_colors_label_->setFont(f);

// more_shapes_label_->setStyleSheet("QLabel{color:blue}");
// edit_colors_label_->setStyleSheet("QLabel{color:blue}");

// QSpacerItem* sp1 = new QSpacerItem(1, 8);
// QSpacerItem* sp2 = new QSpacerItem(1, 8);

// graphics_buttons_layout_->addItem(sp1);

// graphics_buttons_layout_->addWidget(line01);
// graphics_buttons_layout_->addWidget(more_shapes_label_);

// graphics_buttons_layout_->addItem(sp2);

// graphics_buttons_layout_->addWidget(line02);
// graphics_buttons_layout_->addWidget(edit_colors_label_);

// graphics_buttons_layout_->addStretch();

 graphics_buttons_layout_->setSpacing(0);
 graphics_buttons_layout_->setMargin(0);

 graphics_frame_ = new QFrame(this);
 graphics_frame_->setLayout(graphics_layout_);


 main_notebook_->addTab(graphics_frame_, "View");
 main_notebook_->addTab(instructions_, "Instructions");
 main_notebook_->addTab(languages_, "Languages");
 main_notebook_->addTab(svg_source_, "SVG Code");

 main_layout_->addWidget(main_notebook_);
 //?main_layout_->addLayout(url_layout_);

 QString colorful_button_style_sheet =
  "QPushButton:hover {background:rgb(240,190,150);"
  " border-left: 4px groove rgb(240,190,150); "
  " border-right: 4px ridge rgb(240,190,150); "
  "}\n"
  "QPushButton{ padding:1px;  border: 2px solid rgb(240,190,150); "
  "  border-bottom: 1px solid #CEF51D; "
  " border-radius: 6px; "
  " background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, "
  "  stop: 0 white, stop: 0.1 #C0C0C0, stop: 0.6 #CC"
  "C6BC, stop: 0.8 #ECCFA0, stop: 0.9 darkred,  stop: 1 brown"
  "); min-width: 80px; }";



 QString colorful_button_style_sheet_down =
  "QPushButton {background:rgb(190,190,230);padding-left:20;padding-right:20;padding-top:0;padding-bottom:0;"
  " border-left: 4px groove rgb(240,190,150); "
  " border-right: 4px ridge rgb(240,190,150); "
  "}\n";


 clear_button_ = new QPushButton("Clear", this);

 clear_button_->setStyleSheet(colorful_button_style_sheet);


 clear_button_layout_ = new QHBoxLayout;


 QString s1 = QString("%1").arg(QChar(5184));
 zoom_in_button_ = new QPushButton(s1, this);
 zoom_in_button_->setStyleSheet("QPushButton{font-size: 12pt;"
                                "font-weight: bold;"
                                "color: brown;}");
// zoom_in_button_->setFont(zif);
 zoom_in_button_->setMaximumWidth(25);
 zoom_in_button_->setMaximumHeight(15);


 QString s2 = QString("%1").arg(QChar(5189));
 zoom_out_button_ = new QPushButton(s2, this);
 zoom_out_button_->setStyleSheet("QPushButton{font-size: 12pt;"
                                "font-weight: bold; padding:0px; "
                                "color: brown;}");
 zoom_out_button_->setMaximumWidth(25);
 zoom_out_button_->setMaximumHeight(15);

 connect(zoom_in_button_, SIGNAL(pressed()), this, SLOT(zoom_in()));
 connect(zoom_out_button_, SIGNAL(pressed()), this, SLOT(zoom_out()));

 gender_layout_ = new QHBoxLayout;
 gender_label_ = new QLabel("Silhouette Gender:");
 gender_neutral_button_ = new QPushButton("Neutral", this);
 gender_male_button_ = new QPushButton("Male", this);
 gender_female_button_ = new QPushButton("Female", this);

 gender_neutral_button_->setCheckable(true);
 gender_male_button_->setCheckable(true);
 gender_female_button_->setCheckable(true);

 gender_layout_->addWidget(gender_label_);
 gender_layout_->addWidget(gender_neutral_button_);
 gender_layout_->addWidget(gender_male_button_);
 gender_layout_->addWidget(gender_female_button_);


 main_layout_->addLayout(gender_layout_);

//? clear_button_layout_->setEnabled(false);



// QLineEdit* vbl = new QLineEdit("1  1  1  1  " , this);
// QPushButton* vb = new QPushButton("Adjust", this);

// connect(vb, &QPushButton::pressed, [this, vbl]
// {
//  QStringList qsl = vbl->text().split(" ");
//  int x = qsl[0].toInt();
//  int y = qsl[1].toInt();
//  int w = qsl[2].toInt();
//  int h = qsl[3].toInt();
//  QRect view_rect = QRect(x, y, w, h);

//  QRect viewbox = current_svg_item_->renderer()->viewBox();
//  qDebug() << viewbox;

//  current_svg_item_->renderer()->setViewBox(view_rect);
//  current_svg_item_->update();
// });

// clear_button_layout_->addWidget(vbl);
// clear_button_layout_->addWidget(vb);

 zoom_slider_ = new QSlider(Qt::Horizontal, this);

 connect(zoom_slider_, SIGNAL(valueChanged(int)), this,
   SLOT(zoom_slider_value_changed(int)));

 QLabel* zoom_label = new QLabel("Silhouette Zoom:", this);

 QHBoxLayout* zoom_layout = new QHBoxLayout;

 zoom_layout->addStretch();
 clear_button_layout_->addWidget(zoom_label);

 zoom_layout->addWidget(zoom_slider_);
 zoom_layout->addItem(new QSpacerItem(15, 1));

 zoom_layout->addWidget(zoom_out_button_);
 zoom_layout->addItem(new QSpacerItem(5, 1));

 zoom_layout->addWidget(zoom_in_button_);

 zoom_layout->addItem(new QSpacerItem(16, 1));

 zoom_layout->addWidget(clear_button_);
 zoom_layout->addStretch();

 clear_button_layout_->addLayout(zoom_layout);

 main_layout_->addLayout(clear_button_layout_);


 svg_view_->setMinimumWidth(300);

 main_layout_->addWidget(button_box_);

 setLayout(main_layout_);

 original_width_ = this->width();
 original_height_ = this->height();

 //connect(this, SIGNAL(resizeEvent(QResizeEvent*)));

 show();
}


void View_Derm_Dialog::show_svg_view_context_menu(const QPoint& p)
{
 //qDebug() << p;

 QGraphicsItem* item = svg_view_->itemAt(p);

 QPoint scp = this->mapToGlobal(p);

 scp -= QPoint(0, 30);

 QMenu menu;

 if(item)
 {
  QAction* remove_action = menu.addAction("Remove");
  QAction* smaller_action = menu.addAction("Make Smaller");
  QAction* larger_action = menu.addAction("Make Larger");
  connect(remove_action, &QAction::triggered,
    [item, this]
  {
   svg_scene_->removeItem(item);
//   svg_scene_->update();
  });

  connect(smaller_action, &QAction::triggered,
    [item, this]
  {
   item->setScale(item->scale() - 0.125);
//   svg_scene_->update();
  });

  connect(larger_action, &QAction::triggered,
    [item, this]
  {
   item->setScale(item->scale() + 0.125);
//   svg_scene_->update();
  });

  menu.exec(scp);
 }



}


void View_Derm_Dialog::enable_graphics_buttons()
{
 ellipse_button_->setEnabled(true);
 vertical_octagon_button_->setEnabled(true);
 diamond_button_->setEnabled(true);
 cross_plus_button_->setEnabled(true);
 octagon_button_->setEnabled(true);
 skewed_octagon_button_->setEnabled(true);

// deco_plus_button_->setEnabled(true);
// star_button_->setEnabled(true);
// skewed_tight_plus_button_->setEnabled(true);
// triangle_down_button_->setEnabled(true);
}


void View_Derm_Dialog::add_graphics_button_text_and_line(QLabel* label)
{
 graphics_buttons_layout_->addWidget(label);
 QFrame* line = new QFrame(this);
 line->setGeometry(QRect(320, 150, 118, 3));
 line->setFrameShape(QFrame::HLine);
 line->setFrameShadow(QFrame::Raised);
 graphics_buttons_layout_->addWidget(line);
 line->setStyleSheet("QFrame{background:rgba(255,200,200,0.7);}");

 QFont f = label->font();
 f.setPointSize(10);
 label->setFont(f);
 label->setStyleSheet("QLabel{color:darkslateblue;font-weight:900}");

 graphics_buttons_layout_->addStretch();
}



void View_Derm_Dialog::clear_button_clicked()
{
 //?main_text_->clear();
}

void View_Derm_Dialog::horizontal_flip_transform(QGraphicsSvgItem* item, int x_offset)
{
 int w = item->boundingRect().width()/2;

// if(x_offset == 0)
//  x_offset = w;
// qDebug() << w;

 QTransform qtr = QTransform::fromScale(-1, 1);
// qDebug() << qtr;

 int xow = x_offset - w/2;

 item->setTransformOriginPoint(xow, 0);
 item->setTransform(qtr);
}

void View_Derm_Dialog::vertical_flip_transform_alt(QGraphicsSvgItem* item, int y_offset)
{
 int h = item->boundingRect().height()/2;
 QTransform qtr = QTransform().translate(0, h).fromScale(1, -1).translate(0, y_offset - h);
 item->setTransform(qtr);
}


void View_Derm_Dialog::horizontal_flip_transform_alt(QGraphicsSvgItem* item, int x_offset)
{
 int w = item->boundingRect().width()/2;

// if(x_offset == 0)
//  x_offset = w;
//// qDebug() << w;


 QTransform qtr = QTransform().translate(w, 0).fromScale(-1, 1).translate(x_offset - w, 0);
// qDebug() << qtr;

// int xow = x_offset - w/2;

// item->setTransformOriginPoint(-xow, 0);
 item->setTransform(qtr);
}

void View_Derm_Dialog::zoom_slider_value_changed(int val)
{
 int diff = val - old_zoom_slider_value_;
 old_zoom_slider_value_ = val;
 int max = zoom_slider_->maximum();
 //int current = val;

 qreal ratio = 1 + ((qreal)diff)/((qreal)max);

 //qreal test = 99/55;

 front_svg_item_->setScale(front_svg_item_->scale() * ratio);

 back_svg_item_->setScale(back_svg_item_->scale() * ratio);

 left_foot_svg_item_->setScale(left_foot_svg_item_->scale() * ratio);
 right_foot_svg_item_->setScale(right_foot_svg_item_->scale() * ratio);

 left_leg_svg_item_->setScale(left_leg_svg_item_->scale() * ratio);
 right_leg_svg_item_->setScale(right_leg_svg_item_->scale() * ratio);

 left_face_svg_item_->setScale(left_face_svg_item_->scale() * ratio);
 right_face_svg_item_->setScale(right_face_svg_item_->scale() * ratio);

 hands_svg_item_->setScale(hands_svg_item_->scale() * ratio);

// back_svg_item_->setScale(ratio);

// left_foot_svg_item_->setScale(ratio);
// right_foot_svg_item_->setScale(ratio);

// left_leg_svg_item_->setScale(ratio);
// right_leg_svg_item_->setScale(ratio);

// left_face_svg_item_->setScale(ratio);
// right_face_svg_item_->setScale(ratio);

// hands_svg_item_->setScale(ratio);

}

void View_Derm_Dialog::zoom_in()
{
 front_svg_item_->setScale(front_svg_item_->scale() + 0.125);
 back_svg_item_->setScale(back_svg_item_->scale() + 0.125);

 left_foot_svg_item_->setScale(left_foot_svg_item_->scale() + 0.125);
 right_foot_svg_item_->setScale(right_foot_svg_item_->scale() + 0.125);

 left_leg_svg_item_->setScale(left_leg_svg_item_->scale() + 0.125);
 right_leg_svg_item_->setScale(right_leg_svg_item_->scale() + 0.125);

 left_face_svg_item_->setScale(left_face_svg_item_->scale() + 0.125);
 right_face_svg_item_->setScale(right_face_svg_item_->scale() + 0.125);

 hands_svg_item_->setScale(hands_svg_item_->scale() + 0.125);
}

void View_Derm_Dialog::zoom_out()
{
 front_svg_item_->setScale(front_svg_item_->scale() - 0.125);
 back_svg_item_->setScale(back_svg_item_->scale() - 0.125);

 left_foot_svg_item_->setScale(left_foot_svg_item_->scale() - 0.125);
 right_foot_svg_item_->setScale(right_foot_svg_item_->scale() - 0.125);

 left_leg_svg_item_->setScale(left_leg_svg_item_->scale() - 0.125);
 right_leg_svg_item_->setScale(right_leg_svg_item_->scale() - 0.125);

 left_face_svg_item_->setScale(left_face_svg_item_->scale() - 0.125);
 right_face_svg_item_->setScale(right_face_svg_item_->scale() - 0.125);

 hands_svg_item_->setScale(hands_svg_item_->scale() - 0.125);
}

void View_Derm_Dialog::graphics_button_clicked()
{
 if(!current_svg_item_)
 {
  // // the buttons which emit the clicked signal
   //   should only by enabled when current_svg_item_
   //   is defined.
  return;
 }

 QPen qpen(QColor("red"));
 QBrush qbr(QColor("brown"));

 QPushButton* btn = qobject_cast<QPushButton*>(sender());

 if(ellipses_.contains(btn))
 {
  QGraphicsEllipseItem* item = ellipses_[btn];
  QGraphicsEllipseItem* new_item = svg_scene_->addEllipse(item->rect(),
    item->pen(), item->brush());
    //item->rect(), item->pen(), item->brush());
  new_item->setFlag(QGraphicsItem::ItemIsSelectable);
  new_item->setFlag(QGraphicsItem::ItemIsMovable);
  new_item->setFlag(QGraphicsItem::ItemIsFocusable);

  current_svg_specific_items_[current_svg_item_].push_back(new_item);
 }
 else
 {
  QPolygonF poly = polys_[btn];
  QGraphicsItem* item = svg_scene_->addPolygon(poly, qpen, qbr);
  item->setFlag(QGraphicsItem::ItemIsSelectable);
  item->setFlag(QGraphicsItem::ItemIsMovable);
  item->setFlag(QGraphicsItem::ItemIsFocusable);

  current_svg_specific_items_[current_svg_item_].push_back(item);
 }
}



View_Derm_Dialog::~View_Derm_Dialog()
{
 delete button_ok_;
 delete button_proceed_;
 delete button_cancel_;

// delete url_label_;
// delete name_qle_;
}



void View_Derm_Dialog::cancel()
{
 Q_EMIT(canceled(this));
// close();
}

void View_Derm_Dialog::accept()
{
 Q_EMIT(accepted(this));
// close();
}
