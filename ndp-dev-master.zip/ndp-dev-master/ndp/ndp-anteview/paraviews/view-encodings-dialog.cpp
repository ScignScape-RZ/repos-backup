
#include "view-encodings-dialog.h"

//#include "clg-db-antemodel.h";

#include <QApplication>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>

#include <QPlainTextEdit>
#include <QTextStream>

#include <QTableWidget>

#include <QMessageBox>

#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrlQuery>

#include <QHeaderView>

#include <QListWidget>

#include "silotypes/ndp-project/ndp-project.h"
#include "silotypes/ndp-project/ndp-project-initial.h"

USING_RZNS(NDP)

View_Encodings_Dialog::View_Encodings_Dialog(QWidget* parent) //, NDP_Antemodel* antemodel)//, QString url, QWN_XMLDB_Configuration* config)
 : QDialog(parent) //, antemodel_(antemodel)//, config_(config)
{

 button_box_ = new QDialogButtonBox(this);

 button_ok_ = new QPushButton("OK");
 button_proceed_ = new QPushButton("Proceed");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

 button_proceed_->setDefault(false);
 button_proceed_->setAutoDefault(false);

 button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);


 connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));

 main_layout_ = new QVBoxLayout();

 main_text_edit_ = new QPlainTextEdit(this);

 url_label_  = new QLabel("URL", this);
 url_line_edit_ = new QLineEdit(this);

 url_layout_ = new QHBoxLayout;
 url_layout_->addWidget(url_label_);
 url_layout_->addWidget(url_line_edit_);

 main_layout_->addWidget(main_text_edit_);
 main_layout_->addLayout(url_layout_);

 QString colorful_button_style_sheet =
  "QPushButton:hover {background:rgb(240,190,150);"
  " border-left: 4px groove rgb(240,190,150); "
  " border-right: 4px ridge rgb(240,190,150); "
  "}\n"
  "QPushButton{ padding:1px;  border: 2px solid rgb(240,190,150); "
  "  border-bottom: 1px solid #CEF51D; "
  " border-radius: 6px; "
  " background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, "
  "  stop: 0 white, stop: 0.1 #C0C0C0, stop: 0.6 #CC"
  "C6BC, stop: 0.8 #ECCFA0, stop: 0.9 darkred,  stop: 1 brown"
  "); min-width: 80px; }";



 QString colorful_button_style_sheet_down =
  "QPushButton {background:rgb(190,190,230);padding-left:20;padding-right:20;padding-top:0;padding-bottom:0;"
  " border-left: 4px groove rgb(240,190,150); "
  " border-right: 4px ridge rgb(240,190,150); "
  "}\n";


 load_button_ = new QPushButton("Load", this);
// close_button_ = new QPushButton("Close", this);

 load_button_->setStyleSheet(colorful_button_style_sheet);
// close_button_->setStyleSheet(colorful_button_style_sheet);

 load_button_layout_ = new QHBoxLayout;
 load_button_layout_->addStretch();
 load_button_layout_->addWidget(load_button_);
 load_button_layout_->addStretch();

 main_layout_->addLayout(load_button_layout_);

// close_button_layout_ = new QHBoxLayout;
// close_button_layout_->addStretch();
// close_button_layout_->addWidget(close_button_);
// close_button_layout_->addStretch();

// main_layout_->addLayout(close_button_layout_);

 connect(load_button_, SIGNAL(clicked()), this,
         SLOT(load_button_clicked()));




 main_layout_->addWidget(button_box_);

 setLayout(main_layout_);

 show();
}


//void View_Web_Page_Dialog::load_url(QString url)
//{
// web_engine_view_->load(QUrl(url));
//}

//void View_Web_Page_Dialog::load_local_file(QString path)
//{
// QString url = QString("file://%1").arg(path);
// url_line_edit_->setText(url);
// load_url(url);
//}


void View_Encodings_Dialog::load_button_clicked()
{
 QString path = QFileDialog::getOpenFileName(this, "Reload Form from ... (Select File)", DEMO_DIR);
 QFile file (path + ".enc.txt");
 QString encode;
 if(file.open(QIODevice::ReadOnly))
 {
  QTextStream qts(&file);
  qts >> encode;
  file.close();
 }
 QFile file1 (path + ".qenc.txt");
 QString qencode;
 if(file1.open(QIODevice::ReadOnly))
 {
  QTextStream qts(&file1);
  qts >> qencode;
  file1.close();
 }
 QString summary = encode + "\n\n\n" + qencode;
 url_line_edit_->setText(path);

 main_text_edit_->setPlainText(summary);


// QString url = url_line_edit_->text();
// web_engine_view_->load(QUrl(url));
}

//View_Web_Page_Dialog::View_Web_Page_Dialog()
// // : parent_(nullptr), antemodel_(nullptr)
//{

//}
//View_Web_Page_Dialog::View_Web_Page_Dialog(const View_Web_Page_Dialog& rhs)
// // : setP(rhs.parent_), antemodel_(rhs.antemodel_)
//{

//}

View_Encodings_Dialog::~View_Encodings_Dialog()
{
 delete button_ok_;
 delete button_proceed_;
 delete button_cancel_;

// delete url_label_;
// delete name_qle_;
}



void View_Encodings_Dialog::cancel()
{
 Q_EMIT(canceled(this));
// close();
}

void View_Encodings_Dialog::accept()
{
 Q_EMIT(accepted(this));
// close();
}
