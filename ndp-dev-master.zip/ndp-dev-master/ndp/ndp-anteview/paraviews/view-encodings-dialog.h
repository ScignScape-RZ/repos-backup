
#ifndef VIEW_ENCODINGS_DIALOG__H
#define VIEW_ENCODINGS_DIALOG__H


#include <QString>
#include <QMainWindow>

#include <QTextEdit>
//?#include <QWebView>

#include <QWebEngineView>
#include <QLabel>
#include <QPushButton>

#include <QDialog>

#include <QComboBox>

#include "accessors.h"

#include "flags.h"

#include "rzns.h"

//#include "incident-form-dialog.h"

class QPushButton;
class QTextEdit;
class QPlainTextEdit;
class QLineEdit;
class QTabWidget;
class QDialogButtonBox;
class QVBoxLayout;
class QHBoxLayout;
class QCheckBox;
class QFormLayout;
class QSplitter;
class QGridLayout;
class QListWidget;
class QTableWidget;
class QScrollArea;
class QGroupBox;
class QTableWidgetItem;

//RZNS_(QWN)
namespace RZ{ namespace NDP{


class NDP_Antemodel;
class NDP_Project;
class NDP_Project_Initial;


class View_Encodings_Dialog : public QDialog
{
 Q_OBJECT

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QPushButton* button_proceed_;

 QLabel* url_label_;
 QLineEdit* url_line_edit_;

 QPlainTextEdit* main_text_edit_;

 QHBoxLayout* url_layout_;
 QVBoxLayout* main_layout_;
 NDP_Antemodel* antemodel_;

 QHBoxLayout* load_button_layout_;
 QPushButton* load_button_;

// QHBoxLayout* close_button_layout_;
// QPushButton* close_button_;

 void read_file(QString path, QPlainTextEdit* qpte);

public:

 View_Encodings_Dialog(QWidget* parent); //, NDP_Antemodel* antemodel);

// View_Web_Page_Dialog();
// View_Web_Page_Dialog(const View_Web_Page_Dialog& rhs);

 ~View_Encodings_Dialog();

 void activate_search(QString text);
 void load_url(QString url);
 void load_local_file(QString path);


Q_SIGNALS:
 void canceled(QDialog*);
 void accepted(QDialog*);

public Q_SLOTS:
 void accept();
 void cancel();
 //?void proceed();

 void load_button_clicked();

};

} } //_RZNS(NDP)



#endif
