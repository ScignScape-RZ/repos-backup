
#include "view-gecode-demo-dialog.h"


//#include "tesseract/api/baseapi.h"
//#include <leptonica/allheaders.h>


//#include "clg-db-antemodel.h";

#include <QApplication>

#include <QProcess>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>

#include <QPlainTextEdit>
#include <QTextStream>

#include <QTableWidget>

#include <QMessageBox>

#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrlQuery>

#include <QHeaderView>

#include <QListWidget>

#include "silotypes/ndp-project/ndp-project.h"
#include "silotypes/ndp-project/ndp-project-initial.h"



#include <gecode/int.hh>
#include <gecode/minimodel.hh>
#include <gecode/search.hh>

#include "nl-dock-matrix.h"

#include "nl-gecode-solver.h"
#include "nl-gecode-lexicon.h"


using namespace Gecode;


USING_RZNS(NDP)

USING_RZNS(NLG)



View_Gecode_Demo_Dialog::View_Gecode_Demo_Dialog(QWidget* parent) //NDP_Antemodel* antemodel)//, QString url, QWN_XMLDB_Configuration* config)
 : QDialog(parent) //?, antemodel_(antemodel)//, config_(config)
{

 button_box_ = new QDialogButtonBox(this);

 button_ok_ = new QPushButton("OK");
 button_apply_ = new QPushButton("Apply");
 //button_proceed_ = new QPushButton("Proceed");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

// button_proceed_->setDefault(false);
// button_proceed_->setAutoDefault(false);

 button_apply_->setDefault(false);
 button_apply_->setAutoDefault(false);

 button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_apply_, QDialogButtonBox::ApplyRole);
// button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);


// connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
 connect(button_apply_, SIGNAL(clicked()), this, SLOT(apply()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));

 main_layout_ = new QVBoxLayout;

 grammar_file_layout_ = new QHBoxLayout;
 grammar_file_label_ = new QLabel("Grammar File:", this);
 grammar_file_line_edit_ = new QLineEdit(this);
 grammar_file_open_button_ = new QPushButton("Open", this);
 connect(grammar_file_open_button_, SIGNAL(clicked()), this,
   SLOT(grammar_file_open_button_clicked()));
 grammar_file_layout_->addWidget(grammar_file_label_);
 grammar_file_layout_->addWidget(grammar_file_line_edit_);
 grammar_file_layout_->addWidget(grammar_file_open_button_);
 main_layout_->addLayout(grammar_file_layout_);


 QHBoxLayout* nl_file_layout_ = new QHBoxLayout;
 nl_file_label_ = new QLabel("Sample File:", this);
 nl_file_line_edit_ = new QLineEdit(this);
 nl_file_open_button_ = new QPushButton("Open", this);
 connect(nl_file_open_button_, SIGNAL(clicked()), this,
   SLOT(nl_file_open_button_clicked()));
 nl_file_layout_->addWidget(nl_file_label_);
 nl_file_layout_->addWidget(nl_file_line_edit_);
 nl_file_layout_->addWidget(nl_file_open_button_);
 main_layout_->addLayout(nl_file_layout_);

 sentence_line_edit_ = new QLineEdit(this);
 main_layout_->addWidget(sentence_line_edit_);

 main_notebook_ = new QTabWidget(this);
 result_text_edit_ = new QTextEdit(this);
 grammar_text_edit_ = new QTextEdit(this);
 sentence_text_edit_ = new QTextEdit(this);
 cpp_text_edit_ = new QTextEdit(this);

 sentence_line_edit_->setStyleSheet("QLineEdit{background:#B0C4DE;border:none}");

 connect(sentence_text_edit_, &QTextEdit::textChanged,
  [this]
 {
  nl_sample_ = sentence_text_edit_->document()->toPlainText().simplified();
  sentence_line_edit_->setText(nl_sample_);
 });

 cpp_text_edit_->document()->setPlainText(read_file_contents(
   GECODE_SOLVER_FILE
   ));

 main_notebook_->addTab(grammar_text_edit_, "Grammar");
 main_notebook_->addTab(sentence_text_edit_, "Sample");
 main_notebook_->addTab(result_text_edit_, "Result");
 main_notebook_->addTab(cpp_text_edit_, "C++");

 main_layout_->addWidget(main_notebook_);

 QString colorful_button_style_sheet =
  "QPushButton:hover {background:rgb(240,190,150);"
  " border-left: 4px groove rgb(240,190,150); "
  " border-right: 4px ridge rgb(240,190,150); "
  "}\n"
  "QPushButton{ padding:1px;  border: 2px solid rgb(240,190,150); "
  "  border-bottom: 1px solid #CEF51D; "
  " border-radius: 6px; "
  " background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, "
  "  stop: 0 white, stop: 0.1 #C0C0C0, stop: 0.6 #CC"
  "C6BC, stop: 0.8 #ECCFA0, stop: 0.9 darkred,  stop: 1 brown"
  "); min-width: 80px; }";


 run_layout_ = new QHBoxLayout;
 run_button_ = new QPushButton("Run", this);
 connect(run_button_, SIGNAL(clicked()), this, SLOT(run_button_clicked()));
 run_button_->setStyleSheet(colorful_button_style_sheet);
 run_layout_->addStretch();
 run_layout_->addWidget(run_button_);
 run_layout_->addStretch();

 main_layout_->addLayout(run_layout_);



 QString colorful_button_style_sheet_down =
  "QPushButton {background:rgb(190,190,230);padding-left:20;padding-right:20;padding-top:0;padding-bottom:0;"
  " border-left: 4px groove rgb(240,190,150); "
  " border-right: 4px ridge rgb(240,190,150); "
  "}\n";


 main_layout_->addWidget(button_box_);

 setLayout(main_layout_);

 show();
}

void View_Gecode_Demo_Dialog::grammar_file_open_button_clicked()
{
 QString path = QFileDialog::getOpenFileName(this, "Select a grammar file",
  GECODE_DEMO_DIR);
            //  ""/home/nlevisrael/gecode-demo");
 if(!path.isEmpty())
 {
  grammar_path_ = path;
  grammar_file_line_edit_->setText(path);
  grammar_ = read_file_contents(path);

  grammar_text_edit_->document()->setPlainText(grammar_);
  main_notebook_->setCurrentWidget(grammar_text_edit_);


//  QStringList qsl = grammar_.split(QRegularExpression("\\s+"));
//  QString current_key;
//  bool need_val = false;
//  for(QString qs : qsl)
//  {
//   if(qs == "::")
//    need_val = true;
//   else if(need_val)
//   {
//    current_grammar_.insert(current_key, qs);
//    need_val = false;
//   }
//   else
//   {
//    current_key = qs;
//   }

//  }

 }
}

void View_Gecode_Demo_Dialog::run_button_clicked()
{
 QString lex_file = grammar_path_;
//?   DEMO_DIR "/lex1.txt";
//   "/home/nlevisrael/rz-dev/nl/lex.txt";

 //QString nl_file = "/home/nlevisrael/rz-dev/nl/nl.txt";

 QString nl_sentence = nl_sample_; //?"The dog is there";
 //QString nl_sentence = "I go there";

 NL_Gecode_Lexicon ngl(lex_file);

 NL_Gecode_Solver* ngs = new NL_Gecode_Solver(&ngl, nl_sentence);
 DFS<NL_Gecode_Solver>e(ngs) ;
 delete ngs;

 NL_Gecode_Dock_Node_Pair_Vector_Collection dnpvc;
 //QMap< QMap<Dock_Node_Pair, int>, int> dnpms;

 while(NL_Gecode_Solver* s = e.next() )
 {
//?
//?  s->print();
//?
//?
  s->merge_with_dock_node_set(dnpvc);
  delete s ;
 }

// QString summary = dnpvc.inspect();
// qDebug().noquote() << summary;
 QStringList sxprs;
 dnpvc.show_s_expressions(sxprs);

 QString summary = sxprs.join("\n");
 result_text_edit_->setPlainText(summary);
 main_notebook_->setCurrentWidget(result_text_edit_);

#ifdef HIDE
// current_grammar_["The"] = "Adj";
// current_grammar_["dog"] = "N";
// current_grammar_["is"] = "V";
// current_grammar_["here"] = "N";
 sentence_line_edit_->setText(nl_sample_);

 QString lex_file = "/home/nlevisrael/rz-dev/nl/lexicon.txt";

 //QString nl_file = "/home/nlevisrael/rz-dev/nl/nl.txt";

 QString nl_sentence = "The dog is there";

 NL_Gecode_Lexicon ngl(lex_file);

 NL_Gecode_Solver* ngs = new NL_Gecode_Solver(&ngl, nl_sentence);
 DFS<NL_Gecode_Solver>e(ngs) ;
 delete ngs;

 NL_Gecode_Dock_Node_Pair_Vector_Collection dnpvc;
 //QMap< QMap<Dock_Node_Pair, int>, int> dnpms;

 while(NL_Gecode_Solver* s = e.next() )
 {
//?  s->print();
//?
  s->merge_with_dock_node_set(dnpvc);
  delete s ;
 }

// QString summary = dnpvc.inspect();

// qDebug().noquote() << summary;

 QString summary = dnpvc.inspect();
 result_text_edit_->setPlainText(summary);
 main_notebook_->setCurrentWidget(result_text_edit_);
#endif
}


void View_Gecode_Demo_Dialog::nl_file_open_button_clicked()
{
 QString path = QFileDialog::getOpenFileName(this, "Select a sample file", "/home/nlevisrael/gecode-demo");
 if(!path.isEmpty())
 {
  nl_file_line_edit_->setText(path);

  nl_sample_ = read_file_contents(path).simplified();
  sentence_text_edit_->document()->setPlainText(nl_sample_);
  main_notebook_->setCurrentWidget(sentence_text_edit_);

 }
}

QString View_Gecode_Demo_Dialog::read_file_contents(QString path)
{
 QFile infile(path);
 QString result;
 if(infile.open(QFile::ReadOnly))
 {
  QTextStream qts(&infile);
  result = qts.readAll();
 }
 return result;
}



View_Gecode_Demo_Dialog::~View_Gecode_Demo_Dialog()
{
 delete button_ok_;
 delete button_apply_;
 delete button_cancel_;

// delete url_label_;
// delete name_qle_;
}



void View_Gecode_Demo_Dialog::cancel()
{
 Q_EMIT(canceled(this));
// close();
}

void View_Gecode_Demo_Dialog::accept()
{
 Q_EMIT(accepted(this));
// close();
}
