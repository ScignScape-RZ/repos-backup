
#ifndef VIEW_GECODE_DEMO_DIALOG__H
#define VIEW_GECODE_DEMO_DIALOG__H


#include <QString>
#include <QMainWindow>

#include <QTextEdit>
//?#include <QWebView>

#include <QWebEngineView>
#include <QLabel>
#include <QPushButton>
#include <QTableView>
#include <QDialog>
#include <QStandardItemModel>

#include <QComboBox>

#include "accessors.h"

#include "flags.h"

#include "rzns.h"

//#include "incident-form-dialog.h"

class QPushButton;
class QTextEdit;
class QPlainTextEdit;
class QLineEdit;
class QTabWidget;
class QDialogButtonBox;
class QVBoxLayout;
class QHBoxLayout;
class QCheckBox;
class QFormLayout;
class QSplitter;
class QGridLayout;
class QListWidget;
class QTableWidget;
class QScrollArea;
class QGroupBox;
class QTableWidgetItem;

//RZNS_(QWN)
namespace RZ{ namespace NDP{


class NDP_Antemodel;
class NDP_Project;
class NDP_Project_Initial;


class View_Gecode_Demo_Dialog : public QDialog
{
 Q_OBJECT

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 //QPushButton* button_proceed_;
 QPushButton* button_apply_;


 QVBoxLayout* main_layout_;
 NDP_Antemodel* antemodel_;

 QHBoxLayout* grammar_file_layout_;
 QLabel* grammar_file_label_;
 QLineEdit* grammar_file_line_edit_;
 QPushButton* grammar_file_open_button_;

 QHBoxLayout* nl_file_layout_;
 QLabel* nl_file_label_;
 QLineEdit* nl_file_line_edit_;
 QPushButton* nl_file_open_button_;

 QLineEdit* sentence_line_edit_;

 QString current_path_;
 QTabWidget* main_notebook_;
 QTextEdit* result_text_edit_;
 QTextEdit* grammar_text_edit_;
 QTextEdit* sentence_text_edit_;
 QTextEdit* cpp_text_edit_;

 QString grammar_;
 QString nl_sample_;

 QString grammar_path_;

 QHBoxLayout* run_layout_;
 QPushButton* run_button_;

 QMap<QString, QString> current_grammar_;

 void read_file(QString path, QPlainTextEdit* qpte);

 QString read_file_contents(QString path);

public:

 View_Gecode_Demo_Dialog(QWidget* parent);
 ~View_Gecode_Demo_Dialog();


Q_SIGNALS:
 void canceled(QDialog*);
 void accepted(QDialog*);

public Q_SLOTS:
 void accept();
 void cancel();

 void grammar_file_open_button_clicked();
 void nl_file_open_button_clicked();
 void run_button_clicked();
 //?void proceed();


};

} } //_RZNS(NDP)



#endif
