
#include "view-ocr-dialog.h"


//#include "tesseract/api/baseapi.h"
//#include <leptonica/allheaders.h>


//#include "clg-db-antemodel.h";

#include <QApplication>

#include <QProcess>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>

#include <QPlainTextEdit>
#include <QTextStream>

#include <QTableWidget>

#include <QMessageBox>

#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrlQuery>

#include <QHeaderView>

#include <QListWidget>

#include "silotypes/ndp-project/ndp-project.h"
#include "silotypes/ndp-project/ndp-project-initial.h"

USING_RZNS(NDP)

View_OCR_Dialog::View_OCR_Dialog(QWidget* parent, NDP_Antemodel* antemodel)//, QString url, QWN_XMLDB_Configuration* config)
 : QDialog(parent), antemodel_(antemodel)//, config_(config)
{

 button_box_ = new QDialogButtonBox(this);

 button_ok_ = new QPushButton("OK");
 button_proceed_ = new QPushButton("Proceed");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

 button_proceed_->setDefault(false);
 button_proceed_->setAutoDefault(false);

 button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);


 connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));

 main_layout_ = new QVBoxLayout();

 web_engine_view_ = new QWebEngineView(this);

 main_splitter_ = new QSplitter(this);

 main_text_edit_ = new QTextEdit(this);


 url_label_  = new QLabel("URL", this);
 url_line_edit_ = new QLineEdit(this);

 url_layout_ = new QHBoxLayout;
 url_layout_->addWidget(url_label_);
 url_layout_->addWidget(url_line_edit_);

 main_splitter_->addWidget(web_engine_view_);
 main_splitter_->addWidget(main_text_edit_);

 main_layout_->addWidget(main_splitter_);
 main_layout_->addLayout(url_layout_);

 //file:///home/nlevisrael/NDP/tesseract/tesseract/api/handwriting-sample.jpg

 QString colorful_button_style_sheet =
  "QPushButton:hover {background:rgb(240,190,150);"
  " border-left: 4px groove rgb(240,190,150); "
  " border-right: 4px ridge rgb(240,190,150); "
  "}\n"
  "QPushButton{ padding:1px;  border: 2px solid rgb(240,190,150); "
  "  border-bottom: 1px solid #CEF51D; "
  " border-radius: 6px; "
  " background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, "
  "  stop: 0 white, stop: 0.1 #C0C0C0, stop: 0.6 #CC"
  "C6BC, stop: 0.8 #ECCFA0, stop: 0.9 darkred,  stop: 1 brown"
  "); min-width: 80px; }";



 QString colorful_button_style_sheet_down =
  "QPushButton {background:rgb(190,190,230);padding-left:20;padding-right:20;padding-top:0;padding-bottom:0;"
  " border-left: 4px groove rgb(240,190,150); "
  " border-right: 4px ridge rgb(240,190,150); "
  "}\n";


// QHBoxLayout* load_button_layout_;
// QPushButton* load_button_;
// QPushButton* convert_button_;

 open_button_ = new QPushButton("Open", this);
 load_button_ = new QPushButton("Load", this);
 convert_button_ = new QPushButton("Convert", this);
 close_button_ = new QPushButton("Close", this);

 open_button_->setStyleSheet(colorful_button_style_sheet);
 load_button_->setStyleSheet(colorful_button_style_sheet);
 convert_button_->setStyleSheet(colorful_button_style_sheet);
 close_button_->setStyleSheet(colorful_button_style_sheet);

 load_button_layout_ = new QHBoxLayout;
 load_button_layout_->addStretch();
 load_button_layout_->addWidget(open_button_);
 load_button_layout_->addWidget(load_button_);
 load_button_layout_->addWidget(convert_button_);
 load_button_layout_->addStretch();

 main_layout_->addLayout(load_button_layout_);

 close_button_layout_ = new QHBoxLayout;
 close_button_layout_->addStretch();
 close_button_layout_->addWidget(close_button_);
 close_button_layout_->addStretch();

 main_layout_->addLayout(close_button_layout_);

 connect(open_button_, SIGNAL(clicked()), this,
         SLOT(open_button_clicked()));

 connect(load_button_, SIGNAL(clicked()), this,
         SLOT(load_button_clicked()));

 connect(convert_button_, SIGNAL(clicked()), this,
         SLOT(convert_button_clicked()));



 main_layout_->addWidget(button_box_);

 setLayout(main_layout_);

 show();
}


void View_OCR_Dialog::load_url(QString url)
{
 web_engine_view_->load(QUrl(url));
}

void View_OCR_Dialog::load_local_file(QString path)
{
 QString url = QString("file://%1").arg(path);
 url_line_edit_->setText(url);
 load_url(url);
}


void View_OCR_Dialog::load_button_clicked()
{
 QString url = url_line_edit_->text();
 web_engine_view_->load(QUrl(url));
}

void View_OCR_Dialog::open_button_clicked()
{
 QString path = QFileDialog::getOpenFileName(this, "Choose OCR Image File", DEMO_DIR);
 if(!path.isEmpty())
 {
  load_local_file(path);
  current_path_ = path;
 }
}

void View_OCR_Dialog::convert_button_clicked()
{
 QString program = "/home/nlevisrael/NDP/tesseract/build-tconsole-qt-ClangQ58-Debug/tconsole-qt";
 QStringList arguments;

 qDebug() << "Converting << " << current_path_;

 arguments << current_path_;


 QProcess* proc = new QProcess;

 QProcessEnvironment env = QProcessEnvironment::systemEnvironment();
 env.insert("LD_LIBRARY_PATH",
   "$LD_LIBRARY_PATH:/home/nlevisrael/NDP/tesseract/tconsole/:/home/nlevisrael/NDP/tesseract/tesseract/api/.libs/"); // Add an environment variable
 proc->setProcessEnvironment(env);

 QEventLoop loop;

 QProcess::connect(proc,
                   static_cast<void (QProcess::*)(int exit_code, QProcess::ExitStatus exit_status)>
                   (&QProcess::finished), [proc, &loop, this]
   (int exit_code, QProcess::ExitStatus exit_status)
  {

   QString output = QString::fromUtf8(proc->readAllStandardOutput());
   main_text_edit_->setPlainText(output);
   //qDebug() << "Output: " << output;
   loop.exit();
  });


 QProcess::connect(proc,
                   static_cast<void (QProcess::*)(QProcess::ProcessError)>
                   (&QProcess::error), [proc, &loop]
   (QProcess::ProcessError pError)
  {
   //QString output(proc->readAllStandardOutput());
   qDebug() << "Error: ";// << output;
   loop.exit();
  });

 QProcess::connect(proc, &QProcess::started, [proc, &loop]
   ()
  {
   //QString output(proc->readAllStandardOutput());
   qDebug() << "Started. ";// << output;
  });



 proc->start(program, arguments);
// proc->waitForFinished();

// QString output(proc->readAllStandardOutput());

// qDebug() << "O: " << output;

 // test_ocr();

// QApplication app(argc, argv);

//?
 loop.exec();


// char *outText;

// tesseract::TessBaseAPI *api = new tesseract::TessBaseAPI();
// // Initialize tesseract-ocr with English, without specifying tessdata path
// if (api->Init(NULL, "eng")) {
//     fprintf(stderr, "Could not initialize tesseract.\n");
//     exit(1);
// }

// // Open input image with leptonica library
// Pix *image = pixRead("/home/nlevisrael/NDP/tesseract/tesseract/api/handwriting-sample.jpg"); //current_path_.toLatin1()); //"/usr/src/tesseract/testing/phototest.tif");
// api->SetImage(image);
// // Get OCR result
// outText = api->GetUTF8Text();

// QString outt = QString::fromUtf8(outText);

// main_text_edit_->setPlainText(outt);

// //printf("OCR output:\n%s", outText);

// // Destroy used object and release memory
// api->End();
// delete [] outText;
// pixDestroy(&image);

}

//View_OCR_Dialog::View_OCR_Dialog()
// // : parent_(nullptr), antemodel_(nullptr)
//{

//}
//View_OCR_Dialog::View_OCR_Dialog(const View_OCR_Dialog& rhs)
// // : setP(rhs.parent_), antemodel_(rhs.antemodel_)
//{

//}

View_OCR_Dialog::~View_OCR_Dialog()
{
 delete button_ok_;
 delete button_proceed_;
 delete button_cancel_;

// delete url_label_;
// delete name_qle_;
}



void View_OCR_Dialog::cancel()
{
 Q_EMIT(canceled(this));
// close();
}

void View_OCR_Dialog::accept()
{
 Q_EMIT(accepted(this));
// close();
}
