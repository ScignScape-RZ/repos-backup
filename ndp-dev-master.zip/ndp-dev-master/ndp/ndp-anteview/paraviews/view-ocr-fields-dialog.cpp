
#include "view-ocr-fields-dialog.h"


//#include "tesseract/api/baseapi.h"
//#include <leptonica/allheaders.h>


//#include "clg-db-antemodel.h";

#include <QApplication>

#include <QProcess>

#include <QHBoxLayout>
#include <QVBoxLayout>

#include <QScrollArea>
#include <QFileDialog>
#include <QTabWidget>
#include <QSplitter>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>

#include <QPlainTextEdit>
#include <QTextStream>

#include <QTableWidget>

#include <QMessageBox>

#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrlQuery>

#include <QHeaderView>

#include <QListWidget>

#include "silotypes/ndp-project/ndp-project.h"
#include "silotypes/ndp-project/ndp-project-initial.h"

USING_RZNS(NDP)

View_OCR_Fields_Dialog::View_OCR_Fields_Dialog(QWidget* parent,
  QList<OCR_Field>& fields) //NDP_Antemodel* antemodel)//, QString url, QWN_XMLDB_Configuration* config)
 : QDialog(parent) //?, antemodel_(antemodel)//, config_(config)
{

 button_box_ = new QDialogButtonBox(this);

 button_ok_ = new QPushButton("OK");
 button_apply_ = new QPushButton("Apply");
 //button_proceed_ = new QPushButton("Proceed");
 button_cancel_ = new QPushButton("Cancel");

 button_ok_->setDefault(false);
 button_ok_->setAutoDefault(false);

// button_proceed_->setDefault(false);
// button_proceed_->setAutoDefault(false);

 button_apply_->setDefault(false);
 button_apply_->setAutoDefault(false);

 button_cancel_->setDefault(true);

 button_ok_->setEnabled(false);

 button_box_->addButton(button_ok_, QDialogButtonBox::AcceptRole);
 button_box_->addButton(button_apply_, QDialogButtonBox::ApplyRole);
// button_box_->addButton(button_proceed_, QDialogButtonBox::ApplyRole);
 button_box_->addButton(button_cancel_, QDialogButtonBox::RejectRole);


// connect(button_proceed_, SIGNAL(clicked()), this, SLOT(proceed()));
 connect(button_apply_, SIGNAL(clicked()), this, SLOT(apply()));
 connect(button_box_, SIGNAL(accepted()), this, SLOT(accept()));
 connect(button_box_, SIGNAL(rejected()), this, SLOT(cancel()));

 main_layout_ = new QVBoxLayout();

 main_table_view_ = new QTableView(this);
 main_table_model_ = new QStandardItemModel(fields.size(), 4, this);

 main_table_model_->setHorizontalHeaderLabels({"Page", "Field Label", "Value", "Image" });

 main_table_view_->setModel(main_table_model_);

 //?main_table_view_->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

 int i = 0;
 //QMapIterator<QString, QString> it(fields);
 for(OCR_Field f : fields)
 {
  QStandardItem* qsi = new QStandardItem();

  QImage im = f.image->scaled(f.image->width()/8, f.image->height()/8);

  qsi->setData(QVariant(QPixmap::fromImage(im)), Qt::DecorationRole);

  QStandardItem* fp = new QStandardItem(QString::number(f.page));
  fp->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
  main_table_model_->setItem(i, 0, fp);
  main_table_model_->setItem(i, 1, new QStandardItem(f.field_name));
  main_table_model_->setItem(i, 2, new QStandardItem(f.field_value));
  main_table_model_->setItem(i, 3, qsi);

  ++i;
 }

 main_table_view_->setColumnWidth(0, 40);

 main_table_view_->resizeColumnsToContents();

 int width = (main_table_view_->model()->columnCount() - 1) + main_table_view_->verticalHeader()->width();
 for(int column = 0; column < main_table_view_->model()->columnCount(); column++)
 {
  width += main_table_view_->columnWidth(column);
 }

 int height = 0;
 for(int row = 0; row < main_table_view_->model()->rowCount(); row++)
 {
  height += main_table_view_->rowHeight(row);
 }

 main_layout_->addWidget(main_table_view_);

 QString colorful_button_style_sheet =
  "QPushButton:hover {background:rgb(240,190,150);"
  " border-left: 4px groove rgb(240,190,150); "
  " border-right: 4px ridge rgb(240,190,150); "
  "}\n"
  "QPushButton{ padding:1px;  border: 2px solid rgb(240,190,150); "
  "  border-bottom: 1px solid #CEF51D; "
  " border-radius: 6px; "
  " background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, "
  "  stop: 0 white, stop: 0.1 #C0C0C0, stop: 0.6 #CC"
  "C6BC, stop: 0.8 #ECCFA0, stop: 0.9 darkred,  stop: 1 brown"
  "); min-width: 80px; }";



 QString colorful_button_style_sheet_down =
  "QPushButton {background:rgb(190,190,230);padding-left:20;padding-right:20;padding-top:0;padding-bottom:0;"
  " border-left: 4px groove rgb(240,190,150); "
  " border-right: 4px ridge rgb(240,190,150); "
  "}\n";


// QHBoxLayout* load_button_layout_;
// QPushButton* load_button_;
// QPushButton* convert_button_;

// close_button_ = new QPushButton("Close", this);
// close_button_->setStyleSheet(colorful_button_style_sheet);

//? close_button_layout_ = new QHBoxLayout;
// close_button_layout_->addStretch();
// close_button_layout_->addWidget(close_button_);
// close_button_layout_->addStretch();
// main_layout_->addLayout(close_button_layout_);

 main_layout_->addWidget(button_box_);

 height += button_box_->height();

 height += 20;

 setLayout(main_layout_);

 resize(width, height);

 show();
}


View_OCR_Fields_Dialog::~View_OCR_Fields_Dialog()
{
 delete button_ok_;
 delete button_apply_;
 delete button_cancel_;

// delete url_label_;
// delete name_qle_;
}



void View_OCR_Fields_Dialog::cancel()
{
 Q_EMIT(canceled(this));
// close();
}

void View_OCR_Fields_Dialog::accept()
{
 Q_EMIT(accepted(this));
// close();
}
