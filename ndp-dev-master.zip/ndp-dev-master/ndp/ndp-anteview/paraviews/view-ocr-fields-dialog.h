
#ifndef VIEW_OCR_FIELDS_DIALOG__H
#define VIEW_OCR_FIELDS_DIALOG__H


#include <QString>
#include <QMainWindow>

#include <QTextEdit>
//?#include <QWebView>

#include <QWebEngineView>
#include <QLabel>
#include <QPushButton>
#include <QTableView>
#include <QDialog>
#include <QStandardItemModel>

#include <QComboBox>

#include "accessors.h"

#include "flags.h"

#include "rzns.h"

//#include "incident-form-dialog.h"

class QPushButton;
class QTextEdit;
class QPlainTextEdit;
class QLineEdit;
class QTabWidget;
class QDialogButtonBox;
class QVBoxLayout;
class QHBoxLayout;
class QCheckBox;
class QFormLayout;
class QSplitter;
class QGridLayout;
class QListWidget;
class QTableWidget;
class QScrollArea;
class QGroupBox;
class QTableWidgetItem;

//RZNS_(QWN)
namespace RZ{ namespace NDP{


class NDP_Antemodel;
class NDP_Project;
class NDP_Project_Initial;

struct OCR_Field
{
 int page;
 QString field_name;
 QString field_value;
 QImage* image;

};


class View_OCR_Fields_Dialog : public QDialog
{
 Q_OBJECT

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 //QPushButton* button_proceed_;
 QPushButton* button_apply_;


 //QSplitter* main_splitter_;

 QTableView* main_table_view_;

 QStandardItemModel* main_table_model_;

 QVBoxLayout* main_layout_;
 NDP_Antemodel* antemodel_;

// QHBoxLayout* close_button_layout_;
// QPushButton* close_button_;

 QString current_path_;

 void read_file(QString path, QPlainTextEdit* qpte);

public:

 View_OCR_Fields_Dialog(QWidget* parent,
   QList<OCR_Field>& fields );
 //NDP_Antemodel* antemodel);

// View_OCR_Dialog();
// View_OCR_Dialog(const View_OCR_Dialog& rhs);

 ~View_OCR_Fields_Dialog();


Q_SIGNALS:
 void canceled(QDialog*);
 void accepted(QDialog*);

public Q_SLOTS:
 void accept();
 void cancel();
 //?void proceed();


};

} } //_RZNS(NDP)



#endif
