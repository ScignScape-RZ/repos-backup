
#ifndef VIEW_SVG_DIALOG__H
#define VIEW_SVG_DIALOG__H


#include <QString>
#include <QMainWindow>

#include <QTextEdit>
//?#include <QWebView>

#include <QWebEngineView>
#include <QLabel>
#include <QPushButton>

#include <QGraphicsView>
#include <QGraphicsSvgItem>

#include <QBoxLayout>

#include <QDialog>

#include <QComboBox>

#include "accessors.h"

#include "flags.h"

#include "rzns.h"

//#include "incident-form-dialog.h"

class QPushButton;
class QTextEdit;
class QPlainTextEdit;
class QLineEdit;
class QTabWidget;
class QDialogButtonBox;
class QVBoxLayout;
class QHBoxLayout;
class QCheckBox;
class QFormLayout;
class QSplitter;
class QGridLayout;
class QListWidget;
class QTableWidget;
class QScrollArea;
class QGroupBox;
class QTableWidgetItem;

//RZNS_(QWN)
namespace RZ{ namespace NDP{


class CTQ_Antemodel;
class CTQ_Project;
class CTQ_Project_Initial;


//class Contextable_Graphics_Item : public QGraphicsItem
//{
//public:
// Contextable_Graphics_Item(QGraphicsItem)

//};

class View_SVG_Dialog : public QDialog
{
 Q_OBJECT

 QDialogButtonBox* button_box_;
 QPushButton* button_ok_;
 QPushButton* button_cancel_;
 QPushButton* button_proceed_;

 qreal old_zoom_slider_value_;


 QLabel* url_label_;
 QLineEdit* url_line_edit_;

 QTabWidget* main_notebook_;
 QGraphicsView* svg_view_;
 QTextEdit* svg_source_;
 QTextEdit* instructions_;
 QTextEdit* languages_;

 QGraphicsScene* svg_scene_;

 QGraphicsSvgItem* current_svg_item_;

 QMap<QGraphicsSvgItem*, QVector<QGraphicsItem*> > current_svg_specific_items_;

 //QMap<QString, QString> svg_paths_;
 QMap<QGraphicsSvgItem*, QString> svg_names_;
 QMap<QString, QGraphicsSvgItem*> inverse_svg_names_;

 //?QMap<QString, QPolygonF> polys_by_name_;

 QLabel* current_svg_label_;

 QGraphicsSvgItem* front_svg_item_;
 QGraphicsSvgItem* back_svg_item_;
 QGraphicsSvgItem* left_foot_svg_item_;
 QGraphicsSvgItem* right_foot_svg_item_;
 QGraphicsSvgItem* left_leg_svg_item_;
 QGraphicsSvgItem* right_leg_svg_item_;
 QGraphicsSvgItem* left_face_svg_item_;
 QGraphicsSvgItem* right_face_svg_item_;
 QGraphicsSvgItem* hands_svg_item_;

 QGraphicsSvgItem* front_scratch_svg_item_;
 QGraphicsSvgItem* back_scratch_svg_item_;
 QGraphicsSvgItem* left_foot_scratch_svg_item_;
 QGraphicsSvgItem* right_foot_scratch_svg_item_;
 QGraphicsSvgItem* left_leg_scratch_svg_item_;
 QGraphicsSvgItem* right_leg_scratch_svg_item_;
 QGraphicsSvgItem* left_face_scratch_svg_item_;
 QGraphicsSvgItem* right_face_scratch_svg_item_;
 QGraphicsSvgItem* hands_scratch_svg_item_;

 //
 QPushButton* front_svg_item_button_;
 QPushButton* back_svg_item_button_;

 QPushButton* left_foot_svg_item_button_;
 QPushButton* right_foot_svg_item_button_;

 QPushButton* left_leg_svg_item_button_;
 QPushButton* right_leg_svg_item_button_;

 QPushButton* left_face_svg_item_button_;
 QPushButton* right_face_svg_item_button_;

 QPushButton* hands_svg_item_button_;

 QGraphicsScene* scratch_scene_;

 QMap<QGraphicsSvgItem*, QLabel*> labels_to_items_;

 QPushButton* star_button_;
 QPushButton* ellipse_button_;
 QPushButton* diamond_button_;
 QPushButton* plus_button_;
 QPushButton* cross_plus_button_;
 QPushButton* deco_plus_button_;
 QPushButton* octagon_button_;
 QPushButton* vertical_octagon_button_;
 QPushButton* deco_button_;
 QPushButton* skewed_octagon_button_;
 QPushButton* skewed_tight_plus_button_;
 QPushButton* tight_plus_button_;
 QPushButton* triangle_down_button_;
 QPushButton* triangle_up_button_;

 QLabel* persistent_pain_label_;
 QLabel* shooting_pain_label_;
 QLabel* stabbing_pain_label_;
 QLabel* burning_pain_label_;

 QFrame* graphics_frame_;
 QHBoxLayout* graphics_layout_;
 QVBoxLayout* graphics_buttons_layout_;
 QVBoxLayout* silhouettes_buttons_layout_;

 QVBoxLayout* main_layout_;
//? CTQ_Antemodel* antemodel_;

 int original_width_;
 int original_height_;

 QHBoxLayout* clear_button_layout_;
 QPushButton* clear_button_;

 QPushButton* zoom_in_button_;
 QPushButton* zoom_out_button_;

 QSlider* zoom_slider_;

 QMap<QPushButton*, QPolygonF> polys_;

 void read_file(QString path, QPlainTextEdit* qpte);

 void render_to_button(QPushButton* btn, QPolygonF& poly);

 void render_to_button(QPushButton* btn, QGraphicsSvgItem* item,
   QGraphicsSvgItem* scratch_item, QBoxLayout* layout, qreal x_offset, qreal y_offset,
   qreal reenlage_factor, QString text, qreal rotate = 0);

 static void construct_octagon(QPolygonF& poly, float center_x, float center_y,
   float scale_factor, float x_offset, float y_offset, float width);

 static void construct_plus(QPolygonF& poly, float center_x, float center_y,
   float scale_factor, float offset, float width);

 static void construct_deco_plus(QPolygonF& poly, float center_x, float center_y,
   float scale_factor, float offset, float width, float deco_offset);

 static void construct_triangle_down(QPolygonF& poly, float center_x, float center_y,
   float scale_factor, float width, float height, float y_offset);

 static void construct_triangle_up(QPolygonF& poly, float center_x, float center_y,
   float scale_factor, float width, float height, float y_offset);


 void horizontal_flip_transform(QGraphicsSvgItem* item, int x_offset = 0);
 void horizontal_flip_transform_alt(QGraphicsSvgItem* item, int x_offset = 0);
 void vertical_flip_transform_alt(QGraphicsSvgItem* item, int y_offset = 0);

 void add_graphics_button_text_and_line(QLabel* label);

 void enable_graphics_buttons();


 void handle_edit_pain_level(QGraphicsItem* item);

public:

 View_SVG_Dialog(QWidget* parent); //?, CTQ_Antemodel* antemodel);
 ~View_SVG_Dialog();

// ACCESSORS(QTextEdit* ,main_text)

 void get_all_scene_data(QByteArray& qba);
 void load_all_scene_data(QByteArray& qba);


Q_SIGNALS:
 void canceled(QDialog*);
 void accepted(QDialog*);

public Q_SLOTS:
 void accept();
 void cancel();

 void show_svg_view_context_menu(const QPoint& p);

 //?void proceed();

 void graphics_button_clicked();
 void zoom_in();
 void zoom_out();

 void zoom_slider_value_changed(int val);

 void clear_button_clicked();

 void save_scene();
 void open_scene();


};

} } //_RZNS(CTQ)


#endif
