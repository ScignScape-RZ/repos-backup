
#include "ndp-event.h"

#include "ndp-application.h"

#include "data/ndp-data-manager.h"


USING_RZNS(NDP)

NDP_Event::NDP_Event(NDP_Data_Manager* mgr, QDate date, QString description)
  : mgr_(mgr), date_(date),
  description_(description)
{

}

NDP_Event::NDP_Event(NDP_Data_Manager* mgr)
 : mgr_(mgr)
{

}


QString NDP_Event::key_from_date()
{
 return date_.toString(Qt::DateFormat::ISODate);
}

void NDP_Event::absorb_data(QByteArray& qba)
{
 QDataStream qds(&qba, QIODevice::ReadOnly);
 qds >> date_;

// QStringList artist_codes;
// qds >> artist_codes;
 qds >> description_;

// for(QString code : artist_codes)
// {
//  NDP_Artist* pda = mgr_->get_artist_by_code(code);
//  artists_.push_back(pda);
// }
}

QString NDP_Event::to_xml()
{
 QString result = "<event>";
// result += "\n<artists>";
// for(NDP_Artist* a : artists_)
// {
//  result += "\n" + a->to_xml();
// }
// result += "\n</artists>";
 result += "\n<date>" + date_.toString() + "</date>";
 result += "\n<description>\n" + description_ + "\n</description>";
 return result;
}


void NDP_Event::supply_data(QByteArray& qba)
{
 QDataStream qds(&qba, QIODevice::WriteOnly);

// QStringList artist_codes;

// for(NDP_Artist* pda : artists_)
// {
//  artist_codes.push_back(pda->code());
// }

 qds << date_;
// qds << artist_codes;
 qds << description_;
}




