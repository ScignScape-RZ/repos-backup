
#ifndef NDP_EVENT__H
#define NDP_EVENT__H


#include <QString>
#include <QMainWindow>
#include <QUrl>

#include <functional>

#include <QList>

#include <QDate>

#include "accessors.h"

#include "flags.h"


#include "rzns.h"

RZNS_(NDP)
//namespace RZ{ namespace CLG{


class NDP_Data_Manager;

class NDP_Event
{
 NDP_Data_Manager* mgr_;

 QDate date_;
 QString description_;

public:

 NDP_Event(NDP_Data_Manager* mgr, QDate date, QString description);

 NDP_Event(NDP_Data_Manager* mgr);

 ACCESSORS(QDate ,date)
 ACCESSORS(QString ,description)


 QString key_from_date();

 void absorb_data(QByteArray& qba);
 void supply_data(QByteArray& qba);

 QString to_xml();

};

_RZNS(NDP)

#endif
