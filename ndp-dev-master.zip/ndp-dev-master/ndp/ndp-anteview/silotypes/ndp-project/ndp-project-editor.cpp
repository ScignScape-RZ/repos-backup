
#include "ndp-project-editor.h"

#include "ndp-application.h"

#include "data/ndp-data-manager.h"


USING_RZNS(NDP)

//NDP_Project::NDP_Project(NDP_Data_Manager* mgr, QDate date, QString description)
//  : mgr_(mgr), date_(date),
//  description_(description)
//{

//}

NDP_Project_Editor::NDP_Project_Editor(NDP_Project_Record* pror)
 : NDP_Project_Record_Holder(pror)
{

}


void NDP_Project_Editor::absorb_string_map(QMap<QString, QString>& params)
{
 QMap<QString, QString> old_params{{
   { "name", record_->name() },
   { "local-folder", record_->local_folder() },
   { "#local-port", QString::number(record_->local_port()) },
   { "#docker-port", QString::number(record_->docker_port()) },
   { "remote-address", record_->remote_address() },
   { "description", record_->description() },
   { "secondary-addresses", record_->secondary_addresses().join('\n') }
 }};
 this->NDP_Project_Record_Holder::absorb_string_map(params, &old_params);
}
