
#ifndef NDP_PROJECT_EDITOR__H
#define NDP_PROJECT_EDITOR__H


#include <QString>
#include <QMainWindow>
#include <QUrl>

#include <functional>

#include <QList>

#include <QDate>

#include <QMap>

#include "ndp-project-record.h"
#include "ndp-project-record-holder.h"

#include "accessors.h"

#include "flags.h"


#include "rzns.h"

RZNS_(NDP)
//namespace RZ{ namespace CLG{


class NDP_Data_Manager;

class NDP_Project_Editor : public NDP_Project_Record_Holder
{

public:

 NDP_Project_Editor(NDP_Project_Record* pror);

 void absorb_string_map(QMap<QString, QString>& params);


};

_RZNS(NDP)

#endif
