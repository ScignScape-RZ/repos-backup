
#include "ndp-project-initial.h"

#include "ndp-application.h"

#include "data/ndp-data-manager.h"


USING_RZNS(NDP)

//NDP_Project::NDP_Project(NDP_Data_Manager* mgr, QDate date, QString description)
//  : mgr_(mgr), date_(date),
//  description_(description)
//{

//}

NDP_Project_Initial::NDP_Project_Initial(NDP_Data_Manager* mgr)
 : NDP_Project_Record_Holder(mgr)
{

}

//void NDP_Project_Initial::absorb_string_map(QMap<QString, QString>& params)
//{

//}
