
#ifndef NDP_PROJECT_INITIAL__H
#define NDP_PROJECT_INITIAL__H


#include <QString>
#include <QMainWindow>
#include <QUrl>

#include <functional>

#include <QList>

#include <QDate>

#include <QMap>

#include "ndp-project-record.h"
#include "ndp-project-record-holder.h"

#include "accessors.h"

#include "flags.h"


#include "rzns.h"

RZNS_(NDP)
//namespace RZ{ namespace CLG{


class NDP_Data_Manager;

class NDP_Project_Initial : public NDP_Project_Record_Holder
{

public:

 NDP_Project_Initial(NDP_Data_Manager* mgr);


};

_RZNS(NDP)

#endif
