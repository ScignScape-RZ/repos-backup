
#include "ndp-project-record-bridge.h"

#include "ndp-application.h"

#include "data/ndp-data-manager.h"


USING_RZNS(NDP)


NDP_Project_Record_Bridge::NDP_Project_Record_Bridge(NDP_Project_Record* record)
 : NDP_Project_Record_Holder(record)
{

}

void NDP_Project_Record_Bridge::set_secondary_addresses(QString qs)
{
 QStringList qsl = qs.split("\n");
 record_->secondary_addresses() = qsl;
}
