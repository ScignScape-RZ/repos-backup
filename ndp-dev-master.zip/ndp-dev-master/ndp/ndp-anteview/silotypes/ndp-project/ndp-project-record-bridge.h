
#ifndef NDP_PROJECT_RECORD_BRIDGE__H
#define NDP_PROJECT_RECORD_BRIDGE__H


#include <QString>
#include <QMainWindow>
#include <QUrl>

#include <functional>

#include <QList>

#include <QDate>

#include <QMap>

#include "ndp-project-record.h"
#include "ndp-project-record-holder.h"

#include "accessors.h"

#include "flags.h"


#include "rzns.h"

//RZNS_(NDP)
namespace RZ{ namespace NDP{


class NDP_Data_Manager;

class NDP_Project_Record_Bridge : public QObject, public NDP_Project_Record_Holder
{
 Q_OBJECT

public:

 NDP_Project_Record_Bridge(NDP_Project_Record* record);

 ACCESSORS__QINV__RECORD(QDate ,date_created)
 ACCESSORS__QINV__RECORD(QString ,description)
 ACCESSORS__QINV__RECORD(QString ,name)
 ACCESSORS__QINV__RECORD(QString ,local_folder)
 ACCESSORS__QINV__RECORD(int ,local_port)
 ACCESSORS__QINV__RECORD(int ,docker_port)
 ACCESSORS__QINV__RECORD(QString ,remote_address)
 ACCESSORS__QINV__RECORD__RGET(QStringList ,secondary_addresses)

 Q_INVOKABLE void set_secondary_addresses(QString qs);

 //void absorb_string_map(QMap<QString, QString>& params);


};

_RZNS(NDP)

#endif
