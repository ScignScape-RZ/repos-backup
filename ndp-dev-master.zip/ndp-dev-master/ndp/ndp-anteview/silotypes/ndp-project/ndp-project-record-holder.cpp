
#include "ndp-project-record-holder.h"

#include "ndp-application.h"

#include "data/ndp-data-manager.h"

#include "ndp-project-record-bridge.h"


USING_RZNS(NDP)


NDP_Project_Record_Holder::NDP_Project_Record_Holder(NDP_Data_Manager* mgr)
 : record_(new NDP_Project_Record(mgr))
{

}

NDP_Project_Record_Holder::NDP_Project_Record_Holder(NDP_Project_Record* record)
 : record_(record)
{

}


void NDP_Project_Record_Holder::absorb_string_map(QMap<QString, QString>& params,
  QMap<QString, QString>* old_params)
{
 NDP_Project_Record_Bridge prb(record_);
 QMapIterator<QString, QString> it(params);
 while(it.hasNext())
 {
  it.next();
  QString param = it.key();
  QString value = it.value();
  if(old_params)
  {
   if(old_params->value(param) == value)
   {
    continue;
   }
  }
  param.replace('-', '_');
  if(param.startsWith('#'))
  {
   QString setter = QString("set_%1").arg(param.mid(1));
   int v = value.toInt();
   const QMetaObject* qmo = prb.metaObject();
   qmo->invokeMethod(&prb, setter.toLatin1(), Q_ARG(int ,v));
  }
  else if(param.startsWith('%'))
  {
   QString setter = QString("set_%1").arg(param.mid(1));
   double v = value.toDouble();
   const QMetaObject* qmo = prb.metaObject();
   qmo->invokeMethod(&prb, setter.toLatin1(), Q_ARG(double ,v));
  }
  else
  {
   QString setter = QString("set_%1").arg(param);
   const QMetaObject* qmo = prb.metaObject();
   qmo->invokeMethod(&prb, setter.toLatin1(), Q_ARG(QString ,value));
  }
 }
}
