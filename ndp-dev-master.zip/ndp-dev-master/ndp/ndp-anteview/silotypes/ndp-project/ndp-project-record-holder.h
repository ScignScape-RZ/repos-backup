
#ifndef NDP_PROJECT_RECORD_HOLDER__H
#define NDP_PROJECT_RECORD_HOLDER__H


#include <QString>
#include <QMainWindow>
#include <QUrl>

#include <functional>

#include <QList>

#include <QDate>

#include <QMap>

#include "ndp-project-record.h"

#include "accessors.h"

#include "flags.h"


#include "rzns.h"

RZNS_(NDP)
//namespace RZ{ namespace CLG{


class NDP_Data_Manager;

class NDP_Project_Record_Holder
{
protected:

 NDP_Project_Record* record_;

public:

 NDP_Project_Record_Holder(NDP_Project_Record* record);

 NDP_Project_Record_Holder(NDP_Data_Manager* mgr);

 ACCESSORS(NDP_Project_Record* ,record)

 ACCESSORS__RECORD(QDate ,date_created)
 ACCESSORS__RECORD(QString ,description)
 ACCESSORS__RECORD(QString ,name)
 ACCESSORS__RECORD(QString ,local_folder)
 ACCESSORS__RECORD(int ,local_port)
 ACCESSORS__RECORD(int ,docker_port)
 ACCESSORS__RECORD(QString ,remote_address)
 ACCESSORS__RECORD__RGET(QStringList ,secondary_addresses)

 void absorb_string_map(QMap<QString, QString>& params,
   QMap<QString, QString>* old_params = nullptr);


};

_RZNS(NDP)

#endif
