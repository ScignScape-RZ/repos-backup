
#include "ndp-project-silo.h"
#include "ndp-project-record.h"
#include "ndp-project.h"

#include <QRegExp>

#include "rzns.h"

USING_RZNS(NDP)


NDP_Project_Silo::NDP_Project_Silo(int record_count, int type_id, QString type_name)
 : record_count_(record_count),
   last_saved_record_count_(record_count), type_id_(type_id), type_name_(type_name)
{

}

QString NDP_Project_Silo::make_ukey(QString referrer_email, QString potential_contact_name)
{
 QString result = referrer_email.replace(QRegExp("\\s+"), "");
 result += "@@" + potential_contact_name.replace(QRegExp("\\s+"), "");
 return result;
}

int NDP_Project_Silo::new_uid()
{
 return ++record_count_;
}


int NDP_Project_Silo::check_save_record_count()
{
 if(last_saved_record_count_ != record_count_)
 {
  last_saved_record_count_ = record_count_;
  return record_count_;
 }
 else
 {
  return 0;
 }

}


NDP_Project* NDP_Project_Silo::confirm_joinee_from_record
 (NDP_Project_Record& record, int uid)
{
 record.set_uid(uid);

 NDP_Project* result = new NDP_Project;
 result->absorb_record(record);

 return result;
// if(record_count_ != last_saved_record_count_)
// {
//  save_record_count();
// }

}

