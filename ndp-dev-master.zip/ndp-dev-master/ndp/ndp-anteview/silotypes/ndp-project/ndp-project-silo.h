

#ifndef NDP_PROJECT_SILO__H
#define NDP_PROJECT_SILO__H

#include <QString>

#include "accessors.h"
#include "rzns.h"

RZNS_(NDP)

class NDP_Project_Record;
class NDP_Project;
//?class PCV_Data_Manager;

class NDP_Project_Silo
{
 int record_count_;
 int type_id_;
 int last_saved_record_count_;

 QString type_name_;

public:

 ACCESSORS(int ,record_count)
 ACCESSORS(QString ,type_name)
 ACCESSORS(int ,type_id)

 typedef NDP_Project cotype;

 NDP_Project_Silo(int record_count, int type_id, QString type_name);

 int new_uid();


 static QString make_ukey(QString referrer_email, QString potential_contact_name);

 NDP_Project* confirm_joinee_from_record
  (NDP_Project_Record& record, int uid);

 int check_save_record_count();

};

_RZNS(NDP)


#endif
