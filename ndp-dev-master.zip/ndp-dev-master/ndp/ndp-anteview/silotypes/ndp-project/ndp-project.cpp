
#include "ndp-project.h"

#include "ndp-application.h"

#include "data/ndp-data-manager.h"


USING_RZNS(NDP)

//NDP_Project::NDP_Project(NDP_Data_Manager* mgr, QDate date, QString description)
//  : mgr_(mgr), date_(date),
//  description_(description)
//{

//}

NDP_Project::NDP_Project(NDP_Data_Manager* mgr)
 : NDP_Project_Record(mgr)
{

}

void NDP_Project::absorb_record(const NDP_Project_Record& rhs)
{
 this->NDP_Project_Record::operator =(rhs);
}

