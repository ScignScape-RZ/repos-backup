
#ifndef NDP_PROJECT__H
#define NDP_PROJECT__H


#include <QString>
#include <QMainWindow>
#include <QUrl>

#include <functional>

#include <QList>

#include <QDate>

#include "ndp-project-record.h"

#include "accessors.h"

#include "flags.h"


#include "rzns.h"

RZNS_(NDP)
//namespace RZ{ namespace CLG{


class NDP_Data_Manager;

class NDP_Project : public NDP_Project_Record
{

public:

 NDP_Project(NDP_Data_Manager* mgr = nullptr);

 void absorb_record(const NDP_Project_Record& rhs);

};

_RZNS(NDP)

#endif
