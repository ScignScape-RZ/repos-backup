
#include "ndp-socket-listener.h"

#include <QMessageBox>

#include <QTcpSocket>

#include "ndp-application.h"

#include "rzns.h"

USING_RZNS(NDP)



NDP_Socket_Listener::NDP_Socket_Listener(NDP_Application* app)
 : app_(app), tcp_server_(nullptr)
{

}

//QTcpServer* tcp_server = new QTcpServer;

//QObject::connect(tcp_server, &QTcpServer::newConnection,
// [tcp_server, NDPa]
//{
// QTcpSocket* clientConnection = tcp_server->nextPendingConnection();
// QObject::connect(clientConnection, &QTcpSocket::readyRead, [clientConnection, NDPa]
// {
//  qDebug() << "sending response...";
//  QByteArray received = clientConnection->readAll();
//  QString r = QString::fromLatin1(received);

//  qDebug() << r;

//  //?
//  //? check_start_application(NDPa);

//   QMessageBox* qmb = new QMessageBox;

//   qmb->show();

//  //QMessageBox::information(nullptr, "REC:", r);

//  //app_->received_socket_message(r);

//  int statusCode = 200;

//  QString statusText = "OK";

//  QByteArray buffer;
//  buffer.append("HTTP/1.1 ");
//  buffer.append(QByteArray::number(statusCode));
//  buffer.append(' ');
//  buffer.append(statusText);
//  buffer.append("\r\n");

//  buffer.append("Access-Control-Allow-Origin");
//  buffer.append(": ");
//  buffer.append("*"); //headers.value(name));
//  buffer.append("\r\n");

//  buffer.append("Content-Length");
//  buffer.append(": ");
//  buffer.append("9"); //headers.value(name));
//  buffer.append("\r\n");

//  buffer.append("\r\n");


//  buffer.append("<b>OK</b>");
//  buffer.append("\r\n");

//  //?QByteArray block =
//  //?  "HTTP/1.1 200 OK\r\n"
//  //?  "<b>OK</b>"
//  //?  "\0"
//  //? ; //"Access-Control-Allow-Origin: *\nOK---ok\n--ok\n";

//  //?block.append(r.toLatin1());
//  clientConnection->write(buffer);
//  clientConnection->disconnectFromHost();
////  QTextStream out(&block, QIODevice::WriteOnly);
////  out << "OK---ok\n--ok\nxxxxxx";

// });
// qDebug() << "Got conn";
//});

//if(!tcp_server->listen(QHostAddress::Any, 9999))
//{
//    qDebug() << "Server could not start";
//}
//else
//{
//    qDebug() << "Server started!";
//}



void NDP_Socket_Listener::listen(quint64 port)
{
 tcp_server_ = new QTcpServer();

 QString waiting_message;

 if (!tcp_server_->listen(QHostAddress::LocalHost, port))
 {
         QMessageBox::critical(nullptr, "Qt Server",
                               QString("Unable to start the server: %1.")
                               .arg(tcp_server_->errorString()));
  }
  else
  {
   waiting_message = QString("Server waiting on\n\nIP: %1\nport: %2\n\n")
    .arg(tcp_server_->serverAddress().toString()).arg(tcp_server_->serverPort());
 }

 QObject::connect(tcp_server_, &QTcpServer::newConnection, [this]
 {
  QTcpSocket* clientConnection = tcp_server_->nextPendingConnection();
  QObject::connect(clientConnection, &QTcpSocket::readyRead, [clientConnection, this]
  {
   qDebug() << "sending response...";
   QByteArray received = clientConnection->readAll();
   QString r = QString::fromLatin1(received);

   //QMessageBox::information(nullptr, "REC:", r);

   app_->received_socket_message(r);

   int statusCode = 200;

   QString statusText = "OK";

   QByteArray buffer;
   buffer.append("HTTP/1.1 ");
   buffer.append(QByteArray::number(statusCode));
   buffer.append(' ');
   buffer.append(statusText);
   buffer.append("\r\n");

   buffer.append("Access-Control-Allow-Origin");
   buffer.append(": ");
   buffer.append("*"); //headers.value(name));
   buffer.append("\r\n");

   buffer.append("Content-Length");
   buffer.append(": ");
   buffer.append("9"); //headers.value(name));
   buffer.append("\r\n");

   buffer.append("\r\n");


   buffer.append("<b>OK</b>");
   buffer.append("\r\n");

   //?QByteArray block =
   //?  "HTTP/1.1 200 OK\r\n"
   //?  "<b>OK</b>"
   //?  "\0"
   //? ; //"Access-Control-Allow-Origin: *\nOK---ok\n--ok\n";

   //?block.append(r.toLatin1());
   clientConnection->write(buffer);
   clientConnection->disconnectFromHost();

  });
  qDebug() << "Got conn";
  //?clientConnection->write(block);
  //?clientConnection->disconnectFromHost();

  //?clientConnection->deleteLater();
  //?QMessageBox::information(nullptr, "OK", QString("Message received"));
 });

 qDebug() << waiting_message;

// while(true)
// {

// }
//? QMessageBox::information(nullptr, "OK", waiting_message);


}
