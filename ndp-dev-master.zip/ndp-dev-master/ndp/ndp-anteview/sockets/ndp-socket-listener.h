
#ifndef NDP_SOCKET_LISTENER__H
#define NDP_SOCKET_LISTENER__H

#include <QtGlobal>

#include <QTcpServer>

#include "rzns.h"


RZNS_(NDP)

class NDP_Application;


class NDP_Socket_Listener
{
 NDP_Application* app_;
 QTcpServer* tcp_server_;

public:

 NDP_Socket_Listener(NDP_Application* app);

 void listen(quint64 port);


};

_RZNS(NDP)

#endif
