
#include "ndp-gecode-clasp-bridge.h"

#include "rz-qclasp-each/rz-qclasp-callback.h"
#include "rz-qclasp-each/rz-qclasp-each.h"

#include <boost/phoenix/core.hpp>


extern void* get_clasp_host_data();

using boost::phoenix::val;
using boost::phoenix::ref;


#include <QtEndian>

#include <QtGlobal>
#include <QtCore>
//#include <qtendian.h>

#include <QDebug>

//#include <QNetworkRequest>
//#include <QNetworkReply>

USING_RZNS(RZClasp)



NDP_Gecode_Clasp_Bridge::NDP_Gecode_Clasp_Bridge(const NDP_Gecode_Clasp_Bridge& rhs)
 //?: folder_resource_(rhs.folder_resource_)
 : current_graph_build_(rhs.current_graph_build_),
   current_tgn_(rhs.current_tgn_),
   current_sgn_(rhs.current_sgn_),
   carried_discount_(rhs.carried_discount_)
{
}

NDP_Gecode_Clasp_Bridge::NDP_Gecode_Clasp_Bridge()
 //?: folder_resource_(nullptr)
{
 //
 void* hd = get_clasp_host_data();
 void** pvs = (void**) hd;

 //NL_Gecode_Process_Graph_Build** _gb = (NL_Gecode_Process_Graph_Build**) pvs;
 current_graph_build_ = (NL_Gecode_Process_Graph_Build*) pvs[0];
 current_tgn_ = (NL_Gecode_Process_Graph_Node*) pvs[1];
 current_sgn_ = (NL_Gecode_Process_Graph_Node*) pvs[2];
 carried_discount_ = (qreal*) pvs[3];

// current_tgn_.set_direct_value((size_t) pvs[1] );
// current_sgn_.set_direct_value((size_t) pvs[2] );
 //current_sgn_ = reinterpret_cast<caon_ptr<NL_Gecode_Process_Graph_Node>>( (size_t) pvs[2] );
 //current_sgn_ = pvs[2];

}


QString NDP_Gecode_Clasp_Bridge::test()
{
 return QString("Test: %1").arg(current_graph_build_->discounts_total());
}


int NDP_Gecode_Clasp_Bridge::current_target_word_offset()
{
 if(caon_ptr<NL_Gecode_Process_Node_Target> tnt = current_tgn_->nl_node_target())
 {
  return tnt->word_offset();
 }
 return 0;
}

int NDP_Gecode_Clasp_Bridge::current_target_lambda_position()
{
 if(caon_ptr<NL_Gecode_Process_Node_Target> tnt = current_tgn_->nl_node_target())
 {
  return tnt->lambda_position();
 }
 return 0;
}

int NDP_Gecode_Clasp_Bridge::current_target_rewind_level()
{
 if(caon_ptr<NL_Gecode_Process_Node_Target> tnt = current_tgn_->nl_node_target())
 {
  return tnt->rewind_level();
 }
 return 0;
}



int NDP_Gecode_Clasp_Bridge::current_source_word_offset()
{
 if(caon_ptr<NL_Gecode_Process_Node_Target> snt = current_sgn_->nl_node_target())
 {
  return snt->word_offset();
 }
 return 0;
}

int NDP_Gecode_Clasp_Bridge::current_source_lambda_position()
{
 if(caon_ptr<NL_Gecode_Process_Node_Target> snt = current_sgn_->nl_node_target())
 {
  return snt->lambda_position();
 }
 return 0;
}

int NDP_Gecode_Clasp_Bridge::current_source_rewind_level()
{
 if(caon_ptr<NL_Gecode_Process_Node_Target> snt = current_sgn_->nl_node_target())
 {
  return snt->rewind_level();
 }
 return 0;
}


void NDP_Gecode_Clasp_Bridge::abandon_current_graph(QString explanation)
{
 current_graph_build_->abandon( val(explanation) ); //QString("Noun Before Article")) );

 //?qDebug() << "Abandoning: " << explanation;

}

void NDP_Gecode_Clasp_Bridge::set_current_carried_discount(qreal cd)
{
 *carried_discount_ = cd;
}


void NDP_Gecode_Clasp_Bridge::carry_confirm_join(QString join_relation)
{
 confirm_join_with_discount(join_relation, *carried_discount_);
// if(join_relation.startsWith(':'))
//  join_relation = join_relation.mid(1);

// join_relation = join_relation.toLower();

// current_graph_build_->contravein_join(join_relation, current_tgn_,
//    current_sgn_, *carried_discount_);
}

void NDP_Gecode_Clasp_Bridge::confirm_join_with_discount(QString join_relation, qreal discount)
{
 if(join_relation.startsWith(':'))
  join_relation = join_relation.mid(1);

 join_relation = join_relation.toLower();

 current_graph_build_->contravein_join(join_relation, current_tgn_,
    current_sgn_, discount);
}

void NDP_Gecode_Clasp_Bridge::confirm_join(QString join_relation)
{
 confirm_join_with_discount(join_relation, 0);
}




qreal NDP_Gecode_Clasp_Bridge::test1()
{

// CAON_PTR_DEBUG(NL_Gecode_Process_Graph_Node ,current_tgn_)
// CAON_PTR_DEBUG(NL_Gecode_Process_Graph_Node ,current_sgn_)

   if(caon_ptr<NL_Gecode_Process_Node_Target> tnt = current_tgn_->nl_node_target())
   {
    CAON_PTR_DEBUG(NL_Gecode_Process_Node_Target ,tnt)
    NL_Gecode_Process_Node& tpn = tnt->process_node();

    qDebug() << "!!: " << tpn.summary();

    caon_ptr<NL_Gecode_Process_Node_Target> snt = current_sgn_->nl_node_target();
    NL_Gecode_Process_Node& spn = snt->process_node();

    CAON_PTR_DEBUG(NL_Gecode_Process_Node_Target ,snt)

    qDebug() << "!!: " << spn.summary();

    qDebug() << "___";
   }

 return current_graph_build_->discounts_total();
}
