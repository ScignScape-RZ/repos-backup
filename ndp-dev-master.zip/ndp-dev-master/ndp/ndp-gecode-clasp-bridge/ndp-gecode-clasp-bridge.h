
#ifndef NDP_GECODE_CLASP_BRIDGE__H
#define NDP_GECODE_CLASP_BRIDGE__H

#include <QObject>
#include <QDateTime>

#include <QSharedPointer>


#include "process-graph/nl-gecode-process-node.h"
#include "process-graph/kernel/graph/nl-gecode-process-graph-node.h"
#include "process-graph/nl-gecode-process-graph.h"
#include "process-graph/kernel/graph/nl-gecode-process-node-target.h"

#include "process-graph/kernel/grammar/nl-gecode-process-graph-build.h"

#include "process-graph/nl-gecode-contravein-connector-callback.h"



#include "rzns.h"

#include "accessors.h"

RZNS_CLASS_DECLARE(RZClasp ,RZ_QClasp_Each)
RZNS_CLASS_DECLARE(RZClasp ,RZ_QClasp_Callback)
//RZNS_CLASS_DECLARE(RZSite ,PTN_Folder_Resource)

RZNS_CLASS_DECLARE(NLG ,NL_Gecode_Process_Graph_Build)
RZNS_CLASS_DECLARE(NLG ,NL_Gecode_Process_Graph_Node)


USING_RZNS(RZClasp)
USING_RZNS(NLG)

//USING_RZNS(RZSite)


class NDP_Gecode_Clasp_Bridge : public QObject
{
 Q_OBJECT

 //QSharedPointer<PTN_Folder_Resource> folder_resource_;

 NL_Gecode_Process_Graph_Build* current_graph_build_;

 caon_ptr<NL_Gecode_Process_Graph_Node> current_tgn_;
 caon_ptr<NL_Gecode_Process_Graph_Node> current_sgn_;

 qreal* carried_discount_;

// NL_Gecode_Process_Graph_Node* current_tgn_;
// NL_Gecode_Process_Graph_Node* current_sgn_;

public:

 NDP_Gecode_Clasp_Bridge();
 //NDP_Gecode_Clasp_Bridge(QSharedPointer<PTN_Folder_Resource> folder_resource);
 NDP_Gecode_Clasp_Bridge(const NDP_Gecode_Clasp_Bridge& rhs);


 Q_INVOKABLE QString test();
 Q_INVOKABLE qreal test1();

 Q_INVOKABLE int current_target_word_offset();
 Q_INVOKABLE int current_target_lambda_position();
 Q_INVOKABLE int current_target_rewind_level();

 Q_INVOKABLE int current_source_word_offset();
 Q_INVOKABLE int current_source_lambda_position();
 Q_INVOKABLE int current_source_rewind_level();

 Q_INVOKABLE void abandon_current_graph(QString explanation);

 Q_INVOKABLE void set_current_carried_discount(qreal cd);

 Q_INVOKABLE void carry_confirm_join(QString join_relation);

 Q_INVOKABLE void confirm_join_with_discount(QString join_relation, qreal discount);
 Q_INVOKABLE void confirm_join(QString join_relation);

// Q_INVOKABLE QString folder_name();
// Q_INVOKABLE QString complete_local_path();
// Q_INVOKABLE void each(RZ_QClasp_Each* ecb);
// Q_INVOKABLE void each_file(RZ_QClasp_Callback* cb);
// Q_INVOKABLE void each_folder(RZ_QClasp_Callback* cb);
// Q_INVOKABLE QString compare_info(PTN_Site_Manager_File_Bridge* fib);


};

Q_DECLARE_METATYPE(NDP_Gecode_Clasp_Bridge)
Q_DECLARE_METATYPE(NDP_Gecode_Clasp_Bridge*)


#endif
