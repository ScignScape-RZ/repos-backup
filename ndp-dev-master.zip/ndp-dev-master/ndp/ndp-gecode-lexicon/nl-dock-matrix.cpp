
#include "nl-dock-matrix.h"

#include <QDebug>
#include <QVector>

#include "sexpresso.hpp"

#include "process-graph/nl-gecode-process-graph.h"
#include "process-graph/kernel/grammar/nl-gecode-process-graph-build.h"


USING_RZNS(NLG)


QString Dock_Node_Pair_Map_inspect(const QMap<NL_Gecode_Dock_Node_Pair, int>& dnpm)
{
 QString summary;

 QMapIterator<NL_Gecode_Dock_Node_Pair, int> it(dnpm);
 while(it.hasNext())
 {
  it.next();
  const NL_Gecode_Dock_Node_Pair& dnp = it.key();
  summary += QString("\n Count %1 for map: ").arg(it.value());
  summary += "\n  " + dnp.to_string() + "\n--------\n";
 }
 return summary;
}

QString NL_Gecode_Dock_Node_Pair_Vector::inspect() const
{
 QString summary;
 for(const NL_Gecode_Dock_Node_Pair& dnp: pairs)
 {
  summary += dnp.to_string();
  summary += "   ";
 }
 return summary;

}

NL_Gecode_Dock_Node_Pair_Vector::NL_Gecode_Dock_Node_Pair_Vector(int size)
{
 pairs.resize(size);
}

void NL_Gecode_Dock_Node_Pair_Vector::prepare_docks(
  NL_Gecode_Dock_Node& root_node,
  QMap<NL_Gecode_Dock_Node, NL_Gecode_Dock_Node_Pair>& index,
  QMap<NL_Gecode_Dock_Node, NL_Dock_Matrix>& docks) const
{
 int root_node_index = -1;
 //QVector<NL_Gecode_Dock_Node*> lp = QVector<NL_Gecode_Dock_Node>::fromList(lpc.linkpairs());

 QMap<int, NL_Gecode_Dock_Node> nodes_by_word_position;

 for(int i = 0; i < pairs.length(); ++i)
 {
  const NL_Gecode_Dock_Node_Pair& dnp = pairs[i];
  NL_Gecode_Dock_Node sn = dnp.source_node();

  if(root_node_index == -1)
  {
   if(target_count_by_word_position_[sn.word_position()] == 0)
   {
    root_node_index = i;
    root_node = sn;
   }

//   if(sn.in_degree() == 0)
//   {
//    root_node_index = i;
//    root_node = sn;
//   }
  }

   // // defaults here?
//   if(i == pairs.length() - 1)
//   {
//    root_node_index = i;
//    root_node = sn;
//   }
//?
//   else
//   {
//    int match = i;
//    for(int j = i + 1; j < pairs.length(); ++j)
//    {
//     const NL_Gecode_Dock_Node_Pair& jdnp = pairs[j];
//     NL_Gecode_Dock_Node jtn = jdnp.target_node();
//     if(jtn.word_position() == sn.word_position())
//     {
//      match = j;
//      break;
//     }
//    }
//    // no match found
//    if(match == i)
//    {
//     root_node_index = i;
//     root_node = sn;
//    }
//   }
//  }

  int wp = sn.word_position();
  NL_Gecode_Dock_Node first_sn;

  if(nodes_by_word_position.contains(wp))
  {
   first_sn = nodes_by_word_position[wp];
  }
  else
  {
   first_sn = sn;
   nodes_by_word_position[wp] = sn;
  }

  //?NL_Gecode_Dock_Node tn = dnp.target_node();

  if(!docks.contains(first_sn))
  {
   index[first_sn] = dnp;

     //! not first
   NL_Gecode_Lexclass* nlc = first_sn.lexentry()->lexclasses().value(first_sn.interpretation(), nullptr);
   if(nlc)
   {
    int expected_lambda_depth = nlc->expected_lambda_depth();
    docks.insert(first_sn, expected_lambda_depth);
    for(int i = 0; i < expected_lambda_depth; ++i)
    {
     docks[first_sn].resize(i, nlc->arity(i));
    }
   }
  }

//?
//  int rl = dnp.source_node().rewind_level();
//  int lp = dnp.target_node().lambda_position();

  int rl; //= sn.rewind_level();
  int lp; //= sn.lambda_position();

  sn.get_rewind_level_and_lambda_position(rl, lp);

  //?
  if(rl == -1)
   rl = 0;

  if(lp == -1)
   lp = 0;



  docks[first_sn].place_link_pair(rl, lp, dnp);

//  NL_Node* sn = pr->source_node();
//  NL_Node* tn = pr->target_node();

 }

}

void NL_Gecode_Dock_Node_Pair_Vector::insert_pair(const NL_Gecode_Dock_Node_Pair& pr, int pos)
{
 // //  pos_index compared to pos reflects nodes which do not become
  //    source because they are part of a rewind
 int pos_index = pr.source_node().source_node_list_position_index();

 pairs[pos] = pr;
// int i = 0;
// for(const Dock_Node_Pair& old_pr: pairs)
// {
//  if(old_pr < pr)
//  {
//   pairs.insert(i + 1, pr);
//   return;
//  }
//  ++i;
// }
// pairs.insert(i, pr);
}


NL_Dock_Matrix::NL_Dock_Matrix(int rewind_depth)
{
 matrix_.resize(rewind_depth);
}

void NL_Dock_Matrix::resize(int rewind, int size)
{
 matrix_[rewind].resize(size);
}

void NL_Dock_Matrix::place_link_pair(int rewind, int lambda_position, NL_Gecode_Dock_Node_Pair dnp)
{
 matrix_[rewind][lambda_position] = dnp;
}

NL_Gecode_Dock_Node NL_Dock_Matrix::node_at(int rewind, int lambda_position) const
{
 return matrix_[rewind][lambda_position].source_node();
}

NL_Gecode_Dock_Node_Pair NL_Dock_Matrix::pair_at(int rewind, int lambda_position) const
{
 return matrix_[rewind][lambda_position];
}

int NL_Dock_Matrix::rewind_depth() const
{
 return matrix_.size();
}

int NL_Dock_Matrix::arity_at_rewind(int rewind) const
{
 return matrix_[rewind].size();
}

//void NL_Gecode_Dock_Node_Pair_Vector::prepare_docks(QMap<NL_Gecode_Dock_Node, const NL_Decode_Dock_Node_Pair*>& index, QMap<NL_Gecode_Dock_Node, NL_Dock_Matrix>& docks)
//{

//}

//QString NL_Gecode_Dock_Node_Pair_Vector::show_s_expression_from_node(sexpresso::Sexp& sxp, NL_Gecode_Dock_Node& start_node, QString& result_string,
//  QMap<NL_Gecode_Dock_Node, NL_Gecode_Dock_Node_Pair>& index,
//  QMap<NL_Gecode_Dock_Node, NL_Dock_Matrix>& docks) const
//{

//}

QString NL_Gecode_Dock_Node_Pair_Vector::show_s_expression_from_node(sexpresso::Sexp& sxp, NL_Gecode_Dock_Node& start_node, QString& result_string,
  QMap<NL_Gecode_Dock_Node, NL_Gecode_Dock_Node_Pair>& index,
  QMap<NL_Gecode_Dock_Node, NL_Dock_Matrix>& docks,
  int& start_nodes_count,
  NL_Gecode_Process_Graph_Build& gb,
  NL_Gecode_Dock_Node& prior_source_node,
  caon_ptr<NL_Gecode_Process_Graph_Node> prior_source_graph_node) const
{
 ++start_nodes_count;

 sexpresso::Sexp sxp1;

 QString result;
  //NL_Gecode_Dock_Node_Pair result = nullptr;
 const NL_Dock_Matrix& dm = docks[start_node];

 int rewind_depth = dm.rewind_depth();

 result_string += QString(rewind_depth, '(');

 sexpresso::Sexp local_sxp;

 QString s4;

 caon_ptr<NL_Gecode_Process_Graph_Node> source_graph_node;


 for(int i = 0; i < rewind_depth; ++i)
 {
  for(int j = 0; j < dm.arity_at_rewind(i); ++j)
  {
   NL_Gecode_Dock_Node_Pair dnp = dm.pair_at(i, j);
   NL_Gecode_Lexclass* slc = dnp.source_lexclass();

   QString summary = dnp.summary();

   qDebug() << "SUMMARY: " << summary;

   if(summary == "runs => the")
   {
    qDebug() << "SUMMARY: " << summary;
   }

   if(!slc)
   {
    // // a pair not completed due to rewinds ...
    return QString();
   }
   if( (j == 0)  &&  (i == 0) )
   {
    int rl;
    int lp;

    //?dnp.source_node().get_rewind_level_and_lambda_position(rl, lp);
    prior_source_node.get_rewind_level_and_lambda_position(rl, lp);

    int prior_source_word_position = prior_source_node.word_position();

    int wo = dnp.source_word_position() - prior_source_word_position;

    source_graph_node = gb.register_dock_node_entry(dnp.source_node(), wo, rl, lp);

    if(prior_source_graph_node)
    {
     gb.check_contravein_callback(source_graph_node, prior_source_graph_node);
    }

    CAON_PTR_DEBUG(NL_Gecode_Process_Graph_Node ,source_graph_node)

    //?result_string += QString("npc :%1 '%2 ").arg(slc->label())
    result_string += QString("%2 :%1 ").arg(slc->label())
      .arg(dnp.source_node().raw_text());

    //sxp1 = sexpresso::Sexp(slc->label().toStdString());

    local_sxp = sexpresso::Sexp(dnp.source_node().raw_text().toStdString());

    local_sxp.addChild(slc->label().prepend(':').toStdString());
   }
   else if( (j == 0)  && (i > 0) )  //?if(i > 0)
   {
    sexpresso::Sexp copy_local_sxp = local_sxp;
    local_sxp = sexpresso::Sexp();
//    sexpresso::Sexp nested_sxp = sexpresso::Sexp();
//    nested_sxp.addChild(copy_local_sxp);
    local_sxp.addChild(copy_local_sxp);
    QString s3 = QString::fromStdString(local_sxp.toString());

    s4 = QString::fromStdString(copy_local_sxp.toString());

   }
   NL_Gecode_Dock_Node tn = dnp.target_node();
   if(index.contains(tn))
   {
    //g->absorb_dock_node_pair_rce(dnp);


    NL_Gecode_Dock_Node_Pair itdnp = index.value(tn);
    //NL_Gecode_Dock_Node_Pair itdnp = index.value(tn);
    // if(itlp)

    NL_Gecode_Dock_Node sn1 = itdnp.source_node();

    NL_Gecode_Dock_Node sn = dnp.source_node();



    //gb.check_contravein_callback(tgn, source_graph_node);

    sexpresso::Sexp sxp1;

    //?const NL_Link_Pair* r = show_s_expression_from_node(itdnp.source_node(), result_string, index, docks);
    QString r = show_s_expression_from_node(sxp1, sn1, result_string, index, docks,
      start_nodes_count, gb,
       sn,                   //?tn
      source_graph_node);

    local_sxp.addChild(sxp1);
    //?if(r)
    //? result = r;
   }
   else
   {
    int rl;
    int lp;
    //?tn.get_rewind_level_and_lambda_position(rl, lp);
    dnp.source_node().get_rewind_level_and_lambda_position(rl, lp);
    int wo = dnp.pair_word_offset();
    caon_ptr<NL_Gecode_Process_Graph_Node> tgn =
      gb.absorb_dock_node_pair_rcs(dnp, wo, rl, lp);

    CAON_PTR_DEBUG(NL_Gecode_Process_Graph_Node ,source_graph_node)

    gb.check_contravein_callback(tgn, source_graph_node);

    NL_Gecode_Lexclass* tlc = dnp.target_lexclass();
    result_string += QString("%2 :%1 ").arg(tlc->label())
    //? result_string += QString("npc :%1 '%2 ").arg(tlc->label())
      .arg(tn.raw_text());

    local_sxp.addChild(dnp.target_node().raw_text().toStdString());

    local_sxp.addChild(tlc->label().prepend(':').toStdString());
   }
  }
  result_string += ") ";
 }
 //result_string;

 gb.rewind_chiefs();

 sxp1 = sexpresso::parse(result_string.toStdString());

 QString s1 = QString::fromStdString(sxp1.toString());

 QString s2 = QString::fromStdString(local_sxp.toString());

  //? sxp.addChild(local_sxp);

 sxp = local_sxp;

 result = QString::fromStdString(sxp.toString());
 return result_string;
}


//? QList<NL_Gecode_Process_Graph*>& graphs
QString NL_Gecode_Dock_Node_Pair_Vector::show_s_expression(sexpresso::Sexp& sxp, NL_Gecode_Process_Graph_Build& gb) const
{
 NL_Gecode_Dock_Node root_node;

 QMap<NL_Gecode_Dock_Node, NL_Gecode_Dock_Node_Pair> index;
 QMap<NL_Gecode_Dock_Node, NL_Dock_Matrix> docks;
 prepare_docks(root_node, index, docks);

 QString result;

 QString result_string;

 int start_nodes_count = 0;

 //NL_Gecode_Process_Graph* g = new NL_Gecode_Process_Graph;

 show_s_expression_from_node(sxp, root_node, result_string, index, docks,
   start_nodes_count, gb, root_node, nullptr);

 if(start_nodes_count == docks.size())
 {
  gb.finalize_discounts();

   //?
  result = QString::fromStdString(sxp.toString());

  if(!result.isEmpty())
  {
   //?graphs.push_back(g);
    //result = result_string;
    result.prepend('(');
    result.append(')');
  }
 }
// else
// {
//  //?
//  delete g;
// }
 return result;



}


void NL_Gecode_Dock_Node_Pair_Vector_Collection::insert_vector(const NL_Gecode_Dock_Node_Pair_Vector& dnpv)
{
 ++vector_map[dnpv];

// vector_list.push_back(dnpv);
// ++string_map[dnpv.inspect()];

// if(vector_map.contains(dnpv))
// {
//  qDebug() << "HERE: " << dnpv.inspect();
// }
// else
// {
//  vector_map.insert(dnpv, 1);
// }
}

void NL_Gecode_Dock_Node_Pair_Vector_Collection::show_s_expressions(QStringList& result,
  QList<NL_Gecode_Process_Graph*>& graphs, NL_Gecode_Lexicon& nll, NL_Gecode_Contravein_Connector_Callback& contravein) const
{
 QMapIterator<NL_Gecode_Dock_Node_Pair_Vector, int> it(vector_map);
 while(it.hasNext())
 {
  it.next();
  NL_Gecode_Process_Graph* g = new NL_Gecode_Process_Graph;
  NL_Gecode_Process_Graph_Build gb(*g, nll, contravein);
  sexpresso::Sexp sxp;
  QString exp = it.key().show_s_expression(sxp, gb);


  qDebug() << "EXP: " << exp;
  qDebug() << g->to_sexp_string();

  if(!exp.isEmpty())
  {
   result.push_back(exp);
   graphs.push_back(g);
  }
  else
  {
   //?
   delete g;
  }
 }
}


QString NL_Gecode_Dock_Node_Pair_Vector_Collection::inspect() const
{
 QString summary;
 QMapIterator<NL_Gecode_Dock_Node_Pair_Vector, int> it(vector_map);
 while(it.hasNext())
 {
  it.next();
  summary += QString("Count: %1 \n").arg(it.value());
  summary += "\n" + it.key().inspect();
  summary += "\n=====\n";
 }
 summary += "\n/////\n";

// for(const Dock_Node_Pair_Vector& dnpv : vector_list)
// {
//  summary += "\n" + dnpv.inspect();
//  summary += "\n++++\n";
// }

// summary += "\n/////\n";
// QMapIterator<QString, int> it1(string_map);
// while(it1.hasNext())
// {
//  it1.next();
//  summary += QString("Count: %1 \n").arg(it1.value());
//  summary += "\n" + it1.key();
//  summary += "\n~~~\n";
// }


 return summary;
}

//QString Dock_Node_Pair_Map_Set::inspect()
//{
// QString summary;
// QMapIterator< QMap<Dock_Node_Pair, int>, int> it(the_val);
// while(it.hasNext())
// {
//  it.next();
//  const QMap<Dock_Node_Pair, int>& key = it.key();
//  int value = it.value();

//  summary += QString("\nCount %1 for map: ").arg(value);

//  QMapIterator<Dock_Node_Pair, int> it1(key);
//  while(it1.hasNext())
//  {
//   it1.next();
//   const Dock_Node_Pair& dnp = it1.key();
//   summary += QString("\n Count %1 for map: ").arg(it1.value());
//   summary += "\n  " + dnp.to_string() + "\n--------\n";
//  }
//  summary += "\n========\n";
// }
// return summary;
//}


QString NL_Gecode_Dock_Node_Pair_Map_Set_inspect(const QMap< QMap<NL_Gecode_Dock_Node_Pair, int>, int>& dnpms)
{
 QString summary;
 QMapIterator< QMap<NL_Gecode_Dock_Node_Pair, int>, int> it(dnpms);
 while(it.hasNext())
 {
  it.next();
  const QMap<NL_Gecode_Dock_Node_Pair, int>& key = it.key();
  int value = it.value();

  summary += QString("\nCount %1 for map: ").arg(value);

  QMapIterator<NL_Gecode_Dock_Node_Pair, int> it1(key);
  while(it1.hasNext())
  {
   it1.next();
   const NL_Gecode_Dock_Node_Pair& dnp = it1.key();
   summary += QString("\n Count %1 for map: ").arg(it1.value());
   summary += "\n  " + dnp.to_string() + "\n--------\n";
  }
  summary += "\n========\n";
 }
 return summary;
}

RZNS_(NLG)

bool Dock_Node_Pair_Vector_compare(const NL_Gecode_Dock_Node_Pair_Vector& lhs, const NL_Gecode_Dock_Node_Pair_Vector& rhs, int& diverge_position)
{
 diverge_position = 0;
 // returns true if lhs < rhs.
 // if returns false and diverge_position == 0 they're equal

 for(int i = 0; i < lhs.pairs.size(); ++i)
 {
  const NL_Gecode_Dock_Node_Pair& ldnp = lhs.pairs[i];
  const NL_Gecode_Dock_Node_Pair& rdnp = rhs.pairs[i];
  if(ldnp > rdnp)
  {
   diverge_position = i + 1;
   return false;
  }
  if(ldnp < rdnp)
  {
   //?if(diverge_position == 0)
   diverge_position = i + 1;
   return true;
  }
 }
 //diverge_position = 0;
 return false;
 // return(diverge_position != 0);
}

bool operator<(const NL_Gecode_Dock_Node_Pair_Vector& lhs, const NL_Gecode_Dock_Node_Pair_Vector& rhs)
{
 int diverge_position;
 return Dock_Node_Pair_Vector_compare(lhs, rhs, diverge_position);
}

bool operator==(const NL_Gecode_Dock_Node_Pair_Vector& lhs, const NL_Gecode_Dock_Node_Pair_Vector& rhs)
{
 int diverge_position;
 if(Dock_Node_Pair_Vector_compare(lhs, rhs, diverge_position))
 {
  return false;
 }
 return diverge_position == 0;
}

bool operator>(const NL_Gecode_Dock_Node_Pair_Vector& lhs, const NL_Gecode_Dock_Node_Pair_Vector& rhs)
{
 int diverge_position;
 if(Dock_Node_Pair_Vector_compare(lhs, rhs, diverge_position))
 {
  return false;
 }
 return diverge_position > 0;
}


bool Dock_Node_Pair_Map_compare(const QMap<NL_Gecode_Dock_Node_Pair, int>& lhs,
               const QMap<NL_Gecode_Dock_Node_Pair, int>& rhs, int& less_count)
{
 // returns true if they are equal.
 // if less_count > 0 lhs < rhs
 // if less_count == 0 and returns false, rhs > lhs
 less_count = 0;
 if(lhs.size() < rhs.size())
 {
  less_count = rhs.size() - lhs.size();
  return false;
 }
 int temp_less_count = 0;
 QMapIterator<NL_Gecode_Dock_Node_Pair, int> itl(lhs);
 QMapIterator<NL_Gecode_Dock_Node_Pair, int> itr(rhs);
 while(itl.hasNext())
 {
  itl.next();
  itr.next();
  if(itl.key() > itr.key())
   return false;
  if(itl.key() == itr.key())
  {
   if(itl.value() > itr.value())
    return false;
   if(itl.value() < itr.value())
    ++temp_less_count;
  }
  else
  {
   ++temp_less_count;
  }
 }
 if(temp_less_count == 0)
  return true;
 less_count = temp_less_count;
 return false;
}

bool operator<(const QMap<NL_Gecode_Dock_Node_Pair, int>& lhs,
               const QMap<NL_Gecode_Dock_Node_Pair, int>& rhs)
{
 int less_count; // initialized by Dock_Node_Pair_Map_compare
 if(Dock_Node_Pair_Map_compare(lhs, rhs, less_count))
 {
  // they're equal
  return false;
 }
 return less_count > 0;
}

bool operator>(const QMap<NL_Gecode_Dock_Node_Pair, int>& lhs,
               const QMap<NL_Gecode_Dock_Node_Pair, int>& rhs)
{
 int less_count; // initialized by Dock_Node_Pair_Map_compare
 if(Dock_Node_Pair_Map_compare(lhs, rhs, less_count))
 {
  // they're equal
  return false;
 }
 return less_count == 0;
}


_RZNS(NLG)


//?
//bool operator==(const QMap<Dock_Node_Pair, int>& lhs,
//               const QMap<Dock_Node_Pair, int>& rhs)
//{
// int less_count; // initialized by Dock_Node_Pair_Map_compare
// if(Dock_Node_Pair_Map_compare(lhs, rhs, less_count))
// {
//  // they're equal
//  return true;
// }
// return false;
//}


//NL_Dock_Matrix::NL_Dock_Matrix(int rewind_depth)
//{
// matrix_.resize(rewind_depth);
//}

//void NL_Dock_Matrix::resize(int rewind, int size)
//{
// matrix_[rewind].resize(size);
//}

//void NL_Dock_Matrix::place_link_pair(int rewind, int lambda_position, const NL_Link_Pair* lp)
//{
// matrix_[rewind][lambda_position] = lp;
//}

//int NL_Dock_Matrix::arity_at_rewind(int rewind) const
//{
// return matrix_[rewind].size();
//}

//NL_Node* NL_Dock_Matrix::node_at(int rewind, int lambda_position) const
//{
// return matrix_[rewind][lambda_position]->source_node();
//}

//const NL_Link_Pair* NL_Dock_Matrix::pair_at(int rewind, int lambda_position) const
//{
// return matrix_[rewind][lambda_position];
//}

//int NL_Dock_Matrix::rewind_depth() const
//{
// return matrix_.size();
//}



