
#ifndef NL_DOCK_MATRIX__H
#define NL_DOCK_MATRIX__H

#include <gecode/driver.hh>
#include <gecode/int.hh>
#include <gecode/minimodel.hh>


using namespace Gecode;

#include "rz-relae/relae-node-ptr.h"
#include "rz-relae/relae-caon-ptr.h"

#include <vector>
#include <QString>
#include <QSet>
#include <QMap>
#include <QDebug>

#include "nl-gecode-dock-node-pair.h"
#include "nl-gecode-dock-node.h"

#include "rzns.h"

namespace sexpresso  {
 struct Sexp;
}

RZNS_(NLG)

//enum class Lex_Classes
//{
// Noun, Verb, Adj, Prop
//};

class NL_Gecode_Process_Graph;
class NL_Gecode_Process_Graph_Node;
class NL_Gecode_Process_Graph_Build;
class NL_Gecode_Contravein_Connector_Callback;


class NL_Dock_Matrix
{
 QVector< QVector<NL_Gecode_Dock_Node_Pair> > matrix_;

public:

 NL_Dock_Matrix(int rewind_depth = 1);

 void resize(int rewind, int size);
 void place_link_pair(int rewind, int lambda_position, NL_Gecode_Dock_Node_Pair dnp);
 NL_Gecode_Dock_Node node_at(int rewind, int lambda_position) const;
 NL_Gecode_Dock_Node_Pair pair_at(int rewind, int lambda_position) const;
 int rewind_depth() const;
 int arity_at_rewind(int rewind) const;
};



bool Dock_Node_Pair_Map_compare(const QMap<NL_Gecode_Dock_Node_Pair, int>& lhs,
               const QMap<NL_Gecode_Dock_Node_Pair, int>& rhs, int& less_count);

QString Dock_Node_Pair_Map_inspect(const QMap<NL_Gecode_Dock_Node_Pair, int>& dnpm);

QString Dock_Node_Pair_Map_Set_inspect(const QMap< QMap<NL_Gecode_Dock_Node_Pair, int>, int>& dnpms);


class NL_Gecode_Dock_Node_Pair_Vector
{
public:
 NL_Gecode_Dock_Node_Pair_Vector(int size);
 QVector<NL_Gecode_Dock_Node_Pair> pairs;
 QString inspect() const;

 QMap<int, int> target_count_by_word_position_;

 QString show_s_expression_from_node(sexpresso::Sexp& sxp, NL_Gecode_Dock_Node& start_node, QString& result_string,
   QMap<NL_Gecode_Dock_Node, NL_Gecode_Dock_Node_Pair>& index,
   QMap<NL_Gecode_Dock_Node, NL_Dock_Matrix>& docks,
   int& start_nodes_count,
   NL_Gecode_Process_Graph_Build& gb,
   NL_Gecode_Dock_Node& prior_source_node,
   caon_ptr<NL_Gecode_Process_Graph_Node> prior_source_graph_node) const;

 QString show_s_expression(sexpresso::Sexp& sxp, NL_Gecode_Process_Graph_Build& gb) const;

 void insert_pair(const NL_Gecode_Dock_Node_Pair& pr, int pos);


 void prepare_docks(NL_Gecode_Dock_Node& root_node, QMap<NL_Gecode_Dock_Node, NL_Gecode_Dock_Node_Pair>& index, QMap<NL_Gecode_Dock_Node, NL_Dock_Matrix>& docks) const;


 friend bool operator<(const NL_Gecode_Dock_Node_Pair_Vector& lhs, const NL_Gecode_Dock_Node_Pair_Vector& rhs);
 friend bool operator==(const NL_Gecode_Dock_Node_Pair_Vector& lhs, const NL_Gecode_Dock_Node_Pair_Vector& rhs);
 friend bool operator>(const NL_Gecode_Dock_Node_Pair_Vector& lhs, const NL_Gecode_Dock_Node_Pair_Vector& rhs);

 friend bool Dock_Node_Pair_Vector_compare(const NL_Gecode_Dock_Node_Pair_Vector& lhs, const NL_Gecode_Dock_Node_Pair_Vector& rhs, int& less_position);

};

class NL_Gecode_Dock_Node_Pair_Vector_Collection
{
public:

 //QList<Dock_Node_Pair_Vector> vectors;
 //QSet<Dock_Node_Pair_Vector> vectors;
 //QMap< QMap<Dock_Node_Pair, int>, int> the_val;
 QMap<NL_Gecode_Dock_Node_Pair_Vector, int> vector_map;

// QList<Dock_Node_Pair_Vector> vector_list;
// QMap<QString, int> string_map;

 QString inspect() const;

 void show_s_expressions(QStringList& result, QList<NL_Gecode_Process_Graph*>& graphs,
   NL_Gecode_Lexicon& nll, NL_Gecode_Contravein_Connector_Callback& contravein) const;

 void insert_vector(const NL_Gecode_Dock_Node_Pair_Vector& dnpv);




};

bool operator<(const QMap<NL_Gecode_Dock_Node_Pair, int>& lhs,
               const QMap<NL_Gecode_Dock_Node_Pair, int>& rhs);

bool operator>(const QMap<NL_Gecode_Dock_Node_Pair, int>& lhs,
               const QMap<NL_Gecode_Dock_Node_Pair, int>& rhs);

//bool operator==(const QMap<Dock_Node_Pair, int>& lhs,
//               const QMap<Dock_Node_Pair, int>& rhs);

_RZNS(NLG)

#ifdef HIDE
class Lex_Class
{
public:
 std::vector<int> lambda_channel;
 //IntVarArray lambda_channel;
 //IntVar result;
 int result_channel;
 int index;

 bool operator==(const Lex_Class& rhs)
 {
  return index == rhs.index;
 }

};

//class Word
//{
//};

class NL_Dock_Pair
{
public:
 Lex_Class source_lexclass;
 Lex_Class target_lexclass;
 int source_word;
 int target_word;
};

//class NL_Dock_Matrix
//{
//public:
// QVector< QVector<const NL_Link_Pair*> > matrix_;


// NL_Dock_Matrix(int rewind_depth = 1);

// void resize(int rewind, int size);
// void place_link_pair(int rewind, int lambda_position, const NL_Dock_Pair* lp);
// void* node_at(int rewind, int lambda_position) const;
// const NL_Dock_Pair* pair_at(int rewind, int lambda_position) const;
// int rewind_depth() const;
// int arity_at_rewind(int rewind) const;
//};

#endif


#endif
