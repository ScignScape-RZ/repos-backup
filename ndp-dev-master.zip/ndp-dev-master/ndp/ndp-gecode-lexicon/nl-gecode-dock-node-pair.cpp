
#include "nl-gecode-dock-node-pair.h"

USING_RZNS(NLG)

NL_Gecode_Dock_Node_Pair::NL_Gecode_Dock_Node_Pair(const NL_Gecode_Dock_Node& sn, const NL_Gecode_Dock_Node& tn)
 : source_node_(sn), target_node_(tn)
{
}

NL_Gecode_Lexclass* NL_Gecode_Dock_Node_Pair::target_lexclass()
{
 return target_node_.lexentry()->lexclasses().first();
}

int NL_Gecode_Dock_Node_Pair::pair_word_offset() const
{
 return target_node_.word_position() - source_node_.word_position();
}

int NL_Gecode_Dock_Node_Pair::source_word_position() const
{
 return source_node_.word_position();
}

NL_Gecode_Lexclass* NL_Gecode_Dock_Node_Pair::source_lexclass()
{
 if(source_node_.lexentry())
 {
  return source_node_.lexentry()->lexclasses().first();
 }
 return nullptr;
}


NL_Gecode_Dock_Node_Pair::NL_Gecode_Dock_Node_Pair()
// : source_node{"", 0, 0, 0},
//   target_node{"", 0, 0, 0}
{

}

QString NL_Gecode_Dock_Node_Pair::summary() const
{
 return source_node_.word() + " => " + target_node_.word();
}


QString NL_Gecode_Dock_Node_Pair::to_string() const
{
 return source_node_.to_string() + " => " + target_node_.to_string();
}
