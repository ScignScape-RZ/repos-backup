
#ifndef NL_GECODE_DOCK_NODE_PAIR__H
#define NL_GECODE_DOCK_NODE_PAIR__H

#include "rzns.h"

#include <functional>

#include <QString>

#include <QMap>

#include "accessors.h"

#include "nl-gecode-lexclass.h"

#include "nl-gecode-lexclass-vector.h"

#include "nl-gecode-dock-node.h"

RZNS_(NLG)

class NL_Gecode_Dock_Node_Pair
{
 NL_Gecode_Dock_Node source_node_;
 NL_Gecode_Dock_Node target_node_;

public:

 ACCESSORS(NL_Gecode_Dock_Node ,source_node)
 ACCESSORS(NL_Gecode_Dock_Node ,target_node)

 NL_Gecode_Lexclass* source_lexclass();
 NL_Gecode_Lexclass* target_lexclass();

 NL_Gecode_Dock_Node_Pair(const NL_Gecode_Dock_Node& sn, const NL_Gecode_Dock_Node& tn);

 NL_Gecode_Dock_Node_Pair();

 QString to_string() const;
 QString summary() const;

 int pair_word_offset() const;
 int source_word_position() const;

 friend bool operator<(const NL_Gecode_Dock_Node_Pair& lhs, const NL_Gecode_Dock_Node_Pair& rhs)
 {
  bool result;
  if(lhs.source_node() < rhs.source_node())
   result = true;
  else if(lhs.source_node() > rhs.source_node())
   result = false;
  else if(lhs.target_node() < rhs.target_node())
   result = true;
  else
   result = false;
  //qDebug() << lhs.to_string() << " <:" << (result?"T":"F") << rhs.to_string();
  return result;
 }

 friend bool operator==(const NL_Gecode_Dock_Node_Pair& lhs, const NL_Gecode_Dock_Node_Pair& rhs)
 {
  if(lhs.source_node() == rhs.source_node())
  {
   if(lhs.target_node() == rhs.target_node())
   {
    return true;
   }
  }
  return false;
 }

 friend bool operator>(const NL_Gecode_Dock_Node_Pair& lhs, const NL_Gecode_Dock_Node_Pair& rhs)
 {
  return !( (lhs < rhs) || (lhs == rhs) );
 }


};


_RZNS(NLG)



#endif
