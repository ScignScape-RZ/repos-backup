
#include "nl-gecode-dock-node.h"

USING_RZNS(NLG)

NL_Gecode_Dock_Node::NL_Gecode_Dock_Node(NL_Gecode_Lexentry* lexentry, int word_position, int rewind_level,
           int lambda_position, int source_node_list_position_index,
           int local_source_node_list_position_index
                                         )
 : lexentry_(lexentry), word_position_(word_position),
   rewind_level_(rewind_level), lambda_position_(lambda_position),
   source_node_list_position_index_(source_node_list_position_index),
   local_source_node_list_position_index_(local_source_node_list_position_index),
   interpretation_(-1)
    //?,in_degree_(0) ,composite_in_degree_(0)
{

}

NL_Gecode_Dock_Node::NL_Gecode_Dock_Node()
 : lexentry_(nullptr), word_position_(0),
   rewind_level_(0), lambda_position_(0),
   source_node_list_position_index_(0),
   local_source_node_list_position_index_(0),
   interpretation_(-1)
   //?,in_degree_(0) ,composite_in_degree_(0)
{

}

NL_Gecode_Lexclass* NL_Gecode_Dock_Node::lexclass_contingent_on_interpretation() const
{
 if(interpretation_ == -1)
  return nullptr;
 return lexentry_->lexclasses()[interpretation_];
}


void NL_Gecode_Dock_Node::get_rewind_level_and_lambda_position(int interpretation, int& rl, int& lp) const
{
 NL_Gecode_Lexclass* lc = lexentry_->lexclasses().value(interpretation, nullptr);
 if(lc)
 {
  lc->get_rewind_level_and_lambda_position(
    local_source_node_list_position_index_, rl, lp);
 }
 else
 {
  rl = -1;
  lp = -1;
 }
}

void NL_Gecode_Dock_Node::get_rewind_level_and_lambda_position(int& rl, int& lp) const
{
 if(interpretation_ == -1)
 {
  rl = -1;
  lp = -1;
 }
 else
 {
  get_rewind_level_and_lambda_position(interpretation_, rl, lp);
 }
}

//int NL_Gecode_Dock_Node::rewind_level()
//{
// if(interpretation_ == -1)
//  return -1;
// RZ_NL_Lexclass* lc = lexentry_->lexclasses().value(interpretation_, nullptr);
// if(lc)
// {

// }
// return -1;
//}

//int NL_Gecode_Dock_Node::lambda_position()
//{

//}


//void NL_Gecode_Dock_Node::increase_in_degree() const
//{
// ++in_degree_;
//}

//void NL_Gecode_Dock_Node::increase_composite_in_degree() const
//{
// ++composite_in_degree_;
//}

QString NL_Gecode_Dock_Node::word() const
{
 // // the test may or may not be necessary
 if(lexentry_)
 {
  return lexentry_->lexword();
 }
 return QString();
}

QString NL_Gecode_Dock_Node::raw_text() const
{
 return word();
}


QString NL_Gecode_Dock_Node::to_string() const
{
 //QString s = sum;
 //qDebug() << s;
 QString result = word() + QString(" #%1(%4)<%2>%3")
   .arg(word_position_).arg(rewind_level_)
   .arg(lambda_position_).arg(source_node_list_position_index_);
 return result;
}

