
#ifndef NL_GECODE_DOCK_NODE__H
#define NL_GECODE_DOCK_NODE__H

#include "rzns.h"

#include <functional>

#include <QString>

#include <QMap>

#include "accessors.h"

#include "nl-gecode-lexclass.h"

#include "nl-gecode-lexentry.h"

#include "nl-gecode-lexclass-vector.h"

RZNS_(NLG)

class NL_Gecode_Dock_Node
{
 NL_Gecode_Lexentry* lexentry_;

 int word_position_;
 int rewind_level_;
 int lambda_position_;
 int source_node_list_position_index_;
 int local_source_node_list_position_index_;

 mutable int interpretation_;



// mutable int in_degree_;
// mutable int composite_in_degree_;


public:

 NL_Gecode_Dock_Node(NL_Gecode_Lexentry* lexentry, int word_position, int rewind_level,
           int lambda_position,
           int source_node_list_position_index,
           int local_source_node_list_position_index);

 NL_Gecode_Dock_Node();

 QString to_string() const;
 QString raw_text() const;

 NL_Gecode_Lexclass* lexclass_contingent_on_interpretation() const;

 QString word() const;

 ACCESSORS(NL_Gecode_Lexentry* ,lexentry)
 ACCESSORS(int ,word_position)

// ACCESSORS(int ,rewind_level)
// ACCESSORS(int ,lambda_position)

// int rewind_level();
// int lambda_position();

 void get_rewind_level_and_lambda_position(int interpretation, int& rl, int& lp) const;
 void get_rewind_level_and_lambda_position(int& rl, int& lp) const;


 ACCESSORS(int ,source_node_list_position_index)
 ACCESSORS(int ,local_source_node_list_position_index)

 ACCESSORS__CONST(int ,interpretation)

// ACCESSORS__GET(int ,interpretation)
// ACCESSORS__SET__CONST(int ,interpretation)

//? void set_interpretation(int _arg_) const { interpretation_ = _arg_; }


// ACCESSORS(int ,in_degree)
// ACCESSORS(int ,composite_in_degree)

// void increase_in_degree() const;
// void increase_composite_in_degree() const;

 friend bool operator<(const NL_Gecode_Dock_Node& lhs, const NL_Gecode_Dock_Node& rhs)
 {
  if(lhs.lexentry() == rhs.lexentry())
  {
   if(lhs.word_position() < rhs.word_position())
    return true;
   if(lhs.word_position() > rhs.word_position())
    return false;
   // so word_position are the same

   if(lhs.interpretation() < rhs.interpretation())
    return true;

   if(lhs.interpretation() > rhs.interpretation())
    return false;

   return (lhs.local_source_node_list_position_index() < rhs.local_source_node_list_position_index());

//?
//   if(lhs.rewind_level() < rhs.rewind_level())
//    return false;
//   if(lhs.rewind_level() > rhs.rewind_level())
//    return true;
//   // so rewind_level are the same
//   return lhs.lambda_position() < rhs.lambda_position();

  }
  else
  {
   QString lw = lhs.word();
   QString rw = rhs.word();

   return lw < rw;
  }
 }

 friend bool operator==(const NL_Gecode_Dock_Node& lhs, const NL_Gecode_Dock_Node& rhs)
 {
  //  return lhs.to_string() == rhs.to_string();

  return (rhs.word() == lhs.word()) && (rhs.word_position() == lhs.word_position())
    && (lhs.interpretation() == rhs.interpretation())
    && (lhs.local_source_node_list_position_index() == rhs.local_source_node_list_position_index());

//    && (rhs.rewind_level() == lhs.rewind_level())
//    && (rhs.lambda_position() == lhs.lambda_position());
 }

 friend bool operator>(const NL_Gecode_Dock_Node& lhs, const NL_Gecode_Dock_Node& rhs)
 {
  return !( (lhs < rhs) || (lhs == rhs) );
 }
};


_RZNS(NLG)



#endif
