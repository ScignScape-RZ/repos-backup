
#include "nl-gecode-lexclass-vector.h"

#include "nl-gecode-lexclass.h"

#include "nl-gecode-lexicon.h"

USING_RZNS(NLG)


NL_Gecode_Lexclass_Vector::NL_Gecode_Lexclass_Vector():
  QVector<NL_Gecode_Lexclass*>()
{
}

