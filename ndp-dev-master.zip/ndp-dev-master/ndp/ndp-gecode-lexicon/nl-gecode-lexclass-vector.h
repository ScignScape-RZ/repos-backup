
#ifndef NL_GECODE_LEXCLASS_VECTOR__H
#define NL_GECODE_LEXCLASS_VECTOR__H

#include "rzns.h"

#include <functional>

#include <QString>

#include <QMap>
#include <QVector>

#include "accessors.h"


RZNS_(NLG)

class NL_Gecode_Lexicon;
class NL_Gecode_Lexclass;


class NL_Gecode_Lexclass_Vector : public QVector<NL_Gecode_Lexclass*>
{

public:
 NL_Gecode_Lexclass_Vector();

};

_RZNS(NLG)



#endif
