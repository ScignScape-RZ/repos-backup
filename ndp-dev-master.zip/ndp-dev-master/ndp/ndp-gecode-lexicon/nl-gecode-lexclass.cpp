
#include "nl-gecode-lexclass.h"

#include "nl-gecode-lexicon.h"

USING_RZNS(NLG)


NL_Gecode_Lexclass::NL_Gecode_Lexclass(int numeric_code, QString label, QString key, const NL_Gecode_Lexicon& nll)
 : numeric_code_(numeric_code),
  this_root_(Roots::N_A), label_(label), expected_lambda_depth_(0)
{
 //ref_lexcass_ = nullptr;
 QStringList qsl = key.split("..->");
 if(qsl.size() == 1)
 {
  if(key.startsWith('@'))
  {
   QString k = key.mid(1);
   ref_lexcass_ = nll.find_lexclass(k);
  }
  else
  {
   ref_lexcass_ = nullptr;
   this_root_ = parse_root(key);
  }
 }
 else
 {
  ref_lexcass_ = nullptr;

  QStringList qsl1 = qsl[0].split(".->");
  QStringList qsl2 = qsl[1].split(",->");

  for(QString qs : qsl1)
  {
   lambda_channel_.push_back(nll.find_lexclass(qs.trimmed()));
  }

  for(QString qs : qsl2)
  {
   NL_Gecode_Lexclass* nlc = nll.find_lexclass(qs.trimmed());
   int edc = nlc->expected_lambda_depth() + 1;
   if(expected_lambda_depth_ < edc)
    expected_lambda_depth_ = edc;
   profile_channel_.push_back(nll.find_lexclass(qs.trimmed()));
  }
 }

 QMap<int, QPair<int, int> > arities;
 arity_total_ = get_total_arity(arities);

 lamda_rewind_key_.resize(arity_total_);
 for(int i = 0; i < arity_total_; ++i)
 {
  lamda_rewind_key_[i] = arities[i];
 }

 //int total_arity =

}

void NL_Gecode_Lexclass::get_rewind_level_and_lambda_position(int key, int& rl, int& lp)
{
 if(key < lamda_rewind_key_.size())
 {
  rl = lamda_rewind_key_[key].first;
  lp = lamda_rewind_key_[key].second;
 }
 else if((lamda_rewind_key_.size() == 0) && (key == 0))
 {
  rl = 0;
  lp = 0;
 }
 else
 {
  rl = -1;
  lp = -1;
 }
}


NL_Gecode_Lexclass::NL_Gecode_Lexclass()
 : this_root_(Roots::N_A), expected_lambda_depth_(0), ref_lexcass_(0)
{
}

int NL_Gecode_Lexclass::max_arity(int comparison)
{
 if(ref_lexcass_)
 {
  return 0;
 }
 int lcs = lambda_channel_.size();
 if(profile_channel_.isEmpty())
 {
  if(lcs > comparison)
   return lcs;
  else
   return comparison;
 }
 else
 {
  return profile_channel_.first()->max_arity(lcs);
 }
}

int NL_Gecode_Lexclass::get_total_arity(QMap<int, QPair<int, int> >& arities)
{
 if(ref_lexcass_)
 {
  return 0;
 }
 int i = 0;
 int result = 0;
 int total = 0;
 while(true)
 {
  int a = arity(i);
  if(a == -1)
   return result;
  for(int j = 0; j < a; ++j)
  {
   // rewind level first ...
   arities[total] = {i, j};
   ++total;
  }
  result += a;
  ++i;
 }
}


NL_Gecode_Lexclass* NL_Gecode_Lexclass::get_dock_match(int lambda_position, int rewind_level)
{
 if(ref_lexcass_)
 {
  return nullptr;
 }

 if(rewind_level == 0)
 {
  if(lambda_channel_.isEmpty())
  {
   return nullptr;
  }
  else
  {
   return lambda_channel_.value(lambda_position, nullptr);
  }
 }
 else
 {
  if(profile_channel_.isEmpty())
  {
   return nullptr;
  }
  else
  {
   return profile_channel_.first()->get_dock_match(lambda_position, rewind_level - 1);
  }
 }
}


NL_Gecode_Lexclass* NL_Gecode_Lexclass::get_profile_for_rewind_level(int rewind_level)
{
 if(rewind_level == 0)
 {
  if(profile_channel_.isEmpty())
  {
   return this;
  }
  else
  {
   return profile_channel_.first();
  }
 }
 else
 {
  if(profile_channel_.isEmpty())
  {
   return nullptr;
  }
  else
  {
   return profile_channel_.first()->get_profile_for_rewind_level(rewind_level - 1);
  }
 }
}


NL_Gecode_Lexclass* NL_Gecode_Lexclass::get_rewind_for_rewind_level(int rewind_level)
{
 if(rewind_level == 0)
 {
  return this;
 }
 else
 {
  return get_rewind_for_rewind_level(rewind_level - 1);
 }
}

int NL_Gecode_Lexclass::arity(int rewind_level)
{
 if(rewind_level > 0)
 {
  if(profile_channel_.isEmpty())
  {
   return -1;
  }
  return profile_channel_.first()->arity(rewind_level - 1);
 }
 else
 {
  return lambda_channel_.size();
 }
}


