
#ifndef NL_GECODE_LEXCLASS__H
#define NL_GECODE_LEXCLASS__H

#include "rzns.h"

#include <functional>

#include <QString>

#include <QMap>
#include <QVector>

#include "accessors.h"


RZNS_(NLG)

class NL_Gecode_Lexicon;


class NL_Gecode_Lexclass
{
public:

 enum class Roots {
  N_A, Noun, Proposition
 };

 Roots parse_root(QString key)
 {
  static QMap<QString, Roots> static_map {{
    { "N", Roots::Noun },
    { "Noun", Roots::Noun },

    { "P", Roots::Proposition },
    { "Proposition", Roots::Proposition },


                                          }};

  return static_map.value(key, Roots::N_A);
 }

private:

 QVector<NL_Gecode_Lexclass*> lambda_channel_;

 QVector<NL_Gecode_Lexclass*> profile_channel_;

 Roots this_root_;

 QString label_;

 int expected_lambda_depth_;

 int numeric_code_;

 NL_Gecode_Lexclass* ref_lexcass_;

 int arity_total_;

 QVector<QPair<int, int>> lamda_rewind_key_;

public:

 NL_Gecode_Lexclass(int numeric_code, QString label, QString key, const NL_Gecode_Lexicon& nll);

 NL_Gecode_Lexclass();

 ACCESSORS__RGET(QVector<NL_Gecode_Lexclass*> ,lambda_channel)
 ACCESSORS__RGET(QVector<NL_Gecode_Lexclass*> ,profile_channel)

 ACCESSORS(QString ,label)

 ACCESSORS(int ,expected_lambda_depth)
 ACCESSORS(int ,numeric_code)
 ACCESSORS(int ,arity_total)

 int arity(int rewind_level = 0);
 int max_arity(int comparison = 0);

 int get_total_arity(QMap<int, QPair<int, int> >& arities);

 NL_Gecode_Lexclass* get_profile_for_rewind_level(int rewind_level);

 NL_Gecode_Lexclass* get_rewind_for_rewind_level(int rewind_level);

 NL_Gecode_Lexclass* get_dock_match(int lambda_position, int rewind_level);

 void get_rewind_level_and_lambda_position(int key, int& rl, int& lp);

};

_RZNS(Chat)



#endif
