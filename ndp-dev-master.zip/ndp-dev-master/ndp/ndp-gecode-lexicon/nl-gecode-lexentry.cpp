
#include "nl-gecode-lexentry.h"

USING_RZNS(NLG)

NL_Gecode_Lexentry::NL_Gecode_Lexentry(QString lexword, NL_Gecode_Lexclass* lexclass)
 : lexword_(lexword)
{
 lexclasses_.push_back(lexclass);
}

int NL_Gecode_Lexentry::add_lexclass(NL_Gecode_Lexclass* lexclass)
{
 lexclasses_.push_back(lexclass);
 return lexclasses_.size();
}

NL_Gecode_Lexentry::NL_Gecode_Lexentry()
{

}

