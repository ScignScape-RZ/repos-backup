
#ifndef NL_GECODE_LEXENTRY__H
#define NL_GECODE_LEXENTRY__H

#include "rzns.h"

#include <functional>

#include <QString>

#include <QMap>

#include "accessors.h"

#include "nl-gecode-lexclass.h"

#include "nl-gecode-lexclass-vector.h"

RZNS_(NLG)

class NL_Gecode_Lexentry
{
 QString lexword_;

 NL_Gecode_Lexclass_Vector lexclasses_;

public:

 NL_Gecode_Lexentry(QString lexword, NL_Gecode_Lexclass* lexclass);

 NL_Gecode_Lexentry();

 ACCESSORS__GET(NL_Gecode_Lexclass_Vector ,lexclasses)
 ACCESSORS(QString ,lexword)


 int add_lexclass(NL_Gecode_Lexclass* lexclass);

};

_RZNS(NLG)



#endif
