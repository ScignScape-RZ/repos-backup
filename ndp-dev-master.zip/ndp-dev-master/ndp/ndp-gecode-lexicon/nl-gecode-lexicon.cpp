
#include "nl-gecode-lexicon.h"

#include "nl-gecode-lexclass.h"

#include "textio.h"

#include <QRegularExpression>

USING_RZNS(NLG)


NL_Gecode_Lexicon::NL_Gecode_Lexicon(QString source_path)
 : current_lexclass_numeric_code_maximum_(0),
   current_maximum_interpretation_count_(0)
{
 QString code = RZ::TextIO::load_file(source_path);
 QStringList lines = code.split("\n");

 QRegularExpression rx ("([$:@\\w-]+)\\s+(\\W{3,4})");

 for(QString line : lines)
 {
  if(line.trimmed().startsWith(";;-"))
   continue;

  if(line.trimmed().startsWith(";;;"))
  {
   finalize_injection();
   continue;
  }

  if(!current_injection_script_key_.isEmpty())
  {
   current_injection_script_code_ += line + "\n";
   continue;
  }

  line = line.trimmed();

  if(line.isEmpty())
   continue;


  QRegularExpressionMatch rxm = rx.match(line);

  if(rxm.hasMatch())
  {
   QString lexword = rxm.captured(1).trimmed();
   QString defkind = rxm.captured(2).trimmed();

   QString rest = line.mid(rxm.capturedEnd()).trimmed();

   if(defkind == ">>>")
   {
    if(rest.startsWith('$'))
    {
     mark_lexgroup(rest, lexword);
    }
    else
    {
     add_lexentry(lexword, rest);
    }
   }
   else if(defkind == ":::")
   {
    add_lexclass(lexword, rest);
   }
   else if(defkind == "--->")
   {
    if(lexword.startsWith('$'))
    {
     current_injection_script_key_ = lexword;
    }
    else if(lexword.contains(':'))
    {
     lexword.replace(':', '~');
     lexword.prepend('$');
     current_injection_script_key_ = lexword;
    }
    else
    {
     lexword.prepend("$~");
     current_injection_script_key_ = lexword;
    }
    current_injection_script_code_ += rest + "\n";
   }

  }

 }

}


void NL_Gecode_Lexicon::finalize_injection()
{
 injection_scripts_.insert(current_injection_script_key_, current_injection_script_code_);
 current_injection_script_key_.clear();
 current_injection_script_code_.clear();

}


NL_Gecode_Lexclass* NL_Gecode_Lexicon::get_null_lexclass()
{
 return find_lexclass("NA");
}

void NL_Gecode_Lexicon::mark_lexgroup(QString lexgroup, QString key)
{
 lexgroups_.insert(lexgroup, key);
}

void NL_Gecode_Lexicon::add_lexentry(QString lexword, QString key)
{
 int lexentry_interpretation_count = 0;
 if(lexentries_.contains(lexword))
 {
  lexentry_interpretation_count = lexentries_[lexword]->add_lexclass(find_lexclass(key));
 }
 else
 {
  lexentries_[lexword] = new NL_Gecode_Lexentry(lexword, find_lexclass(key));
  lexentry_interpretation_count = 1;
 }
 if(lexentry_interpretation_count > current_maximum_interpretation_count_)
 {
  current_maximum_interpretation_count_ = lexentry_interpretation_count;
 }
}


NL_Gecode_Lexclass* NL_Gecode_Lexicon::get_lexclass_from_numeric_code(int nc)
{
 return lexclasses_by_numeric_code_.value(nc, nullptr);
}

void NL_Gecode_Lexicon::add_lexclass(QString lexclass, QString key)
{
 lexclasses_[lexclass] = new NL_Gecode_Lexclass(current_lexclass_numeric_code_maximum_, lexclass, key, *this);
 lexclasses_by_numeric_code_.push_back(lexclasses_[lexclass]);
 ++current_lexclass_numeric_code_maximum_;
}

NL_Gecode_Lexentry* NL_Gecode_Lexicon::find_lexentry(QString word) const
{
 return lexentries_[word];
}

NL_Gecode_Lexclass* NL_Gecode_Lexicon::find_lexclass(QString label) const
{
 return lexclasses_[label];
}


NL_Gecode_Lexentry* NL_Gecode_Lexicon::match_lexclass(QString word, NL_Gecode_Lexclass_Vector& lcv) const
{
 if(lexentries_.contains(word))
 {
  NL_Gecode_Lexentry* nle = find_lexentry(word);
  lcv = nle->lexclasses();
  return nle;
 }
 return nullptr;
}


