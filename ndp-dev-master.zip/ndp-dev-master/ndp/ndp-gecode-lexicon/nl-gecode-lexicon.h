
#ifndef NL_Gecode_Lexicon__H
#define NL_Gecode_Lexicon__H

#include "rzns.h"

#include <functional>

#include <QString>

#include <QMap>
#include <QVector>

#include "accessors.h"

#include "nl-gecode-lexentry.h"
#include "nl-gecode-lexclass.h"

//?#include "nl-gecode-lexclass-vector.h"


RZNS_(NLG)


class NL_Gecode_Lexicon
{

 QString source_path_;

 QMap<QString, NL_Gecode_Lexentry*> lexentries_;
 QMap<QString, NL_Gecode_Lexclass*> lexclasses_;

 typedef QMap<QString, NL_Gecode_Lexclass*> lexclasses_type;

 QMultiMap<QString, QString> lexgroups_;

 typedef QMultiMap<QString, QString> lexgroups_type;

 int current_lexclass_numeric_code_maximum_;
 int current_maximum_interpretation_count_;

 QVector<NL_Gecode_Lexclass*> lexclasses_by_numeric_code_;

 void finalize_injection();

 QString current_injection_script_code_;
 QString current_injection_script_key_;

 QMap<QString, QString> injection_scripts_;

 typedef QMap<QString, QString> injection_scripts_type;

public:

 explicit NL_Gecode_Lexicon(QString source_path);


 ACCESSORS(int ,current_maximum_interpretation_count)
 ACCESSORS__RGET(lexgroups_type ,lexgroups)
 ACCESSORS__RGET(injection_scripts_type ,injection_scripts)
 ACCESSORS__RGET(lexclasses_type ,lexclasses)



 void add_lexentry(QString lexword, QString key);
 void add_lexclass(QString lexclass, QString key);

 void mark_lexgroup(QString lexgroup, QString key);

 NL_Gecode_Lexclass* get_null_lexclass();

 NL_Gecode_Lexclass* get_lexclass_from_numeric_code(int nc);

 NL_Gecode_Lexentry* find_lexentry(QString word)  const;
 NL_Gecode_Lexclass* find_lexclass(QString label)  const;

 NL_Gecode_Lexentry* match_lexclass(QString word, NL_Gecode_Lexclass_Vector& lcv) const;

};

_RZNS(NLG)



#endif
