
#include "nl-gecode-solver.h"
#include "nl-gecode-lexicon.h"

#include <QFile>

USING_RZNS(NLG)


NL_Gecode_Lexentry* NL_Gecode_Solver::get_sentence_word_as_lexentry(int key) const
{
 return inverse_sentence_words_[key];
}

const NL_Gecode_Dock_Node& NL_Gecode_Solver::get_dock_node(int key) const
{
 return inverse_sentence_nodes_[key];
}

NL_Gecode_Lexentry* NL_Gecode_Solver::get_dock_node_lexentry(int key, int interpretation, int& lambda_offset, int& rewind_level) const
{
 const NL_Gecode_Dock_Node& dn = inverse_sentence_nodes_[key];

 dn.get_rewind_level_and_lambda_position(interpretation, rewind_level, lambda_offset);


 //?lambda_offset = dn.lambda_position();
 //?rewind_level = dn.rewind_level();
 return dn.lexentry();
}

int NL_Gecode_Solver::get_sentence_word_by_index(int key) const
{
 return inverse_sentence_words_index_[key];
}



int NL_Gecode_Solver::find_sentence_word_in_sentence(NL_Gecode_Lexentry* lge, int which)
{
 return sentence_words_.values(lge)[which];
}

int NL_Gecode_Solver::get_count_of_sentence_word_in_sentence(NL_Gecode_Lexentry* lge)
{
 return sentence_words_distinct_[lge].second;
}

//NL_Gecode_Lexclass* NL_Gecode_Solver::get_lexclass_by_word(QString word)
//{
// static QMap<QString, NL_Gecode_Lexclass*> dict{{
//   {"The", NL_Gecode_Lexclass*::Adj},
//   {"dog", NL_Gecode_Lexclass*::Noun},
//   {"is", NL_Gecode_Lexclass*::Verb},
//   {"here", NL_Gecode_Lexclass*::Noun} }};

// return dict.value(word);
//}

NL_Gecode_Lexclass* NL_Gecode_Solver::get_lexclass_by_sentence_word_key(int key, int interpretation)
{
 NL_Gecode_Lexentry* lge = get_sentence_word_as_lexentry(key);
 return lge->lexclasses().value(interpretation, lexicon_->get_null_lexclass());
 //return get_lexclass_by_word(get_sentence_word_as_string(key));
}

NL_Gecode_Lexclass* NL_Gecode_Solver::get_lexclass_by_node_word_key(int key, int interpretation, int& lambda_offset, int& rewind_level)
{
 NL_Gecode_Lexentry* nle = get_dock_node_lexentry(key, interpretation, lambda_offset, rewind_level);
 return nle->lexclasses().value(interpretation, lexicon_->get_null_lexclass());
 //?return get_lexclass_by_word(get_node_word_as_string(key, lambda_offset));
}

int NL_Gecode_Solver::get_lexclass_int_from_lexentry(NL_Gecode_Lexentry* nle)
{
 return nle->lexclasses().first()->numeric_code();
 //return (int) get_lexclass_by_word(word);
}

//QString NL_Gecode_Solver::get_lexclass_string(NL_Gecode_Lexclass* lc) const
//{
// return lc->label();

// static QMap<NL_Gecode_Lexclass*, QString> dict{{
//   {NL_Gecode_Lexclass*::Adj, "Adj"},
//   {NL_Gecode_Lexclass*::Noun, "Noun"},
//   {NL_Gecode_Lexclass*::Verb, "Verb"},
//   {NL_Gecode_Lexclass*::Prop, "Prop"},
//                                        }};
// return dict.value(lc);
//}

QString NL_Gecode_Solver::get_lexclass_string(int nc) const
{
 NL_Gecode_Lexclass* lc = lexicon_->get_lexclass_from_numeric_code(nc);
 return lc->label();
 //return get_lexclass_string( (NL_Gecode_Lexclass*) lc );
}

NL_Gecode_Lexclass* NL_Gecode_Solver::get_profile_for_lexclass(NL_Gecode_Lexclass* lc, int rewind_level)
{
 if(rewind_level == -1)
  rewind_level = 0;

 return lc->get_profile_for_rewind_level(rewind_level);
}

NL_Gecode_Lexclass* NL_Gecode_Solver::get_rewind_for_lexclass(NL_Gecode_Lexclass* lc, int rewind_level)
{
 if(rewind_level == -1)
  rewind_level = 0;

 return lc->get_rewind_for_rewind_level(rewind_level);
}



NL_Gecode_Lexclass* NL_Gecode_Solver::get_match_for_lexclass(NL_Gecode_Lexclass* lc, int lambda_position, int rewind_level)
{
 if(rewind_level == -1)
  rewind_level = 0;

 if(lambda_position == -1)
  lambda_position = 0;


 NL_Gecode_Lexclass* result = lc->get_dock_match(lambda_position, rewind_level);
 if(result)
  return result;
 return lc;
// switch(lc)
// {
// case NL_Gecode_Lexclass*::Adj: return NL_Gecode_Lexclass*::Noun;
// case NL_Gecode_Lexclass*::Verb: return NL_Gecode_Lexclass*::Noun;
// case NL_Gecode_Lexclass*::Noun: return NL_Gecode_Lexclass*::Noun;
// case NL_Gecode_Lexclass*::Prop: return NL_Gecode_Lexclass*::Noun;
// }
}

int NL_Gecode_Solver::get_arity_for_lexclass(NL_Gecode_Lexclass* lc, int rewind_level)
{
 switch(rewind_level)
 {
 case 0: return get_arity_for_lexclass_0(lc);
 default: return 0;
 }
}

int NL_Gecode_Solver::get_total_arity(NL_Gecode_Lexclass* lc, QMap<int, QPair<int, int> >& arities)
{
 return lc->get_total_arity(arities);
 //return get_arity_for_lexclass_0(lc);
}

//int NL_Gecode_Solver::get_total_arity(QString word)
//{
// return get_total_arity(get_lexclass_by_word(word));
//}


int NL_Gecode_Solver::get_arity_for_lexclass_0(NL_Gecode_Lexclass* lc)
{
 return lc->arity(0);
// switch(lc)
// {
// case NL_Gecode_Lexclass*::Adj:
//  return 1;
// case NL_Gecode_Lexclass*::Verb:
//  return 2;
// case NL_Gecode_Lexclass*::Noun:
//  return 0;
// case NL_Gecode_Lexclass*::Prop:
//  return 0;
// }
}

int NL_Gecode_Solver::get_arity_for_lexclass_1(NL_Gecode_Lexclass* lc)
{
 return 0;
}

NL_Gecode_Solver::NL_Gecode_Solver(NL_Gecode_Lexicon* lexicon, QString sentence)
 : lexicon_(lexicon)
//   :
//     words_iva(*this, 6, 0, 3), lexclass_count_iva(*this, 6, 0, 2)
//sentence_words_distinct_{"The", "dog", "is", "here"}
{
 int lexclass_count_ = 8;

 //IntArgs c1;
 int distinct_word_count = 0;
 int total_word_count = 0;
 int total_node_count = 0;
 int source_node_list_position_index = 0;
 QStringList qsl = sentence.split(" ");

 int total_pairs_count = 0;

 for(QString word : qsl)
 {
  NL_Gecode_Lexentry* nle = lexicon->find_lexentry(word);

  if(sentence_words_distinct_.contains(nle))
  {
   ++sentence_words_distinct_[nle].second;
  }
  else
  {
   sentence_words_distinct_.insert(nle, {distinct_word_count, 1});
   inverse_sentence_words_distinct_.push_back(nle);
   ++distinct_word_count;
  }

  int max_arity_over_interpretations = 0;
  //NL_Gecode_Lexclass* nlc;
  int interpretation_count = 0;

  int interpretation_with_max_arity_count = 0;

  QMap<int, QMap<int, QPair<int, int> > > arities;

  while(true)
  {
   NL_Gecode_Lexclass* interpretation_nlc = nle->lexclasses().value(interpretation_count, nullptr);
   if(interpretation_nlc)
   {
    QMap<int, QPair<int, int> > local_arities;
    int a = get_total_arity(interpretation_nlc, local_arities);
    arities[interpretation_count] = local_arities;
    if(a > max_arity_over_interpretations)
    {
     interpretation_with_max_arity_count = interpretation_count;
     max_arity_over_interpretations = a;
    }
   }
   else
   {
    break;
   }
   ++interpretation_count;
  }

 // total_pairs_count += a;

  int a_adj = max_arity_over_interpretations;
  if(a_adj == 0)
   a_adj = 1;
  for(int i = 0; i < a_adj; ++i)
  {
   //  if a == 0, source_node_list_position_index in dn should be -1;
   //  otherwise take source_node_list_position_index, but then it needs inc.

   //NL_Gecode_Lexentry* nle = lexicon->find_lexentry(word);

   int rl = arities[interpretation_with_max_arity_count][i].first;
   int lp = arities[interpretation_with_max_arity_count][i].second;

   NL_Gecode_Dock_Node dn(nle, total_word_count, rl, lp,                      
    (max_arity_over_interpretations == 0)? -1:source_node_list_position_index++,
    i );


   inverse_sentence_nodes_.push_back(dn);
   sentence_nodes_.insert(total_node_count, dn);

   inverse_sentence_words_index_.push_back(total_word_count);

   ++total_node_count;
  }


  inverse_sentence_words_.push_back(nle);
  sentence_words_.insert(nle, total_word_count);
  ++total_word_count;
 }

 //int
 //?
 int valid_pairs_count = total_word_count - 1;

 invalid_pairs_count_ = total_pairs_count - valid_pairs_count;


 total_pairs_count = valid_pairs_count;

 //?--total_pairs_count;

 int iva_max = total_node_count - 1;

 sources_nodes_iva_ = IntVarArray(*this, total_pairs_count, 0, iva_max);
 sources_words_iva_ = IntVarArray(*this, total_pairs_count, 0, total_word_count);

 pair_merge_iva_ = IntVarArray(*this, total_pairs_count, 0, 10000);

 sources_rewind_offsets_iva_ = IntVarArray(*this, total_pairs_count, 0, max_lambda_offset);
 sources_lambda_offsets_iva_ = IntVarArray(*this, total_pairs_count, 0, max_lambda_offset);
 sources_lambda_comp_offsets_iva_ = IntVarArray(*this, total_pairs_count, 0, max_lambda_offset);

 int interpretation_count = lexicon_->current_maximum_interpretation_count();

 words_interpretations_iva_ = IntVarArray(*this, total_word_count, 0, interpretation_count - 1);

 sources_interpretations_iva_ = IntVarArray(*this, total_pairs_count, 0, interpretation_count - 1);
 targets_interpretations_iva_ = IntVarArray(*this, total_pairs_count, 0, interpretation_count - 1);

 sources_lexclass_iva_ = IntVarArray(*this, total_pairs_count, 0, lexclass_count_ - 1);
 sources_lambdas_lexclass_iva_ = IntVarArray(*this, total_pairs_count, 0, lexclass_count_ - 1);

 targets_nodes_iva_ = IntVarArray(*this, total_pairs_count, 0, iva_max);
 targets_words_iva_ = IntVarArray(*this, total_pairs_count, 0, total_word_count);

 targets_lexclass_iva_ = IntVarArray(*this, total_pairs_count, 0, lexclass_count_ - 1);
 targets_profiles_lexclass_iva_ = IntVarArray(*this, total_pairs_count, 0, lexclass_count_ - 1);
 targets_rewinding_lexclass_iva_ = IntVarArray(*this, total_pairs_count, 0, lexclass_count_ - 1);
 targets_rewinding_flags_bva_  = BoolVarArray(*this, total_pairs_count, 0, 1);




 lambda_position_iva_ = IntVarArray(*this, total_pairs_count, 0, maximum_arity);
 rewind_level_iva_ = IntVarArray(*this, total_pairs_count, 0, maximum_rewind);

 //??
//? lex_class_array_with_NA_option_ = IntArgs(total_node_count * 2);

 words_index_array_ = IntArgs(total_node_count);
 targets_words_array_ = IntArgs(total_node_count);

 lex_class_array_ = IntArgs(total_node_count * interpretation_count);
 sources_rewind_offsets_array_ = IntArgs(total_node_count * interpretation_count);
 sources_lambda_offsets_array_ = IntArgs(total_node_count * interpretation_count);
 sources_lambdas_lex_class_array_ = IntArgs(total_node_count * interpretation_count);
 targets_profiles_lex_class_array_ = IntArgs(total_node_count * interpretation_count);
 targets_rewinding_lex_class_array_ = IntArgs(total_node_count * interpretation_count);

 lambda_position_array_ = IntArgs(total_node_count * interpretation_count);

 for(int i = 0; i < total_node_count; ++i)
 {
  for(int interpretation = 0; interpretation < interpretation_count; ++interpretation)
  {
   int offset = interpretation * total_node_count;

   int lambda_offset;
   int rewind_level;


   NL_Gecode_Lexclass* lc = get_lexclass_by_node_word_key(i, interpretation, lambda_offset, rewind_level);
   lex_class_array_[i + offset] = lc->numeric_code();//get_lexclass_int_by_word(get_word_as_string(i));



//  lex_class_array_with_NA_option_[i] = 0;
//  lex_class_array_with_NA_option_[i + total_node_count] = lc->numeric_code();

   int slc = get_match_for_lexclass(lc, lambda_offset, rewind_level)->numeric_code();
   int tlc = get_profile_for_lexclass(lc, rewind_level)->numeric_code();
   int trc = get_rewind_for_lexclass(lc, rewind_level)->numeric_code();
   sources_lambdas_lex_class_array_[i + offset] = slc; //get_match_for_lexclass(lc, lambda_offset, rewind_level)->numeric_code();
   targets_profiles_lex_class_array_[i + offset] = tlc; //get_profile_for_lexclass(lc, rewind_level)->numeric_code();
   targets_rewinding_lex_class_array_[i + offset] = trc; //get_profile_for_lexclass(lc, rewind_level)->numeric_code();

   sources_lambda_offsets_array_[i + offset] = lambda_offset;// + i*100;
   sources_rewind_offsets_array_[i + offset] = rewind_level;// + i*100;
  }
  int k = get_sentence_word_by_index(i);
  words_index_array_[i] = k;
 }

#ifdef HIDE
   //? IntArgs lex_class_array_with_NA_option_ = IntArgs(total_node_count * 2);
   IntArgs lex_class_array_with_NA_option = IntArgs(total_node_count * 2);

   IntArgs sources_lambdas_lex_class_array_with_NA_option = IntArgs(total_node_count * 2);
   IntArgs targets_profiles_lex_class_array_with_NA_option = IntArgs(total_node_count * 2);
   IntArgs targets_rewinding_lex_class_array_with_NA_option = IntArgs(total_node_count * 2);


 for(int i = 0; i < total_node_count; ++i)
 {
  int offset2 = 0;
  int offset1 = total_node_count;
  lex_class_array_with_NA_option[i + offset2] = lex_class_array_[i];
  lex_class_array_with_NA_option[i + offset1] = 0;

  sources_lambdas_lex_class_array_with_NA_option[i + offset2] = sources_lambdas_lex_class_array_[i];
  sources_lambdas_lex_class_array_with_NA_option[i + offset1] = 0;

  targets_profiles_lex_class_array_with_NA_option[i + offset2] = targets_profiles_lex_class_array_[i];
  targets_profiles_lex_class_array_with_NA_option[i + offset1] = 0;

  targets_rewinding_lex_class_array_with_NA_option[i + offset2] = targets_rewinding_lex_class_array_[i];
  targets_rewinding_lex_class_array_with_NA_option[i + offset1] = 0;

 }



// Matrix<IntArgs> targets_lex_class_matrix = Matrix<IntArgs>(lex_class_array_with_NA_option, total_node_count, 2);
// Matrix<IntArgs> sources_lex_class_matrix = Matrix<IntArgs>(lex_class_array_with_NA_option, total_node_count, 2);
// Matrix<IntArgs> sources_lambdas_matrix = Matrix<IntArgs>(sources_lambdas_lex_class_array_with_NA_option, total_node_count, 2);
// Matrix<IntArgs> targets_profiles_matrix = Matrix<IntArgs>(targets_profiles_lex_class_array_with_NA_option, total_node_count, 2);
// Matrix<IntArgs> targets_rewinding_matrix = Matrix<IntArgs>(targets_rewinding_lex_class_array_with_NA_option, total_node_count, 2);

#endif

 Matrix<IntArgs> targets_lex_class_matrix = Matrix<IntArgs>(lex_class_array_, total_node_count, interpretation_count);
 Matrix<IntArgs> sources_lex_class_matrix = Matrix<IntArgs>(lex_class_array_, total_node_count, interpretation_count);
 Matrix<IntArgs> sources_lambdas_matrix = Matrix<IntArgs>(sources_lambdas_lex_class_array_, total_node_count, interpretation_count);
 Matrix<IntArgs> targets_profiles_matrix = Matrix<IntArgs>(targets_profiles_lex_class_array_, total_node_count, interpretation_count);
 Matrix<IntArgs> targets_rewinding_matrix = Matrix<IntArgs>(targets_rewinding_lex_class_array_, total_node_count, interpretation_count);

 Matrix<IntArgs> sources_lambda_offsets_matrix = Matrix<IntArgs>(sources_lambda_offsets_array_, total_node_count, interpretation_count);
 Matrix<IntArgs> sources_rewind_offsets_matrix = Matrix<IntArgs>(sources_rewind_offsets_array_, total_node_count, interpretation_count);

// count(*this, sources_interpretations_iva_, 0, IRT_EQ, invalid_pairs_count_);
// count(*this, targets_interpretations_iva_, 0, IRT_EQ, invalid_pairs_count_);

 rel(*this, sources_nodes_iva_, IRT_LE);

 //words_interpretations_iva_[sources_words_iva_[i]] =  sources_interpretations_iva_[i];

 for(int i = 0; i < total_pairs_count; ++i)
 {
  // // ///


  rel(*this, sources_nodes_iva_[i] != targets_nodes_iva_[i]);
//   (
//    (sources_interpretations_iva_[i] == 0)
//        && (targets_interpretations_iva_[i] == 0)
//        && (sources_nodes_iva_[i] == targets_nodes_iva_[i])


//         //?&& (sources_lexclass_iva_[i] == lexicon->find_lexclass("V")->numeric_code())
//      )
//      ||
//      (
//       (sources_interpretations_iva_[i] != 0)
//        && (targets_interpretations_iva_[i] != 0)
//        && (sources_nodes_iva_[i] != targets_nodes_iva_[i])
//      )
//     )
//      //sources_nodes_iva_[i] != targets_nodes_iva_[i])
//    ;

   // viz., sources_lexclass_iva_[i] = lex_class_array_[sources_nodes_iva_[i]];
   // viz., sources_lexclass_iva_[i] = sources_lex_class_matrix[sources_nodes_iva_[i]][interp];
    //?
    //?element(*this, lex_class_array_, sources_nodes_iva_[i], sources_lexclass_iva_[i]);
  //?

  element(*this, words_interpretations_iva_, sources_words_iva_[i], sources_interpretations_iva_[i]);
  element(*this, words_interpretations_iva_, targets_words_iva_[i], targets_interpretations_iva_[i]);


  rel(*this, sources_words_iva_[i] != targets_words_iva_[i]);


  //words_interpretations_iva_[sources_words_iva_[i]] =  sources_interpretations_iva_[i];


  //??  element(*this, lex_class_array_, targets_nodes_iva_[i], targets_lexclass_iva_[i]);
 // viz., targets_lexclass_iva_[i] = lex_class_matrix[[sources_nodes_iva_[i]][0];

//?IntVar interpretation(*this, 0, 0);

  element(*this, sources_lex_class_matrix, sources_nodes_iva_[i], sources_interpretations_iva_[i], sources_lexclass_iva_[i]);
  element(*this, targets_lex_class_matrix, targets_nodes_iva_[i], targets_interpretations_iva_[i], targets_lexclass_iva_[i]);

//??
//  element(*this, sources_lambdas_lex_class_array_, sources_nodes_iva_[i], sources_lambdas_lexclass_iva_[i]);
//  element(*this, targets_profiles_lex_class_array_, targets_nodes_iva_[i], targets_profiles_lexclass_iva_[i]);
//  element(*this, targets_rewinding_lex_class_array_, targets_nodes_iva_[i], targets_rewinding_lexclass_iva_[i]);


  element(*this, sources_lambdas_matrix, sources_nodes_iva_[i], sources_interpretations_iva_[i], sources_lambdas_lexclass_iva_[i]);
  element(*this, targets_profiles_matrix, targets_nodes_iva_[i], targets_interpretations_iva_[i], targets_profiles_lexclass_iva_[i]);
  element(*this, targets_rewinding_matrix, targets_nodes_iva_[i], targets_interpretations_iva_[i], targets_rewinding_lexclass_iva_[i]);

  element(*this, sources_lambda_offsets_matrix, sources_nodes_iva_[i], sources_interpretations_iva_[i], sources_lambda_offsets_iva_[i]);
  element(*this, sources_rewind_offsets_matrix, sources_nodes_iva_[i], sources_interpretations_iva_[i], sources_rewind_offsets_iva_[i]);



  element(*this, words_index_array_, sources_nodes_iva_[i], sources_words_iva_[i]);
  element(*this, words_index_array_, targets_nodes_iva_[i], targets_words_iva_[i]);
//???

//?/  element(*this, sources_lambda_offsets_array_, sources_nodes_iva_[i], sources_lambda_offsets_iva_[i]);
//?/  element(*this, sources_rewind_offsets_array_, sources_nodes_iva_[i], sources_rewind_offsets_iva_[i]);



//?//
  rel(*this, sources_lambda_comp_offsets_iva_[i] ==
      (sources_words_iva_[i] * 100) + (sources_rewind_offsets_iva_[i] * 10) + sources_lambda_offsets_iva_[i]);
//?//
  rel(*this, pair_merge_iva_[i] ==
      (sources_nodes_iva_[i] * 100) + targets_nodes_iva_[i]);

 //?
//?
//   rel(*this,
//       (
//        (targets_profiles_lexclass_iva_[i] == sources_lambdas_lexclass_iva_[i])
//         &&
//        (targets_rewinding_flags_bva_[i] == false)
//       )
//        ||
//       (
//        (targets_rewinding_lexclass_iva_[i] == sources_lambdas_lexclass_iva_[i])
//         &&
//        (targets_rewinding_flags_bva_[i] == true)
//       )
//      );


//???? ==>>
     rel(*this,

//         (sources_nodes_iva_[i] == targets_nodes_iva_[i])
//          ||
         (
          (targets_profiles_lexclass_iva_[i] == sources_lambdas_lexclass_iva_[i])
           &&
          (targets_rewinding_flags_bva_[i] == false)
         )
          ||
         (
          (targets_rewinding_lexclass_iva_[i] == sources_lambdas_lexclass_iva_[i])
           &&
          (targets_rewinding_flags_bva_[i] == true)
         )
        );

//?
//  rel(*this, sources_interpretations_iva_[i] != 0);
//  rel(*this, targets_interpretations_iva_[i] != 0);

//?
 rel(*this, sources_lexclass_iva_[i] != 0);
 rel(*this, targets_lexclass_iva_[i] != 0);

//      );

//?
//  rel(*this,
//      ( (targets_interpretations_iva_[i] == 0) && (targets_rewinding_flags_bva_[i] == true) )
//    ||
//      ( (targets_interpretations_iva_[i] != 0) && (targets_rewinding_flags_bva_[i] == false) )
//     );


  rel(*this, sources_lexclass_iva_[i] != lexicon->find_lexclass("N")->numeric_code());
  rel(*this, sources_lexclass_iva_[i] != lexicon->find_lexclass("P")->numeric_code());



//??  rel(*this, sources_lexclass_iva_[i] != lexicon->find_lexclass("NA")->numeric_code());
//?
//?

   //?? rel(*this, sources_words_iva_[i] != targets_words_iva_[i]);

//?
//  rel(*this,
//      (
//       (targets_interpretations_iva_[i] == 0) &&
//       (sources_words_iva_[i] == targets_words_iva_[i])
//      ) ||
//      (
//       (targets_interpretations_iva_[i] != 0) &&
//       (sources_words_iva_[i] != targets_words_iva_[i])
//      )
//    );

 }



//? for(int i = 1; i < total_pairs_count; ++i)
//? {
  //?->
   //???
  //rel(*this, targets_nodes_iva_[i] != sources_nodes_iva_[0]);
//? }

 distinct(*this, sources_nodes_iva_);
 distinct(*this, targets_nodes_iva_);

//?
 branch(*this, sources_interpretations_iva_, INT_VAR_MIN_MIN(), INT_VAL_SPLIT_MIN());//INT_VAR_SIZE_MIN());//, INT_VAL_MIN());
 branch(*this, targets_interpretations_iva_, INT_VAR_MIN_MIN(), INT_VAL_SPLIT_MIN());//INT_VAR_SIZE_MIN());//, INT_VAL_MIN());
 branch(*this, sources_nodes_iva_, INT_VAR_MIN_MIN(), INT_VAL_SPLIT_MIN());//INT_VAR_SIZE_MIN());//, INT_VAL_MIN());
 branch(*this, targets_nodes_iva_, INT_VAR_MIN_MIN(), INT_VAL_SPLIT_MIN());//INT_VAR_SIZE_MIN());//, INT_VAL_MIN());
}

NL_Gecode_Solver::NL_Gecode_Solver(bool share, NL_Gecode_Solver& s)
 : Space(share, s), lexicon_(s.lexicon_)
{
 invalid_pairs_count_ = s.invalid_pairs_count_;

 lex_class_array_ = s.lex_class_array_;
 words_index_array_ = s.words_index_array_;
 targets_words_array_ = s.targets_words_array_;

 //?lex_class_array_with_NA_option_ = s.lex_class_array_with_NA_option_;
 //lex_class_matrix_ = s.lex_class_matrix_;

 sources_lambdas_lex_class_array_ = s.sources_lambdas_lex_class_array_;
 targets_profiles_lex_class_array_ = s.targets_profiles_lex_class_array_;
 targets_rewinding_lex_class_array_ = s.targets_rewinding_lex_class_array_;

 sentence_words_distinct_ = s.sentence_words_distinct_;
 inverse_sentence_words_distinct_ = s.inverse_sentence_words_distinct_;

 sentence_words_ = s.sentence_words_;
 inverse_sentence_words_ = s.inverse_sentence_words_;

 sentence_nodes_ = s.sentence_nodes_;
 inverse_sentence_nodes_ = s.inverse_sentence_nodes_;

 sources_lambda_offsets_array_ = s.sources_lambda_offsets_array_;
 sources_rewind_offsets_array_ = s.sources_rewind_offsets_array_;


 //?   words_iva_.update(*this, share, s.words_iva_);
 //   lexclass_iva_.update(*this, share, s.lexclass_iva_);

 sources_nodes_iva_.update(*this, share, s.sources_nodes_iva_);
 sources_words_iva_.update(*this, share, s.sources_words_iva_);
 sources_lexclass_iva_.update(*this, share, s.sources_lexclass_iva_);
 sources_interpretations_iva_.update(*this, share, s.sources_interpretations_iva_);
 targets_interpretations_iva_.update(*this, share, s.targets_interpretations_iva_);
 sources_lambdas_lexclass_iva_.update(*this, share, s.sources_lambdas_lexclass_iva_);

 words_interpretations_iva_.update(*this, share, s.words_interpretations_iva_);


 pair_merge_iva_.update(*this, share, s.pair_merge_iva_);

 targets_nodes_iva_.update(*this, share, s.targets_nodes_iva_);
 targets_words_iva_.update(*this, share, s.targets_words_iva_);

 sources_lambda_offsets_iva_.update(*this, share, s.sources_lambda_offsets_iva_);
 sources_rewind_offsets_iva_.update(*this, share, s.sources_rewind_offsets_iva_);
 sources_lambda_comp_offsets_iva_.update(*this, share, s.sources_lambda_comp_offsets_iva_);

 targets_lexclass_iva_.update(*this, share, s.targets_lexclass_iva_);
 targets_profiles_lexclass_iva_.update(*this, share, s.targets_profiles_lexclass_iva_);
 targets_rewinding_lexclass_iva_.update(*this, share, s.targets_rewinding_lexclass_iva_);
 targets_rewinding_flags_bva_.update(*this, share, s.targets_rewinding_flags_bva_);

 lambda_position_iva_.update(*this, share, s.lambda_position_iva_);
 rewind_level_iva_.update(*this, share, s.rewind_level_iva_);

}

NL_Gecode_Lexentry* NL_Gecode_Solver::test_prune_rewinds() const
{
 for(int i = 0; i < targets_rewinding_flags_bva_.size(); ++i)
 {
  BoolVar bv = targets_rewinding_flags_bva_[i];
  if(bv.assigned())
  {
   if(bv.val() == true)
   {
    // check that the ith target does not occur as a source
    IntVar tiv = targets_nodes_iva_[i];

//    int t_lambda_offset;
//    int t_rewind_level;

    // test Lexentries? ...
    const NL_Gecode_Dock_Node& tn = get_dock_node(tiv.val());
    //NL_Gecode_Lexentry* tle = get_dock_node_lexentry(tiv.val(), t_lambda_offset, t_rewind_level);

    int i = 0;

    for(IntVar siv : sources_nodes_iva_)
    {
//     int s_lambda_offset;
//     int s_rewind_level;

     const NL_Gecode_Dock_Node& sn = get_dock_node(siv.val());
//     NL_Gecode_Lexentry* sle = get_dock_node_lexentry(siv.val(), s_lambda_offset, s_rewind_level);
     if(tn.word_position() == sn.word_position())
     {
      int s_lambda_offset;
      int s_rewind_level;
      int interpretation = sources_interpretations_iva_[i].val();
      NL_Gecode_Lexentry* sle = get_dock_node_lexentry(siv.val(), interpretation, s_lambda_offset, s_rewind_level);
      return sle;
     }
     ++i;
    }
   }
  }
 }
 return nullptr;
}

Space* NL_Gecode_Solver::copy(bool share)
{
 return new NL_Gecode_Solver(share, *this);
}

void NL_Gecode_Solver::register_interpretations()
{
 int i = 0;
 NL_Gecode_Dock_Node_Pair_Vector dnpv(sources_nodes_iva_.size());
 for(IntVar iv : sources_nodes_iva_)
 {
  const NL_Gecode_Dock_Node& sdn = get_dock_node(iv.val());
  const NL_Gecode_Dock_Node& tdn = get_dock_node(targets_nodes_iva_[i].val());

  sdn.set_interpretation(sources_interpretations_iva_[i].val());
  tdn.set_interpretation(targets_interpretations_iva_[i].val());

  ++i;
 }
}

void NL_Gecode_Solver::merge_with_dock_node_set(NL_Gecode_Dock_Node_Pair_Vector_Collection& dnpvc) const
{
 int i = 0;
 NL_Gecode_Dock_Node_Pair_Vector dnpv(sources_nodes_iva_.size());
 //QMap<Dock_Node_Pair, int> dnpm;

// int max_in_degree = 0;

 for(IntVar iv : sources_nodes_iva_)
 {
//  int ivv = iv.val();
//  qDebug() << ivv;
  const NL_Gecode_Dock_Node& sdn = get_dock_node(iv.val());
  const NL_Gecode_Dock_Node& tdn = get_dock_node(targets_nodes_iva_[i].val());

  ++dnpv.target_count_by_word_position_[tdn.word_position()];
  //?tdn.increase_in_degree();

  //  if(tdn.word() == "The")
  //  {
  //   tdn.increase_composite_in_degree();
  //  }

//  if(tdn.in_degree() > max_in_degree)
//   max_in_degree = tdn.in_degree();

  NL_Gecode_Dock_Node_Pair dnp = NL_Gecode_Dock_Node_Pair(sdn, tdn);
  dnpv.insert_pair(dnp, i);

  //    qDebug() << "For i: " << i;
  //    qDebug() << "DNP: " << dnp.to_string();
  ////    qDebug() << "DNPM1: " << Dock_Node_Pair_Map_inspect(dnpm);

  //    if(dnpm.contains(dnp))
  //    {
  //     qDebug() << "???DNP: " << dnp.to_string();
  //     int v = dnpm.value(dnp);
  //     dnpm.insert(dnp, v + 1);
  //    }
  //    else
  //    {
  //     dnpm.insert(dnp, 1);
  //    }
  //    qDebug() << "DNPM2: " << Dock_Node_Pair_Map_inspect(dnpm);
  ++i;
 }



 //?   dnpvc.vectors.push_back(dnpv);
//? if(max_in_degree == 1)
  dnpvc.insert_vector(dnpv);

 //   if(dnpms.the_val.contains(dnpm))
 //   {
 //    qDebug() << "Old dnpm: ";
 //    qDebug() << Dock_Node_Pair_Map_inspect(dnpm);

 //    auto x = dnpms.the_val.keys()[0];
 //    qDebug() << "trying...";
 //    qDebug() << Dock_Node_Pair_Map_inspect(x);
 //    if(x == dnpm)
 //    {
 //     qDebug() << "EQ";
 //    }
 //    else
 //    {
 //     qDebug() << "NE";
 //    }

 //    int v = dnpms.the_val.value(dnpm);
 //    dnpms.the_val.insert(dnpm, v + 1);
 //   }
 //   else
 //   {
 //    qDebug() << "New dnpm: ";
 //    qDebug() << Dock_Node_Pair_Map_inspect(dnpm);
 //    dnpms.the_val[dnpm] = 1;
 //   }

 //   qDebug() << "\nDNPM: " << Dock_Node_Pair_Map_inspect(dnpm);
 //   ++(dnpms.the_val[dnpm]);

 //   qDebug() << "\n\nDNPMS: " << dnpms.inspect();
 //   qDebug() << "\n==========\n";
}

void NL_Gecode_Solver::print() const
{
 static int count = 0;
 ++count;

 int i = 0;

 QString summary;

 std::stringstream ss;
 //? ss << words_iva_;
 ss << sources_nodes_iva_;
 ss << targets_nodes_iva_;
 summary += "words:" + QString::fromStdString(ss.str());

 ss.str(std::string());
 //?ss << lexclass_iva_;
 ss << sources_lexclass_iva_;
 ss << targets_lexclass_iva_;
 summary += "lexclasses:" + QString::fromStdString(ss.str());

 ss.str(std::string());
 //?ss << lexclass_iva_;
 ss << lex_class_array_;
 summary += "lca:" + QString::fromStdString(ss.str());
// ss.str(std::string());
// ss << lex_class_array_with_NA_option_;
// summary += "lca-NA:" + QString::fromStdString(ss.str());
 summary += "\n";

 ss.str(std::string());
 //?ss << lexclass_iva_;
 ss << sources_interpretations_iva_;
 summary += "s-Interpretations:" + QString::fromStdString(ss.str());
 summary += "\n";

 ss.str(std::string());
 //?ss << lexclass_iva_;
 ss << targets_interpretations_iva_;
 summary += "t-Interpretations:" + QString::fromStdString(ss.str());
 summary += "\n";

 ss.str(std::string());
 //?ss << lexclass_iva_;
 ss << words_interpretations_iva_;
 summary += "w-Interpretations:" + QString::fromStdString(ss.str());
 summary += "\n";



 ss.str(std::string());
 //?ss << lexclass_iva_;
 ss << words_index_array_;
 summary += "wia:" + QString::fromStdString(ss.str());
 ss.str(std::string());
 //?ss << lexclass_iva_;
 ss << sources_words_iva_;
 summary += "swi:" + QString::fromStdString(ss.str());
 ss.str(std::string());
 //?ss << lexclass_iva_;
 ss << targets_words_iva_;
 summary += "twi:" + QString::fromStdString(ss.str());

 summary += "\n";

 ss.str(std::string());
 //?ss << lexclass_iva_;
 ss << sources_lambdas_lex_class_array_;
 summary += "sllca:" + QString::fromStdString(ss.str());
 ss.str(std::string());
 //?ss << lexclass_iva_;
 ss << sources_lambdas_lexclass_iva_;
 summary += "!sllciva:" + QString::fromStdString(ss.str());
 ss.str(std::string());
 //?ss << lexclass_iva_;
 ss << targets_profiles_lex_class_array_;
 summary += "\ntplca:" + QString::fromStdString(ss.str());
 ss.str(std::string());
 //?ss << lexclass_iva_;
 ss << targets_profiles_lexclass_iva_;
 summary += "!tplciva:" + QString::fromStdString(ss.str());
 ss.str(std::string());

 ss << targets_rewinding_lex_class_array_;
 summary += "trlca:" + QString::fromStdString(ss.str());
 ss.str(std::string());
 ss << targets_rewinding_lexclass_iva_;
 summary += "!trlciva:" + QString::fromStdString(ss.str());
 ss.str(std::string());

 ss << targets_rewinding_flags_bva_;
 summary += "!trfbva:" + QString::fromStdString(ss.str());


 ss.str(std::string());
 //?ss << lexclass_iva_;
 ss << pair_merge_iva_;
 summary += "pair_merge_iva:" + QString::fromStdString(ss.str());

 summary += "\n";

 ss.str(std::string());
 //?ss << lexclass_iva_;
 ss << sources_lambda_offsets_array_;
 summary += "sloa:" + QString::fromStdString(ss.str());
 ss.str(std::string());
 ss << sources_lambda_offsets_iva_;
 summary += "sloi:" + QString::fromStdString(ss.str());

 ss.str(std::string());
 //?ss << lexclass_iva_;
 ss << sources_rewind_offsets_array_;
 summary += "sroa:" + QString::fromStdString(ss.str());
 ss.str(std::string());
 ss << sources_rewind_offsets_iva_;
 summary += "sroi:" + QString::fromStdString(ss.str());

 ss.str(std::string());
 ss << sources_lambda_comp_offsets_iva_;
 summary += "slcoi:" + QString::fromStdString(ss.str());

 summary += "\n";
 //?ss << lexclass_iva_;

 //?   for(IntVar iv : words_iva_)
 //?#ifdef HIDE
 for(IntVar iv : sources_nodes_iva_)
 {
  int s_lambda_offset;
  int s_rewind_level;
  int s_interp = sources_interpretations_iva_[i].val();

  summary += get_dock_node_lexentry(iv.val(), s_interp, s_lambda_offset, s_rewind_level)->lexword();
  summary += QString("#%1-%2,%3").arg(s_lambda_offset).arg(s_rewind_level).arg(s_interp);
  summary += ":"
    + get_lexclass_string(sources_lexclass_iva_[i].val()) + ",";


  int t_lambda_offset;
  int t_rewind_level;
  int t_interp = targets_interpretations_iva_[i].val();

  summary += get_dock_node_lexentry(targets_nodes_iva_[i].val(), t_interp, t_lambda_offset, t_rewind_level)->lexword();
  summary += QString("#%1-%2,%3").arg(t_lambda_offset).arg(t_rewind_level).arg(t_interp);

  if(targets_lexclass_iva_[i].assigned())
  {
   summary += ":" + get_lexclass_string(targets_lexclass_iva_[i].val()) + " ";
  }
  else
  {
   summary += ":NA ";
  }

  if(count == 17)
  {
   qDebug() << "!!!";
  }

  ++i;
 }

//?
// QFile qf("/home/nlevisrael/NDP/tmp1.txt");
// if(qf.open(QIODevice::Append))
// {
//  QTextStream stream( &qf );
//  stream << summary;
//  qf.close();
// }



 summary += "\n";

 //?#endif // HIDE
 qDebug().noquote() << summary;
}


