
#ifndef NL_GECODE_SOLVER__H
#define NL_GECODE_SOLVER__H

#include "rzns.h"

#include "nl-dock-matrix.h"

//Touseintegervariablesandconstraints
#include<gecode/int.hh>
//Tomakemodelingmorecomfortable
#include<gecode/minimodel.hh>
//Tousesearchengines
#include<gecode/search.hh>
//ToavoidtypingGecode::allthetime

#include <map>

#include <QDebug>
#include <QVector>
#include <QMap>
#include <QString>
#include <QStringList>

#include <boost/algorithm/string.hpp>

using namespace Gecode;


RZNS_(NLG)

class NL_Gecode_Lexicon;
class NL_Gecode_Lexentry;

class NL_Gecode_Solver : public Space
{
protected:
 IntVarArray lambda_position_iva_;
 IntVarArray rewind_level_iva_;

 IntVarArray sources_nodes_iva_;
 //?
 IntVarArray sources_words_iva_;

 IntVarArray sources_lexclass_iva_;
 IntVarArray sources_lambdas_lexclass_iva_;

 IntVarArray targets_nodes_iva_;
 //?
 IntVarArray targets_words_iva_;

 IntVarArray words_interpretations_iva_;

 IntVarArray targets_lexclass_iva_;
 IntVarArray targets_profiles_lexclass_iva_;
 IntVarArray targets_rewinding_lexclass_iva_;
 BoolVarArray targets_rewinding_flags_bva_;

  //?
//?
//? IntArgs lex_class_array_with_NA_option_;
 //??
 IntArgs lex_class_array_;

//? IntArgs lex_class_array_;

 //?Matrix<IntArgs> lex_class_matrix_;

 //?IntVarArray lex_class_array_;
 IntArgs words_index_array_;
 IntArgs targets_words_array_;

 IntArgs sources_lambdas_lex_class_array_;
 IntArgs targets_profiles_lex_class_array_;
 IntArgs targets_rewinding_lex_class_array_;


 IntArgs lambda_position_array_;

 IntVarArray sources_rewind_offsets_iva_;
 IntVarArray sources_lambda_offsets_iva_;
 IntVarArray sources_lambda_comp_offsets_iva_;

 IntVarArray sources_interpretations_iva_;
 IntVarArray targets_interpretations_iva_;

 IntVarArray pair_merge_iva_;

 IntArgs sources_lambda_offsets_array_;
 IntArgs sources_rewind_offsets_array_;


 // first int is order; second is count
 QMap<NL_Gecode_Lexentry*, QPair<int, int> > sentence_words_distinct_;
 QVector<NL_Gecode_Lexentry*> inverse_sentence_words_distinct_;

 QMultiMap<NL_Gecode_Lexentry*, int> sentence_words_;
 QVector<NL_Gecode_Lexentry*> inverse_sentence_words_;

 QVector<int> inverse_sentence_words_index_;

 QMap<int, NL_Gecode_Dock_Node> sentence_nodes_;
 QVector<NL_Gecode_Dock_Node> inverse_sentence_nodes_;

 NL_Gecode_Lexicon* lexicon_;

 static constexpr int maximum_arity = 2;
 static constexpr int maximum_rewind = 1;
 //?static constexpr int NL_Gecode_Lexclass*_count = 4;
 static constexpr int max_lambda_offset = 10000;

 int invalid_pairs_count_;

public:

 NL_Gecode_Lexentry* get_sentence_word_as_lexentry(int key) const;

 const NL_Gecode_Dock_Node& get_dock_node(int key) const;

 void register_interpretations();

 NL_Gecode_Lexentry* get_dock_node_lexentry(int key, int interpretation, int& lambda_offset, int& rewind_level) const;

 int NL_get_sentence_word_by_index(int key) const;
 int get_sentence_word_by_index(int key) const;

 NL_Gecode_Lexentry* test_prune_rewinds() const;


 int find_sentence_word_in_sentence(NL_Gecode_Lexentry* lge, int which);
 int get_count_of_sentence_word_in_sentence(NL_Gecode_Lexentry* lge);

// static NL_Gecode_Lexclass* get_lexclass_by_word(QString word);

 NL_Gecode_Lexclass* get_lexclass_by_sentence_word_key(int key, int interpretation);

 NL_Gecode_Lexclass* get_lexclass_by_node_word_key(int key,
   int interpretation,
   int& lambda_offset, int& rewind_level);

 int get_lexclass_int_from_lexentry(NL_Gecode_Lexentry* nle);

 //QString get_lexclass_string(NL_Gecode_Lexclass* lc) const;
 QString get_lexclass_string(int nc) const;

 NL_Gecode_Lexclass* get_profile_for_lexclass(NL_Gecode_Lexclass* lc, int rewind_level = 0);

 NL_Gecode_Lexclass* get_rewind_for_lexclass(NL_Gecode_Lexclass* lc, int rewind_level = 0);

 NL_Gecode_Lexclass* get_match_for_lexclass(NL_Gecode_Lexclass* lc, int lambda_position, int rewind_level = 0);

 int get_arity_for_lexclass(NL_Gecode_Lexclass* lc, int rewind_level = 0);
 int get_total_arity(NL_Gecode_Lexclass* lc, QMap<int, QPair<int, int> >& arities);

 // static int get_total_arity(QString word);

 int get_arity_for_lexclass_0(NL_Gecode_Lexclass* lc);

 int get_arity_for_lexclass_1(NL_Gecode_Lexclass* lc);

 NL_Gecode_Solver(bool share, NL_Gecode_Solver& s);
 NL_Gecode_Solver(NL_Gecode_Lexicon* lexicon, QString sentence);
 void print() const;
 virtual Space* copy(bool share);
 void merge_with_dock_node_set(NL_Gecode_Dock_Node_Pair_Vector_Collection& dnpvc) const;

};

_RZNS(NLG)



#endif
