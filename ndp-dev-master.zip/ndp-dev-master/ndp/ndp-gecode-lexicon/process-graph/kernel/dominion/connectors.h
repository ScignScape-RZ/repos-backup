

DOMINION_CONNECTOR(N_A, "No Connection")

DOMINION_CONNECTOR(Dock_Call_Entry, "dock-call-entry")
DOMINION_CONNECTOR(Dock_Call_Sequence, "dock-call-sequence")
DOMINION_CONNECTOR(Dock_Cross_Sequence, "dock-cross-sequence")
DOMINION_CONNECTOR(Dock_Call_Continue, "dock-cross-continue")


DOMINION_CONNECTOR(CV_Subject_To_Verb, "cv-subject-to-verb")
DOMINION_CONNECTOR(CV_Direct_Object_To_Verb, "cv-direct-object-to-verb")
DOMINION_CONNECTOR(CV_Noun_To_Adjective, "cv-noun-to-adjective")
