

#define DOMINION_NODE_TYPE NL_Gecode_Process_Graph_Node

#ifndef DOMINION_HIDE_NO_NAMESPACE
// // No namespace
#include "rz-relae/dominion-macros.h"
DOMINION_TYPE(dbl, double, Double)
DOMINION_TYPE(integer, int, Int)
DOMINION_TYPE(i8, char, I8)
DOMINION_TYPE(qstring, QString, QStr)
#endif

#include "rz-relae/dominion-macros.h"

#define DOMINION_OUTER_NAMESPACE RZ


#define DOMINION_INNER_NAMESPACE NLG
#include "rz-relae/dominion-macros.h"
DOMINION_TYPE(nl_root, NL_Gecode_Process_Graph_Root, NL_Gecode_Process_Graph_Root)
DOMINION_TYPE(nl_node, NL_Gecode_Process_Node, NL_Gecode_Process_Node)
DOMINION_TYPE(nl_node_target, NL_Gecode_Process_Node_Target, NL_Gecode_Process_Node_Target)
DOMINION_TYPE(nl_contravein_node_target, NL_Gecode_Contravein_Node_Target, NL_Gecode_Contravein_Node_Target)

#undef DOMINION_INNER_NAMESPACE
#undef DOMINION_OUTER_NAMESPACE
#undef DOMINION_NODE_TYPE

