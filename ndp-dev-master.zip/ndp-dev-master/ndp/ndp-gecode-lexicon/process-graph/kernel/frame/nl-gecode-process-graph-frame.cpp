
#include "nl-gecode-process-graph-frame.h"

#include "process-graph/kernel/graph/nl-gecode-process-graph-node.h"

#include "rzns.h"

#include <QDebug>


USING_RZNS(NLG)

NL_Gecode_Process_Graph_Frame::NL_Gecode_Process_Graph_Frame()
 : node_frame<NL_Gecode_Process_Graph_Dominion>()
{
}

NL_Gecode_Process_Graph_Frame& NL_Gecode_Process_Graph_Frame::instance()
{
 static NL_Gecode_Process_Graph_Frame* the_instance = nullptr;
 if(!the_instance)
  the_instance = new NL_Gecode_Process_Graph_Frame;
 return *the_instance;
}
