
#ifndef NL_GECODE_PROCESS_GRAPH_FRAME__H
#define NL_GECODE_PROCESS_GRAPH_FRAME__H

//?#include "rz-re-frame.h"

#include "rz-relae/relae-node-ptr.h"

#include "process-graph/kernel/nl-gecode-process-graph-dominion.h"

#include "rzns.h"

RZNS_(NLG)


class NL_Gecode_Process_Graph_Frame : public node_frame<NL_Gecode_Process_Graph_Dominion>
{
 NL_Gecode_Process_Graph_Frame();
 // RE_Dominion::Connectors N_A;
 public:

 static NL_Gecode_Process_Graph_Frame& instance();

};

_RZNS(NLG)

#endif
