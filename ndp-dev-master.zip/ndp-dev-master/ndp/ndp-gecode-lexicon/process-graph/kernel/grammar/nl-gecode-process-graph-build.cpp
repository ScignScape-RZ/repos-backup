
#include "nl-gecode-process-graph-build.h"

#include "process-graph/nl-gecode-process-graph.h"
#include "process-graph/nl-gecode-process-node.h"
#include "process-graph/kernel/graph/nl-gecode-process-graph-node.h"
#include "process-graph/kernel/graph/nl-gecode-process-node-target.h"
#include "process-graph/kernel/graph/nl-gecode-contravein-node-target.h"
#include "nl-gecode-dock-node-pair.h"

#include <QtCore/qmath.h>

USING_RZNS(NLG)

NL_Gecode_Process_Graph_Build::NL_Gecode_Process_Graph_Build(
  NL_Gecode_Process_Graph& graph,
  NL_Gecode_Lexicon& lexicon,
  NL_Gecode_Contravein_Connector_Callback& contravein)
 : graph_(graph), lexicon_(lexicon), contravein_(contravein), current_state_(States::N_A),
   current_node_(nullptr), composite_weight_count_(0), discounts_total_(0),
   fr_(NL_Gecode_Process_Graph_Frame::instance()),
   nq_(NL_Gecode_Process_Graph_Query::instance())
{

}

QString NL_Gecode_Process_Graph_Build::check_abandonment_explanation_string()
{
 return graph_.abandonment_explanation_string();
}


void NL_Gecode_Process_Graph_Build::abandon(std::function<QString()> ae)
{
 graph_.set_abandonment_explanation(ae);
}

//void NL_Gecode_Process_Graph_Build::abandon(void* ae)
//{
// graph_.set_abandonment_explanation(ae);
//}

caon_ptr<NL_Gecode_Process_Graph_Node> NL_Gecode_Process_Graph_Build::register_dock_node_entry(const NL_Gecode_Dock_Node& dn,
  int wo, int rl, int lp)
{
 CAON_PTR_DEBUG(NL_Gecode_Process_Graph_Node ,current_node_)

// int rl;
// int lp;
// dn.get_rewind_level_and_lambda_position(rl, lp);

 caon_ptr<NL_Gecode_Process_Node> spn = new NL_Gecode_Process_Node(dn);
 caon_ptr<NL_Gecode_Process_Node_Target> sptn = new
   NL_Gecode_Process_Node_Target(*spn, wo, rl, lp);

 caon_ptr<NL_Gecode_Process_Graph_Node> sgn = new NL_Gecode_Process_Graph_Node(sptn);

 sgn->set_label(sptn->summary());
 if(current_node_)
 {
  switch(current_state_)
  {
  case States::Active_Chief:
   current_node_ << fr_/nq_.Dock_Cross_Sequence >> sgn;
   current_node_ = sgn;
   break;

  default:
   current_node_ << fr_/nq_.Dock_Call_Entry >> sgn;
   current_node_ = sgn;
   break;
  }
 }
 else
 {
  graph_.set_root_node(sgn);
  current_node_ = sgn;
 }
 current_state_ = States::Active_Token;
 chiefs_.push_back(current_node_);
 return sgn;
}

void NL_Gecode_Process_Graph_Build::check_contravein_callback(caon_ptr<NL_Gecode_Process_Graph_Node> tgn, caon_ptr<NL_Gecode_Process_Graph_Node> sgn)
{
 caon_ptr<NL_Gecode_Process_Node_Target> snt = sgn->nl_node_target();
 NL_Gecode_Process_Node& spn = snt->process_node();
 CAON_PTR_DEBUG(NL_Gecode_Process_Node_Target ,snt)

 NL_Gecode_Lexclass* nlc = spn.dock_node().lexclass_contingent_on_interpretation();
 NL_Gecode_Lexentry* nle = spn.dock_node().lexentry();

 qreal carried_discount = 0;

 QString inj_label;
 QString inj = contravein_.get_injection_script(nle, nlc, inj_label);
 if(!inj.isEmpty())
 {
  contravein_.script_callback()(*this, tgn, sgn,
    carried_discount, inj_label, inj);
 }

 if(contravein_.lexentry_callbacks().contains({nle, nlc}))
 {
  for(auto cb : contravein_.lexentry_callbacks().value({nle, nlc}))
  {
   QString label;
   QString inj = contravein_.get_injection_script(nle, nlc, label);
   cb(*this, tgn, sgn,
    carried_discount, label, inj);
  }
 }

 QString nlc_inj = contravein_.get_injection_script(nlc);
 if(!nlc_inj.isEmpty())
 {
  contravein_.script_callback()(*this, tgn, sgn,
    carried_discount, nlc->label(), nlc_inj);
 }

 if(contravein_.lexclass_callbacks().contains(nlc))
 {
  for(auto cb : contravein_.lexclass_callbacks().value(nlc))
  {
   QString label;
   QString inj = contravein_.get_injection_script(nle, nlc, label);
   cb(*this, tgn, sgn,
    carried_discount, label, inj);
  }
 }


}


void NL_Gecode_Process_Graph_Build::rewind_chiefs()
{
 CAON_PTR_DEBUG(NL_Gecode_Process_Graph_Node ,current_node_)

 if(!chiefs_.empty())
 {
  current_node_ = chiefs_.top();
  chiefs_.pop();
  current_state_ = States::Active_Chief;
 }

}


void NL_Gecode_Process_Graph_Build::absorb_dock_node_pair_rce(NL_Gecode_Dock_Node_Pair& dnp,
  int wo, int rl, int lp)
{
 CAON_PTR_DEBUG(NL_Gecode_Process_Graph_Node ,current_node_)

 caon_ptr<NL_Gecode_Process_Node> psn = new NL_Gecode_Process_Node(dnp.source_node());

 caon_ptr<NL_Gecode_Process_Graph_Node> gsn = new NL_Gecode_Process_Graph_Node(psn);
 gsn->set_label(psn->summary());

 caon_ptr<NL_Gecode_Process_Node> ptn = new NL_Gecode_Process_Node(dnp.target_node());
 caon_ptr<NL_Gecode_Process_Node_Target> pttn = new
   NL_Gecode_Process_Node_Target(*ptn, wo, rl, lp);

 caon_ptr<NL_Gecode_Process_Graph_Node> gtn = new NL_Gecode_Process_Graph_Node(pttn);
 gtn->set_label(pttn->summary());

 gsn << fr_/nq_.Dock_Call_Entry >> gtn;

 if(current_node_)
 {
  current_node_ <<fr_/nq_.Dock_Call_Entry>> gsn;
 }
 else
 {
  current_node_ = gsn;
  graph_.set_root_node(gsn);
 }

 current_state_ = States::Active_Token;
}


caon_ptr<NL_Gecode_Process_Graph_Node> NL_Gecode_Process_Graph_Build::absorb_dock_node_pair_rcs(NL_Gecode_Dock_Node_Pair& dnp,
  int wo, int rl, int lp)
{
 CAON_PTR_DEBUG(NL_Gecode_Process_Graph_Node ,current_node_)
//?
// caon_ptr<NL_Gecode_Process_Node> psn = new NL_Gecode_Process_Node(dnp.source_node());
// caon_ptr<NL_Gecode_Process_Graph_Node> gsn = new NL_Gecode_Process_Graph_Node(psn);

// gsn->set_label(psn->summary());

 caon_ptr<NL_Gecode_Process_Node> ptn = new NL_Gecode_Process_Node(dnp.target_node());
 caon_ptr<NL_Gecode_Process_Node_Target> pttn = new
   NL_Gecode_Process_Node_Target(*ptn, wo, rl, lp);

 caon_ptr<NL_Gecode_Process_Graph_Node> gtn = new NL_Gecode_Process_Graph_Node(pttn);
 gtn->set_label(pttn->summary());

 switch(current_state_)
 {
 case States::Active_Chief:
  current_node_ << fr_/nq_.Dock_Call_Continue >> gtn;

  break;
 default:
  current_node_ << fr_/nq_.Dock_Call_Sequence >> gtn;
  break;

 }

 current_node_ = gtn;

 current_state_ = States::Active_Token;

 return gtn;
}

void NL_Gecode_Process_Graph_Build::finalize_discounts()
{
 if(!discounts_.isEmpty())
 {
  qreal ratio = discounts_total_/discounts_.size();
  qreal adjustment = 0;
  for(int i = 0; i < discounts_.size(); ++i)
  {
   qreal exp = qPow(ratio, i + 1);
   adjustment += exp;
  }
  graph_.adjust_composite_weight(-adjustment);
 }
}

void NL_Gecode_Process_Graph_Build::contravein_join(QString connector_label,
  caon_ptr<NL_Gecode_Process_Graph_Node> tn,
  caon_ptr<NL_Gecode_Process_Graph_Node> sn,
  qreal discount
  )
{
 const NL_Gecode_Process_Graph_Connectors& conn = nq_.get_connector_by_label(connector_label);
 if(conn != nq_.N_A)
 {
  contravein_join(conn, tn, sn, discount);
 }
}


void NL_Gecode_Process_Graph_Build::contravein_join(
  const NL_Gecode_Process_Graph_Connectors& connector,
  caon_ptr<NL_Gecode_Process_Graph_Node> tn,
  caon_ptr<NL_Gecode_Process_Graph_Node> sn, qreal discount)
{
 if(caon_ptr<NL_Gecode_Process_Node_Target> ttn = tn->nl_node_target())
 {
  if(discount != 0)
  {
   discounts_.push_back(discount);
   discounts_total_ += discount;
  }
  //graph_.adjust_composite_weight(-discount);
  ++composite_weight_count_;

  CAON_PTR_DEBUG(NL_Gecode_Process_Node_Target ,ttn)

  NL_Gecode_Process_Node_Target& rttn = *ttn;

  caon_ptr<NL_Gecode_Process_Node_Target> snt = sn->nl_node_target();

  CAON_PTR_DEBUG(NL_Gecode_Process_Node_Target ,snt)

  NL_Gecode_Process_Node& tnn = ttn->process_node();

  NL_Gecode_Process_Node& spn = snt->process_node();

  caon_ptr<NL_Gecode_Contravein_Node_Target> cnt =
    new NL_Gecode_Contravein_Node_Target(spn, discount);


  caon_ptr<NL_Gecode_Process_Graph_Node> sng =
    new NL_Gecode_Process_Graph_Node(cnt);


  tn << fr_/connector >> sng;
 }
}

void NL_Gecode_Process_Graph_Build::join_noun_to_adjective(
  caon_ptr<NL_Gecode_Process_Graph_Node> tn,
  caon_ptr<NL_Gecode_Process_Graph_Node> sn, qreal discount)
{
 contravein_join(nq_.CV_Noun_To_Adjective, tn, sn, discount);
}

void NL_Gecode_Process_Graph_Build::join_subject_to_verb(
  caon_ptr<NL_Gecode_Process_Graph_Node> tn,
  caon_ptr<NL_Gecode_Process_Graph_Node> sn, qreal discount)
{
 contravein_join(nq_.CV_Subject_To_Verb, tn, sn, discount);
}

void NL_Gecode_Process_Graph_Build::join_direct_object_to_verb(
  caon_ptr<NL_Gecode_Process_Graph_Node> tn,
  caon_ptr<NL_Gecode_Process_Graph_Node> sn, qreal discount)
{


 if(caon_ptr<NL_Gecode_Process_Node_Target> ttn = tn->nl_node_target())
 {
  contravein_join(nq_.CV_Direct_Object_To_Verb, tn, sn, discount);
 }
}
