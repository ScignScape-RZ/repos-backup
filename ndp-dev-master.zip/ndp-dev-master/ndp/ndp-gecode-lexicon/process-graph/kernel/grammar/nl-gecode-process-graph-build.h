
#ifndef NL_GECODE_PROCESS_GRAPH_BUILD__H
#define NL_GECODE_PROCESS_GRAPH_BUILD__H

#include "rzns.h"

#include <functional>

#include <QString>
#include <QVector>
#include <QStack>
#include <QMap>

#include "accessors.h"

#include "nl-gecode-lexclass.h"

#include "nl-gecode-lexentry.h"

#include "nl-gecode-lexclass-vector.h"

#include "process-graph/kernel/frame/nl-gecode-process-graph-frame.h"
#include "process-graph/kernel/query/nl-gecode-process-graph-query.h"

#include "rz-relae/relae-node-ptr.h"
#include "rz-relae/relae-caon-ptr.h"

#include "process-graph/nl-gecode-contravein-connector-callback.h"

RZNS_(NLG)


class NL_Gecode_Process_Graph;
class NL_Gecode_Process_Graph_Node;
class NL_Gecode_Process_Node;
class NL_Gecode_Dock_Node_Pair;
class NL_Gecode_Dock_Node;
class NL_Gecode_Lexicon;

class NL_Gecode_Process_Graph_Build
{
 enum class States {
  N_A, Active_Token, Active_Chief
 };


 caon_ptr<NL_Gecode_Process_Graph_Node> current_node_;

 QList<caon_ptr<NL_Gecode_Process_Graph_Node>> nodes_;

 QList<qreal> discounts_;

 qreal discounts_total_;

 NL_Gecode_Process_Graph_Frame& fr_;
 const NL_Gecode_Process_Graph_Query& nq_;

 NL_Gecode_Process_Graph& graph_;

 States current_state_;

 QStack<caon_ptr<NL_Gecode_Process_Graph_Node>> chiefs_;

 NL_Gecode_Lexicon& lexicon_;
 NL_Gecode_Contravein_Connector_Callback& contravein_;

 int composite_weight_count_;

public:

 NL_Gecode_Process_Graph_Build(NL_Gecode_Process_Graph& graph,
   NL_Gecode_Lexicon& lexicon, NL_Gecode_Contravein_Connector_Callback& contravein);

 ACCESSORS__GET(qreal ,discounts_total)


//? void abandon(void* ae);
 void abandon(std::function<QString()> ae);

 void absorb_dock_node_pair_rce(NL_Gecode_Dock_Node_Pair& dnp, int wo, int rl, int lp);
 caon_ptr<NL_Gecode_Process_Graph_Node> absorb_dock_node_pair_rcs(NL_Gecode_Dock_Node_Pair& dnp, int wo, int rl, int lp);

 caon_ptr<NL_Gecode_Process_Graph_Node> register_dock_node_entry(const NL_Gecode_Dock_Node& dn, int wo, int rl, int lp);

 void rewind_chiefs();

 void check_contravein_callback(caon_ptr<NL_Gecode_Process_Graph_Node> tgn, caon_ptr<NL_Gecode_Process_Graph_Node> sgn);

 void join_subject_to_verb(
   caon_ptr<NL_Gecode_Process_Graph_Node> tn,
   caon_ptr<NL_Gecode_Process_Graph_Node> sn,
   qreal discount = 0
   );

 void join_direct_object_to_verb(
   caon_ptr<NL_Gecode_Process_Graph_Node> tn,
   caon_ptr<NL_Gecode_Process_Graph_Node> sn,
   qreal discount = 0
   );

 void join_noun_to_adjective(
   caon_ptr<NL_Gecode_Process_Graph_Node> tn,
   caon_ptr<NL_Gecode_Process_Graph_Node> sn,
   qreal discount = 0);


 void contravein_join(const NL_Gecode_Process_Graph_Connectors& connector,
   caon_ptr<NL_Gecode_Process_Graph_Node> tn,
   caon_ptr<NL_Gecode_Process_Graph_Node> sn,
   qreal discount = 0
   );

 void contravein_join(QString connector_label,
   caon_ptr<NL_Gecode_Process_Graph_Node> tn,
   caon_ptr<NL_Gecode_Process_Graph_Node> sn,
   qreal discount = 0
   );

 void finalize_discounts();

 QString check_abandonment_explanation_string();

};


_RZNS(NLG)



#endif
