
#include "nl-gecode-contravein-node-target.h"
#include "process-graph/nl-gecode-process-node.h"

USING_RZNS(NLG)

NL_Gecode_Contravein_Node_Target::NL_Gecode_Contravein_Node_Target(NL_Gecode_Process_Node& process_node,
  qreal discount)
 : process_node_(process_node), discount_(discount)
{

}

QString NL_Gecode_Contravein_Node_Target::summary()
{
 return process_node_.dock_node().lexentry()->lexword();
}

QString NL_Gecode_Contravein_Node_Target::lexword()
{
 return process_node_.dock_node().lexentry()->lexword();
}
