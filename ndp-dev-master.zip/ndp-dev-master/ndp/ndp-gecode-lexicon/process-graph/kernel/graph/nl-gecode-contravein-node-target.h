
#ifndef NL_GECODE_CONTRAVEIN_NODE_TARGET__H
#define NL_GECODE_CONTRAVEIN_NODE_TARGET__H

#include "rzns.h"

#include <functional>

#include <QString>

#include <QMap>

#include "accessors.h"

#include "nl-gecode-lexclass.h"
#include "nl-gecode-lexentry.h"
#include "nl-gecode-lexclass-vector.h"
#include "nl-gecode-dock-node.h"


RZNS_(NLG)

class NL_Gecode_Process_Node;


class NL_Gecode_Contravein_Node_Target
{
 NL_Gecode_Process_Node& process_node_;

 qreal discount_;

public:

 //?NL_Gecode_Process_Node(NL_Gecode_Dock_Node dock_node);
 NL_Gecode_Contravein_Node_Target(NL_Gecode_Process_Node& process_node,
   qreal discount = 0);

 ACCESSORS__GET(NL_Gecode_Process_Node& ,process_node)

 QString summary();

 QString lexword();

};


_RZNS(NLG)



#endif
