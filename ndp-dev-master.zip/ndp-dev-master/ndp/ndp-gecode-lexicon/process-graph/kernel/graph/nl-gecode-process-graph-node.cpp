
#include "nl-gecode-process-graph-node.h"

#include "process-graph/nl-gecode-process-node.h"
#include "process-graph/kernel/graph/nl-gecode-process-node-target.h"

#include "nl-gecode-dock-node.h"

#include "rzns.h"
USING_RZNS(NLG)

void NL_Gecode_Process_Graph_Node::each_connection(std::function<void(const NL_Gecode_Process_Graph_Connectors& connector,
 const NL_Gecode_Process_Graph_Node&)> fn) const
{
 targets_iterator_type it(targets_);
 while(it.hasNext())
 {
  it.next();
  const NL_Gecode_Process_Graph_Connectors& connector = *it.key();
  const NL_Gecode_Process_Graph_Node& target = *it.value();
  fn(connector, target);
 }
}

void NL_Gecode_Process_Graph_Node::write_to_sexp_string(QString& result)
{
 if(caon_ptr<NL_Gecode_Process_Node_Target> n = nl_node_target() )
 {
  result += n->lexword();
 }
}



void NL_Gecode_Process_Graph_Node::debug_connections()
{
 targets_iterator_type it(targets_);
 while(it.hasNext())
 {
  it.next();
  CAON_EVALUATE_DEBUG(NL_Gecode_Process_Graph_Connectors ,key ,it.key())
  CAON_EVALUATE_DEBUG(NL_Gecode_Process_Graph_Node ,value ,it.value())
  //?QString val = value.label();
 }
}


void NL_Gecode_Process_Graph_Node::swap_relation(const NL_Gecode_Process_Graph_Connectors& connector,
 caon_ptr<NL_Gecode_Process_Graph_Node> n1, caon_ptr<NL_Gecode_Process_Graph_Node> n2)
{
 CAON_PTR_DEBUG(NL_Gecode_Process_Graph_Node ,n1)
 CAON_PTR_DEBUG(NL_Gecode_Process_Graph_Node ,n2)


 #ifdef NO_CAON
   NL_Gecode_Process_Graph_Connectors* pc = const_cast<NL_Gecode_Process_Graph_Connectors*>( &connector );
   targets_.remove(pc, n1);
   targets_.insert(pc, n2);
 #else
  targets_.remove(&connector, n1);
  targets_.insert(&connector, n2);
 #endif //NO_CAON

 //caon_ptr<RE_Node>& old = n1->targets_.
}


void NL_Gecode_Process_Graph_Node::delete_relation(const NL_Gecode_Process_Graph_Connectors& connector,
 caon_ptr<NL_Gecode_Process_Graph_Node> n1)
{
 CAON_PTR_DEBUG(NL_Gecode_Process_Graph_Node ,n1)
  #ifdef NO_CAON
    NL_Gecode_Process_Graph_Connectors* pc = const_cast<NL_Gecode_Process_Graph_Connectors*>( &connector );
    targets_.remove(pc, n1);
  #else
   targets_.remove(&connector, n1);
  #endif //NO_CAON
}

