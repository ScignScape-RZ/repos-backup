
#ifndef NL_GECODE_PROCESS_GRAPH_NODE__H
#define NL_GECODE_PROCESS_GRAPH_NODE__H

#include "rz-relae/relae-node-ptr.h"

#include "process-graph/kernel/nl-gecode-process-graph-dominion.h"

#include "process-graph/kernel/frame/nl-gecode-process-graph-frame.h"

#include "rzns.h"

//#include <functional>
//#include <QString>
//#include <QMap>
//#include "accessors.h"
//#include "nl-gecode-lexclass.h"
//#include "nl-gecode-lexentry.h"
//#include "nl-gecode-lexclass-vector.h"

RZNS_(NLG)

class NL_Gecode_Dock_Node;


class NL_Gecode_Process_Graph_Node: public node_ptr<NL_Gecode_Process_Graph_Dominion>
{
public:
 #define DOMINION_TYPE DOMINION_NODE_CONSTRUCTOR
 #include "process-graph/kernel/dominion/types.h"
 #undef DOMINION_TYPE

 void debug_connections();

//?
 void each_connection(std::function<void(const NL_Gecode_Process_Graph_Connectors& connector,
  const NL_Gecode_Process_Graph_Node&)> fn)  const;
 void swap_relation(const NL_Gecode_Process_Graph_Connectors& connector,
  caon_ptr<NL_Gecode_Process_Graph_Node> n1, caon_ptr<NL_Gecode_Process_Graph_Node> n2);
 void delete_relation(const NL_Gecode_Process_Graph_Connectors& connector,
  caon_ptr<NL_Gecode_Process_Graph_Node> n1);

 void write_to_sexp_string(QString& result);

};


_RZNS(NLG)

#endif

