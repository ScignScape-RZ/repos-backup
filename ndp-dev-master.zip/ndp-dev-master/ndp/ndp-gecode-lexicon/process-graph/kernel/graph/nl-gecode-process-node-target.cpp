
#include "nl-gecode-process-node-target.h"
#include "process-graph/nl-gecode-process-node.h"

USING_RZNS(NLG)

NL_Gecode_Process_Node_Target::NL_Gecode_Process_Node_Target(NL_Gecode_Process_Node& process_node,
  int word_offset, int rewind_level,
  int lambda_position)
 : process_node_(process_node),
   word_offset_(word_offset),
   rewind_level_(rewind_level),
   lambda_position_(lambda_position)
{

}

QString NL_Gecode_Process_Node_Target::summary()
{
 return process_node_.dock_node().lexentry()->lexword();
}

QString NL_Gecode_Process_Node_Target::lexword()
{
 return process_node_.dock_node().lexentry()->lexword();
}
