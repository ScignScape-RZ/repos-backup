
#ifndef NL_GECODE_PROCESS_NODE_TARGET__H
#define NL_GECODE_PROCESS_NODE_TARGET__H

#include "rzns.h"

#include <functional>

#include <QString>

#include <QMap>

#include "accessors.h"

#include "nl-gecode-lexclass.h"
#include "nl-gecode-lexentry.h"
#include "nl-gecode-lexclass-vector.h"
#include "nl-gecode-dock-node.h"


RZNS_(NLG)

class NL_Gecode_Process_Node;


class NL_Gecode_Process_Node_Target
{
 NL_Gecode_Process_Node& process_node_;

 int word_offset_;
 int rewind_level_;
 int lambda_position_;

public:

 //?NL_Gecode_Process_Node(NL_Gecode_Dock_Node dock_node);
 NL_Gecode_Process_Node_Target(NL_Gecode_Process_Node& process_node,
   int word_offset, int rewind_level,
   int lambda_position);


 ACCESSORS(int ,word_offset)
 ACCESSORS(int ,rewind_level)
 ACCESSORS(int ,lambda_position)

 ACCESSORS__GET(NL_Gecode_Process_Node& ,process_node)


 QString summary();

 QString lexword();

};


_RZNS(NLG)



#endif
