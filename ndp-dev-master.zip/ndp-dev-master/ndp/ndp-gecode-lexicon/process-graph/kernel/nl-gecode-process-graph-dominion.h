
#ifndef NL_GECODE_PROCESS_GRAPH_DOMINION__H
#define NL_GECODE_PROCESS_GRAPH_DOMINION__H


#include "rz-relae/relae-node-ptr.h"
#include "rz-relae/relae-caon-ptr.h"

#include "rzns.h"



#define DOMINION_HIDE_NO_NAMESPACE
#define DOMINION_TYPE DOMINION_TYPE_DECLARE
#include "dominion/types.h"
#undef DOMINION_TYPE
#undef DOMINION_HIDE_NO_NAMESPACE

RZNS_(NLG)

class NL_Gecode_Process_Graph_Root;
class NL_Gecode_Process_Graph_Node;
class NL_Gecode_Process_Graph_Frame;
class NL_Gecode_Process_Graph_Galaxy;
class NL_Gecode_Process_Graph;
class NL_Gecode_Process_Graph_Connectors;
class NL_Gecode_Process_Graph_Document;

struct NL_Gecode_Process_Graph_Dominion
{
 typedef NL_Gecode_Process_Graph_Galaxy Galaxy_type;
 typedef NL_Gecode_Process_Graph_Node Node_type;
 typedef NL_Gecode_Process_Graph_Frame Frame_type;
 typedef NL_Gecode_Process_Graph_Connectors Connectors_type;
 typedef NL_Gecode_Process_Graph_Document Document_type;
 typedef NL_Gecode_Process_Graph Graph_type;
 typedef NL_Gecode_Process_Graph_Root Root_type;

// struct Connectors : node_connectors<RE_Dominion> {

//    Connectors(QString label) : node_connectors<RE_Dominion>(label){}

// };

 enum class Type_Codes { N_A,
  #define DOMINION_TYPE DOMINION_TYPE_ENUM
  #include "dominion/types.h"
  #undef DOMINION_TYPE
 };

 template<typename T>
 Type_Codes get_type_code()
 {
 }
 //typedef Test_Connector Connector_Type;
 // typedef Test_Type_Codes Connector_Type;

};



struct NL_Gecode_Process_Graph_Galaxy : Node_Ptr_Default_Galaxy<NL_Gecode_Process_Graph_Dominion>
{

};

enum class NL_Gecode_Process_Graph_Connectors_Case_Labels
{
 #define DOMINION_CONNECTOR(name, label) \
  name,
 #include "process-graph/kernel/dominion/connectors.h"
 #undef DOMINION_CONNECTOR
};

struct NL_Gecode_Process_Graph_Connectors : node_connectors<NL_Gecode_Process_Graph_Dominion>
{
  NL_Gecode_Process_Graph_Connectors(NL_Gecode_Process_Graph_Connectors_Case_Labels cl = NL_Gecode_Process_Graph_Connectors_Case_Labels::N_A,
    QString label = QString())
   : node_connectors<NL_Gecode_Process_Graph_Dominion>(label), case_label(cl),
     priority(0), order(0){}
  NL_Gecode_Process_Graph_Connectors_Case_Labels case_label;
  int priority;
  int order;
  bool operator<(const NL_Gecode_Process_Graph_Connectors& rhs) const
  {
   return order < rhs.order;
  }
  operator bool() const
  {
   return order > 0;
  }
};


//class RE_Node : public node_ptr<RE_Dominion>
//{
//public:
// #define DOMINION_TYPE DOMINION_NODE_CONSTRUCTOR
// #include "dominion/types.h"
// #undef DOMINION_TYPE
//};

_RZNS(NLG)


#endif
