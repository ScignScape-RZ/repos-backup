
#include "nl-gecode-process-graph-root.h"

#include "rzns.h"

USING_RZNS(NLG)

NL_Gecode_Process_Graph_Root::NL_Gecode_Process_Graph_Root(QString nl_file,
  QString lexicon_file)
 : nl_file_(nl_file), lexicon_file_(lexicon_file)
{

}

