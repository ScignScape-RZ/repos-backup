
#ifndef NL_GECODE_PROCESS_GRAPH_ROOT__H
#define NL_GECODE_PROCESS_GRAPH_ROOT__H


#include "rz-relae/relae-node-ptr.h"

#include "nl-gecode-process-graph-dominion.h"

#include "rzns.h"

#include "accessors.h"

RZNS_(NLG)

class NL_Gecode_Process_Graph_Root
{
 QString nl_file_;
 QString lexicon_file_;

public:

 NL_Gecode_Process_Graph_Root(QString nl_file,
   QString lexicon_file);

 ACCESSORS(QString ,nl_file)
 ACCESSORS(QString ,lexicon_file)

};

_RZNS(RECore)


#endif
