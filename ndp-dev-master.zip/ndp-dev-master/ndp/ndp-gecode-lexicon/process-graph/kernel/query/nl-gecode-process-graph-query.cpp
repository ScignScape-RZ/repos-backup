
#include "nl-gecode-process-graph-query.h"

#include "rzns.h"


USING_RZNS(NLG)


NL_Gecode_Process_Graph_Query::NL_Gecode_Process_Graph_Query()
 : node_query<NL_Gecode_Process_Graph_Dominion>()
  #define DOMINION_CONNECTOR(name, label) \
    ,name(NL_Gecode_Process_Graph_Connectors(NL_Gecode_Process_Graph_Connectors_Case_Labels::name, label))
  #include "process-graph/kernel/dominion/connectors.h"
  #undef DOMINION_CONNECTOR
{
 int order = 0;
 #define DOMINION_CONNECTOR(name, label) \
  name.order = order; \
  ++order;
 #include "process-graph/kernel/dominion/connectors.h"
 #undef DOMINION_CONNECTOR
}

const NL_Gecode_Process_Graph_Connectors& NL_Gecode_Process_Graph_Query::get_connector_by_label(QString label) const
{
 static QMap<QString, NL_Gecode_Process_Graph_Connectors> static_map {{
   #define DOMINION_CONNECTOR(name, label) \
   { label, name },
   #include "process-graph/kernel/dominion/connectors.h"
   #undef DOMINION_CONNECTOR
   }};

 if(static_map.contains(label))
 {
  return static_map[label];
 }
 else
 {
  return this->N_A;
 }
 // return static_map.value(label, N_A);
}

const NL_Gecode_Process_Graph_Query& NL_Gecode_Process_Graph_Query::instance()
{
 static NL_Gecode_Process_Graph_Query* the_instance = nullptr;
 if(!the_instance)
  the_instance = new NL_Gecode_Process_Graph_Query;
 return *the_instance;
}
