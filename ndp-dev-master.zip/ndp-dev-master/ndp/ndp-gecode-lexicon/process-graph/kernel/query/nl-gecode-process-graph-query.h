
#ifndef NL_GECODE_PROCESS_GRAPH_QUERY__H
#define NL_GECODE_PROCESS_GRAPH_QUERY__H

#include "process-graph/kernel/nl-gecode-process-graph-dominion.h"

#include "rz-relae/relae-node-ptr.h"

#include "rzns.h"

RZNS_(NLG)

//class RE_Connector
//{
// //public:
// QString label_;

// public:
//  RE_Connector(QString label) : label_(label){}

//};

//template<type

class NL_Gecode_Process_Graph_Query : public node_query<NL_Gecode_Process_Graph_Dominion>
{
 NL_Gecode_Process_Graph_Query();
 // RE_Dominion::Connectors N_A;
 public:
  #define DOMINION_CONNECTOR(name, label) \
   NL_Gecode_Process_Graph_Connectors name;
  #include "process-graph/kernel/dominion/connectors.h"
  #undef DOMINION_CONNECTOR

 const NL_Gecode_Process_Graph_Connectors& get_connector_by_label(QString label) const;

 static const NL_Gecode_Process_Graph_Query& instance();
};

_RZNS(NLG)

#endif
