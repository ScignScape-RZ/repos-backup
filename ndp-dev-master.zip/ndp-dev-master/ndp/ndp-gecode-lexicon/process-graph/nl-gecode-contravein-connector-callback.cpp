
#include "nl-gecode-contravein-connector-callback.h"

#include "nl-gecode-lexicon.h"

#include <QMultiMap>
#include <QTextStream>

USING_RZNS(NLG)

NL_Gecode_Contravein_Connector_Callback::NL_Gecode_Contravein_Connector_Callback(NL_Gecode_Lexicon& lexicon)
 : lexicon_(lexicon)
{
// QMapIterator<QString, QString> it(lexicon_.injection_scripts_());
// while(it.hasNext())
// {
//  it.next();
// }
}


void NL_Gecode_Contravein_Connector_Callback::write_rz_file(QString path)
{
 QFile outfile(path);
 if(outfile.open(QIODevice::WriteOnly))
 {
  QTextStream outstream(&outfile);
  QMapIterator<QString, QString> it(lexicon_.injection_scripts());
  while(it.hasNext())
  {
   it.next();
   outstream << "\nour ," << it.key() << " = "
     << it.value() << "\n;;\n";
  }
  outfile.close();
 }
}


void NL_Gecode_Contravein_Connector_Callback::finalize_lexgroups()
{
 QMapIterator<QString, NL_Gecode_Lexclass*> it(lexicon_.lexclasses());
 while(it.hasNext())
 {
  it.next();
  QString key = it.key();
  key.prepend("$~");
  if(lexicon_.injection_scripts().contains(key))
  {
   NL_Gecode_Lexclass* lc = it.value();
   lexclass_injection_scripts_.insert(lc, lexicon_.injection_scripts().value(key));
  }
 }


 for(QString key : lexicon_.lexgroups().keys())
 {
  if(lexicon_.injection_scripts().contains(key))
  {
   QStringList vals = lexicon_.lexgroups().values(key);
   for(QString new_key : vals)
   {
    int new_index = new_key.indexOf(':');
    if(new_index == -1)
    {
//?     if(lexclass_callbacks_.contains(lexicon_.find_lexclass(new_key)))
//     {
//      lexclass_callbacks_[lexicon_.find_lexclass(new_key)].push_back(script_callback_);
//     }
//     else
//     {
//      lexclass_callbacks_.insert(lexicon_.find_lexclass(new_key), {script_callback_});
//     }
    }
    else
    {
     QString new_word = new_key.left(new_index);
     QString new_lc = new_key.mid(new_index + 1);

     lexentry_injection_scripts_.insert(key,
       lexicon_.injection_scripts()[key]);

     lexentry_injection_script_labels_.insert({lexicon_.find_lexentry(new_word),
       lexicon_.find_lexclass(new_lc)},
       key);


//?
//     if(lexentry_callbacks_.contains({lexicon_.find_lexentry(new_word),
//                                     lexicon_.find_lexclass(new_lc)}))
//     {
//      lexentry_callbacks_[{lexicon_.find_lexentry(new_word),
//        lexicon_.find_lexclass(new_lc)}].push_back(script_callback_);
//     }
//     else
//     {
//      lexentry_callbacks_.insert({lexicon_.find_lexentry(new_word),
//        lexicon_.find_lexclass(new_lc)}, {script_callback_});
//     }

    }
   }
  }

  if(lexgroup_callbacks_.contains(key))
  {
   for(callback_type cb : lexgroup_callbacks_.value(key))
   {
    QStringList vals = lexicon_.lexgroups().values(key);
    for(QString new_key : vals)
    {
     int new_index = new_key.indexOf(':');
     if(new_index == -1)
     {
      if(lexclass_callbacks_.contains(lexicon_.find_lexclass(new_key)))
      {
       lexclass_callbacks_[lexicon_.find_lexclass(new_key)].push_back(cb);
      }
      else
      {
       lexclass_callbacks_.insert(lexicon_.find_lexclass(new_key), {cb});
      }
     }
     else
     {
      QString new_word = new_key.left(new_index);
      QString new_lc = new_key.mid(new_index + 1);
      if(lexentry_callbacks_.contains({lexicon_.find_lexentry(new_word),
                                      lexicon_.find_lexclass(new_lc)}))
      {
       lexentry_callbacks_[{lexicon_.find_lexentry(new_word),
         lexicon_.find_lexclass(new_lc)}].push_back(cb);
      }
      else
      {
       lexentry_callbacks_.insert({lexicon_.find_lexentry(new_word),
         lexicon_.find_lexclass(new_lc)}, {cb});
      }
     }
    }
   }
  }
 }
}

QString NL_Gecode_Contravein_Connector_Callback::get_injection_script(NL_Gecode_Lexentry* le, NL_Gecode_Lexclass* lc, QString& label)
{
 label = lexentry_injection_script_labels_.value({le, lc}, QString());
 return lexentry_injection_scripts_.value(label, QString());
}

QString NL_Gecode_Contravein_Connector_Callback::get_injection_script(NL_Gecode_Lexclass* lc)
{
 return lexclass_injection_scripts_.value(lc, QString());
}


void NL_Gecode_Contravein_Connector_Callback::duplicate(QString key, QString new_key)
{
 int index = key.indexOf(':');
 QString word;
 QString lc;

 int new_index = new_key.indexOf(':');
 QString new_word;
 QString new_lc;

 if(index != -1)
 {
  word = key.left(index);
  lc = key.mid(index + 1);
 }
 if(new_index != -1)
 {
  new_word = new_key.left(new_index);
  new_lc = new_key.mid(new_index + 1);
 }

 if(word.isEmpty())
 {
  if(key.startsWith('$'))
  {
   if(new_key.startsWith('$'))
   {
    lexgroup_callbacks_.insert(new_key, lexgroup_callbacks_.value(key));
   }
   else if(new_word.isEmpty())
   {
    lexclass_callbacks_.insert(lexicon_.find_lexclass(new_key),
      lexgroup_callbacks_.value(key));
   }
   else
   {
    lexentry_callbacks_.insert({lexicon_.find_lexentry(new_word),
      lexicon_.find_lexclass(new_lc)},
      lexgroup_callbacks_.value(key));
   }
  }
  else
  {
   if(new_key.startsWith('$'))
   {
    lexgroup_callbacks_.insert(new_key,
      lexclass_callbacks_.value(lexicon_.find_lexclass(key)));
   }
   else if(new_word.isEmpty())
   {
    lexclass_callbacks_.insert(lexicon_.find_lexclass(new_key),
      lexclass_callbacks_.value(lexicon_.find_lexclass(key)));
   }
   else
   {
    lexentry_callbacks_.insert({lexicon_.find_lexentry(new_word),
      lexicon_.find_lexclass(new_lc)},
      lexclass_callbacks_.value(lexicon_.find_lexclass(key)));
   }
//   lexclass_callbacks_.insert(lexicon_.find_lexclass(new_key),
//     lexgroup_callbacks_.value(lexicon_.find_lexclass(new_key)));
  }
 }
 else
 {
  if(new_key.startsWith('$'))
  {
   lexgroup_callbacks_.insert(new_key,
     lexentry_callbacks_.value({lexicon_.find_lexentry(word), lexicon_.find_lexclass(lc)}));
  }
  else if(new_word.isEmpty())
  {
   lexclass_callbacks_.insert(lexicon_.find_lexclass(new_key),
     lexentry_callbacks_.value({lexicon_.find_lexentry(word), lexicon_.find_lexclass(lc)}));
  }
  else
  {
   lexentry_callbacks_.insert(
    {lexicon_.find_lexentry(new_word), lexicon_.find_lexclass(new_lc)},
    lexentry_callbacks_.value({lexicon_.find_lexentry(word), lexicon_.find_lexclass(lc)}));
  }
 }
}

QVector<NL_Gecode_Contravein_Connector_Callback::callback_type>& NL_Gecode_Contravein_Connector_Callback::operator[](QString key)
{
 if(key.startsWith('$'))
 {
  return lexgroup_callbacks_[key];
 }
 int index = key.indexOf(':');
 if(index != -1)
 {
  QString word = key.left(index);
  QString lc = key.mid(index + 1);

  return lexentry_callbacks_[{lexicon_.find_lexentry(word), lexicon_.find_lexclass(lc)}];
 }
 else
 {
  return lexclass_callbacks_[lexicon_.find_lexclass(key)];
 }
}


