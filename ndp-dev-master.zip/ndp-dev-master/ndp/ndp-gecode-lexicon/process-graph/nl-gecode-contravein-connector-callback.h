
#ifndef NL_GECODE_CONTRAVEIN_CONNECTOR_CALLBACK__H
#define NL_GECODE_CONTRAVEIN_CONNECTOR_CALLBACK__H

#include "rzns.h"

#include <functional>

#include "rz-relae/relae-node-ptr.h"
#include "rz-relae/relae-caon-ptr.h"

#include <QString>

#include <QMap>

#include "accessors.h"

#include "nl-gecode-lexclass.h"
#include "nl-gecode-lexentry.h"
#include "nl-gecode-lexclass-vector.h"
#include "nl-gecode-dock-node.h"


RZNS_(NLG)

class NL_Gecode_Dock_Node;
class NL_Gecode_Lexentry;
class NL_Gecode_Lexclass;
class NL_Gecode_Process_Graph_Node;
class NL_Gecode_Process_Node_Target;
class NL_Gecode_Process_Graph_Build;


class NL_Gecode_Contravein_Connector_Callback
{

 typedef std::function<void(
   NL_Gecode_Process_Graph_Build& gb,
   caon_ptr<NL_Gecode_Process_Graph_Node>,
   caon_ptr<NL_Gecode_Process_Graph_Node>,
   qreal&, QString, QString)> callback_type;

 NL_Gecode_Lexicon& lexicon_;

 QMap<NL_Gecode_Lexclass*, QVector<callback_type> > lexclass_callbacks_;
 typedef QMap<NL_Gecode_Lexclass*, QVector<callback_type> > lexclass_callbacks_type;

 QMap<QPair<NL_Gecode_Lexentry*, NL_Gecode_Lexclass*>, QVector<callback_type> > lexentry_callbacks_;
 typedef QMap<QPair<NL_Gecode_Lexentry*, NL_Gecode_Lexclass*>, QVector<callback_type> > lexentry_callbacks_type;


 QMap<QPair<NL_Gecode_Lexentry*, NL_Gecode_Lexclass*>, QString> lexentry_injection_script_labels_;
 //typedef QMap<QPair<NL_Gecode_Lexentry*, NL_Gecode_Lexclass*>, QVector<callback_type> > lexentry_callbacks_type;

 QMap<QString, QString> lexentry_injection_scripts_;
 QMap<NL_Gecode_Lexclass*, QString> lexclass_injection_scripts_;



 QMap<QString, QVector<callback_type> > lexgroup_callbacks_;
 //?typedef QMap<QString, callback_type> lexgroup_callbacks_type;

 callback_type script_callback_;

public:

 NL_Gecode_Contravein_Connector_Callback(NL_Gecode_Lexicon& lexicon);

 ACCESSORS__RGET(lexclass_callbacks_type ,lexclass_callbacks)
 ACCESSORS__RGET(lexentry_callbacks_type ,lexentry_callbacks)

 ACCESSORS(callback_type ,script_callback)


 QVector<callback_type>& operator[](QString key);

 void duplicate(QString key, QString new_key);

 void write_rz_file(QString path);

 void finalize_lexgroups();

 QString get_injection_script(NL_Gecode_Lexentry*, NL_Gecode_Lexclass*, QString& label);
 QString get_injection_script(NL_Gecode_Lexclass*);

};


_RZNS(NLG)



#endif
