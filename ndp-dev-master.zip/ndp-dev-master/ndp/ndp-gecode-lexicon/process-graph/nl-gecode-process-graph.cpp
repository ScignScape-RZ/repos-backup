
#include "nl-gecode-process-graph.h"
#include "nl-gecode-process-node.h"
#include "process-graph/kernel/graph/nl-gecode-process-graph-node.h"
#include "nl-gecode-dock-node-pair.h"
#include "process-graph/kernel/graph/nl-gecode-process-node-target.h"
#include "process-graph/kernel/graph/nl-gecode-contravein-node-target.h"


USING_RZNS(NLG)

NL_Gecode_Process_Graph::NL_Gecode_Process_Graph()
 : root_node_(nullptr), abandonment_explanation_(nullptr),
   fr_(NL_Gecode_Process_Graph_Frame::instance()),
   nq_(NL_Gecode_Process_Graph_Query::instance()),
   composite_weight_(1)
{

}

void NL_Gecode_Process_Graph::adjust_composite_weight(qreal w)
{
 composite_weight_ += w;
}

QString NL_Gecode_Process_Graph::to_sexp_string()
{
 QString result;
 if(root_node_)
 {
  result += "(";
  result += to_sexp_string(root_node_);
  result += ")";
 }
 return result;
}

void NL_Gecode_Process_Graph::check_call_sequence_to_string
  (caon_ptr<NL_Gecode_Process_Graph_Node> start_node, QString& result) //, int rewind_level)
{
// caon_ptr<NL_Gecode_Process_Graph_Node> node;
// if(rewind_level == 0)
//  node = nq_.Dock_Call_Sequence(start_node);
// else
//  node = nq_.Dock_Call_Continue(start_node);

 caon_ptr<NL_Gecode_Process_Graph_Node> node = start_node;

 while(node)
 {
  CAON_PTR_DEBUG(NL_Gecode_Process_Graph_Node ,node)
  result += " ";
  node->write_to_sexp_string(result);
  if(caon_ptr<NL_Gecode_Process_Graph_Node> entry_node = nq_.Dock_Call_Entry(node))
  {
   result += " (" + to_sexp_string(entry_node) + ")";
   if(caon_ptr<NL_Gecode_Process_Graph_Node> continue_node = nq_.Dock_Call_Continue(entry_node))
   {
    check_call_sequence_to_string(continue_node, result);
   }
   else if(caon_ptr<NL_Gecode_Process_Graph_Node> cross_node = nq_.Dock_Cross_Sequence(entry_node))
   {
    result += " (" + to_sexp_string(cross_node) + ")";
   }

  }
  node = nq_.Dock_Call_Sequence(node);
 }
}


QString NL_Gecode_Process_Graph::abandonment_explanation_string()
{
 if(abandonment_explanation_)
 {
  return abandonment_explanation_();
  //return ((QString(*)())abandonment_explanation_)();
 }
 return QString();
}

void NL_Gecode_Process_Graph::report(QTextStream& qts)
{
 if(abandonment_explanation_)
 {
  qts << "\n\nAbandoned: " << abandonment_explanation_string();
 }
 qts << "\n\nComposite Weight: " << composite_weight_ << "\n\n";
 report_from_node(qts, *root_node_);
}

void NL_Gecode_Process_Graph::report_from_node(QTextStream& qts,
 const NL_Gecode_Process_Graph_Node& node, int indent)
{
 QString padding(indent, ' ');
 qts << "\n" << padding;
 if(caon_ptr<NL_Gecode_Process_Node_Target> nt = node.nl_node_target())
 {
  qts << "[token= " << nt->summary() << "]";
 }
// else
// if(caon_ptr<Dock_Call_Entry> dce = node.dock_call_entry())
// {
//  CAON_PTR_DEBUG(Dock_Call_Entry ,dce)
//  QString extra;
//  qts << QString("<call %1>").arg();
// }
 else if(caon_ptr<NL_Gecode_Contravein_Node_Target> nt = node.nl_contravein_node_target())
 {
  qts << "[contravein= " << nt->summary() << "]";
 }
 else
 {
  qts << "<<node/" << node.label() << ">>";
 }
  //Run_Data_Entry
 node.each_connection([this, &qts, &padding, &indent]
  (const NL_Gecode_Process_Graph_Connectors& connector, const NL_Gecode_Process_Graph_Node& target)
 {
  qts << "\n\n" << padding << "For connection: " << connector.label() << "\n"
      << padding << "==== ";
  report_from_node(qts, target, indent + 1);
  qts << "\n" << padding << "....";
 });
 //report_from_node(root_node_);
}


void NL_Gecode_Process_Graph::report_to_file(QString path)
{
 QFile file(path);
 if(file.open(QIODevice::WriteOnly))
 {
  QTextStream qts(&file);
  report(qts);
  file.close();
 }
}


QString NL_Gecode_Process_Graph::to_sexp_string(caon_ptr<NL_Gecode_Process_Graph_Node> start_node)
{
 CAON_PTR_DEBUG(NL_Gecode_Process_Graph_Node ,start_node)
 QString result;
 start_node->write_to_sexp_string(result);
 start_node->debug_connections();

 if(caon_ptr<NL_Gecode_Process_Graph_Node> node = nq_.Dock_Call_Sequence(start_node))
 {
  check_call_sequence_to_string(node, result);
 }
// check_call_sequence_to_string(start_node, result); //, 0);
// while(node)
// {
//  CAON_PTR_DEBUG(NL_Gecode_Process_Graph_Node ,node)
//  result += " ";
//  node->write_to_sexp_string(result);
//  if(caon_ptr<NL_Gecode_Process_Graph_Node> entry_node = nq_.Dock_Call_Entry(node))
//  {
//   result += " (" + to_sexp_string(entry_node) + ")";
//  }
//  node = nq_.Dock_Call_Sequence(node);
// }
 if(caon_ptr<NL_Gecode_Process_Graph_Node> entry_node = nq_.Dock_Call_Entry(start_node))
 {
  result += " (" + to_sexp_string(entry_node) + ")";
  if(caon_ptr<NL_Gecode_Process_Graph_Node> continue_node = nq_.Dock_Call_Continue(entry_node))
  {
   check_call_sequence_to_string(continue_node, result);
  }
  else if(caon_ptr<NL_Gecode_Process_Graph_Node> cross_node = nq_.Dock_Cross_Sequence(entry_node))
  {
   result += " (" + to_sexp_string(cross_node) + ")";
  }

 }

 //?check_call_sequence_to_string(start_node, result, 1);

 return result;
}

