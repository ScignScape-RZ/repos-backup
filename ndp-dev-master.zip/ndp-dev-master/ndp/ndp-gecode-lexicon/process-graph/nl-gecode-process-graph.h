
#ifndef NL_GECODE_PROCESS_GRAPH__H
#define NL_GECODE_PROCESS_GRAPH__H

#include "rzns.h"

#include <functional>

#include <QString>

#include <QMap>

#include "accessors.h"

#include "nl-gecode-lexclass.h"

#include "nl-gecode-lexentry.h"

#include "nl-gecode-lexclass-vector.h"

#include "process-graph/kernel/frame/nl-gecode-process-graph-frame.h"
#include "process-graph/kernel/query/nl-gecode-process-graph-query.h"

#include "rz-relae/relae-node-ptr.h"
#include "rz-relae/relae-caon-ptr.h"

#include <QTextStream>

RZNS_(NLG)


class NL_Gecode_Process_Graph_Node;
class NL_Gecode_Process_Node;
class NL_Gecode_Dock_Node_Pair;
class NL_Gecode_Dock_Node;

class NL_Gecode_Process_Graph
{
 caon_ptr<NL_Gecode_Process_Graph_Node> root_node_;

 //?QList<caon_ptr<NL_Gecode_Process_Graph_Node>> nodes_;

 NL_Gecode_Process_Graph_Frame& fr_;
 const NL_Gecode_Process_Graph_Query& nq_;

 //?void* abandonment_explanation_;
 std::function<QString()> abandonment_explanation_;

 qreal composite_weight_;


public:

 ACCESSORS(caon_ptr<NL_Gecode_Process_Graph_Node> ,root_node)
 ACCESSORS(std::function<QString()> ,abandonment_explanation)
 ACCESSORS(qreal ,composite_weight)

 NL_Gecode_Process_Graph();

 QString to_sexp_string();
 QString to_sexp_string(caon_ptr<NL_Gecode_Process_Graph_Node> start_node);
 void check_call_sequence_to_string
   (caon_ptr<NL_Gecode_Process_Graph_Node> start_node, QString& result);
     //?, int rewind_level;

 void adjust_composite_weight(qreal w);


 void report_to_file(QString path);

 void report(QTextStream& qts);
 void report_from_node(QTextStream& qts,
   const NL_Gecode_Process_Graph_Node& node, int indent = 0);

 QString abandonment_explanation_string();

};


_RZNS(NLG)



#endif
