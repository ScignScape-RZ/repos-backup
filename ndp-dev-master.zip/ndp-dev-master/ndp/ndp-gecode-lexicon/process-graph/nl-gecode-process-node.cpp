
#include "nl-gecode-process-node.h"

USING_RZNS(NLG)

NL_Gecode_Process_Node::NL_Gecode_Process_Node(const NL_Gecode_Dock_Node& dock_node)
 //NL_Gecode_Process_Node::NL_Gecode_Process_Node(NL_Gecode_Dock_Node dn)
 : dock_node_(dock_node)
{

}

QString NL_Gecode_Process_Node::summary()
{
 return dock_node().lexentry()->lexword();
}
