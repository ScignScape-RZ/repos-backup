
#ifndef NL_GECODE_PROCESS_NODE__H
#define NL_GECODE_PROCESS_NODE__H

#include "rzns.h"

#include <functional>

#include <QString>

#include <QMap>

#include "accessors.h"

#include "nl-gecode-lexclass.h"
#include "nl-gecode-lexentry.h"
#include "nl-gecode-lexclass-vector.h"
#include "nl-gecode-dock-node.h"


RZNS_(NLG)

class NL_Gecode_Dock_Node;


class NL_Gecode_Process_Node
{
 NL_Gecode_Dock_Node dock_node_;


public:

 //?NL_Gecode_Process_Node(NL_Gecode_Dock_Node dock_node);
 NL_Gecode_Process_Node(const NL_Gecode_Dock_Node& dock_node);

 ACCESSORS__CONST_RGET(NL_Gecode_Dock_Node ,dock_node)

 QString summary();

};


_RZNS(NLG)



#endif
