


#include <QDebug>

#include <QCoreApplication>

#include <QProcess>

#include <QMap>
#include <map>

#include <QDir>

#include "ndp-anteview/ndp-anteview.h"
#include "ndp-anteview/ndp-application.h"

#include "qunqlite-callback-parser.h"


#include "baseapi.h"
//
#include <leptonica/allheaders.h>

#include <QEventLoop>

#include <QApplication>

#include <QDebug>

USING_RZNS(NDP)


void prepare_application(NDP_Application* ndpa)
{
 QUnQLite_Callback_Parser callback_parser;

 std::function<int(QString message, int arglength, void* data)>
  allobase_callback = [&callback_parser](QString message, int arglength, void* data) -> int
 {
  return callback_parser.run_query(message, arglength, data);
 };

 std::function<int(QString message, QString key, QString value, QString* ref)>
  index_callback = [&callback_parser](QString message, QString key, QString value, QString* ref = nullptr) -> int
 {
  if(ref)
  {
   void* data[2] = {&key, ref};
   return callback_parser.run_query(message, 2, data);
  }
  else
  {
   void* data[2] = {&key, &value};
   return callback_parser.run_query(message, 2, data);
  }
 };

 std::function<QString()>
   error_callback = [&callback_parser]() -> QString
 {
   return callback_parser.last_error_code();
 };

 //ndpa->set_default_open_directory(DEFAULT_HTML_DIRECTORY);
 ndpa->allobase_init(DEFAULT_DATA_DIRECTORY, "all-ndp",
   allobase_callback, index_callback, error_callback);

 ndpa->prepare_anteview("Patient Intake Form Development and Management Platform");
//  ndpa->prepare_anteview("Document/Form Management");
}

void start_application(NDP_Application* ndpa)
{
 ndpa->launch();
}


//void test_ocr()
//{
//    char *outText;

//    tesseract::TessBaseAPI *api = new tesseract::TessBaseAPI();
//    // Initialize tesseract-ocr with English, without specifying tessdata path
//    if (api->Init(NULL, "eng")) {
//        qDebug() << "Could not initialize(); tesseract.\n";
//        return;
//    }

//    // Open input image with leptonica library
//    Pix *image = pixRead("/home/nlevisrael/NDP/tesseract/tesseract/api/handwriting-sample.jpg");
//    api->SetImage(image);
//    // Get OCR result
//    outText = api->GetUTF8Text();

//    QString outt = QString::fromUtf8(outText);

//    qDebug() << "OCR output:\n" << outt;

//    // Destroy used object and release memory
//    api->End();
//    delete [] outText;
//    pixDestroy(&image);

//}

int main(int argc, char* argv[])
{
 QApplication qapp(argc, argv);

 QString program = "/home/nlevisrael/NDP/tesseract/build-tconsole-qt-ClangQ58-Debug/tconsole-qt";
 QStringList arguments;
 arguments << "/home/nlevisrael/NDP/tesseract/tesseract/api/handwriting-sample.jpg";

 QProcess* proc = new QProcess;

 QProcessEnvironment env = QProcessEnvironment::systemEnvironment();
 env.insert("LD_LIBRARY_PATH",
   "$LD_LIBRARY_PATH:/home/nlevisrael/NDP/tesseract/tconsole/:/home/nlevisrael/NDP/tesseract/tesseract/api/.libs/"); // Add an environment variable
 proc->setProcessEnvironment(env);

 QEventLoop loop;

 QProcess::connect(proc,
                   static_cast<void (QProcess::*)(int exit_code, QProcess::ExitStatus exit_status)>
                   (&QProcess::finished), [proc, &loop]
   (int exit_code, QProcess::ExitStatus exit_status)
  {

   QString output = QString::fromUtf8(proc->readAllStandardOutput());
   qDebug() << "Output: " << output;
   loop.exit();
  });


 QProcess::connect(proc,
                   static_cast<void (QProcess::*)(QProcess::ProcessError)>
                   (&QProcess::error), [proc, &loop]
   (QProcess::ProcessError pError)
  {
   //QString output(proc->readAllStandardOutput());
   qDebug() << "Error: ";// << output;
   loop.exit();
  });

 QProcess::connect(proc, &QProcess::started, [proc, &loop]
   ()
  {
   //QString output(proc->readAllStandardOutput());
   qDebug() << "Started. ";// << output;
  });



 proc->start(program, arguments);
// proc->waitForFinished();

// QString output(proc->readAllStandardOutput());

// qDebug() << "O: " << output;

 // test_ocr();

// QApplication app(argc, argv);

//?
 loop.exec();

// NDP_Application* ndpa = new NDP_Application(argc, argv);

////? ndpa->set_rz_callback(compile_rz_src);
// prepare_application(ndpa);

// start_application(ndpa);

 return 0;
}
