
#include <QDebug>

#include <QCoreApplication>

#include <QMap>
#include <map>

#include <QDir>

#include "ndp-anteview/ndp-anteview.h"
#include "ndp-anteview/ndp-application.h"

#include "qunqlite-callback-parser.h"

//#include "baseapi.h"
////
//#include <leptonica/allheaders.h>

USING_RZNS(NDP)


//void test_ocr()
//{
//    char *outText;

//    tesseract::TessBaseAPI *api = new tesseract::TessBaseAPI();
//    // Initialize tesseract-ocr with English, without specifying tessdata path
//    if (api->Init(NULL, "eng"))
//    {
//     qDebug() << "Could not initialize(); tesseract.\n";
//     return;
//        //fprintf(stderr, "Could not initialize(); tesseract.\n");
//        //exit(1);
//    }

//    // Open input image with leptonica library
//    Pix *image = pixRead("/home/nlevisrael/NDP/tesseract/tesseract/api/handwriting-sample.jpg");
//    api->SetImage(image);
//    // Get OCR result
//    outText = api->GetUTF8Text();
//    qDebug() << "OCR output:\n" <<  outText;

//    // Destroy used object and release memory
////    api->End();
////    delete [] outText;
////    pixDestroy(&image);

//}


void prepare_application(NDP_Application* ndpa)
{
 QUnQLite_Callback_Parser callback_parser;

 std::function<int(QString message, int arglength, void* data)>
  allobase_callback = [&callback_parser](QString message, int arglength, void* data) -> int
 {
  return callback_parser.run_query(message, arglength, data);
 };

 std::function<int(QString message, QString key, QString value, QString* ref)>
  index_callback = [&callback_parser](QString message, QString key, QString value, QString* ref = nullptr) -> int
 {
  if(ref)
  {
   void* data[2] = {&key, ref};
   return callback_parser.run_query(message, 2, data);
  }
  else
  {
   void* data[2] = {&key, &value};
   return callback_parser.run_query(message, 2, data);
  }
 };

 std::function<QString()>
   error_callback = [&callback_parser]() -> QString
 {
   return callback_parser.last_error_code();
 };

 //ndpa->set_default_open_directory(DEFAULT_HTML_DIRECTORY);
 ndpa->allobase_init(DEFAULT_DATA_DIRECTORY, "all-ndp",
   allobase_callback, index_callback, error_callback);

 ndpa->prepare_anteview("Patient Intake Form Development and Management Platform");
//  ndpa->prepare_anteview("Document/Form Management");
}

void start_application(NDP_Application* ndpa)
{
 ndpa->launch();
}


int main(int argc, char* argv[])
{
 //? test_ocr();

// qputenv("QT_IM_MODULE", QByteArray("qtvirtualkeyboard"));

// qputenv("QT_VIRTUALKEYBOARD_PINYIN_DICTIONARY", QByteArray("/home/nlevisrael/NDP/vk/qtvirtualkeyboard-dev/src/virtualkeyboard/3rdparty/pinyin/data/dict_pinyin.dat"));



 NDP_Application* ndpa = new NDP_Application(argc, argv);

//? ndpa->set_rz_callback(compile_rz_src);
 prepare_application(ndpa);
//? clasp_bridge->set_print_callback(ndpa->print_callback());
 start_application(ndpa);

 //
}



#ifdef HIDE

void compile_rz(QString file, QString& result)
{
 RZ_QClasp_Generator::compile_rz(file, result);
}

int main2(int argc, char *argv[])
{
//? QApplication qapp(argc, argv);

  QCoreApplication qapp(argc, argv);

  QString result;

  compile_rz("/home/nlevisrael/rz-lisp/rz/t1.rz", result);

  qDebug() << result;
}

//#ifdef HIDE
int main(int argc, char *argv[])
{
//? QApplication qapp(argc, argv);

  QCoreApplication qapp(argc, argv);

  QString result;

  compile_rz("/home/nlevisrael/rz-lisp/rz/t1.rz", result);


 // qRegisterMetaType<PTN_Recommendation_Clasp_Interface>();
 // qRegisterMetaType<PTN_Recommendation_Clasp_Interface*>();
 // qRegisterMetaType<PTN_Recommendation_Clasp_Interface>();
 // qRegisterMetaType<PTN_Recommendation_Clasp_Interface*>();

  qRegisterMetaType<PTN_Site_Manager_Bridge>();
  qRegisterMetaType<PTN_Site_Manager_Bridge*>();

  qRegisterMetaType<PTN_Site_Manager_Date_Time>();
  qRegisterMetaType<PTN_Site_Manager_Date_Time*>();

  qRegisterMetaType<PTN_Site_Manager_Folder_Bridge>();
  qRegisterMetaType<PTN_Site_Manager_Folder_Bridge*>();

  qRegisterMetaType<PTN_Site_Manager_File_Bridge>();
  qRegisterMetaType<PTN_Site_Manager_File_Bridge*>();

  qRegisterMetaType<PTN_Site_Manager_Event_Loop>();
  qRegisterMetaType<PTN_Site_Manager_Event_Loop*>();

// qRegisterMetaType<PTN_Recommendation_Clasp_Interface>();
// qRegisterMetaType<PTN_Recommendation_Clasp_Interface*>();

 std::map<std::string, int> dummy_map;
 dummy_map["x"] = 1;
 dummy_map["y"] = 2;

 RZ_QClasp_Eval* clasp_eval = new RZ_QClasp_Eval;


 char argc_ = 3;

 char* argv_[argc_];
 //?QDir::setCurrent(
 QString current_dir =  "/run/media/nlevisrael/DualBootShared/CLASPQ/branches/new-testing/clasp/build/boehmdc";

 qDebug() << current_dir;

 argv_[0] = "cclasp-boehmdc";
// ////
// argv_[1] = "-l";
// argv_[2] = "/home/nlevisrael/rz-dev/cl/exit.lisp";

 argv_[1] = "-I";
 argv_[2] = "-n";

 //argv_[3] = "-I";
 //argv_[3] = "-n";


 //?clasp_eval->start_iclasp(argc, argv);

 clasp_eval->start_clasp_from_dir(argc_, argv_, current_dir);
 RZ_QClasp_Bridge* clasp_bridge = new RZ_QClasp_Bridge(*clasp_eval);

 //?QString qs1 = "(core::q-callback :invoke   (core::q-create  :|PTN_Recommendation_Clasp_Interface|) :|value_from_qcmap|     \"a\"     \"b\"      \"aaa\"      \"xxx\" ) ";
 //?qDebug() << "\n\nQS1 --- \n" << qs1 << "\n\n===\n";



 clasp_bridge->eval_file("/home/nlevisrael/rz-lisp/rz/t1.rz.cl");

// clasp_bridge->eval_rz_file("/home/nlevisrael/rz-dev/cl/t4.rz");

 //?clasp_bridge->eval_string("(core::q-callback :invoke   (core::q-create  :|PTN_Recommendation_Clasp_Interface|) :|value_from_qcmap|     \"a\"     \"b\"      \"aaa\"      \"xxx\")");


}
//#endif

#endif //HIDE
