
#include "rz-qclasp-bridge/rz-qclasp-bridge.h"
#include "rz-qclasp-eval/rz-qclasp-eval.h"

#include "rz-qclasp-generator/rz-qclasp-generator.h"



#include "ptn-path-segment.h"

#include "ptn-path-resource.h"

#include "ptn-file-resource.h"

#include "ptn-resource-encoder.h"
#include "ptn-resource-decoder.h"
#include "ptn-site-request.h"

#include "ptn-site-manager-bridge.h"
#include "ptn-site-manager-date-time.h"
#include "ptn-site-manager-file-bridge.h"
#include "ptn-site-manager-event-loop.h"

#include <QDebug>

#include <QCoreApplication>

#include <QMap>
#include <map>

#include <QEventLoop>


#include <QDebug>

#include <QCoreApplication>

#include <QMap>
#include <map>

#include <QDir>

#include "ndp-anteview/ndp-anteview.h"
#include "ndp-anteview/ndp-application.h"

#include "qunqlite-callback-parser.h"

USING_RZNS(NDP)

void init_clasp();

void prepare_application(NDP_Application* ndpa)
{
 QUnQLite_Callback_Parser callback_parser;

 std::function<int(QString message, int arglength, void* data)>
  allobase_callback = [&callback_parser](QString message, int arglength, void* data) -> int
 {
  return callback_parser.run_query(message, arglength, data);
 };

 std::function<int(QString message, QString key, QString value, QString* ref)>
  index_callback = [&callback_parser](QString message, QString key, QString value, QString* ref = nullptr) -> int
 {
  if(ref)
  {
   void* data[2] = {&key, ref};
   return callback_parser.run_query(message, 2, data);
  }
  else
  {
   void* data[2] = {&key, &value};
   return callback_parser.run_query(message, 2, data);
  }
 };

 std::function<QString()>
   error_callback = [&callback_parser]() -> QString
 {
   return callback_parser.last_error_code();
 };

 //ndpa->set_default_open_directory(DEFAULT_HTML_DIRECTORY);
 ndpa->allobase_init(DEFAULT_DATA_DIRECTORY, "all-ndp",
   allobase_callback, index_callback, error_callback);

 ndpa->prepare_anteview("Charm\u03beTorque  --  Hybrid Web/Native Development Platform");

}

void start_application(NDP_Application* ndpa)
{
 ndpa->launch();
}

USING_RZNS(RZClasp)

RZ_QClasp_Bridge* clasp_bridge;

void compile_rz(QString file, QString& result)
{
 RZ_QClasp_Generator::compile_rz(file, result);
}

void save_file(QString path, QString contents)
{
 QFile file(path);
 if(file.open(QIODevice::WriteOnly | QIODevice::Text))
 {
  QTextStream out(&file);
  out << contents;
 }
}

QString compile_rz_src(QString src)
{
 QString result;
 save_file(DEFAULT_TEMP_RZ_FILE, src);
 compile_rz(DEFAULT_TEMP_RZ_FILE, result);
 return result;
}


void* eval_clasp(QString code)
{
 clasp_bridge->eval_string(code);
 return nullptr;
}

int main(int argc, char* argv[])
{
 NDP_Application* ndpa = new NDP_Application(argc, argv);
 init_clasp();
 ndpa->set_clasp_callback(eval_clasp);
 ndpa->set_rz_callback(compile_rz_src);
 prepare_application(ndpa);
 clasp_bridge->set_print_callback(ndpa->print_callback());
 start_application(ndpa);
 //
}

////
//int main2(int argc, char *argv[])
//{
////? QApplication qapp(argc, argv);

//  QCoreApplication qapp(argc, argv);

//  QString result;

//  compile_rz("/home/nlevisrael/rz-lisp/rz/t1.rz", result);

//  qDebug() << result;
//}

//#ifdef HIDE
void init_clasp()
{
//? QApplication qapp(argc, argv);

//  QString result;

//?  compile_rz("/home/nlevisrael/rz-lisp/rz/t1.rz", result);


 // qRegisterMetaType<PTN_Recommendation_Clasp_Interface>();
 // qRegisterMetaType<PTN_Recommendation_Clasp_Interface*>();
 // qRegisterMetaType<PTN_Recommendation_Clasp_Interface>();
 // qRegisterMetaType<PTN_Recommendation_Clasp_Interface*>();

  qRegisterMetaType<PTN_Site_Manager_Bridge>();
  qRegisterMetaType<PTN_Site_Manager_Bridge*>();

  qRegisterMetaType<PTN_Site_Manager_Date_Time>();
  qRegisterMetaType<PTN_Site_Manager_Date_Time*>();

  qRegisterMetaType<PTN_Site_Manager_Folder_Bridge>();
  qRegisterMetaType<PTN_Site_Manager_Folder_Bridge*>();

  qRegisterMetaType<PTN_Site_Manager_File_Bridge>();
  qRegisterMetaType<PTN_Site_Manager_File_Bridge*>();

  qRegisterMetaType<PTN_Site_Manager_Event_Loop>();
  qRegisterMetaType<PTN_Site_Manager_Event_Loop*>();

// qRegisterMetaType<PTN_Recommendation_Clasp_Interface>();
// qRegisterMetaType<PTN_Recommendation_Clasp_Interface*>();

 std::map<std::string, int> dummy_map;
 dummy_map["x"] = 1;
 dummy_map["y"] = 2;

 RZ_QClasp_Eval* clasp_eval = new RZ_QClasp_Eval;


 char argc_ = 3;

 char* argv_[argc_];
 //?QDir::setCurrent(
 QString current_dir =  "/run/media/nlevisrael/DualBootShared/CLASPQ/branches/new-testing/clasp/build/boehmdc";

 qDebug() << current_dir;

 argv_[0] = "cclasp-boehmdc";
// ////
// argv_[1] = "-l";
// argv_[2] = "/home/nlevisrael/rz-dev/cl/exit.lisp";

 argv_[1] = "-I";
 argv_[2] = "-n";

 //argv_[3] = "-I";
 //argv_[3] = "-n";


 //?clasp_eval->start_iclasp(argc, argv);

 clasp_eval->start_clasp_from_dir(argc_, argv_, current_dir);
 clasp_bridge = new RZ_QClasp_Bridge(*clasp_eval);

 //?QString qs1 = "(core::q-callback :invoke   (core::q-create  :|PTN_Recommendation_Clasp_Interface|) :|value_from_qcmap|     \"a\"     \"b\"      \"aaa\"      \"xxx\" ) ";
 //?qDebug() << "\n\nQS1 --- \n" << qs1 << "\n\n===\n";


 //clasp_bridge->eval_file("/home/nlevisrael/rz-lisp/rz/t1.rz.cl");

// clasp_bridge->eval_rz_file("/home/nlevisrael/rz-dev/cl/t4.rz");

 //?clasp_bridge->eval_string("(core::q-callback :invoke   (core::q-create  :|PTN_Recommendation_Clasp_Interface|) :|value_from_qcmap|     \"a\"     \"b\"      \"aaa\"      \"xxx\")");


}
//#endif

//?#endif //HIDE
