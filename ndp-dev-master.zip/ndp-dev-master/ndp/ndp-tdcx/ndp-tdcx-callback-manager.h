
#ifndef RZ_TDCX_CALLBACK_MANAGER__H
#define RZ_TDCX_CALLBACK_MANAGER__H

#include <cstdint>
#include <QByteArray>

#include "rzns.h"

#include "accessors.h"

RZNS_(TransDCX)

class TDCX_Callback_Manager
{
public:

 virtual int callback(QString message, int arglength, void* data) = 0;
 virtual int callback(QString message, void* data);
 virtual int callback(QString message, QString arg1, QString arg2);
 virtual int callback(QString message);

};


_RZNS(TransDCX)



#endif
