
#ifndef RZ_TDCX_STORING_PROFILE__H
#define RZ_TDCX_STORING_PROFILE__H

#include <cstdint>

#include "rzns.h"

#include "accessors.h"

RZNS_(TransDCX)

typedef std::uint32_t u32;
typedef std::uint32_t u8;

enum class TDCX_Storing_Setting_Status
{
 Set, Not_Set, Auto_Set
};

template<typename T, typename VALUE_Type = u8>
struct Profile_Value
{
 VALUE_Type value;
 TDCX_Storing_Setting_Status status;
 Profile_Value(VALUE_Type v) : value(v), status(TDCX_Storing_Setting_Status::Set){}
 Profile_Value() : value( (VALUE_Type) 0), status(TDCX_Storing_Setting_Status::Not_Set){}
 Profile_Value(VALUE_Type v, TDCX_Storing_Setting_Status s) : value(v), status(s){}
};

enum class Padding_Mode { None, First, Last, Byte_Array };

struct Padding : public Profile_Value<Padding, Padding_Mode>
{
 using Profile_Value::Profile_Value;
 inline static Padding_Mode from_code(u8 code)
 {
  switch (code & 3)
  {
  case 0: return Padding_Mode::Byte_Array;
  case 1: return Padding_Mode::First;
  case 2: return Padding_Mode::Last;
  case 3: return Padding_Mode::None;
  }
 }

 inline static u8 code_for(Padding_Mode pm)
 {
  switch (pm)
  {
  case Padding_Mode::Byte_Array: return 0;
  case Padding_Mode::First: return 1;
  case Padding_Mode::Last: return 2;
  case Padding_Mode::None: return 3;
  }
 }
 u8 code()
 {
  return code_for(value);
 }
};

struct Bitsize : public Profile_Value<Bitsize> { using Profile_Value::Profile_Value; };
struct Length : public Profile_Value<Length> { using Profile_Value::Profile_Value; };

//struct Padding
//{
// u8 value;
// TDCX_Storing_Setting_Status status;
// Padding(u8 v) : value(v), status(TDCX_Storing_Setting_Status::Set){}
// Padding() : value(0), status(TDCX_Storing_Setting_Status::Not_Set){}
// Padding(u8 v, TDCX_Storing_Setting_Status s) : value(v), status(s){}
//};

//struct Bitsize
//{
// u32 value;
// TDCX_Storing_Setting_Status status;
// Bitsize(u32 v) : value(v), status(TDCX_Storing_Setting_Status::Set){}
// Bitsize() : value(0), status(TDCX_Storing_Setting_Status::Not_Set){}
// Bitsize(u8 v, TDCX_Storing_Setting_Status s) : value(v), status(s){}
//};

//struct Length
//{
// u32 value;
// TDCX_Storing_Setting_Status status;
// Length(u32 v) : value(v), status(TDCX_Storing_Setting_Status::Set){}
// Length() : value(0), status(TDCX_Storing_Setting_Status::Not_Set){}
// Length(u8 v, TDCX_Storing_Setting_Status s) : value(v), status(s){}
//};


class TDCX_Storing_Profile
{
 Padding padding_;
 Bitsize bitsize_;
 Length length_;
 int type_code_byte_length_;

public:

 TDCX_Storing_Profile():type_code_byte_length_(0){}

 TDCX_Storing_Profile(Padding p)
  : padding_(p), type_code_byte_length_(0){}

 TDCX_Storing_Profile(Bitsize b)
  : bitsize_(b), type_code_byte_length_(0){}

 TDCX_Storing_Profile(Length l)
  : length_(l), type_code_byte_length_(0){}

 TDCX_Storing_Profile(Padding p, Bitsize b)
  : padding_(p), bitsize_(b), type_code_byte_length_(0){}

 TDCX_Storing_Profile(Bitsize b, Padding p)
  : padding_(p), bitsize_(b), type_code_byte_length_(0){}

 TDCX_Storing_Profile(Length l, Padding p)
  : length_(l), padding_(p), type_code_byte_length_(0){}

 TDCX_Storing_Profile(Padding p, Length l)
  : length_(l), padding_(p), type_code_byte_length_(0){}

 TDCX_Storing_Profile(Length l, Bitsize b)
  : length_(l), bitsize_(b), type_code_byte_length_(0){}

 TDCX_Storing_Profile(Bitsize b, Length l)
  : length_(l), bitsize_(b), type_code_byte_length_(0){}

 TDCX_Storing_Profile(Padding p, Bitsize b, Length l)
  : padding_(p), length_(l), bitsize_(b), type_code_byte_length_(0){}

 TDCX_Storing_Profile(Padding p, Length l, Bitsize b)
  : padding_(p), length_(l), bitsize_(b), type_code_byte_length_(0){}

 TDCX_Storing_Profile(Bitsize b, Padding p, Length l)
  : padding_(p), length_(l), bitsize_(b), type_code_byte_length_(0){}

 TDCX_Storing_Profile(Bitsize b, Length l, Padding p)
  : padding_(p), length_(l), bitsize_(b), type_code_byte_length_(0){}

 TDCX_Storing_Profile(Length l, Bitsize b, Padding p)
  : padding_(p), length_(l), bitsize_(b), type_code_byte_length_(0){}

 TDCX_Storing_Profile(Length l, Padding p, Bitsize b)
  : padding_(p), length_(l), bitsize_(b), type_code_byte_length_(0){}

 ACCESSORS(Padding ,padding)
 ACCESSORS(Bitsize ,bitsize)
 ACCESSORS(Length ,length)
 ACCESSORS(int ,type_code_byte_length)

 void autoset_padding(Padding_Mode padding)
 {
  padding_ = Padding(padding, TDCX_Storing_Setting_Status::Auto_Set);
 }

 void autoset_bitsize(u32 bitsize)
 {
  bitsize_ = {bitsize, TDCX_Storing_Setting_Status::Auto_Set};
 }

 void autoset_length(u32 length)
 {
  length_ = {length, TDCX_Storing_Setting_Status::Auto_Set};
 }

};

_RZNS(TransDCX)

#endif
