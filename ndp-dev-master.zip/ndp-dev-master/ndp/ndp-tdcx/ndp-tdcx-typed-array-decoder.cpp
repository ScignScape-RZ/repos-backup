
#include "ndp-tdcx-typed-array-decoder.h"

#include <QStringList>
#include <QtEndian>
#include <QRegularExpression>

#include <QDebug>

#include <QQuaternion>

#include "rzns.h"

USING_RZNS(TransDCX)

TDCX_Typed_Array_Decoder::TDCX_Typed_Array_Decoder(QString code)
 : code_(code)
{

}

void TDCX_Typed_Array_Decoder::quaternion_decode()
{
 QVector4D code_vecs {0, 0, 0, 0};

 for(int i = 0; i < 20; i += 5)
 {
  bool ok = false;
  int x = quaternion_encode_string_.mid(i, 5).toInt(&ok, 32);
  float f = (float) x;
  code_vecs[i/5] = f;
 }

 QQuaternion qq(code_vecs);

// QQuaternion qq { 2.0f, 1.0f, 0.0f, 0.0f};

 qq.normalize();

 float s = qq.scalar();

 qq.setScalar(-s);


 QRegularExpression split_rx("[_wxyz]");
 int index = 0;
 while(true)
 {
  QRegularExpressionMatch m = split_rx.match(code_, index);
  if(m.hasMatch())
  {
   QString str = code_.mid(index, m.capturedEnd());
   decode(str, &qq);
   index = m.capturedEnd();
  }
  else
  {
   break;
  }
 }
}




void TDCX_Typed_Array_Decoder::decode()
{

 QRegularExpression split_rx("[_wxyz]");
 int index = 0;
 while(true)
 {
  QRegularExpressionMatch m = split_rx.match(code_, index);
  if(m.hasMatch())
  {
   QString str = code_.mid(index, m.capturedEnd());
   decode(str);
   index = m.capturedEnd();
  }
  else
  {
   break;
  }
 }
}


//void TDCX_Typed_Array_Decoder::encode_from_numeric_values(QString& str, const QVector<quint64>& vals)
//{
//}

void TDCX_Typed_Array_Decoder::decode_to_numeric_values(QString str, QVector<quint64>& vals)
{
 int s = str.size() - 1;
 QChar remainder_code = str[s];
 str.chop(1);

 int remainder;

 switch(remainder_code.toLatin1())
 {
 case 'w': remainder = 0; break;
 case 'x': remainder = 1; break;
 case 'y': remainder = 2; break;
 case 'z': remainder = 3; break;
 case '_': remainder = 4; break;
 default: remainder = 0;
 }
 for(int i = 0; i < s; i += 8)
 {
  QString c = str.mid(i, 8).toUpper();
  bool conversion_ok = false;
  QByteArray conv = c.toLatin1();

  // val is actually 5 bytes ...
  u64 val = conv.toLongLong(&conversion_ok, 32);
  vals.push_back(val);
 }
}

void TDCX_Typed_Array_Decoder::quaternion_transform(const QByteArray& qba, QByteArray& qqba, QQuaternion& qq)
{
 QDataStream qds(qba);

 int s;
 qds >> s;



 for(int i = 0; i < s; ++i)
 {
  QVector3D qv3d;
  qds >> qv3d;

  QVector3D qqv3d = qq.rotatedVector(qv3d);

  float qqu1f = qqv3d.x();
  float qqu2f = qqv3d.y();
  float qqu3f = qqv3d.z();

  quint16 u1ff = qRound(qqu1f);
  quint16 u2ff = qRound(qqu2f);
  quint16 u3ff = qRound(qqu3f);

  quint64 au = ( ((quint64)u1ff) << 28) + ( ((quint64)u2ff) << 14) + (quint64)u3ff;

  QByteArray res(5, 0);
  memcpy(res.data(), &au, 5);

  qqba.push_back(res);
 }
}


void TDCX_Typed_Array_Decoder::decode(QString str, QQuaternion* qq)
{
 int s = str.size() - 1;
 QChar remainder_code = str[s];
 str.chop(1);
 QByteArray result;

 int remainder;

 switch(remainder_code.toLatin1())
 {
 case 'w': remainder = 0; break;
 case 'x': remainder = 1; break;
 case 'y': remainder = 2; break;
 case 'z': remainder = 3; break;
 case '_': remainder = 4; break;
 default: remainder = 0; // error?
 }

 //?str += QString(rem, QChar('0'));

 for(int i = 0; i < s; i += 8)
 {
  QString c = str.mid(i, 8).toUpper();
  bool conversion_ok = false;
  QByteArray conv = c.toLatin1();
  u64 val = conv.toLongLong(&conversion_ok, 32);
  //val = qToBigEndian(val);

  QString vb1 = QString::number(val, 2);

  QByteArray qba(5, 0);
  memcpy(qba.data(), &val, 5); //(void*)(((size_t)&val) + 3), 5);

  result.append(qba);
 }
 // 170 2 1 240 4
 result.chop(remainder);

 if(qq)
 {
  QByteArray r;
  quaternion_transform(result, r, *qq);
  QSharedPointer<TDCX_Typed_Array> ta = QSharedPointer<TDCX_Typed_Array>(new TDCX_Typed_Array(r));
  typed_arrays_.push_back(ta);
 }
 else
 {
  QSharedPointer<TDCX_Typed_Array> ta = QSharedPointer<TDCX_Typed_Array>(new TDCX_Typed_Array(result));
  typed_arrays_.push_back(ta);
 }
}





//void TDCX_Typed_Array_Decoder::decode(QString str, QQuaternion* qq)
//{
// int s = str.size() - 1;
// QChar remainder_code = str[s];
// str.chop(1);
// QByteArray result;

// int remainder;

// switch(remainder_code.toLatin1())
// {
// case 'w': remainder = 0; break;
// case 'x': remainder = 1; break;
// case 'y': remainder = 2; break;
// case 'z': remainder = 3; break;
// case '_': remainder = 4; break;
// default: remainder = 0; // error?
// }

// //?str += QString(rem, QChar('0'));

// for(int i = 0; i < s; i += 8)
// {
//  QString c = str.mid(i, 8).toUpper();
//  bool conversion_ok = false;
//  QByteArray conv = c.toLatin1();
//  u64 val = conv.toLongLong(&conversion_ok, 32);
//  //val = qToBigEndian(val);

//  u64 actual_val;

//  if(qq)
//  {
//   quint64 mask1 = 0b11111111111111;
//   quint64 mask2 = mask1 << 14;

//   quint64 mask_1 = 0b111111111111;
//   quint64 mask3 = mask_1 << 28;

//   quint64  _u1 = (val & mask3);
//   quint64  _u2 = (val & mask2);
//   quint64  _u3 = (val & mask1);

//   quint16  u1 = _u1 >> 28;
//   quint16  u2 = _u2 >> 14;
//   quint16  u3 = _u3;

//   float u1f = (float) u1;
//   //memcpy(&u1f, &u1, sf);
//   float u2f = (float) u2;
//   //memcpy(&u2f, &u2, sf);
//   float u3f = (float) u3;
//   //memcpy(&u3f, &u3, sf);

//   QVector3D v3d{u1f, u2f, u3f};

//   QVector3D qqv3d = qq->rotatedVector(v3d);

//   float qqu1f = qqv3d.x();
//   float qqu2f = qqv3d.y();
//   float qqu3f = qqv3d.z();

//   quint16 u1ff = qRound(qqu1f);
//   quint16 u2ff = qRound(qqu2f);
//   quint16 u3ff = qRound(qqu3f);


//   //quint64 u = (((quint64)u1) << 28) + (((quint64)u2) << 14) + (quint64)u3;
//   quint64 au = ( ((quint64)u1ff) << 28) + ( ((quint64)u2ff) << 14) + (quint64)u3ff;
//   actual_val = au;

//   // debug ...
//   uvals.push_back(au);
//   qquvals.push_back(val);

//  }
//  else
//  {
//   actual_val = val;
//  }

//  QString vb1 = QString::number(actual_val, 2);

//  QByteArray qba(5, 0);
//  memcpy(qba.data(), &actual_val, 5); //(void*)(((size_t)&val) + 3), 5);

//  result.append(qba);
// }
// // 170 2 1 240 4
// result.chop(remainder);

// QSharedPointer<TDCX_Typed_Array> ta = QSharedPointer<TDCX_Typed_Array>(new TDCX_Typed_Array(result));
// typed_arrays_.push_back(ta);
//}




