
#ifndef NDP_TDCX_TYPED_ARRAY_DECODER__H
#define NDP_TDCX_TYPED_ARRAY_DECODER__H

#include <cstdint>

#include "ndp-tdcx-typed-array.h"

#include <QByteArray>
#include <QList>
#include <QSharedPointer>

#include "rzns.h"

#include "accessors.h"

RZNS_(TransDCX)

class TDCX_Typed_Array;
class TDCX_Storing_Profile;

class TDCX_Typed_Array_Decoder
{
 QString code_;
 QList<QSharedPointer<TDCX_Typed_Array>> typed_arrays_;

 QString quaternion_encode_string_;

 typedef std::int32_t u32;
 typedef std::int64_t u64;

 void decode(QString str, QQuaternion* qq = nullptr);

public:

 // debug ...
 QVector<quint64> uvals;
 QVector<quint64> qquvals;

 void decode();
 void quaternion_decode();

 void quaternion_transform(const QByteArray& qba, QByteArray& qqba, QQuaternion& qq);

 TDCX_Typed_Array_Decoder(QString code);


 ACCESSORS(QString ,quaternion_encode_string)


 static void decode_to_numeric_values(QString str, QVector<quint64>& vals);
 static void encode_from_numeric_values(QString& str, const QVector<quint64>& vals);


 template<typename T>
 void reload(QVector<QSharedPointer<T>>& ts)
 {
  for(QSharedPointer<TDCX_Typed_Array> ta : typed_arrays_)
  {
   if(T* t = TDCX_Match_Type_Code<T>(*ta))
   {
    if(TDCX_Initialize(&t, *ta))
     reload(*t, *ta);
    ts.push_back(QSharedPointer<T>(t));
   }
  }
 }

 template<typename T>
 static void reload(T& t, TDCX_Typed_Array& ta)
 {
  TDCX_Set_Storage_Mode<T>(ta);
  QByteArray qba;
  switch(ta.storage_mode())
  {
  case TDCX_Storage_Modes::Byte_Array:
   ta.read_to_qbytearray(qba);
   TDCX_From_QByteArray(t, qba);
   break;
  default:
   ta.read_direct_value(qba);
   TDCX_From_QByteArray(t, qba);
   break;
  }

 }

 template<typename T>
 void reload(u32 index, T& t)
 {
  QSharedPointer<TDCX_Typed_Array> ta = typed_arrays_.value(index, QSharedPointer<TDCX_Typed_Array>(nullptr));
  if(ta)
  {
   reload(t, *ta);
  }
 }

};


_RZNS(TransDCX)



#endif

