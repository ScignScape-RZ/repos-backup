
#include "ndp-tdcx-typed-array-document.h"

#include <QtEndian>

#include <QVector3D>
#include <QQuaternion>

#include "rzns.h"

USING_RZNS(TransDCX)

TDCX_Typed_Array_Document::TDCX_Typed_Array_Document()
{
 //typed_arrays_.push_back(nullptr);
}

TDCX_Typed_Array_Document::u32 TDCX_Typed_Array_Document::add_typed_array(QSharedPointer<TDCX_Typed_Array> ta)
{
 u32 result = typed_arrays_.size();
 typed_arrays_.push_back(ta);
 return result;
}


void TDCX_Typed_Array_Document::encode(const TDCX_Typed_Array& ta, QByteArray& qba)
{
 qba.append(ta.data());
}


void TDCX_Typed_Array_Document::quaternion_transform(const QByteArray& qba, QByteArray& qqba, QQuaternion& qq)
{
 QByteArray qba_copy(qba);
 QDataStream qqds(&qqba, QIODevice::WriteOnly);

 int s = qba.size();

 int remainder = s % 5;
 if(remainder != 0)
 {
  for(int r = remainder; r < 5; ++r)
  {
   qba_copy.push_back((char) 0);
  }
 }

 int s1 = qba_copy.size();

 qqds << (s1/5);

 for(int i = 0; i < s1; i += 5)
 {
  u64 val = 0;
  memcpy(&val, qba_copy.data() + i, 5);

  quint64 mask1 = 0b11111111111111;
  quint64 mask2 = mask1 << 14;

  quint64 mask_1 = 0b111111111111;
  quint64 mask3 = mask_1 << 28;

  quint64  _u1 = (val & mask3);
  quint64  _u2 = (val & mask2);
  quint64  _u3 = (val & mask1);

  quint16  u1 = _u1 >> 28;
  quint16  u2 = _u2 >> 14;
  quint16  u3 = _u3;

  float u1f = (float) u1;
  //memcpy(&u1f, &u1, sf);
  float u2f = (float) u2;
  //memcpy(&u2f, &u2, sf);
  float u3f = (float) u3;
  //memcpy(&u3f, &u3, sf);

  QVector3D v3d{u1f, u2f, u3f};

  QVector3D qqv3d = qq.rotatedVector(v3d);

  float qqu1f = qqv3d.x();
  //memcpy(&u1f, &u1, sf);
  float qqu2f = qqv3d.y();
  //memcpy(&u2f, &u2, sf);
  float qqu3f = qqv3d.z();

  //   quint16 u1ff = qRound(qqu1f);
  //   quint16 u2ff = qRound(qqu2f);
  //   quint16 u3ff = qRound(qqu3f);

  //   quint32

  qqds << qqv3d;

 }


}

void TDCX_Typed_Array_Document::encode(const TDCX_Typed_Array& ta, QString& code)
{
 QByteArray qba;
 encode(ta, qba);
 encode(qba, ta, code);
}

void TDCX_Typed_Array_Document::quaternion_encode(const TDCX_Typed_Array& ta, QString& code, QQuaternion& qq)
{
 QByteArray qba;
 encode(ta, qba);
 QByteArray qqba;
 quaternion_transform(qba, qqba, qq);
 encode(qqba, ta, code);
}

void TDCX_Typed_Array_Document::encode(const QByteArray& qba, const TDCX_Typed_Array& ta, QString& code)
{
 int s = qba.size();
 QString result;
 // 170 2 1 240 4

 int r1 = s % 5;
 int r2 = 5 - r1;

 int remainder = s % 5;
 if(remainder != 0)
 {
  remainder = 5 - remainder;
 }

 for(int i = 0; i < s; i += 5)
 {
  u64 val = 0;
  memcpy(&val, qba.data() + i, 5);

  QString v1 = QString("%1").arg(val, 8, 32, QChar('0'));
  QString vb1 = QString::number(val, 2);
//  val = qToBigEndian(val);
//  val >>= 24;
//  val = qFromBigEndian(val);
  QString v2 = QString::number(val, 32);
  QString vb2 = QString::number(val, 2);


  QByteArray check (5, 0);
  memcpy(check.data(), &val, 5);

  QByteArray check1 (5, 0);
  memcpy(check1.data(), (void*)((size_t)&val + 3), 5);


  result += QString("%1").arg(val, 8, 32, QChar('0')); //?QString::number(val, 32);

 }
 switch(remainder)
 {
 case 0: code += result + 'w'; break;
 case 1: code += result + 'x'; break;
 case 2: code += result + 'y'; break;
 case 3: code += result + 'z'; break;
 case 4: code += result + '_'; break;
 }
}

QString TDCX_Typed_Array_Document::quaternion_encode(QString& qq_result)
{
 QVector4D code_vecs {0, 0, 0, 0};

 for(int i = 0; i < 20; i += 5)
 {
  bool ok = false;
  int x = quaternion_encode_string_.mid(i, 5).toInt(&ok, 32);
  float f = (float) x;
  code_vecs[i/5] = f;
 }

 QQuaternion qq(code_vecs);

// QQuaternion qq { 2.0f, 1.0f, 0.0f, 0.0f};

 qq.normalize();

 QString result;
 for(QSharedPointer<TDCX_Typed_Array> ta : typed_arrays_)
 {
  quaternion_encode(*ta, qq_result, qq);
  //quaternion_transform(*ta, );
  encode(*ta, result);
 }
// result.chop(1);
 return result;
}


QString TDCX_Typed_Array_Document::encode()
{
 QString result;
 for(QSharedPointer<TDCX_Typed_Array> ta : typed_arrays_)
 {
  encode(*ta, result);
 }
// result.chop(1);
 return result;
}



//void TDCX_Typed_Array_Document::encode(const QByteArray& qba, const TDCX_Typed_Array& ta, QString& code, QQuaternion* qq, QString* qq_result)
//{
// int s = qba.size();
// QString result;
// // 170 2 1 240 4

// int r1 = s % 5;
// int r2 = 5 - r1;

// int remainder = s % 5;
// if(remainder != 0)
// {
//  remainder = 5 - remainder;
// }

// for(int i = 0; i < s; i += 5)
// {
//  u64 val = 0;
//  memcpy(&val, qba.data() + i, 5);

//  u64 actual_val;
//  if(qq)
//  {
//   quint64 mask1 = 0b11111111111111;
//   quint64 mask2 = mask1 << 14;

//   quint64 mask_1 = 0b111111111111;
//   quint64 mask3 = mask_1 << 28;

//   quint64  _u1 = (val & mask3);
//   quint64  _u2 = (val & mask2);
//   quint64  _u3 = (val & mask1);

//   quint16  u1 = _u1 >> 28;
//   quint16  u2 = _u2 >> 14;
//   quint16  u3 = _u3;

//   float u1f = (float) u1;
//   //memcpy(&u1f, &u1, sf);
//   float u2f = (float) u2;
//   //memcpy(&u2f, &u2, sf);
//   float u3f = (float) u3;
//   //memcpy(&u3f, &u3, sf);

//   QVector3D v3d{u1f, u2f, u3f};

//   QVector3D qqv3d = qq->rotatedVector(v3d);

//   float qqu1f = qqv3d.x();
//   //memcpy(&u1f, &u1, sf);
//   float qqu2f = qqv3d.y();
//   //memcpy(&u2f, &u2, sf);
//   float qqu3f = qqv3d.z();

////   quint16 u1ff = qRound(qqu1f);
////   quint16 u2ff = qRound(qqu2f);
////   quint16 u3ff = qRound(qqu3f);

////   quint32

//   QByteArray qqba;



//   QDataStream qqds(&qqba, QIODevice::WriteOnly);

//   qqds << qqv3d;

//   int s = qqba.size();
//   qqba.resize(15);
//   for(s; s < 15; ++s)
//   {
//    qqba[s] = 0;
//   }

//   //quint64 u = (((quint64)u1) << 28) + (((quint64)u2) << 14) + (quint64)u3;
////   quint64 au = ( ((quint64)u1ff) << 28) + ( ((quint64)u2ff) << 14) + (quint64)u3ff;
////   actual_val = au;

//   uvals.push_back(val);
//   //?qquvals.push_back(au);

//  }
//  else
//  {
//   actual_val = val;
//  }

//  QString v1 = QString("%1").arg(actual_val, 8, 32, QChar('0'));
//  QString vb1 = QString::number(actual_val, 2);
////  val = qToBigEndian(val);
////  val >>= 24;
////  val = qFromBigEndian(val);
//  QString v2 = QString::number(actual_val, 32);
//  QString vb2 = QString::number(actual_val, 2);


//  QByteArray check (5, 0);
//  memcpy(check.data(), &actual_val, 5);

//  QByteArray check1 (5, 0);
//  memcpy(check1.data(), (void*)((size_t)&actual_val + 3), 5);


//  result += QString("%1").arg(actual_val, 8, 32, QChar('0')); //?QString::number(val, 32);

// }
// switch(remainder)
// {
// case 0: code += result + 'w'; break;
// case 1: code += result + 'x'; break;
// case 2: code += result + 'y'; break;
// case 3: code += result + 'z'; break;
// case 4: code += result + '_'; break;
// }
//}

