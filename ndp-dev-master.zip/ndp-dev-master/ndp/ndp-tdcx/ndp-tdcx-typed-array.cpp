
#include "ndp-tdcx-typed-array.h"


#define _TDCX_MEMCPY_(value, data, length) \
  memcpy(&value, data, length); \
  value <<= 8 * (8 - length);


#include <QBitArray>
#include <QString>

#include <QDebug>
#include <QtEndian>
#include <QtMath>

//ACCESSORS__DECLARE(int ,bitsize)
//ACCESSORS__DECLARE(int ,padding)

#include "rzns.h"

#include "ndp-tdcx-storing-profile.h"


template <> inline unsigned long qbswap<unsigned long>(unsigned long source)
{
 return qbswap<quint64>(source);
}


USING_RZNS(TransDCX)

TDCX_Typed_Array::TDCX_Typed_Array(TDCX_Storing_Profile& profile)
 : profile_(&profile), storage_mode_(TDCX_Storage_Modes::Mixed),
   bitsize_(0), length_(0), type_code_(0)
{

}


TDCX_Typed_Array::TDCX_Typed_Array(u8 bytes_key)
 : length_(0), profile_(nullptr), storage_mode_(TDCX_Storage_Modes::Mixed) //, bitsize_(_Default_bitsize), type_code_(_Default_type_code)
{
 int type_code_bytes_length;
 int length_bytes_length;
 int bitsize_bytes_length;

 if(bytes_key == _Default_bytes_key)
 {
  type_code_bytes_length = _Default_type_code_bytes_length;
  length_bytes_length = _Default_length_bytes_length;
  bitsize_bytes_length = _Default_bitsize_bytes_length;
 }

 data_start_position_ = 1 + type_code_bytes_length + length_bytes_length + bitsize_bytes_length;
 data_.resize(data_start_position_);
 data_.fill(0);

 update_typecode(_Default_type_code, type_code_bytes_length);
 update_bitsize(_Default_bitsize, bitsize_bytes_length, type_code_bytes_length);

 data_[0] = bytes_key;

}

void TDCX_Typed_Array::update_typecode(u32 typecode)
{
 u8 key = data_[0];
 key >>= 5;
 update_typecode(typecode, key + 1);
}

void TDCX_Typed_Array::update_typecode(u32 typecode, u8 type_code_bytes_length)
{
 type_code_ = typecode;
 int actual_type_code_bytes_length = 1 + typecode/256;
 int unused_type_code_bytes_length = type_code_bytes_length - actual_type_code_bytes_length;
 memcpy(data_.data() + 1 + unused_type_code_bytes_length, &type_code_, actual_type_code_bytes_length);
}

void TDCX_Typed_Array::update_bitsize(u32 bitsize, u8 bitsize_bytes_length, u8 type_code_bytes_length)
{
 bitsize_ = bitsize;
 int actual_bitsize_bytes_length = 1 + bitsize/256;
 int unused_bitsize_bytes_length = bitsize_bytes_length - actual_bitsize_bytes_length;
 memcpy(data_.data() + 1 + type_code_bytes_length + unused_bitsize_bytes_length,
  &bitsize_, actual_bitsize_bytes_length);
}

void TDCX_Typed_Array::update_length(u32 length, u8 length_bytes_length, u8 type_code_and_bitsize_bytes_length)
{
 length_ = length;
 int actual_length_bytes_length = 1 + length/256;
 int unused_length_bytes_length = length_bytes_length - actual_length_bytes_length;
 memcpy(data_.data() + 1 + type_code_and_bitsize_bytes_length + unused_length_bytes_length,
  &length_, actual_length_bytes_length);
}

void TDCX_Typed_Array::update_bitsize(u32 bitsize)
{
 u8 key = data_[0];
 key >>= 3;
 int bitsize_bytes_length = 1 + key & 3;
 key >>= 2;
 int type_code_bytes_length = 1 + key;
 update_bitsize(bitsize, bitsize_bytes_length, type_code_bytes_length);
}

void TDCX_Typed_Array::update_length(u32 length)
{
 u8 key = data_[0];
 int length_bytes_length = 1 + key & 7;
 key >>= 3;
 int bitsize_bytes_length = 1 + key & 3;
 key >>= 2;
 int type_code_bytes_length = 1 + key;
 update_length(length, length_bytes_length, bitsize_bytes_length + type_code_bytes_length);
}

void TDCX_Typed_Array::update_increment_length()
{
 u8 key = data_[0];
 int length_bytes_length = 1 + key & 7;
 key >>= 3;
 int bitsize_bytes_length = 1 + key & 3;
 key >>= 2;
 int type_code_bytes_length = 1 + key;
 update_increment_length(length_bytes_length, bitsize_bytes_length + type_code_bytes_length);
}

void TDCX_Typed_Array::update_increment_length(u8 length_bytes_length, u8 type_code_and_bitsize_bytes_length)
{
 ++length_;
 int actual_length_bytes_length = 1 + length_/256;
 int unused_length_bytes_length = length_bytes_length - actual_length_bytes_length;
 memcpy(data_.data() + 1 + type_code_and_bitsize_bytes_length + unused_length_bytes_length,
  &length_, actual_length_bytes_length);
}


TDCX_Typed_Array::TDCX_Typed_Array(const QByteArray& lhs)
 : storage_mode_(TDCX_Storage_Modes::Mixed), type_code_(0)
 //: data_(lhs.data())
{
 data_.resize(lhs.size());
 memcpy(data_.data(), lhs.data(), lhs.size());
 decode_bytes();
}


void TDCX_Typed_Array::set_bitsize(int bitsize)
{
 int p = padding_code();
 update_bitsize((bitsize << 2) | p);
 //bitsize_ = (bitsize << 2) | p;
}

int TDCX_Typed_Array::bitsize() const
{
 return bitsize_ >> 2;
}

void TDCX_Typed_Array::set_padding(Padding_Mode p)
{
 update_bitsize( (bitsize_ ^ 3) | Padding::code_for(p) );
}

Padding_Mode TDCX_Typed_Array::padding() const
{
 return Padding::from_code(bitsize_);
}


void TDCX_Typed_Array::init_data_start(u8 key)
{
 u8 key_copy = key;
 int length_bytes_length = 1 + key & 7;
 key >>= 3;
 int bitsize_bytes_length = 1 + key & 3;
 key >>= 2;
 int type_code_bytes_length = 1 + key & 7;

 int data_start = 1 + bitsize_bytes_length + type_code_bytes_length + length_bytes_length;

 if(data_start > data_.size())
 {
  data_.resize(data_start);
  data_.fill(0, data_start);
 }

 data_start_position_ = data_start;
 data_[0] = key_copy;
}


void TDCX_Typed_Array::init_length_bytes()
{
 u8 key = data_[0];
 int length_bytes_length = 1 + key & 7;
 key >>= 3;
 int bitsize_bytes_length = 1 + key & 3;
 key >>= 2;
 int type_code_bytes_length = 1 + key & 7;

 u64 _bitsize = qToBigEndian(bitsize_);
 u64 _length = qToBigEndian(length_);
 u64 _type_code = qToBigEndian(type_code_);

 int index = 1;
 memcpy(data_.data() + index, (const void*)((size_t)&_type_code + 8 - type_code_bytes_length), type_code_bytes_length);
 index += type_code_bytes_length;
 memcpy(data_.data() + index, (const void*)((size_t)&_bitsize + 8 - bitsize_bytes_length), bitsize_bytes_length);
 index += bitsize_bytes_length;
 memcpy(data_.data() + index, (const void*)((size_t)&_length + 8 - length_bytes_length), length_bytes_length);
}

void TDCX_Typed_Array::decode_bytes(u8 key)
{
 int length_bytes_length = 1 + key & 7;
 key >>= 3;
 int bitsize_bytes_length = 1 + key & 3;
 key >>= 2;
 int type_code_bytes_length = 1 + key & 7;

 int data_start = 1 + bitsize_bytes_length + type_code_bytes_length + length_bytes_length;

 if(data_start > data_.size())
 {
  data_.resize(data_start);
 }

 int index = 1;

 QByteArray type_code_bytes = data_.mid(index, type_code_bytes_length);
 index += type_code_bytes_length;

 QByteArray bitsize_bytes = data_.mid(index, bitsize_bytes_length);
 index += bitsize_bytes_length;

 QByteArray length_bytes = data_.mid(index, length_bytes_length);
 index += length_bytes_length;

 data_start_position_ = index;

 u32 _type_code, _length, _bitsize;

 _TDCX_MEMCPY_(_type_code, type_code_bytes.data(), type_code_bytes_length)
 _TDCX_MEMCPY_(_bitsize, bitsize_bytes.data(), bitsize_bytes_length)
 _TDCX_MEMCPY_(_length, length_bytes.data(), length_bytes_length)


// memcpy(&_type_code, type_code_bytes.data(), type_code_bytes_length);

 // memcpy(&_bitsize, bitsize_bytes.data(), bitsize_bytes_length);
// _bitsize <<= 8 * (8 - bitsize_bytes_length);

// memcpy(&_length, length_bytes.data(), length_bytes_length);
// _length <<= 8 * (8 - length_bytes_length);

 type_code_ = qFromBigEndian(_type_code);

 bitsize_ = qFromBigEndian(_bitsize);

 length_ = qFromBigEndian(_length);

}


TDCX_Typed_Array::u8 TDCX_Typed_Array::bytes_key()
{
 return data_.at(0);
}

int TDCX_Typed_Array::position_index(Fine_Index& fi, int index)
{
 int s = bitsize();
 int result = s + padding_bit_length();
 result += storage_mode_bit_length();
 if(result % 8)
 {
  int bits_length = result * index;
  fi.byte_index = data_start_position_ + bits_length / 8;
  fi.bit_index = bits_length % 8;
 }
 else
 {
  int bytes_length = 1 + result / 8;
  fi.byte_index = data_start_position_ + index * bytes_length;
  fi.bit_index = 0;
 }
 return result;
}

int TDCX_Typed_Array::check_resize(Fine_Index& fi)
{
 int s = bitsize();
 int result = s + padding_bit_length();
 result += storage_mode_bit_length();
 int trailing_free = 0;
 if(result > trailing_free)
 {
  fi.byte_index = reserve(result - trailing_free);
  fi.bit_index = 0;
  return result;
 }
}

int TDCX_Typed_Array::reserve(size_t number_of_bits)
{
 int result = get_next_index();
 int new_size = result + number_of_bits / 8;
 data_.resize(new_size);
 for(int i = result; i < new_size; ++i)
 {
  data_[i] = 0;
 }
 return result;
}

int TDCX_Typed_Array::get_next_index()
{
 int result = bitsize() + padding_bit_length();
 result *= (length_ - 1);
 result /= 8;
 result += data_start_position_;
 return result;
}

QString TDCX_Typed_Array::full_rep()
{
 QString result;
 for(u8 U8 : data_)
 {
  result += full_rep(U8);
 }
 return result;
}

QString TDCX_Typed_Array::full_rep(u8 U8)
{
 QString result = "00000000 ";
 QString b = QString::number(U8, 2);
 for(int i = 0, j = 1; i < 8; ++i, j <<= 1)
 {
  if( (U8 & j) > 0)
  {
   result[7 - i] = '1';
  }
 }
 return result;
}

QByteArray TDCX_Typed_Array::check_invert(const QByteArray& qba)
{
 #ifdef SWITCH_ENDIAN
 int s = qba.size();
 QByteArray result(s, 0);
 for(int i = 0; i < s; ++i)
 {
  result[i] = qba[s - i - 1];
 }
 return result;
 //memcpy(actual_data.data(), invert(qba));
 //   for(int i = 0; i < s; ++i)
 //   {
 //    qba[s] =
 //   }
 #else
 return qba;
 #endif
}

void TDCX_Typed_Array::check_init_profile()
{
 u8 profile_key = 0;

 if(profile_)
 {
  if(profile_->padding().status == TDCX_Storing_Setting_Status::Set)
  {
   set_raw_padding(profile_->padding().value);
  }
  else
  {
   set_raw_padding(_Default_padding);
   profile_->autoset_padding(_Default_padding);
  }
  if(profile_->bitsize().status == TDCX_Storing_Setting_Status::Set)
  {
   set_raw_bitsize(profile_->bitsize().value);
  }
  else
  {
   set_raw_bitsize(_Default_raw_bitsize);
   profile_->autoset_bitsize(_Default_raw_bitsize);
  }

  encode_length(bitsize_, profile_key, 3);
  QString str = QString::number(profile_key, 2);

  if(profile_->length().status == TDCX_Storing_Setting_Status::Set)
  {
   set_length(profile_->length().value);
  }
  else
  {
   set_length(_Default_length);
   profile_->autoset_length(_Default_length);
  }

  encode_length(length_, profile_key, 0);

  int type_code_byte_length = profile_->type_code_byte_length();

  if(type_code_byte_length == 0)
  {
   type_code_byte_length = _Default_type_code_bytes_length;
  }
  encode_raw_length(type_code_byte_length - 1, profile_key, 5);

  init_data_start(profile_key);

 }
}

void TDCX_Typed_Array::store_direct_value(const QByteArray& qba)
{
 if(qba.size() <= 8)
 {
  u64 val = 0;
  QByteArray actual_data(8, 0);
  int s = qba.size();
  memcpy(actual_data.data() + 8 - s, qba.data(), s);
  memcpy(&val, actual_data.data(), 8);

  u64 sdv = qToBigEndian(val);

  store_direct_value(sdv);
 }
 else if(storage_mode_ == TDCX_Storage_Modes::Byte_Array)
 {
  data_.append(qba);
 }
}
// Fine_Index fi;
// int total_bit_length = check_resize(fi);

// int mask = 1;

// // //  for direct val
//  // total_bit_length += 2;
// val <<= 2;
// val |= 3;

// int bi = fi.bit_index;

// if(bi > 0)
// {
//  total_bit_length -= (8 - bi);
//  u8 byte = 0;
//  u8 val = qba[0];
//  for(int i = bi, j = 1; i < 8; ++i, j <<= 1, mask <<= 1)
//  {
//   if(val & mask > 0)
//    byte |= j;
//  }
//  byte <<= bi;
//  byte |= data_.at(fi.byte_index);
//  data_[fi.byte_index] = byte;
//  ++fi.byte_index;
//  val >> 8 - bi;
// }
// if(total_bit_length == 0)
//  return;

// u8 actual_val_bytes = 1 + val / 256;
// u8 total_bytes = total_bit_length / 8;
// if(total_bit_length % 8)
//  ++total_bytes;
// u8 unused_val_bytes = total_bytes - actual_val_bytes;
// memcpy(data_.data() + fi.byte_index + unused_val_bytes, &val, actual_val_bytes);
// update_increment_length();
//}


TDCX_Typed_Array::u64 TDCX_Typed_Array::read_direct_value(u32 index)
{
 Fine_Index fi;
 int total_bit_length = position_index(fi, index);

 int mask = 1;

 int bi = fi.bit_index;

 u64 result = 0;

 if(bi > 0)
 {
//?  total_bit_length -= (8 - bi);
//  u8 byte = 0;
//  for(int i = bi, j = 1; i < 8; ++i, j <<= 1, mask <<= 1)
//  {
//   if(val & mask > 0)
//    byte |= j;
//  }
//  byte <<= bi;
//  byte |= data_.at(fi.byte_index);
//  data_[fi.byte_index] = byte;
//  ++fi.byte_index;
//  val >> 8 - bi;
 }
 if(total_bit_length == 0)
  return result;

 //int actual_val_bytes = 1 + val / 256;
 int total_byte_length = total_bit_length / 8;
 if(total_bit_length % 8)
  ++total_byte_length;
 if(total_byte_length > 8)
 {

 }
 else
 {
  int offset = 8 - total_byte_length;
  QByteArray actual_data(8, 0);
  memcpy(actual_data.data() + offset, data_.data() + fi.byte_index, total_byte_length);
  //for(int i = 0; i < )
  //data_.prepend()
  memcpy(&result, actual_data.data(), 8); // 8); //+ offset
         //, data_.mid(fi.byte_index, total_byte_length), total_byte_length);
  QString avn = QString::number(result, 2);
  qDebug() << avn;
  //result =
 }
 if(storage_mode_ == TDCX_Storage_Modes::Mixed)
 {
  switch(result & 3)
  {
  case 3:
   // // direct value
   return result >> 2;
  }
 }
 QByteArray qba(8, 0);
 memcpy(qba.data(), &result, 8);
 //result = qToBigEndian(result);
 QString avn = QString::number(result, 2);
 qDebug() << avn;
 return result;
 //return result;
}
// u8 unused_val_bytes = total_bytes - actual_val_bytes;
// memcpy(data_.data() + fi.byte_index + unused_val_bytes, &val, actual_val_bytes);
// update_increment_length();
//}

void TDCX_Typed_Array::read_to_qbytearray(QByteArray& qba, u32 index)
{
 qba = data_.mid(data_start_position_);
}

void TDCX_Typed_Array::read_direct_value(QByteArray& qba, u32 index)
{
 u64 val = read_direct_value(index);

 if(storage_mode_ == TDCX_Storage_Modes::Mixed)
 {
  val = qToBigEndian(val);
  int mode = val & 3;
  val >>= 2;
  val = qFromBigEndian(val);

 }


 u8 p = padding_bit_length();
 if(p)
 {
  if(padding() == Padding_Mode::First)
  {
   val = qToBigEndian(val);
   u8 mask = ~0;
   mask <<= p;
   mask >>= p;
   u8 keep = val & mask;
   val -= keep;
   val >>= p;
   val |= keep;
   val = qFromBigEndian(val);
  }
 }


 u64 bitsz = bitsize(); // + padding();
 u64 byte_length = bitsz / 8;
 if(bitsz % 8)
  ++byte_length;
 qba.resize(byte_length);
 qba.fill(0);

 //int actual_byte_length = 0;
 int offset = byte_length;
 u64 v1 = qToBigEndian(val);



 while(v1 > 0)
 {
  --offset;
  //++actual_byte_length;
  v1 >>= 8;
 }

 //offset = 0;

 QByteArray qba1(8,0);
 memcpy(qba1.data(), &val, 8);

 QByteArray qba2(5,0);
 memcpy(qba2.data(), (void*)((size_t)&val + 8 - byte_length), 5);

 //int offset = byte_length - actual_byte_length;
 memcpy(qba.data()// + offset
        , (void*)((size_t)&val + 8 - byte_length), byte_length);



 qDebug() << "ok";
}

//void TDCX_Typed_Array::load_data(const QByteArray& qba)
//{
// data_ = qba;
//}

void TDCX_Typed_Array::store_ref(u64 index)
{
 store_direct_value(index);
 update_increment_length();
}

void TDCX_Typed_Array::store_direct_value(u64 val)
{
 Fine_Index fi;
 int total_bit_length = check_resize(fi);

 int mask = 1;

 // //  for direct val
  // total_bit_length += 2;


 u64 val1 = val;
 QString str = QString::number(val1, 2);

 if(storage_mode_ == TDCX_Storage_Modes::Mixed)
 {
  val1 <<= 2;
  val1 |= 3;
 }

 QString str1 = QString::number(val1, 2);

 //val = qToBigEndian(val);

 int bi = fi.bit_index;

 if(bi > 0)
 {
  total_bit_length -= (8 - bi);
  u8 byte = 0;
  for(int i = bi, j = 1; i < 8; ++i, j <<= 1, mask <<= 1)
  {
   if(val & mask > 0)
    byte |= j;
  }
  byte <<= bi;
  byte |= data_.at(fi.byte_index);
  data_[fi.byte_index] = byte;
  ++fi.byte_index;
  val >> 8 - bi;
 }
 if(total_bit_length == 0)
  return;

 QString avn = QString::number(val, 2);

 //u64 np = qNextPowerOfTwo(val);

 int actual_val_bytes = 0;

 u64 v1 = val;//qToBigEndian(val);
 while(v1 > 0)
 {
  ++actual_val_bytes;
  v1 >>= 8;
 }
 //  sizeof(val);//1 + (val / 256);
 u8 total_bytes = total_bit_length / 8;
 if(total_bit_length % 8)
  ++total_bytes;
 u8 unused_val_bytes = total_bytes - actual_val_bytes;

 int p = padding_bit_length();
 if(p)
 {
  if(padding() == Padding_Mode::First)
  {
   u8 mask = ~0;
   mask <<= p;
   mask >>= p;
   u8 keep = val1 & mask;
   val1 -= keep;
   val1 <<= p;
   val1 |= keep;
  }
 }

 u64 val3 = qFromBigEndian(val1);

 memcpy(data_.data() + fi.byte_index, // + unused_val_bytes,
        (void*)((size_t)&val3 + 8 - total_bytes), total_bytes);

 qDebug() << ".ok";
 //update_increment_length();
}
// u8 byte = 0;
// for(int i = 0, j = 1; true; j <<= 1, mask <<= 1)
// {
//  if( (val & mask) > 0)
//   byte |= j;
//  ++i;
//  if(i == total)
//  {
//   data_[fi.byte_index] = byte;
//   byte = 0;
//   break;
//  }
//  else if(i % 8 == 0)
//  {
//   j = 1;
//   data_[fi.byte_index] = byte;
//   ++fi.byte_index;
//   byte = 0;
//  }
// }

//}
// int trailing_free = 0;
// total -= trailing_free;
// int byte_size = total / 8;
// if(total % 8)
// {
//  ++byte_size;
// }
// QByteArray qba();


// if(total % 8)
// {
  // //   The simple case: just push new bytes on data_.
//  for(int i = 0; i < s; ++i)
//  {

//  }

// }
//}


