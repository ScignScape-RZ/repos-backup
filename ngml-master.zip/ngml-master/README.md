
# NGML

NGML is a markup language, under development, which compiles to HTML, LaTeX, and other formats.

It compiles to an experimental format called "Khi Forms", which extends S-Expressions and can be read by a Lisp engine with suitable reader macros defines (see the khi-forms directory).  Khi Forms can be an intermediary format allowing arbitrary Lisp code to be run during preparation of the final document.

NGML itself combines elements of HTML and LaTeX and has been used on some long papers to generate both formats.  One feature of NGML is the option of defining callbacks in C++ for special processing tags and instructions.  

The published code is slightly incomplete, because it depends on a few additional files from the "ScignScape" library.  Since NGML is a work in progress, potential uses in a production environment need some setting up.  The NGML format itself needs to be explained, and certain features (like error handling) are in a rough state.  The intention however is for NGML to be released as a self-contained Open-Source library in due time.

See the Progressive Technology Network website for examples of pages generated from NGML, which include the option of viewing the original NGML and Khi Forms sources.
