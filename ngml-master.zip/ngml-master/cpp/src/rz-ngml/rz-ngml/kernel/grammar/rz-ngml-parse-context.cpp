
#include "rz-ngml-parse-context.h"

#include "rzns.h"
USING_RZNS(NGML)


NGML_Parse_Context::NGML_Parse_Context(): Flags(0)
{

}


