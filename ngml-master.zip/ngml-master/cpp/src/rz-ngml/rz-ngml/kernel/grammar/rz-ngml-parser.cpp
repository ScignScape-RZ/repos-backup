
#include "rz-ngml-parser.h"

USING_RZNS(NGML)

NGML_Parser::NGML_Parser(caon_ptr<NGML_Graph> g)
 : Relae_Parser<NGML_Galaxy>(g)
{
}

