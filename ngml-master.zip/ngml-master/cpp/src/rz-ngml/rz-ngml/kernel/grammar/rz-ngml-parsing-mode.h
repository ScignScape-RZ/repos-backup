
#ifndef RZ_NGML_PARSING_MODE__H
#define RZ_NGML_PARSING_MODE__H

#include "rzns.h"

RZNS_(NGML)

enum class NGML_Parsing_Modes {
  NGML, HTML, KHIF
 };

_RZNS(NGML)


#endif
