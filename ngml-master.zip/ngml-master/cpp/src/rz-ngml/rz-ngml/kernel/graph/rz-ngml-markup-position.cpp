
#include "rz-ngml-markup-position.h"

#include "tag-command/rz-ngml-tag-command.h"

#include <QStringList>
#include <QRegularExpression>

#include <QDebug>

#include "rzns.h"

USING_RZNS(NGML)


NGML_Markup_Position::NGML_Markup_Position(caon_ptr<tNode> current_node)
 :  current_node_(current_node), current_attribute_node_(nullptr),
   comment_semis_(0), comment_tildes_(0),
   fr_(NGML_Frame::instance()), qry_(NGML_Query::instance()),
   position_state_(Root), held_position_state_(Held_Empty), current_khif_connector_(Khif_Connectors::Khif_N_A)
{
}

QString NGML_Markup_Position::current_tag_command_name()
{
 QString result;
 if(!tag_commands_.isEmpty())
 {
  if(caon_ptr<NGML_Tag_Command> ntc = tag_commands_.top()->ngml_tag_command())
  {
   result = ntc->name();
  }
 }
 return result;
}

void NGML_Markup_Position::tag_command_annotation(caon_ptr<tNode> node)
{
 switch(position_state_)
 {
  case Tag_Command_Entry:
   current_node_ << fr_/qry_.Tag_Command_Annotation >> node;
   break;
  default:
   break;
 }
}

void NGML_Markup_Position::close_annotation()
{
 position_state_ = Annotation_Close;
}


void NGML_Markup_Position::annotation_entry(caon_ptr<tNode> node, caon_ptr<tNode> anode)
{
 CAON_PTR_DEBUG(tNode ,node)
 CAON_PTR_DEBUG(tNode ,current_node_)

 node << fr_/qry_.Tile_Annotation >> anode;

 switch(position_state_)
 {
   // //?  Is this part right?
 case Tag_Command_Entry:
   //
 case Tag_Body_Leave:
  current_node_ << fr_/qry_.Tag_Command_Main_Tile >> node;
  current_node_ = node;
  break;
 case Tag_Command_Leave:
  current_node_ << fr_/qry_.Tag_Command_Continue >> node;
  current_node_ = node;
  break;
 default:
  current_node_ << fr_/qry_.Annotation_Tile_Sequence >> node;
  current_node_ = node;
 }
}


void NGML_Markup_Position::enter_multiline_comment(int semis, int tildes)
{
 comment_semis_ = semis;
 comment_tildes_ = tildes;
}

bool NGML_Markup_Position::check_leave_multiline_comment(int semis, int tildes)
{
 if(comment_semis_ == semis && comment_tildes_ == tildes)
 {
  comment_semis_ = 0;
  comment_tildes_ = 0;
  return true;
 }
 return false;
}

void NGML_Markup_Position::tag_command_entry(caon_ptr<NGML_Node> node)
{
 CAON_PTR_DEBUG(tNode ,current_node_)
 current_attribute_node_ = caon_ptr<tNode>( nullptr );
 switch(position_state_)
 {
 case Tag_Body_Leave:
  {
   if(caon_ptr<NGML_Tag_Command> ntc = current_node_->ngml_tag_command())
   {
    CAON_PTR_DEBUG(NGML_Tag_Command ,ntc)
    ntc->flags.has_entry = true;
   }
  }
  // fallthrough
 case Root:
 case Annotation_Close:
 case Tile_Sequence:
  current_node_ << fr_/qry_.Tag_Command_Entry >> node;
  position_state_ = Tag_Command_Entry;
  break;

 case Tag_Command_Leave:
  current_node_ << fr_/qry_.Tag_Command_Cross >> node;
  position_state_ = Tag_Command_Entry;
  break;

 case Active_Khif_Connector:
  attach_khif_tag_command_node(node);
  break;

default:
  //  likely syntax error
  break;
 }

 current_node_ = node;
 tag_commands_.push(node);
}


void NGML_Markup_Position::load_khif_connectors(QString connectors)
{
 current_connectors_ = connectors;

 QStringList cs = connectors.split(QRegularExpression("\\s+"));
 for(QString c : cs)
 {
  Khif_Connectors kc = parse_khif_connector(c);
  if(kc != Khif_Connectors::Khif_N_A)
  {
   current_khif_connector_ = kc;
  }
 }

 position_state_ = Position_States::Active_Khif_Connector;

}

void NGML_Markup_Position::attach_khif_tag_command_node(caon_ptr<NGML_Node> node)
{
 CAON_PTR_DEBUG(NGML_Node ,node)
 switch(current_khif_connector_)
 {
 case Khif_Connectors::Khif_N_A:
  break;

 case Khif_Connectors::Khif_Entry:
  current_node_ << fr_/qry_.Tag_Command_Entry >> node;
  break;

 case Khif_Connectors::Khif_Cross:
  current_node_ << fr_/qry_.Tag_Command_Cross >> node;
  break;

 case Khif_Connectors::Khif_Continue:
  current_node_ << fr_/qry_.Tag_Command_Continue >> node;
  break;

 case Khif_Connectors::Khif_Attribute:
  //? error...
  break;

 case Khif_Connectors::Khif_Main_Tile:
  //? error...
  break;

 default:
  //? error...
  break;
 }

}

void NGML_Markup_Position::add_khif_tile_node(caon_ptr<tNode> node)
{
 CAON_PTR_DEBUG(tNode ,node)
 CAON_PTR_DEBUG(tNode ,current_node_)
 switch(current_khif_connector_)
 {
 case Khif_Connectors::Khif_N_A:
  break;

 case Khif_Connectors::Khif_Entry:
   if(caon_ptr<NGML_Tag_Command> ntc = node->ngml_tag_command())
   {
    ntc->flags.has_entry = true;
   }
  current_attribute_node_ = caon_ptr<tNode>( nullptr );
  current_node_ << fr_/qry_.Tile_Sequence >> node;
  break;

 case Khif_Connectors::Khif_Cross:
  current_attribute_node_ = caon_ptr<tNode>( nullptr );
  current_node_ << fr_/qry_.Tag_Command_Cross >> node;
  break;

 case Khif_Connectors::Khif_Continue:
  current_attribute_node_ = caon_ptr<tNode>( nullptr );
  current_node_ << fr_/qry_.Tag_Command_Continue >> node;
  break;

 case Khif_Connectors::Khif_Attribute:
  if(current_attribute_node_)
  {
   current_attribute_node_ << fr_/qry_.Tile_Sequence >> node;
  }
  else
  {
   if(caon_ptr<NGML_Tag_Command> ntc = current_node_->ngml_tag_command())
   {
    ntc->flags.has_attribute_tile = true;
   }
   current_node_ << fr_/qry_.Tag_Command_Attribute_Tile >> node;
  }
  current_attribute_node_ = node;
  break;

 case Khif_Connectors::Khif_Space:
 case Khif_Connectors::Khif_Main_Tile:
  {
   current_attribute_node_ = caon_ptr<tNode>( nullptr );
   if(caon_ptr<NGML_Tag_Command> ntc = current_node_->ngml_tag_command())
   {
    ntc->flags.has_main_tile = true;
   }
   current_node_ << fr_/qry_.Tag_Command_Main_Tile >> node;
   current_node_ = node;
  }
  //? error...
  break;

 default:
  //? error...
  break;
 }
}

void NGML_Markup_Position::khif_tag_command_leave()
{
 current_attribute_node_ = caon_ptr<tNode>( nullptr );
 if(tag_commands_.isEmpty())
 {
  if(caon_ptr<NGML_Tag_Command> ntc = current_node_->ngml_tag_command())
  {
   CAON_PTR_DEBUG(NGML_Tag_Command ,ntc)
   qDebug() << "Too far closing: " <<  ntc->name();
  }
  return;
  //throw(nullptr);
 }
 current_node_ = tag_commands_.pop();
 position_state_ = Khif_Tag_Command_Leave;
 if(caon_ptr<NGML_Tag_Command> ntc = current_node_->ngml_tag_command())
 {
  CAON_PTR_DEBUG(NGML_Tag_Command ,ntc)
  ntc->flags.is_closed = true;
 }

}

void NGML_Markup_Position::tag_body_leave()
{
 position_state_ = Tag_Body_Leave;
 current_node_ = tag_commands_.top();
}


caon_ptr<NGML_Markup_Position::tNode> NGML_Markup_Position::check_tag_command_leave(QString tag_command)
{
 if(tag_commands_.isEmpty())
  return caon_ptr<tNode>( nullptr );;
 current_attribute_node_ = caon_ptr<tNode>( nullptr );;
 caon_ptr<tNode> result = tag_commands_.top();
 CAON_PTR_DEBUG(NGML_Node ,result)
 if(caon_ptr<NGML_Tag_Command> ntc = result->ngml_tag_command())
 {
  if(ntc->name() == tag_command)
  {
   return result;
  }
 }
 return caon_ptr<tNode>( nullptr );;
}

void NGML_Markup_Position::rewind_tag_command_leave(QString tag_command)
{
 if(tag_commands_.isEmpty())
  return;
 current_attribute_node_ = caon_ptr<tNode>( nullptr );
 caon_ptr<tNode> result = tag_commands_.pop();
 CAON_PTR_DEBUG(NGML_Node ,result)
 if(caon_ptr<NGML_Tag_Command> ntc = result->ngml_tag_command())
 {
  if(ntc->name() == tag_command)
  {
   position_state_ = Tag_Command_Leave;
   current_node_ = result;
   ntc->flags.is_closed = true;
  }
  else
  {
   //?ntc->flags.is_closed = true;
   rewind_tag_command_leave(tag_command);
  }
 }
}

caon_ptr<NGML_Markup_Position::tNode> NGML_Markup_Position::tag_command_leave()
{
 if(tag_commands_.isEmpty())
  return caon_ptr<tNode>( nullptr );
 current_attribute_node_ = caon_ptr<tNode>( nullptr );
 caon_ptr<tNode> result = tag_commands_.top();
 CAON_PTR_DEBUG(NGML_Node ,result)
 if(caon_ptr<NGML_Tag_Command> ntc = result->ngml_tag_command())
 {
  //confirm_tag_command_leave(result);
  return result;
 }
 return caon_ptr<tNode>( nullptr );
}


void NGML_Markup_Position::confirm_tag_command_leave(caon_ptr<tNode> node)
{
 CAON_PTR_DEBUG(tNode ,node)
 tag_commands_.pop();
 position_state_ = Tag_Command_Leave;
 current_node_ = node;
 if(caon_ptr<NGML_Tag_Command> ntc = node->ngml_tag_command())
 {
  ntc->flags.is_closed = true;
 }
}

void NGML_Markup_Position::restore_current_node(caon_ptr<tNode> node)
{
 position_state_ = held_position_state_;
 held_position_state_ = Held_Empty;
 current_node_ = node;
}



void NGML_Markup_Position::add_attribute_tile_node(caon_ptr<NGML_Node> node)
{
 CAON_PTR_DEBUG(NGML_Node ,node)
 CAON_PTR_DEBUG(NGML_Node ,current_node_)
 CAON_PTR_DEBUG(NGML_Node ,current_attribute_node_)

 switch(position_state_)
 {
 case Tag_Command_Entry:
 case Tag_Body_Leave:
  {
   if(caon_ptr<NGML_Tag_Command> ntc = current_node_->ngml_tag_command())
   {
    ntc->flags.has_attribute_tile = true;
   }
   current_node_ << fr_/qry_.Tag_Command_Attribute_Tile >> node;
  }
  break;
 case Tile_Sequence:
  current_attribute_node_ << fr_/qry_.Tile_Sequence >> node;
  break;
 }
 current_attribute_node_ = node;
 position_state_ = Tile_Sequence;
}

caon_ptr<NGML_Markup_Position::tNode> NGML_Markup_Position::tag_command_instruction(caon_ptr<tNode> node)
{
 held_position_state_ = position_state_;
 caon_ptr<tNode> result = current_node_;
 current_node_ << fr_/qry_.Tag_Command_Instruction >> node;
 current_node_ = node;
 tag_commands_.push(node);
 return result;
}


void NGML_Markup_Position::add_tile_node(caon_ptr<NGML_Node> node)
{
 CAON_PTR_DEBUG(NGML_Node ,node)
 CAON_PTR_DEBUG(NGML_Node ,current_node_)

 switch(position_state_)
 {
 case Root:
  current_node_ << fr_/qry_.Tile_Sequence >> node;
  break;
 case Tag_Command_Entry:
  {
   if(caon_ptr<NGML_Tag_Command> ntc = current_node_->ngml_tag_command())
   {
    ntc->flags.has_entry = true;
   }
   current_node_ << fr_/qry_.Tag_Command_Entry >> node;
  }
  break;
 case Tag_Body_Leave:
  {
   if(caon_ptr<NGML_Tag_Command> ntc = current_node_->ngml_tag_command())
   {
    ntc->flags.has_main_tile = true;
   }
  }
  current_node_ << fr_/qry_.Tag_Command_Main_Tile >> node;
  break;
 case Tag_Command_Leave:
  current_node_ << fr_/qry_.Tag_Command_Continue >> node;
  break;
 case Tile_Sequence:
  current_node_ << fr_/qry_.Tile_Sequence >> node;
  break;

 case Annotation_Close:
  current_node_ << fr_/qry_.Tile_Sequence >> node;
  break;
 }
 current_node_ = node;
 position_state_ = Tile_Sequence;
}

