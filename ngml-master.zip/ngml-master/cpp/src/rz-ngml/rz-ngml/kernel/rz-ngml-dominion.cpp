
#include "rz-ngml-dominion.h"

#include "graph/rz-ngml-node.h"

#define DOMINION_NODE_NAMESPACE RZ::NGML
#define DOMINION_TYPE DOMINION_RETRIEVE_TYPE_CODE
#include "dominion/types.h"
#undef DOMINION_TYPE
#undef DOMINION_NODE_NAMESPACE
