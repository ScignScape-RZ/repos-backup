
#ifndef RZ_NGML_ROOT__H
#define RZ_NGML_ROOT__H

#include "whitespace/rz-ngml-whitespace-holder.h"

#include "rzns.h"

RZNS_(NGML)

class NGML_Document;

class NGML_Root : public NGML_Whitespace_Holder
{
};

_RZNS(NGML)


#endif
