
# ptn-dev
This includes C++ code for those Qt callbacks allowing scripts to manage web sites, using Qt networking libraries.  I'm using this to work with the "Progressive Technology Network" site, for practical and developmental sake.  The idea is to write scripts in the "R/Z" generator, which (after being "compiled" to Common Lisp) run via Clasp and callback to these "ptn-dev" classes to update remote files, get remote file information, and so forth.  E.g. a script to update files in a specific group of remote folders, by copying from newer local folders, looks like this: 


```
my ,psmb ==  PTN_Site_Manager_Bridge;

;;- Set the basic web info
psmb -> set-web-root-folder "~/ptn-test";
psmb -> set-host "localhost";
psmb -> set-port 1726; 

;;- Focus on this folder
psmb -> set-current-folder-relative "test-update";

;;- Get info on the remote version of that folder 
my ,psmfb = psmb ->  ..PTN_Site_Manager_Folder_Bridge*  get-remote-folder-as-bridge-resource;

;;- Visit inner folders
psmfb -> each-folder  do .(inner-psmfb <- PTN_Site_Manager_Folder_Bridge*) ->
 my ,fn = inner-psmfb -> ..QString folder-name;
 format t "~%Checking Update Folder Needed: ~a" fn;
 psmb -> enter-current-folder-relative fn;
 my ,inner-psmfb-remote = psmb ->  ..PTN_Site_Manager_Folder_Bridge*  get-remote-folder-as-bridge-resource;
 format t "~%FN path: ~a" (inner-psmfb-remote -> ..QString  complete-local-path);
 inner-psmfb-remote -> each-file  do .(psmf <- PTN_Site_Manager_File_Bridge*) ->
  my ,fn1 = psmf -> ..QString file-name;
  format t "~%Checking Update File Needed: ~a" fn1;
  psmb -> set-current-file-relative fn1;
  psmb -> check-file-update-needed  do .() ->
   format t "~%Updating: ~a" fn1;
   psmb -> send-update  do .(response) ->
    format t "~%Update Response: ~a" response;    
   ;;
  ;;
 psmb -> leave-current-folder-relative;
 ;;
```


Or, this verion visits inner folders recursively.



```
;;;- Define a function for processing each folder, so it can be called recursively 

our ,process-folder = .(psmb <- PTN_Site_Manager_Bridge*  psmfb <- PTN_Site_Manager_Folder_Bridge*) ->
 my ,fn = psmfb -> ..QString folder-name;
 format t "~%Checking Update Folder Needed: ~a" fn; 
 my ,psmfb-remote = psmb ->  ..PTN_Site_Manager_Folder_Bridge*  get-remote-folder-as-bridge-resource;
 psmfb-remote -> each-folder  do .(inner-psmfb <- PTN_Site_Manager_Folder_Bridge*) ->
  psmb -> enter-current-folder-relative (inner-psmfb -> ..QString folder-name);
  process-folder psmb inner-psmfb;
  psmb -> leave-current-folder-relative;
  ;;
 format t "~%Checking Files ...";  
 psmfb-remote -> each-file  do .(psmf <- PTN_Site_Manager_File_Bridge*) ->
  my ,fn1 = psmf -> ..QString file-name;
  format t "~%Checking Update File Needed: ~a" fn1;
  psmb -> set-current-file-relative fn1;  
  psmb -> check-file-update-needed  do .() ->
   format t "~%Updating: ~a" fn1;   
   psmb -> send-update  do .(response) ->
    format t "~%Update Response: ~a" response;    
    ;;
   ;;
  ;;
 ;;

 
;;- Allocate the underlying manager  
my ,psmb ==  PTN_Site_Manager_Bridge;

;;- Set the basic web info
psmb -> set-web-root-folder "~/ptn-test";
psmb -> set-host "localhost";
psmb -> set-port 1726; 

;;- Focus on this folder
psmb -> set-current-folder-relative "test-update";

;;- Get info on the remote version of that folder 
my ,psmfb = psmb ->  ..PTN_Site_Manager_Folder_Bridge*  get-remote-folder-as-bridge-resource;

;;- Visit inner folders
process-folder  psmb psmfb;

```


Finally, here is an example using asynchronous callbacks 
(the "@->" symbol marks the passed closure as intended to be called asynchronously).
```

my ,psmb ==  PTN_Site_Manager_Bridge;
psmb -> set-web-root-folder "~/openshift/ptn-test/local-version";
psmb -> set-host "localhost";
psmb -> set-port 1726;

my ,file-name = "index.html";

psmb -> set-current-file-relative file-name;

my ,loop ==  PTN_Site_Manager_Event_Loop;

format t "~%Updating: ~a" file-name;
psmb -> send-update  do .(response) @->
 format t "~%Update Response ... ~%~a" response;    
 loop -> leave;
 ;;

format t "~%~%Waiting ..."; 

loop -> enter;


```
