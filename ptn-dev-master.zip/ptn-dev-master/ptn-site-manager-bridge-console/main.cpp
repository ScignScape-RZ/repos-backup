
#include "rz-qclasp-bridge/rz-qclasp-bridge.h"
#include "rz-qclasp-eval/rz-qclasp-eval.h"




#include "ptn-path-segment.h"

#include "ptn-path-resource.h"

#include "ptn-file-resource.h"

#include "ptn-resource-encoder.h"
#include "ptn-resource-decoder.h"
#include "ptn-site-request.h"

#include "ptn-folder-resource.h"

#include "ptn-site-manager-bridge.h"

#include "ptn-site-manager-folder-bridge.h"

#include <QDebug>

#include <QCoreApplication>

#include <QMap>
#include <map>

USING_RZNS(RZClasp)



template<>
struct TDCX_Type_Info<PTN_File_Resource> : TDCX_Byte_Array_Storage //?: TDCX_Pure_Value_Storage
{
 static QString get_QString_Type_Name(){ return "PTN_File_Resource"; }
 static int get_Type_Code(){ return 1; }
};


template<>
struct TDCX_Type_Info<PTN_Folder_Resource> : TDCX_Byte_Array_Storage //?: TDCX_Pure_Value_Storage
{
 static QString get_QString_Type_Name(){ return "PTN_Folder_Resource"; }
 static int get_Type_Code(){ return 2; }
};


int main(int argc, char *argv[])
{
 QCoreApplication app(argc, argv);

 PTN_Site_Manager_Bridge psmb;

 psmb.set_web_root_folder("/home/nlevisrael/openshift/ptn-test/local-version");

 psmb.set_port(1726);
 psmb.set_host("localhost");

 QString file_name = "index.html";

 psmb.set_current_file_relative(file_name);

 QEventLoop qel;

//?
// psmb.send_update_async([&qel](QString result)
// {
//  qDebug() << "RR: " << result;
//  qel.quit();
// } );

 qel.exec();

}

int main1(int argc, char *argv[])
{
 QCoreApplication app(argc, argv);

 PTN_Site_Manager_Bridge psmb;

 //PTN_Site_Manager_Bridge psmb;

//? psmb.set_web_root_folder("/home/nlevisrael/openshift/pvc/pvc-docker-image/web/pvc/public");
 psmb.set_web_root_folder("/home/nlevisrael/openshift/ptn-test");
 psmb.set_current_folder_relative("test-update");

 psmb.set_port(1726);
 psmb.set_host("localhost");

 PTN_Site_Manager_Folder_Bridge* pfb = psmb.get_remote_folder_as_bridge_resource();

 for(QString s : pfb->contained_folders())
 {
  qDebug() << "Checking update folder needed: " << s;
  psmb.enter_current_folder_relative(s);
  QSharedPointer<PTN_Folder_Resource> inner_pfr = psmb.get_remote_folder_as_resource();
  for(QString inner_s : inner_pfr->contained_files())
  {
   qDebug() << "Checking update file needed: " << inner_s;
   psmb.set_current_file_relative(inner_s);
   psmb.check_file_update_needed( [&psmb, &inner_s]
   {
    qDebug() << "Updating: " << inner_s;
    psmb.send_update();
   }
   );
  }
  psmb.leave_current_folder_relative();
 }

// PTN_Site_Manager_Folder_Bridge* psmf = psmb.get_remote_folder_as_resource();
// qDebug() << psmf->file_list_summary();
 return 0;
}


#ifdef HIDE
int main(int argc, char *argv[])
{
//? QApplication qapp(argc, argv);

  QCoreApplication qapp(argc, argv);

 // qRegisterMetaType<PTN_Recommendation_Clasp_Interface>();
 // qRegisterMetaType<PTN_Recommendation_Clasp_Interface*>();
 // qRegisterMetaType<PTN_Recommendation_Clasp_Interface>();
 // qRegisterMetaType<PTN_Recommendation_Clasp_Interface*>();

  qRegisterMetaType<PTN_Site_Manager_Bridge>();
  qRegisterMetaType<PTN_Site_Manager_Bridge*>();

// qRegisterMetaType<PTN_Recommendation_Clasp_Interface>();
// qRegisterMetaType<PTN_Recommendation_Clasp_Interface*>();

 std::map<std::string, int> dummy_map;
 dummy_map["x"] = 1;
 dummy_map["y"] = 2;

 RZ_QClasp_Eval* clasp_eval = new RZ_QClasp_Eval;


 char argc_ = 3;

 char* argv_[argc_];
 //?QDir::setCurrent(
 QString current_dir =  "/run/media/nlevisrael/DualBootShared/CLASPQ/branches/new-testing/clasp/build/boehmdc";

 qDebug() << current_dir;

 argv_[0] = "cclasp-boehmdc";
// ////
// argv_[1] = "-l";
// argv_[2] = "/home/nlevisrael/rz-dev/cl/exit.lisp";

 argv_[1] = "-I";
 argv_[2] = "-n";

 //argv_[3] = "-I";
 //argv_[3] = "-n";


 //?clasp_eval->start_iclasp(argc, argv);

 clasp_eval->start_clasp_from_dir(argc_, argv_, current_dir);
 RZ_QClasp_Bridge* clasp_bridge = new RZ_QClasp_Bridge(*clasp_eval);

 //?QString qs1 = "(core::q-callback :invoke   (core::q-create  :|PTN_Recommendation_Clasp_Interface|) :|value_from_qcmap|     \"a\"     \"b\"      \"aaa\"      \"xxx\" ) ";
 //?qDebug() << "\n\nQS1 --- \n" << qs1 << "\n\n===\n";



 clasp_bridge->eval_file("/home/nlevisrael/rz-lisp/rz/t1.rz.cl");

// clasp_bridge->eval_rz_file("/home/nlevisrael/rz-dev/cl/t4.rz");

 //?clasp_bridge->eval_string("(core::q-callback :invoke   (core::q-create  :|PTN_Recommendation_Clasp_Interface|) :|value_from_qcmap|     \"a\"     \"b\"      \"aaa\"      \"xxx\")");


}

#endif //HIDE
