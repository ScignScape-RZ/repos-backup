
#include "ptn-site-manager-date-time.h"

#include "lunar/date.h"
//home/nlevisrael/openshift/ptn/ptn-docker-image/cpp/src/lunar/

#include "ptn-path-segment.h"

#include "ptn-path-resource.h"

#include "ptn-file-resource.h"

#include "ptn-resource-encoder.h"
#include "ptn-resource-decoder.h"
#include "ptn-site-request.h"

//#include "rz-tdcx/rz-tdcx/rz-tdcx-bridge.h"
//#include "rz-tdcx/rz-tdcx/rz-tdcx-typed-array.h"
//#include "rz-tdcx/rz-tdcx/rz-tdcx-typed-array-document.h"
//#include "rz-tdcx/rz-tdcx/rz-tdcx-typed-array-decoder.h"

#include "rz-qclasp-each/rz-qclasp-callback.h"

#include <QtEndian>

#include <QtGlobal>
#include <QtCore>
//#include <qtendian.h>

#include <QDebug>

#include <QNetworkRequest>
#include <QNetworkReply>

USING_RZNS(RZSite)
USING_RZNS(RZClasp)

PTN_Site_Manager_Date_Time::PTN_Site_Manager_Date_Time(QDateTime qdt)
 : qdt_(qdt)
{

}

PTN_Site_Manager_Date_Time::PTN_Site_Manager_Date_Time(const PTN_Site_Manager_Date_Time& rhs)
 : qdt_(rhs.qdt_)
{

}

PTN_Site_Manager_Date_Time::PTN_Site_Manager_Date_Time()
 : qdt_()
{

}


QString PTN_Site_Manager_Date_Time::get_french_republican_date_time(QDate qdt, int offset)
{
 QDate dt = qdt.addDays(offset);

 int day = dt.day();
 int month = dt.month();
 long year = dt.year();

 long js = dmy_to_day(day, month, year, CALENDAR_JULIAN_GREGORIAN);


 int r_day;
 int r_month;
 long r_year;

 static QStringList months_html {
   "Vend&eacute;miaire",
   "Brumaire",
   "Frimaire",
   "Niv&ocirc;se",
   "Pluvi&ocirc;se",
   "Vent&ocirc;se",
   "Germinal",
   "Flor&eacute;al",
   "Prairial",
   "Messidor",
   "Thermidor",
   "Fructidor",
//   "???1",
//   "???2",

 };

 static QStringList extra_days_html {
   "La F&ecirc;te de la Vertu",
   "La F&ecirc;te du G&eacute;nie",
   "La F&ecirc;te du Travail",
   "La F&ecirc;te de l&rsquo;Opinion",
   "La F&ecirc;te des R&eacute;compenses",
   "La F&ecirc;te de la R&eacute;volution",
//   "???e1",
//   "???e2",
 };

 static QStringList day_names {
   "D&eacute;cadi",
   "Primidi",
   "Duodi",
   "Tridi",
   "Quartidi",
   "Quintidi",
   "Sextidi",
   "Septidi",
   "Octidi",
   "Nonidi",
 };


 day_to_dmy(js, &r_day, &r_month, &r_year, CALENDAR_REVOLUTIONARY);

 QString decade;

 if(r_day < 11)
  decade = "I";
 else if(r_day < 21)
  decade = "II";
 else
  decade = "III";

 QString result = QString("%1 %2, ").arg(decade).arg(day_names[r_day%10]);
 //= );
 //= day_names[]

 if(r_month == 13)
 {
  result += extra_days_html[r_day];
 }
// else if(r_day == 30)
// {
//  result += QString::number(1) + " " + months_html[r_month];
// }
 else
 {
  result += QString::number(r_day) + " " + months_html[r_month - 1];
 }
 result += ", an " + QString::number(r_year);
 return result;


}

QString PTN_Site_Manager_Date_Time::get_french_republican_date_time()
{
 QDateTime now = QDateTime::currentDateTimeUtc();
 return get_french_republican_date_time(now.date());
}


QString PTN_Site_Manager_Date_Time::to_str()
{
 if(qdt_.isNull())
 {
  return "Null Date Time";
 }
 else if(!qdt_.isValid())
 {
  return "Invalid Date Time";
 }
 QString utc = qdt_.toUTC().toString(
    "dddd MMMM d yyyy h:mm:ss ap");

 QString str = qdt_.toString();
 QString rep = get_french_republican_date_time(qdt_.date());

 rep.replace("&ocirc;", "o");
 rep.replace("&eacute;", "e");
 rep.replace("&ecirc;", "e");

 return QString("Local: %1\nUTC: %2\nRepublican: %3")
   .arg(str).arg(utc).arg(rep);
}

void PTN_Site_Manager_Date_Time::test()
{
 qDebug() << "\nTest ok!";
}
