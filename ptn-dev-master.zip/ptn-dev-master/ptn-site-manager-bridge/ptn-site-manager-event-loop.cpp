
#include "ptn-site-manager-event-loop.h"


#include "rz-qclasp-each/rz-qclasp-callback.h"

#include <QDebug>

USING_RZNS(RZSite)
USING_RZNS(RZClasp)

PTN_Site_Manager_Event_Loop::PTN_Site_Manager_Event_Loop()
 : current_event_loop_(nullptr)
{

}

PTN_Site_Manager_Event_Loop::PTN_Site_Manager_Event_Loop(const PTN_Site_Manager_Event_Loop& rhs)
 : current_event_loop_(rhs.current_event_loop_)
{

}


void PTN_Site_Manager_Event_Loop::enter()
{
 if(!current_event_loop_)
  current_event_loop_ = new QEventLoop;
 current_event_loop_->exec();
}

void PTN_Site_Manager_Event_Loop::leave()
{
 if(current_event_loop_)
 {
  if(current_event_loop_->isRunning())
  {
   current_event_loop_->exit();
  }
 }
}
