
#include "ptn-site-manager-file-bridge.h"

#include "ptn-folder-resource.h"

#include "ptn-path-segment.h"

#include "ptn-path-resource.h"

#include "ptn-file-resource.h"

#include "ptn-resource-encoder.h"
#include "ptn-resource-decoder.h"
#include "ptn-site-request.h"

//#include "rz-tdcx/rz-tdcx/rz-tdcx-bridge.h"
//#include "rz-tdcx/rz-tdcx/rz-tdcx-typed-array.h"
//#include "rz-tdcx/rz-tdcx/rz-tdcx-typed-array-document.h"
//#include "rz-tdcx/rz-tdcx/rz-tdcx-typed-array-decoder.h"

#include "rz-qclasp-each/rz-qclasp-callback.h"
#include "rz-qclasp-each/rz-qclasp-each.h"

#include <QtEndian>

#include <QtGlobal>
#include <QtCore>
//#include <qtendian.h>

#include <QDebug>

#include <QNetworkRequest>
#include <QNetworkReply>

USING_RZNS(RZSite)
USING_RZNS(RZClasp)


template<>
struct TDCX_Type_Info<PTN_File_Resource> : TDCX_Byte_Array_Storage //?: TDCX_Pure_Value_Storage
{
 static QString get_QString_Type_Name(){ return "PTN_File_Resource"; }
 static int get_Type_Code(){ return 1; }
};


template<>
struct TDCX_Type_Info<PTN_Folder_Resource> : TDCX_Byte_Array_Storage //?: TDCX_Pure_Value_Storage
{
 static QString get_QString_Type_Name(){ return "PTN_Folder_Resource"; }
 static int get_Type_Code(){ return 2; }
};

//template<>
//struct TDCX_Type_Info<PTN_File_Resource> : TDCX_Byte_Array_Storage //?: TDCX_Pure_Value_Storage
//{
// static QString get_QString_Type_Name(){ return "PTN_File_Resource"; }
// static int get_Type_Code(){ return 3; }
//};


PTN_Site_Manager_File_Bridge::PTN_Site_Manager_File_Bridge(QSharedPointer<PTN_File_Resource> file_resource)
 : file_resource_(file_resource)
{

}

PTN_Site_Manager_File_Bridge::PTN_Site_Manager_File_Bridge(const PTN_Site_Manager_File_Bridge& rhs)
 : file_resource_(rhs.file_resource_)
{

}

PTN_Site_Manager_File_Bridge::PTN_Site_Manager_File_Bridge()
 : file_resource_(nullptr)
{

}

QString PTN_Site_Manager_File_Bridge::file_name()
{
 if(file_resource_)
  return file_resource_->file_name();
 return "???";
}

QString PTN_Site_Manager_File_Bridge::complete_local_path()
{
 if(file_resource_)
  return file_resource_->path_resource().complete_local_path();
 return "???";
}
