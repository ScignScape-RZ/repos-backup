
#ifndef PTN_SITE_MANAGER_FILE_BRIDGE__H
#define PTN_SITE_MANAGER_FILE_BRIDGE__H

#include <QObject>
#include <QDateTime>

#include <QSharedPointer>

#include "ptn-path-resource.h"


#include "rzns.h"

#include "accessors.h"

RZNS_CLASS_DECLARE(RZClasp ,RZ_QClasp_Each)
RZNS_CLASS_DECLARE(RZClasp ,RZ_QClasp_Callback)
RZNS_CLASS_DECLARE(RZSite ,PTN_File_Resource)

USING_RZNS(RZClasp)
USING_RZNS(RZSite)


class PTN_Site_Manager_File_Bridge : public QObject
{
 Q_OBJECT

 QSharedPointer<PTN_File_Resource> file_resource_;

public:

 PTN_Site_Manager_File_Bridge();
 PTN_Site_Manager_File_Bridge(QSharedPointer<PTN_File_Resource> file_resource);
 PTN_Site_Manager_File_Bridge(const PTN_Site_Manager_File_Bridge& rhs);

 Q_INVOKABLE QString complete_local_path();
 Q_INVOKABLE QString file_name();

};

Q_DECLARE_METATYPE(PTN_Site_Manager_File_Bridge)
Q_DECLARE_METATYPE(PTN_Site_Manager_File_Bridge*)


#endif
