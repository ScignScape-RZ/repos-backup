
#include "ptn-site-manager-folder-bridge.h"

#include "ptn-site-manager-file-bridge.h"

#include "ptn-folder-resource.h"
#include "ptn-file-resource.h"

#include "ptn-path-segment.h"

#include "ptn-path-resource.h"

#include "ptn-file-resource.h"

#include "ptn-resource-encoder.h"
#include "ptn-resource-decoder.h"
#include "ptn-site-request.h"

//#include "rz-tdcx/rz-tdcx/rz-tdcx-bridge.h"
//#include "rz-tdcx/rz-tdcx/rz-tdcx-typed-array.h"
//#include "rz-tdcx/rz-tdcx/rz-tdcx-typed-array-document.h"
//#include "rz-tdcx/rz-tdcx/rz-tdcx-typed-array-decoder.h"

#include "rz-qclasp-each/rz-qclasp-callback.h"
#include "rz-qclasp-each/rz-qclasp-each.h"

#include <QtEndian>

#include <QtGlobal>
#include <QtCore>
//#include <qtendian.h>

#include <QDebug>

#include <QNetworkRequest>
#include <QNetworkReply>

USING_RZNS(RZSite)
USING_RZNS(RZClasp)


template<>
struct TDCX_Type_Info<PTN_File_Resource> : TDCX_Byte_Array_Storage //?: TDCX_Pure_Value_Storage
{
 static QString get_QString_Type_Name(){ return "PTN_File_Resource"; }
 static int get_Type_Code(){ return 1; }
};


template<>
struct TDCX_Type_Info<PTN_Folder_Resource> : TDCX_Byte_Array_Storage //?: TDCX_Pure_Value_Storage
{
 static QString get_QString_Type_Name(){ return "PTN_Folder_Resource"; }
 static int get_Type_Code(){ return 2; }
};



PTN_Site_Manager_Folder_Bridge::PTN_Site_Manager_Folder_Bridge(QSharedPointer<PTN_Folder_Resource> folder_resource)
 : folder_resource_(folder_resource)
{

}

PTN_Site_Manager_Folder_Bridge::PTN_Site_Manager_Folder_Bridge(const PTN_Site_Manager_Folder_Bridge& rhs)
 : folder_resource_(rhs.folder_resource_)
{

}

PTN_Site_Manager_Folder_Bridge::PTN_Site_Manager_Folder_Bridge()
 : folder_resource_(nullptr)
{

}

QString PTN_Site_Manager_Folder_Bridge::file_list_summary()
{
 QString result;
 if(folder_resource_)
 {
  for(QString s : folder_resource_->contained_files())
  {
   result += QString("\n%1").arg(s);
  }
 }
 else
 {
  result = "Invalid Resource!";
 }
 return result;
}

QStringList PTN_Site_Manager_Folder_Bridge::contained_folders()
{
 if(folder_resource_)
 {
  return folder_resource_->contained_folders();
 }
 return QStringList();
}


QStringList PTN_Site_Manager_Folder_Bridge::contained_files()
{
 if(folder_resource_)
 {
  return folder_resource_->contained_files();
 }
 return QStringList();
}

QString PTN_Site_Manager_Folder_Bridge::folder_name()
{
 if(folder_resource_)
 {
  return folder_resource_->folder_name();
 }
 return QString();
}

QString PTN_Site_Manager_Folder_Bridge::complete_local_path()
{
 if(folder_resource_)
 {
  return folder_resource_->complete_local_path();
 }
 return QString();
}

void PTN_Site_Manager_Folder_Bridge::each_folder(RZ_QClasp_Callback* cb)
{
 if(folder_resource_)
 {
  for(QString s : folder_resource_->contained_folders())
  {
   PTN_Path_Resource ppr = folder_resource_->path_resource();
   PTN_Path_Resource ppr1 = ppr.under(s, PTN_Path_Segment::Segment_Roles::Folder_Generic);
   QSharedPointer<PTN_Folder_Resource> pfr =
     QSharedPointer<PTN_Folder_Resource>(new PTN_Folder_Resource(ppr1));

   PTN_Site_Manager_Folder_Bridge psmfb(pfr);

    // //   Using the "pointer" version of the type name ensures that
     //     the value will be passed as a pointer into other functions
   cb->run_function("PTN_Site_Manager_Folder_Bridge*", &psmfb);
  }
 }

}

void PTN_Site_Manager_Folder_Bridge::each_file(RZ_QClasp_Callback* ecb)
{
 if(folder_resource_)
 {
  for(QString s : folder_resource_->contained_files())
  {
   PTN_Path_Resource ppr = folder_resource_->path_resource();
   PTN_Path_Resource ppr1 = ppr.under(s);
   QSharedPointer<PTN_File_Resource> pfr =
     QSharedPointer<PTN_File_Resource>(new PTN_File_Resource(ppr1));

   PTN_Site_Manager_File_Bridge psmf(pfr);

    // //   Using the "pointer" version of the type name ensures that
     //     the value will be passed as a pointer into other functions
   ecb->run_function("PTN_Site_Manager_File_Bridge*", &psmf);
  }
 }
}

QString PTN_Site_Manager_Folder_Bridge::compare_info(PTN_Site_Manager_File_Bridge* fib)
{
 return QString("OK: %1").arg(fib->complete_local_path());
}

void PTN_Site_Manager_Folder_Bridge::each(RZ_QClasp_Each* ecb)
{
 if(folder_resource_)
 {
  for(QString s : folder_resource_->contained_files())
  {
   ecb->run_function("QString", &s);
  }
 }
}
