

#include "ptn-path-segment.h"

#include "ptn-path-resource.h"

#include "ptn-file-resource.h"

#include "ptn-resource-encoder.h"
#include "ptn-resource-decoder.h"
#include "ptn-site-request.h"

#include "ptn-site-manager-local-bridge.h"

#include "ptn-folder-resource.h"


//#include "rz-tdcx/rz-tdcx/rz-tdcx-bridge.h"
//#include "rz-tdcx/rz-tdcx/rz-tdcx-typed-array.h"
//#include "rz-tdcx/rz-tdcx/rz-tdcx-typed-array-document.h"
//#include "rz-tdcx/rz-tdcx/rz-tdcx-typed-array-decoder.h"

//#include "ptn-site-manager-folder-bridge.h"

#include <QtEndian>

#include <QtGlobal>
#include <QtCore>
//#include <qtendian.h>

#include <QDebug>

#include <QNetworkRequest>
#include <QNetworkReply>

USING_RZNS(RZSite)


template<>
struct TDCX_Type_Info<PTN_File_Resource> : TDCX_Byte_Array_Storage //?: TDCX_Pure_Value_Storage
{
 static QString get_QString_Type_Name(){ return "PTN_File_Resource"; }
 static int get_Type_Code(){ return 1; }
};


template<>
struct TDCX_Type_Info<PTN_Folder_Resource> : TDCX_Byte_Array_Storage //?: TDCX_Pure_Value_Storage
{
 static QString get_QString_Type_Name(){ return "PTN_Folder_Resource"; }
 static int get_Type_Code(){ return 2; }
};



int main0(int argc, char *argv[])
{
 QVector<int> sizes{{
   2,
   2, 2,2,
   3,3,3, 3,3,3,
   4,4,4,4, 4,4,4,4,
   5,5,5,5,5, 5,5,5,5,5,
   6,6,6,6,6,6, 6,6,6,6,6,6,
   7,7,7,7,7,7,7, 7,7,7,7,7,7,7,
   8,8,8,8,8,8,8,8, 8,8,8,8,8,8,8,8,
   9,9,9,9,9,9,9,9,9,
                    }};

 qDebug() << "i: " << sizes.size();

 int total = 0;

 for(int i = 1; i < 80; ++i)
 {
  int x = i * (sizes[i - 1]);
  total += x;
  qDebug() << "i: " << x;
 }
 qDebug() << total;

 int tt = total/79;
 qDebug() << tt;

 int tt1 = tt * 79;
 qDebug() << tt1;

 qDebug() << total - tt1;

 return 0;
}


int main(int argc, char *argv[])
{
 QCoreApplication app(argc, argv);

 PTN_Site_Manager_Local_Bridge psmb;

 psmb.set_web_root_folder("/home/nlevisrael/openshift/ptn-test/local-version");

 psmb.set_port(1726);
 psmb.set_host("localhost");

 QString file_name = "index.html";

 psmb.set_current_file_relative(file_name);

 QEventLoop qel;

 //QString result;

 //
 psmb.send_update([&qel](QString result)
 {
  qDebug() << "RR: " << result;
  qel.quit();
 } );

 qDebug() << "xxx";

 //?psmb.send_update_no_reply();

// QObject::connect(repl, &QNetworkReply::finished, [repl, &qel, &result] //&qel
//  {
//   result = repl->readAll();
//   qDebug() << "RESULT: " << result;
//   qel.quit();
//  });
 qel.exec();

// QEventLoop qel;
// QString result;

// QObject::connect(repl, &QNetworkReply::finished, [repl, &qel, &result]
// {
//  result = repl->readAll();
//  qDebug() << "RES: " << result;
//  qel.quit();
// });
// qel.exec();

// QEventLoop qel;
// qel.exec();
 return 0;
 //return app.exec();
}


int main2(int argc, char *argv[])
{
 QCoreApplication app(argc, argv);

 PTN_Site_Manager_Local_Bridge psmb;

 //PTN_Site_Manager_Bridge psmb;

//? psmb.set_web_root_folder("/home/nlevisrael/openshift/pvc/pvc-docker-image/web/pvc/public");
 psmb.set_web_root_folder("/home/nlevisrael/openshift/ptn-test");
 psmb.set_current_folder_relative("test-update");

 //psmb.set_current_file_relative("test-u1.html");

 psmb.set_port(1726);
 psmb.set_host("localhost");

 psmb.add_secondary_host("localhost", 1726);
 psmb.add_secondary_host("localhost", 17260);

 QString report_file = "/home/nlevisrael/openshift/recommendations3.xml";

 QString silo = "ptn-recommendation";

 qDebug() << "Getting response ...";

 QString response = psmb.get_silo_response(silo, report_file);

 qDebug() << "Response: " << response;

#ifdef HIDE
 QSharedPointer<PTN_Folder_Resource> pfr = psmb.get_remote_folder_as_resource();

 for(QString s : pfr->contained_folders())
 {
  qDebug() << "Checking update folder needed: " << s;
  psmb.enter_current_folder_relative(s);
  QSharedPointer<PTN_Folder_Resource> inner_pfr = psmb.get_remote_folder_as_resource();
  for(QString inner_s : inner_pfr->contained_files())
  {
   qDebug() << "Checking update file needed: " << inner_s;
   psmb.set_current_file_relative(inner_s);
   psmb.check_file_update_needed( [&psmb, &inner_s]
   {
    qDebug() << "Updating: " << inner_s;
    psmb.send_update();
   }
   );
  }
  psmb.leave_current_folder_relative();
 }
#endif // HIDE

 return 0;
}

#ifdef HIDE
int main3(int argc, char ** argv)
{
 QCoreApplication a{argc, argv};
 QNetworkAccessManager* manager = new QNetworkAccessManager;
 QString test = "ABCDEFGHIJKL";
 QNetworkRequest req(QUrl("http://localhost:1726/up__edit"));
 req.setHeader(QNetworkRequest::ContentTypeHeader, "raw");

 QNetworkReply* r = manager->post(req, test.toLatin1());

 QObject::connect(r, &QNetworkReply::finished, [r]()
 {
       qDebug() << r->readAll();
 });

 return a.exec();
}



int main2(int argc, char ** argv)
{
    QCoreApplication a{argc, argv};
    QNetworkAccessManager manager;
    QByteArray post{"a="};
    post.append(QByteArray{512, 'b'});
    QNetworkRequest req(QUrl("http://localhost:1726/up__edit"));
    req.setHeader(QNetworkRequest::ContentTypeHeader, "application/x-www-form-urlencoded");

    // Must be a queued connection, or else the multi-threaded manager might
    // win the race and signal quit before `a.exec()` starts running. In such
    // case, the `quit()` is a NOP. We don't want that.
    QObject::connect(&manager, &QNetworkAccessManager::finished, &a, [](QNetworkReply * reply){
       qDebug() << reply->errorString();
       qApp->quit();
    }, Qt::QueuedConnection);

    manager.post(req, post);
    return a.exec();
}




int main4(int argc, char *argv[])
{
 QCoreApplication app(argc, argv);


// ptn
 PTN_Path_Resource ptn_d_w("/home/nlevisrael/openshift/ptn/ptn-docker-image/web/ptn/public");
 ptn_d_w.set_segment_role(PTN_Path_Segment::Segment_Roles::Web_Root);

 // pvc
// PTN_Path_Resource ptn_d_w("/home/nlevisrael/openshift/pvc/pvc-docker-image/web/pvc/public");
// ptn_d_w.set_segment_role(PTN_Path_Segment::Segment_Roles::Web_Root);

//? PTN_Path_Resource file_p_r = ptn_d_w.under("main-info-pages/contact.html");
 PTN_Path_Resource file_p_r = ptn_d_w.under("test-update/test-update.html");

//? PTN_Path_Resource* file_p_r = new PTN_Path_Resource("/home/nlevisrael/test.txt");

 PTN_File_Resource pfr(file_p_r);
 pfr.load_contents();

 //?
 pfr.append_contents("\n<b>UPDATE TEST: OK></b>");

 QByteArray qba;

 pfr.to_qbytearray(qba);

// PTN_File_Resource pfr1;
// pfr1.from_qbytearray(qba);

 PTN_Resource_Encoder prenc;

// TDCX_Storing_Profile profile;
// TDCX_Typed_Array_Document tad;

//? enc.  tad.store(pfr, profile);

 QString encode; // = tad.encode();
 prenc.do_encode(pfr, encode);
 qDebug() << encode;

//  PTN_Resource_Decoder prdec;
//  QSharedPointer<PTN_File_Resource> pfr1 = prdec.do_decode<PTN_File_Resource>(encode);
//  qDebug() << pfr1->contents_to_latin1qstring();

//? PTN_Site_Request psr("localhost", 1726);

//? PTN_Site_Request psr("https://pvc-dev.arukascloud.io/");
// PTN_Site_Request psr("seaof-153-125-235-174.jp-tokyo-14.arukascloud.io", 31424);

//? psr.send_edit(encode);

// PTN_Resource_Decoder prdec;
// QSharedPointer<PTN_File_Resource> pfr1 = prdec.do_decode<PTN_File_Resource>(encode);
// qDebug() << pfr1->contents_to_latin1qstring();

 //QString result = pfr.contents_to_latin1qstring();
 //QString::fromLatin1(pfr.)

 //?qDebug() << result;
 return 0;

}
#endif
