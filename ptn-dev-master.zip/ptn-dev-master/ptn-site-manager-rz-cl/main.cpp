
//?
//#include "rz-qclasp-bridge/rz-qclasp-bridge.h"
//#include "rz-qclasp-eval/rz-qclasp-eval.h"

#include "rz-qclasp-generator/rz-qclasp-generator.h"



//#include "ptn-path-segment.h"
//#include "ptn-path-resource.h"
//#include "ptn-file-resource.h"
//#include "ptn-resource-encoder.h"
//#include "ptn-resource-decoder.h"
//#include "ptn-site-request.h"
//#include "ptn-site-manager-bridge.h"


//#include "rz-tdcx/rz-tdcx/rz-tdcx-bridge.h"
//#include "rz-tdcx/rz-tdcx/rz-tdcx-typed-array.h"
//#include "rz-tdcx/rz-tdcx/rz-tdcx-typed-array-document.h"
//#include "rz-tdcx/rz-tdcx/rz-tdcx-typed-array-decoder.h"

#include <QtEndian>

#include <QtGlobal>
#include <QtCore>
//#include <qtendian.h>

#include <QDebug>

#include <QNetworkRequest>
#include <QNetworkReply>

//USING_RZNS(RZSite)
USING_RZNS(RZClasp)


//template<>
//struct TDCX_Type_Info<PTN_File_Resource> : TDCX_Byte_Array_Storage //?: TDCX_Pure_Value_Storage
//{
// static QString get_QString_Type_Name(){ return "PTN_File_Resource"; }
// static int get_Type_Code(){ return 1; }
//};


//std::string program_name()
//{
// return "Clasp";
//}


void compile_rz(QString file)
{
 QString result;
 RZ_QClasp_Generator::compile_rz(file, result);
}

int main(int argc, char *argv[])
{
 compile_rz("/home/nlevisrael/rz-lisp/rz/t1.rz");
 return 0;
}

#ifdef HIDE
void run_clasp(QString file)
{
 RZ_QClasp_Eval* clasp_eval = new RZ_QClasp_Eval;

 char argc_ = 3;

 char* argv_[argc_];
 //?QDir::setCurrent(
 QString current_dir =  "/run/media/nlevisrael/DualBootShared/CLASPQ/branches/new-testing/clasp/build/boehmdc";

 qDebug() << current_dir;

 argv_[0] = "cclasp-boehmdc";
// ////
// argv_[1] = "-l";
// argv_[2] = "/home/nlevisrael/rz-dev/cl/exit.lisp";

 argv_[1] = "-I";
 argv_[2] = "-n";

 clasp_eval->start_clasp_from_dir(argc_, argv_, current_dir);
 RZ_QClasp_Bridge* clasp_bridge = new RZ_QClasp_Bridge(*clasp_eval);

 clasp_bridge->eval_file(file);

}

int main(int argc, char *argv[])
{
//? QApplication qapp(argc, argv);

  QCoreApplication qapp(argc, argv);
  qRegisterMetaType<PTN_Site_Manager_Bridge>();
  qRegisterMetaType<PTN_Site_Manager_Bridge*>();

// qRegisterMetaType<PTN_Recommendation_Clasp_Interface>();
// qRegisterMetaType<PTN_Recommendation_Clasp_Interface*>();

 std::map<std::string, int> dummy_map;
 dummy_map["x"] = 1;
 dummy_map["y"] = 2;

 compile_rz("/home/nlevisrael/scignscape-git/scripts/rz/t1.rz");
  //? run_clasp("/home/nlevisrael/scignscape-git/scripts/rz/t1.rz.cl");

}

// qRegisterMetaType<PTN_Recommendation_Clasp_Interface>();
// qRegisterMetaType<PTN_Recommendation_Clasp_Interface*>();
// qRegisterMetaType<PTN_Recommendation_Clasp_Interface>();
// qRegisterMetaType<PTN_Recommendation_Clasp_Interface*>();



int main1(int argc, char *argv[])
{
 QCoreApplication app(argc, argv);

 PTN_Site_Manager_Bridge psmb;

 psmb.set_web_root_folder("/home/nlevisrael/openshift/pvc/pvc-docker-image/web/pvc/public");

 //psmb.set_current_file_relative("index.html");

//
//? psmb.set_current_file_relative("seo-shared/sitemap.xml");
//?
//? psmb.set_host("pvc-dev.arukascloud.io");
//?
//? psmb.set_scheme("https");

// psmb.set_web_root_folder("/home/nlevisrael/openshift/ptn-test");
// psmb.set_current_file_relative("test-update/test-update.html");
// psmb.set_host("localhost");
// psmb.set_port(17260);

//? QString result = psmb.send_update();

//? qDebug() << "\nResult: " << result;
 return 0;
}
#endif
