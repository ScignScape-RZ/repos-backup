
//#include "/home/nlevisrael/scignscape-git/rz-qclasp/cpp/src/rz-qclasp-generator/rz-qclasp-generator.h"
#include "rz-qclasp-generator/rz-qclasp-generator.h"


//void compile_rz(QString file_name, QString& result)
//{
// RE_Document* doc = new RE_Document(file_name);
// doc->parse();

// doc->report_graph(file_name + ".txt");

// //    DEFAULT_RE_DIRECTORY "/t2.rz.txt");

// RE_Pre_Normal_Lisp prenorm(doc);
// prenorm.output("..prenorm.txt");

// RE_Prerun_Tokens tokens(doc); //, &RZ_Lisp_Token::init_lisp_token);
// tokens.output("..prenorm2.txt");


// RE_Prerun_Normalize normalize(*doc->graph());


// caon_ptr<RZ_Lisp_Graph_Visitor> visitor = normalize.scan();

// visitor->set_document_directory(doc->local_directory());

// QString handlers = doc->rz_path_handlers();
// if(!handlers.isEmpty())
// {
//  visitor->prepare_rz_path_handlers_output(handlers);
// }


// doc->report_graph(file_name + ".re1.txt");

// // DEFAULT_RE_DIRECTORY "/t2.re1.txt");

// RE_Pre_Normal_Lisp prenorm1(doc);
// prenorm1.output("..prenorm1.txt");


// RZ_Clasp_Code_Generator& ccg = *visitor->rz_clasp_code_generator();


// RE_Generate_Clasp gen(*visitor);


// RE_Prerun_Anticipate anticipate(*visitor);

// RZ_File_List_Type extra_files;

// gen.init_project(extra_files);
// anticipate.scan();

// QString output;
// QTextStream qts(&output);
// //ccg.write(qts);


// gen.write(qts);
// //qDebug() << output;

// QString output1;


// QTextStream qts1(&output1);


// ccg.write(qts1);
// //gen.write(qts);
// qDebug() << output1.toStdString().c_str();


// //?QString result = doc->local_path() + ".cxq";

// QString result_file = doc->local_path() + ".cl";
// QFile outfile(result_file);


// if(outfile.open(QIODevice::WriteOnly | QIODevice::Text))
// {
//  QTextStream out(&outfile);
//  out << output1;
// }
// result = output1;

//}


USING_RZNS(RZClasp)

int main(int argc, char *argv[])
{
 QString result;
 RZ_QClasp_Generator::compile_rz("/home/nlevisrael/scignscape-git/scripts/rz/t1.rz", result);
 //QApplication qapp(argc, argv);

 return 0;

}

