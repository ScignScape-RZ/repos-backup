
#include "rz-tdcx-bridge.h"

#include <QtEndian>

USING_RZNS(TransDCX)


TDCX_Bridge::TDCX_Bridge(//QString default_data_directory,
                         callback_type callback)
 : //default_data_directory_(default_data_directory),
   callback_(callback), highest_typecode_(0)
{

}

void TDCX_Bridge::check_load_typed_value_count(QString& str, u32& val, u32 inc)
{
 str.prepend('(');
 str.append(")0");
 QSharedPointer<QByteArray> sba(new QByteArray(4, 0));
 void* args[2] {&str, &sba};
 callback("DB_Load", 2, args);
 u32 count;
 memcpy(&count, sba->data(), 4);
 val = inc + qFromBigEndian(count);
 u32 store = qToBigEndian(val);
 memcpy(sba->data(), &store, 4);
 callback("DB_Store", 2, args);
 str.chop(1);
 // //  32 is for "base 32", 0-9 and a-v
 str.append(QString::number(val, 32));
}

void TDCX_Bridge::store_load_typed_value_count(QString& str, u32& val)
{
 str.prepend('(');
 str.append(")0");
 QSharedPointer<QByteArray> sba(new QByteArray(4, 0));
 void* args[2] {&str, &sba};
 u32 store = qToBigEndian(val);
 memcpy(sba->data(), &store, 4);
 callback("DB_Store", 2, args);
}


TDCX_Bridge::u32 TDCX_Bridge::get_typecode(QString& str)
{
 // //   Accept the operator[] semantics of inserting a new key by default
 u32& result = type_codes_[str];
 if(result == 0)
 {
  result = check_typecode(str);
 }
 str = QString::number(result, 32);
 return result;
}

TDCX_Bridge::u32 TDCX_Bridge::check_typecode(QString str)
{
 QSharedPointer<QByteArray> sba(new QByteArray(4, 0));
 void* args[2] {&str, &sba};
 callback("DB_Load", 2, args);
 u32 count;
 memcpy(&count, sba->data(), 4);
 u32 result = qFromBigEndian(count);
 if(result == 0)
 {
  QString key = "$$HIGHEST_TYPECODE";
  if(highest_typecode_ == 0)
  {
   void* args[2] {&key, &sba};
   callback("DB_Load", 2, args);
   u32 count;
   memcpy(&count, sba->data(), 4);
   highest_typecode_ = 1 + qFromBigEndian(count);
  }
  u32 store = qToBigEndian(highest_typecode_);
  memcpy(sba->data(), &store, 4);
  callback("DB_Store", 2, args);
  result = highest_typecode_;
 }
 return result;
}


TDCX_Bridge::u32 TDCX_Bridge::get_new_value_code(QString& str, u32& typecode, u32 inc)
{
 u32& val = typed_value_codes_[str];
 typecode = get_typecode(str);
 // //   Accept the operator[] semantics of inserting a new key by default
 if(val == 0)
 {
  check_load_typed_value_count(str, val, inc);
 }
 else
 {
  val += inc;
  store_load_typed_value_count(str, val);
 }
 return val;
}



int TDCX_Bridge::create_or_open(QString database_directory, QString database_file_name)
{
 QString* args[2] {&database_directory, &database_file_name};
 return callback("DB_Create_Or_Open", 2, args);
}


int TDCX_Bridge::callback(QString message, int arglength, void* data)
{
 return callback_(message, arglength, data);
}
