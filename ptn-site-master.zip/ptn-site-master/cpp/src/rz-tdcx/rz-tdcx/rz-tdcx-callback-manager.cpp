
#include "rz-tdcx-callback-manager.h"

#include <QBitArray>
#include <QString>

#include <QDebug>
#include <QtEndian>
#include <QtMath>

//ACCESSORS__DECLARE(int ,bitsize)
//ACCESSORS__DECLARE(int ,padding)

#include "rzns.h"

USING_RZNS(TransDCX)


int TDCX_Callback_Manager::callback(QString message, void *data)
{
 callback(message, 1, data);
}

int TDCX_Callback_Manager::callback(QString message)
{
 callback(message, 0, nullptr);
}

int TDCX_Callback_Manager::callback(QString message, QString arg1, QString arg2)
{
 QString* args[2] = {&arg1, &arg2};
 callback(message, 2, args);
}
