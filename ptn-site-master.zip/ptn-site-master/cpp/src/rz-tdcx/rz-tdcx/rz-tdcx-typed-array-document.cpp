
#include "rz-tdcx-typed-array-document.h"

#include <QtEndian>

#include "rzns.h"

USING_RZNS(TransDCX)

TDCX_Typed_Array_Document::TDCX_Typed_Array_Document()
{
 //typed_arrays_.push_back(nullptr);
}

TDCX_Typed_Array_Document::u32 TDCX_Typed_Array_Document::add_typed_array(QSharedPointer<TDCX_Typed_Array> ta)
{
 u32 result = typed_arrays_.size();
 typed_arrays_.push_back(ta);
 return result;
}


void TDCX_Typed_Array_Document::encode(const TDCX_Typed_Array& ta, QByteArray& qba)
{
 qba.append(ta.data());
}

void TDCX_Typed_Array_Document::encode(const TDCX_Typed_Array& ta, QString& code)
{
 QByteArray qba;
 encode(ta, qba);
 int s = qba.size();
 QString result;
 // 170 2 1 240 4

 int r1 = s % 5;
 int r2 = 5 - r1;

 int remainder = s % 5;
 if(remainder != 0)
 {
  remainder = 5 - remainder;
 }

 for(int i = 0; i < s; i += 5)
 {
  u64 val = 0;
  memcpy(&val, qba.data() + i, 5);
  QString v1 = QString("%1").arg(val, 8, 32, QChar('0'));
  QString vb1 = QString::number(val, 2);
//  val = qToBigEndian(val);
//  val >>= 24;
//  val = qFromBigEndian(val);
  QString v2 = QString::number(val, 32);
  QString vb2 = QString::number(val, 2);


  QByteArray check (5, 0);
  memcpy(check.data(), &val, 5);

  QByteArray check1 (5, 0);
  memcpy(check1.data(), (void*)((size_t)&val + 3), 5);


  result += QString("%1").arg(val, 8, 32, QChar('0')); //?QString::number(val, 32);

 }
 switch(remainder)
 {
 case 0: code += result + 'w'; break;
 case 1: code += result + 'x'; break;
 case 2: code += result + 'y'; break;
 case 3: code += result + 'z'; break;
 case 4: code += result + '_'; break;
 }
}

QString TDCX_Typed_Array_Document::encode()
{
 QString result;
 for(QSharedPointer<TDCX_Typed_Array> ta : typed_arrays_)
 {
  encode(*ta, result);
 }
// result.chop(1);
 return result;
}
