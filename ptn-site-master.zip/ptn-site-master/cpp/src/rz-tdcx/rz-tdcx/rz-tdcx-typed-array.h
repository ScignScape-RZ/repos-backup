
#ifndef RZ_TDCX_TYPED_ARRAY__H
#define RZ_TDCX_TYPED_ARRAY__H

#include <cstdint>
#include <QByteArray>

#include <memory>

#include "rzns.h"

#include "accessors.h"

#include "rz-tdcx-type-info.h"
#include "rz-tdcx-storing-profile.h"

struct Unusued_Typed_Array_Holder_Type {};

template<typename T, typename TYPED_ARRAY_HOLDER_Type = Unusued_Typed_Array_Holder_Type>
void TDCX_To_QByteArray(const T& t, QByteArray& qba, TYPED_ARRAY_HOLDER_Type* holder = nullptr)
{
 t.to_qbytearray(qba);
}

template<typename T>
void TDCX_From_QByteArray(T& t, const QByteArray& qba)
{
 t.from_qbytearray(qba);
}

RZNS_(TransDCX)

class TDCX_Storing_Profile;

class TDCX_Typed_Array
{
public:
 typedef std::uint8_t u8;
 typedef std::uint32_t u32;
 typedef std::uint64_t u64;

private:

 static constexpr u8 _Default_bytes_key = 0b01000000;
 static constexpr u8 _Default_type_code_bytes_length = 3;
 static constexpr u8 _Default_length_bytes_length = 1;
 static constexpr u8 _Default_bitsize_bytes_length = 1;
 static constexpr u32 _Default_type_code = 1;
 static constexpr u8 _Default_bitsize = 38 << 2;
 static constexpr u8 _Default_raw_bitsize = 38;
 static constexpr u32 _Default_length = 1;
 static constexpr Padding_Mode _Default_padding = Padding_Mode::None;

 //static constexpr u8 mode_bit_length = 2;

 //enum Modes { Always_Direct, Always_Ref };

 TDCX_Storage_Modes storage_mode_;

 u64 type_code_;
 //std::int8_t bytes_key_;
 QByteArray data_;
 u64 length_;
 u64 bitsize_;
 u64 data_start_position_;
 void decode_bytes(u8 key);
 void init_data_start(u8 key);
 void decode_bytes()
 {
  decode_bytes(data_[0]);
 }

 template<typename T>
 inline void encode_length(T t, u8& key, u8 offset)
 {
  int size = t;
  int size_bytes_length = 0;
  size >>= 8;
  while(size > 0)
  {
   size >>= 8;
   ++size_bytes_length;
  }
  key |= (size_bytes_length << offset);
 }

 template<typename T>
 inline void encode_raw_length(T t, u8& key, u8 offset)
 {
  key |= (t << offset);
 }
 struct Fine_Index {
  int bit_index;
  int byte_index;
 };

 TDCX_Storing_Profile* profile_;

 int check_resize(Fine_Index& fi);
 int reserve(size_t number_of_bits);
 int get_next_index();

 void update_typecode(u32 typecode);
 void update_typecode(u32 typecode, u8 type_code_bytes_length);
 void update_bitsize(u32 bitsize);
 void update_bitsize(u32 bitsize, u8 bitsize_bytes_length, u8 type_code_bytes_length);
 void update_length(u32 length);
 void update_length(u32 length, u8 length_bytes_length, u8 type_code_and_bitsize_bytes_length);
 void update_increment_length();
 void update_increment_length(u8 length_bytes_length, u8 type_code_and_bitsize_bytes_length);
 void check_init_profile();

 void set_raw_bitsize(int bitsize)
 {
  bitsize_ |= bitsize << 2;
 }

 void set_raw_padding(Padding p)
 {
  set_raw_padding_code(p.code());
 }

 void set_raw_padding_code(int padding_code)
 {
  bitsize_ |= padding_code;
 }

 u8 padding_code() const
 {
  return bitsize_ & 3;
 }

 void init_length_bytes();

public:

 ACCESSORS(int ,type_code)
 ACCESSORS(int ,length)
 ACCESSORS(QByteArray ,data)
 ACCESSORS__DECLARE(int ,bitsize)
 ACCESSORS__DECLARE(Padding_Mode ,padding)
 ACCESSORS(TDCX_Storage_Modes ,storage_mode)


 TDCX_Typed_Array(TDCX_Storing_Profile& profile);
 TDCX_Typed_Array(u8 bytes_key = _Default_bytes_key);

 TDCX_Typed_Array(const QByteArray& lhs);

 u8 storage_mode_bit_length()
 {
  switch(storage_mode_)
  {
  case TDCX_Storage_Modes::Mixed: return 2;
  default: return 0;
  }
 }

 u8 padding_bit_length()
 {
  switch(padding())
  {
  case Padding_Mode::Byte_Array :
  case Padding_Mode::None : return 0;
  case Padding_Mode::First:
  case Padding_Mode::Last: return 8 - bitsize() % 8;
  }
 }


 void decode();
 u8 bytes_key();

 void init_lengths_with_typecode(u32 typecode)
 {
  check_init_profile();
  type_code_ = typecode;
  init_length_bytes();
 }

 void store_ref(u64 index);
 void store_direct_value(u64 val);
 void store_direct_value(const QByteArray& qba);

 u64 read_direct_value(u32 index = 0);
 void read_direct_value(QByteArray& qba, u32 index = 0);

 void read_to_qbytearray(QByteArray& qba, u32 index = 0);


 int position_index(Fine_Index& fi, int index);

 //void load_data(const QByteArray& qba);

 QString full_rep();
 static QString full_rep(u8 U8);
 static QByteArray check_invert(const QByteArray& qba);

 template<typename T>
 void to_value(T& t)
 {
  QByteArray qba;
  read_direct_value(qba);
  TDCX_From_QByteArray(t, qba);
 }

};


_RZNS(TransDCX)

USING_RZNS(TransDCX)

template<typename T>
T* TDCX_Match_Type_Code(TDCX_Typed_Array& ta)
{
 if(ta.type_code() == TDCX_Get_Type_Code<T>())
 {
  return (T*)std::malloc(sizeof(T));
 }
 return nullptr;
}

template<typename T>
T* TDCX_Initialize(T** t, TDCX_Typed_Array& ta)
{
 *t = new (*t) T();
 return *t;
}



#endif
