
#include "downpull-data-receiver.h"
#include "downpull-request-manager.h"

#include <QDebug>
#include <QFile>


Downpull_Data_Receiver::Downpull_Data_Receiver(Downpull_Request_Manager* drm,
  QString report_file, QMap<QString, QString>& hosts)
 : drm_(drm), report_file_(report_file)
{
 url_key_by_host_ = hosts;
 for(QString h : hosts.keys())
 {
  response_count_by_host_[h] = -1;
 }
}

void Downpull_Data_Receiver::check_for_completion(QString host)
{
 QMapIterator<QString, int> it(response_count_by_host_);

 while(it.hasNext())
 {
  it.next();
  if(it.value() == -1)
   return;
  if(it.value() > 0)
   return;
 }

 // // all done ...



 QMapIterator<QString, QString> it1(xml_text_by_host_);
 while(it1.hasNext())
 {
  it1.next();
  result_text_ += it1.value();
 }

 QFile outfile(report_file_);

 if( outfile.open(QIODevice::WriteOnly) )
 {
  QTextStream qts(&outfile);
  qts << result_text_;
 }

 outfile.close();

 Q_EMIT all_records_received_and_saved();


}

void Downpull_Data_Receiver::handle_host_records_received(QString host, QString text, int count)
{
 xml_text_by_host_[host] += text;

 int rc = response_count_by_host_[host] -= count;
 if(rc == 0)
 {
  check_for_completion(host);
 }
}

void Downpull_Data_Receiver::handle_host_count_received(QString host, int count)
{
 //
 QString url_key = url_key_by_host_[host];
 qDebug() << "Host: " << host << "; count: " << count << "; key: " << url_key;

 response_count_by_host_[host] = count;

 if(count == 0)
 {
  check_for_completion(host);
 }

 for(int i = 1; i <= count; i += 10)
 {
  int end = i + 9;
  if(end > count)
   end = count;

//?
  drm_->get_xml_records_response(host, url_key, "ptn-recommendation", i, end);
 //? get_records(addr, "ptn-recommendation-", 2, 2);
 }

}
