
#include "downpull-request-manager.h"



#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QCoreApplication>
#include <QUrlQuery>
 //?#include <QXmlQuery>
#include <QBuffer>

#include <QRegularExpression>
#include <QRegularExpressionMatch>

#include <QUrl>


Downpull_Request_Manager::Downpull_Request_Manager(QNetworkAccessManager* qnam)
 : qnam_(qnam)
{

}

void Downpull_Request_Manager::get_xml_records_response(QString host, QString url_key, QString silo,
  int start, int end)
{
 QString addr = QString("http://%1/qt-client").arg(host);

 QUrl url(addr);
 QUrlQuery urlq;
 urlq.addQueryItem("silo", silo);
 urlq.addQueryItem("action", "get-records");
 urlq.addQueryItem("url-key", url_key);
 urlq.addQueryItem("start", QString::number(start));
 urlq.addQueryItem("end", QString::number(end));
 url.setQuery(urlq);


 QNetworkRequest req;

//? qDebug() << "Host: " << host << "URL: " << url.toString();

 req.setUrl(url);

 QNetworkReply* reply = qnam_->get(req);

// QObject::connect(&qnam, static_cast<void (QNetworkAccessManager::*)(QNetworkReply*)>
// (&QNetworkAccessManager::finished),
// [&qnam, addr, host, this](QNetworkReply* reply)

 QObject::connect(reply, &QNetworkReply::finished,
  [addr, host, reply, this, start, end]()
 {
  QString text = QString::fromLatin1( reply->readAll() );
  if(text.isEmpty())
  {
   //qDebug() << "empty text";
   return;
  }

  Q_EMIT(host_records_received(host, text, end - start + 1));

//?  qDebug() << "Host: " << host << "Text: " << text;
 });

}

void Downpull_Request_Manager::get_xml_count_response(QString host, QString url_key, QString silo)
{
 //?QString addr = QString("https://%1/qt-client").arg(host);
 QString addr = QString("http://%1/qt-client").arg(host);
 QUrl url(addr);
 QUrlQuery urlq;
 urlq.addQueryItem("silo", silo);
 urlq.addQueryItem("action", "get-count");
 urlq.addQueryItem("url-key", url_key);

 url.setQuery(urlq);

 QNetworkRequest req;

//?
 qDebug() << "Host: " << host << "URL: " << url.toString();

 req.setUrl(url);

 QNetworkReply* reply = qnam_->get(req);

// QObject::connect(&qnam, static_cast<void (QNetworkAccessManager::*)(QNetworkReply*)>
// (&QNetworkAccessManager::finished),
// [&qnam, addr, host, this](QNetworkReply* reply)

  QObject::connect(reply, &QNetworkReply::finished,
  [addr, host, url_key, reply, this]()
 {
  QString text = QString::fromLatin1( reply->readAll() );
  if(text.isEmpty())
  {
   Q_EMIT(host_count_received(host, 0));
   return;
  }

//  QBuffer device;
//  device.setData(text.toUtf8());
//  device.open(QIODevice::ReadOnly);

   QRegularExpression rx("<record-count>\\s*(\\d+)");
   QRegularExpressionMatch rxm = rx.match(text);
   int count = 0;
   if(rxm.hasMatch())
   {
    QString num = rxm.captured(1);
    count = num.toInt();
   }
//  QXmlQuery query;
//  QString q = "doc($inputDocument)/result/record-count/text()";
//  query.bindVariable("inputDocument", &device);
//  query.setQuery(q);
//  int count = 0;
//  if (query.isValid())
//  {
//   QString qs;
//   query.evaluateTo(&qs);
//   count = qs.trimmed().toInt();
//  }

  Q_EMIT(host_count_received(host, count));

//  for(int i = 1; i <= count; i += 10)
//  {
//   int end = i + 9;
//   if(end > count)
//    end = count;
//   RZ::PTN::get_records(*clasp_bridge, addr, "ptn-recommendation", i, end);
//  }

//?   qDebug() << "Count: " << count;
 });

}
