
#include "ptn-file-resource.h"

#include <QFile>
#include <QDataStream>
#include <QFileInfo>

USING_RZNS(RZSite)


PTN_File_Resource::PTN_File_Resource(PTN_Path_Resource& path_resource)
 : path_resource_(path_resource)
{

}

PTN_File_Resource::PTN_File_Resource()
 : path_resource_(PTN_Path_Resource())
{

}

void PTN_File_Resource::to_qbytearray(QByteArray& qba) const
{
 QDataStream qds(&qba, QIODevice::WriteOnly);
 //?QString pr = path_resource_->complete_local_path();

// QByteArray pr_qba;
// path_resource_.to_qbytearray(pr_qba);

 qds << path_resource_;
 qds << contents_;

 // qds << *path_resource_;
 // //path_resource_->write_to(qds);
 // qds << contents_;
}

void PTN_File_Resource::get_last_modified(QDateTime& qdt)
{
 QString clp = path_resource_.complete_local_path();
 QFile qf(clp);
 QFileInfo qfi(qf);
 qdt = qfi.lastModified();
}

void PTN_File_Resource::from_qbytearray(const QByteArray& qba)
{

 //?&qba, QIODevice::ReadOnly
 QDataStream qds(qba);
 //?QString pr;

  qds >> path_resource_;

// QByteArray pr_qba;
// qds >> pr_qba;
// path_resource_.from_qbytearray(pr_qba);

 qds >> contents_;

 //?path_resource_->write_to(qds);

// qds >> *path_resource_;
// qds >> contents_;

}


void PTN_File_Resource::append_contents(QString str)
{
 contents_.append(str);
}

QString PTN_File_Resource::file_name()
{
 return path_resource_.file_name();
}


quint64 PTN_File_Resource::load_contents()
{
 QString path = path_resource_.complete_local_path();
 QFile infile(path);
 if(infile.open(QIODevice::ReadOnly))
 {
  contents_ = infile.readAll();
  return contents_.length();
 }
 return -1;
}

QString PTN_File_Resource::contents_to_latin1qstring()
{
 return QString::fromLatin1(contents_);
}
