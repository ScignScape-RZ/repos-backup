
#ifndef PTN_FILE_RESOURCE__H
#define PTN_FILE_RESOURCE__H

#include <QString>

#include <QByteArray>
#include <QDateTime>

#include "rzns.h"

#include "ptn-path-resource.h"

RZNS_(RZSite)


class PTN_File_Resource
{
 PTN_Path_Resource path_resource_;

 QByteArray contents_;

public:

 PTN_File_Resource(PTN_Path_Resource& path_resource);
 PTN_File_Resource();

 ACCESSORS__CONST_RGET(PTN_Path_Resource ,path_resource)

 quint64 load_contents();

 QString contents_to_latin1qstring();

 QString file_name();

 void to_qbytearray(QByteArray& qba) const;
 void from_qbytearray(const QByteArray& qba);

 void append_contents(QString str);

 void get_last_modified(QDateTime& qdt);



};


_RZNS(RZSite)


#endif
