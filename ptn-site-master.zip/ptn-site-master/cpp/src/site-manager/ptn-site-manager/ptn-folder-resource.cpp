
#include "ptn-folder-resource.h"

#include <QFile>
#include <QDataStream>
#include <QFileInfo>

#include <QDir>

USING_RZNS(RZSite)


PTN_Folder_Resource::PTN_Folder_Resource(PTN_Path_Resource& path_resource)
 : path_resource_(path_resource)
{

}

PTN_Folder_Resource::PTN_Folder_Resource()
 : path_resource_(PTN_Path_Resource())
{

}

void PTN_Folder_Resource::set_path_resource(const PTN_Path_Resource& ptr)
{
 path_resource_ = ptr;
}


void PTN_Folder_Resource::read_contained(QMap<PTN_Path_Segment::Segment_Roles, QString>&& substitutions)
{
 QDir qd(path_resource_.complete_path(std::move(substitutions)));
 QFileInfoList qfil = qd.entryInfoList();
 for(QFileInfo qfi : qfil)
 {
  if(qfi.isDir())
  {
   if(qfi.fileName() == ".")
    continue;
   if(qfi.fileName() == "..")
    continue;
   contained_folders_.append(qfi.fileName());
  }
  else
  {
   contained_files_.append(qfi.fileName());
  }
 }
}

QString PTN_Folder_Resource::folder_name()
{
 QDir qd(path_resource_.complete_local_path());
 return qd.dirName();
}

QString PTN_Folder_Resource::complete_local_path()
{
 return path_resource_.complete_local_path();
}

void PTN_Folder_Resource::read_contained()
{
 //path_resource_.
 QDir qd(path_resource_.complete_local_path());
 QFileInfoList qfil = qd.entryInfoList();
 for(QFileInfo qfi : qfil)
 {
  if(qfi.isDir())
  {
   if(qfi.fileName() == ".")
    continue;
   if(qfi.fileName() == "..")
    continue;
   contained_folders_.append(qfi.fileName());
  }
  else
  {
   contained_files_.append(qfi.fileName());
  }
 }

}

void PTN_Folder_Resource::add_file(QString name)
{
 contained_files_.append(name);
}

void PTN_Folder_Resource::add_folder(QString name)
{
 contained_folders_.append(name);
}


void PTN_Folder_Resource::to_qbytearray(QByteArray& qba) const
{
 QDataStream qds(&qba, QIODevice::WriteOnly);
 qds << path_resource_;
 qds << contained_folders_;
 qds << contained_files_;
}

void PTN_Folder_Resource::from_qbytearray(const QByteArray& qba)
{
 QDataStream qds(qba);
 qds >> path_resource_;

 qds >> contained_folders_;
 qds >> contained_files_;
}


//?
//void PTN_Folder_Resource::get_last_modified(QDateTime& qdt)
//{
// QString clp = path_resource_.complete_local_path();
// QFile qf(clp);
// QFileInfo qfi(qf);
// qdt = qfi.lastModified();
//}
