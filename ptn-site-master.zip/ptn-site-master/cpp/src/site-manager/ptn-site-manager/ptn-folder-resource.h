
#ifndef PTN_FOLDER_RESOURCE__H
#define PTN_FOLDER_RESOURCE__H

#include <QString>

#include <QByteArray>
#include <QDateTime>

#include "rzns.h"

#include "ptn-path-resource.h"

RZNS_(RZSite)


class PTN_Folder_Resource
{
 PTN_Path_Resource path_resource_;

 QStringList contained_files_;
 QStringList contained_folders_;

public:

 PTN_Folder_Resource(PTN_Path_Resource& path_resource);
 PTN_Folder_Resource();

 ACCESSORS__CONST_RGET(PTN_Path_Resource ,path_resource)

 ACCESSORS__CONST_RGET(QStringList ,contained_folders)
 ACCESSORS__CONST_RGET(QStringList ,contained_files)

 void set_path_resource(const PTN_Path_Resource& ptr);

 void to_qbytearray(QByteArray& qba) const;
 void from_qbytearray(const QByteArray& qba);

 void add_file(QString name);
 void add_folder(QString name);
 void read_contained();

 void read_contained(QMap<PTN_Path_Segment::Segment_Roles, QString>&& substitutions);

 QString folder_name();

 QString complete_local_path();


 //?void get_last_modified(QDateTime& qdt);


};


_RZNS(RZSite)


#endif
