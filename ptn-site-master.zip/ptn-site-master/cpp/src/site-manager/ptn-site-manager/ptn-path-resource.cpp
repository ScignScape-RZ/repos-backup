
#include "ptn-path-resource.h"

#include <QDataStream>

USING_RZNS(RZSite)

PTN_Path_Resource::PTN_Path_Resource()
{

}

PTN_Path_Resource::PTN_Path_Resource(QString local_path)
{
 segments_.append(PTN_Path_Segment(local_path));
}

PTN_Path_Resource::PTN_Path_Resource(const PTN_Path_Segment& segment)
{
 segments_.append(segment);
}

PTN_Path_Resource::PTN_Path_Resource(const QList<PTN_Path_Segment>& segments)
{
 segments_.append(segments);
}

void PTN_Path_Resource::add_segment(QString local_path, PTN_Path_Segment::Segment_Roles sr)
{
 segments_.append(PTN_Path_Segment(local_path, sr));
}

void PTN_Path_Resource::reset_segments(QString local_path)
{
 segments_.clear();
 segments_.append(PTN_Path_Segment(local_path));
}

void PTN_Path_Resource::add_segment(PTN_Path_Segment& pps)
{
 segments_.append(pps);
}

void PTN_Path_Resource::reset_segments(PTN_Path_Segment& pps)
{
 segments_.clear();
 segments_.append(pps);
}

void PTN_Path_Resource::reset_segments(PTN_Path_Segment&& pps)
{
 segments_.clear();
 segments_.append(pps);
}

PTN_Path_Resource PTN_Path_Resource::under(QString partial_path,
  PTN_Path_Segment::Segment_Roles sr)
{
 PTN_Path_Resource result = PTN_Path_Resource(segments_);
 result.add_segment(partial_path, sr);
 return result;
}

QString PTN_Path_Resource::complete_local_path() const
{
 QString result;
 for(const PTN_Path_Segment& pps : segments_)
 {
  result += pps.local_to_string();
 }
 return result;
}

void PTN_Path_Resource::unroll_segment(PTN_Path_Segment::Segment_Roles sr)
{
 if(!segments_.isEmpty())
 {
  if(segments_.last().segment_role() == sr)
  {
   segments_.removeLast();
  }
 }
}

QString PTN_Path_Resource::file_name() const
{
 for(PTN_Path_Segment s : segments_)
 {
  if(s.segment_role() == PTN_Path_Segment::Segment_Roles::File_Generic)
  {
   return s.local_to_string();
  }
 }
 return QString();
}

void PTN_Path_Resource::to_qbytearray(QByteArray& qba) const
{
 QDataStream qds(&qba, QIODevice::WriteOnly);
 for(const PTN_Path_Segment& pps : segments_)
 {
  QByteArray pps_qba;
  pps.to_qbytearray(pps_qba);
  qds << pps_qba;
 }

}

void PTN_Path_Resource::from_qbytearray(const QByteArray& qba)
{
 QDataStream qds(qba);
 QByteArray pps_qba;
 qds >> pps_qba;
 PTN_Path_Segment pps;
 pps.from_qbytearray(pps_qba);
 //?qba pps_qba;

}

void PTN_Path_Resource::set_segment_role(PTN_Path_Segment::Segment_Roles sr)
{
 if(!segments_.isEmpty())
 {
  PTN_Path_Segment& pps = segments_.last();
  pps.set_segment_role(sr);

 }
}



void RZ::RZSite::operator>>(QDataStream& qds, PTN_Path_Resource& ppr)
{
 int segment_size;

 qds >> segment_size;

 for(int i = 0; i < segment_size; ++i)
 {
  PTN_Path_Segment pps;
  qds >> pps;
  ppr.add_segment(pps);

 }

}

void RZ::RZSite::operator<<(QDataStream& qds, const PTN_Path_Resource& ppr)
{
 qds << ppr.segments().size();
 for(const PTN_Path_Segment& pps : ppr.segments())
 {
  qds << pps;
 }
}

QString PTN_Path_Resource::complete_path(const QMap<PTN_Path_Segment::Segment_Roles, QString>&& substitutions) const
{
 QString result;
 for(const PTN_Path_Segment& pps : segments_)
 {
  result += pps.to_string(substitutions);
 }
 return result;
}



