
#ifndef PTN_PATH_RESOURCE__H
#define PTN_PATH_RESOURCE__H

#include <QString>
#include <QList>

#include "rzns.h"
#include "accessors.h"

#include "ptn-path-segment.h"

//#define ACCESSORS__CONST_RGET__CONST(type, name) \
// const type& name() const { return name##_; }


RZNS_(RZSite)


class PTN_Path_Resource
{
 QList<PTN_Path_Segment> segments_;

public:

// ACCESSORS(QString ,local_path)
// ACCESSORS(QString ,remote_path)
// ACCESSORS(PTN_Path_Resource* ,parent)
// ACCESSORS(Path_Roles ,path_role)

 PTN_Path_Resource();
 PTN_Path_Resource(QString local_path);
 PTN_Path_Resource(const PTN_Path_Segment& segment);
 PTN_Path_Resource(const QList<PTN_Path_Segment>& segments);

 ACCESSORS__CGET(QList<PTN_Path_Segment> ,segments)

 void unroll_segment(PTN_Path_Segment::Segment_Roles sr = PTN_Path_Segment::Segment_Roles::Folder_Generic);

 PTN_Path_Resource under(QString partial_path,
   PTN_Path_Segment::Segment_Roles sr = PTN_Path_Segment::Segment_Roles::File_Generic);

 QString complete_local_path() const;

 QString file_name() const;

 QString complete_path(const QMap<PTN_Path_Segment::Segment_Roles, QString>&& substitutions) const;

 void to_qbytearray(QByteArray& qba) const;
 void from_qbytearray(const QByteArray& qba);

 void add_segment(QString local_path,
   PTN_Path_Segment::Segment_Roles sr = PTN_Path_Segment::Segment_Roles::File_Generic);
 void add_segment(PTN_Path_Segment& pps);

 void reset_segments(QString local_path);
 void reset_segments(PTN_Path_Segment& pps);
 void reset_segments(PTN_Path_Segment&& pps);

 void set_segment_role(PTN_Path_Segment::Segment_Roles sr);

// void write_to(QDataStream& qds) const;

 friend void operator>>(QDataStream& qds, PTN_Path_Resource& ppr);
 friend void operator<<(QDataStream& qds, const PTN_Path_Resource& ppr);


};


_RZNS(RZSite)


#endif
