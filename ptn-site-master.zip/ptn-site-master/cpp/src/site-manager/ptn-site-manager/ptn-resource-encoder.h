
#ifndef PTN_RESOURCE_ENCODER__H
#define PTN_RESOURCE_ENCODER__H

#include <QString>

#include "rzns.h"

#include "accessors.h"

#include "rz-tdcx/rz-tdcx/rz-tdcx-typed-array.h"
#include "rz-tdcx/rz-tdcx/rz-tdcx-typed-array-document.h"
#include "rz-tdcx/rz-tdcx/rz-tdcx-typed-array-decoder.h"

RZNS_(RZSite)


class PTN_Resource_Encoder
{
 TDCX_Storing_Profile profile_;
 TDCX_Typed_Array_Document tad_;

 //PTN_Resource_Encoder

public:

 PTN_Resource_Encoder();

 template<typename T>
 void do_encode(const T& t, QString& result)
 {
  tad_.store(t, profile_);
  result = tad_.encode();
 }

};


_RZNS(RZSite)


#endif
