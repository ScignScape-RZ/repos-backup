
#include "ptn-site-manager-local-bridge.h"

#include "ptn-folder-resource.h"
#include "ptn-site-request.h"

#include "ptn-resource-decoder.h"
#include "ptn-resource-encoder.h"
#include "ptn-file-resource.h"

#include "downpull/downpull-request-manager.h"
#include "downpull/downpull-data-receiver.h"

#include "rzns.h"

#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>

#include <QFile>
#include <QFileInfo>

#include <QEventLoop>

#include <QBuffer>


USING_RZNS(RZSite)


template<>
struct TDCX_Type_Info<PTN_File_Resource> : TDCX_Byte_Array_Storage //?: TDCX_Pure_Value_Storage
{
 static QString get_QString_Type_Name(){ return "PTN_File_Resource"; }
 static int get_Type_Code(){ return 1; }
};

template<>
struct TDCX_Type_Info<PTN_Folder_Resource> : TDCX_Byte_Array_Storage //?: TDCX_Pure_Value_Storage
{
 static QString get_QString_Type_Name(){ return "PTN_Folder_Resource"; }
 static int get_Type_Code(){ return 2; }
};


PTN_Site_Manager_Local_Bridge::PTN_Site_Manager_Local_Bridge()
 : port_(0)
{


}

QString PTN_Site_Manager_Local_Bridge::send_get_folder_contents()
{
 PTN_Folder_Resource pfr;
 get_current_folder_resource(pfr);

  //? pfr.read_contained();
 PTN_Resource_Encoder prenc;
 QString encode; // = tad.encode();
 prenc.do_encode(pfr, encode);

 PTN_Site_Request psr(host_, port_);
 check_set_scheme(psr);

 QString result = psr.send_get_folder_contents(encode);
 return result;
}

void PTN_Site_Manager_Local_Bridge::get_file_encode_string(QString& result)
{
 PTN_File_Resource pfr(current_file_path_resource_);
 pfr.load_contents();
 PTN_Resource_Encoder prenc;
 prenc.do_encode(pfr, result);
}

void PTN_Site_Manager_Local_Bridge::get_path_encode_string(QString& result)
{
 PTN_File_Resource pfr(current_file_path_resource_);
 PTN_Resource_Encoder prenc;
 prenc.do_encode(pfr, result);
}

void PTN_Site_Manager_Local_Bridge::check_file_update_needed(std::function<void()> fn)
{
 QString clp = current_file_path_resource_.complete_local_path();
 QFile qfi(clp);
 QFileInfo qfin(qfi);
 QDateTime qdt_local = qfin.lastModified();

 PTN_File_Resource pfr(current_file_path_resource_);

 PTN_Resource_Encoder prenc;
 QString encode; // = tad.encode();
 prenc.do_encode(pfr, encode);

 PTN_Site_Request psr(host_, port_);
 check_set_scheme(psr);
 QString qdt_remote_s = psr.send_get_file_last_modified(encode);

 qlonglong qll = qdt_remote_s.toLongLong();

 QDateTime qdt_remote = QDateTime::fromMSecsSinceEpoch(qll);

 if(qdt_remote < qdt_local)
 {
  fn();
 }
}

void PTN_Site_Manager_Local_Bridge::check_set_secondary_scheme(PTN_Site_Request& psr)
{
 if(!scheme_.isEmpty())
 {
  if(scheme_.contains('/'))
  {
   int ind = scheme_.indexOf('/');
   psr.set_scheme(scheme_.left(ind));
  }
  else
  {
   psr.set_scheme(scheme_);
  }
 }
}

void PTN_Site_Manager_Local_Bridge::check_set_scheme(PTN_Site_Request& psr)
{
 if(!scheme_.isEmpty())
 {
  if(scheme_.contains('/'))
  {
   psr.set_scheme(scheme_.replace('/', ""));
  }
  else
  {
   psr.set_scheme(scheme_);
  }
 }
}


QString PTN_Site_Manager_Local_Bridge::send_update(std::function<void(QString)> fn)
{
 QString encode;
 get_file_encode_string(encode);
 QString result;

 if(secondary_hosts_.isEmpty())
 {
  if(fn)
  {
   PTN_Site_Request* psr = new PTN_Site_Request(host_, port_);
   check_set_scheme(*psr);

   const QNetworkAccessManager& qnam = psr->qnam();

   QObject::connect(&qnam, static_cast<void (QNetworkAccessManager::*)(QNetworkReply*)>
     (&QNetworkAccessManager::finished),
   [psr, fn](QNetworkReply* reply)
   {
    QString result = reply->readAll();
    fn(result);
    delete psr;
   });
   psr->send_edit_async(encode);
  }
  else
  {
   PTN_Site_Request psr(host_, port_);
   check_set_scheme(psr);
   result = psr.send_edit(encode);
  }
 }
 else
 {
  QMapIterator<QString, int> it(secondary_hosts_);
  while(it.hasNext())
  {
   it.next();
   QString h = it.key();
   int port = it.value();
   PTN_Site_Request psr(host_, port_);
   check_set_secondary_scheme(psr);
   QString temp_result = psr.send_edit(encode);
   result += QString("\nHost %1:%2 result: %3").arg(h).arg(port).arg(temp_result);
  }
 }
 return result;
}


void PTN_Site_Manager_Local_Bridge::send_info_test(QMap<QString, std::function<void(QString)> > fns)
{
 PTN_Site_Request* psr = new PTN_Site_Request(host_, port_);
 check_set_scheme(*psr);

 const QNetworkAccessManager& qnam = psr->qnam();

 std::function<void(QString)> finished_fn = fns.value("finished");
 std::function<void(QString)> error_fn = fns.value("error");

 QObject::connect(&qnam, static_cast<void (QNetworkAccessManager::*)(QNetworkReply*)>
   (&QNetworkAccessManager::finished),
 [psr, finished_fn, error_fn](QNetworkReply* reply)
 {
  QString result;
  if(reply->error() == QNetworkReply::NoError)
  {
   result = reply->readAll();
   finished_fn(result);
  }
  else
  {
   result = reply->errorString();
   error_fn(result);
  }
  reply->deleteLater();
  delete psr;
 });

 psr->send_info_test_async();
}

QString PTN_Site_Manager_Local_Bridge::send_info_test(std::function<void(QString)> fn)
{
 QString result;
 if(fn)
 {
  PTN_Site_Request* psr = new PTN_Site_Request(host_, port_);
  check_set_scheme(*psr);

  const QNetworkAccessManager& qnam = psr->qnam();

  QObject::connect(&qnam, static_cast<void (QNetworkAccessManager::*)(QNetworkReply*)>
    (&QNetworkAccessManager::finished),
  [psr, fn](QNetworkReply* reply)
  {
   QString result = reply->readAll();
   fn(result);
   delete psr;
  });
  psr->send_info_test_async();
 }
 else
 {
  PTN_Site_Request psr(host_, port_);
  check_set_scheme(psr);
  result = psr.send_info_test();
 }
 return result;
}


//QString PTN_Site_Manager_Local_Bridge::send_update()
//{
// return send_update(nullptr);
//}


void PTN_Site_Manager_Local_Bridge::set_web_root_folder(QString str)
{
 web_root_folder_path_resource_.reset_segments(PTN_Path_Segment(str,
   PTN_Path_Segment::Segment_Roles::Web_Root));
}

void PTN_Site_Manager_Local_Bridge::set_current_file_relative(QString str)
{
 if(current_folder_path_resource_.segments().isEmpty())
 {
  current_file_path_resource_ = web_root_folder_path_resource_.under(str);
 }
 else
 {
  current_file_path_resource_ = current_folder_path_resource_.under(str);
 }
}

void PTN_Site_Manager_Local_Bridge::set_current_folder_relative(QString str)
{
 current_folder_path_resource_ = web_root_folder_path_resource_.under(str,
   PTN_Path_Segment::Segment_Roles::Folder_Generic);
}

void PTN_Site_Manager_Local_Bridge::leave_current_folder_relative()
{
 current_folder_path_resource_.unroll_segment();
}

void PTN_Site_Manager_Local_Bridge::enter_current_folder_relative(QString str)
{
 if(current_folder_path_resource_.segments().isEmpty())
 {
  set_current_folder_relative(str);
 }
 else
 {
  current_folder_path_resource_.add_segment(str, PTN_Path_Segment::Segment_Roles::Folder_Generic);
 }
}


void PTN_Site_Manager_Local_Bridge::get_current_folder_resource(PTN_Folder_Resource& pfr)
{
 pfr.set_path_resource(current_folder_path_resource_);
}

QSharedPointer<PTN_Folder_Resource> PTN_Site_Manager_Local_Bridge::get_remote_folder_as_resource()
{
 QString encode = send_get_folder_contents();
 PTN_Resource_Decoder prdec;
 QSharedPointer<PTN_Folder_Resource> result = prdec.do_decode<PTN_Folder_Resource>(encode);
 return result;
}


void PTN_Site_Manager_Local_Bridge::add_secondary_host(QString h)
{
 secondary_hosts_.insert(h, 0);
}

void PTN_Site_Manager_Local_Bridge::add_secondary_host(QString h, int port)
{
 secondary_hosts_.insert(h, port);
}

QString PTN_Site_Manager_Local_Bridge::get_silo_response(QString silo_name, QString report_file)
{
 //QNetworkAccessManager* qnam = new QNetworkAccessManager;
 QString sqrb = silo_query_route_base_.isEmpty()?
    "qt-client": silo_query_route_base_;

 QMap<QString, QString> hs;

 if(!secondary_hosts_.isEmpty())
 {
  QMapIterator<QString, int> it(secondary_hosts_);
  while(it.hasNext())
  {
   it.next();
   QString url = QString("%1:%2").arg(it.key()).arg(it.value());
   hs[url] = QString::number(it.value());
  }
 }
 else if(port_ != 0)
 {
  hs[QString("%1:%2").arg(host_).arg(port_)] = "default";
 }
 else
 {
  hs[host_] = "default";
 }

 PTN_Site_Request* psr = new PTN_Site_Request(host_, port_);
 QString response = psr->send_downpull_request(report_file, silo_name, hs);
 return response;

}



#ifdef HIDE
QString PTN_Site_Manager::decode_file_resource(QString code)
{
 PTN_Resource_Decoder prdec;
 QSharedPointer<PTN_File_Resource> pfr = prdec.do_decode<PTN_File_Resource>(code);
 QString path = path_in_site_context(pfr->path_resource());
 return path;
}

QString PTN_Site_Manager::decode_file_resource(QString code, QString& contents)
{
 PTN_Resource_Decoder prdec;

 QSharedPointer<PTN_File_Resource> pfr = prdec.do_decode<PTN_File_Resource>(code);

 QString path = path_in_site_context(pfr->path_resource());

 contents = pfr->contents_to_latin1qstring();
 return path;
}

QString PTN_Site_Manager::receive_create_file(QString code)
{
 QString contents;
 QString path = decode_file_resource(code, contents);
 QString result = save_file(path, contents);
 if(result.isEmpty())
 {
  return QString("File successfully created: %1").arg(path);
 }
 else
 {
  return QString("File not created: %1").arg(result);
 }
}

QString PTN_Site_Manager::receive_get_file_last_modified(QString code)
{
 QString path = decode_file_resource(code);
 QFile qf(path);
 QFileInfo qfi(qf);
 QDateTime qdt = qfi.lastModified();
 return QString::number(qdt.toMSecsSinceEpoch());
}

QString PTN_Site_Manager::receive_update_file(QString code)
{
 QString contents;
 QString path = decode_file_resource(code, contents);
 QString result = save_file(path, contents);
 if(result.isEmpty())
 {
  return QString("File successfully saved: %1").arg(path);
 }
 else
 {
  return QString("File not saved: %1").arg(result);
 }
}
#endif // HIDE

