
#ifndef PTN_SITE_MANAGER__H
#define PTN_SITE_MANAGER__H

#include <QString>

#include <QNetworkAccessManager>

#include "rzns.h"

#include "accessors.h"

RZNS_(RZSite)

class PTN_Path_Resource;
class PTN_Folder_Resource;

class PTN_Site_Manager
{

 QString web_root_path_;
 QString data_root_path_;

public:

 ACCESSORS(QString ,web_root_path)
 ACCESSORS(QString ,data_root_path)

 PTN_Site_Manager();

 //?void send_update_file(QString code);
 QString receive_update_file(QString code);
 QString receive_create_file(QString code);
 QString receive_get_file_last_modified(QString code);
 QString decode_file_resource(QString code, QString& contents);
 QString decode_file_resource(QString code);

 QSharedPointer<PTN_Folder_Resource> decode_folder_resource(QString code);

 QString receive_get_folder_contents(QString code);

 QString path_in_site_context(const PTN_Path_Resource& ppr);

 static QString save_file(QString path, QString contents);

};


_RZNS(RZSite)


#endif
