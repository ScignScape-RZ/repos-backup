
#ifndef PTN_SITE_REQUEST__H
#define PTN_SITE_REQUEST__H

#include <QString>

#include <QNetworkAccessManager>

#include "rzns.h"

#include "accessors.h"

#include <functional>

RZNS_(RZSite)


class PTN_Site_Request
{
 QNetworkAccessManager qnam_;

 QString host_;
 quint64 port_;

 QString scheme_;


public:

 PTN_Site_Request(QString host, quint64 port = 0);

 ACCESSORS(QString ,scheme)

 ACCESSORS__CONST_RGET(QNetworkAccessManager ,qnam)

 QString send_edit(QString code);
 void send_edit_async(QString code);

 QString send_info_test(QString code = QString());
 void send_info_test_async(QString code = QString());


 QString send_new_file(QString code);

 void send_request_async(QString code, QString route, QString mode = "post");


 QString send_request(QString code, QString route, QString mode = "post");
 QString send_get_file_last_modified(QString code);
 QString send_get_folder_contents(QString code);



 QString send_downpull_request(QString report_file, QString silo, QMap<QString, QString>& hosts);

};


_RZNS(RZSite)


#endif
