
#ifndef TEXTIO__H
#define TEXTIO__H

#include "rzns.h"

#include <QFile>
#include <QTextStream>


RZNS_(TextIO)


QString load_file(QString path)
{
 QString result;
 QFile infile(path);
 if (!infile.open(QIODevice::ReadOnly | QIODevice::Text))
   return result;
 QTextStream in_ts(&infile);
 result = in_ts.readAll();
 infile.close();
 return result;
}



_RZNS(TextIO)


#endif
