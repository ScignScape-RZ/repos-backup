
# RelaeGraph

RelaeGraph is a C++/Qt framework for managing Semantic Graph like data.  It is not an advanced persistence or live memory management system; users are responsible for memory management.  RelaeGraph assumes that relevant data is modeled in terms of pointers (which are then incorporated into a simple tagged pointer system which provides the possibility of passing data structures to other environments using tagged pointers, such as Clasp).  A few C++ macros are available to work with these tagged pointers in a context like the Qt Creator IDE.  A Relae "node" wraps each tagged pointer and provides a QMultiMap to represent Semantic "triples".  

The Semantic "relations" are defined within "Dominions", or "Domain Specific Mini-Ontologies", and a certain amount of C++ operator overloading is used to make defining "triples" and using Dominion-relations (also called "connectors") to traverse Semantic Graphs.  This is used in the ScignScape libraries, for example by NGML when converting input sources to output files.  

RelaeGraph also provides a notion of "frames", which in principle can narrow the scope of a triple-assertion.  If this granularity is not needed, simply provide a single frame for the entire data space (as demonstrated by the NGML code, for example).

Finally, RelaeGraph provides a parsing framework for converting text input to RelaeGraph structures.  This framework provides context-sensitive formal grammar capabilities and a Qt oriented text manipulation and callback environment, which can be used as a replacement for tools like Lex and Yacc.  This Qt-based environment relies on dynamically modifiable Regular Expression matches and code callbacksm as compared with precompiled rules and productions as with Yacc and most other parser generators; so the Qt-based system can be easier to use and can implement more flexible, syntactically nuanced formal languages.
