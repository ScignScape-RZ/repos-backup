# rz-dev
This is the very ugly very latest R/Z development.  Frankly the purpose of this particular repo right now is mostly keeping a backup going.

Much of the R/Z implementation is subobtimal.  I know what needs to be done to improve it while keeping the "semantic grammar" principles, but have to find time to do so.

Nonetheless R/Z can be used for real-world purposes, so I'd be willing to work on specific improvements that someone might find useful.  Until then it will be build and improved gradually.
