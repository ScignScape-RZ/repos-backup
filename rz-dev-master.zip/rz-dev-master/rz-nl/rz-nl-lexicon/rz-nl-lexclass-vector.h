
#ifndef NL_LEXCLASS_VECTOR__H
#define NL_LEXCLASS_VECTOR__H

#include "rzns.h"

#include <functional>

#include <QString>

#include <QMap>
#include <QVector>

#include "accessors.h"


RZNS_(NL)

class NL_Lexicon;
class NL_Lexclass;


class NL_Lexclass_Vector : public QVector<NL_Lexclass*>
{

public:
 NL_Lexclass_Vector();

};

_RZNS(Chat)



#endif
