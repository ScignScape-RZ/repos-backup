
#include "rz-nl-lexclass.h"

#include "rz-nl-lexicon.h"

USING_RZNS(NL)


NL_Lexclass::NL_Lexclass(QString label, QString key, const NL_Lexicon& nll):
  this_root_(Roots::N_A), label_(label), expected_lambda_depth_(0)
{
 QStringList qsl = key.split("..->");
 if(qsl.size() == 1)
 {
  this_root_ = parse_root(key);
 }
 else
 {
  QStringList qsl1 = qsl[0].split(".->");
  QStringList qsl2 = qsl[1].split(",->");

  for(QString qs : qsl1)
  {
   lambda_channel_.push_back(nll.find_lexclass(qs.trimmed()));
  }

  for(QString qs : qsl2)
  {
   NL_Lexclass* nlc = nll.find_lexclass(qs.trimmed());
   int edc = nlc->expected_lambda_depth() + 1;
   if(expected_lambda_depth_ < edc)
    expected_lambda_depth_ = edc;
   profile_channel_.push_back(nll.find_lexclass(qs.trimmed()));
  }
 }
}

NL_Lexclass::NL_Lexclass() : this_root_(Roots::N_A), expected_lambda_depth_(0)
{
}

int NL_Lexclass::max_arity(int comparison)
{
 int lcs = lambda_channel_.size();
 if(profile_channel_.isEmpty())
 {
  if(lcs > comparison)
   return lcs;
  else
   return comparison;
 }
 else
 {
  return profile_channel_.first()->max_arity(lcs);
 }
}

int NL_Lexclass::arity(int rewind_level)
{
 if(rewind_level > 0)
 {
  if(profile_channel_.isEmpty())
  {
   return -1;
  }
  return profile_channel_.first()->arity(--rewind_level);
 }
 else
 {
  return lambda_channel_.size();
 }
}


