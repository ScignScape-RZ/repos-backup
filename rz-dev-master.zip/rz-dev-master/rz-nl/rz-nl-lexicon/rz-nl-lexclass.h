
#ifndef NL_LEXCLASS__H
#define NL_LEXCLASS__H

#include "rzns.h"

#include <functional>

#include <QString>

#include <QMap>
#include <QVector>

#include "accessors.h"


RZNS_(NL)

class NL_Lexicon;


class NL_Lexclass
{
public:

 enum class Roots {
  N_A, Noun, Proposition
 };

 Roots parse_root(QString key)
 {
  static QMap<QString, Roots> static_map {{
    { "N", Roots::Noun },
    { "Noun", Roots::Noun },

    { "P", Roots::Proposition },
    { "Proposition", Roots::Proposition },


                                          }};

  return static_map.value(key, Roots::N_A);
 }

private:

 QVector<NL_Lexclass*> lambda_channel_;

 QVector<NL_Lexclass*> profile_channel_;

 Roots this_root_;

 QString label_;

 int expected_lambda_depth_;

public:

 NL_Lexclass(QString label, QString key, const NL_Lexicon& nll);

 NL_Lexclass();

 ACCESSORS__RGET(QVector<NL_Lexclass*> ,lambda_channel)
 ACCESSORS__RGET(QVector<NL_Lexclass*> ,profile_channel)

 ACCESSORS(QString ,label)

 ACCESSORS(int ,expected_lambda_depth)

 int arity(int rewind_level = 0);
 int max_arity(int comparison = 0);

};

_RZNS(Chat)



#endif
