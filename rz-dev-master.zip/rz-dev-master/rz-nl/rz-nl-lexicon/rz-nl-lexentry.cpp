
#include "rz-nl-lexentry.h"

USING_RZNS(NL)

NL_Lexentry::NL_Lexentry(QString lexword, NL_Lexclass* lexclass)
 : lexword_(lexword)
{
 lexclasses_.push_back(lexclass);
}

void NL_Lexentry::add_lexclass(NL_Lexclass* lexclass)
{
 lexclasses_.push_back(lexclass);
}

NL_Lexentry::NL_Lexentry()
{

}

