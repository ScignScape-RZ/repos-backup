
#include "rz-nl-lexicon.h"

#include "textio.h"

#include <QRegularExpression>

USING_RZNS(NL)


NL_Lexicon::NL_Lexicon(QString source_path)
{
 QString code = RZ::TextIO::load_file(source_path);
 QStringList lines = code.split("\n");

 QRegularExpression rx ("([\\w-]+)\\s+(\\W{3})");

 for(QString line : lines)
 {
  line = line.trimmed();

  if(line.isEmpty())
   continue;

  if(line.startsWith(";;-"))
   continue;

  QRegularExpressionMatch rxm = rx.match(line);

  if(rxm.hasMatch())
  {
   QString lexword = rxm.captured(1).trimmed();
   QString defkind = rxm.captured(2).trimmed();

   QString rest = line.mid(rxm.capturedEnd()).trimmed();

   if(defkind == ">>>")
   {
    add_lexentry(lexword, rest);
   }
   else if(defkind == ":::")
   {
    add_lexclass(lexword, rest);
   }

  }

 }

}

void NL_Lexicon::add_lexentry(QString lexword, QString key)
{
 if(lexentries_.contains(lexword))
 {
  lexentries_[lexword]->add_lexclass(find_lexclass(key));
 }
 else
 {
  lexentries_[lexword] = new NL_Lexentry(lexword, find_lexclass(key));
 }
}


void NL_Lexicon::add_lexclass(QString lexclass, QString key)
{
 lexclasses_[lexclass] = new NL_Lexclass(lexclass, key, *this);
}

NL_Lexentry* NL_Lexicon::find_lexentry(QString word) const
{
 return lexentries_[word];
}

NL_Lexclass* NL_Lexicon::find_lexclass(QString word) const
{
 return lexclasses_[word];
}


NL_Lexentry* NL_Lexicon::match_lexclass(QString word, NL_Lexclass_Vector& lcv) const
{
 if(lexentries_.contains(word))
 {
  NL_Lexentry* nle = find_lexentry(word);
  lcv = nle->lexclasses();
  return nle;
 }
 return nullptr;
}


