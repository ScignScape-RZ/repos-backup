
#ifndef NL_LEXICON__H
#define NL_LEXICON__H

#include "rzns.h"

#include <functional>

#include <QString>

#include <QMap>
#include <QVector>

#include "accessors.h"

#include "rz-nl-lexentry.h"
#include "rz-nl-lexclass.h"
#include "rz-nl-lexclass-vector.h"


RZNS_(NL)

class NL_Lexicon
{

 QString source_path_;

 QMap<QString, NL_Lexentry*> lexentries_;
 QMap<QString, NL_Lexclass*> lexclasses_;

public:

 explicit NL_Lexicon(QString source_path);

 void add_lexentry(QString lexword, QString key);
 void add_lexclass(QString lexclass, QString key);

 NL_Lexentry* find_lexentry(QString word)  const;
 NL_Lexclass* find_lexclass(QString word)  const;

 NL_Lexentry* match_lexclass(QString word, NL_Lexclass_Vector& lcv) const;

};

_RZNS(Chat)



#endif
