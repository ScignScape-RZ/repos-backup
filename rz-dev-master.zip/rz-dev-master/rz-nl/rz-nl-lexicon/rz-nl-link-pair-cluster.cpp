
#include "rz-nl-link-pair-cluster.h"
#include "rz-nl-link-pair.h"


USING_RZNS(NL)


NL_Link_Pair_Cluster::NL_Link_Pair_Cluster(int local_index)
 : local_index_(local_index), cluster_size_(0)
{

}

void NL_Link_Pair_Cluster::clone_from(const NL_Link_Pair_Cluster& rhs)
{
 linkpairs_ = rhs.linkpairs();
 depth_change_ = rhs.depth_change();
 cluster_size_ = rhs.cluster_size();
 node_arity_ = rhs.node_arity();
 node_arity__labels_ = rhs.node_arity__labels();

 debug_ = rhs.debug_;
}

const NL_Link_Pair* NL_Link_Pair_Cluster::find_source_target_duplicate(const NL_Link_Pair* pr) const
{
 for(const NL_Link_Pair* cpr : linkpairs_)
 {
  if(cpr->source_node() == pr->source_node())
  {
   if(cpr->target_node() == pr->target_node())
   {
    return cpr;
   }
  }
 }
 return nullptr;
}


int NL_Link_Pair_Cluster::find_pair_position(const NL_Link_Pair* pr) const
{
// int i = 0;
 return linkpairs_.indexOf(pr);
// for(const NL_Link_Pair* cpr : linkpairs_)
// {
//  if(cpr == pr)
//   return i;
//  ++i;
// }
// return -1;
}

void NL_Link_Pair_Cluster::find_source_node_positions(
  caon_ptr<RE_Node> source_node, QVector<QPair<int, const NL_Link_Pair*> >& positions) const
{
 int i = 0;
 for(const NL_Link_Pair* pr : linkpairs_)
 {
  if(pr->source_node() == source_node)
  {
   positions.push_back({i, pr});


  }
  ++i;
 }
}

const NL_Link_Pair* NL_Link_Pair_Cluster::match_pair_with_regent(caon_ptr<RE_Node> node) const
{
 for(const NL_Link_Pair* pr : linkpairs_)
 {
  if(pr->source_node() == node)
  {
   return pr;
  }
 }
 return nullptr;
}


void NL_Link_Pair_Cluster::append_link_pair(const NL_Link_Pair* pr)
{
 linkpairs_.push_back(pr);
 int dc = pr->lambda_position() == 0? 1 : 0;
 depth_change_.push_back(dc);
 ++cluster_size_;

 debug_ = short_summary();

}


QString NL_Link_Pair_Cluster::short_summary() const
{
 QString result;

 for(const NL_Link_Pair* pr : linkpairs_)
 {
  result += pr->short_summary() + "  ";
 }
 result.chop(2);

 return result;
}


void NL_Link_Pair_Cluster::append_link_pair_at_position(const NL_Link_Pair* pr, int pos, signed int dc)
{
 //?linkpairs_.push_back(lp);
 linkpairs_.insert(pos, pr);
 depth_change_.insert(pos, dc);
 ++cluster_size_;

 QString ss = short_summary();

 debug_ = short_summary();

 if(cluster_size_ > 2)
 {
   QString s = "";
 }

}

void NL_Link_Pair_Cluster::increase_node_arity(caon_ptr<RE_Node> node, int rewind_level)
{
 ++node_arity_[node][rewind_level];
}

void NL_Link_Pair_Cluster::increase_node_arity__labels(QString n, int rewind_level)
{
 ++node_arity__labels_[n][rewind_level];
}


int NL_Link_Pair_Cluster::get_node_arity(caon_ptr<RE_Node> node, int rewind_level)
{
 return node_arity_.value(node, {}).value(rewind_level, 0);
}

bool NL_Link_Pair_Cluster::has_node_arity(caon_ptr<RE_Node> node)
{
 return node_arity_.contains(node);
}


void NL_Link_Pair_Cluster::prepend_link_pair_at_position(const NL_Link_Pair* pr, int pos, signed int dc)
{
 if(pos == 0)
 {
  linkpairs_.push_front(pr);
  depth_change_.push_front(dc);
 }
 else
 {
  linkpairs_.insert(pos - 1, pr);
  depth_change_.insert(pos - 1, dc);
 }

 ++cluster_size_;

 debug_ = short_summary();

 QString ss = short_summary();

 if(cluster_size_ > 2)
 {
   QString s = "";
 }

}





