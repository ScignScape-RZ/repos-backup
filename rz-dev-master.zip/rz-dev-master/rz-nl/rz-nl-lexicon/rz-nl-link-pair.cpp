
#include "rz-nl-link-pair.h"


USING_RZNS(NL)


NL_Link_Pair::NL_Link_Pair(int local_index)
 :
  local_index_(local_index),
  source_node_(nullptr),
  target_node_(nullptr),
  source_lexclass_(nullptr),
  target_lexclass_(nullptr),
  lambda_position_(-1),
  profile_position_(-1),
  rewind_level_(-1),
  shared_rewind_level_(0),
  continue_offset_(0)
{

}






