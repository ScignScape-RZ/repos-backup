
#ifndef NL_LINK_PAIR__H
#define NL_LINK_PAIR__H

#include "rzns.h"

#include <functional>

#include <QSet>

#include <QString>

#include <QMap>
#include <QVector>

#include "accessors.h"

//#include "rz-relae/relae-caon-ptr.h"
//#include "rz-relae/relae-node-ptr.h"


RZNS_CLASS_DECLARE(RECore ,RE_Node)
USING_RZNS(RECore)


RZNS_(NL)

class NL_Lexicon;
class NL_Lexclass;

class NL_Link_Pair
{
 int local_index_;

 RE_Node* source_node_;
 RE_Node* target_node_;

 NL_Lexclass* source_lexclass_;
 NL_Lexclass* target_lexclass_;

 int lambda_position_;
 int profile_position_;
 int rewind_level_;
 int shared_rewind_level_;

 signed int continue_offset_;


 QString label_;
 QString short_summary_;

public:

 friend bool operator <(const NL_Link_Pair& lhs, const NL_Link_Pair& rhs)
 {
  return lhs.local_index_ < rhs.local_index_;
 }

 friend bool operator ==(const NL_Link_Pair& lhs, const NL_Link_Pair& rhs)
 {
  if(lhs.source_node() == rhs.source_node() &&
     lhs.target_node() == rhs.target_node() &&
     lhs.lambda_position() == rhs.lambda_position() &&
     lhs.profile_position() == rhs.profile_position() &&
     lhs.source_lexclass() == rhs.source_lexclass() &&
     lhs.target_lexclass() == rhs.target_lexclass()
     )
   return true;
  return lhs.local_index_ == rhs.local_index_;
 }

 //friend



 ACCESSORS(int ,local_index)
 ACCESSORS(RE_Node*,source_node)
 ACCESSORS(RE_Node*,target_node)

 ACCESSORS(NL_Lexclass* ,source_lexclass)
 ACCESSORS(NL_Lexclass* ,target_lexclass)

 ACCESSORS(int ,lambda_position)
 ACCESSORS(int ,profile_position)
 ACCESSORS(int ,rewind_level)

 ACCESSORS(int ,shared_rewind_level)

 int shared_rewind_offset() const
 {
  return rewind_level_ - shared_rewind_level_;
 }

 ACCESSORS(QString ,label)
 ACCESSORS(QString ,short_summary)

 ACCESSORS(signed int ,continue_offset)

 NL_Link_Pair(int local_index);


};

//template<>
inline int qHash(const NL_Link_Pair& lhs)
{
 return lhs.local_index();
}

_RZNS(Chat)



#endif
