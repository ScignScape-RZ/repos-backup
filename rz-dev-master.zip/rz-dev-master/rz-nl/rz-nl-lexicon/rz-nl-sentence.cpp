
#include "rz-nl-sentence.h"

USING_RZNS(NL)

NL_Sentence::NL_Sentence(caon_ptr<RE_Node> punctuation_node)
 : punctuation_node_(punctuation_node)
{
}

