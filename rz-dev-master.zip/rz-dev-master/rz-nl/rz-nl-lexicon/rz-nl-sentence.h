
#ifndef NL_SENTENCE__H
#define NL_SENTENCE__H

#include "rzns.h"

#include <functional>

#include <QString>

#include <QMap>
#include <QVector>

#include "accessors.h"

//#include "rz-relae/relae-caon-ptr.h"
//#include "rz-relae/relae-node-ptr.h"


//?RZNS_CLASS_DECLARE(Text ,RZ_Text_Punctuation)

RZNS_CLASS_DECLARE(RECore ,RE_Node)
USING_RZNS(RECore)


RZNS_(NL)




class NL_Sentence
{

 RE_Node* punctuation_node_;


public:

 NL_Sentence(RE_Node* punctuation_node);

};

_RZNS(NL)



#endif
