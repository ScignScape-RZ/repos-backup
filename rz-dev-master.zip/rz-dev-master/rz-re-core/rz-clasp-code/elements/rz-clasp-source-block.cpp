
#include "rz-clasp-source-block.h"

#include "rz-clasp-code-lexmap.h"

#include "rz-clasp-source-fundef.h"

#define LEX_ENTRY_CODE "(q-callback :lex-entry)"
#define LEX_LEAVE_CODE "(q-callback :lex-leave)"


#define SCC caon_static_cast<RZ_Clasp_Source_Element>()

USING_RZNS(RZClasp)

RZ_Clasp_Source_Block::RZ_Clasp_Source_Block(caon_ptr<RZ_Clasp_Cpp_Code_Generator> cpp_code_gen,
  caon_ptr<RZ_Clasp_Source_Element> parent_element,
  caon_ptr<RZ_Clasp_Source_Block> parent_block,
  caon_ptr<RZ_Clasp_Code_Block> code_block, RZ_Clasp_Code_Block_Kinds block_kind,
  caon_ptr<RZ_Clasp_Source_Fundef> fundef)
 : RZ_Clasp_Source_Element(cpp_code_gen, parent_element),
   parent_block_(parent_block), code_block_(code_block),
   block_kind_(block_kind),
   fundef_(fundef),
   continue_block_(nullptr),
   expression_count_(0), elsif_count_(0), lexmap_(nullptr)
{
 CAON_PTR_DEBUG(RZ_Clasp_Source_Fundef ,fundef)
 if(parent_element)
 {
  CAON_PTR_DEBUG(RZ_Clasp_Source_Element ,parent_element)
  if(parent_block)
  {
   CAON_PTR_DEBUG(RZ_Clasp_Source_Block ,parent_block)
   CAON_DEBUG_NOOP
  }
  if(parent_element->flags.if_elsif)
  {
   flags.if_elsif = true;
  }
 }
}

void RZ_Clasp_Source_Block::check_as_block(caon_ptr<RZ_Clasp_Source_Block>& bl)
{
 bl = this;
}

QString RZ_Clasp_Source_Block::source_element_cpp_type()
{
 return "RZ_Clasp_Source_Block";
}

void RZ_Clasp_Source_Block::debug_inspect()
{
 for(caon_ptr<RZ_Clasp_Source_Element> el : child_elements_)
 {
  CAON_PTR_DEBUG(RZ_Clasp_Source_Element ,el)
  QString elt = el->source_element_cpp_type();
  el->debug_inspect();
 }
}

caon_ptr<RZ_Clasp_Source_Block> RZ_Clasp_Source_Block::prepare_block_map_continue()
{
 CAON_PTR_DEBUG(RZ_Clasp_Source_Element ,parent_element_)

 parent_element_->debug_inspect();

 CAON_PTR_DEBUG(RZ_Clasp_Source_Fundef ,fundef_)
 caon_ptr<RZ_Clasp_Source_Fundef> sequence = fundef_->do_map_sequence_ref();
 CAON_PTR_DEBUG(RZ_Clasp_Source_Fundef ,sequence)
 caon_ptr<RZ_Clasp_Source_Block> result = sequence->block();
 CAON_PTR_DEBUG(RZ_Clasp_Source_Block ,result)
 result->set_parent_element(parent_element_);
 result->set_text_hint("Block Map Continue...");
 return result;
}



//void RZ_Clasp_Source_Block::parent_write_indentation(QTextStream& qts)
//{
// if(parent_element_)
//  parent_element_->write_indentation(qts, 0);
//}

QString RZ_Clasp_Source_Block::lexmap_declarations(QString& scope_entry, QString& scope_leave, int indentation)
{
 QString result;
 if(lexmap_)
 {
  scope_entry = LEX_ENTRY_CODE;
  scope_leave = LEX_LEAVE_CODE;

  lexmap_->write(result);
 }
 return result;
}

void RZ_Clasp_Source_Block::write(QTextStream& qts, int indentation)
{
 qts << "\n";
 parent_write_indentation(qts, indentation); //?indentation);
 // parent_element_->write_indentation(qts, 0);
 //write_indentation(qts, 0);

 QString lexmap;

 QString lex_entry;
 QString lex_leave;

 if(cpp_code_gen_)
 {
  switch(block_kind_)
  {
  case RZ_Clasp_Code_Block_Kinds::Fundef_Block:
   //   lexmap = lexmap_declarations(indentation);
   //   if(!lexmap.isEmpty())
   //    qts << '(' << lexmap;
   break;
  case RZ_Clasp_Code_Block_Kinds::Scan_Block:
   //qts << "(scan-map";
   break;
  default:
   {
//    lexmap = lexmap_declarations(indentation);
//    if(lexmap.isEmpty())
//     qts << "(progn";
//    else
//     qts << '(' << lexmap;
   }
  }
 }
 else
 {
  switch(block_kind_)
  {
  case RZ_Clasp_Code_Block_Kinds::Fundef_Block:
   lexmap = lexmap_declarations(lex_entry, lex_leave, indentation);
   if(!lexmap.isEmpty())
    qts << '(' << lexmap;

   if(!lex_entry.isEmpty())
    qts << "\n " << lex_entry << "\n\n";

   break;
  case RZ_Clasp_Code_Block_Kinds::Scan_Block:
   qts << "(scan-map";
  //?case RZ_Clasp_Code_Block_Kinds::Do_Block:
   break;
  default:
   {
    lexmap = lexmap_declarations(lex_entry, lex_leave, indentation);
    if(lexmap.isEmpty())
     qts << "(progn";
    else
     qts << '(' << lexmap;

    if(!lex_entry.isEmpty())
     qts << "\n " << lex_entry << "\n\n";

   }
  }
 }

 write_precode_output(qts);

 //?write_indentation(qts, indentation);
 write_code_output(qts);
 write_children(qts, 0); //, indentation);
 //write_children_parent_indentation(qts, indentation);
 qts << "\n";
 parent_write_indentation(qts, indentation); // indentation);
 //parent_element_->write_indentation(qts, 0);
 //write_indentation(qts, 0);

 switch(block_kind_)
 {
 case RZ_Clasp_Code_Block_Kinds::Fundef_Block:
  if(!lexmap.isEmpty())
  {
   if(!lex_leave.isEmpty())
    qts << "\n " << lex_leave << "\n";


   qts << "\n;let;\n) ";
  }
  break;
 case RZ_Clasp_Code_Block_Kinds::Scan_Block:
  if(!lex_leave.isEmpty())
   qts << "\n " << lex_leave << "\n";

  qts << ";progn/scan;\n))\n";
  break;
 default:
  if(!lex_leave.isEmpty())
   qts << "\n " << lex_leave << "\n";

  qts << ";progn/let;\n)\n";
 }

 if(flags.if_elsif)
 {
  qts << ");clause;\n";
 }

 write_postcode_output(qts);

 qts << elsif_expression_;

 if(continue_block_)
 {
  continue_block_->write(qts, indentation);
 }

}

void RZ_Clasp_Source_Block::add_statement(caon_ptr<RZ_Clasp_Source_Statement> st)
{
 child_elements_.push_back(st.SCC);
}

void RZ_Clasp_Source_Block::prepare_expression_entry(QString prefix)
{
 // this should mean that the block is continued e.g. else or elsif...
 //postcode_output_ += '(';
 ++expression_count_;
 if(elsif_count_ > 0)
 {
  // should we assume always if_elsif?
  //?if(flags.if_elsif)
  elsif_expression_ += "( ;elsif-clause:\n";
  elsif_expression_ += prefix + '(';
 }
}


void RZ_Clasp_Source_Block::prepare_expression_leave()
{
 // this should mean that the block is continued e.g. else or elsif...
 if(elsif_count_ > 0)
 {
  if(cpp_code_gen_)
  {

  }
  else
   elsif_expression_ += ')';
 }
 else
 {
  //?postcode_output_ += ')';
 }
 --elsif_count_;

 //postcode_output_ += ')';
}

void RZ_Clasp_Source_Block::hold_infix_token(QString str)
{
 // //  for Clasp we're justing putting in the token usually
 basic_add_token(str);
}

void RZ_Clasp_Source_Block::basic_add_token(QString str)
{
 if(expression_count_ > 0)
 {
  if(elsif_count_ > 0)
  {
   elsif_expression_ += str + " ";
  }
  else
  {
   postcode_output_ += str + " ";
  }
 }
 else
 {
  code_output_ += str + " ";
 }
}



void RZ_Clasp_Source_Block::add_token(QString str)
{
 if(str == "else")
 {
  if(block_kind_ == RZ_Clasp_Code_Block_Kinds::Elsif_Block)//?if(elsif_expression_.isEmpty())
  {
   // // assume is_elsif flag
   postcode_output_ += "\n (t ;else\n";
   //?postcode_output_ += "\n;else\n";
  }
  else
  {
   postcode_output_ += "\n;else\n";
   //? postcode_output_ += "\n t ;else\n";
  }
 }
 else if(str == "elsif")
 {
  postcode_output_ += "\n;elsif\n";
  ++elsif_count_;
 }
 else
  basic_add_token(str);
}

void RZ_Clasp_Source_Block::add_nested_block(caon_ptr<RZ_Clasp_Source_Block> sb)
{
 continue_block_ = sb;
}

caon_ptr<RZ_Clasp_Source_Element> RZ_Clasp_Source_Block::find_parent_unwind(int& unwind_count)
{
 CAON_PTR_DEBUG(RZ_Clasp_Source_Element ,parent_element_)
 switch(block_kind_)
 {
 case RZ_Clasp_Code_Block_Kinds::Elsif_Block:
 case RZ_Clasp_Code_Block_Kinds::Else_Block:
  ++unwind_count;
  return parent_element_->find_parent_unwind(unwind_count);
 case RZ_Clasp_Code_Block_Kinds::If_Block:
  ++unwind_count;
  return parent_element_;
 default:
  ++unwind_count;
  return parent_element_;
 }
}

void RZ_Clasp_Source_Block::find_parent_block(caon_ptr<RZ_Clasp_Source_Block>& result)
{
 // //  Overloaded so as to set the first RZ_Clasp_Source_Element
  // which is a RZ_Clasp_Source_Block; the implementation for
  // types other than RZ_Clasp_Source_Element just calls the same
  // method on its parent, if that exists; so eventually
  // looping through parents until reaching here.
 result = this;
}

QString RZ_Clasp_Source_Block::switch_current_labels(QString new_label)
{
 QString result = current_label_;
 current_label_ = new_label;
 return result;
}


