
#ifndef RZ_CLASP_SOURCE_BLOCK__H
#define RZ_CLASP_SOURCE_BLOCK__H

#include "accessors.h"
#include "flags.h"

#include "rz-clasp-source-element.h"

#include "rz-code-generators/rz-function-def-syntax.h"
#include "rz-clasp-code-block-kinds.h"
#include "rz-clasp-code-special-conditions.h"

#include <QString>
#include <QTextStream>
#include <QMap>
#include <QList>

#include <functional>

#include "rzns.h"


RZNS_(GVal)

class RZ_Function_Def_Info;

_RZNS(GVal)

USING_RZNS(GVal)


RZNS_(RECore)

class RZ_Clasp_Code_Block;

_RZNS(RECore)

USING_RZNS(RECore)


RZNS_(RZClasp)

class RZ_Clasp_Code_Lexmap;

class RZ_Clasp_Source_Block : public RZ_Clasp_Source_Element
{
 RZ_Clasp_Code_Block_Kinds block_kind_;
 caon_ptr<RZ_Clasp_Source_Fundef> fundef_;
 caon_ptr<RZ_Clasp_Source_Block> continue_block_;
 caon_ptr<RZ_Clasp_Source_Block> parent_block_;

 // //  this may not be necessary (not currently used ...)
 caon_ptr<RZ_Clasp_Code_Block> code_block_;

 int expression_count_;

 int elsif_count_;

 QString elsif_expression_;

 void basic_add_token(QString str);

 caon_ptr<RZ_Clasp_Code_Lexmap> lexmap_;

 QString current_label_;

 QString text_hint_;


public:

 RZ_Clasp_Source_Block(caon_ptr<RZ_Clasp_Cpp_Code_Generator> cpp_code_gen,
  caon_ptr<RZ_Clasp_Source_Element> parent_element, caon_ptr<RZ_Clasp_Source_Block> parent_block,
  caon_ptr<RZ_Clasp_Code_Block> code_block, RZ_Clasp_Code_Block_Kinds block_kind,
  caon_ptr<RZ_Clasp_Source_Fundef> fundef = nullptr);

 caon_ptr<RZ_Clasp_Source_Element> find_parent_unwind(int& unwind_count) override;


 ACCESSORS(caon_ptr<RZ_Clasp_Code_Lexmap> ,lexmap)
 ACCESSORS(QString ,text_hint)
 ACCESSORS(caon_ptr<RZ_Clasp_Source_Fundef> ,fundef)
 ACCESSORS(RZ_Clasp_Code_Block_Kinds ,block_kind)
 ACCESSORS(caon_ptr<RZ_Clasp_Code_Block> ,code_block)
 ACCESSORS(caon_ptr<RZ_Clasp_Source_Block> ,parent_block)

 QString lexmap_declarations(QString& scope_entry, QString& scope_leave, int indentation = 0);

 void write(QTextStream& qts, int indentation) override;
 void add_statement(caon_ptr<RZ_Clasp_Source_Statement> st) override;
 void check_as_block(caon_ptr<RZ_Clasp_Source_Block>& bl) override;

 void prepare_expression_entry(QString prefix) override;
 void prepare_expression_leave() override;
 void add_token(QString str) override;
 void add_nested_block(caon_ptr<RZ_Clasp_Source_Block> sb) override;
 void hold_infix_token(QString str) override;
 void find_parent_block(caon_ptr<RZ_Clasp_Source_Block>& result) override;

 QString source_element_cpp_type() override;
 void debug_inspect() override;



 caon_ptr<RZ_Clasp_Source_Block> prepare_block_map_continue() override;

 void get_block_kind(RZ_Clasp_Code_Block_Kinds& block_kind) override
 {
  if(block_kind_ == RZ_Clasp_Code_Block_Kinds::N_A)
   block_kind = RZ_Clasp_Code_Block_Kinds::Generic_Block;
  else
   block_kind = block_kind_;
 }

 QString switch_current_labels(QString new_label);
};

_RZNS(RZClasp)

#endif
