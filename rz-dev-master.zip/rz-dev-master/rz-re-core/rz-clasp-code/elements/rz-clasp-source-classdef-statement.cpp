
#include "rz-clasp-source-classdef-statement.h"

#include "rz-clasp-source-classdef.h"
#include "rz-clasp-source-fundef.h"

#define SCC caon_static_cast<RZ_Clasp_Source_Element>()

USING_RZNS(RZClasp)


RZ_Clasp_Source_Classdef_Statement::RZ_Clasp_Source_Classdef_Statement(caon_ptr<RZ_Clasp_Cpp_Code_Generator> cpp_code_gen_,
  caon_ptr<RZ_Clasp_Source_Element> parent_element)
 :  RZ_Clasp_Source_Statement(cpp_code_gen_, parent_element)
{
 flags.fieldef = true;
}

//RZ_Clasp_Source_Statement::RZ_Clasp_Source_Statement(caon_ptr<RZ_Clasp_Source_Element> parent_element)
// : RZ_Clasp_Source_Element(parent_element),
//   expression_count_(0), current_expression_count_(0), first_nested_block_(nullptr)
//{

//}

void RZ_Clasp_Source_Classdef_Statement::write(QTextStream& qts, int indentation)
{
 if(flags.no_write)
  return;

 if(cpp_code_gen_)
 {
  if(function_field_name_.isEmpty())
  {
   if(type_name_.isEmpty())
    qts << //?"auto! " <<
           field_name_ << " ";
   else
    qts << type_name_ << " " << field_name_ << " ";
  }
 }
 else
 {
  qts << '(' << field_name_ << " :accessor "
    << class_name_prefix() << field_name_
    << " :initarg :" << field_name_ << "= "
    << " :initform ";
 }
 write_code_output(qts);

 write_children(qts, 0);

 write_postcode_output(qts);

 //qts << ")\n";
}

QString RZ_Clasp_Source_Classdef_Statement::class_name_prefix()
{
 if(current_classdef_)
 {
  return QString("%1///").arg(current_classdef_->class_name());
 }
 return QString();
}


void RZ_Clasp_Source_Classdef_Statement::add_fundef(caon_ptr<RZ_Clasp_Source_Fundef> el)
{
 CAON_PTR_DEBUG(RZ_Clasp_Source_Fundef ,el)
 function_field_name_ = el->function_name();
 el->set_current_classdef(current_classdef_);
 child_elements_.push_back(el.SCC);
 first_nested_fundef_ = el;
}

void RZ_Clasp_Source_Classdef_Statement::add_car_token(QString str)
{
 if(str == ";;;;")
 {
  flags.no_write = true;
  current_classdef_->leave();
 }
}


void RZ_Clasp_Source_Classdef_Statement::add_type_declaration_token(QString str)
{
 if(cpp_code_gen_)
 {
  type_name_ = str;
 }
 else
 {
  type_declaration_output_ += QString("\n(declare (type %1 ").arg(str);
 }
}


void RZ_Clasp_Source_Classdef_Statement::add_token(QString str)
{
 if(field_name_.isEmpty())
 {
  field_name_ = str;
 }
 else
 {
  this->RZ_Clasp_Source_Statement::add_token(str);
 }
}


//void RZ_Clasp_Source_Statement::write(QTextStream& qts, int indentation)
//{
// write_indentation(qts, indentation);
// //?qts << '(';

// if(!label_.isEmpty())
// {
//  if(!previous_label_.isEmpty())
//  {
//   qts << " \n ;" << previous_label_ << ";\n";
//   write_indentation(qts, indentation);
//   qts << ") ";
//  }
//  qts << label_ << " (lambda ()";
// }

// write_code_output(qts);
// write_children(qts, indentation);
// write_postcode_output(qts);
////?
//// if(!first_nested_block_)
//// {
////  if(!code_output_.isEmpty() || child_count() > 0)
////   ;//?qts << ")\n";
//// }
//}

//void RZ_Clasp_Source_Statement::add_element(caon_ptr<RZ_Clasp_Source_Element> el)
//{
// CAON_PTR_DEBUG(RZ_Clasp_Source_Element ,el)
// child_elements_.push_back(el);
//}

//void RZ_Clasp_Source_Statement::add_fundef(caon_ptr<RZ_Clasp_Source_Fundef> el)
//{
// CAON_PTR_DEBUG(RZ_Clasp_Source_Fundef ,el)
// child_elements_.push_back(el.SCC);
// first_nested_fundef_ = el;
//}

//void RZ_Clasp_Source_Statement::add_statement(caon_ptr<RZ_Clasp_Source_Statement> st)
//{
// add_element(st.SCC);
//}


//void RZ_Clasp_Source_Statement::prepare_expression_entry(QString prefix)
//{
// if(flags.if_elsif)
// {
//  if(flags.if_elsif_entry)
//  {
//   code_output_ += prefix + "( ;clause: \n";
//   flags.if_elsif_entry = false;
//  }
// }
// code_output_ += prefix + '(';
// expression_stack_.push(expression_count_);
// current_expression_count_ = expression_count_;
// ++expression_count_;
//}

//void RZ_Clasp_Source_Statement::unwind_expression_leave()
//{
//// prepare_expression_leave();

// while(!expression_stack_.isEmpty())
// {
//  int top = expression_stack_.top();
//  prepare_expression_leave();
// }
//}

//void RZ_Clasp_Source_Statement::register_call_entry_label(QString label, QString previous_label)
//{
// label_ = label;
// previous_label_ = previous_label;
//}


//void RZ_Clasp_Source_Statement::prepare_expression_leave()
//{
// if(expression_stack_.isEmpty())
// {
//  // maybe an unwind_expression_leave already handled everything...
//  return;
// }
// current_expression_count_ = expression_stack_.pop();
// if(current_expression_count_ == 0)
// {
//  postcode_output_ += ";statement;\n";
//  postcode_output_ += ')';
//  postcode_output_ += '\n';
// }
// else if(first_nested_block_)
// {
//  postcode_output_ += ";expr;\n";
//  postcode_output_ += ')';
//  postcode_output_ += '\n';
// }
// else if(first_nested_fundef_)
// {
//  postcode_output_ += ";expr;\n";
//  postcode_output_ += ')';
//  postcode_output_ += '\n';
// }
// else
// {
//  code_output_ += ";expr;\n";
//  code_output_ += ')';
//  code_output_ += '\n';

////?
////  code_output_ += ";expr;\n";
////  code_output_ += ')';
////  code_output_ += '\n';
// }
//// while(current_expression_count_ > 0)
//// {
////  --current_expression_count_;
////  if(current_expression_count_ > 0)
////   postcode_output_ += ')';
////  else
////   postcode_output_ += " ;added:statement;\n)";
//// }
//}

//void RZ_Clasp_Source_Statement::prepare_expression_continue()
//{
// code_output_ += " ";
//}

//void RZ_Clasp_Source_Statement::hold_infix_token(QString str)
//{
// // For clasp, don't bother with held tokens usually...
// add_token(str);
// // held_infix_tokens_[current_expression_count_] = str;
//}

//void RZ_Clasp_Source_Statement::check_held_infix_token(QString follow)
//{
// if(held_infix_tokens_.contains(current_expression_count_))
// {
//  code_output_ += held_infix_tokens_.take(current_expression_count_) + follow;
// }
//}

//void RZ_Clasp_Source_Statement::add_token(QString str)
//{
// this->RZ_Clasp_Source_Element::add_token(str);
// //? check_held_infix_token(" ");
//}

//void RZ_Clasp_Source_Statement::add_car_token(QString str)
//{
// this->RZ_Clasp_Source_Element::add_car_token(str);
// //? check_held_infix_token(" ");
//}

//void RZ_Clasp_Source_Statement::add_nested_block(caon_ptr<RZ_Clasp_Source_Block> sb)
//{
// add_element(sb.SCC);
// if(!first_nested_block_)
//  first_nested_block_ = sb;
//}
