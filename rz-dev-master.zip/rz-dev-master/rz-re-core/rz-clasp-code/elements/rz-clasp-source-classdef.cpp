
#include "rz-clasp-source-classdef.h"

#include "rz-clasp-source-classdef-statement.h"

#include "rz-clasp-source-statement.h"

USING_RZNS(RZClasp)

#define SCC caon_static_cast<RZ_Clasp_Source_Element>()

RZ_Clasp_Source_Classdef::RZ_Clasp_Source_Classdef(caon_ptr<RZ_Clasp_Cpp_Code_Generator> cpp_code_gen,
  caon_ptr<RZ_Clasp_Source_Element> parent_element,
  caon_ptr<RZ_Clasp_Source_Classdef> parent_classdef,                                                  QString scope_kind_name,
  QString class_name)
 : RZ_Clasp_Source_Element(cpp_code_gen, parent_element),
   parent_classdef_(parent_classdef),
   scope_kind_name_(scope_kind_name), class_name_(class_name)
{

}


void RZ_Clasp_Source_Classdef::leave()
{
 CAON_PTR_DEBUG(RZ_Clasp_Source_Element ,parent_element_)

 flags.scope_close = true;
}


caon_ptr<RZ_Clasp_Source_Element> RZ_Clasp_Source_Classdef::new_nested_statement()
{
 caon_ptr<RZ_Clasp_Source_Classdef_Statement> result =
   new RZ_Clasp_Source_Classdef_Statement(cpp_code_gen_, this);
 add_element(result.SCC);
 result->set_current_classdef(this);
 return result.SCC;
}

void RZ_Clasp_Source_Classdef::add_statement(caon_ptr<RZ_Clasp_Source_Statement> st)
{
 //
 add_element(st.SCC);
 st->set_current_classdef(this);
}


void RZ_Clasp_Source_Classdef::add_token(QString str)
{
 code_output_ += str + " ";
}

caon_ptr<RZ_Clasp_Source_Element> RZ_Clasp_Source_Classdef::check_end_statement()
{
 return this;
}

QString RZ_Clasp_Source_Classdef::check_function_rename(QString str)
{
 static QMap<QString, QString> static_map {{
  { "our", "field-def" },
 }};

 return static_map.value(str);
}

caon_ptr<RZ_Clasp_Source_Element> RZ_Clasp_Source_Classdef::add_as_child(caon_ptr<RZ_Clasp_Source_Element> se)
{
 CAON_PTR_DEBUG(RZ_Clasp_Source_Element ,se)
 se->add_classdef(this);
 return this;
// if(se->child_count() == 0)
// {
//  se->add_fundef(this);
//  //?this->RZ_Clasp_Source_Element::add_as_child(se);
//  //?se->swap_in_parent(this);
//  return block_.SCC;
// }
// else
// {
//  se->add_fundef(this);
//  //?this->RZ_Clasp_Source_Element::add_as_child(se);
//  return nullptr;
// }
}

QString RZ_Clasp_Source_Classdef::inheritance_string()
{
 return parent_class_names_.join(' ');
}


void RZ_Clasp_Source_Classdef::write(QTextStream& qts, int indentation)
{
 if(cpp_code_gen_)
 {
  qts << scope_kind_name_ << " " << class_name_ << "\n{\n";
 }
 else
 {
  qts << "defclass " << class_name_ << " ("
   << inheritance_string() << ")( \n\n";
 }
 write_children(qts, indentation);
 if(cpp_code_gen_)
 {
  qts << "\n}\n\n";
 }
 else
 {
  qts << ";field/slots;\n) ;defclass;\n)\n";
 }
}




