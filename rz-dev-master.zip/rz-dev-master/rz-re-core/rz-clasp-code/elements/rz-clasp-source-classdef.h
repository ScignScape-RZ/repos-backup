
#ifndef RZ_CLASP_SOURCE_CLASSDEF__H
#define RZ_CLASP_SOURCE_CLASSDEF__H

#include "accessors.h"
#include "flags.h"

#include "rz-clasp-source-element.h"

#include <QString>
#include <QTextStream>
#include <QMap>
#include <QList>

#include <functional>

#include "rzns.h"


RZNS_(GVal)

//class RZ_Function_Def_Info;

_RZNS(GVal)

USING_RZNS(GVal)


RZNS_(RZClasp)

class RZ_Clasp_Source_Block;

class RZ_Clasp_Source_Classdef : public RZ_Clasp_Source_Element
{
 QString scope_kind_name_;

 QString class_name_;

 QStringList parent_class_names_;

 // caon_ptr<RZ_Clasp_Source_Block> block_;
 caon_ptr<RZ_Clasp_Source_Element> context_element_;

 caon_ptr<RZ_Clasp_Source_Classdef> parent_classdef_;

public:

 RZ_Clasp_Source_Classdef(caon_ptr<RZ_Clasp_Cpp_Code_Generator> cpp_code_gen, caon_ptr<RZ_Clasp_Source_Element> parent_element,
  caon_ptr<RZ_Clasp_Source_Classdef> parent_classdef, QString scope_kind_name, QString class_name);

 //?
 ACCESSORS(caon_ptr<RZ_Clasp_Source_Element> ,context_element)
 ACCESSORS(QString ,class_name)

 ACCESSORS(caon_ptr<RZ_Clasp_Source_Classdef> ,parent_classdef)


 void write(QTextStream& qts, int indentation) override;

 caon_ptr<RZ_Clasp_Source_Element> add_as_child(caon_ptr<RZ_Clasp_Source_Element> se) override;

 void add_statement(caon_ptr<RZ_Clasp_Source_Statement> st) override;
 void add_token(QString str) override;

 caon_ptr<RZ_Clasp_Source_Element> check_end_statement() override;

 QString check_function_rename(QString str) override;
 caon_ptr<RZ_Clasp_Source_Element> new_nested_statement() override;

 void leave();
 QString inheritance_string();

};

_RZNS(RZClasp)

#endif
