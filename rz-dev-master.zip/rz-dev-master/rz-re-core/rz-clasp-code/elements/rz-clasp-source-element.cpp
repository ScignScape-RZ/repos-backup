
#include "rz-clasp-source-element.h"

#include "rz-clasp-source-classdef.h"

#include "rz-graph-core/token/rz-re-token.h"

#define SCC caon_static_cast<RZ_Clasp_Source_Element>()


USING_RZNS(RZClasp)


RZ_Clasp_Source_Element::RZ_Clasp_Source_Element(caon_ptr<RZ_Clasp_Cpp_Code_Generator> cpp_code_gen,
  caon_ptr<RZ_Clasp_Source_Element> parent_element)
 : Flags(0), cpp_code_gen_(cpp_code_gen), parent_element_(parent_element),
   current_classdef_(nullptr), indentation_(0)
 //: parent_block_(parent_block)
{

}

void RZ_Clasp_Source_Element::write_indentation(QTextStream& qts, int indentation)
{
 qts << QString(indentation_ + indentation, ' ');
}

void RZ_Clasp_Source_Element::parent_write_indentation(QTextStream& qts, int indentation)
{
 if(parent_element_)
  parent_element_->write_indentation(qts, indentation);
}

void RZ_Clasp_Source_Element::write_newline_and_indentation(QTextStream& qts, int indentation)
{
 qts << "\n";
 write_indentation(qts, indentation);
}



void RZ_Clasp_Source_Element::add_statement(caon_ptr<RZ_Clasp_Source_Statement> st)
{

}

void RZ_Clasp_Source_Element::add_fundef(caon_ptr<RZ_Clasp_Source_Fundef> fdef)
{
 add_element(fdef.SCC);
}

void RZ_Clasp_Source_Element::add_classdef(caon_ptr<RZ_Clasp_Source_Classdef> cdef)
{
 add_element(cdef.SCC);
 if(parent_element_)
 {
  parent_element_->enter_classdef(cdef);
 }
}

void RZ_Clasp_Source_Element::enter_classdef(caon_ptr<RZ_Clasp_Source_Classdef> cdef)
{
 current_classdef_ = cdef;
 //current_element_ = cdef;
 cdef->set_context_element(this);
}


void RZ_Clasp_Source_Element::find_parent_block(caon_ptr<RZ_Clasp_Source_Block>& result)
{
 if(parent_element_)
 {
  parent_element_->find_parent_block(result);
 }
 else
 {
  result = nullptr;
 }
}

void RZ_Clasp_Source_Element::add_precode(QString str)
{
 precode_output_ += str;
}

void RZ_Clasp_Source_Element::add_postcode(QString str)
{
 postcode_output_ += str;
}

void RZ_Clasp_Source_Element::set_label(QString label)
{
 // // many elements don't have labels ...
}

void RZ_Clasp_Source_Element::write(QTextStream& qts, int indentation)
{
 write_children(qts, indentation);
 write_post_raw_lisp(qts);
}

QString RZ_Clasp_Source_Element::type_indicator_when_preceding_symbol(QString type_name)
{
 return QString(":|type:%1|").arg(type_name);
}

void RZ_Clasp_Source_Element::setup_retval()
{
 flags.has_setup_retval = true;
}


void RZ_Clasp_Source_Element::write_post_raw_lisp(QTextStream& qts)
{
 qts << post_raw_lisp_;
}

void RZ_Clasp_Source_Element::write_code_output(QTextStream& qts)
{
 qts << code_output_;
}

void RZ_Clasp_Source_Element::write_postcode_output(QTextStream& qts)
{
 if(!held_type_declaration_token_.isEmpty())
 {
  qts << " " << held_type_declaration_token_;
 }
 qts << postcode_output_;
}

void RZ_Clasp_Source_Element::write_precode_output(QTextStream& qts)
{
 qts << precode_output_;
}

caon_ptr<RZ_Clasp_Source_Block> RZ_Clasp_Source_Element::prepare_block_map_continue()
{
 // //  syntax error?
 return nullptr;
}

void RZ_Clasp_Source_Element::write_children(QTextStream& qts, int indentation)
{
 for(caon_ptr<RZ_Clasp_Source_Element> el: child_elements_)
 {
  CAON_PTR_DEBUG(RZ_Clasp_Source_Element ,el)
  el->write(qts, indentation + indentation_);
 }
}

void RZ_Clasp_Source_Element::prepare_statement_leave_after_block_map()
{
 // // syntax error?
}


void RZ_Clasp_Source_Element::check_as_block(caon_ptr<RZ_Clasp_Source_Block>& bl)
{
}
//void RZ_Clasp_Source_Element::write_children_parent_indentation(QTextStream& qts, int indentation)
//{
// if(parent_element_)
//  indentation += parent_element_->indentation_;
// for(caon_ptr<RZ_Clasp_Source_Element> el: child_elements_)
// {
//  el->write(qts, indentation);
// }
//}

void RZ_Clasp_Source_Element::add_raw_lisp(QString lisp, RZ_Clasp_Code_Lisp_Paste_Modes mode)
{
//?
 switch(mode)
 {
 case RZ_Clasp_Code_Lisp_Paste_Modes::Root:
  post_raw_lisp_ += lisp;
  break;

 case RZ_Clasp_Code_Lisp_Paste_Modes::Follow:
  {
   if(child_elements_.count() > 0)
   {
    caon_ptr<RZ_Clasp_Source_Element> ce = child_elements_.last();
    ce->add_raw_lisp(lisp, mode);
   }
  }
 }
 //post_raw_lisp_ += lisp;
}

void RZ_Clasp_Source_Element::add_element(caon_ptr<RZ_Clasp_Source_Element> el)
{
 child_elements_.push_back(el);
}

void RZ_Clasp_Source_Element::add_token(QString str)
{
 code_output_ += str + " ";
}

void RZ_Clasp_Source_Element::add_car_token(QString str)
{
 add_token(str);
}


void RZ_Clasp_Source_Element::add_assignment_entry_token(QString str)
{
 if(cpp_code_gen_)
 {
  if(held_type_declaration_token_.isEmpty())
   add_token(str);
  else
  {
   add_token("typedef");
   //type_declaration_output_ += held_type_declaration_token_;
  }
 }
 else
 {
  add_token(str);
 }
}

//held_type_declaration_token_

void RZ_Clasp_Source_Element::add_type_declaration_token(QString str)
{
 if(cpp_code_gen_)
 {
  if(str.endsWith('\''))
    str.chop(1);

  held_type_declaration_token_ = str;
  //add_token(str);
 }
 else
 {
  type_declaration_output_ += QString("\n(declare (type %1 ").arg(str);
 }
}

void RZ_Clasp_Source_Element::add_type_declaration_symbol(QString str)
{
 if(cpp_code_gen_)
 {

 }
 else if(!type_declaration_output_.isEmpty())
 {
  type_declaration_output_ += QString("%1))\n").arg(str);
 }
}


void RZ_Clasp_Source_Element::debug_inspect()
{

}

QString RZ_Clasp_Source_Element::source_element_cpp_type()
{
 return "RZ_Clasp_Source_Element";
}

void RZ_Clasp_Source_Element::hold_infix_token(QString str)
{
 // //  for Clasp we're justing putting in the token usually
 code_output_ += str + " ";
}

int RZ_Clasp_Source_Element::child_count()
{
 return child_elements_.count();
}

caon_ptr<RZ_Clasp_Source_Element> RZ_Clasp_Source_Element::add_as_child(caon_ptr<RZ_Clasp_Source_Element> se)
{
 se->add_element(this);
 return nullptr;
}

void RZ_Clasp_Source_Element::swap_in_parent(caon_ptr<RZ_Clasp_Source_Element> se)
{
 parent_element_->swap_child(this, se);
}

void RZ_Clasp_Source_Element::swap_child(caon_ptr<RZ_Clasp_Source_Element> old_se, caon_ptr<RZ_Clasp_Source_Element> new_se)
{
 CAON_PTR_DEBUG(RZ_Clasp_Source_Element ,old_se)
 CAON_PTR_DEBUG(RZ_Clasp_Source_Element ,new_se)
 int i = child_elements_.lastIndexOf(old_se);
 if(i != -1)
 {
  child_elements_.replace(i, new_se);
 }
}

void RZ_Clasp_Source_Element::prepare_expression_entry(QString prefix)
{

}

void RZ_Clasp_Source_Element::prepare_expression_leave()
{

}

caon_ptr<RZ_Clasp_Source_Element> RZ_Clasp_Source_Element::check_end_statement()
{
 return nullptr;
}


void RZ_Clasp_Source_Element::write_type_declarations(QTextStream& qts, int indentation)
{
 qts << type_declaration_output_;
}


QString RZ_Clasp_Source_Element::check_function_rename(QString str)
{
 if(current_classdef_)
  return current_classdef_->check_function_rename(str);
 return QString();
}

caon_ptr<RZ_Clasp_Source_Element> RZ_Clasp_Source_Element::new_nested_statement()
{
 return nullptr;
}


void RZ_Clasp_Source_Element::unwind_expression_leave()
{

}

void RZ_Clasp_Source_Element::prepare_expression_continue()
{

}

void RZ_Clasp_Source_Element::register_call_entry_label(QString label, QString previous_label)
{

}

void RZ_Clasp_Source_Element::add_nested_block(caon_ptr<RZ_Clasp_Source_Block> sb)
{

}

caon_ptr<RZ_Clasp_Source_Element> RZ_Clasp_Source_Element::find_parent_unwind(int& unwind_count)
{
 return nullptr;
 //? This should only be blocks?
}

void RZ_Clasp_Source_Element::init_special_condition(RZ_Clasp_Code_Special_Conditions sc)
{
 switch(sc)
 {
 case RZ_Clasp_Code_Special_Conditions::If_Elsif:
  flags.if_elsif = true;
  break;
 case RZ_Clasp_Code_Special_Conditions::If_Elsif_Entry:
  flags.if_elsif_entry = true;
  break;
 default:
  break;
 }
}

