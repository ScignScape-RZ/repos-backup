
#ifndef RZ_CLASP_SOURCE_ELEMENT__H
#define RZ_CLASP_SOURCE_ELEMENT__H

#include "accessors.h"
#include "flags.h"

#include "rz-relae/relae-node-ptr.h"

#include "output/rz-re-lisp-output.h"

#include "rz-graph-core/kernel/graph/rz-re-graph.h"

#include "rz-graph-token/token/token-kinds.h"

//?
#include "rz-clasp-code/rz-clasp-code-special-conditions.h"

#include "flags.h"

#include <QString>
#include <QTextStream>
#include <QMap>
#include <QList>

#include <functional>

#include "rz-clasp-code/rz-clasp-code-block-kinds.h"

#include "rz-clasp-code/rz-clasp-code-lisp-paste-modes.h"

#include "rzns.h"


RZNS_(RZClasp)

class RZ_Clasp_Source_Statement;
class RZ_Clasp_Source_Fundef;
class RZ_Clasp_Source_Block;
class RZ_Clasp_Source_Classdef;
class RZ_Clasp_Cpp_Code_Generator;

class RZ_Clasp_Source_Element
{
public:

 flags_(1)
  bool if_elsif:1;
  bool if_elsif_entry:1;
  bool fieldef:1;
  bool no_write:1;
  bool scope_close:1;
  bool is_source_file_entry:1;
  bool has_setup_retval:1;
 _flags


protected:

 int indentation_;
 caon_ptr<RZ_Clasp_Source_Element> parent_element_;
 QList<caon_ptr<RZ_Clasp_Source_Element> > child_elements_;

 caon_ptr<RZ_Clasp_Source_Classdef> current_classdef_;

 QString code_output_;
 QString precode_output_;
 QString postcode_output_;

 QString type_declaration_output_;

 QString post_raw_lisp_;

 QString held_type_declaration_token_;

// void write_indentation(QTextStream& qts, int indentation);

 void write_newline_and_indentation(QTextStream& qts, int indentation);
 //caon_ptr<RZ_Clasp_Code_Block> parent_block_;

 void write_indentation(QTextStream& qts, int indentation);
 void parent_write_indentation(QTextStream& qts, int indentation);

 caon_ptr<RZ_Clasp_Cpp_Code_Generator> cpp_code_gen_;


public:

 RZ_Clasp_Source_Element(caon_ptr<RZ_Clasp_Cpp_Code_Generator> cpp_code_gen, caon_ptr<RZ_Clasp_Source_Element> parent_element = nullptr);

 //RZ_Clasp_Source_Element(caon_ptr<RZ_Clasp_Cpp_Code_Generator> cpp_code_gen_);

// ACCESSORS__GET(caon_ptr<RZ_Clasp_Code_Block> ,parent_block)

 ACCESSORS(caon_ptr<RZ_Clasp_Source_Element> ,parent_element)
 ACCESSORS(int ,indentation)
 ACCESSORS(QString ,code_output)
 ACCESSORS(caon_ptr<RZ_Clasp_Source_Classdef> ,current_classdef)

 ACCESSORS(caon_ptr<RZ_Clasp_Cpp_Code_Generator> ,cpp_code_gen)

 ACCESSORS(QString ,type_declaration_output)


 virtual void write(QTextStream& qts, int indentation);
 virtual void add_element(caon_ptr<RZ_Clasp_Source_Element> el);
 virtual void write_children(QTextStream& qts, int indentation);

 virtual void add_token(QString str);
 virtual void add_assignment_entry_token(QString str);
 //held_type_declaration_token_

 virtual void add_type_declaration_token(QString str);
 virtual void add_type_declaration_symbol(QString str);

 virtual void add_car_token(QString str);

 virtual caon_ptr<RZ_Clasp_Source_Block> prepare_block_map_continue();

 virtual void prepare_statement_leave_after_block_map();

 virtual void write_code_output(QTextStream& qts);
 virtual void write_precode_output(QTextStream& qts);
 virtual void write_postcode_output(QTextStream& qts);
 virtual void add_statement(caon_ptr<RZ_Clasp_Source_Statement> st);
 virtual void add_fundef(caon_ptr<RZ_Clasp_Source_Fundef> st);
 virtual void add_classdef(caon_ptr<RZ_Clasp_Source_Classdef> st);
 virtual void add_nested_block(caon_ptr<RZ_Clasp_Source_Block> sb);
 virtual void add_precode(QString str);
 virtual void add_postcode(QString str);
 int child_count();
 virtual caon_ptr<RZ_Clasp_Source_Element> add_as_child(caon_ptr<RZ_Clasp_Source_Element> se);
 void swap_in_parent(caon_ptr<RZ_Clasp_Source_Element> se);
 void swap_child(caon_ptr<RZ_Clasp_Source_Element> old_se, caon_ptr<RZ_Clasp_Source_Element> new_se);
 virtual void prepare_expression_entry(QString prefix);
 virtual void prepare_expression_leave();
 virtual void unwind_expression_leave();
 virtual void find_parent_block(caon_ptr<RZ_Clasp_Source_Block>& result);

 virtual void enter_classdef(caon_ptr<RZ_Clasp_Source_Classdef> cdef);

 virtual void add_raw_lisp(QString lisp, RZ_Clasp_Code_Lisp_Paste_Modes mode);

 virtual void set_label(QString label);

 virtual void write_post_raw_lisp(QTextStream& qts);

 virtual void setup_retval();

 virtual QString source_element_cpp_type();

 virtual QString type_indicator_when_preceding_symbol(QString type_name);

 virtual void prepare_expression_continue();
 virtual void hold_infix_token(QString str);
 virtual void check_as_block(caon_ptr<RZ_Clasp_Source_Block>& bl);
 virtual caon_ptr<RZ_Clasp_Source_Element> find_parent_unwind(int& unwind_count);

 virtual void init_special_condition(RZ_Clasp_Code_Special_Conditions sc);

 virtual void debug_inspect();
 virtual void get_block_kind(RZ_Clasp_Code_Block_Kinds& block_kind)
 {
  block_kind = RZ_Clasp_Code_Block_Kinds::N_A;
 }

 virtual void register_call_entry_label(QString label, QString previous_label);

 virtual caon_ptr<RZ_Clasp_Source_Element> check_end_statement();
 virtual caon_ptr<RZ_Clasp_Source_Element> new_nested_statement();

 virtual QString check_function_rename(QString str);

 virtual void write_type_declarations(QTextStream& qts, int indentation);


 //?virtual void write_children_parent_indentation(QTextStream& qts, int indentation);

 //?
 //void write_indentation(QTextStream& qts, int indentation);

};

_RZNS(RZClasp)

#endif
