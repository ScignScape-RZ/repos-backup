
#include "rz-clasp-source-fieldef.h"


USING_RZNS(RZClasp)

RZ_Clasp_Source_Fieldef::RZ_Clasp_Source_Fieldef(caon_ptr<RZ_Clasp_Cpp_Code_Generator> cpp_code_gen)
 : RZ_Clasp_Source_Element(cpp_code_gen)
{

}



