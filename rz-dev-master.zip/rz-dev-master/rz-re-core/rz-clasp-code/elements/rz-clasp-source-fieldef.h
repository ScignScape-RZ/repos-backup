
#ifndef RZ_CLASP_SOURCE_FIELDEF__H
#define RZ_CLASP_SOURCE_FIELDEF__H

#include "accessors.h"
#include "flags.h"

#include "rz-clasp-source-element.h"

#include <QString>
#include <QTextStream>
#include <QMap>
#include <QList>

#include <functional>

#include "rzns.h"


RZNS_(RZClasp)

class RZ_Clasp_Source_Fieldef : public RZ_Clasp_Source_Element
{

public:

 RZ_Clasp_Source_Fieldef(caon_ptr<RZ_Clasp_Cpp_Code_Generator> cpp_code_gen);



};

_RZNS(RZClasp)

#endif
