
#include "rz-clasp-source-file-entry.h"



USING_RZNS(RZClasp)

RZ_Clasp_Source_File_Entry::RZ_Clasp_Source_File_Entry(
  caon_ptr<RZ_Clasp_Cpp_Code_Generator> cpp_code_gen)
 : RZ_Clasp_Source_Element(cpp_code_gen)
{
 flags.is_source_file_entry = true;
}


void RZ_Clasp_Source_File_Entry::write(QTextStream& qts, int indentation)
{
 if(cpp_code_gen_)
 {
  qts << "\n\n// // Insert extra requires/includes...\n";
  qts << "#include \"" RZ_INSTALLATION_DIRECTORY "/core-include.h\"";
  qts << "\n\n";
 }
 else
 {
  qts << "\n\n;;;; Insert extra requires/includes...\n";
   //? qts << "(load \"" RZ_INSTALLATION_DIRECTORY "/cl/core-load.cl\")";
  qts << "\n\n";
 }
 write_post_raw_lisp(qts);
}

