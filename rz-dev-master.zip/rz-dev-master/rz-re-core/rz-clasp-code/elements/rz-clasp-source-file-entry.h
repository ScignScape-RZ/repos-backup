
#ifndef RZ_CLASP_SOURCE_FILE_ENTRY__H
#define RZ_CLASP_SOURCE_FILE_ENTRY__H

#include "accessors.h"
#include "flags.h"

#include "rz-clasp-source-element.h"

#include <QString>
#include <QTextStream>
#include <QMap>
#include <QList>

#include <functional>

#include "rzns.h"


RZNS_(RZClasp)

class RZ_Clasp_Source_File_Entry : public RZ_Clasp_Source_Element
{

public:

 RZ_Clasp_Source_File_Entry(caon_ptr<RZ_Clasp_Cpp_Code_Generator> cpp_code_gen);

 void write(QTextStream& qts, int indentation) override;


};

_RZNS(RZClasp)

#endif
