
#include "rz-clasp-source-file.h"
#include "rz-clasp-source-block.h"
#include "rz-clasp-source-file-entry.h"

//?RZ_Clasp_Source_Block

#define SCC caon_static_cast<RZ_Clasp_Source_Element>()


USING_RZNS(RZClasp)

RZ_Clasp_Source_File::RZ_Clasp_Source_File(caon_ptr<RZ_Clasp_Cpp_Code_Generator> cpp_code_gen_)
 : RZ_Clasp_Source_Element(cpp_code_gen_), current_classdef_(nullptr)
{

}

void RZ_Clasp_Source_File::add_nested_block(caon_ptr<RZ_Clasp_Source_Block> sb)
{
 source_block_ = sb;
}

void RZ_Clasp_Source_File::add_element(caon_ptr<RZ_Clasp_Source_Element> el)
{
 if(el->flags.is_source_file_entry)
 {
  source_file_entry_ = el.caon_cast<RZ_Clasp_Source_File_Entry>();
 }
 else
 {
  child_elements_.push_back(el);
 }
}

void RZ_Clasp_Source_File::write(QTextStream& qts, int indentation)
{
 //?qts << "(progn \n\n";

 write_post_raw_lisp(qts);

 QString lex_entry;
 QString lex_leave;

 QString lexmap;

 if(source_file_entry_)
 {
  source_file_entry_->write(qts, indentation);
 }

 if(source_block_)
 {
  lexmap = source_block_->lexmap_declarations(lex_entry, lex_leave);
 }

 if(!lexmap.isNull())
 {
  qts << '(' << lexmap << "\n\n";
 }

 if(!lex_entry.isEmpty())
 {
  qts << "\n " << lex_entry << "\n\n";
 }

 for(caon_ptr<RZ_Clasp_Source_Element> el: child_elements_)
 {
  CAON_PTR_DEBUG(RZ_Clasp_Source_Element ,el)
  el->write(qts, indentation);
 }

 if(!lex_leave.isEmpty())
 {
  qts << "\n " << lex_leave;
 }

 if(!lexmap.isNull())
 {
  qts << "\n ;source-file-block;\n)";
 }
 //?qts << "\n\n;progn;\n)";
}

void RZ_Clasp_Source_File::debug_inspect()
{
 for(caon_ptr<RZ_Clasp_Source_Element> el: child_elements_)
 {
  CAON_PTR_DEBUG(RZ_Clasp_Source_Element ,el)
  el->debug_inspect();
 }
}


void RZ_Clasp_Source_File::add_statement(caon_ptr<RZ_Clasp_Source_Statement> st)
{
 child_elements_.push_back(st.SCC);
}


