
#ifndef RZ_CLASP_SOURCE_FILE__H
#define RZ_CLASP_SOURCE_FILE__H

#include "accessors.h"
#include "flags.h"

#include "rz-clasp-source-element.h"

#include <QString>
#include <QTextStream>
#include <QMap>
#include <QList>

#include <functional>

#include "rzns.h"


RZNS_(RZClasp)


class RZ_Clasp_Source_Classdef;
class RZ_Clasp_Source_Block;
class RZ_Clasp_Source_File_Entry;


class RZ_Clasp_Source_File : public RZ_Clasp_Source_Element
{

 caon_ptr<RZ_Clasp_Source_Classdef> current_classdef_;
 caon_ptr<RZ_Clasp_Source_Block> source_block_;

 caon_ptr<RZ_Clasp_Source_File_Entry> source_file_entry_;

public:

 ACCESSORS(caon_ptr<RZ_Clasp_Source_Classdef> ,current_classdef)


 RZ_Clasp_Source_File(caon_ptr<RZ_Clasp_Cpp_Code_Generator> cpp_code_gen_);



 void write(QTextStream& qts, int indentation) override;
 void add_statement(caon_ptr<RZ_Clasp_Source_Statement> st) override;
 void debug_inspect() override;

 void add_nested_block(caon_ptr<RZ_Clasp_Source_Block> sb) override;

 void add_element(caon_ptr<RZ_Clasp_Source_Element> el) override;

};

_RZNS(RZClasp)

#endif
