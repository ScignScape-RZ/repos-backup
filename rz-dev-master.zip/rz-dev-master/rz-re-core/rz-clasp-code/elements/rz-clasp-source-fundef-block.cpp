
//#include "rz-clasp-source-fundef-block.h"

//#include "rz-code-generators/rz-function-def-info.h"

//#define SCC caon_static_cast<RZ_Clasp_Source_Element>()

//USING_RZNS(RZClasp)

//RZ_Clasp_Source_Fundef_Block::RZ_Clasp_Source_Fundef_Block(caon_ptr<RZ_Clasp_Source_Element> parent_element,
//  RZ_Clasp_Source_Fundef& fundef, RZ_Clasp_Code_Block_Kinds block_kind)
// : RZ_Clasp_Source_Element(parent_element), fundef_(fundef), block_kind_(block_kind)
//{

//}

//void RZ_Clasp_Source_Fundef_Block::add_statement(caon_ptr<RZ_Clasp_Source_Statement> st)
//{
// child_elements_.push_back(st.SCC);
//}


//void RZ_Clasp_Source_Fundef_Block::write(QTextStream& qts, int indentation)
//{
// qts << "\n{";
// write_precode_output(qts);
// //?write_indentation(qts, indentation);
// write_code_output(qts);
// write_children(qts, indentation);
// qts << "\n}";
//}




