
//#ifndef RZ_CLASP_SOURCE_FUNDEF_BLOCK__H
//#define RZ_CLASP_SOURCE_FUNDEF_BLOCK__H

//#include "accessors.h"
//#include "flags.h"

//#include "rz-clasp-source-element.h"

//#include "rz-code-generators/rz-function-def-syntax.h"
//#include "rz-clasp-code-block-kinds.h"


//#include <QString>
//#include <QTextStream>
//#include <QMap>
//#include <QList>

//#include <functional>

//#include "rzns.h"


//RZNS_(GVal)

//class RZ_Function_Def_Info;

//_RZNS(GVal)

//USING_RZNS(GVal)


//RZNS_(RZClasp)

//class RZ_Clasp_Source_Fundef;

//class RZ_Clasp_Source_Fundef_Block :
//  public RZ_Clasp_Source_Element
//{
// RZ_Clasp_Source_Fundef& fundef_;
// RZ_Clasp_Code_Block_Kinds block_kind_;

//public:

// RZ_Clasp_Source_Fundef_Block(caon_ptr<RZ_Clasp_Source_Element> parent_element,
//  RZ_Clasp_Source_Fundef& fundef, RZ_Clasp_Code_Block_Kinds block_kind);

// void write(QTextStream& qts, int indentation) override;
// void add_statement(caon_ptr<RZ_Clasp_Source_Statement> st) override;


//};

//_RZNS(RZClasp)

//#endif
