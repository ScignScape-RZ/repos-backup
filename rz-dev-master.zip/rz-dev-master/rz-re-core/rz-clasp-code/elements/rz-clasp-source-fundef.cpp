
#include "rz-clasp-source-fundef.h"

#include "rz-code-generators/rz-function-def-info.h"

#include "rz-clasp-source-block.h"

USING_RZNS(RZClasp)

#define SCC caon_static_cast<RZ_Clasp_Source_Element>()

RZ_Clasp_Source_Fundef::RZ_Clasp_Source_Fundef(caon_ptr<RZ_Clasp_Cpp_Code_Generator> cpp_code_gen_,
  caon_ptr<RZ_Clasp_Source_Element> parent_element,
  QString function_name, RZ_Function_Def_Info& fdi)
 : RZ_Clasp_Source_Element(cpp_code_gen_, parent_element),
   function_name_(function_name), fdi_(fdi),
   do_map_sequence_ref_(nullptr), do_map_sequence_order_(0)
{

}

const RZ_Function_Def_Syntax& RZ_Clasp_Source_Fundef::cpp_function_def_syntax()
{
 static RZ_Function_Def_Syntax* result = nullptr;
 if(!result)
 {
  result = new RZ_Function_Def_Syntax;
  result->set_argument_default_type("auto");
  result->set_type_from_symbol_separator("<-");
   //?result->flags.type_required = true;
  result->flags.type_before_symbol = true;
 }
 return *result;
}


const RZ_Function_Def_Syntax& RZ_Clasp_Source_Fundef::function_def_syntax()
{
 static RZ_Function_Def_Syntax* result = nullptr;
 if(!result)
 {
  result = new RZ_Function_Def_Syntax;
  result->flags.hide_type = true;
  //result->set_argument_default_type("auto");
 }
 return *result;
}

bool RZ_Clasp_Source_Fundef::is_do_lambda()
{
 return fdi_.flags.do_lambda;
}

caon_ptr<RZ_Clasp_Source_Element> RZ_Clasp_Source_Fundef::add_as_child(caon_ptr<RZ_Clasp_Source_Element> se)
{
 CAON_PTR_DEBUG(RZ_Clasp_Source_Element ,se)
 if(se->child_count() == 0)
 {
  se->add_fundef(this);
  //?this->RZ_Clasp_Source_Element::add_as_child(se);
  //?se->swap_in_parent(this);
  return block_.SCC;
 }
 else
 {
  se->add_fundef(this);
  //?this->RZ_Clasp_Source_Element::add_as_child(se);
  return nullptr;
 }
}

//?
//void RZ_Clasp_Source_Fundef::write_with_possible_do_map_sequence(QTextStream& qts, int indentation, caon_ptr<RZ_Clasp_Source_Fundef> prior)
//{
// //? write_with_possible_do_map_sequence(qts, indentation, nullptr);
//}

QString RZ_Clasp_Source_Fundef::source_element_cpp_type()
{
 return "RZ_Clasp_Source_Fundef";
}

void RZ_Clasp_Source_Fundef::debug_inspect()
{
 if(block_)
 {
  CAON_PTR_DEBUG(RZ_Clasp_Source_Block ,block_)
  block_->debug_inspect();
 }

}

void RZ_Clasp_Source_Fundef::set_label(QString label)
{
 label_ = label;
}

QString RZ_Clasp_Source_Fundef::label()
{
 return label_;
}

void RZ_Clasp_Source_Fundef::write(QTextStream& qts, int indentation)
{
 QString return_channel;

 if(cpp_code_gen_)
  return_channel = fdi_.return_channel_string_cpp();
 else
  return_channel = fdi_.return_channel_string_clasp();

 QString lambda_channel;
 QString sigma_channel;

 if(cpp_code_gen_)
 {
  lambda_channel = fdi_.lambda_channel_string(cpp_function_def_syntax());
  sigma_channel = fdi_.sigma_channel_string(cpp_function_def_syntax());
 }
 else
 {
  lambda_channel = fdi_.lambda_channel_string(function_def_syntax());
  sigma_channel = fdi_.sigma_channel_string(function_def_syntax());
 }


 QString context_channel = fdi_.context_channel_string();

 QString make_do_map_close;

 write_indentation(qts, indentation);
 write_precode_output(qts);

 bool setf_lambda, do_lambda, class_lambda;

 QString label;

 if(fdi_.flags.do_lambda)
 {
  do_lambda = true;
  setf_lambda = false;
  class_lambda = false;
 }
 else if(current_classdef_)
 {
  class_lambda = true;
  do_lambda = false;
  setf_lambda = false;
 }
 else
 {
  class_lambda = false;
  do_lambda = false;
  setf_lambda = fdi_.flags.lexical_lambda || fdi_.flags.logical_lambda;
 }

 if(cpp_code_gen_)
 {
  QString merged_lambda_channel;
  if(sigma_channel.isEmpty())
  {
   merged_lambda_channel = lambda_channel;
  }
  else if(lambda_channel.isEmpty())
  {
   merged_lambda_channel = sigma_channel;
  }
  else
  {
   merged_lambda_channel = sigma_channel + ' ' + lambda_channel;
  }

  // //? This works for Clasp...
  // qts << "(cqr::cqr-defn \"" << function_name_.toUpper()
  //    << "\" (function (cl::lambda (" << lambda_channel << ')';

  // But the basic syntax for ECL

  if(class_lambda)
  {
   qts << return_channel << " " << function_name_
      << " (" << merged_lambda_channel << ')';
  }
  else if(setf_lambda)
  {
   qts << "setf " << function_name_
       << " (lambda (" << merged_lambda_channel << ')';
  }
  else if(do_lambda)
  {
   qts << " (function  (cl::lambda (" << merged_lambda_channel << ')';
  }
  else
  {
   qts << return_channel << " " << function_name_
      << " (" << merged_lambda_channel << ')';
  }

 }
 else
 {
  QString merged_lambda_channel;
  if(sigma_channel.isEmpty())
  {
   merged_lambda_channel = lambda_channel;
  }
  else if(lambda_channel.isEmpty())
  {
   merged_lambda_channel = sigma_channel;
  }
  else
  {
   merged_lambda_channel = sigma_channel + ' ' + lambda_channel;
  }

  // //? This works for Clasp...
  // qts << "(cqr::cqr-defn \"" << function_name_.toUpper()
  //    << "\" (function (cl::lambda (" << lambda_channel << ')';

  // But the basic syntax for ECL

  if(class_lambda)
  {
   qts << " (lambda (" << merged_lambda_channel << ')';
  }
  else if(setf_lambda)
  {
   qts << "setf " << function_name_
       << " (lambda (" << merged_lambda_channel << ')';
  }
  else if(do_lambda)
  {
   label = fdi_.get_label();

   if(label.isEmpty())
   {
    if(fdi_.flags.async)
    {
     qts << " q-callback :mark-async (";
    }
    qts << " function (cl::lambda (" << merged_lambda_channel << ')';
   }
   else
   {
    if(fdi_.flags.has_preceding)
    {
     if(fdi_.flags.async)
     {
      //?
      //qts << " q-callback :mark-async (";
      qts << "\n :|@" << label << "|  (function (cl::lambda (" << merged_lambda_channel << ')';

     }
     else
     {
      qts << "\n :|" << label << "|  (function (cl::lambda (" << merged_lambda_channel << ')';
     }
    }
    else
    {
     if(fdi_.flags.async)
     {
      //?
      //qts << " q-callback :mark-async (";
      qts << "q-callback :make-do-map :|@" << label << "|  (function (cl::lambda (" << merged_lambda_channel << ')';
       // //  do-map close paren handled by expr close?
      make_do_map_close = "\n) ;do-map;\n";
     }
     else
     {
       // //  do-map close paren handled by expr close?
      qts << "q-callback :make-do-map :|" << label << "|  (function (cl::lambda (" << merged_lambda_channel << ')';
      make_do_map_close = "\n) ;do-map;\n";

     }
    }
   }
  }
  else
  {
//   cqr::cqr-defn \"" << function_name_.toUpper()
//?   qts << "q-defun " << function_name_
//?      << "  (function (cl::lambda (" << merged_lambda_channel << ')';


   qts << "core::q-callback :defun  \"" << function_name_.toUpper()
      << "\"  (function (cl::lambda (" << merged_lambda_channel << ')';


//?   qMessageBox

//   qts << "defun " << function_name_
//      << " (" << merged_lambda_channel << ')';
  }
 }
 if(fdi_.flags.no_def)
 {
  if(cpp_code_gen_)
  {
   qts << ";\n";
  }
 }
 else if(block_)
 {
  if(cpp_code_gen_)
  {
   qts << "\n{";
  }
  block_->write(qts, indentation);
  if(cpp_code_gen_)
  {
   qts << "\n}";
  }
  qts << "\n";
 }
 else
 {
  //? qts << ";\n";
 }

 if(cpp_code_gen_)
 {
  qts << "\n//fdef";
 }
 else
 {
  if(setf_lambda)
  {
   qts << ";lex/lambda;\n)";
  }
  else if(class_lambda)
  {
   qts << ";method/lambda;\n)";
  }
  else if(do_lambda)
  {
   if(!label.isEmpty())
   {
    qts << ") ;labeled-fn;\n";
   }
   else if(fdi_.flags.async)
    qts << ") ;mark-async;\n";

   // //? no need to close parens: the enclosing
    // expression will do so?
    //   Correction: if we start with  function (cl::lambda
    //   need one paren for the "function"
   qts << ") ;do/lambda;\n";

   //?qts << make_do_map_close;

   //?qts << ";do/lambda;\n";
  }
  else
  {
   //?qts << ";defun;\n";

   qts << " )) ;function/cl::lambda;"; // (function (cl::lambda
  }
 }

 if(do_map_sequence_ref_)
 {
  do_map_sequence_ref_->write(qts, indentation);
 }

 qts << make_do_map_close;

 //?qts << ')';
 //write_children();

}




