
#ifndef RZ_CLASP_SOURCE_FUNDEF__H
#define RZ_CLASP_SOURCE_FUNDEF__H

#include "accessors.h"
#include "flags.h"

#include "rz-clasp-source-element.h"

#include "rz-code-generators/rz-function-def-syntax.h"

#include <QString>
#include <QTextStream>
#include <QMap>
#include <QList>

#include <functional>

#include "rzns.h"


RZNS_(GVal)

class RZ_Function_Def_Info;

_RZNS(GVal)

USING_RZNS(GVal)


RZNS_(RZClasp)

class RZ_Clasp_Source_Block;

class RZ_Clasp_Source_Fundef : public RZ_Clasp_Source_Element
{
 QString function_name_;
 RZ_Function_Def_Info& fdi_;

 static const RZ_Function_Def_Syntax& function_def_syntax();
 static const RZ_Function_Def_Syntax& cpp_function_def_syntax();


 caon_ptr<RZ_Clasp_Source_Block> block_;

 caon_ptr<RZ_Clasp_Source_Fundef> do_map_sequence_ref_;

 // //  maybe just for debug?
 int do_map_sequence_order_;

 QString label_;

public:

 RZ_Clasp_Source_Fundef(caon_ptr<RZ_Clasp_Cpp_Code_Generator> cpp_code_gen_,
   caon_ptr<RZ_Clasp_Source_Element> parent_element,
   QString function_name, RZ_Function_Def_Info &fdi);

 ACCESSORS(caon_ptr<RZ_Clasp_Source_Block> ,block)
 ACCESSORS(QString ,function_name)
 ACCESSORS(caon_ptr<RZ_Clasp_Source_Fundef> ,do_map_sequence_ref)
 ACCESSORS(int ,do_map_sequence_order)

 void set_label(QString label) override;

 QString label();

 QString source_element_cpp_type() override;

 void write(QTextStream& qts, int indentation) override;

 void debug_inspect() override;

//?
// void write_with_possible_do_map_sequence
//   (QTextStream& qts, int indentation, caon_ptr<RZ_Clasp_Source_Fundef> prior);

 caon_ptr<RZ_Clasp_Source_Element> add_as_child(caon_ptr<RZ_Clasp_Source_Element> se) override;

 bool is_do_lambda();

};

_RZNS(RZClasp)

#endif
