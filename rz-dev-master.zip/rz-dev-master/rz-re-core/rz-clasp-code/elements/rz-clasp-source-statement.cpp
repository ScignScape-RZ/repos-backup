
#include "rz-clasp-source-statement.h"

#include "rz-clasp-source-fundef.h"

#include <QDebug>

#define SCC caon_static_cast<RZ_Clasp_Source_Element>()

USING_RZNS(RZClasp)

RZ_Clasp_Source_Statement::RZ_Clasp_Source_Statement(caon_ptr<RZ_Clasp_Cpp_Code_Generator> cpp_code_gen,
  caon_ptr<RZ_Clasp_Source_Element> parent_element)
 : RZ_Clasp_Source_Element(cpp_code_gen, parent_element),
   expression_count_(0), current_expression_count_(0), first_nested_block_(nullptr)
{

}

void RZ_Clasp_Source_Statement::write(QTextStream& qts, int indentation)
{
 status_ = "write...";

 write_indentation(qts, indentation);
 //?qts << '(';

 if(flags.has_setup_retval)
 {
  if(cpp_code_gen_)
  {
   // //  anything to do here?
  }
  else
  {
   qts << "\n (q-callback :hold-retval \n";
  }

 }

 if(!label_.isEmpty())
 {
  if(!previous_label_.isEmpty())
  {
   if(cpp_code_gen_)
   {
    qts << " \n //" << previous_label_ << " \n";
    write_indentation(qts, indentation);
   }
   else
   {
    qts << " \n ;" << previous_label_ << ";\n";
    write_indentation(qts, indentation);
    qts << ") ";
   }
  }
  //(function (cl::lambda ()
  qts << label_ << " (lambda ()";
 }

 write_code_output(qts);
 write_children(qts, indentation);
 write_postcode_output(qts);

 write_type_declarations(qts, indentation);

 write_post_raw_lisp(qts);

 if(flags.has_setup_retval)
 {
  if(cpp_code_gen_)
  {
   // //  anything to do here?
  }
  else
  {
   qts << "\n ) ;hold-retval; \n";
  }
 }

//?
// if(!first_nested_block_)
// {
//  if(!code_output_.isEmpty() || child_count() > 0)
//   ;//?qts << ")\n";
// }
}

void RZ_Clasp_Source_Statement::add_element(caon_ptr<RZ_Clasp_Source_Element> el)
{
 CAON_PTR_DEBUG(RZ_Clasp_Source_Element ,el)
 child_elements_.push_back(el);
}

void RZ_Clasp_Source_Statement::add_fundef(caon_ptr<RZ_Clasp_Source_Fundef> el)
{
 CAON_PTR_DEBUG(RZ_Clasp_Source_Fundef ,el)
 child_elements_.push_back(el.SCC);
 first_nested_fundef_ = el;
}

void RZ_Clasp_Source_Statement::add_statement(caon_ptr<RZ_Clasp_Source_Statement> st)
{
 add_element(st.SCC);
}


void RZ_Clasp_Source_Statement::prepare_expression_entry(QString prefix)
{
 if(flags.if_elsif)
 {
  if(flags.if_elsif_entry)
  {
   if(cpp_code_gen_)
   {
    //  before this had "else if" but that's probably wrong.
    code_output_ += "if " + prefix;
   }
   else
   {
    code_output_ += prefix + "(( ;if-clause:  \n";
   }
   flags.if_elsif_entry = false;
  }
 }
 else if(flags.fieldef)
 {
  code_output_ += prefix;
 }
 else if(cpp_code_gen_)
 {
  code_output_ += prefix;
 }
 else
 {
  code_output_ += prefix + '(';
 }
 expression_stack_.push(expression_count_);
 current_expression_count_ = expression_count_;
 ++expression_count_;
}

void RZ_Clasp_Source_Statement::unwind_expression_leave()
{
// prepare_expression_leave();

 while(!expression_stack_.isEmpty())
 {
  int top = expression_stack_.top();
  prepare_expression_leave();
 }
}

void RZ_Clasp_Source_Statement::register_call_entry_label(QString label, QString previous_label)
{
 label_ = label;
 previous_label_ = previous_label;
}

void RZ_Clasp_Source_Statement::prepare_statement_leave_after_block_map()
{
 if(cpp_code_gen_)
 {
  postcode_output_ += "; // statement\n";
 }
 else
 {
  postcode_output_ += ";statement;\n";
  postcode_output_ += ')';
  postcode_output_ += '\n';
 }
}

void RZ_Clasp_Source_Statement::debug_inspect()
{
 for(caon_ptr<RZ_Clasp_Source_Element> el : child_elements_)
 {
  CAON_PTR_DEBUG(RZ_Clasp_Source_Element ,el)
  QString elt = el->source_element_cpp_type();
  el->debug_inspect();
 }
}

QString RZ_Clasp_Source_Statement::source_element_cpp_type()
{
 return "RZ_Clasp_Source_Statement";
}


void RZ_Clasp_Source_Statement::prepare_expression_leave()
{
 if(expression_stack_.isEmpty())
 {
  // maybe an unwind_expression_leave already handled everything...
  return;
 }
 current_expression_count_ = expression_stack_.pop();
 if(current_expression_count_ == 0)
 {
  if(cpp_code_gen_)
  {
   postcode_output_ += "; // statement\n";
  }
  else
  {
   postcode_output_ += ";statement;\n";
   postcode_output_ += ')';
   postcode_output_ += '\n';
  }
 }
 else if(first_nested_block_)
 {
  if(cpp_code_gen_)
  {
   postcode_output_ += "; // expr\n";
  }
  else
  {
   postcode_output_ += ";expr;\n";
   postcode_output_ += ')';
   postcode_output_ += '\n';
  }
 }
 else if(first_nested_fundef_)
 {
  CAON_PTR_DEBUG(RZ_Clasp_Source_Fundef ,first_nested_fundef_)
  CAON_PTR_DEBUG(RZ_Clasp_Source_Block ,first_nested_block_)

  QString label = first_nested_fundef_->label();

  if(!label.isEmpty())
  {
   if(cpp_code_gen_)
   {
    postcode_output_ += "; // expr -- first was " + label + "\n";
   }
   else
   {
    postcode_output_ += ";do map; -- first was " + label + "\n";
    postcode_output_ += '\n';
   }
  }
//  if(caon_ptr<RECore::RE_Function_Def_Entry> rfde = first_nested_fundef_->function_def_entry())
//  {
//  }
  //   CAON_PTR_DEBUG(RECore::RE_Function_Def_Entry ,rfde)
  //   if(caon_ptr<RECore::RE_Node> ln = rfde->label_node())
  //   {
  //    CAON_PTR_DEBUG(RECore::RE_Node ,ln)
  //      // // no need to close expression
  //    postcode_output_ += ";expr; = " + ln->raw_text() + "\n";


  //   }

  else
  {
   if(cpp_code_gen_)
   {
    postcode_output_ += "; // expr\n";
   }
   else
   {
    postcode_output_ += ";expr;\n";
    postcode_output_ += ')';
    postcode_output_ += '\n';
   }
  }
 }
 else
 {
  if(cpp_code_gen_)
  {
   postcode_output_ += "; // expr\n";
  }
  else
  {
   code_output_ += ";expr;\n";
   code_output_ += ')';
   code_output_ += '\n';
  }

//?
//  code_output_ += ";expr;\n";
//  code_output_ += ')';
//  code_output_ += '\n';
 }
// while(current_expression_count_ > 0)
// {
//  --current_expression_count_;
//  if(current_expression_count_ > 0)
//   postcode_output_ += ')';
//  else
//   postcode_output_ += " ;added:statement;\n)";
// }
}

void RZ_Clasp_Source_Statement::prepare_expression_continue()
{
 code_output_ += " ";
}

void RZ_Clasp_Source_Statement::hold_infix_token(QString str)
{
 if(cpp_code_gen_)
 {
  held_infix_tokens_[current_expression_count_] = str;
 }
 else
 {
  // For clasp, don't bother with held tokens usually...
  add_token(str);
 }
}

void RZ_Clasp_Source_Statement::check_held_infix_token(QString follow)
{
 if(held_infix_tokens_.contains(current_expression_count_))
 {
  code_output_ += held_infix_tokens_.take(current_expression_count_) + follow;
 }
}

void RZ_Clasp_Source_Statement::add_raw_lisp(QString lisp, RZ_Clasp_Code_Lisp_Paste_Modes mode)
{
 switch(mode)
 {
 case RZ_Clasp_Code_Lisp_Paste_Modes::Immediate:
  code_output_ += lisp;
  break;

 case RZ_Clasp_Code_Lisp_Paste_Modes::Follow:
  post_raw_lisp_ += lisp;
  break;

 }

}


void RZ_Clasp_Source_Statement::add_token(QString str)
{
 this->RZ_Clasp_Source_Element::add_token(str);

 if(cpp_code_gen_)
  check_held_infix_token(" ");
}


void RZ_Clasp_Source_Statement::add_car_token(QString str)
{
 this->RZ_Clasp_Source_Element::add_car_token(str);
 //? check_held_infix_token(" ");
}

void RZ_Clasp_Source_Statement::add_nested_block(caon_ptr<RZ_Clasp_Source_Block> sb)
{
 add_element(sb.SCC);
 if(!first_nested_block_)
  first_nested_block_ = sb;
}
