
#ifndef RZ_CLASP_SOURCE_STATEMENT__H
#define RZ_CLASP_SOURCE_STATEMENT__H

#include "accessors.h"
#include "flags.h"

#include "rz-clasp-source-element.h"

#include <QString>
#include <QTextStream>
#include <QMap>
#include <QList>
#include <QStack>

#include <functional>

#include "rzns.h"


RZNS_(RZClasp)

class RZ_Clasp_Source_Fundef;
class RZ_Clasp_Source_Block;

class RZ_Clasp_Source_Statement : public RZ_Clasp_Source_Element
{
 //QStack<QString> held_infix_token_;
 int expression_count_;
 int current_expression_count_;
 QStack<int> expression_stack_;
 QMap<int, QString> held_infix_tokens_;

protected:

 caon_ptr<RZ_Clasp_Source_Block> first_nested_block_;
 caon_ptr<RZ_Clasp_Source_Fundef> first_nested_fundef_;

 QString label_;
 QString previous_label_;

 // // temp ...
 QString status_;

public:

 RZ_Clasp_Source_Statement(caon_ptr<RZ_Clasp_Cpp_Code_Generator> cpp_code_gen,
   caon_ptr<RZ_Clasp_Source_Element> parent_element);

 void write(QTextStream& qts, int indentation);
 void add_element(caon_ptr<RZ_Clasp_Source_Element> el) override;
 void add_fundef(caon_ptr<RZ_Clasp_Source_Fundef> el) override;
 void prepare_expression_entry(QString prefix) override;
 void prepare_expression_leave() override;
 void unwind_expression_leave() override;
 void hold_infix_token(QString str) override;
 void check_held_infix_token(QString follow);
 void add_token(QString str) override;
 void add_car_token(QString str) override;
 void add_nested_block(caon_ptr<RZ_Clasp_Source_Block> sb) override;
 void add_statement(caon_ptr<RZ_Clasp_Source_Statement> st) override;
 void prepare_expression_continue() override;
 void register_call_entry_label(QString label, QString previous_label) override;

 void prepare_statement_leave_after_block_map() override;

 void debug_inspect() override;

 void add_raw_lisp(QString lisp, RZ_Clasp_Code_Lisp_Paste_Modes mode) override;

 QString source_element_cpp_type() override;

};

_RZNS(RZClasp)

#endif
