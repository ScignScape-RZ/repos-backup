
#ifndef RZ_CLASP_CODE_BLOCK_KINDS__H
#define RZ_CLASP_CODE_BLOCK_KINDS__H

#include "rzns.h"


RZNS_(RZClasp)


enum class RZ_Clasp_Code_Block_Kinds
{
 N_A, If_Block, Else_Block, Elsif_Block,
   Fundef_Block, File_Block, Generic_Block, Scan_Block //?Do_Block,
};

_RZNS(RZClasp)

#endif
