
#include "rz-clasp-code-generator.h"

#include "rz-clasp-cpp-code-generator.h"

#include "elements/rz-clasp-source-file.h"
#include "elements/rz-clasp-source-fundef.h"
#include "elements/rz-clasp-source-classdef.h"
#include "elements/rz-clasp-source-fundef-block.h"
#include "elements/rz-clasp-source-file-entry.h"
#include "elements/rz-clasp-source-statement.h"

#include "rz-code-generators/rz-function-def-info.h"

#include "rz-clasp-project/code/rz-clasp-code-block.h"

#include "rz-graph-run/token/rz-graph-run-token.h"
//#include "rz-generator-sre/rz-generator-sre.h"

#include "rz-graph-sre/rz-sre-token.h"

//#include "rz-graph-valuer/vector/rz-string-plex.h"

#include "elements/rz-clasp-source-block.h"

#include <QDebug>
#include <QRegularExpression>
#include <QRegularExpressionMatch>

USING_RZNS(RZClasp)


#define SCC caon_static_cast<RZ_Clasp_Source_Element>()


RZ_Clasp_Code_Generator::RZ_Clasp_Code_Generator()
 : source_file_(new RZ_Clasp_Source_File(nullptr)) //: file_(file)
  ,current_element_(source_file_.caon_static_cast<RZ_Clasp_Source_Element>())
  ,root_element_(source_file_.SCC), current_indentation_(0)
  ,current_block_(nullptr), cpp_code_gen_(nullptr)
{
}

void RZ_Clasp_Code_Generator::init_cpp_code_generation()
{
 cpp_code_gen_ = new RZ_Clasp_Cpp_Code_Generator(this);
 source_file_->set_cpp_code_gen(cpp_code_gen_);
}

void RZ_Clasp_Code_Generator::write(QTextStream& qts)
{
 qts << initial_output_text_;

 root_element_->write(qts, 0);
 //qts << "ok";
}

void RZ_Clasp_Code_Generator::setup_retval()
{
 if(cpp_code_gen_)
 {
  // //  anything to do here?
 }
 else
 {
  current_element_->setup_retval();
 }
}



void RZ_Clasp_Code_Generator::add_initial_cpp_output_text(QString text)
{
 if(cpp_code_gen_)
  cpp_code_gen_->add_initial_cpp_output_text(text);
}

void RZ_Clasp_Code_Generator::add_logical_function_def(caon_ptr<RZ_Clasp_Source_Fundef> fd)
{
 current_element_->add_element(fd.SCC);
}

void RZ_Clasp_Code_Generator::add_source_element(caon_ptr<RZ_Clasp_Source_Element> se)
{
 CAON_PTR_DEBUG(RZ_Clasp_Source_Element, current_element_)
 CAON_PTR_DEBUG(RZ_Clasp_Source_Element, se)
 caon_ptr<RZ_Clasp_Source_Element> new_ce = se->add_as_child(current_element_);

 if(caon_ptr<RZ_Clasp_Source_Element> parent = new_ce->parent_element())
 {
  //
  CAON_PTR_DEBUG(RZ_Clasp_Source_Element, parent)
  qDebug() << "Unexpected parent!";
 }
 else if(new_ce)
 {
  new_ce->set_parent_element(current_element_);
 }

 if(new_ce)
 {
  current_element_ = new_ce;
  new_ce->check_as_block(current_block_);
 }
 //add_element(current_element_, se.raw_pointer());
 //current_element_ = se;
}


//void RZ_Clasp_Code_Generator::add_element(caon_ptr<RZ_Clasp_Source_Element> cse, RZ_Clasp_Source_Fundef* sf)
//{
// if(cse->child_count() == 0)
// {

// }
// else
// {
//  cse->add_element(sf);
// }
//}

//void RZ_Clasp_Code_Generator::add_element(caon_ptr<RZ_Clasp_Source_Element> cse, RZ_Clasp_Source_Element* se)
//{
// //CAON_PTR_DEBUG(RZ_Clasp_Source_Element, se)
// cse->add_element(se);
//}


caon_ptr<RZ_Clasp_Source_Element>
 RZ_Clasp_Code_Generator::enter_class_definition(QString scope_kind_name, QString name)
{
 CAON_PTR_DEBUG(RZ_Clasp_Source_Element ,current_element_)

 //?caon_ptr<RZ_Clasp_Source_Element> parent = (fdi.flags.lexical_lambda || fdi.flags.logical_lambda)?
 //?   nullptr : current_element_;

 caon_ptr<RZ_Clasp_Source_Element> parent = nullptr;

 caon_ptr<RZ_Clasp_Source_Classdef> parent_class_def = source_file_->current_classdef();

 CAON_PTR_DEBUG(RZ_Clasp_Source_Classdef ,parent_class_def)


 caon_ptr<RZ_Clasp_Source_Classdef> cdf =
   new RZ_Clasp_Source_Classdef(cpp_code_gen_, parent, parent_class_def, scope_kind_name, name);

 source_file_->set_current_classdef(cdf);


 CAON_PTR_DEBUG(RZ_Clasp_Source_Classdef ,cdf)

 return cdf.SCC;
}

void RZ_Clasp_Code_Generator::reset_classdef_to_parent()
{
 caon_ptr<RZ_Clasp_Source_Classdef> parent_class_def = source_file_->current_classdef();
 CAON_PTR_DEBUG(RZ_Clasp_Source_Classdef ,parent_class_def)
 source_file_->set_current_classdef(parent_class_def);
}

void RZ_Clasp_Code_Generator::link_source_fundef_to_ref(caon_ptr<RZ_Clasp_Source_Element> lhs, caon_ptr<RZ_Clasp_Source_Element> rhs)
{
 caon_ptr<RZ_Clasp_Source_Fundef> lf = lhs.caon_static_cast<RZ_Clasp_Source_Fundef>();
 caon_ptr<RZ_Clasp_Source_Fundef> rf = rhs.caon_static_cast<RZ_Clasp_Source_Fundef>();
 if(lf)
 {
  CAON_PTR_DEBUG(RZ_Clasp_Source_Fundef ,lf)
  CAON_PTR_DEBUG(RZ_Clasp_Source_Fundef ,rf)
  lf->set_do_map_sequence_ref(rf);
  rf->set_do_map_sequence_order(lf->do_map_sequence_order() + 1);
 }

}


caon_ptr<RZ_Clasp_Source_Element>
 RZ_Clasp_Code_Generator::new_logical_function_def(QString name, RZ_Function_Def_Info& fdi, QString label)
{
 root_element_->debug_inspect();

 CAON_PTR_DEBUG(RZ_Clasp_Source_Element ,current_element_)

 //?caon_ptr<RZ_Clasp_Source_Element> parent = (fdi.flags.lexical_lambda || fdi.flags.logical_lambda)?
 //?   nullptr : current_element_;

 caon_ptr<RZ_Clasp_Source_Element> parent = nullptr;

 caon_ptr<RZ_Clasp_Source_Fundef> fd = new RZ_Clasp_Source_Fundef(cpp_code_gen_, parent, name, fdi);

 fd->set_label(label);

 if(fdi.flags.no_impl)
 {
  //current_element_ = fd.SCC;
 }
 else
 {
  caon_ptr<RZ_Clasp_Source_Block> fdb = new RZ_Clasp_Source_Block(
    cpp_code_gen_, parent, current_block_, nullptr, RZ_Clasp_Code_Block_Kinds::Fundef_Block, fd);
  fd->set_block(fdb);
  //current_element_ = fdb.SCC;
 }
 return fd.SCC;
}

void RZ_Clasp_Code_Generator::add_raw_lisp(QString lisp, RZ_Clasp_Code_Lisp_Paste_Modes mode)
{
 current_element_->add_raw_lisp(lisp, mode);
}

caon_ptr<RZ_Clasp_Source_Element>
 RZ_Clasp_Code_Generator::add_file_entry()
{
 caon_ptr<RZ_Clasp_Source_File_Entry> sfe = new RZ_Clasp_Source_File_Entry(cpp_code_gen_);
 //  if(cpp_code_gen_)
 //  sfe->set_cpp_code_gen(cpp_code_gen_);

 //? caon_ptr<RZ_Clasp_Source_Element> rce = sfe.caon_static_cast<RZ_Clasp_Source_Element>();
 //? caon_ptr<RZ_Clasp_Source_Element> rce1 = new RZ_Clasp_Source_Element(nullptr);

 //?current_element_->add_element(rce1); //?sfe.caon_static_cast<RZ_Clasp_Source_Element>() );

 //qDebug() << "XXX";

 current_element_->add_element(sfe.SCC);
 return sfe.SCC;
                               //?SCC);
}

void RZ_Clasp_Code_Generator::register_call_entry_label(QString label)
{
 CAON_PTR_DEBUG(RZ_Clasp_Source_Block ,current_block_)
 if(current_block_->block_kind() == RZ_Clasp_Code_Block_Kinds::Scan_Block)
 {
  QString old_label = current_block_->switch_current_labels(label);
  //?current_block_->register_call_entry_label(label, current_element_);
  current_element_->register_call_entry_label(label, old_label);
  //?current_element_->register_call_entry_label(label);
 }
 else
 {
  current_element_->register_call_entry_label(label, QString());
 }
}


void RZ_Clasp_Code_Generator::prepare_statement_entry()
{
 CAON_PTR_DEBUG(RZ_Clasp_Source_Element, current_element_)
 caon_ptr<RZ_Clasp_Source_Element> stel = current_element_->new_nested_statement();

 if(stel)
 {
  current_element_ = stel;
  stel->prepare_expression_entry("");
 }
 else
 {
  caon_ptr<RZ_Clasp_Source_Statement> st = new RZ_Clasp_Source_Statement(cpp_code_gen_, current_element_);
  CAON_PTR_DEBUG(RZ_Clasp_Source_Element, current_element_)
  current_element_->add_statement(st);
  current_element_ = st.SCC;
  st->prepare_expression_entry("");
 }
}

void RZ_Clasp_Code_Generator::end_statement()
{
 CAON_PTR_DEBUG(RZ_Clasp_Source_Element, current_element_)
 caon_ptr<RZ_Clasp_Source_Element> ces = current_element_->check_end_statement();
 if(ces)
 {
  return;
 }
 else
 {
  current_element_ = current_element_->parent_element();
  if(current_element_)
  {
   CAON_PTR_DEBUG(RZ_Clasp_Source_Element, current_element_)
   if(current_element_->flags.scope_close)
   {
    caon_ptr<RZ_Clasp_Source_Element> parent = current_element_->parent_element();
    CAON_PTR_DEBUG(RZ_Clasp_Source_Element ,parent)
    current_element_ = parent;
   }
  }
 }
}

void RZ_Clasp_Code_Generator::prepare_expression_entry(QString prefix)
{
 current_element_->prepare_expression_entry(prefix);
}

void RZ_Clasp_Code_Generator::prepare_statement_leave_after_block_map()
{
 current_element_->prepare_statement_leave_after_block_map();

 //?
 current_element_ = current_element_->parent_element();
}

void RZ_Clasp_Code_Generator::prepare_expression_leave()
{
 current_element_->prepare_expression_leave();
}

void RZ_Clasp_Code_Generator::nested_block_rewind_prepare_continue()
{
 // // bypassing the nested statement leave?
 current_element_->add_postcode("\n) ;statement -- nested block\n");


 CAON_PTR_DEBUG(RZ_Clasp_Source_Element ,current_element_)
 CAON_PTR_DEBUG(RZ_Clasp_Source_Block ,current_block_)

 if(current_block_)
 {
  if(caon_ptr<RZ_Clasp_Source_Block> psb =  current_block_->parent_block())
  {
   CAON_PTR_DEBUG(RZ_Clasp_Source_Block ,psb)
   if(caon_ptr<RZ_Clasp_Code_Block> pcb = psb->code_block())
   {
    CAON_PTR_DEBUG(RZ_Clasp_Code_Block ,pcb)
    caon_ptr<RE_Node> cbn = pcb->block_entry_node();
    CAON_PTR_DEBUG(RE_Node ,cbn)
    current_block_ = psb;
    CAON_DEBUG_NOOP
   }
  }
  //if(caon_ptr<RE_Node> ben = current_block_->block)

 }

 //? ?!?
 current_element_ = current_block_.caon_static_cast<RZ_Clasp_Source_Element>();

 CAON_DEBUG_NOOP
}

void RZ_Clasp_Code_Generator::prepare_block_map_continue()
{
 caon_ptr<RZ_Clasp_Source_Block> sb = current_element_->prepare_block_map_continue();
 if(sb)
 {
  current_element_ = sb.SCC;
  current_block_ = sb;
 }
}

void RZ_Clasp_Code_Generator::unwind_expression_leave()
{
 current_element_->unwind_expression_leave();
}

void RZ_Clasp_Code_Generator::prepare_expression_continue()
{
 current_element_->prepare_expression_continue();
}


void RZ_Clasp_Code_Generator::block_leave()
{
 CAON_PTR_DEBUG(RZ_Clasp_Source_Element, current_element_)
 CAON_DEBUG_NOOP
}


caon_ptr<RZ_Clasp_Source_Fundef>
 RZ_Clasp_Code_Generator::nested_block_leave(RZ_Clasp_Code_Block_Kinds& block_kind)
{
 // //  Otherwise this is top-level?
 CAON_PTR_DEBUG(RZ_Clasp_Source_Element, current_element_)
 CAON_PTR_DEBUG(RZ_Clasp_Source_Block, current_block_)

 caon_ptr<RZ_Clasp_Source_Fundef> result = nullptr;

 if(!current_element_)
  return nullptr;

 current_element_->get_block_kind(block_kind);

 if(current_block_)
 {
  result = current_block_->fundef();

  int unwind_count = 0;
  current_element_ = current_block_->find_parent_unwind(unwind_count);
  current_indentation_ -= unwind_count;
//  switch(current_block_->block_kind())
//  {

//  }
//  current_element_ = current_block_->parent_element();
//  --current_indentation_;
  CAON_PTR_DEBUG(RZ_Clasp_Source_Element, current_element_)

  if(current_element_)
  {
   current_element_->find_parent_block(current_block_);
   if(caon_ptr<RZ_Clasp_Source_Element> parent = current_element_->parent_element())
   {
    CAON_PTR_DEBUG(RZ_Clasp_Source_Element ,parent)
    CAON_DEBUG_NOOP
   }
  }
  CAON_DEBUG_NOOP
 }

 return result;
 //caon_ptr<RZ_Clasp_Source_Block> sb = new RZ_Clasp_Source_Block(current_element_, block_kind);
}

void RZ_Clasp_Code_Generator::nested_block_pre_entry(caon_ptr<RZ_Clasp_Code_Block> block, RZ_Clasp_Code_Block_Kinds block_kind)
{
 CAON_PTR_DEBUG(RZ_Clasp_Source_Element, current_element_)
 CAON_PTR_DEBUG(RZ_Clasp_Source_Block, current_block_)

   // perhaps caon_ptr need to overload !=
// if(current_element_.raw_pointer() != current_block_.raw_pointer())
// {
//  // some sort of block rewind?
//  //?qDebug() << "Check Rewind ...";

//  current_element_ = current_block_.caon_static_cast<RZ_Clasp_Source_Element>();

// }

 //?
 //
 caon_ptr<RZ_Clasp_Source_Block> sb = new RZ_Clasp_Source_Block(cpp_code_gen_, current_element_, current_block_, block, block_kind);
 //?
 //caon_ptr<RZ_Clasp_Source_Block> sb = new RZ_Clasp_Source_Block(cpp_code_gen_, current_block_.caon_static_cast<RZ_Clasp_Source_Element>(), block_kind);

 QString co = current_element_->code_output();

 sb->set_text_hint(current_element_->code_output());

 current_element_->add_nested_block(sb);
 current_element_ = sb.SCC;
 current_block_ = sb;
 ++current_indentation_;
 current_element_->set_indentation(current_indentation_);
 current_element_->add_precode("\n");

 //? block_pre_entry();
}

void RZ_Clasp_Code_Generator::check_nested_block_pre_entry(caon_ptr<RZ_Clasp_Code_Block> block, RZ_Clasp_Code_Block_Kinds block_kind)
{
 CAON_PTR_DEBUG(RZ_Clasp_Source_Element, current_element_)

  //?root_element_->debug_inspect();

 switch(block_kind)
 {
 //?case RZ_Clasp_Code_Block_Kinds::Do_Block:
 case RZ_Clasp_Code_Block_Kinds::Fundef_Block:
  //? case RZ_Clasp_Code_Block_Kinds::If_Block:
   // //  Blocks should already be entered ...
  ++current_indentation_;
  current_element_->set_indentation(current_indentation_);
  current_element_->add_precode("\n");
  return;

 default:
  nested_block_pre_entry(block, block_kind);
 }
}



void RZ_Clasp_Code_Generator::function_expression_entry(
  //RZ_Graph_Run_Token& rzt, RZ_SRE_Token& sre_token,
  QString cpp_string_value)
{
 QString function_name = current_element_->check_function_rename(cpp_string_value);

 if(cpp_string_value == "do")
 {
  qDebug() << "error?...";
 }

 if(function_name.isEmpty())
 {
  function_name = cpp_string_value;
  check_function_rename(function_name);
 }

  //?root_element_->debug_inspect();
 current_element_->add_car_token(function_name);

 if(function_name == ";;;;")
 {
  if(caon_ptr<RZ_Clasp_Source_Classdef> cdef = source_file_->current_classdef())
  {
   caon_ptr<RZ_Clasp_Source_Classdef> parent_cdef = cdef->parent_classdef();

   CAON_PTR_DEBUG(RZ_Clasp_Source_Classdef ,parent_cdef)

   source_file_->set_current_classdef(parent_cdef);

   if(parent_cdef)
    current_element_ = parent_cdef.SCC;

  }

 }


 //? root_element_->debug_inspect();
}


void RZ_Clasp_Code_Generator::function_expression_entry_infix(
  QString cpp_string_value)
{
 check_function_rename(cpp_string_value);
 current_element_->hold_infix_token(cpp_string_value);
}

void RZ_Clasp_Code_Generator::check_type_rename(QString& sv)
{
 if(cpp_code_gen_)
 {
  //?cpp_code_gen_->check_type_rename(sv);
  return;
 }
 static QMap<QString, QString> static_map {{
   { "int", "fixnum" },
   { "dbl", "bignum" },
  }};
 if(static_map.contains(sv))
 {
  sv = static_map[sv];
 }
}

void RZ_Clasp_Code_Generator::check_token_rename(QString& sv)
{
 if(cpp_code_gen_)
 {
  cpp_code_gen_->check_token_rename(sv);
  return;
 }
 static QMap<QString, QString> static_map {{
  { "..do..", "do" },
  { "/do/", "do" },
 }};
 if(static_map.contains(sv))
 {
  sv = static_map[sv];
 }
 else if(sv.startsWith(';') && sv.endsWith(';') && (sv.size() > 1))
 {
  sv.clear();
 }
 else
 {
  check_token_expansion(sv);
 }
}

void RZ_Clasp_Code_Generator::check_token_expansion(QString& sv)
{
 // //  Currently this converts tokens to forms in any
  //    (non call-entry) context; consider whether to
  //    support more precise matches (e.g. after setf...)
 QRegularExpression rx("^(?<ns>[^:]+):(?<rest>\\S+)");
 QRegularExpressionMatch match = rx.match(sv);
 if(match.hasMatch())
 {
  QString ns = match.captured("ns");
  QString rest = match.captured("rest");
  if(rest.contains("\\/"))
  {
   QString result = QString("(");
   QString held;
   QStringList parts = rest.split("\\/");
   int count = 0;
   for(QString p : parts)
   {
    switch(count)
    {
    case 0: held = p; break;
    case 1: result += ns + ':' + p + ' ' + ns + ':' + held; break;
    default: result += ' ' + p;
    }
    ++count;
   }
   result += ')';
   sv = result;
  }
 }
 else if(sv.contains("\\/"))
 {
  QString result = QString("(");
  QString held;
  QStringList parts = sv.split("\\/");
  int count = 0;
  for(QString p : parts)
  {
   switch(count)
   {
    case 0: held = p; break;
    case 1: result += "slot-value " + held + " '" + p; break;
    default:
     result.prepend("(slot-value ");
     result.append(") '");
     result.append(p);
     break;
   }
   ++count;
  }
  result += ')';
  sv = result;
 }
}

void RZ_Clasp_Code_Generator::check_function_rename(QString& sv)
{
 if(cpp_code_gen_)
 {
  cpp_code_gen_->check_function_rename(sv);
  return;
 }
 static QMap<QString, QString> static_map {{
  { "=?", "eql" },
  { "my", "setf" },
  { "our", "setf" },
  { "their", "setf" },
  { "===", "setf" },
  { "=", "setf" },
  { "?", "identity" },
  { "vide", "identity" },
  { "ival", "identity" },
  { "iden", "identity" },
  { "ret", "identity" },
  { "call", "" },
  { "$", "slot-value" },
  { "do", "progn" },
  { "-!", "null" },
  { "-?", "identity" },
  { "if-", "if" },

  { "pr", "format t" },
  { "prf", "format nil" },

  { "retval", "identity" },
  { "nothing", "values" },

 }};
 if(static_map.contains(sv))
 {
  sv = static_map[sv];

  //? Temporary
  if(sv == "setf")
   sv = "setq";

 }
 else if(sv.startsWith(">-"))
 {
  if(sv.endsWith("->"))
  {
   if(sv.length() == 4)
   {
    sv = "q-callback :static-invoke-sigma";
     //??? sv = "q-callback :invoke";
   }
  }
  else
  {
   sv.replace(0, 2, "q-callback :");
  }
 }
 else if(sv.startsWith('|') and sv.endsWith('|'))
 {

 }
 else if(sv.startsWith('|'))
 {

 }
 else if(sv.endsWith('|'))
 {

 }
 else if(sv == "/->")
 {
  // //  I'm switching these two but does that confuse the >- ... -> costruct?
  sv = "q-callback :invoke";
  //??? sv = "q-callback :static-invoke-sigma";
 }

 // temp
 else if(sv == "qpc")
 {
  sv = "q-callback :print-to-callback (format nil ";
  current_element_->add_postcode("\n);qpr ...");
 }

 else
 {
  sv.replace("||", "::callback :");
 }
}

void RZ_Clasp_Code_Generator::register_block_objects(caon_ptr<RZ_Clasp_Code_Lexmap> rlx)
{
 // current_block_ or current_element_?
 if(current_block_)
 {
  current_block_->set_lexmap(rlx);
 }
}


void RZ_Clasp_Code_Generator::set_current_code_block(caon_ptr<RZ_Clasp_Code_Block> cb, RZ_Clasp_Code_Block_Kinds block_kind)
{
 CAON_PTR_DEBUG(RZ_Clasp_Code_Block ,cb)
 caon_ptr<RZ_Clasp_Source_Block> sb =
   new RZ_Clasp_Source_Block(cpp_code_gen_, current_element_, current_block_, cb, block_kind);
 CAON_PTR_DEBUG(RZ_Clasp_Source_Block ,sb)
 sb->set_block_kind(block_kind);
 current_element_->add_nested_block(sb);
 current_block_ = sb;
}

void RZ_Clasp_Code_Generator::block_pre_entry(caon_ptr<RZ_Clasp_Code_Block> block, RZ_Clasp_Code_Block_Kinds block_kind)
{
 CAON_PTR_DEBUG(RZ_Clasp_Source_Element, current_element_)

 switch(block_kind)
 {
 case RZ_Clasp_Code_Block_Kinds::Elsif_Block:
 case RZ_Clasp_Code_Block_Kinds::Else_Block:
  nested_block_pre_entry(block, block_kind);

  return;

 case RZ_Clasp_Code_Block_Kinds::Fundef_Block:
 case RZ_Clasp_Code_Block_Kinds::If_Block:
  // //  Blocks should already be entered ...
  ++current_indentation_;
  current_element_->set_indentation(current_indentation_);
  current_element_->add_precode("\n");
  return;

 default:
  return;
 }

}


void RZ_Clasp_Code_Generator::add_symbol_with_type(RZ_Graph_Run_Token& rzt, QString type)
{
 QString tps = current_element_->type_indicator_when_preceding_symbol(type);
 current_element_->add_token(tps);
 add_symbol(rzt);
}

void RZ_Clasp_Code_Generator::add_symbol_with_type_pending(RZ_Graph_Run_Token& rzt)
{

}


void RZ_Clasp_Code_Generator::add_symbol(RZ_Graph_Run_Token& rzt)
{
 QString sv = cpp_code_gen_? rzt.cpp_string_value() : rzt.lisp_string_value();

 if(rzt.flags.is_their && rzt.flags.is_cpp_scoped)
 {
  sv.replace("::", ".prototype.");
 }

 if(rzt.flags.is_lex_assignment_entry)
 {
  check_token_rename(sv);

  // possibly handle different assignment symbols...
  if(cpp_code_gen_)
  {
   current_element_->add_assignment_entry_token(sv);
  }
 }
 else if(rzt.flags.is_type_symbol_in_declaration)
 {
  check_type_rename(sv);
  // possibly handle different assignment symbols...
  current_element_->add_type_declaration_token(sv);
 }
 else
 {
  check_token_rename(sv);
  if(sv.endsWith(".."))
  {
   sv.prepend(":|");
   sv.append("|");
  }
  if(rzt.flags.is_untyped_symbol_declaration)
  {
   if(cpp_code_gen_)
   {
    current_element_->add_token("auto");
   }
  }
  current_element_->add_token(sv);
  if(rzt.flags.is_symbol_declaration)
  {
   current_element_->add_type_declaration_symbol(sv);
  }
 }
}

void RZ_Clasp_Code_Generator::add_string_literal(RZ_Graph_Run_Token& rzt)
{
 QString sv = rzt.string_value();
 QString tok = QString("\"%1\"").arg(sv);
 current_element_->add_token(tok);
}

void RZ_Clasp_Code_Generator::init_special_condition(RZ_Clasp_Code_Special_Conditions sc)
{
 current_element_->init_special_condition(sc);
}

