
#ifndef RZ_CLASP_CODE_GENERATOR__H
#define RZ_CLASP_CODE_GENERATOR__H

#include "accessors.h"
#include "flags.h"

#include "rz-relae/relae-node-ptr.h"

#include "output/rz-re-lisp-output.h"

#include "rz-graph-core/kernel/graph/rz-re-graph.h"

#include "rz-graph-token/token/token-kinds.h"

//#include "rz-clasp-web-build-info.h"

#include "rz-web-build/rz-web-builder.h"


#include "rz-clasp-code-block-kinds.h"
#include "rz-clasp-code-special-conditions.h"

#include "rz-clasp-code-lisp-paste-modes.h"

#include <QString>
#include <QTextStream>
#include <QMap>
#include <QDebug>

#include <functional>

#include "rzns.h"


typedef QMap<QString, QPair<int, QString>> RZ_File_List_Type;
typedef QMapIterator<QString, QPair<int, QString>> RZ_File_List_Iterator_Type;
typedef QMutableMapIterator<QString, QPair<int, QString>> RZ_File_List_Mutable_Iterator_Type;

RZNS_(GRun)

 class RZ_Graph_Run_Token;

_RZNS(GRun)

USING_RZNS(GRun)



RZNS_(GVal)

 class RZ_String_Plex;
 class RZ_Function_Def_Info;

_RZNS(GVal)

USING_RZNS(GVal)

RZNS_(RECore)

class RE_Document;
class RE_Node;
class RE_Graph;
class RZ_Sre_Token;
class RZ_Clasp_Code_Block;


_RZNS(RECore)

USING_RZNS(RECore)


RZNS_(RZClasp)


class RZ_Clasp_Source_File;
class RZ_Clasp_Source_Element;
class RZ_Clasp_Source_Fundef;
class RZ_Clasp_Source_Block;
class RZ_Clasp_Code_Lexmap;
class RZ_Clasp_Cpp_Code_Generator;


class RZ_Clasp_Code_Generator
{
// QString file_;

 caon_ptr<RZ_Clasp_Source_File> source_file_;
 caon_ptr<RZ_Clasp_Source_Element> current_element_;
 caon_ptr<RZ_Clasp_Source_Element> root_element_;
 caon_ptr<RZ_Clasp_Source_Block> current_block_;
 int current_indentation_;

 QString initial_output_text_;

 caon_ptr<RZ_Clasp_Cpp_Code_Generator> cpp_code_gen_;


 void check_type_rename(QString& sv);


public:

 ACCESSORS(QString ,initial_output_text)
 ACCESSORS(caon_ptr<RZ_Clasp_Cpp_Code_Generator> ,cpp_code_gen)


 RZ_Clasp_Code_Generator();

 void write(QTextStream& qts);

 void setup_retval();


 void add_initial_output_text(QString text)
 {
  initial_output_text_ += text;
 }

 void set_current_code_block(caon_ptr<RZ_Clasp_Code_Block> cb, RZ_Clasp_Code_Block_Kinds block_kind);

 void add_initial_cpp_output_text(QString text);

 void init_cpp_code_generation();

 void add_logical_function_def(caon_ptr<RZ_Clasp_Source_Fundef> fd);

 void add_raw_lisp(QString lisp, RZ_Clasp_Code_Lisp_Paste_Modes mode);

 caon_ptr<RZ_Clasp_Source_Element>
  new_logical_function_def(QString name, RZ_Function_Def_Info& fdi, QString label = QString());

 caon_ptr<RZ_Clasp_Source_Element>
  add_file_entry(); //QString name, RZ_Function_Def_Info& fdi);

 caon_ptr<RZ_Clasp_Source_Element> enter_class_definition(QString scope_kind_name, QString name);

 void prepare_statement_entry();
 void prepare_expression_entry(QString prefix);
 void prepare_expression_leave();
 void unwind_expression_leave();
 void prepare_expression_continue();

 void function_expression_entry(QString cpp_string_value);
 void function_expression_entry_infix(QString cpp_string_value);
                                //RZ_Graph_Run_Token& rzt, RZ_SRE_Token& sre_token);

 void add_symbol(RZ_Graph_Run_Token& rzt);
 void add_symbol_with_type(RZ_Graph_Run_Token& rzt, QString type);
 void add_symbol_with_type_pending(RZ_Graph_Run_Token& rzt);

 void prepare_statement_leave_after_block_map();

 void add_string_literal(RZ_Graph_Run_Token& rzt);
 void end_statement();
 void add_source_element(caon_ptr<RZ_Clasp_Source_Element> se);
 void block_pre_entry(caon_ptr<RZ_Clasp_Code_Block> block, RZ_Clasp_Code_Block_Kinds block_kind);
 void nested_block_pre_entry(caon_ptr<RZ_Clasp_Code_Block> block, RZ_Clasp_Code_Block_Kinds block_kind);

 void nested_block_rewind_prepare_continue();

 //void check_nested_block_pre_entry(RZ_Clasp_Code_Block_Kinds block_kind);
 void check_nested_block_pre_entry(caon_ptr<RZ_Clasp_Code_Block> block, RZ_Clasp_Code_Block_Kinds block_kind);

 void check_token_expansion(QString& sv);

 void check_function_rename(QString& sv);
 void check_token_rename(QString& sv);
 caon_ptr<RZ_Clasp_Source_Fundef> nested_block_leave(RZ_Clasp_Code_Block_Kinds& block_kind);
 void block_leave();

 void prepare_block_map_continue();

 void init_special_condition(RZ_Clasp_Code_Special_Conditions sc);

 void register_block_objects(caon_ptr<RZ_Clasp_Code_Lexmap> rlx);
 void register_call_entry_label(QString label);

 void reset_classdef_to_parent();

 void link_source_fundef_to_ref(caon_ptr<RZ_Clasp_Source_Element> lhs, caon_ptr<RZ_Clasp_Source_Element> rhs);

// void add_source_element(caon_ptr<RZ_Clasp_Source_Fundef> sf);
// void add_element(caon_ptr<RZ_Clasp_Source_Element> cse, RZ_Clasp_Source_Fundef* sf);
// void add_element(caon_ptr<RZ_Clasp_Source_Element> cse, RZ_Clasp_Source_Element* se);

};

_RZNS(RZClasp)

#endif
