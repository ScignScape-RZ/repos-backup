
#include "rz-clasp-code-lexmap.h"

#include "rzns.h"



USING_RZNS(RZClasp)

RZ_Clasp_Code_Lexmap::RZ_Clasp_Code_Lexmap()
{

}

void RZ_Clasp_Code_Lexmap::add_value(QString key, caon_ptr<RE_Node> value)
{
 values_[key] = {QString(), value};
}

void RZ_Clasp_Code_Lexmap::add_value(QString key, QString value)
{
 values_[key] = {value, nullptr};
}

void RZ_Clasp_Code_Lexmap::write(QString& result)
{
 result += "let* (";
 QMapIterator<QString, RZ_Clasp_Code_Lexmap_Value> it(values_);
 while(it.hasNext())
 {
  it.next();
  QString key = it.key();
  RZ_Clasp_Code_Lexmap_Value v = it.value();
  if(v.node)
  {
   result += QString("(%1 nil)").arg(key);
  }
  else
  {
   result += QString("(%1 %2)").arg(key).arg(v.output);
  }
 }
 result += ')';

}

