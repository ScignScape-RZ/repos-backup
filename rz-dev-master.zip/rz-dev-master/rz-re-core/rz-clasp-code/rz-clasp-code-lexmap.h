

#ifndef RZ_CLASP_CODE_LEXMAP__H
#define RZ_CLASP_CODE_LEXMAP__H

#include "accessors.h"
#include "flags.h"

#include "rz-relae/relae-node-ptr.h"

#include <QString>
#include <QTextStream>
#include <QMap>

#include <functional>

#include "rzns.h"


RZNS_(RECore)

class RE_Document;
class RE_Node;
class RE_Graph;

_RZNS(RECore)

USING_RZNS(RECore)


RZNS_(RZClasp)

class RZ_Clasp_Code_Lexmap
{
 struct RZ_Clasp_Code_Lexmap_Value
 {
  QString output;
  caon_ptr<RE_Node> node;
 };

 QMap<QString, RZ_Clasp_Code_Lexmap_Value> values_;


public:

 RZ_Clasp_Code_Lexmap();

 void add_value(QString key, caon_ptr<RE_Node> value);
 void add_value(QString key, QString value);
 void write(QString& result);
};

_RZNS(RZClasp)

#endif
