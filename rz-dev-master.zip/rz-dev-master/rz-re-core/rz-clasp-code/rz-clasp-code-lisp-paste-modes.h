
#ifndef RZ_CLASP_CODE_LISP_PASTE_KINDS__H
#define RZ_CLASP_CODE_LISP_PASTE_KINDS__H

#include "rzns.h"


RZNS_(RZClasp)


enum class RZ_Clasp_Code_Lisp_Paste_Modes
{
 N_A, Root, Immediate, Pending, Follow
};


_RZNS(RZClasp)

#endif
