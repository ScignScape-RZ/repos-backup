
#ifndef RZ_CLASP_CODE_SPECIAL_CONDITIONS__H
#define RZ_CLASP_CODE_SPECIAL_CONDITIONS__H

#include "rzns.h"


RZNS_(RZClasp)


enum class RZ_Clasp_Code_Special_Conditions
{
 N_A, If_Elsif, If_Elsif_Entry
};


_RZNS(RZClasp)

#endif
