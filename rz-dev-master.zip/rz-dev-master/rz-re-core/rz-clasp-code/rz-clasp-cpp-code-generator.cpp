
#include "rz-clasp-cpp-code-generator.h"

#include "rzns.h"

USING_RZNS(RZClasp)


RZ_Clasp_Cpp_Code_Generator::RZ_Clasp_Cpp_Code_Generator(caon_ptr<RZ_Clasp_Code_Generator> mg)
 : main_gen_(mg)
{

}

void RZ_Clasp_Cpp_Code_Generator::add_initial_cpp_output_text(QString text)
{
 initial_cpp_output_text_ += text;
}

void RZ_Clasp_Cpp_Code_Generator::check_function_rename(QString& sv)
{
 static QMap<QString, QString> static_map {{
  { "=?", "==" },
  { "my", "" },
  { "our", "" },
  { "their", "" },
  { "===", "" },
  { "=", "=" },
  { "?", "" },
  { "iden", "" },
  { "ret", "return" },
  { "call", "" },
  { "$", "slot-value" },
  { "do", "do" },
  { "-!", "null" },
  { "-?", "identity" },
  { "if-", "if" },
 }};
 if(static_map.contains(sv))
 {
  sv = static_map[sv];
 }
}

void RZ_Clasp_Cpp_Code_Generator::check_token_rename(QString& sv)
{
 static QMap<QString, QString> static_map {{
  { "..do..", "do" },
  { "/do/", "do" },
 }};
 if(static_map.contains(sv))
 {
  sv = static_map[sv];
 }
 else if(sv.startsWith(';') && sv.endsWith(';') && (sv.size() > 1))
 {
  sv.clear();
 }
 else if(sv.startsWith('|') and sv.endsWith('|'))
 {

 }
 else if(sv.startsWith('|'))
 {

 }
 else if(sv.endsWith('|'))
 {

 }
 else
 {
  //? sv.replace("||", "::callback :");
 }
// else
// {
//  //?check_token_expansion(sv);
// }
}
