
#ifndef RZ_CLASP_CPP_CODE_GENERATOR__H
#define RZ_CLASP_CPP_CODE_GENERATOR__H

#include "accessors.h"
#include "flags.h"

#include "rz-relae/relae-node-ptr.h"


#include "rzns.h"

RZNS_(RZClasp)

class RZ_Clasp_Code_Generator;


class RZ_Clasp_Cpp_Code_Generator
{

 caon_ptr<RZ_Clasp_Code_Generator> main_gen_;

 QString initial_cpp_output_text_;


public:

 ACCESSORS(QString ,initial_cpp_output_text)


 RZ_Clasp_Cpp_Code_Generator(caon_ptr<RZ_Clasp_Code_Generator> mg);

 void add_initial_cpp_output_text(QString text);
 void check_function_rename(QString& sv);
 void check_token_rename(QString& sv);

};

_RZNS(RZClasp)

#endif
