
#ifndef RZ_QCLASP_GENERATOR__H
#define RZ_QCLASP_GENERATOR__H

#include <QString>

#include "rzns.h"

#include "accessors.h"


RZNS_CLASS_DECLARE(NL ,NL_Lexicon)
USING_RZNS(NL)


RZNS_(RZClasp)


class RZ_QClasp_Eval;
class RZ_QClasp_Object_Bridge;


class RZ_QClasp_Generator
{

public:

 //?RZ_QClasp_Generator();

 //?QString eval_rz_file(QString file_name);
 static void compile_rz(QString file_name, QString& result);

};


_RZNS(RZClasp)







//class Clasp_Bridge1
//{

//public:

// // static void select_and_eval_file_msg();
// // static QString select_and_eval_file();
// // static QString eval_file(QString file_name);
//};


#endif
