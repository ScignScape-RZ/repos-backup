
#include "rz-clasp-code-block.h"


#include "rz-graph-valuer/scope/rz-lisp-graph-block-info.h"

#include "rz-graph-core/kernel/graph/rz-re-node.h"

USING_RZNS(RECore)


RZ_Clasp_Code_Block::RZ_Clasp_Code_Block(caon_ptr<RZ_Clasp_Code_Block> parent_block,
  //caon_ptr<RE_Block_Entry> rbe
  caon_ptr<RE_Node> block_entry_node)
 : parent_block_(parent_block), block_entry_node_(block_entry_node)
{
 CAON_PTR_DEBUG(RE_Node ,block_entry_node)
 if(parent_block)
 {
  caon_ptr<RE_Block_Entry> rbe1 = parent_block->get_block_entry();
  CAON_PTR_DEBUG(RE_Block_Entry ,rbe1)
  CAON_DEBUG_NOOP
 }
}


caon_ptr<RE_Block_Entry> RZ_Clasp_Code_Block::get_block_entry()
{
 if(block_entry_node_)
 {
  return block_entry_node_->re_block_entry();
 }
}

//caon_ptr<RE_Node> RZ_Clasp_Code_Block::get_block_entry_node()
//{
// caon_ptr<RE_Node> result;
// if(block_info_)
// {
//  result = block_info_->block_entry_node();
//  caon_ptr<RE_Block_Entry> rbe = result->re_block_entry();
//  if(rbe != block_entry_)
//  {
//   qDebug() << "Apparent block entry mismatch?";
//  }
// }
// return result;
//}



