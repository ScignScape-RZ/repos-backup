
#ifndef RZ_CLASP_CODE_BLOCK__H
#define RZ_CLASP_CODE_BLOCK__H

#include "accessors.h"
#include "flags.h"

#include "rz-relae/relae-node-ptr.h"

#include "output/rz-re-lisp-output.h"

#include "rz-graph-core/kernel/graph/rz-re-graph.h"

#include "rz-graph-token/token/token-kinds.h"

#include <QString>
#include <QTextStream>
#include <QMap>

#include <functional>

#include "rzns.h"

RZNS_(GVal)
class RZ_Lisp_Graph_Block_Info;
_RZNS(GVal)
USING_RZNS(GVal)

RZNS_(RECore)

class RE_Block_Entry;
class RE_Node;

class RZ_Clasp_Code_Block
{
 caon_ptr<RZ_Clasp_Code_Block> parent_block_;

 //caon_ptr<RE_Block_Entry> block_entry_;
 caon_ptr<RE_Node> block_entry_node_;

 caon_ptr<RZ_Lisp_Graph_Block_Info> block_info_;


public:

 RZ_Clasp_Code_Block(caon_ptr<RZ_Clasp_Code_Block> parent_block,
  //caon_ptr<RE_Block_Entry> rbe = nullptr
  caon_ptr<RE_Node> ren = nullptr
   );

 ACCESSORS__GET(caon_ptr<RZ_Clasp_Code_Block> ,parent_block)

 ACCESSORS__GET(caon_ptr<RE_Node> ,block_entry_node)


 //ACCESSORS__GET(caon_ptr<RE_Block_Entry> ,block_entry)
 ACCESSORS(caon_ptr<RZ_Lisp_Graph_Block_Info> ,block_info)

 //caon_ptr<RE_Node> get_block_entry_node();
 caon_ptr<RE_Block_Entry> get_block_entry();

};

_RZNS(RECore)

#endif
