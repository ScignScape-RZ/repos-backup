
//#include "rz-clasp-embed-branch.access-modifier.h"

//#include "rz-graph-run/token/rz-graph-run-token.h"

//#include "rz-graph-sre/rz-sre-token.h"


//USING_RZNS(RECore)


//RZ_Clasp_Embed_Branch__Access_Modifier::RZ_Clasp_Embed_Branch__Access_Modifier(
//  QTextStream& qts,
//  caon_ptr<RZ_Clasp_Embed_Branch> parent_branch,
//  int current_indentation_depth)
// :  RZ_Clasp_Embed_Branch(qts, parent_branch, current_indentation_depth)
//{

//}

//void RZ_Clasp_Embed_Branch__Access_Modifier::write_function_name(const RZ_SRE_Token& sre_token)
//{
// const RZ_Graph_Run_Token& rzt = *sre_token.run_token();
// qts_ << rzt.string_value() << ':';
//}

//void RZ_Clasp_Embed_Branch__Access_Modifier::write_function_expression_leave()
//{

//}

//void RZ_Clasp_Embed_Branch__Access_Modifier::write_symbol_name(const RZ_SRE_Token& sre_token)
//{
//}

//void RZ_Clasp_Embed_Branch__Access_Modifier::write_statement_final()
//{
//}

////void RZ_Clasp_Embed_Branch__Class::write_string_literal(const RZ_Graph_Run_Token& rzt)
////{

////}

