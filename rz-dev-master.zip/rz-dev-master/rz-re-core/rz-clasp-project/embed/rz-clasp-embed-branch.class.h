
//#ifndef RZ_CLASP_EMBED_BRANCH__CLASS__H
//#define RZ_CLASP_EMBED_BRANCH__CLASS__H

//#include "accessors.h"
//#include "flags.h"

//#include "rz-clasp-embed-branch.h"

//#include "rzns.h"

//RZNS_(RECore)

//class RZ_Clasp_Embed_Branch__Class : public RZ_Clasp_Embed_Branch
//{
// flags_(1)
//  bool is_class_definition_entry:1;
// _flags

// enum class Secondary_Tokens {
//  N_A, Enter_Logical_Scope
//  };

// Secondary_Tokens match_secondary_token(QString str)
// {
//  static QMap<QString, Secondary_Tokens> static_map {{
//   { "---", Secondary_Tokens::Enter_Logical_Scope },
//   { "----", Secondary_Tokens::Enter_Logical_Scope },
//   { "-----", Secondary_Tokens::Enter_Logical_Scope },
//   { "------", Secondary_Tokens::Enter_Logical_Scope },
//  }};

//  return static_map.value(str, Secondary_Tokens::N_A);
// }

//public:

// RZ_Clasp_Embed_Branch__Class(QTextStream& qts, caon_ptr<RZ_Clasp_Embed_Branch> parent_branch,
//  int current_indentation_depth);

// virtual void write_function_name(const RZ_SRE_Token& sre_token);
// virtual void write_symbol_name(const RZ_SRE_Token& sre_token);

// virtual void write_function_expression_leave();
// virtual void write_statement_final();


//};

//_RZNS(RECore)

//#endif
