
#include "rz-clasp-embed-branch.noop.h"

#include "rz-graph-run/token/rz-graph-run-token.h"

#include "rz-graph-sre/rz-sre-token.h"



USING_RZNS(RECore)


RZ_Clasp_Embed_Branch__Noop::RZ_Clasp_Embed_Branch__Noop(QTextStream& qts,
  caon_ptr<RZ_Clasp_Embed_Branch> parent_branch,
  RZ_Clasp_Code_Generator& ccg)
 :  RZ_Clasp_Embed_Branch(qts, parent_branch, ccg)
  //, //Flags(0)
{

}


void RZ_Clasp_Embed_Branch__Noop::ccg_add_file_entry()
{
}

void RZ_Clasp_Embed_Branch__Noop::ccg_prepare_statement_entry()
{
}

void RZ_Clasp_Embed_Branch__Noop::ccg_nested_block_pre_entry(caon_ptr<RZ_Clasp_Code_Block> block, RZ_Clasp_Code_Block_Kinds block_kind)
{
}

void RZ_Clasp_Embed_Branch__Noop::ccg_block_pre_entry(caon_ptr<RZ_Clasp_Code_Block> block, RZ_Clasp_Code_Block_Kinds block_kind)
{
}

void RZ_Clasp_Embed_Branch__Noop::ccg_prepare_expression_entry(QString prefix)
{
}

void RZ_Clasp_Embed_Branch__Noop::ccg_prepare_expression_leave()
{
}

void RZ_Clasp_Embed_Branch__Noop::ccg_end_statement()
{
}

caon_ptr<RZ_Clasp_Source_Fundef>
 RZ_Clasp_Embed_Branch__Noop::ccg_nested_block_leave(RZ_Clasp_Code_Block_Kinds& block_kind)
{
}

void RZ_Clasp_Embed_Branch__Noop::ccg_add_source_element(caon_ptr<RZ_Clasp_Source_Element> current_source_element)
{
}

void RZ_Clasp_Embed_Branch__Noop::ccg_function_expression_entry(RZ_Graph_Run_Token& rzt, RZ_SRE_Token& sre_token)
{
}

void RZ_Clasp_Embed_Branch__Noop::ccg_add_symbol(RZ_Graph_Run_Token& rzt)
{
}

void RZ_Clasp_Embed_Branch__Noop::ccg_add_symbol_with_type(RZ_Graph_Run_Token& rzt, QString type)
{
}

void RZ_Clasp_Embed_Branch__Noop::ccg_add_symbol_with_type_pending(RZ_Graph_Run_Token& rzt)
{
}

void RZ_Clasp_Embed_Branch__Noop::ccg_add_string_literal(RZ_Graph_Run_Token& rzt)
{
}





//void RZ_Clasp_Embed_Branch__Noop__Noop::write_statement_entry()
//{
// qts_ << "\n  --  noop\n";
//}


//void RZ_Clasp_Embed_Branch__Noop__Noop::write_function_name(const RZ_SRE_Token& sre_token)
//{
//}

//void RZ_Clasp_Embed_Branch__Noop__Noop::write_symbol_name(const RZ_SRE_Token& sre_token)
//{
//}

//void RZ_Clasp_Embed_Branch__Noop__Noop::write_function_expression_leave()
//{
//}

//void RZ_Clasp_Embed_Branch__Noop__Noop::write_statement_final()
//{
//}

