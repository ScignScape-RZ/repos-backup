
#ifndef RZ_CLASP_EMBED_BRANCH__NOOP__H
#define RZ_CLASP_EMBED_BRANCH__NOOP__H

#include "accessors.h"
#include "flags.h"

#include "rz-clasp-embed-branch.h"

#include "rzns.h"

RZNS_(RECore)

class RZ_Clasp_Embed_Branch__Noop : public RZ_Clasp_Embed_Branch
{
public:

 RZ_Clasp_Embed_Branch__Noop(QTextStream& qts, caon_ptr<RZ_Clasp_Embed_Branch> parent_branch,
  RZ_Clasp_Code_Generator& ccg);

 void ccg_add_file_entry() override;

 void ccg_prepare_statement_entry() override;
 void ccg_nested_block_pre_entry(caon_ptr<RZ_Clasp_Code_Block> block, RZ_Clasp_Code_Block_Kinds block_kind) override;
 void ccg_block_pre_entry(caon_ptr<RZ_Clasp_Code_Block> block, RZ_Clasp_Code_Block_Kinds block_kind) override;
 void ccg_prepare_expression_entry(QString prefix) override;
 void ccg_prepare_expression_leave() override;
 void ccg_end_statement() override;
 void ccg_add_symbol_with_type(RZ_Graph_Run_Token& rzt, QString type) override;
 void ccg_add_symbol_with_type_pending(RZ_Graph_Run_Token& rzt) override;


 caon_ptr<RZ_Clasp_Source_Fundef> ccg_nested_block_leave(RZ_Clasp_Code_Block_Kinds& block_kind) override;

 void ccg_add_source_element(caon_ptr<RZ_Clasp_Source_Element> current_source_element) override;


 void ccg_function_expression_entry(RZ_Graph_Run_Token& rzt, RZ_SRE_Token& sre_token) override;
 void ccg_add_symbol(RZ_Graph_Run_Token& rzt) override;
 void ccg_add_string_literal(RZ_Graph_Run_Token& rzt) override;




//  void write_function_name(const RZ_SRE_Token& sre_token) Q_DECL_OVERRIDE;
//  void write_symbol_name(const RZ_SRE_Token& sre_token) Q_DECL_OVERRIDE;

//  void write_function_expression_leave() Q_DECL_OVERRIDE;
//  void write_statement_final() Q_DECL_OVERRIDE;
//  void write_statement_entry() Q_DECL_OVERRIDE;


};

_RZNS(RECore)

#endif
