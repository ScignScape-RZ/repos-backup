
//#include "rz-clasp-embed-branch.self-closing-statement.h"

//#include "rz-graph-run/token/rz-graph-run-token.h"

//#include "rz-graph-sre/rz-sre-token.h"


//USING_RZNS(RECore)


//RZ_Clasp_Embed_Branch__Self_Closing_Statement::RZ_Clasp_Embed_Branch__Self_Closing_Statement(
//  QString cpp_out, QTextStream& qts,
//  caon_ptr<RZ_Clasp_Embed_Branch> parent_branch,
//  int current_indentation_depth)
// :  RZ_Clasp_Embed_Branch(qts, parent_branch, current_indentation_depth),
//   cpp_out_(cpp_out)
//{

//}

//void RZ_Clasp_Embed_Branch__Self_Closing_Statement::write_function_name(const RZ_SRE_Token& sre_token)
//{
// qts_ << cpp_out_;
//}

//void RZ_Clasp_Embed_Branch__Self_Closing_Statement::write_function_expression_leave()
//{

//}

//void RZ_Clasp_Embed_Branch__Self_Closing_Statement::write_symbol_name(const RZ_SRE_Token& sre_token)
//{
// //const RZ_Graph_Run_Token& rzt = *sre_token.run_token();
// base_write_symbol_name(sre_token);
//}



////void RZ_Clasp_Embed_Branch__Class::write_string_literal(const RZ_Graph_Run_Token& rzt)
////{

////}

