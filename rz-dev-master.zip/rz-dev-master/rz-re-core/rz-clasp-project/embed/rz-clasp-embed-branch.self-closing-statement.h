
//#ifndef RZ_Cheerp_EMBED_BRANCH__SELF_CLOSING_STATEMENT__H
//#define RZ_Cheerp_EMBED_BRANCH__SELF_CLOSING_STATEMENT__H

//#include "accessors.h"
//#include "flags.h"

//#include "rz-cheerp-embed-branch.h"

//#include "rzns.h"

//RZNS_(RECore)

//class RZ_Cheerp_Embed_Branch__Self_Closing_Statement : public RZ_Cheerp_Embed_Branch
//{
// QString cpp_out_;

//public:

// RZ_Cheerp_Embed_Branch__Self_Closing_Statement(QString cpp_out, QTextStream& qts,
//  caon_ptr<RZ_Cheerp_Embed_Branch> parent_branch,
//  int current_indentation_depth);

// virtual void write_function_name(const RZ_SRE_Token& sre_token);
// virtual void write_symbol_name(const RZ_SRE_Token& sre_token);

// virtual void write_function_expression_leave();


//};

//_RZNS(RECore)

//#endif
