
#include "rz-clasp-cpp-project.h"

#include "rz-graph-valuer/vector/rz-string-plex.h"

USING_RZNS(RECore)


RZ_Clasp_Cpp_Project::RZ_Clasp_Cpp_Project()
 : clasp_project_(nullptr)
{

}

