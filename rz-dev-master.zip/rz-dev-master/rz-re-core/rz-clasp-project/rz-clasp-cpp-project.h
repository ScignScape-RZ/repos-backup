
#ifndef RZ_CLASP_CPP_PROJECT__H
#define RZ_CLASP_CPP_PROJECT__H

#include "accessors.h"
#include "flags.h"

#include "rz-relae/relae-node-ptr.h"

#include "output/rz-re-lisp-output.h"

#include "rz-graph-core/kernel/graph/rz-re-graph.h"

#include "rz-graph-token/token/token-kinds.h"

#include "rz-clasp-web-build-info.h"

#include "rz-web-build/rz-web-builder.h"

#include "rz-clasp-code/rz-clasp-code-generator.h"

#include <QString>
#include <QTextStream>
#include <QMap>
#include <QStringList>

#include <functional>

#include "rzns.h"

RZNS_(GVal)

 class RZ_String_Plex;

_RZNS(GVal)

USING_RZNS(GVal)


RZNS_(RECore)


class RE_Document;
class RE_Node;
class RE_Graph;

//?class RZ_Clasp_Source_Fundef;

class RZ_Clasp_Project;

class RZ_Clasp_Cpp_Project
{
 caon_ptr<RZ_Clasp_Project> clasp_project_;

public:

 RZ_Clasp_Cpp_Project();


};

_RZNS(RECore)

#endif
