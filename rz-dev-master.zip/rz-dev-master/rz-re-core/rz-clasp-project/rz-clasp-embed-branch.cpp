
#include "rz-clasp-embed-branch.h"

#include "rz-graph-run/token/rz-graph-run-token.h"

#include "rz-graph-sre/rz-sre-token.h"

#include "rz-clasp-code/rz-clasp-code-generator.h"

USING_RZNS(RECore)


RZ_Clasp_Embed_Branch::RZ_Clasp_Embed_Branch(QTextStream& qts,
  caon_ptr<RZ_Clasp_Embed_Branch> parent_branch,
  RZ_Clasp_Code_Generator& ccg)
 : qts_(qts), parent_branch_(parent_branch), ccg_(ccg)
    //current_indentation_depth_(current_indentation_depth)
{

}


void RZ_Clasp_Embed_Branch::ccg_add_raw_lisp(QString lisp, RZ_Clasp_Code_Lisp_Paste_Modes mode)
{
 ccg_.add_raw_lisp(lisp, mode);
}

void RZ_Clasp_Embed_Branch::ccg_add_file_entry()
{
 ccg_.add_file_entry();
}

void RZ_Clasp_Embed_Branch::ccg_register_call_entry_label(QString label)
{
 ccg_.register_call_entry_label(label);
}

void RZ_Clasp_Embed_Branch::ccg_prepare_statement_entry()
{
 ccg_.prepare_statement_entry();
}

void RZ_Clasp_Embed_Branch::ccg_nested_block_pre_entry(caon_ptr<RZ_Clasp_Code_Block> block, RZ_Clasp_Code_Block_Kinds block_kind)
{
 ccg_.nested_block_pre_entry(block, block_kind);
}

void RZ_Clasp_Embed_Branch::ccg_check_nested_block_pre_entry(caon_ptr<RZ_Clasp_Code_Block> block, RZ_Clasp_Code_Block_Kinds block_kind)
{
 ccg_.check_nested_block_pre_entry(block, block_kind);
}

void RZ_Clasp_Embed_Branch::ccg_set_current_code_block(caon_ptr<RZ_Clasp_Code_Block> block, RZ_Clasp_Code_Block_Kinds block_kind)
{
 ccg_.set_current_code_block(block, block_kind);
}


void RZ_Clasp_Embed_Branch::ccg_block_pre_entry(caon_ptr<RZ_Clasp_Code_Block> block, RZ_Clasp_Code_Block_Kinds block_kind)
{
 ccg_.block_pre_entry(block, block_kind);
}

void RZ_Clasp_Embed_Branch::ccg_register_block_objects(caon_ptr<RZ_Clasp_Code_Lexmap> rlx)
{
 ccg_.register_block_objects(rlx);
}


void RZ_Clasp_Embed_Branch::ccg_prepare_expression_entry(QString prefix)
{
 ccg_.prepare_expression_entry(prefix);
}

void RZ_Clasp_Embed_Branch::ccg_nested_block_rewind_prepare_continue()
{
 ccg_.nested_block_rewind_prepare_continue();
}

void RZ_Clasp_Embed_Branch::ccg_prepare_block_map_continue()
{
 ccg_.prepare_block_map_continue();
}

void RZ_Clasp_Embed_Branch::ccg_unwind_expression_leave()
{
 ccg_.unwind_expression_leave();
}

void RZ_Clasp_Embed_Branch::ccg_prepare_expression_leave()
{
 ccg_.prepare_expression_leave();
}

void RZ_Clasp_Embed_Branch::ccg_prepare_statement_leave_after_block_map()
{
 ccg_.prepare_statement_leave_after_block_map();
}

void RZ_Clasp_Embed_Branch::ccg_end_statement()
{
 ccg_.end_statement();
}

caon_ptr<RZ_Clasp_Source_Fundef>
 RZ_Clasp_Embed_Branch::ccg_nested_block_leave(RZ_Clasp_Code_Block_Kinds& block_kind)
{
 return ccg_.nested_block_leave(block_kind);
}

void RZ_Clasp_Embed_Branch::ccg_block_leave()
{
 ccg_.block_leave();
}

void RZ_Clasp_Embed_Branch::ccg_add_source_element(caon_ptr<RZ_Clasp_Source_Element> current_source_element)
{
 ccg_.add_source_element(current_source_element);
}

void RZ_Clasp_Embed_Branch::ccg_setup_retval()
{
 ccg_.setup_retval();
}

void RZ_Clasp_Embed_Branch::ccg_function_expression_entry(RZ_Graph_Run_Token& rzt, RZ_SRE_Token& sre_token)
{
 //  //

 // Using RZ_Graph_Run_Token here maybe leads to circular lib dependencies...
 //  workaround?  Currently that class just inlines clasp_string_value()...
 QString sv;
 if(rzt.flags.is_if_with_elsif)
 {
  sv = "cond";
  ccg_.init_special_condition(RZ_Clasp_Code_Special_Conditions::If_Elsif);
  ccg_.init_special_condition(RZ_Clasp_Code_Special_Conditions::If_Elsif_Entry);
 }
 else if(rzt.flags.is_elsif_with_elsif)
 {
  //?
  sv = rzt.clasp_string_value();
  ccg_.init_special_condition(RZ_Clasp_Code_Special_Conditions::If_Elsif);
 }
 else
  sv = rzt.clasp_string_value();

 // //  temporary patch ... !

 if(sv == "make-instance")
  sv = "q-create";

 if(rzt.flags.is_infix_operator_entry)
  ccg_.function_expression_entry_infix(sv);
 else
  ccg_.function_expression_entry(sv);
}

void RZ_Clasp_Embed_Branch::ccg_add_symbol_with_type(RZ_Graph_Run_Token& rzt, QString type)
{
 ccg_.add_symbol_with_type(rzt, type);
}

void RZ_Clasp_Embed_Branch::ccg_add_symbol_with_type_pending(RZ_Graph_Run_Token& rzt)
{
 ccg_.add_symbol_with_type_pending(rzt);
}

void RZ_Clasp_Embed_Branch::ccg_add_symbol(RZ_Graph_Run_Token& rzt)
{
 ccg_.add_symbol(rzt);
}

void RZ_Clasp_Embed_Branch::ccg_add_string_literal(RZ_Graph_Run_Token& rzt)
{
 ccg_.add_string_literal(rzt);
}






//void RZ_Clasp_Embed_Branch::check_write_held_infix_operator()
//{
// if(!held_infix_operator_.isEmpty())
//  qts_ << held_infix_operator_ << ' ';
// held_infix_operator_.clear();
//}

//void RZ_Clasp_Embed_Branch::write_line_indentation()
//{
// qts_ << QString(current_indentation_depth_, ' ');
//}


//void RZ_Clasp_Embed_Branch::write_line_standalone(QString str)
//{
// qts_ << '\n';
// write_line_indentation();
// qts_ << str << '\n';
//}

//void RZ_Clasp_Embed_Branch::write_function_name(const RZ_SRE_Token& sre_token)
//{
// //const RZ_Graph_Run_Token& rzt = *sre_token.run_token();

// qts_ << get_function_name(sre_token);
// qts_ << '(';
//}


//QString RZ_Clasp_Embed_Branch::get_function_name(const RZ_SRE_Token& sre_token)
//{
// const RZ_Graph_Run_Token& rzt = *sre_token.run_token();

// QString result = rzt.string_value();
// if(rzt.flags.is_core_function_symbol)
// {
//  result.prepend("RZ::Cpp_Run::");
// }
// return result;
//// static QMap<QString, QString> static_map {{
////  { "pr", "RZ::Cpp_Run::pr"  },
////  }};
//}

//void RZ_Clasp_Embed_Branch::write_string_literal(const RZ_SRE_Token& sre_token)
//{
// const RZ_Graph_Run_Token& rzt = *sre_token.run_token();

// qts_ << '"' << rzt.string_value() << '"' << ' ';
// check_write_held_infix_operator();
//}

//void RZ_Clasp_Embed_Branch::base_write_symbol_name(const RZ_SRE_Token& sre_token)
//{
// const RZ_Graph_Run_Token& rzt = *sre_token.run_token();

//// if(rzt.flags.has_cpp_redirect)
////  write_line_indentation();
// QString sv = rzt.string_value();
// qts_ << sv;
// if(!sv.endsWith('\n'))
//  qts_ << ' ';
//}

//void RZ_Clasp_Embed_Branch::write_function_expression_leave()
//{
// //?qts_ << '(';
// qts_ << ')';
//}

//void RZ_Clasp_Embed_Branch::write_statement_final()
//{
// qts_ << ';' << '\n';
//}

