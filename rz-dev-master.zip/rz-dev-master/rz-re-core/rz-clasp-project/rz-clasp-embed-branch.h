
#ifndef RZ_CLASP_EMBED_BRANCH__H
#define RZ_CLASP_EMBED_BRANCH__H

#include "accessors.h"
#include "flags.h"

#include "rz-relae/relae-node-ptr.h"

#include "output/rz-re-lisp-output.h"

#include "rz-graph-core/kernel/graph/rz-re-graph.h"

#include "rz-graph-token/token/token-kinds.h"

#include "rz-clasp-code/rz-clasp-code-block-kinds.h"
#include "rz-clasp-code/rz-clasp-code-special-conditions.h"

#include "rz-clasp-code/rz-clasp-code-lisp-paste-modes.h"



#include <QString>
#include <QTextStream>
#include <QMap>

#include <functional>

#include "rzns.h"

RZNS_(GRun)

 class RZ_Graph_Run_Token;

_RZNS(GRun)

USING_RZNS(GRun)


RZNS_(RZClasp)

 class RZ_Clasp_Code_Generator;
 class RZ_Clasp_Source_Element;
 class RZ_Clasp_Code_Lexmap;
 class RZ_Clasp_Source_Fundef;

 enum class RZ_Clasp_Code_Block_Kinds;

_RZNS(RZClasp)

USING_RZNS(RZClasp)


RZNS_(RECore)


class RE_Document;
class RE_Node;
class RE_Graph;
class RZ_SRE_Token;
class RZ_Clasp_Code_Block;


class RZ_Clasp_Embed_Branch
{

protected:

 QTextStream& qts_;

 caon_ptr<RZ_Clasp_Embed_Branch> parent_branch_;
 RZ_Clasp_Code_Generator& ccg_;

// QString held_infix_operator_;

// int current_indentation_depth_;

// void check_write_held_infix_operator();
// QString get_function_name(const RZ_SRE_Token& sre_token);


public:

 RZ_Clasp_Embed_Branch(QTextStream& qts,
  caon_ptr<RZ_Clasp_Embed_Branch> parent_branch,
  RZ_Clasp_Code_Generator& ccg);
  //?int current_indentation_depth);

  // ACCESSORS__RGET(int ,current_indentation_depth)
 ACCESSORS__GET(caon_ptr<RZ_Clasp_Embed_Branch> ,parent_branch)

 virtual void ccg_add_file_entry();

 virtual void ccg_setup_retval();

 virtual void ccg_set_current_code_block(caon_ptr<RZ_Clasp_Code_Block> block, RZ_Clasp_Code_Block_Kinds block_kind);
 virtual void ccg_prepare_statement_entry();
 virtual void ccg_nested_block_pre_entry(caon_ptr<RZ_Clasp_Code_Block> block, RZ_Clasp_Code_Block_Kinds block_kind);
 virtual void ccg_check_nested_block_pre_entry(caon_ptr<RZ_Clasp_Code_Block> block, RZ_Clasp_Code_Block_Kinds block_kind);
 virtual void ccg_block_pre_entry(caon_ptr<RZ_Clasp_Code_Block> block, RZ_Clasp_Code_Block_Kinds block_kind);
 virtual void ccg_prepare_expression_entry(QString prefix);
 virtual void ccg_prepare_expression_leave();
 virtual void ccg_unwind_expression_leave();
 virtual void ccg_end_statement();
 virtual caon_ptr<RZ_Clasp_Source_Fundef> ccg_nested_block_leave(RZ_Clasp_Code_Block_Kinds& block_kind);
 virtual void ccg_block_leave();
 virtual void ccg_prepare_block_map_continue();

 virtual void ccg_nested_block_rewind_prepare_continue();

 virtual void ccg_prepare_statement_leave_after_block_map();


 virtual void ccg_add_source_element(caon_ptr<RZ_Clasp_Source_Element> current_source_element);
 virtual void ccg_register_call_entry_label(QString label);

 virtual void ccg_function_expression_entry(RZ_Graph_Run_Token& rzt, RZ_SRE_Token& sre_token);
 virtual void ccg_add_symbol(RZ_Graph_Run_Token& rzt);

 virtual void ccg_add_symbol_with_type(RZ_Graph_Run_Token& rzt, QString type);
 virtual void ccg_add_symbol_with_type_pending(RZ_Graph_Run_Token& rzt);


 virtual void ccg_add_string_literal(RZ_Graph_Run_Token& rzt);
 virtual void ccg_register_block_objects(caon_ptr<RZ_Clasp_Code_Lexmap> rlx);

 virtual void ccg_add_raw_lisp(QString lisp, RZ_Clasp_Code_Lisp_Paste_Modes mode);

// virtual void write_function_name(const RZ_SRE_Token& sre_token);
// virtual void write_string_literal(const RZ_SRE_Token& sre_token);
// virtual void base_write_symbol_name(const RZ_SRE_Token& sre_token);

// virtual void write_line_standalone(QString str);
// virtual void write_line_indentation();

// virtual void write_function_expression_leave();
// virtual void write_statement_final();

// virtual void write_symbol_name(const RZ_SRE_Token& sre_token) = 0;



};

_RZNS(RECore)

#endif
