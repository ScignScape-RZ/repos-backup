
#ifndef RZ_CLASP_EMBED_NORMAL__H
#define RZ_CLASP_EMBED_NORMAL__H

#include "accessors.h"
#include "flags.h"

#include "rz-clasp-embed-branch.h"

#include "rzns.h"

RZNS_(RECore)

class RZ_Clasp_Embed_Normal : public RZ_Clasp_Embed_Branch
{

public:

 RZ_Clasp_Embed_Normal(QTextStream& qts, caon_ptr<RZ_Clasp_Embed_Branch> parent_branch,
  RZ_Clasp_Code_Generator& ccg);

// virtual void write_function_name(const RZ_Graph_Run_Token& rzt);
// virtual void write_string_literal(const RZ_Graph_Run_Token& rzt);

// virtual void write_symbol_name(const RZ_SRE_Token& sre_token);

};

_RZNS(RECore)

#endif
