
#include "rz-clasp-project.h"

#include "rz-graph-valuer/vector/rz-string-plex.h"

USING_RZNS(RECore)


RZ_Clasp_Project::RZ_Clasp_Project(RZ_File_List_Type& extra_files_to_process, QString file)
 : extra_files_to_process_(extra_files_to_process), file_(file)
{

}

void RZ_Clasp_Project::add_file_to_process(QString file)
{
 extra_files_to_process_[file] = {1, ""}; //.push_back(file);
}


void RZ_Clasp_Project::parse_info(RZ_String_Plex& plex)
{
 web_build_info_.parse_info(plex, web_builder_);
 web_builder_.generate();
}


