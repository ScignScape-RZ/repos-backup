
#include "rz-clasp-web-build-info.h"

#include "rz-graph-valuer/vector/rz-string-plex.h"

#include "rz-web-build/rz-web-builder.h"

#include <QStringList>
#include <QRegularExpression>

USING_RZNS(RECore)


RZ_Clasp_Web_Build_Info::RZ_Clasp_Web_Build_Info()
{

}

void RZ_Clasp_Web_Build_Info::parse_info(RZ_String_Plex& plex, RZ_Web_Builder& builder)
{
//?
// QString files = plex.get_value("files");
// builder.set_files(files);
// QString patterns = plex.get_value("patterns");
// builder.set_patterns(patterns);
// QString file_type = plex.get_value("file-type");
// builder.set_file_type(file_type);
// QString path_type = plex.get_value("path-type");
// builder.set_path_type(path_type);
// QString target = plex.get_value("target");
// builder.set_target(target);
// QString raws = plex.get_value("raws");
// builder.set_raws_target(raws);
}


