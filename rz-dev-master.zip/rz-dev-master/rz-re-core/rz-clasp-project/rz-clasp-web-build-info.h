
#ifndef RZ_CLASP_WEB_BUILD_INFO__H
#define RZ_CLASP_WEB_BUILD_INFO__H

#include "accessors.h"
#include "flags.h"

#include "rz-relae/relae-node-ptr.h"

#include "output/rz-re-lisp-output.h"

#include "rz-graph-core/kernel/graph/rz-re-graph.h"

#include "rz-graph-token/token/token-kinds.h"

#include <QString>
#include <QList>
#include <QMap>

#include <functional>

#include "rzns.h"


RZNS_(GVal)

class RZ_String_Plex;

_RZNS(GVal)

USING_RZNS(GVal)


RZNS_(RECore)


class RE_Document;
class RE_Node;
class RE_Graph;
class RZ_Web_Builder;

class RZ_Clasp_Web_Build_Info
{
 QList<QString> files_;
 QList<QString> patterns_;
 QString file_type_;
 QString path_type_;
 QString target_;
 QString raws_;


public:

 RZ_Clasp_Web_Build_Info();
 void parse_info(RZ_String_Plex& plex, RZ_Web_Builder& builder);


};

_RZNS(RECore)

#endif
