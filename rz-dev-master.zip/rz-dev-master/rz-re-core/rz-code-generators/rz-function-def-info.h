

#ifndef RZ_FUNCTION_DEF_GENERATOR__H
#define RZ_FUNCTION_DEF_GENERATOR__H

#include "accessors.h"

#include "flags.h"

#include <functional>

#include <QString>

// //
#include "rz-graph-core/code/rz-re-function-def-entry.h"


//#include "rz-graph-core/kernel/query/rz-re-query.h"
//#include "rz-graph-core/kernel/frame/rz-re-frame.h"
//const RE_Query& rq_;
//RE_Frame& fr_;

#include "rz-relae/relae-caon-ptr.h"

#include "rzns.h"

#include "flags.h"

#include <QStack>

RZNS_(RECore)

class RE_Node;
class RE_Function_Def_Entry;
class RE_Query;

_RZNS(RECore)

USING_RZNS(RECore)

RZNS_(GBuild)

class RZ_Lisp_Token;

_RZNS(GBuild)

USING_RZNS(GBuild)


RZNS_(GVal)

class RZ_Lisp_Graph_Valuer;
class RZ_Function_Def_Syntax;

class RZ_Function_Def_Info
{
public:
 flags_(2)
  bool lambda:1;
  bool type_expression:1;
  bool type_symbol_assignment:1;
  bool monad:1;
  bool with_matching:1;
  bool no_impl:1;
  bool lexical_lambda:1;
  bool logical_lambda:1;
  bool do_lambda:1;
  bool no_def:1;
  bool async:1;
  bool has_preceding:1;
 _flags

private:

 typedef RE_Node tNode;

 typedef std::function<QString(QString)> type_name_callback_type;

 caon_ptr<RE_Function_Def_Entry> function_def_entry_;
 type_name_callback_type type_name_callback_;

 caon_ptr<tNode> lambda_channel_entry_node_;
 caon_ptr<tNode> return_channel_entry_node_;
 caon_ptr<tNode> sigma_channel_entry_node_;
 caon_ptr<tNode> error_channel_entry_node_;
 caon_ptr<tNode> monad_channel_entry_node_;
 caon_ptr<tNode> context_channel_entry_node_;

 caon_ptr<tNode> map_key_sequence_ref_node_;

 void init_channels(tNode& fdef_node);

 caon_ptr<RZ_Lisp_Token> channel_sequence(caon_ptr<tNode>& sequence_node, signed int& depth_change);

 const RE_Query& rq_;

 QStack<caon_ptr<RE_Node>> entry_nodes_;

 // debug ...

 int map_key_sequence_order_;

public:

 RZ_Function_Def_Info(RE_Function_Def_Entry& function_def_entry
  , const type_name_callback_type& type_name_callback);

 ACCESSORS(caon_ptr<RE_Function_Def_Entry> ,function_def_entry)
 ACCESSORS(caon_ptr<RE_Node> ,map_key_sequence_ref_node)
 ACCESSORS(int ,map_key_sequence_order)

 QString channel_string(const RZ_Function_Def_Syntax& syntax, caon_ptr<RE_Node> sequence_node);
 QString lambda_channel_string(const RZ_Function_Def_Syntax& syntax);
 QString sigma_channel_string(const RZ_Function_Def_Syntax& syntax);
 QString return_channel_string(int& token_count);
 QString return_channel_string_cpp();
 QString return_channel_string_cheerp();
 QString return_channel_string_clasp();

 QString context_channel_string();

 caon_ptr<tNode> function_def_entry_node();

 caon_ptr<tNode> function_def_entry_prior_node()
 {
  return function_def_entry_->prior_node();
 }

 QString return_channel_string_haskell();
 QString monad_channel_string(RZ_Function_Def_Syntax& syntax);

 QString get_label();


};

_RZNS(GVal)

#endif
