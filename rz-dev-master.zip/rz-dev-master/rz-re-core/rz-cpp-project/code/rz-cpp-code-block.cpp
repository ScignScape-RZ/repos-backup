
#include "rz-cpp-code-block.h"


USING_RZNS(RECore)


RZ_Cpp_Code_Block::RZ_Cpp_Code_Block(caon_ptr<RZ_Cpp_Code_Block> parent_block)
 : parent_block_(parent_block)
{

}

