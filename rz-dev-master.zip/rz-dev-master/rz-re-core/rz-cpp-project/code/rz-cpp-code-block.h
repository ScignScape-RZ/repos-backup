
#ifndef RZ_CPP_CODE_BLOCK__H
#define RZ_CPP_CODE_BLOCK__H

#include "accessors.h"
#include "flags.h"

#include "rz-relae/relae-node-ptr.h"

#include "output/rz-re-lisp-output.h"

#include "rz-graph-core/kernel/graph/rz-re-graph.h"

#include "rz-graph-token/token/token-kinds.h"

#include <QString>
#include <QTextStream>
#include <QMap>

#include <functional>

#include "rzns.h"


RZNS_(RECore)

class RZ_Cpp_Code_Block
{
 caon_ptr<RZ_Cpp_Code_Block> parent_block_;

public:

 RZ_Cpp_Code_Block(caon_ptr<RZ_Cpp_Code_Block> parent_block);

 ACCESSORS__GET(caon_ptr<RZ_Cpp_Code_Block> ,parent_block)


};

_RZNS(RECore)

#endif
