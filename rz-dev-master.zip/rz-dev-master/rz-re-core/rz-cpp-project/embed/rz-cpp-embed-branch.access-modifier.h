
#ifndef RZ_CPP_EMBED_BRANCH__ACCESS_MODIFIER__H
#define RZ_CPP_EMBED_BRANCH__ACCESS_MODIFIER__H

#include "accessors.h"
#include "flags.h"

#include "rz-cpp-embed-branch.h"

#include "rzns.h"

RZNS_(RECore)

class RZ_Cpp_Embed_Branch__Access_Modifier : public RZ_Cpp_Embed_Branch
{
 //QString cpp_out_;

public:

 RZ_Cpp_Embed_Branch__Access_Modifier(QTextStream& qts,
  caon_ptr<RZ_Cpp_Embed_Branch> parent_branch,
  int current_indentation_depth);

 virtual void write_function_name(const RZ_SRE_Token& sre_token);
 virtual void write_symbol_name(const RZ_SRE_Token& sre_token);

 virtual void write_function_expression_leave();
 virtual void write_statement_final();


};

_RZNS(RECore)

#endif
