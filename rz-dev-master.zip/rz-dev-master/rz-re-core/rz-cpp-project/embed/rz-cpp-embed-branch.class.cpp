
#include "rz-cpp-embed-branch.class.h"

#include "rz-graph-run/token/rz-graph-run-token.h"

#include "rz-graph-sre/rz-sre-token.h"



USING_RZNS(RECore)


RZ_Cpp_Embed_Branch__Class::RZ_Cpp_Embed_Branch__Class(QTextStream& qts,
  caon_ptr<RZ_Cpp_Embed_Branch> parent_branch,
  int current_indentation_depth)
 :  RZ_Cpp_Embed_Branch(qts, parent_branch, current_indentation_depth),
   Flags(0)
{

}

void RZ_Cpp_Embed_Branch__Class::write_function_name(const RZ_SRE_Token& sre_token)
{
 qts_ << "class ";
}

void RZ_Cpp_Embed_Branch__Class::write_symbol_name(const RZ_SRE_Token& sre_token)
{
 const RZ_Graph_Run_Token& rzt = *sre_token.run_token();
 QString sv = rzt.string_value();
 Secondary_Tokens st = match_secondary_token(sv);
 switch(st)
 {
 case Secondary_Tokens::Enter_Logical_Scope:
  flags.is_class_definition_entry = true;
  write_line_standalone("{");
  ++current_indentation_depth_;
  break;
 default:
  base_write_symbol_name(sre_token);
  break;
 //  qts_ << '{' << '\n';

 }
}

void RZ_Cpp_Embed_Branch__Class::write_function_expression_leave()
{

}

void RZ_Cpp_Embed_Branch__Class::write_statement_final()
{
 if(!flags.is_class_definition_entry)
  qts_ << ';';
}


//void RZ_Cpp_Embed_Branch__Class::write_string_literal(const RZ_Graph_Run_Token& rzt)
//{

//}

