
#include "rz-cpp-embed-branch.h"

#include "rz-graph-run/token/rz-graph-run-token.h"

#include "rz-graph-sre/rz-sre-token.h"


USING_RZNS(RECore)


RZ_Cpp_Embed_Branch::RZ_Cpp_Embed_Branch(QTextStream& qts,
  caon_ptr<RZ_Cpp_Embed_Branch> parent_branch,
  int current_indentation_depth)
 : qts_(qts), parent_branch_(parent_branch),
   current_indentation_depth_(current_indentation_depth)
{

}


void RZ_Cpp_Embed_Branch::check_write_held_infix_operator()
{
 if(!held_infix_operator_.isEmpty())
  qts_ << held_infix_operator_ << ' ';
 held_infix_operator_.clear();
}

void RZ_Cpp_Embed_Branch::write_line_indentation()
{
 qts_ << QString(current_indentation_depth_, ' ');
}


void RZ_Cpp_Embed_Branch::write_line_standalone(QString str)
{
 qts_ << '\n';
 write_line_indentation();
 qts_ << str << '\n';
}

void RZ_Cpp_Embed_Branch::write_function_name(const RZ_SRE_Token& sre_token)
{
 //const RZ_Graph_Run_Token& rzt = *sre_token.run_token();

 qts_ << get_function_name(sre_token);
 qts_ << '(';
}


QString RZ_Cpp_Embed_Branch::get_function_name(const RZ_SRE_Token& sre_token)
{
 const RZ_Graph_Run_Token& rzt = *sre_token.run_token();

 QString result = rzt.string_value();
 if(rzt.flags.is_core_function_symbol)
 {
  result.prepend("RZ::Cpp_Run::");
 }
 return result;
// static QMap<QString, QString> static_map {{
//  { "pr", "RZ::Cpp_Run::pr"  },
//  }};
}

void RZ_Cpp_Embed_Branch::write_string_literal(const RZ_SRE_Token& sre_token)
{
 const RZ_Graph_Run_Token& rzt = *sre_token.run_token();

 qts_ << '"' << rzt.string_value() << '"' << ' ';
 check_write_held_infix_operator();
}

void RZ_Cpp_Embed_Branch::base_write_symbol_name(const RZ_SRE_Token& sre_token)
{
 const RZ_Graph_Run_Token& rzt = *sre_token.run_token();

// if(rzt.flags.has_cpp_redirect)
//  write_line_indentation();
 QString sv = rzt.string_value();
 qts_ << sv;
 if(!sv.endsWith('\n'))
  qts_ << ' ';
}

void RZ_Cpp_Embed_Branch::write_function_expression_leave()
{
 qts_ << '(';
}

void RZ_Cpp_Embed_Branch::write_statement_final()
{
 qts_ << ';' << '\n';
}
