
#ifndef RZ_CPP_EMBED_BRANCH__H
#define RZ_CPP_EMBED_BRANCH__H

#include "accessors.h"
#include "flags.h"

#include "rz-relae/relae-node-ptr.h"

#include "output/rz-re-lisp-output.h"

#include "rz-graph-core/kernel/graph/rz-re-graph.h"

#include "rz-graph-token/token/token-kinds.h"

#include <QString>
#include <QTextStream>
#include <QMap>

#include <functional>

#include "rzns.h"

RZNS_(GRun)

 class RZ_Graph_Run_Token;

_RZNS(GRun)

USING_RZNS(GRun)


RZNS_(RECore)


class RE_Document;
class RE_Node;
class RE_Graph;
class RZ_SRE_Token;


class RZ_Cpp_Embed_Branch
{

protected:

 QTextStream& qts_;

 caon_ptr<RZ_Cpp_Embed_Branch> parent_branch_;

 QString held_infix_operator_;

 int current_indentation_depth_;

 void check_write_held_infix_operator();
 QString get_function_name(const RZ_SRE_Token& sre_token);


public:

 RZ_Cpp_Embed_Branch(QTextStream& qts, caon_ptr<RZ_Cpp_Embed_Branch> parent_branch,
  int current_indentation_depth);

 ACCESSORS__RGET(int ,current_indentation_depth)
 ACCESSORS__GET(caon_ptr<RZ_Cpp_Embed_Branch> ,parent_branch)

 virtual void write_function_name(const RZ_SRE_Token& sre_token);
 virtual void write_string_literal(const RZ_SRE_Token& sre_token);
 virtual void base_write_symbol_name(const RZ_SRE_Token& sre_token);

 virtual void write_line_standalone(QString str);
 virtual void write_line_indentation();

 virtual void write_function_expression_leave();
 virtual void write_statement_final();

 virtual void write_symbol_name(const RZ_SRE_Token& sre_token) = 0;


};

_RZNS(RECore)

#endif
