
#include "rz-cpp-embed-normal.h"

#include "rz-graph-run/token/rz-graph-run-token.h"

#include "rz-graph-sre/rz-sre-token.h"


USING_RZNS(RECore)


RZ_Cpp_Embed_Normal::RZ_Cpp_Embed_Normal(QTextStream& qts,
  caon_ptr<RZ_Cpp_Embed_Branch> parent_branch,
  int current_indentation_depth)
 : RZ_Cpp_Embed_Branch(qts, parent_branch, current_indentation_depth)
{

}


void RZ_Cpp_Embed_Normal::write_symbol_name(const RZ_SRE_Token& sre_token)
{
 const RZ_Graph_Run_Token& rzt = *sre_token.run_token();

 QString str = rzt.string_value();
 if(rzt.flags.is_infix_operator_entry)
 {
  held_infix_operator_ = str;
 }
 else
 {
  base_write_symbol_name(sre_token);
  //qts_ << str << ' ';
  check_write_held_infix_operator();
 }
}


