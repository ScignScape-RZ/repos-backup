
#ifndef RZ_CPP_EMBED_NORMAL__H
#define RZ_CPP_EMBED_NORMAL__H

#include "accessors.h"
#include "flags.h"

#include "rz-cpp-embed-branch.h"

#include "rzns.h"

RZNS_(RECore)

class RZ_Cpp_Embed_Normal : public RZ_Cpp_Embed_Branch
{

public:

 RZ_Cpp_Embed_Normal(QTextStream& qts, caon_ptr<RZ_Cpp_Embed_Branch> parent_branch,
  int current_indentation_depth);

// virtual void write_function_name(const RZ_Graph_Run_Token& rzt);
// virtual void write_string_literal(const RZ_Graph_Run_Token& rzt);

 virtual void write_symbol_name(const RZ_SRE_Token& sre_token);

};

_RZNS(RECore)

#endif
