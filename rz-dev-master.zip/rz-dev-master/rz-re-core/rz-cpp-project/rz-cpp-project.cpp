
#include "rz-cpp-project.h"


USING_RZNS(RECore)


RZ_Cpp_Project::RZ_Cpp_Project(QString file)
 : file_(file)
{

}

