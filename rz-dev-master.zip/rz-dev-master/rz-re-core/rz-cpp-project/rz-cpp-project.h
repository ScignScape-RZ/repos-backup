
#ifndef RZ_CPP_PROJECT__H
#define RZ_CPP_PROJECT__H

#include "accessors.h"
#include "flags.h"

#include "rz-relae/relae-node-ptr.h"

#include "output/rz-re-lisp-output.h"

#include "rz-graph-core/kernel/graph/rz-re-graph.h"

#include "rz-graph-token/token/token-kinds.h"

#include <QString>
#include <QTextStream>
#include <QMap>

#include <functional>

#include "rzns.h"


RZNS_(RECore)


class RE_Document;
class RE_Node;
class RE_Graph;


class RZ_Cpp_Project
{
 QString file_;

public:

 RZ_Cpp_Project(QString file = QString());


};

_RZNS(RECore)

#endif
