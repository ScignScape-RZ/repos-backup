
#ifndef RZ_GENERATOR_SRE__H
#define RZ_GENERATOR_SRE__H


#include "accessors.h"
#include "flags.h"

#include "rz-relae/relae-node-ptr.h"

#include "digamma-pluviose/semantic-readtable-emulator.h"


#include "rz-graph-core/kernel/graph/rz-re-graph.h"

#include "rz-graph-token/token/token-kinds.h"

#include "rz-graph-sre/rz-read-table-state.h"


#include <QString>
#include <QTextStream>
#include <QMap>

#include <functional>

#include "rzns.h"

RZNS_(GBuild)

class RZ_Lisp_Graph_Visitor;
class RZ_Lisp_Graph_Visitor_Run_State;
class RZ_Lisp_Graph_Visitor_Clasp;

_RZNS(GBuild)

RZNS_(GRun)

 class RZ_Graph_Run_Token;

_RZNS(GRun)


RZNS_(RZClasp)

class RZ_Clasp_Source_Element;

_RZNS(RZClasp)

USING_RZNS(RZClasp)

RZNS_(GVal)

class RZ_Function_Def_Info;

_RZNS(GVal)

USING_RZNS(GVal)
USING_RZNS(GBuild)
USING_RZNS(GRun)


RZNS_(RECore)


class RE_Document;
class RE_Node;
class RE_Graph;
class RZ_Cpp_Project;
class RZ_Cpp_Embed_Branch;
class RZ_Cpp_Code_Block;
class RZ_SRE_Token;


class RZ_Generator_Sre : public Semantic_Readtable_Emulator<RE_Dominion>
{

 RZ_Lisp_Graph_Visitor& visitor_;
 caon_ptr<RZ_Lisp_Graph_Visitor_Clasp> visitor_clasp_;

 RZ_Lisp_Graph_Visitor_Run_State& run_state_;

public:

 RZ_Generator_Sre(RZ_Lisp_Graph_Visitor& visitor);

 ACCESSORS__GET(RZ_Lisp_Graph_Visitor& ,visitor)
 ACCESSORS__GET(RZ_Lisp_Graph_Visitor_Run_State& ,run_state)

 RZ_Lisp_Graph_Visitor_Clasp& visitor_clasp()
 {
  return *visitor_clasp_;
 }


// RZ_Lisp_Graph_Visitor_Run_State& run_state();
// RZ_Lisp_Graph_Visitor& visitor();

 void init();
 void begin();
 void advance();
 void load_sre_token(RZ_SRE_Token& sre_token, caon_ptr<RZ_Clasp_Source_Element>& current_source_element) override;

 RZ_Read_Table_State read_table_state();
 RZ_Read_Table_Post_Advance_State post_advance_state();

};

_RZNS(RECore)

#endif
