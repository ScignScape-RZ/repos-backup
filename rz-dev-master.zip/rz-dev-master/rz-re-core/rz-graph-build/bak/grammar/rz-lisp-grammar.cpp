

#include "rz-lisp-grammar.h"

#include "rz-lisp-graph-build.h"
#include "rz-lisp-parser.h"
//#include "rz-lisp.h"


#include "rz-parser/rz-parser.templates.h"

#include <QMapIterator>

//#include "rz-parser/rz-grammar.cpp"

//#include "rz-grammar/rz-base-grammar.h"

#include "rzns.h"

USING_RZNS(GBuild)


RZ_Lisp_Grammar::RZ_Lisp_Grammar() : RZ_Grammar<RZ_Lisp_Graph>()
{
}

void RZ_Lisp_Grammar::init(RZ_Lisp_Parser& p, RZ_Lisp_Graph& g,
 RZ_Lisp_Graph_Build& graph_build)
{
 RZ_Lisp_Document& d = *graph_build.document();

 pre_rule( "script-word", "(?:[^{}()\\[\\]\\s`;,:]|(?:\\w::?\\w))+" );
 pre_rule( "space-to-end-of-line", "[__\\t]* \\n" );
 pre_rule( "end-of-line", "[__\\t\\S]* \\n" );
 pre_rule( "single-space", "[__\\t]" );

 Context run_context = add_context("run-context");
// Context view_context = add_context("view-context");
 Context print_context = add_context("print-context");
 Context data_context = add_context("data-context");
 Context lara_context = add_context("lara-context");
 Context chi_tile_context = add_context("chi-tile-context");

 Context lisp_context = add_context("lisp-context");

 track_context({&run_context, &print_context,
  &data_context, &lara_context, &chi_tile_context, &lisp_context});

 Context run_or_print_context = add_context("run-or-print",
  {run_context, print_context});

 Context run_or_lara_context = add_context("run-or-lara",
  {run_context, lara_context});

 Context run_or_chi_tile_context = add_context("run-or-chi-tile",
  {run_context, chi_tile_context});

 activate(run_context);

 RZ_Lisp_Parse_Context& parse_context = graph_build.parse_context();

 add_rule( print_context, "print-comment",
   " (?: (?: ;~ ) | (?: %~ ) | (?: %~ ) ) .end_of_line. "
   ,[&]
  {
 //  graph_build.current_position_acc(" \n");// += " \n";
//   graph_build.raw_print_acc(" \n");
 //  graph_build.raw_acc_length += 2;

 //  graph_build.acc_length += 2;
  });

//??
 add_rule( flags_all_(parse_context ,inside_string_literal), run_context,
  "string-literal-character",
  " [^\\\"] | \\\\\" ",
  [&]
 {
  QString str = p.match_text();
  if(str == "\\\"")
   str = "\"";
  graph_build.add_to_string_literal(str);
 });



 add_rule( run_context, "multiline-run-comment",
           " .single-space.* ;+ -- (?:[^-] | - (?!-;))* -- ;+ .end-of-line. "
   ,[&]
  {
   graph_build.add_rz_comment(p.match_text());
 //  graph_build.acc_length += 2;
  });


 add_rule( run_context, "run-comment",
   " .single-space.* ;+ - .end-of-line. "
   ,[&]
  {
   graph_build.add_rz_comment(p.match_text());
 //  graph_build.acc_length += 2;
  });


 add_rule( run_context, "html-style-run-comment",
   " .single-space.* \\< !-- .single-space. -- .end-of-line. "
   ,[&]
  {
    QString s = p.match_text();
//    qDebug() << s;
//   graph_build.add_rz_comment(p.match_text());
 //  graph_build.acc_length += 2;
  });


 add_rule( print_context, "raw-space",
  " \\s+  "
  ,[&]
 {
  graph_build.check_new_print_lines(p.match_text());
 });

 add_rule( run_context, "raw-space",
  " \\s+  "
  ,[&]
 {
  graph_build.check_new_lines(p.match_text());
 });

 add_rule( run_context, "quote-phrase-separator",
  " \\: (?<keyword> \\S* ) \\:  "
  ,[&]
 {
  graph_build.add_quote_phrase_separator(p.match_text(), p.matched("keyword"));
 });



 add_rule( run_context, "script-token-with-prefix",
  "(?<prefix> [:;,]) (?<script-word> .script-word.)",
    [&]
 {
  QString prefix = p.matched("prefix");
  QString script_word = p.matched("script-word");
  graph_build.process_script_token(prefix, script_word);
 });


 add_rule( run_context, "semis4-6",
  "(?<semis> ; {4,6}) .end-of-line. "
  ,[&]
 {
  QString m = p.matched("semis");
  int size = m.size();

  graph_build.process_semis(size);

  if(size == 5)
  {
   QString remainder = p.get_remainder();

   graph_build.set_data_layer(remainder);

//   qDebug() << remainder;

   p.end_of_file(remainder.data_ptr());
//   int pos = p.current_position + p.match_text().size();
  }


//  QString

 });

 add_rule( run_context, "semis1-2",
  " ; {1,2} "
  ,[&]
 {
  QString m = p.match_text();
  graph_build.process_semis(m.size());
 });

 add_rule( run_context, "semis3-l",
  " ;;; .space-to-end-of-line "
  ,[&]
 {
  QString m = p.match_text();
  graph_build.process_semis(3);
 });

 add_rule( run_context, "semis3",
  " ;;; "
  ,[&]
 {
  QString m = p.match_text();
  graph_build.process_semis(3);
 });

 add_rule( run_context, "syntax-markup-with-prefix",
 " (?<prefix>[*#~.]+) (?<markup> [(){}\\[\\]]) ",
  [&]
 {
  tString prefix = p.matched("prefix");
  tString markup = p.matched("markup");
  graph_build.add_run_prefixed_markup(prefix, markup);
 });

 ////  Escaped quote characters given
 //    parse_context.flags.inside_string_literal
 //    will be captured by the previous rule.
 add_rule(run_context, "delimit-string-literal",
  " \" ",
  [&]
 {
  if(parse_context.flags.inside_string_literal)
  {
   graph_build.process_string_literal();
   parse_context.flags.inside_string_literal = false;
  }
  else
   parse_context.flags.inside_string_literal = true;
//  graph_build->reset_string_literal();
//  syntax_markup.flags.inside_string_literal = true;
//   p.enter_string_mode();
 });


 add_rule( chi_tile_context, "chi-tile-dot-escaped-character",
  "\\. [(\\[{]",
  [&]
 {
  QString m = p.match_text();
  graph_build.chi_tile_acc(m);
 });

 add_rule( run_or_chi_tile_context, "chi-syntax-entry",
  " [+-] [{\\[]",
  [&]
 {
  tString match_text = p.match_text();
  graph_build.chi_syntax_entry(match_text);
 });

 add_rule( chi_tile_context, "chi-tile-end",
  "(?= [(){}\\[\\]] | \\s ;)",
  [&]
 {
//  QString m = p.match_text();
  graph_build.chi_tile_end(); //m);
 });



 add_rule( chi_tile_context, "chi-tile-character",
  ".",
  [&]
 {
  QString m = p.match_text();
  graph_build.chi_tile_acc(m);
 });


 add_rule( run_context, "close-syntax-markup-with-follow",
  "(?<markup>[}\\]]) (?<follow>[~*])",
  [&]
 {
  tString markup = p.matched("markup");
  tString follow = p.matched("follow");
  graph_build.close_run_markup_with_follow(markup, follow);
 });


 add_rule( run_context, "syntax-markup",
  " [(){}\\[\\]] ",
  [&]
 {
  tString match_text = p.match_text();
  graph_build.add_run_markup(match_text);
 });

 add_rule( run_context, "numeric-token",
   " -? \\d .script-word.? ",
   [&]
  {
   tString match_text = p.match_text();
   graph_build.process_numeric_token(match_text);
  });

 add_rule( run_context, "logical-scope-entry-token",
  " - {3,6}",
    [&]
 {
  QString m = p.match_text();
  graph_build.process_statement_closing_script_token(m);
 });



 add_rule( run_context, "quoted-script-token",
  "(?<quotes> ['\"`]+ ) (?<word> .script-word. )",
    [&]
 {
  QString q = p.matched("quotes");
  QString m = p.matched("word");
  graph_build.process_quoted_script_token(q, m);
 });



 add_rule( run_context, "script-token",
  ".script-word.",
    [&]
 {
  QString m = p.match_text();
  graph_build.process_script_token(m);
 });



 add_rule( lara_context, "lara-script-token",
  ".script-word.",
    [&]
 {
  QString m = p.match_text();
  graph_build.check_lara_token(m);
 });

 add_rule( lara_context, "lara-character",
  ".",
  [&]
 {
  QString m = p.match_text();
  graph_build.check_lara_acc(m);
 });




 add_rule( lisp_context, "lisp-script-token",
  ".script-word.",
    [&]
 {
  QString m = p.match_text();
  graph_build.check_lisp_token(m);
 });

 add_rule( lisp_context, "lisp-character",
  ".",
  [&]
 {
  QString m = p.match_text();
  graph_build.check_lisp_acc(m);
 });



}

