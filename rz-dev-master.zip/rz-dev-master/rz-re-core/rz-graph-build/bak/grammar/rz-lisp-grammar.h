
#ifndef RZ_LISP_GRAMMAR__H
#define RZ_LISP_GRAMMAR__H


#include "graph/rz-lisp-graph.h"

#include "methodic.h"

#include "rz-parser/rz-grammar.h"

//#include "rz-grammar/rz-base-grammar.h"

#include "rzns.h"
RZNS_(GBuild)

class RZ_Lisp_Graph_Build;

class RZ_Lisp_Grammar : public RZ_Grammar<RZ_Lisp_Graph>
{
public:

 RZ_Lisp_Grammar();

 void init(RZ_Lisp_Parser& p, RZ_Lisp_Graph& g,
           RZ_Lisp_Graph_Build& graph_build);


};

_RZNS(GBuild)

#endif
