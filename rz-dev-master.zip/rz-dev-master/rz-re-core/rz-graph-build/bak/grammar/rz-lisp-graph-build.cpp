
#include "rz-lisp-graph-build.h"

#include "graph/rz-lisp-node.h"

#include "rz-lisp-root.h"

//#include "rz-lisp.h"

//#include "rz-run-section.h"

#include "rz-lisp-grammar.h"

#include "graph/rz-lisp-graph.h"

#include "rz-lisp-frame.h"

//?#include "lara/lara-argument.h"
//#include "chi-forms/rz-chi-form.h"
//#include "chi-forms/rz-chi-object.h"
//#include "chi-forms/rz-chi-tile.h"

#include "rz-graph-token/token/rz-string-phrase.h"

//#include "commands/rz-lisp-command.h"
//#include "commands/rz-lisp-command-arguments.h"

#include "kernel/rz-lisp-kernel-relation.h"
//#include "commands/rz-text-command-arguments.h"

#include "token/rz-lisp-token.h"

#include "rz-lisp-document.h"

#include "rzns.h"
USING_RZNS(GBuild)

typedef RZ_Lisp_Kernel_Relation LNR;

RZ_Lisp_Graph_Build::RZ_Lisp_Graph_Build(RZ_Lisp_Document* d,
 RZ_Lisp_Graph& g, RZ_Lisp_Parser& p)
 : Flags(0)
  ,document_(d)
  ,graph_(g)
  ,parser_(p)
  ,current_command_node_(nullptr)
  ,current_node_(nullptr)
  ,current_line_(1)
  ,fr_()
  ,current_position_state_(Root_Position)
  ,markup_position_(this)
  ,active_run_node_(nullptr)
  ,active_chief_token_(nullptr)
  ,current_weighted_markup_formation_weight_(0)

//   current_run_section_(nullptr),
//   current_math_segment_node_(nullptr)
{
}

void RZ_Lisp_Graph_Build::init()
{
 RZ_Lisp_Root* cdr = new RZ_Lisp_Root;
 active_run_node_ = current_node_ = root_node_ = new RZ_Lisp_Node(cdr);
// current_position_state_ = Root_Position;
 root_node_->set_label("<root>");
 graph_.set_root_node(root_node_);
 fr_.activate();

 QString sct = "_lara _lisp";
 QStringList sctl = sct.split(' ');

 for(QString s : sctl)
  automatic_statement_closing_tokens_.insert(s);


// current_run_section_ = new RZ_Run_Section(root_node_);
}

//RZ_Run_Token*
void
RZ_Lisp_Graph_Build::process_numeric_token(QString match_text)
{
// RZ_Lisp_Token* token = make_new_script_token(match_text);

 if(flags.quote_word_context)
 {
  RZ_Lisp_Token* token = make_new_script_token(match_text);
  token->flags.is_string_literal = true;
  add_script_token(token);
  return;
 }
 if(flags.quote_phrase_context)
 {
  if(flags.weighted_markup_formation && quote_phrase_list_.isEmpty())
  {
   current_weighted_markup_formation_weight_ = match_text.toInt();
  }
  else
   quote_phrase_list_.push_back(match_text);
  return;
 }

 RZ_Lisp_Token* token = make_new_script_token(match_text);

 token->flags.is_numeric_literal = true;

 add_script_token(token);
}

RZ_Run_Token* RZ_Lisp_Graph_Build::process_string_literal()
{
 RZ_Lisp_Token* token = make_new_script_token(string_literal_acc_);
 token->flags.is_string_literal = true;
 add_literal_script_token(token);
 string_literal_acc_.clear();
}

void RZ_Lisp_Graph_Build::set_data_layer(QString s)
{
 document_->set_data_layer(s);
// document_->generator_.
}

void RZ_Lisp_Graph_Build::process_semis(int count)
{
 switch(count)
 {
 case 1: case 2: break;
 case 3:
  process_script_token(";;;");
  break;
 case 4:
  process_script_token(";;;;");
  break;
 case 5:
  process_script_token(";;;;;");
  break;
 case 6:
 default:
  process_script_token(";;;;;;");
  break;
// default:
//  break;
 }

 markup_position_.process_semis(count, active_run_node_); //current_node_);

// if(count == 1)
//  markup_position_.process_semis(1, current_node_);
// else if(count == 4)
// {
//  process_script_token(";;;;");

//  markup_position_.process_semis(1, current_node_);

////  add_script_token();
// }

// if(count == 4)
// {
//  RZ_Lisp_Node* node = new RZ_Lisp_Node(token);
//  node->set_label(token->raw_text());
//  markup_position_.add_token_node(node);

// }
// markup_position_.process_semis(count, current_node_);
}


void RZ_Lisp_Graph_Build::check_new_lines(QString match_text)
{
 int c = match_text.count(QRegExp("\\n"));
 current_line_ += c;
}

void RZ_Lisp_Graph_Build::check_new_print_lines(QString match_text)
{
}

void RZ_Lisp_Graph_Build::add_rz_comment(QString match_text)
{
 document_->add_rz_comment(match_text, current_line_);
// comments_by_line_[current_line_] = match_text;
 current_line_ += match_text.count('\n');
}


void RZ_Lisp_Graph_Build::insert_node(LBR rtoken, RZ_Lisp_Node* ctn)
{
 active_run_node_ << fr_/rtoken >> ctn;
// void insert_node(tRel rtoken, tNode* ctn);
}

void RZ_Lisp_Graph_Build::attach_nodes(RZ_Lisp_Node* lhs, LBR rtoken, RZ_Lisp_Node* rhs)
{
 lhs << fr_/rtoken >> rhs;
// void insert_node(tRel rtoken, tNode* ctn);
}


RZ_Lisp_Node* RZ_Lisp_Graph_Build::make_new_node(RZ_Lisp_Token* token)
{
 RZ_Lisp_Node* result = new RZ_Lisp_Node(token);
 result->set_label(token->raw_text());
 return result;
}


void RZ_Lisp_Graph_Build::add_literal_script_token(RZ_Lisp_Token* token)
{
 RZ_Lisp_Node* node = make_new_node(token);
 markup_position_.add_token_node(node);
}

void RZ_Lisp_Graph_Build::add_script_token(RZ_Lisp_Token* token)
{
 RZ_Lisp_Node* node = make_new_node(token);
 if(flags.quote_word_context)
 {
  markup_position_.add_token_node(node);
  return;
 }
// else if(flags.quote_phrase_context)
// {
//  markup_position_.add_token_node(node);
//  return;
// }

 QString rt = token->raw_text();

 ////  Currently this is the only arrow node specially recognized,
 //    but there are plans for other arrows whose use is similar.
 if(rt == "->")
 {
  markup_position_.add_arrow_node(node);
 }
// else if(token->raw_text() == "<-")
// {
//  markup_position_.add_inverted_arrow_node(node);
//  token->flags.is_inverted_arrow = true;
// }
 else if(token->flags.is_lara_argument)
 {
  markup_position_.add_lara_node(node);
  document_->grammar()->activate_context(QString("lara-context"));
 }
 else if(automatic_statement_closing_tokens_.contains(rt))
 {
  markup_position_.add_statement_closing_node(node);
 }
 else
  markup_position_.add_token_node(node);
}

void RZ_Lisp_Graph_Build::chi_syntax_entry(QString match_text)
{
 if(flags.chi_tile_context)
 {
  finalize_chi_tile();
  document_->grammar()->activate_context(QString("run-context"));
 }

//? RZ_Chi_Form::Chi_Syntax_Formations csf = RZ_Chi_Form::get_chi_syntax_formation(match_text);

 if(active_run_node_)
  if(RZ_Lisp_Token* token = active_run_node_->lisp_token())
   token->flags.precedes_chi_argument = true;

 if(flags.chi_tile_context)
 {
  flags.chi_tile_context = false;
//?
//  RZ_Chi_Tile* rct = new RZ_Chi_Tile(active_run_node_, csf,
//   markup_position_.current_chi_object());
//  RZ_Lisp_Node* n = new RZ_Lisp_Node(rct);
//  active_run_node_ << fr_/LBR::Chi_Node_Value >> n;
//  markup_position_.add_chi_entry(n, rct);
 }
 else
 {
//?
//  RZ_Chi_Object* rco = new RZ_Chi_Object(active_run_node_, csf);
//  RZ_Lisp_Node* n = new RZ_Lisp_Node(rco);
//  active_run_node_ << fr_/LBR::Chi_Node_Value >> n;
//  markup_position_.add_chi_entry(n, rco);
 }
}

void RZ_Lisp_Graph_Build::check_chi_begin_accumulate(RZ_Lisp_Node* chi_object_node,
 RZ_Lisp_Node* predicate_vector_chief_node)
{
 // //  We have to check whether we are closing the predicate vector itself
 //     (or just a nested entry)
 RZ_Lisp_Token* tok = predicate_vector_chief_node->lisp_token();
 if(predicate_vector_chief_node == rlq_.Run_Vector_Entry(chi_object_node))
 {
  document_->grammar()->activate_context("chi-tile-context");
  flags.chi_tile_context = true;
 }
 // // else other entries...
}



// switch(current_position_state_)
// {
// case Root_Position:
//  current_node_ << fr_/LBR::Run_Call_Entry >> node;
//  current_node_ = node;
//  current_position_state_ = Run_Sequence;
//  break;
// case Run_Sequence:
//  current_node_ << fr_/LBR::Run_Call_Sequence >> node;
//  current_node_ = node;
//  break;
// case Statement_Sequence:
//  break;

// }

//}


void RZ_Lisp_Graph_Build::check_lara_token(QString match_text)
{
//?
// if(Lara_Argument::check(match_text) == Lara_Argument::N_A)
//  lara_acc_ += match_text;
// else
// {
//  finalize_lara_token();
//  add_lara_token(match_text);
// }
}

void RZ_Lisp_Graph_Build::finalize_lara_token()
{
//?
// RZ_Lisp_Token* token = make_new_script_token(lara_acc_.trimmed());
// token->flags.is_lara_string_literal = true;
// add_literal_script_token(token);
// lara_acc_.clear();
}

void RZ_Lisp_Graph_Build::add_lara_token(QString match_text)
{
//?
// RZ_Lisp_Token* token = make_new_script_token(match_text);
// token->flags.is_lara_argument = true;
// RZ_Lisp_Node* node = make_new_node(token);
// markup_position_.add_lara_node(node);
}


void RZ_Lisp_Graph_Build::check_lisp_acc(QString match_text)
{
 lisp_acc_ += match_text;
}

void RZ_Lisp_Graph_Build::check_lisp_token(QString match_text)
{
 if(match_text == "_lisp")
 {
  finalize_lisp_paste();
  RZ_Lisp_Token* token = make_new_script_token(match_text);
  add_script_token(token);
 }
 else
  lisp_acc_ += match_text;
}


void RZ_Lisp_Graph_Build::finalize_lisp_paste()
{
 RZ_Lisp_Token* token = new RZ_Lisp_Token(lisp_acc_);
 token->flags.is_direct_lisp_paste = true;

 lisp_acc_.clear();

 add_script_token(token);



 document_->grammar()->activate_context(QString("run-context"));
}


void RZ_Lisp_Graph_Build::chi_tile_acc(QString match_text)
{
 chi_acc_ += match_text;
}

void RZ_Lisp_Graph_Build::chi_tile_end() //QString match_text)
{
 finalize_chi_tile();
 flags.chi_tile_context = false;
 document_->grammar()->activate_context("run-context");
 markup_position_.clear_chi_pointers();
// if(match_text.endsWith(';'))
// {

// }
}


void RZ_Lisp_Graph_Build::finalize_chi_tile()
{
 RZ_Lisp_Token* token = make_new_script_token(chi_acc_.trimmed());
 token->flags.is_chi_string_literal = true;
// RZ_Chi_Tile* rct = new RZ_Chi_Tile()
 add_literal_script_token(token);
 chi_acc_.clear();
}


void RZ_Lisp_Graph_Build::check_lara_acc(QString match_text)
{
 if(match_text == "(")
 {
  finalize_lara_token();
  document_->grammar()->activate_context("run-context");
  add_run_markup(match_text);
 }
 else if(match_text == ")")
 {
  finalize_lara_token();
  document_->grammar()->activate_context("run-context");
  add_run_markup(match_text);
 }
 else
  lara_acc_ += match_text;
}



void RZ_Lisp_Graph_Build::process_script_token(QString prefix, QString script_word)
{
 RZ_Lisp_Token* token = make_new_script_token(script_word);
 QChar c = prefix[0];
 switch(c.toLatin1())
 {
 case ':' : token->flags.is_keyword = true; break;
 case ',' : token->flags.is_symbol_declaration = true; break;
 case ';' : token->flags.is_captured_symbol_declaration = true; break;
 case '\'' : token->flags.is_quoted = true; break;
 default: ;
 }
 add_script_token(token);
}

void RZ_Lisp_Graph_Build::process_statement_closing_script_token(QString match_text)
{
 process_script_token(match_text);
 markup_position_.process_statement_end();
}


void RZ_Lisp_Graph_Build::process_quoted_script_token(QString quotes,
 QString match_text)
{
 Quoting_Formations qf = get_quoting_formation(quotes);

 if(qf == Quoting_Formation_Not_Recognized)
 {
  process_script_token(quotes + match_text);
  return;
 }

 RZ_Lisp_Token* token = make_new_script_token(match_text);

 switch(qf)
 {
 case Single:
  token->flags.is_quoted = true;
  add_script_token(token);
  break;

 case Double_Single:
  token->flags.is_double_quoted = true;
  add_script_token(token);
  break;

 case Backtick:
  token->flags.is_back_quoted = true;
  add_script_token(token);
  break;

 case Double_Backtick:
  token->flags.is_string_literal = true;
  token->flags.is_double_back_quoted = true;
  add_literal_script_token(token);
  break;

 default:
  break;
 }

}

void RZ_Lisp_Graph_Build::add_quote_phrase_separator(QString match_text, QString keyword)
{
 if(flags.quote_phrase_context)
 {
  check_quote_phrase_list(match_text, keyword);
  return;
 }
 else
  process_script_token(match_text);
}

void RZ_Lisp_Graph_Build::process_script_token(QString match_text)
{
 if(flags.quote_word_context)
 {
  RZ_Lisp_Token* token = make_new_script_token(match_text);
  token->flags.is_string_literal = true;
  add_script_token(token);
  return;
 }
 if(flags.quote_phrase_context)
 {
  quote_phrase_list_.push_back(match_text);
  return;
 }
 if(match_text == "<-")
 {
  markup_position_.add_inverted_arrow();
  return;
 }
 RZ_Lisp_Token* token = make_new_script_token(match_text);

//? if(Lara_Argument::check(match_text) != Lara_Argument::N_A)
//  token->flags.is_lara_argument = true;

// if()

 add_script_token(token);

 if(match_text == "lisp_")
  document_->grammar()->activate_context(QString("lisp-context"));

}

RZ_Lisp_Token* RZ_Lisp_Graph_Build::make_new_script_token(QString raw_text)
{
 return new RZ_Lisp_Token(raw_text, current_line_);
}


void RZ_Lisp_Graph_Build::close_run_markup_with_follow(QString markup, QString follow)
{
 check_apply_markup_formation_preliminary();

 Markup_Formations mf = get_markup_formation(follow);
 switch(mf)
 {
 case Star:
  flags.quote_word_context = false;
  break;
 case Tilde:
  check_quote_phrase_list();
  flags.quote_phrase_context = false;
  break;
 default: ;
 }
 add_run_markup(markup);
}

void RZ_Lisp_Graph_Build::check_quote_phrase_list(QString match_text, QString keyword)
{
 // //  Some data structures can be used to create either vectors or
 //     map/vector hybrids.  In this case a :: token separates strings
 //     in a vector, while a token like :key: indicated a new mapkey.
 //     Combining both forms in one structure yields either a
 //     map-of-vectors or a multi-map.  This function keeps track of
 //     the most recent separator and its form.  The keyword parameter
 //     indicates a :key: form or something equivalent (this function
 //     does not check syntax, so alternative syntaxes can be used for
 //     analogous graph formations, like -key- in lieu of :key:.

 if(!quote_phrase_list_.isEmpty())
 {
  RZ_Lisp_Token* token;
  if(flags.use_current_string_key)
  {
   token = make_new_script_token(current_string_key_);
   token->flags.is_string_key = true;
   flags.use_current_string_key = false;
  }
  else
  {
   token = make_new_script_token(current_string_key_);
  }
  if(keyword.isEmpty())
  {
   current_string_key_ = match_text;
  }
  else
  {
   current_string_key_ = keyword;
   flags.use_current_string_key = true;
  }

  RZ_Lisp_Node* token_node = make_new_node(token);
  markup_position_.add_token_node(token_node);

  RZ_String_Phrase* sp;
  if(flags.weighted_markup_formation)
   sp = new RZ_String_Phrase(quote_phrase_list_, current_weighted_markup_formation_weight_);
  else
   sp = new RZ_String_Phrase(quote_phrase_list_);
  RZ_Lisp_Node* value_node = new RZ_Lisp_Node(sp);
  token_node << rlq_.Static_Init_Value >> value_node;

  //?
  //markup_position_.connect_value_node(token_node, value_node);
  quote_phrase_list_.clear();
 }
 else if(flags.use_current_string_key)
 {
  current_string_key_ = keyword;
 }
 else if(!keyword.isEmpty())
 {
  current_string_key_ = keyword;
  flags.use_current_string_key = true;
 }
}


void RZ_Lisp_Graph_Build::add_run_markup(QString match_text)
{
 markup_position_.add_markup(match_text[0]);
 if(active_chief_token_)
 {
  if(active_chief_token_->flags.precedes_lara_argument)
   document_->grammar()->activate_context("lara-context");
 }
}

void RZ_Lisp_Graph_Build::add_run_prefixed_markup(QString prefix,
 QString markup)
{
 QString prelim;
 if(prefix.startsWith('#'))
 {
  prelim = "#";
  prefix = prefix.mid(1);
 }
 Markup_Formation_Preliminaries mfp = get_markup_formation_preliminary(prelim);
 Markup_Formations mf = get_markup_formation(prefix);
 QChar c = markup[0];

 switch(mf)
 {
 case Dot:
  markup_position_.add_dot_markup(c);
  break;

 case Double_Dot:
  markup_position_.add_double_dot_markup(c);
  break;

 case Markup_Formation_Not_Recognized:
  break;

 default:
  add_run_markup(c, mf, mfp);

  ;
 }

}

void RZ_Lisp_Graph_Build::check_apply_markup_formation_preliminary(Markup_Formation_Preliminaries mfp)
{
 switch(mfp)
 {
 case Markup_Formation_Use_Weighted:
  flags.weighted_markup_formation = true;
  current_weighted_markup_formation_weight_ = 1;
  break;
 default:
  flags.weighted_markup_formation = false;
  current_weighted_markup_formation_weight_ = 0;
  break;
 }
}

void RZ_Lisp_Graph_Build::add_run_markup(QChar prefix, Markup_Formations mf, Markup_Formation_Preliminaries mfp)
{
 switch(prefix.toLatin1())
 {
 case '[':
  add_run_vector_markup(mf);
  check_apply_markup_formation_preliminary(mfp);
  break;
 case '{':
  add_run_map_markup(mf);
  check_apply_markup_formation_preliminary(mfp);
  break;
 }
}

RZ_Lisp_Binary_Relation_Token::Relation_Labels
 RZ_Lisp_Graph_Build::get_call_sequence_relation()
{
 if(flags.quote_word_context)
  return RZ_Lisp_Binary_Relation_Token::Run_Vector_Sequence;

 if(flags.quote_phrase_context)
  return RZ_Lisp_Binary_Relation_Token::Run_Vector_Sequence;

 return RZ_Lisp_Binary_Relation_Token::Run_Call_Sequence;
}

void RZ_Lisp_Graph_Build::add_run_vector_markup(Markup_Formations mf)
{
 switch(mf)
 {
 case Star:
  flags.quote_word_context = true;
  markup_position_.add_vector_markup();
 case Double_Star:
  break;
 case Tilde:
 case Double_Tilde:
  flags.quote_phrase_context = true;
  markup_position_.add_vector_markup();
  break;
 }
}

void RZ_Lisp_Graph_Build::add_run_map_markup(Markup_Formations mf)
{
 switch(mf)
 {
 case Star:
  flags.quote_word_context = true;
  markup_position_.add_map_markup();
 case Double_Star:
  break;
 case Tilde:
 case Double_Tilde:
  flags.quote_phrase_context = true;
  markup_position_.add_map_markup();
  break;
 }
}


