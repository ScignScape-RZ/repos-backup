
#ifndef RZ_LISP_GRAPH_BUILD__H
#define RZ_LISP_GRAPH_BUILD__H

//#include "graph/rz-text-relation.h"
#include "rz-lisp-parser.h"

#include "flags.h"

#include "methodic.h"

#include "rz-lisp-parse-context.h"

#include "rz-lisp-frame.h"

#include "relations/rz-lisp-markup-position.h"

#include "relations/rz-lisp-binary-relation-token.h"

#include "query/rz-lisp-query.h"


#include <QStack>
#include <QSet>
#include <QStringList>

#include "rzns.h"
RZNS_(GBuild)

class RZ_Lisp_Document;
class RZ_Lisp_Parser;
class RZ_Lisp_Graph;
class RZ_Lisp_Command;

class RZ_Run_Token;
class RZ_Lisp_Token;
class RZ_Lisp_Node;

class RZ_Lisp_Graph_Build
{
 flags_(2)
  bool active_command_entry:1;
  bool math_mode:1;
  bool run_mode:1;
  bool skip_command_node_insert:1;
  bool chi_tile_context:1;

  bool quote_word_context:1;
  bool quote_phrase_context:1;
  bool use_current_string_key:1;

  bool weighted_markup_formation:1;

 _flags

 RZ_Lisp_Document* document_;
 RZ_Lisp_Parser& parser_;
 RZ_Lisp_Graph& graph_;

 QString math_acc_;
 QString current_string_key_;

 RZ_Lisp_Query rlq_;


 typedef RZ_Lisp_Binary_Relation_Token LBR;

 enum Position_States {
  Root_Position, Run_Sequence,
  Statement_Sequence
  //Sentence_Reset, Sentence_End, Sentence_Start,
  //Word_Sequence, Word_Chain,
  //  Command_End, // Section_End,
  //  Math_Mode
 };

 Position_States current_position_state_;

 enum Markup_Formation_Preliminaries {
  Markup_Formation_Normal,
  Markup_Formation_Use_Weighted
 };

 Markup_Formation_Preliminaries get_markup_formation_preliminary(QString s)
 {
  static QMap<QString, Markup_Formation_Preliminaries> static_map
  {{
    { "#", Markup_Formation_Use_Weighted },
  }};

  return static_map.value(s, Markup_Formation_Normal);
 }



 enum Markup_Formations {
  Markup_Formation_Not_Recognized,
  Dot, Double_Dot,
  Star, Double_Star,
  Tilde, Double_Tilde
 };

 Markup_Formations get_markup_formation(QString s)
 {
  static QMap<QString, Markup_Formations> static_map
  {{
    { ".", Dot },
    { "..", Double_Dot },
    { "*", Star },
    { "**", Double_Star },
    { "~", Tilde },
    { "~~", Double_Tilde },
  }};

  return static_map.value(s, Markup_Formation_Not_Recognized);
 }

 enum Quoting_Formations {
  Quoting_Formation_Not_Recognized, Single,
  Double_Single, Backtick, Double_Backtick
 };

 Quoting_Formations get_quoting_formation(QString s)
 {
  static QMap<QString, Quoting_Formations> static_map
  {{
    { "'", Single },
    { "''", Double_Single },
    { "`", Backtick },
    { "``", Double_Backtick },
  }};

  return static_map.value(s, Quoting_Formation_Not_Recognized);
 }


 RZ_Lisp_Node* current_node_;
 RZ_Lisp_Node* current_command_node_;
 RZ_Lisp_Node* root_node_;
 RZ_Lisp_Node* active_run_node_;
 RZ_Lisp_Token* active_chief_token_;

 RZ_Lisp_Parse_Context parse_context_;


 int current_line_;

 QStack<RZ_Lisp_Node*> parent_command_nodes_;

 QString string_literal_acc_;
 QString lara_acc_;
 QString lisp_acc_;
 QString chi_acc_;

 RZ_Lisp_Frame fr_;

 RZ_Lisp_Markup_Position markup_position_;


 QSet<QString> automatic_statement_closing_tokens_;

 QStringList quote_phrase_list_;

 int current_weighted_markup_formation_weight_;

public:

 RZ_METHODIC(RZ_Lisp_Document* ,document)
 RZ_METHODIC(RZ_Lisp_Node* ,current_node)
 RZ_METHODIC(RZ_Lisp_Node* ,root_node)
 RZ_METHODIC(RZ_Lisp_Node* ,active_run_node)
 RZ_METHODIC(RZ_Lisp_Token* ,active_chief_token)

// RZ_METHODIC(RZ_Run_Section* ,current_run_section)

 RZ_METHODIC_RGET(RZ_Lisp_Parse_Context ,parse_context)

 RZ_Lisp_Graph_Build(RZ_Lisp_Document* d,
  RZ_Lisp_Graph& g, RZ_Lisp_Parser& p);

 void init();
 void check_chi_begin_accumulate(RZ_Lisp_Node* chi_object_node, RZ_Lisp_Node* predicate_vector_chief_node);


 void check_new_lines(QString match_text);
 void check_new_print_lines(QString match_text);

 void check_quote_phrase_list(QString match_text = QString(), QString keyword = QString());

//{}

 RZ_Lisp_Token* make_new_script_token(QString raw_text);
 RZ_Lisp_Node* make_new_node(RZ_Lisp_Token* token);

 void add_quote_phrase_separator(QString match_text, QString keyword);

 void process_script_token(QString prefix, QString script_word);

 void process_statement_closing_script_token(QString match_text);
 void process_script_token(QString match_text);

 void process_quoted_script_token(QString quotes,
  QString match_text);


 void process_semis(int count);

 void add_run_markup(QString match_text);

 void close_run_markup_with_follow(QString markup, QString follow);

 void chi_syntax_entry(QString match_text);


 void insert_node(LBR rtoken, RZ_Lisp_Node* ctn);

 void attach_nodes(RZ_Lisp_Node* lhs, LBR rtoken, RZ_Lisp_Node* rhs);

 void add_rz_comment(QString match_text);

 void add_run_prefixed_markup(QString prefix, QString markup);

 void check_apply_markup_formation_preliminary(Markup_Formation_Preliminaries mfp = Markup_Formation_Normal);

 void add_run_markup(QChar prefix, Markup_Formations mf, Markup_Formation_Preliminaries mfp);
 void add_run_vector_markup(Markup_Formations mf);
 void add_run_map_markup(Markup_Formations mf);

// void add_run_dot_markup(QString match_text);

 void add_to_string_literal(QString str)
 {
  string_literal_acc_ += str;
 }

 RZ_Run_Token* process_string_literal();
//? RZ_Run_Token*
 void process_numeric_token(QString match_text);

 void add_script_token(RZ_Lisp_Token* token);
 void add_literal_script_token(RZ_Lisp_Token* token);

 void check_lara_token(QString script_word);
 void finalize_lara_token();

 void chi_tile_acc(QString match_text);
 void chi_tile_end(); //QString match_text);
 void finalize_chi_tile();

 void add_lara_token(QString match_text);
 void check_lara_acc(QString match_text);
 void check_lisp_acc(QString match_text);

 void check_lisp_token(QString match_text);
 void finalize_lisp_paste();

 void set_data_layer(QString s);

 RZ_Lisp_Binary_Relation_Token::Relation_Labels get_call_sequence_relation();


};

_RZNS(GBuild)

#endif
