
#include "rz-lisp-parse-context.h"

#include "rzns.h"
USING_RZNS(GBuild)

RZ_Lisp_Parse_Context::RZ_Lisp_Parse_Context()
 : Flags(0), current_open_print_node(nullptr)
{

}

