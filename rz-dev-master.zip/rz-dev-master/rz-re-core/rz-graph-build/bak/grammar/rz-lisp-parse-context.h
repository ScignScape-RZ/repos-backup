
#ifndef RZ_LISP_CONTEXT__H
#define RZ_LISP_CONTEXT__H

#include "flags.h"
#include "rz-typedefs.h"

#include <memory>

#include "rzns.h"
RZNS_(GBuild)

class RZ_Lisp_Node;

struct RZ_Lisp_Parse_Context
{
 typedef RZ_Lisp_Node tNode;

 flags_(2)
  flag_(1, multiline_comment);
  flag_(2, awaiting_run_entry);
  flag_(3, awaiting_run_sequence);
  flag_(4, inline_cmd);
  flag_(5, inside_command_arguments);
  flag_(6, inside_string_literal);
  flag_(7, parse_as_escaped_cdm);
  flag_(8, parse_as_latex);
  flag_(9, parse_as_data_page);
  flag_(10, awaiting_command_argument);
 _flags_


// typedef RZ_Script_Galaxy::tCon tCon;

// typedef typename tGraph::tNode tNode;
// typedef typename tGraph::tString Str;
// typedef typename tGraph::tCon tCon;
// typedef typename tGraph::tMid tMid;

 tNode* current_open_print_node;


 RZ_Lisp_Parse_Context();
  //, stacked_connectors_count(0) {}

};

_RZNS(GBuild)

#endif
