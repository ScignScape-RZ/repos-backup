
#include "rz-lisp-parser.h"

#include "rzns.h"
USING_RZNS(GBuild)

RZ_Lisp_Parser::RZ_Lisp_Parser(RZ_Lisp_Graph* g)
  : RZ_Generic_Parser(g) // RZ_Parser<RZ_Lisp_Galaxy>(g)
{}


QString RZ_Lisp_Parser::get_remainder()
{
 int pos = current_position + match_text().size();

 QString result = raw_text_.mid(pos);

 return result;


}


