
#ifndef RZ_LISP_PARSER__H
#define RZ_LISP_PARSER__H

#include "rz-parser/rz-regex.h"

//#include "rz-parser/rz-parser.h"

#include "methodic.h"

#include "rz-parser/rz-generic-parser.h"

#include "rzns.h"
RZNS_(GBuild)

class RZ_Lisp_Graph;

//struct RZ_Lisp_Galaxy
//{
// typedef RZ_Lisp_Graph tGraph;

//};


class RZ_Lisp_Graph;

class RZ_Lisp_Parser : public RZ_Generic_Parser //<RZ_Lisp_Galaxy>
{
// RZ_Lisp_Graph* graph_;
 QString raw_text_;


public:

// RZ_METHODIC(RZ_Lisp_Graph* ,graph)
 RZ_METHODIC(QString ,raw_text)

 RZ_Lisp_Parser(RZ_Lisp_Graph* g);

 QString get_remainder();


};

_RZNS(GBuild)

//#include "rz-parser/rz-regex.h"
//#include "rz-parser/rz-parser.h"

//#include "rz-text-typedefs.h"

//class RZ_Text_Parser : public RZ_Parser<RZ_Text_Galaxy>
//{
//public:
// RZ_Text_Parser(RZ_Text_Graph* g);
// void set_raw_text(QString s);


//};

//typedef RZ_Parser<RZ_Text_Galaxy> RZ_Text_Parser;

#endif
