
#include "rz-lisp-graph.h"

#include "rzns.h"
USING_RZNS(GBuild)

RZ_Lisp_Graph::RZ_Lisp_Graph()
 : root_node_(nullptr)
{}

