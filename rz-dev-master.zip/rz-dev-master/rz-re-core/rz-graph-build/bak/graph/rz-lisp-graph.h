
#ifndef RZ_LISP_GRAPH__H
#define RZ_LISP_GRAPH__H

#include "rz-lisp-node.h"

#include "rzns.h"
RZNS_(GBuild)

class RZ_Lisp_Parser;
class RZ_Lisp_Document;

class RZ_Lisp_Graph
{
 QList<RZ_Lisp_Node*> nodes_;

 RZ_Lisp_Node* root_node_;

 RZ_Lisp_Document* document_;

public:

 typedef RZ_Lisp_Parser tParser;
 typedef RZ_Lisp_Node tNode;

 RZ_METHODIC_RGET(QList<RZ_Lisp_Node*> ,nodes)
 RZ_METHODIC(RZ_Lisp_Node* ,root_node)
 RZ_METHODIC(RZ_Lisp_Document* ,document)

 RZ_Lisp_Graph();


};

_RZNS(GBuild)

#endif
