
#include "rz-lisp-node.h"

#include "rz-graph-token/rz-lisp-graph-value-holder.h"

#include <QDebug>

#include "rzns.h"
USING_RZNS(GBuild)


void RZ_Lisp_Node::to_vh(RZ_Lisp_Graph_Value_Holder& vh, RZ_Type_Object* tobj)
{
 vh.set_type_object(tobj);
 vh.set_direct_value(vertex_);
}


void RZ_Lisp_Node::attach_node(RZ_Lisp_Binary_Relation_Token rtoken,
//  RZ_Lisp_Kernel_Relation::Relation_Labels label,
 RZ_Lisp_Node* target_node)
{
 relation_nodes_.push_back(RZ_Lisp_Kernel_Relation(rtoken, target_node));
 QString lbl = rtoken.label_string();// RZ_Lisp_Kernel_Relation::static_label_string(rtoken);
 qDebug( ) << lbl;
}

RZ_Lisp_Node* RZ_Lisp_Node::find_relation(RZ_Lisp_Binary_Relation_Token rtoken)
{
 QMutableListIterator<RZ_Lisp_Kernel_Relation> it(relation_nodes_);
 while(it.hasNext())
 {
  RZ_Lisp_Kernel_Relation& rel = it.next();
  if(rel.rtoken() == rtoken)
  {
   ////  The question here is whether a single relations
   //    can appear multiple times in the list or
   //    just once with a list of targets.
   if(rel.target_nodes().isEmpty())
    continue;
   // return nullptr;

   return rel.target_nodes().first();
  }
 }
 return nullptr;
}

void RZ_Lisp_Node::delete_relation(tRel rtoken, RZ_Lisp_Node* target_node)
{
 QMutableListIterator<RZ_Lisp_Kernel_Relation> it(relation_nodes_);
 while(it.hasNext())
 {
  RZ_Lisp_Kernel_Relation& rel = it.next();
  if(rel.rtoken() == rtoken)
  {
   int i = rel.target_nodes().indexOf(target_node);
   if(i != -1)
   {
    rel.target_nodes().remove(i);
   }
   return;
  }
 }
}



void RZ_Lisp_Node::swap_relation(tRel rtoken,
 RZ_Lisp_Node* old_target_node, RZ_Lisp_Node* new_target_node)
{
 QMutableListIterator<RZ_Lisp_Kernel_Relation> it(relation_nodes_);
 while(it.hasNext())
 {
  RZ_Lisp_Kernel_Relation& rel = it.next();
  if(rel.rtoken() == rtoken)
  {
   int i = rel.target_nodes().indexOf(old_target_node);
   if(i != -1)
   {
    rel.target_nodes().replace(i, new_target_node);
//    RZ_Lisp_Node* n = rel.target_nodes().first();
//    QString s = n->label();
   }
   return;
  }
 }
}



void RZ_Lisp_Node::delete_relation(tRel rtoken)
{
 QMutableListIterator<RZ_Lisp_Kernel_Relation> it(relation_nodes_);
 while(it.hasNext())
 {
  RZ_Lisp_Kernel_Relation& rel = it.next();
  if(rel.rtoken() == rtoken)
  {
   rel.target_nodes().clear();
   return;
//   return rel.target_nodes().first();
  }
 }
}

