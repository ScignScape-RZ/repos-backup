
#ifndef RZ_LISP_NODE__H
#define RZ_LISP_NODE__H

#include "kernel/rz-lisp-kernel-types.h"

#include "kernel/rz-lisp-kernel-type-codes.h"

#include "kernel/rz-lisp-kernel-relation.h"

#include "rz-lisp-frame.h"

#include "rz-frame/graph/rz-minimal-node.h"
#include "rz-frame/graph/rz-abstract-node.h"

#include "relations/rz-lisp-binary-relation-token.h"

#include "rz-lisp-galaxy.h"

#include <QVector>
#include <QByteArray>

#include "rzns.h"

RZNS_(GVal)

class RZ_Lisp_Core_Function;
class RZ_Lisp_Lexical_Scope;
class RZ_Lisp_User_Resource;
class RZ_Lisp_User_Class;
class RZ_Chi_Object;
class RZ_Chi_Tile;
class RZ_Lisp_Vector;
class RZ_Lisp_Map;

_RZNS(GVal)


RZNS_(GEmbed)

class RZ_Graph_Embed_Token;

_RZNS(GEmbed)


USING_RZNS(GVal)
USING_RZNS(GEmbed)


RZNS_(GBuild)

USING_CTQNS(Frame)


// // replace this with #include
class RZ_Lisp_Token;
class RZ_Lisp_Root;
class RZ_Type_Object;
class RZ_Lisp_Graph_Value_Holder;

class RZ_Lisp_Node : public RZ_Minimal_Node,
 public RZ_Abstract_Node<RZ_Lisp_Galaxy> //, RZ_Lisp_Binary_Relation_Token>
{
 typedef RZ_Lisp_Binary_Relation_Token tRel;

 RZ_Lisp_Kernel_Types::Codes native_type_code_;

private:
 QList<RZ_Lisp_Kernel_Relation> relation_nodes_;

public:

 RZ_METHODIC_RGET(QList<RZ_Lisp_Kernel_Relation> ,relation_nodes)
 RZ_METHODIC(RZ_Lisp_Kernel_Types::Codes ,native_type_code)

//? RZ_METHODIC(void* ,vertex)

 template<typename T>
 RZ_Lisp_Node(T* t) : RZ_Minimal_Node(t)
 {
  native_type_code_ = RZ_Lisp_get_native_type_code<T>();
 }

 void attach_node(tRel rtoken,
  RZ_Lisp_Node* target_node);

 RZ_Lisp_Node* find_relation(tRel rtoken);

 void delete_relation(tRel rtoken);
 void delete_relation(tRel rtoken, RZ_Lisp_Node* target_node);

 void swap_relation(tRel rtoken,
  RZ_Lisp_Node* old_target_node, RZ_Lisp_Node* new_target_node);

 void to_vh(RZ_Lisp_Graph_Value_Holder& vh, RZ_Type_Object* tobj);


 #define CTQ_TEMP_MACRO(method_name, \
   type_name, type_code) \
  type_name* method_name() \
  { \
   if(native_type_code_ == RZ_Lisp_Kernel_Types::type_code) \
    return reinterpret_cast<type_name*>(vertex_); \
   return nullptr; \
  } \

 #define CTQ_TEMP_MACRO_NS(ns_name, method_name, type_name, type_code) \
  CTQ_TEMP_MACRO(method_name, type_name, type_code)

 #include "kernel/rz-lisp-kernel-type-list.h"

 #undef CTQ_TEMP_MACRO
 #undef CTQ_TEMP_MACRO_NS

 template<typename T>
 T* pValue_as()
 {
  if(native_type_code_ == RZ_Lisp_get_native_type_code<T>())
   return reinterpret_cast<T*>(vertex_);
  return nullptr;
 }

};

_RZNS(GBuild)

#endif
