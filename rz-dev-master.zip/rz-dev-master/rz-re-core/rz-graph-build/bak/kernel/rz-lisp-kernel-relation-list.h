
////  This is a list of relations and their
//    labels.  The CTQ_TEMP_MACRO has
//    different definitions depending
//    on where this file is included.

CTQ_TEMP_MACRO(Unknown, "Unknown")
CTQ_TEMP_MACRO(Run_Entry, "Run Entry")
CTQ_TEMP_MACRO(Run_Call_Entry, "Run Call Entry")
CTQ_TEMP_MACRO(Run_Call_Sequence, "Run Call Sequence")
CTQ_TEMP_MACRO(Run_Cross_Sequence, "Run Cross Sequence")


CTQ_TEMP_MACRO(Run_Embed_Redirect, "Run Embed Redirect")
CTQ_TEMP_MACRO(Run_Embed_Rename, "Run Embed Rename")

CTQ_TEMP_MACRO(Run_Block_Entry, "Run Block Entry")
CTQ_TEMP_MACRO(Run_Block_Sequence, "Run Block Sequence")

CTQ_TEMP_MACRO(Run_Block2_Entry, "Run Block2 Entry")

CTQ_TEMP_MACRO(Run_Lexical_Scope, "Run Lexical Scope")

CTQ_TEMP_MACRO(Run_Cross_Block, "Run Cross Block")
CTQ_TEMP_MACRO(Run_Continue_Sequence, "Run Continue Sequence")
CTQ_TEMP_MACRO(Run_Continue_Block, "Run Continue Block")
CTQ_TEMP_MACRO(Run_Vector_Sequence, "Run Vector Sequence")
CTQ_TEMP_MACRO(Run_Dot_List_Entry, "Run Dot List Entry")
CTQ_TEMP_MACRO(Run_Dot_List_Cross, "Run Dot List Cross")
CTQ_TEMP_MACRO(Run_Double_Dot_List_Entry, "Run Double Dot List Entry")
CTQ_TEMP_MACRO(Run_Double_Dot_List_Cross, "Run Double Dot List Cross")
CTQ_TEMP_MACRO(Run_Vector_Entry, "Run Vector Entry")
CTQ_TEMP_MACRO(Run_Dot_Vector_Entry, "Run Dot Vector Entry")
CTQ_TEMP_MACRO(Run_Dot_Vector_Cross, "Run Dot Vector Cross")
CTQ_TEMP_MACRO(Run_Double_Dot_Vector_Entry, "Run Double Dot Vector Entry")
CTQ_TEMP_MACRO(Run_Double_Dot_Vector_Cross, "Run Double Dot Vector Cross")
CTQ_TEMP_MACRO(Run_Map_Entry, "Run Map Entry")
CTQ_TEMP_MACRO(Run_Map_Cross, "Run Map Cross")
CTQ_TEMP_MACRO(Run_Double_Dot_Map_Entry, "Run Double Dot Map Entry")
CTQ_TEMP_MACRO(Run_Double_Dot_Map_Cross, "Run Double Dot Map Cross")

CTQ_TEMP_MACRO(Run_Assignment_Initialize_Type, "Run Assignment Initialize Type")
CTQ_TEMP_MACRO(Run_Assignment_Initialize_Type_Entry, "Run Assignment Initialize Type Entry")

CTQ_TEMP_MACRO(Run_Assignment_Initialize_Value, "Run Assignment Initialize Value")
CTQ_TEMP_MACRO(Run_Assignment_Initialize_Value_Entry, "Run Assignment Initialize Value Entry")

CTQ_TEMP_MACRO(Chi_Node_Value, "Chi Node Value")

CTQ_TEMP_MACRO(Static_Init_Value, "Static Init Value")

CTQ_TEMP_MACRO(Chi_Tuple_Entry, "Chi Tuple Entry")
CTQ_TEMP_MACRO(Chi_Tuple_Sequence, "Chi Tuple Sequence")
CTQ_TEMP_MACRO(Chi_Tuple_Continue, "Chi Tuple Continue")


CTQ_TEMP_MACRO(Retval_Follow, "Retval Follow")


