
#include "rz-lisp-kernel-relation.h"
#include "graph/rz-lisp-node.h"

#include <QDebug>

#include "rzns.h"
USING_RZNS(GBuild)

QString RZ_Lisp_Kernel_Relation::label_string() const
{
 return rtoken_.label_string();
}

void RZ_Lisp_Kernel_Relation::report() const
{
//? qDebug() << "\n For relation " << label_string()
//  << ": \n";

// for(RZ_Lisp_Node* ctn : target_nodes_)
// {
//  ctn->report();
// }
}

void RZ_Lisp_Kernel_Relation::delete_target(RZ_Lisp_Node* ctn)
{
 int index = target_nodes_.indexOf(ctn);
 if(index != -1)
  target_nodes_.remove(index);
}

