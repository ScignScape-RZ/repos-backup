
#ifndef RZ_LISP_KERNEL_RELATION__H
#define RZ_LISP_KERNEL_RELATION__H

#include "methodic.h"

#include "relations/rz-lisp-binary-relation-token.h"

#include <QVector>
#include <QString>


#include "rzns.h"
RZNS_(GBuild)

class RZ_Lisp_Node;

class RZ_Lisp_Kernel_Relation
{

private:
 RZ_Lisp_Binary_Relation_Token rtoken_;
// Relation_Labels label_;
 QVector<RZ_Lisp_Node*> target_nodes_;


public:
 RZ_METHODIC(RZ_Lisp_Binary_Relation_Token ,rtoken)
 RZ_METHODIC_RGET(QVector<RZ_Lisp_Node*> ,target_nodes)

 RZ_Lisp_Kernel_Relation(RZ_Lisp_Binary_Relation_Token rtoken, RZ_Lisp_Node* n)
  : rtoken_(rtoken)
 {
  target_nodes_.push_back(n);
 }

// static QString static_label_string(Relation_Labels lbl);
 QString label_string() const;
 void report() const;

 void delete_target(RZ_Lisp_Node* ctn);

};

_RZNS(GBuild)

#endif
