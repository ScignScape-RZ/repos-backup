
//class RZ_Lisp_Root;
//class RZ_Lisp_Command_Arguments;

#include "rz-lisp-kernel-type-codes.h"

//#include "rzns.h"
//USING_RZNS(GBuild)


//#define CTQ_TEMP_MACRO(method_name, \
// type_name, type_code) \
// class type_name; \
// template<> \
// struct RZ_Lisp_get_native_type_code_<type_name> \
// { \
//  static RZ_Lisp_Kernel_Types::Codes Code() \
//  { \
//   return RZ_Lisp_Kernel_Types::type_code; \
//  } \
// };

//RZNS_(GBuild)
////#include "rz-lisp-kernel-type-list.h"
//_RZNS(GBuild)

//#undef CTQ_TEMP_MACRO


//RZNS_(GBuild)

//template<typename T>
//RZ_Lisp_Kernel_Types::Codes RZ_Lisp_get_native_type_code()
//{
// return RZ_Lisp_Kernel_Types::N_A;
//}

//_RZNS(GBuild)





