
#ifndef RZ_LISP_KERNEL_TYPE_CODES__H
#define RZ_LISP_KERNEL_TYPE_CODES__H

#include <QString>

#include <QDebug>

#include "rz-lisp-kernel-types.h"

#include "rzns.h"

#define CTQ_TEMP_MACRO(method_name, \
 type_name, type_code) \
 class type_name; \

#define CTQ_TEMP_MACRO_NS(ns_name, method_name, \
 type_name, type_code) \
 RZNS_(ns_name) \
 class type_name; \
 _RZNS(ns_name)
#include "rz-lisp-kernel-type-list.namespaced.h"
#undef CTQ_TEMP_MACRO_NS
#undef CTQ_TEMP_MACRO



USING_RZNS(GVal)

RZNS_(GBuild)

template<typename T>
struct RZ_Lisp_get_native_type_code_
{
 static RZ_Lisp_Kernel_Types::Codes Code()
 {
  return RZ_Lisp_Kernel_Types::N_A;
 }
};


#define CTQ_TEMP_MACRO(method_name, \
 type_name, type_code) \
 template<> \
 struct RZ_Lisp_get_native_type_code_<type_name> \
 { \
  static void check_namespace() \
  { \
    qDebug() << "<global>"; \
  } \
  static RZ_Lisp_Kernel_Types::Codes Code() \
  { \
   return RZ_Lisp_Kernel_Types::type_code; \
  } \
 }; \

#define CTQ_TEMP_MACRO_NS(ns_name, method_name, type_name, type_code) \
 template<> \
 struct RZ_Lisp_get_native_type_code_<RZ::ns_name::type_name> \
 { \
  static void check_namespace() \
  { \
    qDebug() << #ns_name; \
  } \
  static RZ_Lisp_Kernel_Types::Codes Code() \
  { \
   return RZ_Lisp_Kernel_Types::type_code; \
  } \
 }; \


//?CTQ_TEMP_MACRO(method_name, type_name, type_code)

#include "rz-lisp-kernel-type-list.h"
#undef CTQ_TEMP_MACRO_NS
#undef CTQ_TEMP_MACRO



template<typename T>
RZ_Lisp_Kernel_Types::Codes RZ_Lisp_get_native_type_code()
{
 return RZ_Lisp_get_native_type_code_<T>::Code();
}

_RZNS(GBuild)

#endif



//#define CTQ_TEMP_MACRO(method_name, \
// type_name, type_code) \
// class type_name; \
// template<> \
// struct RZ_Lisp_get_native_type_code_<type_name> \
// { \
//  static RZ_Lisp_Kernel_Types::Codes Code() \
//  { \
//   return RZ_Lisp_Kernel_Types::type_code; \
//  } \
// }; \

//#include "rz-lisp-kernel-type-list.h"
//#undef CTQ_TEMP_MACRO
