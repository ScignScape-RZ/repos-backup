

////  This is a list of relevant types.
//    The CTQ_TEMP_MACRO has different
//    definitions depending on where
//    this file is included.

CTQ_TEMP_MACRO(string, QString, String)

#include "rz-lisp-kernel-type-list.namespaced.h"

