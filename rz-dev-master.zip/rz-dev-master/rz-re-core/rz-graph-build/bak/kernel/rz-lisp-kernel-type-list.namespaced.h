

////  This is a list of types which may be held by nodes.
//    The CTQ_TEMP_MACRO has different
//    definitions depending on where
//    this file is included.

CTQ_TEMP_MACRO_NS(GBuild, lisp_token, RZ_Lisp_Token, Lisp_Token)
CTQ_TEMP_MACRO_NS(GBuild, lisp_root, RZ_Lisp_Root, Lisp_Root)
CTQ_TEMP_MACRO_NS(GBuild, core_function, RZ_Lisp_Graph_Core_Function, Lisp_Graph_Core_Function)
CTQ_TEMP_MACRO_NS(GVal, lexical_scope, RZ_Lisp_Lexical_Scope, Lexical_Scope)
CTQ_TEMP_MACRO_NS(GVal, user_class, RZ_Lisp_User_Class, User_Class)
CTQ_TEMP_MACRO_NS(GVal, user_resouece, RZ_Lisp_User_Resource, User_Resource)
CTQ_TEMP_MACRO_NS(GVal, chi_object, RZ_Chi_Object, Chi_Object)
CTQ_TEMP_MACRO_NS(GVal, chi_tile, RZ_Chi_Tile, Chi_Tile)
CTQ_TEMP_MACRO_NS(GVal, vec, RZ_Lisp_Vector, Lisp_Vector)
CTQ_TEMP_MACRO_NS(GVal, map, RZ_Lisp_Map, Lisp_Map)
CTQ_TEMP_MACRO_NS(GBuild, string_phrase, RZ_String_Phrase, String_Phrase)
CTQ_TEMP_MACRO_NS(GEmbed, embed_token, RZ_Graph_Embed_Token, Embed_Token)

//CTQ_TEMP_MACRO(lisp_root, Ctq_Lisp_Root, Lisp_Root)
//CTQ_TEMP_MACRO(lisp_command, Ctq_Lisp_Command, Lisp_Command)
//CTQ_TEMP_MACRO(command_arguments, Ctq_Lisp_Command_Arguments, Command_Arguments)


//CTQ_TEMP_MACRO(sentence, Ctq_Text_Sentence, Sentence)
//CTQ_TEMP_MACRO(section, Ctq_Text_Section, Section)
//CTQ_TEMP_MACRO(word_token, Ctq_Word_Token, Word_Token)
//CTQ_TEMP_MACRO(word_chain, Ctq_Word_Chain, Word_Chain)
//CTQ_TEMP_MACRO(text_command, Ctq_Text_Command, Text_Command)
//CTQ_TEMP_MACRO(punctuation, Ctq_Punctuation, Punctuation)
//CTQ_TEMP_MACRO(special_character_sequence, Ctq_Special_Character_Sequence, Special_Character_Sequence)
//CTQ_TEMP_MACRO(math_segment, Ctq_Math_Segment, Math_Segment)
//CTQ_TEMP_MACRO(math_character_sequence, Ctq_Math_Character_Sequence, Math_Character_Sequence)
//CTQ_TEMP_MACRO(command_arguments, Ctq_Text_Command_Arguments, Command_Arguments)
//CTQ_TEMP_MACRO(run_section, Ctq_Run_Section, Run_Section)
//CTQ_TEMP_MACRO(run_output, Ctq_Run_Output, Run_Output)
//CTQ_TEMP_MACRO(run_token, Ctq_Run_Token, Run_Token)
//CTQ_TEMP_MACRO(run_markup, Ctq_Run_Markup, Run_Markup)
//CTQ_TEMP_MACRO(run_value, Ctq_Run_Value, Run_Value)
