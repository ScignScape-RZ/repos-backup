
#ifndef RZ_LISP_KERNEL_TYPES__H
#define RZ_LISP_KERNEL_TYPES__H

//#include "ctq-lisp-relation.h"

#include "methodic.h"

//class RZ_Lisp_Root;

#include "rzns.h"
RZNS_(GBuild)

class RZ_Lisp_Kernel_Types
{
public:

 enum Codes {
  N_A

#define CTQ_TEMP_MACRO(method_name, type_name, type_code) ,type_code
#define CTQ_TEMP_MACRO_NS(ns_name, method_name, type_name, type_code) \
 CTQ_TEMP_MACRO(method_name, type_name, type_code)
#include "rz-lisp-kernel-type-list.h"
#undef CTQ_TEMP_MACRO_NS
#undef CTQ_TEMP_MACRO
 };


};

_RZNS(GBuild)

#endif
