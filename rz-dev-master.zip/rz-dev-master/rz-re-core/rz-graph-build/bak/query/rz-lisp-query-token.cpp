
#include "rz-lisp-query-token.h"

#include "graph/rz-lisp-node.h"

//?#include "ctqns.h"
#include "rzns.h"

//?USING_CTQNS(Lisp)
USING_RZNS(GBuild)


RZ_Lisp_Query_Token::RZ_Lisp_Query_Token
 (RZ_Lisp_Binary_Relation_Token::Relation_Labels relation_label)
 : RZ_Abstract_Query_Token<RZ_Lisp_Galaxy>(relation_label)
{

}

