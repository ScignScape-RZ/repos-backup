
#ifndef RZ_LISP_QUERY_TOKEN__H
#define RZ_LISP_QUERY_TOKEN__H

#include "relations/rz-lisp-binary-relation-token.h"

#include "rzns.h"

#include "rz-lisp-galaxy.h"

#include "rz-frame/rz-abstract-query-token.h"

RZNS_(GBuild)

USING_CTQNS(Frame)

class RZ_Lisp_Node;

class RZ_Lisp_Query_Token : public RZ_Abstract_Query_Token<RZ_Lisp_Galaxy>
{

public:
 RZ_Lisp_Query_Token(RZ_Lisp_Binary_Relation_Token::Relation_Labels relation_label);

};


_RZNS(GBuild)


#endif
