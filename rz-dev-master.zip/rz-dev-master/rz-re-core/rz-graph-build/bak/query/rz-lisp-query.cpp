
#include "rz-lisp-query.h"

#include "rzns.h"

USING_RZNS(GBuild)

RZ_Lisp_Query::RZ_Lisp_Query()
 : query_text_()
   #define CTQ_TEMP_MACRO(relation_label, relation_text_name) \
    ,relation_label(RZ_Lisp_Query_Token(RZ_Lisp_Binary_Relation_Token::relation_label))
   #include "kernel/rz-lisp-kernel-relation-list.h"
   #undef CTQ_TEMP_MACRO
{


}
