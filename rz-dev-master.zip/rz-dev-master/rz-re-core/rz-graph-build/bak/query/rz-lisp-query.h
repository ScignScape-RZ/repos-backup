
#ifndef RZ_LISP_QUERY__H
#define RZ_LISP_QUERY__H

#include "rzns.h"

#include "rz-lisp-query-token.h"


//#include "flags.h"
#include "ns.h"

RZNS_(GBuild)

class RZ_Lisp_Query
{
 QString query_text_;
// flags_(1)
//  bool

// _flags

public:

#define CTQ_TEMP_MACRO(relation_label, relation_text_name) \
 RZ_Lisp_Query_Token relation_label;
#include "kernel/rz-lisp-kernel-relation-list.h"
#undef CTQ_TEMP_MACRO

 RZ_Lisp_Query();

};

_RZNS(GBuild)

#endif
