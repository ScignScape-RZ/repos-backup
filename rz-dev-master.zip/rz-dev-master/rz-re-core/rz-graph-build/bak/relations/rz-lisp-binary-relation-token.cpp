
#include "rz-lisp-binary-relation-token.h"

#include "rzns.h"
USING_RZNS(GBuild)

RZ_Lisp_Binary_Relation_Token::RZ_Lisp_Binary_Relation_Token
 (Relation_Labels relation_label)
  : relation_label_(relation_label)
{

}

QString RZ_Lisp_Binary_Relation_Token::static_label_string(Relation_Labels lbl)
{
 switch(lbl)
 {
  #define CTQ_TEMP_MACRO(relation_label, relation_text_name) \
 case relation_label: return relation_text_name;
  #include "kernel/rz-lisp-kernel-relation-list.h"
  #undef CTQ_TEMP_MACRO
 }
 return QString();
}

QString RZ_Lisp_Binary_Relation_Token::label_string() const
{
 return static_label_string(relation_label_);
}


