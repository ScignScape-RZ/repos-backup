
#ifndef RZ_LISP_BINARY_RELATION_TOKEN__H
#define RZ_LISP_BINARY_RELATION_TOKEN__H

//#include "kernel/rz-lisp-kernel-relation.h"

#include "methodic.h"

#include <QString>

#include "rzns.h"
RZNS_(GBuild)

class RZ_Lisp_Binary_Relation_Token
{
public:

 enum Relation_Labels
 {
  #define CTQ_TEMP_MACRO(relation_label, relation_text_name) relation_label,
  #include "kernel/rz-lisp-kernel-relation-list.h"
  #undef CTQ_TEMP_MACRO
 };

public:

 Relation_Labels relation_label_;


public:

 RZ_METHODIC_GET(Relation_Labels ,relation_label)

 RZ_Lisp_Binary_Relation_Token(Relation_Labels relation_label);

  static QString static_label_string(Relation_Labels lbl);
  QString label_string() const;

  bool operator==(RZ_Lisp_Binary_Relation_Token& rhs)
  {
   return relation_label_ == rhs.relation_label();
  }

};

_RZNS(GBuild)

#endif
