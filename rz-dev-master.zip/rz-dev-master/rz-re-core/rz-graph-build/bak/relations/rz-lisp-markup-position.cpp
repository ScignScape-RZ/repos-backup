
#include "rz-lisp-markup-position.h"

#include "grammar/rz-lisp-graph-build.h"
#include "graph/rz-lisp-node.h"
#include "token/rz-lisp-token.h"

//?#include "chi-forms/rz-chi-object.h"
//?#include "chi-forms/rz-chi-tile.h"

#include "rzns.h"

USING_RZNS(GBuild)


RZ_Lisp_Markup_Position::RZ_Lisp_Markup_Position
 (RZ_Lisp_Graph_Build* graph_build)
 : Flags(0), graph_build_(graph_build),
    active_relation_label_(tRel::Run_Block_Entry),
    dot_entry_markup_state_(Initial_Markup_State),
    active_run_token_(nullptr),
    block2_run_node_(nullptr),
    block_run_node_(nullptr),
    last_popped_chief_(nullptr),
    last_non_dot_token_node_(nullptr),
    last_arrow_node_(nullptr),
    last_unwind_node_(nullptr),
    first_dot_list_node_(nullptr),
    active_assign_initialization_node_(nullptr),
    active_initialization_type_node_(nullptr),
    current_depth_(0), current_chi_object_(nullptr),
    current_chi_tile_(nullptr),
    current_markup_state_(Initial_Markup_State)
{
 connection_map = QMap< State_Addition_Pair, State_Connection_Pair >({
  #include "rz-lisp-markup.connection-map.h"
  });
}

void RZ_Lisp_Markup_Position::handle_add_token_node(tNode* ctn)
{
 handle_add_token_node(ctn, current_markup_state_);
}

void RZ_Lisp_Markup_Position::handle_add_token_node(tNode* ctn, RZ_Lisp_Markup_States markup_state)
{
 RZ_Lisp_Token* tok = ctn->lisp_token();
// n->pRestore<RZ_Lisp_Token>();
// n->set_label(nt->string_value);

 switch(markup_state)
 {
 case RZ_Lisp_Markup_Position::Open_Paren_Entry:
// ?  list_entry_map[ctn] = graph_build_->active_run_node();
  break;
 case RZ_Lisp_Markup_Position::Double_Dot_Open_Paren_Entry:
 case RZ_Lisp_Markup_Position::Dot_Open_Paren_Entry:
 case RZ_Lisp_Markup_Position::Dot_Open_Bracket_Entry:
 case RZ_Lisp_Markup_Position::Open_Bracket_Entry:
  if(!first_dot_list_node_)
   first_dot_list_node_ = ctn;
  break;
 default: break;
 }

}

void RZ_Lisp_Markup_Position::add_vector_markup()
{
 add_markup<Open_Bracket>();
}

void RZ_Lisp_Markup_Position::add_map_markup()
{
 add_markup<Open_Brace>();
}


void RZ_Lisp_Markup_Position::add_dot_markup(QChar c)
{
 switch(c.toLatin1())
 {
 case '(': add_markup<Dot_Open_Paren>(); break;
 case '{': add_markup<Dot_Open_Brace>(); break;
 case '[': add_markup<Dot_Open_Bracket>(); break;
 default: break;
 }
}

void RZ_Lisp_Markup_Position::add_double_dot_markup(QChar c)
{
 switch(c.toLatin1())
 {
 case '(': add_markup<Double_Dot_Open_Paren>(); break;
// case '{': add_markup<Dot_Open_Brace>(); break;
// case '[': add_markup<Dot_Open_Bracket>(); break;
 default: break;
 }
}


void RZ_Lisp_Markup_Position::add_markup(QChar c)
{
 switch(c.toLatin1())
 {
 case '(': add_markup<Open_Paren>(); break;
 case '{': add_markup<Open_Brace>(); break;
 case '[': add_markup<Open_Bracket>(); break;
 case ')': add_markup<Close_Paren>(); break;
 case '}': add_markup<Close_Brace>(); break;
 case ']': add_markup<Close_Bracket>(); break;
 default: break;
 }

}

void RZ_Lisp_Markup_Position::connect_value_node(tNode* token_node, tNode* value_node)
{
 graph_build_->attach_nodes(token_node,
  tRel::Static_Init_Value, value_node);
}


void RZ_Lisp_Markup_Position::check_chi_begin_accumulate()
{
 if(current_chi_tile_)
 {
  if(last_popped_chief_)
  {
//?   graph_build_->check_chi_begin_accumulate(current_chi_tile_->node(), last_popped_chief_);
  }
 }
 else if(current_chi_object_)
 {
  if(last_popped_chief_)
  {
//?   graph_build_->check_chi_begin_accumulate(current_chi_object_->node(), last_popped_chief_);
  }
 }
}


void RZ_Lisp_Markup_Position::standard_add_markup(const State_Connection_Pair scp)
{
 current_markup_state_ = scp.state;
 active_relation_label_ = scp.relation_label;
 current_depth_ += scp.depth_offset;
 switch(scp.extra_action)
 {
 case Do_Nothing: break;
 case Pop_Chief:
  last_popped_chief_ = chiefs.pop();
  check_chi_begin_accumulate();
  graph_build_->set_active_run_node(last_popped_chief_);
  set_active_run_token();
  if(!chiefs.empty())
  {
   graph_build_->set_active_chief_token(
    chiefs.top()->lisp_token());
  }
  check_dot_tuple_context();
//  qDebug() << "Popped token " << active_run_token->string_value;
  break;
 case Push_Chief: break;
 case Push_Paren:
  mark_stack.push(RZ_Lisp_Markup_Stack::Mark_Paren);
  break;
 case Push_Bracket:
  mark_stack.push(RZ_Lisp_Markup_Stack::Mark_Bracket);
  break;
 case Push_Brace:
  mark_stack.push(RZ_Lisp_Markup_Stack::Mark_Brace);
  break;
 case Pop_Block_Chief:
  graph_build_->set_active_run_node(block_chiefs.pop());
  set_active_run_token();
//  qDebug() << "Popped token " << active_run_token->string_value;
  break;
 case Push_Empty_Double_Dot_Paren_Pair:
  insert_empty_tuple_node(RZ_Lisp_Empty_Tuple::Empty_Double_Dot_List);
  break;
 case Push_Empty_Dot_Paren_Pair:
  insert_empty_tuple_node(RZ_Lisp_Empty_Tuple::Empty_Dot_List);
  break;
 case Push_Empty_Paren_Pair:
  insert_empty_tuple_node(RZ_Lisp_Empty_Tuple::Empty_List);
  break;
 }
}

void RZ_Lisp_Markup_Position::insert_empty_tuple_node(RZ_Lisp_Empty_Tuple::Empty_Tuple_Kinds k)
{
 tNode* node_to_insert;

 // //  We save this node in case we need it
 //     as a pre_arrow_node_ for a dot-tuple
 tNode* previous_active_node = graph_build_->active_run_node();

 last_unwind_node_ = previous_active_node;

 bool surrounding_dot_tuple_context = flags.dot_tuple_context;

 bool use_run_cross = current_markup_state_ != Active_Cross_Token;
 // //  TODO: distinguish whether there is an active cross token,
 //     which would mean a _Cross or _Empty relation token here...
 switch(k)
 {
 case RZ_Lisp_Empty_Tuple::Empty_List:
  node_to_insert = add_empty_tuple_node(RZ_Lisp_Empty_Tuple::Empty_List,
     use_run_cross? tRel::Run_Cross_Sequence : tRel::Run_Call_Entry);
  handle_add_token_node(node_to_insert, Open_Paren_Entry);
  check_dot_tuple_context(Open_Paren_Entry, previous_active_node);
  break;

 case RZ_Lisp_Empty_Tuple::Empty_Double_Dot_List:
  node_to_insert = add_empty_tuple_node(RZ_Lisp_Empty_Tuple::Empty_Double_Dot_List,
    use_run_cross? tRel::Run_Double_Dot_List_Cross: tRel::Run_Double_Dot_List_Entry);
  handle_add_token_node(node_to_insert, Double_Dot_Open_Paren_Entry);
  check_dot_tuple_context(Double_Dot_Open_Paren_Entry, previous_active_node);
  break;

 case RZ_Lisp_Empty_Tuple::Empty_Dot_List:
  node_to_insert = add_empty_tuple_node(RZ_Lisp_Empty_Tuple::Empty_Dot_List,
    use_run_cross? tRel::Run_Dot_List_Cross: tRel::Run_Dot_List_Entry);
  handle_add_token_node(node_to_insert, Dot_Open_Paren_Entry);
  check_dot_tuple_context(Dot_Open_Paren_Entry, previous_active_node);
  break;

 case RZ_Lisp_Empty_Tuple::Empty_Double_Dot_Vector:
  node_to_insert = add_empty_tuple_node(RZ_Lisp_Empty_Tuple::Empty_Double_Dot_Vector,
    use_run_cross? tRel::Run_Double_Dot_Vector_Cross: tRel::Run_Double_Dot_Vector_Entry);
  handle_add_token_node(node_to_insert, Double_Dot_Open_Bracket_Entry);
  check_dot_tuple_context(Double_Dot_Open_Bracket_Entry, previous_active_node);
  break;

 case RZ_Lisp_Empty_Tuple::Empty_Dot_Vector:
  node_to_insert = add_empty_tuple_node(RZ_Lisp_Empty_Tuple::Empty_Dot_Vector,
    use_run_cross? tRel::Run_Dot_Vector_Cross: tRel::Run_Dot_Vector_Entry);
  handle_add_token_node(node_to_insert, Dot_Open_Bracket_Entry);
  check_dot_tuple_context(Dot_Open_Bracket_Entry, previous_active_node);
  break;

 case RZ_Lisp_Empty_Tuple::Empty_Double_Dot_Map:
  node_to_insert = add_empty_tuple_node(RZ_Lisp_Empty_Tuple::Empty_Double_Dot_Map,
    use_run_cross? tRel::Run_Double_Dot_Map_Cross: tRel::Run_Double_Dot_Map_Entry);
  handle_add_token_node(node_to_insert, Double_Dot_Open_Brace_Entry);
  check_dot_tuple_context(Double_Dot_Open_Brace_Entry, previous_active_node);
  break;

 }
 // //
 flags.dot_tuple_context = surrounding_dot_tuple_context;
// graph_build_->set_active_run_node(node_to_insert);

}


RZ_Lisp_Markup_Position::tNode* RZ_Lisp_Markup_Position::add_empty_tuple_node
  (RZ_Lisp_Empty_Tuple::Empty_Tuple_Kinds k, rLabel rt)
{
 //? //  This function does not set the graph_build_->active_run_node ...
 RZ_Lisp_Empty_Tuple* value = new RZ_Lisp_Empty_Tuple(k);
 RZ_Lisp_Token* token = graph_build_->make_new_script_token(value->get_string_value());
 token->set_value(value);
 token->flags.is_empty_tuple = true;
 tNode* result = graph_build_->make_new_node(token);
 value->set_node(result);
 graph_build_->insert_node(rt, result);
 current_markup_state_ = Active_Cross_Token;
 graph_build_->set_active_run_node(result);
 last_popped_chief_ = result;
 return result;
}

void RZ_Lisp_Markup_Position::set_active_run_token()
{
 active_run_token_ = graph_build_->active_run_node()->lisp_token();
 active_run_token_->set_syntactic_depth(current_depth_);
}


void RZ_Lisp_Markup_Position::process_statement_end()
{
 add_markup<Single_Semi>();
}


void RZ_Lisp_Markup_Position::process_semis(int count, tNode* node)
{
 switch(count)
 {
 case 1:
  process_statement_end();
  break;
 case 2:
  graph_build_->set_active_run_node(block2_run_node_);
  active_relation_label_ =  tRel::Run_Cross_Sequence;//&RZ_Connect.Lisp_Cross_Sequence;
  current_markup_state_ = Open_Semi;
  set_active_run_token();
  break;
 default:
  process_statement_end();
//?  add_statement_closing_node(node);
  break;
// case 2: add_markup_entry<Single_Semi>(); break;
 }
}

void RZ_Lisp_Markup_Position::add_statement_closing_node(tNode* node)
{
 // // the node has already been added...
 add_token_node(node);

 process_statement_end();
//? add_markup<Single_Semi>();
}

void RZ_Lisp_Markup_Position::add_inverted_arrow()
{
 active_assign_initialization_node_ = graph_build_->active_run_node();
 if(active_assign_initialization_node_)
 {
  active_assign_initialization_node_->lisp_token()->flags.has_assignment_initialization = true;
 }
// graph_build_->insert_node(tRel::Run_Assignment_Initialize, ctn);
// graph_build_->set_active_run_node(ctn);
}


void RZ_Lisp_Markup_Position::add_arrow_node(tNode* ctn)
{
 //// The arrow is inserted between a setter and
 //   dot-tuple entry node
 if(flags.setter_context && flags.dot_tuple_context)
 {
//  insert_arrow_node(n);
  mark_non_leaf(ctn);
  flags.arrow_context = true;
  return;
 }

// if(flags.setter_context)
// {
//  flags.setter_context = false;
// }

 if(current_markup_state_ == Active_Cross_Token)
 {
  insert_arrow_node_non_dot_context(ctn);
  mark_non_leaf(ctn);
  flags.arrow_context = true;
  return;
 }

 graph_build_->insert_node(active_relation_label_, ctn);

//? graph_build_->active_run_node() <<active_relation_label_>> ctn;

 mark_non_leaf();
 check_dot_tuple_context();
 tNode* previous_active_node = graph_build_->active_run_node();
 graph_build_->set_active_run_node(ctn);
 check_chief(previous_active_node);

 set_active_run_token();

 if(flags.setter_context)
 {
  flags.setter_context = false;
  active_run_token_->flags.is_declaration_arrow = true;
 }
 else
 {
  //// Confirming that the current token is a call arrow
  //   set_active_run_token() has just set this token
  //   to the vertex in ctn.
  active_run_token_->flags.is_call_arrow = true;
 }
 active_relation_label_ = tRel::Run_Call_Sequence;
 current_markup_state_ = Active_Token;

 flags.setter_context = false;

 //? flags.arrow_context = true;

}

void RZ_Lisp_Markup_Position::insert_arrow_node_non_dot_context
 (tNode* arrow_node_to_add)
{
// tNode* pre_arrow_node = last_non_dot_token_node_ || last_popped_chief_;
// tNode* first_dot_list_node;
// tRel::Relation_Labels dot_relation;

 if(last_non_dot_token_node_)
 {
  switch(dot_entry_markup_state_)
  {
  case Dot_Open_Paren_Entry:
   insert_arrow_node(arrow_node_to_add, last_non_dot_token_node_,
    tRel::Run_Dot_List_Entry, tRel::Run_Dot_List_Cross);
   break;
  case Double_Dot_Open_Paren_Entry:
   insert_arrow_node(arrow_node_to_add, last_non_dot_token_node_,
    tRel::Run_Double_Dot_List_Entry, tRel::Run_Double_Dot_List_Cross);
   break;
  case Dot_Open_Bracket_Entry:
   insert_arrow_node(arrow_node_to_add, last_non_dot_token_node_,
    tRel::Run_Dot_Vector_Entry, tRel::Run_Dot_Vector_Cross);
   break;
  case Double_Dot_Open_Bracket_Entry:
   insert_arrow_node(arrow_node_to_add, last_non_dot_token_node_,
    tRel::Run_Double_Dot_Vector_Entry, tRel::Run_Double_Dot_Vector_Cross);
   break;
//?  case Double_Dot_Open_Bracet_Entry:
//   insert_arrow_node(arrow_node_to_add, last_non_dot_token_node_,
//    tRel::Run_Double_Dot_Map_Entry);
//   break;
  }
 }
 else
 {
  first_dot_list_node_ = last_popped_chief_;
  insert_arrow_node(arrow_node_to_add, last_unwind_node_,
   tRel::Run_Call_Entry);
 }

 last_non_dot_token_node_ = nullptr;
 flags.dot_tuple_context = false;
 flags.pre_arrow_context = false;
 dot_entry_markup_state_ = Initial_Markup_State;
 first_dot_list_node_ = nullptr;
 current_markup_state_ = Block2_Entry;
 active_relation_label_ = tRel::Run_Block2_Entry;
// if( list_entry_map.contains(graph_build_->active_run_node()))
// {
//  pre_arrow_node = list_entry_map[graph_build_->active_run_node()];
//  first_dot_list_node = graph_build_->active_run_node();
//  dot_relation = tRel::Run_Call_Entry;
//  insert_arrow_node(arrow_node_to_add, pre_arrow_node, first_dot_list_node,
//   dot_relation);
// }
// else if( dot_list_entry_map.contains(graph_build_->active_run_node()))
// {
//  pre_arrow_node = dot_list_entry_map[graph_build_->active_run_node()];
//  first_dot_list_node = graph_build_->active_run_node();
//  dot_relation = tRel::Run_Dot_List_Entry;
//  insert_arrow_node(arrow_node_to_add, pre_arrow_node, first_dot_list_node,
//   dot_relation);
// }
// else if( dot_vector_entry_map.contains(graph_build_->active_run_node()))
// {
//  pre_arrow_node = dot_vector_entry_map[graph_build_->active_run_node()];
//  first_dot_list_node = graph_build_->active_run_node();
//  dot_relation = tRel::Run_Dot_Vector_Entry;
//  insert_arrow_node(arrow_node_to_add, pre_arrow_node, first_dot_list_node,
//   dot_relation);
// }

}

//// These will be called with the current active node
//   corresponding to an entry node confirming that
//   an arrow represents a function definition.
//   This dot-tuple node and its sequents must be moved
//   between the arrow node and this entry node.
void RZ_Lisp_Markup_Position::insert_arrow_node(tNode* arrow_node_to_add,
 tNode* pre_arrow_node,
 tRel::Relation_Labels dot_relation, tRel::Relation_Labels dot_cross_relation)
{
 if(!pre_arrow_node)
  return;

 // //  First check if the pre_arrow_node_ has a dot-cross relation
 //     which would mean that a regular list started the signature
 //     (because the pre_arrow_node_ would then be nested)

 if(tNode* cross = pre_arrow_node->find_relation(dot_cross_relation))
 {
  // //  this depends on last_unwind_node_ being the true pre_arrow_node_:
  //     note: this means no nested lists inside non-dotted parameter
  //     tuples, so only <- style type specifications are possible there.
  //     (that is, regular lisp lambda lists are not fully supported).
  //     If users wants them they can just use .[...] or initial
  //     ..(...) syntax.
  // //  Also, we should have cross == first_dot_list_node_ until ...
  if(cross != first_dot_list_node_)
  {
   // ?
   qDebug() << "Unexpected node " << cross->label();
   return;
  }
  first_dot_list_node_ = pre_arrow_node;
  insert_arrow_node(arrow_node_to_add, last_unwind_node_, tRel::Run_Call_Entry);
 }
 else
 {
  insert_arrow_node(arrow_node_to_add, pre_arrow_node, dot_relation);
 }
}

void RZ_Lisp_Markup_Position::insert_arrow_node(tNode* arrow_node_to_add,
 tNode* pre_arrow_node,
 tRel::Relation_Labels dot_relation)
{
 if(!pre_arrow_node)
  return;
 pre_arrow_node->delete_relation(dot_relation, first_dot_list_node_);

 graph_build_->attach_nodes(pre_arrow_node,
  tRel::Run_Call_Entry, arrow_node_to_add);

 graph_build_->attach_nodes(arrow_node_to_add, dot_relation, first_dot_list_node_);
 RZ_Lisp_Token* token = arrow_node_to_add->lisp_token();
 token->flags.is_declaration_arrow = true;
}


RZ_Lisp_Markup_Position::tNode*
  RZ_Lisp_Markup_Position::check_assignment_initialization_end(tNode* node_to_add)
{
 // //   Currently result is set to
 //      active_assign_initialization_node_
 //      in case this pointer is then cleared,
 //      even though this return value is
 //      not used, except that its being
 //      non-null indicates that the new
 //      node has already been inserted
 tNode* result = nullptr;
 if(active_assign_initialization_node_)
 {
  if(tNode* n = graph_build_->active_run_node())
  {
   if(n == active_assign_initialization_node_)
   {
    RZ_Lisp_Token* tok = node_to_add->lisp_token();
    if(!tok)
    {
     // ?
    }
    else if(active_initialization_type_node_)
    {
     result = active_assign_initialization_node_;
     graph_build_->insert_node(tRel::Run_Assignment_Initialize_Type, active_initialization_type_node_);
     graph_build_->insert_node(tRel::Run_Assignment_Initialize_Value, node_to_add);
     active_assign_initialization_node_ = nullptr;
     active_initialization_type_node_ = nullptr;
    }
    else if(tok->flags.final_question_mark)
    {
     result = active_assign_initialization_node_;
     active_initialization_type_node_ = node_to_add;
    }
    else if(tok->flags.initial_question_mark)
    {
     result = active_assign_initialization_node_;
     graph_build_->insert_node(tRel::Run_Assignment_Initialize_Value, node_to_add);
     active_assign_initialization_node_ = nullptr;
     active_initialization_type_node_ = nullptr;
    }
    else
    {
     result = active_assign_initialization_node_;
     graph_build_->insert_node(tRel::Run_Assignment_Initialize_Type, node_to_add);
     active_assign_initialization_node_ = nullptr;
     active_initialization_type_node_ = nullptr;
    }
   }
  }
 }
 return result;
}


void RZ_Lisp_Markup_Position::add_lara_node(tNode* node)
{
 if(active_run_token_)
  active_run_token_->flags.precedes_lara_argument = true;
 add_token_node(node);
}

void RZ_Lisp_Markup_Position::clear_chi_pointers()
{
 current_chi_object_ = nullptr;
 current_chi_tile_ = nullptr;
}


void RZ_Lisp_Markup_Position::add_chi_entry(tNode* n, RZ_Chi_Object* rco, RZ_Chi_Tile* rct) //RZ_Chi_Form::Chi_Syntax_Formations csf)
{
 if(rco)
 {
  current_chi_object_ = rco;
 }
 if(rct)
 {
  current_chi_tile_ = rct;
 }

//? RZ_Chi_Form::Chi_Syntax_Formations csf = rct? rct->csf() : current_chi_object_->csf();
// switch(csf)
// {
// case RZ_Chi_Form::String_Vector:
// case RZ_Chi_Form::Token_Vector:
//  add_markup<Open_Bracket>();
//  break;

// case RZ_Chi_Form::String_Map:
// case RZ_Chi_Form::Token_Map:
//  add_markup<Open_Brace>();
//  break;

// default:
//  break;
// }

//// if(active_run_token_)
////  active_run_token_->flags.precedes_lara_argument = true;
//// RZ_Lisp_Node
}



void RZ_Lisp_Markup_Position::add_token_node(tNode* ctn)
{
 RZ_Lisp_Token* tok = ctn->lisp_token();
#ifdef RZ_LABEL_NODES
  ctn->set_label(tok->string_value());
#endif
// n->set_label(nt->string_value);

 // //  This checks if adding the one token node
 //     will cause an assignment_initialization
 //     to end, as in .(x <- int ...)
 tNode* check_assignment_initialization_node =
   check_assignment_initialization_end(ctn);

 if(check_assignment_initialization_node)
  return;
 handle_add_token_node(ctn);

 graph_build_->insert_node(active_relation_label_, ctn);
//  active_run_node()
//   << active_relation_label_ >> ctn;

 check_run_markup_stack();

 mark_non_leaf();
 check_dot_tuple_context();
 tNode* previous_active_node = graph_build_->active_run_node();
 graph_build_->set_active_run_node(ctn);
 set_active_run_token(tok);
 check_chief(previous_active_node);
 check_block_chief();

 confirm_arrow_context();
 check_arrow_context();

 set_active_relation_label
   (graph_build_->get_call_sequence_relation());//  tRel::Run_Call_Sequence);

 // active_run_connector = &RZ_Connect.Lisp_Call_Sequence;
 set_current_markup_state
  (RZ_Lisp_Markup_Position::Active_Token);

 check_setter_token();
}


void RZ_Lisp_Markup_Position::check_run_markup_stack()
{
 if(mark_stack.empty())
  return;

//?
// RZ_Script_Relation* relation_vertex =
//  active_run_node->match_relation(active_run_connector);
// if(relation_vertex)
// {
//  relation_vertex->add_markup_stack(mark_stack);
//  mark_stack.clear();
// }
}

void RZ_Lisp_Markup_Position::check_dot_tuple_context()
{
 check_dot_tuple_context(current_markup_state_, graph_build_->active_run_node());
}


//// Reserves the current token node in case the
//   node being added is inside a dot_tuple context.
//   In the event of an arrow operator after one
//   or more dotted tuples, the graph will be
//   immediately rearranged with a Lisp_Call_Entry
//   between this reserved node and the arrow node.
void RZ_Lisp_Markup_Position::check_dot_tuple_context
  (RZ_Lisp_Markup_States markup_state, tNode* active_node)
{
 switch(markup_state)
 {
 case Dot_Open_Paren_Entry:
 case Dot_Open_Brace_Entry:
 case Dot_Open_Bracket_Entry:
 case Double_Dot_Open_Paren_Entry:
  if(!flags.dot_tuple_context && !flags.pre_arrow_context)
  {
   last_non_dot_token_node_ = active_node;
   flags.dot_tuple_context = true;
   flags.pre_arrow_context = true;
   dot_entry_markup_state_ = markup_state;
  }
  break;

//? case Close_Paren:
// case Close_Brace:
// case Close_Bracket:

 case Active_Cross_Token:
  flags.dot_tuple_context = false;
  break;
 default:
//  last_non_dot_token_node = graph_build_->active_run_node();
//  RZ_Lisp_Token* tok = last_non_dot_token_node->pRestore<RZ_Lisp_Token>();
//  qDebug() << tok->string_value;

//  flags.dot_tuple_context = false;
  break;
 }
}

void RZ_Lisp_Markup_Position::check_arrow_context()
{
 switch(current_markup_state_)
 {
 case Open_Paren_Entry:
 case Dot_Open_Paren_Entry:
 case Dot_Open_Brace_Entry:
 case Dot_Open_Bracket_Entry:
// case Close_Paren:
// case Close_Brace:
// case Close_Bracket:
  break;
 default:
  flags.arrow_context = false;
  break;
 }

}


void RZ_Lisp_Markup_Position::check_setter_token()
{
 switch(current_markup_state_)
 {
 case Active_Token:
  if(flags.dot_tuple_context)
   break;
  flags.setter_context = active_run_token_->string_value().endsWith("=");
  break;
 case Dot_Open_Paren_Entry:
 case Dot_Open_Brace_Entry:
 case Dot_Open_Bracket_Entry:
 case Close_Paren:
 case Close_Brace:
 case Close_Bracket:
  break;
 default:
  flags.setter_context = false;
  break;

 }
}

void RZ_Lisp_Markup_Position::mark_non_leaf()
{
 mark_non_leaf(active_run_token_);
}

void RZ_Lisp_Markup_Position::mark_non_leaf(tNode* ctn)
{
 mark_non_leaf(ctn->lisp_token());
}

void RZ_Lisp_Markup_Position::mark_non_leaf(RZ_Lisp_Token* crt)
{
 if(crt)
  crt->flags.is_non_leaf = true;
}

//// This function will check whether adding a token node
//   will confirm that an arrow represents a function definition,
//   and syntactically enter a new lexical scope if so.
void RZ_Lisp_Markup_Position::confirm_arrow_context()
{
 if(flags.dot_tuple_context)
 {
  return;// false;
 }
 if(flags.arrow_context)
 {
  if(current_markup_state_ == Open_Paren_Entry)
   return;
//  qDebug() << "  Setting arrow context ... " << active_run_token->string_value;

  push_block2_run_node();
//  fix_graph_with_arrow_context();
  chiefs.push(graph_build_->active_run_node());
  flags.arrow_context = false;
 }
 else
 {
 }
}


void RZ_Lisp_Markup_Position::push_block2_run_node()
{
 if(flags.arrow_context)
 {
  if(chiefs.empty())
   return;
  block2_run_node_ = chiefs.top();
//  qDebug()<< " \n BRN: " << block_run_node->pRestore<RZ_Lisp_Token>()->string_value;
 }
// block_run_nodes.push(block_run_node);
}

void RZ_Lisp_Markup_Position::pop_block2_run_node()
{
// block_run_node = block_run_nodes.pop();
}

void RZ_Lisp_Markup_Position::check_chief(tNode* previous_active_node)
{
 switch(current_markup_state_)
 {
 case Open_Paren_Entry:
  last_unwind_node_ = previous_active_node;
  // //  last_popped_chief_ would be for (...) (...) situations...
//?  last_unwind_node_ = last_popped_chief_;
  //fallthrough
 case Initial_Markup_State:
 case Dot_Open_Paren_Entry:
 case Double_Dot_Open_Paren_Entry:
 case Dot_Open_Brace_Entry:
 case Double_Dot_Open_Brace_Entry:
 case Dot_Open_Bracket_Entry:
 case Double_Dot_Open_Bracket_Entry:
 case Open_Brace_Entry:
 case Open_Bracket_Entry:
 case Open_Semi:
  chiefs.push(graph_build_->active_run_node());
  break;

 default: break;
// case Active_Token: add_markup<Active_Token, New_Markup>(); break;
// case Active_Cross_Token: add_markup<Active_Cross_Token, New_Markup>(); break;
// case Open_Paren_Entry: add_markup<Open_Paren_Entry, New_Markup>(); break;
// case Open_Brace_Entry: add_markup<Open_Brace_Entry, New_Markup>(); break;
// case Open_Bracket_Entry: add_markup<Open_Bracket_Entry, New_Markup>(); break;
// case Open_Block_Entry: add_markup<Open_Block_Entry, New_Markup>(); break;
 }

}

void RZ_Lisp_Markup_Position::check_block_chief()
{
 switch(current_markup_state_)
 {
 case Active_Cross_Block_Token:
 case Open_Brace_Entry:
  block_chiefs.push(graph_build_->active_run_node());
  //chiefs.push(active_run_node);
  block_run_node_ = graph_build_->active_run_node();
  break;
 case Block2_Entry:
  block2_chiefs.push(graph_build_->active_run_node());
  break;
 default: break;
 }

}





