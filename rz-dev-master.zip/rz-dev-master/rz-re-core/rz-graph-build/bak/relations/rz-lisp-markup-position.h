
#ifndef RZ_LISP_MARKUP_POSITION__H
#define RZ_LISP_MARKUP_POSITION__H

#include "methodic.h"
#include "flags.h"

#include "relations/rz-lisp-binary-relation-token.h"

#include "graph/rz-lisp-node.h"

//#include "graph/rz-text-relation.h"

#include "rz-lisp-markup-stack.h"

#include "types/rz-lisp-empty-tuple.h"

//?#include "chi-forms/rz-chi-form.h"

#include <QList>
#include <QStack>
#include <QMap>
#include <QVector>

#include "rzns.h"

RZNS_(GBuild)

//?USING_RZNS(GVal)

class RZ_Lisp_Token;
class RZ_Lisp_Graph_Build;

//?class RZ_Chi_Object;
//class RZ_Chi_Tile;

class RZ_Lisp_Markup_Position
{
public:
 flags_(1)
  flag_(1, setter_context);
  flag_(2, arrow_context);
  flag_(3, dot_tuple_context);
  flag_(4, inside_string_literal);
  flag_(5, inside_compact_regex);
  flag_(6, inside_long_regex);
  flag_(7, pre_arrow_context);
 _flags_

private:

 typedef RZ_Lisp_Binary_Relation_Token tRel;
 typedef tRel::Relation_Labels rLabel;


 enum RZ_Lisp_Markup_States
 {
  Initial_Markup_State, Active_Token, Active_Cross_Token, Active_Continue_Token,
  Active_Cross_Block_Token, Open_Paren_Entry,

  Block2_Entry,

  Open_Brace_Entry, Open_Bracket_Entry,
  Dot_Open_Paren_Entry,
  Double_Dot_Open_Paren_Entry,
  Dot_Open_Brace_Entry,
  Double_Dot_Open_Brace_Entry,
  Dot_Open_Bracket_Entry,
  Double_Dot_Open_Bracket_Entry,
  Open_Semi, Syntax_Error
 };

 enum RZ_Lisp_Markup_Additions
 {
  Token, Open_Paren, Close_Paren, Open_Brace, Close_Brace,
  Open_Bracket, Close_Bracket, Open_Chi, Close_Chi,
  Single_Semi, Dot_Open_Paren, Double_Dot_Open_Paren,
  Dot_Open_Brace, Double_Dot_Open_Brace,
  Dot_Open_Bracket, Double_Dot_Open_Bracket
 };

 enum RZ_Lisp_Markup_Addition_Extra_Action
 {
  Do_Nothing, Push_Chief, Pop_Chief,

   Push_Paren, Push_Empty_Paren_Pair,
   Push_Bracket, Push_Empty_Bracket_Pair,
   Push_Brace, Push_Empty_Brace_Pair,

  Push_Dot_Paren, Push_Empty_Dot_Paren_Pair,
  Push_Dot_Bracket, Push_Empty_Dot_Bracket_Pair,
  Push_Dot_Brace, Push_Empty_Dot_Brace_Pair,

  Push_Double_Dot_Paren, Push_Empty_Double_Dot_Paren_Pair,
  Push_Double_Dot_Bracket, Push_Empty_Double_Dot_Bracket_Pair,
  Push_Double_Dot_Brace, Push_Empty_Double_Dot_Brace_Pair,


   Pop_Block_Chief, Raise_Error
 };

 struct State_Addition_Pair
 {
  RZ_Lisp_Markup_States state;
  RZ_Lisp_Markup_Additions addition;
  friend bool operator<(const State_Addition_Pair& lhs, const State_Addition_Pair& rhs)
  {
   if(lhs.state == rhs.state)
    return lhs.addition < rhs.addition;
   return lhs.state < rhs.state;
  }
 };

 struct State_Connection_Pair
 {
  RZ_Lisp_Markup_States state;
  rLabel relation_label;
  int depth_offset;
  RZ_Lisp_Markup_Addition_Extra_Action extra_action;
 };


 RZ_Lisp_Markup_States current_markup_state_;

 typedef RZ_Lisp_Node tNode;

 rLabel active_relation_label_;

// tNode* active_run_node;
// void add_data_text(tNode* data_text_next, tNode*& last_node);
 RZ_Lisp_Graph_Build* graph_build_;
 RZ_Lisp_Token* active_run_token_;

 //tNode* added_run_node;

 tNode* block_run_node_;
 tNode* block2_run_node_;
 tNode* last_non_dot_token_node_;
 tNode* last_arrow_node_;
 tNode* last_unwind_node_;
 tNode* first_dot_list_node_;
 tNode* last_popped_chief_;

 RZ_Chi_Object* current_chi_object_;
 RZ_Chi_Tile* current_chi_tile_;

 tNode* active_assign_initialization_node_;
 tNode* active_initialization_type_node_;

 RZ_Lisp_Markup_States dot_entry_markup_state_;

 int current_depth_;
// RZ_Script_Connector_Prototypes& RZ_Connect;
 QString acc;
 QStack<tNode*> chiefs;
 QStack<tNode*> block_chiefs;
 QStack<tNode*> block2_chiefs;

 //tStack<tNode*> branches;

 //tStack<tNode*> block_run_nodes;

 QMap< State_Addition_Pair, State_Connection_Pair> connection_map;

// QMap< tNode*, tNode* > dot_list_entry_map;
// QMap< tNode*, tNode* > dot_vector_entry_map;
// QMap< tNode*, tNode* > list_entry_map;
// QMap< tNode*, tNode* > vector_entry_map;

public:

 RZ_METHODIC(rLabel ,active_relation_label)
 RZ_METHODIC(RZ_Lisp_Token* ,active_run_token)
 RZ_METHODIC(RZ_Lisp_Markup_States ,current_markup_state)

//? RZ_METHODIC(RZ_Chi_Object* ,current_chi_object)

 RZ_Lisp_Markup_Position(RZ_Lisp_Graph_Build* graph_build);

 RZ_Lisp_Markup_Stack::Stack_type mark_stack;

 void process_semis(int count, tNode* node);

 void process_statement_end();

 void clear_chi_pointers();

 void connect_value_node(tNode* token_node, tNode* value_node);
 // void add_markup_entry(QChar c);
// void add_dot_markup_entry(QChar c);

 void add_markup(QChar c);
 void add_dot_markup(QChar c);
 void add_double_dot_markup(QChar c);

 void add_vector_markup();
 void add_map_markup();


 void add_inverted_arrow();

 void insert_empty_tuple_node(RZ_Lisp_Empty_Tuple::Empty_Tuple_Kinds k);

 void add_statement_closing_node(tNode* node);

 void add_lara_node(tNode* node);

 void handle_add_token_node(tNode* ctn);
 void handle_add_token_node(tNode* ctn, RZ_Lisp_Markup_States markup_state);

 void check_setter_token();
 void check_arrow_context();
 void check_dot_tuple_context();
 void check_dot_tuple_context(RZ_Lisp_Markup_States markup_state, tNode* active_node);
 void check_chief(tNode* previous_active_node);
 void check_block_chief();
 void add_token_node(tNode* ctn);
 void mark_non_leaf(RZ_Lisp_Token* crt);

 void insert_arrow_node(tNode* arrow_node_to_add,
  tNode* pre_arrow_node,
  rLabel dot_relation, tRel::Relation_Labels dot_cross_relation);

 void insert_arrow_node(tNode* arrow_node_to_add,
  tNode* pre_arrow_node,
  rLabel dot_relation);


 void insert_arrow_node_non_dot_context(tNode* arrow_node_to_add);

 RZ_Lisp_Markup_Position::tNode* add_empty_tuple_node(RZ_Lisp_Empty_Tuple::Empty_Tuple_Kinds k, rLabel rt);

 tNode* check_assignment_initialization_end(tNode* node_to_add);
 void confirm_arrow_context();
 void mark_non_leaf();
 void push_block2_run_node();
 void pop_block2_run_node();
 void check_run_markup_stack();
 void set_active_run_token();
 void standard_add_markup(const State_Connection_Pair scp);
 void add_arrow_node(tNode* ctn);
 inline void mark_non_leaf(tNode* ctn);

 void check_chi_begin_accumulate();

 void add_chi_entry(tNode* n, RZ_Chi_Object* rco, RZ_Chi_Tile* rct);

 void add_chi_entry(tNode* n, RZ_Chi_Object* rco)
 {
  add_chi_entry(n, rco, nullptr);
 }

 void add_chi_entry(tNode* n, RZ_Chi_Tile* rct)
 {
  add_chi_entry(n, nullptr, rct);
 }

// void insert_arrow_node_non_dot_context(tNode* arrow_node_to_add);

 template<RZ_Lisp_Markup_Additions New_Markup>
 void add_markup()
 {
  switch(current_markup_state_)
  {
  case Initial_Markup_State: add_markup<Initial_Markup_State, New_Markup>(); break;
  case Active_Token: add_markup<Active_Token, New_Markup>(); break;
  case Active_Cross_Token: add_markup<Active_Cross_Token, New_Markup>(); break;
  case Open_Semi: add_markup<Open_Semi, New_Markup>(); break;
  case Active_Cross_Block_Token: add_markup<Active_Cross_Block_Token, New_Markup>(); break;

   // // An "Entry" markup here implies either a closed
   //    empty tuple or a nested tuple as the first element
   //    of its enclosing tuple
  case Open_Paren_Entry: add_markup<Open_Paren_Entry, New_Markup>(); break;
  case Open_Brace_Entry: add_markup<Open_Brace_Entry, New_Markup>(); break;
  case Open_Bracket_Entry: add_markup<Open_Bracket_Entry, New_Markup>(); break;
//  case Open_Block_Entry: add_markup<Open_Block_Entry, New_Markup>(); break;

  case Dot_Open_Paren_Entry: add_markup<Dot_Open_Paren_Entry, New_Markup>(); break;
  case Double_Dot_Open_Paren_Entry: add_markup<Double_Dot_Open_Paren_Entry, New_Markup>(); break;

  case Dot_Open_Bracket_Entry: add_markup<Dot_Open_Bracket_Entry, New_Markup>(); break;
  case Double_Dot_Open_Bracket_Entry: add_markup<Double_Dot_Open_Bracket_Entry, New_Markup>(); break;

  case Dot_Open_Brace_Entry: add_markup<Dot_Open_Brace_Entry, New_Markup>(); break;
  case Double_Dot_Open_Brace_Entry: add_markup<Double_Dot_Open_Brace_Entry, New_Markup>(); break;

  }

 }

 template<RZ_Lisp_Markup_States Current_State, RZ_Lisp_Markup_Additions New_Markup>
 void add_markup()
 {
  State_Addition_Pair sap{Current_State, New_Markup};
  if(connection_map.contains(sap))
  {
   const State_Connection_Pair scp = connection_map[sap];
   standard_add_markup( scp );
  }
 }


};


_RZNS(GBuild)

#endif
