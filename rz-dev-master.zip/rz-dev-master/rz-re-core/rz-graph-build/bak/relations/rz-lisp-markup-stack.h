
#ifndef RZ_LISP_MARKUP_STACK__H
#define RZ_LISP_MARKUP_STACK__H

//#include "methodic.h"
//#include "flags.h"

//#include "graph/rz-text-relation.h"

#include <QStack>

//class RZ_Run_Token;

struct RZ_Lisp_Markup_Stack
{
 enum Markup_Types
 {
  Mark_Paren, Mark_Brace, Mark_Bracket
 };

 typedef QStack<RZ_Lisp_Markup_Stack::Markup_Types> Stack_type;
 Stack_type marks;
 RZ_Lisp_Markup_Stack(Stack_type& st):marks(st){}

};


#endif
