
////  This file is included into ctq-syntax-markup.h
//    It is used to initialize a map of connections
//    defining which connnector prototype and which
//    subsequent markup state is needed based on
//    the current markup state and new markup or nodes.

//    The left element in each pair is a state/new markup
//    pair, and the right element is a state/connector pair.
//    The connector represents the connection to the next
//    node to be added, and the state is used in case
//    subsequent syntactic markup is introduced before
//    the addition of a node.  The add_token_node
//    function will set the current markup state to
//    Active_Token and the connector to Run_Call_Sequence.

//Initial_Markup_State, Active_Token, Open_Paren_Entry,
//Open_Brace_Entry, Open_Bracket_Entry, Open_Block_Entry, Syntax_Error

//Token, Open_Paren, Close_Paren, Open_Brace, Close_Brace,
//Open_Bracket, Close_Bracket

{ {Initial_Markup_State, Token},
 {Active_Token, tRel::Run_Call_Entry, 0, Do_Nothing} },

{ {Initial_Markup_State, Open_Paren},
 {Open_Paren_Entry, tRel::Run_Call_Entry, 1, Do_Nothing} },

{ {Initial_Markup_State, Open_Brace},
 {Open_Brace_Entry, tRel::Run_Block_Entry, 1, Do_Nothing} },

{ {Initial_Markup_State, Dot_Open_Paren},
 {Dot_Open_Paren_Entry, tRel::Run_Dot_List_Entry, 1, Do_Nothing} },



{ {Active_Token, Token},
 {Active_Token, tRel::Run_Call_Sequence, Do_Nothing} },

{ {Active_Token, Open_Paren},
 {Open_Paren_Entry, tRel::Run_Call_Entry, 1, Do_Nothing} },

{ {Active_Token, Open_Brace},
 {Open_Brace_Entry, tRel::Run_Block_Entry, 1, Do_Nothing} },

{ {Active_Token, Open_Bracket},
 {Open_Bracket_Entry, tRel::Run_Vector_Entry, 1, Do_Nothing} },





{ {Active_Token, Dot_Open_Paren},
 {Dot_Open_Paren_Entry, tRel::Run_Dot_List_Entry, 1, Do_Nothing} },

{ {Active_Cross_Token, Dot_Open_Paren},
 {Dot_Open_Paren_Entry, tRel::Run_Dot_List_Cross, 1, Do_Nothing} },


{ {Active_Token, Double_Dot_Open_Paren},
 {Double_Dot_Open_Paren_Entry, tRel::Run_Double_Dot_List_Entry, 1, Do_Nothing} },

{ {Active_Cross_Token, Double_Dot_Open_Paren},
 {Double_Dot_Open_Paren_Entry, tRel::Run_Double_Dot_List_Cross, 1, Do_Nothing} },


{ {Active_Token, Dot_Open_Bracket},
 {Dot_Open_Bracket_Entry, tRel::Run_Dot_Vector_Entry, 1, Do_Nothing} },

{ {Active_Cross_Token, Dot_Open_Bracket},
 {Dot_Open_Bracket_Entry, tRel::Run_Dot_Vector_Cross, 1, Do_Nothing} },



{ {Active_Token, Close_Paren},
 {Active_Cross_Token, tRel::Run_Continue_Sequence, -1, Pop_Chief} },

{ {Active_Token, Close_Brace},
 {Syntax_Error, tRel::Run_Continue_Block, -1, Pop_Block_Chief} },

{ {Active_Token, Close_Bracket},
 {Active_Cross_Token, tRel::Run_Continue_Sequence, -1, Pop_Chief} },

{ {Active_Token, Single_Semi},
 {Open_Semi, tRel::Run_Cross_Sequence, 0, Pop_Chief} },




{ {Open_Semi, Token},
 {Active_Token, tRel::Run_Call_Sequence, Do_Nothing} },

{ {Open_Semi, Open_Paren},
 {Open_Paren_Entry, tRel::Run_Call_Entry, 1, Do_Nothing} },

{ {Open_Semi, Dot_Open_Paren},
 {Dot_Open_Paren_Entry, tRel::Run_Dot_List_Entry, 1, Do_Nothing} },

{ {Open_Semi, Close_Paren},
 {Syntax_Error, tRel::Run_Continue_Sequence, 1, Raise_Error} },

{ {Open_Semi, Close_Brace},
 {Active_Cross_Block_Token, tRel::Run_Continue_Block, 1, Pop_Block_Chief} },



{ {Open_Paren_Entry, Open_Paren},
 {Open_Paren_Entry, tRel::Run_Call_Entry, 1, Push_Paren} },

//{ {Open_Paren_Entry, Open_Bracket},
// {Open_Bracket_Entry, tRel::Run_Dot_List_Entry, Do_Nothing} },

//{ {Open_Paren_Entry, Close_Paren},
// {Syntax_Error, tRel::Run_Continue_Sequence, Raise_Error} },

//{ {Open_Paren_Entry, Close_Brace},
// {Active_Cross_Block_Token, tRel::Run_Continue_Block, Pop_Block_Chief} },





//{ {Open_Semi, Single_Semi},
// {Open_Semi, tRel::Run_Cross_Sequence, Pop_Chief} },





{ {Active_Cross_Token, Token},
 {Active_Token, tRel::Run_Continue_Sequence, Do_Nothing} },

{ {Active_Cross_Token, Open_Paren},
 {Open_Paren_Entry, tRel::Run_Cross_Sequence, 1, Do_Nothing} },

{ {Active_Cross_Token, Open_Brace},
 {Open_Brace_Entry, tRel::Run_Block_Entry, 1, Do_Nothing} },

{ {Active_Cross_Token, Open_Bracket},
 {Active_Token, tRel::Run_Vector_Sequence, 1, Do_Nothing} },

{ {Active_Cross_Token, Close_Paren},
 {Active_Cross_Token, tRel::Run_Continue_Sequence, -1, Pop_Chief} },



{ {Active_Cross_Token, Close_Brace},
 {Active_Token, tRel::Run_Continue_Block, -1, Do_Nothing} },



{ {Active_Cross_Token, Single_Semi},
 {Open_Semi, tRel::Run_Cross_Sequence, -1, Pop_Chief} },



{ {Active_Cross_Block_Token, Open_Brace},
 {Open_Brace_Entry, tRel::Run_Cross_Block, 1, Do_Nothing} },

{ {Active_Cross_Block_Token, Single_Semi},
 {Active_Cross_Token, tRel::Run_Cross_Sequence, Pop_Chief} },

//{ {Active_Cross_Token, Open_Paren},
// {Open_Paren_Entry, tRel::Run_Cross_Sequence, Do_Nothing} },

//{ {Active_Cross_Token, Open_Brace},
// {Open_Brace_Entry, tRel::Run_Block_Entry, Do_Nothing} },

//{ {Active_Cross_Token, Close_Paren},
// {Active_Token, tRel::Run_Continue_Sequence, Do_Nothing} },

//{ {Active_Cross_Token, Close_Brace},
// {Active_Token, tRel::Run_Continue_Block, Do_Nothing} },

//{ {Active_Cross_Token, Single_Semi},
// {Open_Semi, tRel::Run_Cross_Sequence, Pop_Chief} },

{ {Double_Dot_Open_Paren_Entry, Close_Paren},
 {Active_Cross_Token, tRel::Run_Continue_Sequence, 0, Push_Empty_Double_Dot_Paren_Pair} },

{ {Dot_Open_Paren_Entry, Close_Paren},
 {Active_Cross_Token, tRel::Run_Continue_Sequence, 0, Push_Empty_Dot_Paren_Pair} },

{ {Open_Paren_Entry, Close_Paren},
 {Active_Cross_Token, tRel::Run_Continue_Sequence, 0, Push_Empty_Paren_Pair} },


{ {Double_Dot_Open_Bracket_Entry, Close_Bracket},
 {Active_Cross_Token, tRel::Run_Continue_Sequence, 0, Push_Empty_Double_Dot_Bracket_Pair} },

{ {Dot_Open_Bracket_Entry, Close_Bracket},
 {Active_Cross_Token, tRel::Run_Continue_Sequence, 0, Push_Empty_Dot_Bracket_Pair} },

{ {Open_Bracket_Entry, Close_Bracket},
 {Active_Cross_Token, tRel::Run_Continue_Sequence, 0, Push_Empty_Bracket_Pair} },



{ {Double_Dot_Open_Brace_Entry, Close_Brace},
 {Active_Cross_Token, tRel::Run_Continue_Sequence, 0, Push_Empty_Double_Dot_Brace_Pair} },

{ {Dot_Open_Bracket_Entry, Close_Brace},
 {Active_Cross_Token, tRel::Run_Continue_Sequence, 0, Push_Empty_Dot_Brace_Pair} },

{ {Open_Bracket_Entry, Close_Brace},
 {Active_Cross_Token, tRel::Run_Continue_Sequence, 0, Push_Empty_Brace_Pair} },



