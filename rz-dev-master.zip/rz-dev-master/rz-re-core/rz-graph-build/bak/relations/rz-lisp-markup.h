
#ifndef RZ_LISP_MARKUP__H
#define RZ_LISP_MARKUP__H

#include "methodic.h"
#include "flags.h"


#include <QList>

#include "rzns.h"

RZNS_(GBuild)


class RZ_Lisp_Token;

class RZ_Lisp_Markup
{

};

_RZNS(GBuild)


#endif
