
#include "rz-lisp-frame.h"

#include "graph/rz-lisp-node.h"

#include <QDebug>

#include "rzns.h"
USING_RZNS(GBuild)

void RZ_Lisp_Frame::connect_nodes(RZ_Lisp_Node* source_node,
 RZ_Lisp_Binary_Relation_Token rtoken,
 RZ_Lisp_Node* target_node)
{
 source_node->attach_node(rtoken, target_node);
}

void RZ_Lisp_Frame::connect_nodes_while_inactive(RZ_Lisp_Node* source_node,
 RZ_Lisp_Binary_Relation_Token rtoken, RZ_Lisp_Node* target_node)
{
}
