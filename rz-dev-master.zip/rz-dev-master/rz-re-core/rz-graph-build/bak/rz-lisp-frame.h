
#ifndef RZ_LISP_FRAME__H
#define RZ_LISP_FRAME__H

#include "kernel/rz-lisp-kernel-relation.h"

#include "relations/rz-lisp-binary-relation-token.h"

#include "rz-frame/rz-abstract-frame.h"

#include "rz-lisp-galaxy.h"

#include "rzns.h"


RZNS_(GBuild)

USING_CTQNS(Frame)



class RZ_Lisp_Frame : public RZ_Abstract_Frame<RZ_Lisp_Galaxy>
{
 bool active_;

public:

 bool is_active()
 {
  return active_;
 }

 void activate()
 {
  active_ = true;
 }


 void report() const{}

 void attach_lisp_node(RZ_Lisp_Binary_Relation_Token rtoken,
  RZ_Lisp_Node* target_node);

 void connect_nodes(RZ_Lisp_Node* source_node,
  RZ_Lisp_Binary_Relation_Token rtoken,
  RZ_Lisp_Node* target_node);

// void connect_nodes(RZ_Lisp_Node* source_node,
//  RZ_Lisp_Node* target_node);

 void connect_nodes_while_inactive(RZ_Lisp_Node* source_node,
  RZ_Lisp_Binary_Relation_Token rtoken,
  RZ_Lisp_Node* target_node);


};

_RZNS(GBuild)

#endif
