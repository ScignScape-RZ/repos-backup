
#ifndef RZ_CONSOLE_GALAXY__H
#define RZ_CONSOLE_GALAXY__H

#include "rzns.h"

RZNS_(GBuild)

class RZ_Lisp_Node;
class RZ_Lisp_Frame;
class RZ_Lisp_Binary_Relation_Token;

struct RZ_Lisp_Galaxy
{
 typedef RZ_Lisp_Node tNode;
 typedef RZ_Lisp_Frame tFrame;
 typedef RZ_Lisp_Binary_Relation_Token tRel;
};

_RZNS(GBuild)

#endif
