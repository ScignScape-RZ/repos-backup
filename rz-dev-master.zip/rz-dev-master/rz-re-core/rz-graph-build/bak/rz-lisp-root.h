
#ifndef RZ_LISP_ROOT__H
#define RZ_LISP_ROOT__H

#include "rzns.h"

RZNS_(GBuild)

class RZ_Lisp_Root
{



};

_RZNS(GBuild)


#endif
