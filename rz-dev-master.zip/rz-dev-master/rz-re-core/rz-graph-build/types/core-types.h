#ifndef CORE__CORE_TYPES__H
#define CORE__CORE_TYPES__H

//#include "valuer/ctq-symbol.h"
//#include "user/ctq-user-function.h"
//#include "user/ctq-user-class.h"

#include "rz-graph-valuer/string/rz-string.h"

#include "rz-graph-valuer/valuer/rz-lisp-symbol.h"

#include "types/run-types.h"

#include "rz-graph-valuer/valuer/rz-opaque-call.h"
#include "rz-graph-valuer/valuer/rz-opaque-type-symbol.h"
#include "rz-graph-token/valuer/rz-null-value.h"

//#include "run/rz-lisp-core-function.h"
//class RZ_Lisp_Core_Function;

#include "rzns.h"
//RZNS_(GBuild)

#define RZ_RUN_TYPE_NS(ns_name, enum_name, name, cpp_name, haskell_name, fam) \
 RZNS_(ns_name) \
 class cpp_name; \
 _RZNS(ns_name)
#include "types/type-codes.namespaced.h"
#undef RZ_RUN_TYPE_NS

//class RZ_Lisp_Core_Function;
//class RZ_Lisp_Function_Definition;
//class RZ_Lisp_Empty_Tuple;
//class RZ_Lisp_User_Class;
//class RZ_Lisp_User_Resource;
//class RZ_Lara_Form;
//class RZ_Chi_Form;
//class RZ_Chi_Object;
//class RZ_Chi_Tile;


//class RZ_Opaque_Type_Symbol;



#include "types/run-type-codes.h"

#endif
