#ifndef TYPES__RUN_TYPE_CODES__H
#define TYPES__RUN_TYPE_CODES__H

//#include "types/run-type-value.h"

//struct Ctq_Core_Function_Token;
//struct Ctq_Rule;
//struct Ctq_Simplex;
//struct Ctq_Match;
//struct Ctq_Keyword;

#include "rzns.h"


RZNS_(GBuild)


class RZ_Symbol;


#define RZ_RUN_TYPE(enum_name, name, cpp_name, haskell_name, fam) \
 template<> \
 struct RZ_Run_Type<RZ_Run_Types::enum_name> \
 { \
  typedef cpp_name Type; \
  static const RZ_Type_Families::Enum Type_Family = RZ_Type_Families::fam; \
 }; \
 template<> \
 struct RZ_Run_Type_Code<cpp_name> \
 { \
  static const RZ_Run_Types::Enum Value = RZ_Run_Types::enum_name; \
 };


#define RZ_RUN_TYPE_NS(ns_name, enum_name, name, cpp_name, haskell_name, fam) \
 RZ_RUN_TYPE(enum_name, name, cpp_name, haskell_name, fam)

#include "types/type-codes.h"

#undef RZ_RUN_TYPE
#undef RZ_RUN_TYPE_NS



_RZNS(GBuild)


//template<>
//struct Ctq_Run_Type<Ctq_Run_Types::Str>
//{
// typedef QString Type;
//// static const Ctq_Run_Types::Enum Code = Ctq_Type_Not_Set;
//};

//template<>
//struct Ctq_Run_Type_Code<QString>
//{
// static const Ctq_Run_Types::Enum Value = Ctq_Run_Types::Str;
//};

//template<>
//struct Ctq_Run_Type_Code<int>
//{
// static const Ctq_Run_Types::Enum Value = Ctq_Run_Types::Int;
//};

//template<>
//struct Ctq_Run_Type<Ctq_Run_Types::Int>
//{
// typedef int Type;
//};



#endif
