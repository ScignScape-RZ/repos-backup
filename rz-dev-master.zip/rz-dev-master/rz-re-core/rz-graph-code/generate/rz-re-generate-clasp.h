
#ifndef RZ_RE_GENERATE_CLASP__H
#define RZ_RE_GENERATE_CLASP__H

#include "accessors.h"
#include "flags.h"

#include "rz-relae/relae-node-ptr.h"

#include "digamma-pluviose/semantic-readtable-emulator.h"

#include "output/rz-re-lisp-output.h"

#include "rz-graph-core/kernel/graph/rz-re-graph.h"

#include "rz-graph-token/token/token-kinds.h"

#include "rz-graph-sre/rz-read-table-state.h"

#include "rz-generator-sre/rz-generator-sre.h"
#include "rz-code-generators/rz-function-def-syntax.h"

#include "rz-clasp-code/rz-clasp-code-generator.h"

#include "rz-clasp-code/rz-clasp-code-lisp-paste-modes.h"

#include <QString>
#include <QTextStream>
#include <QMap>
#include <QStack>

#include <functional>

#include "rzns.h"

RZNS_(GBuild)

class RZ_Lisp_Graph_Visitor;
class RZ_Lisp_Graph_Visitor_Run_State;

_RZNS(GBuild)

RZNS_(GRun)

class RZ_Graph_Run_Token;

_RZNS(GRun)


RZNS_(GVal)

class RZ_Function_Def_Info;
class RZ_Tqns_Code;
class RZ_Lisp_Graph_Scope_Token;
class RZ_Lisp_Graph_Valuer;

_RZNS(GVal)

USING_RZNS(GVal)


RZNS_(RZClasp)

class RZ_Clasp_Code_Generator;
class RZ_Clasp_Code_Lexmap;

_RZNS(RZClasp)

USING_RZNS(RZClasp)



USING_RZNS(GBuild)
USING_RZNS(GRun)


RZNS_(RECore)


class RE_Document;
class RE_Node;
class RE_Graph;
class RZ_Clasp_Project;
class RZ_Clasp_Cpp_Project;
class RZ_Clasp_Embed_Branch;
class RZ_Clasp_Code_Block;
class RZ_SRE_Token;

class RE_Block_Entry;

//class RZ_Tqns_Code;

class RE_Generate_Clasp //: public Semantic_Readtable_Emulator<RE_Dominion>
{
 RZ_Clasp_Code_Generator& ccg_;

 RZ_Generator_Sre sre_;

 Basic_Token_Kinds get_current_token(RZ_SRE_Token& sre_token, caon_ptr<RZ_Clasp_Source_Element>& current_source_element);

 caon_ptr<RZ_Clasp_Project> project_;
 caon_ptr<RZ_Clasp_Cpp_Project> clasp_cpp_project_;

 caon_ptr<RE_Node> pending_raw_lisp_node_;

 caon_ptr<RZ_Lisp_Graph_Block_Info> current_block_info_;
 int block_count_;

 void write_function_def_redirect(QTextStream& qts, QString function_name,
  RZ_Function_Def_Info& fdef);

 QString get_function_name(const RZ_Graph_Run_Token& rzt);

 caon_ptr<RZ_Clasp_Embed_Branch> current_embed_branch_;
 caon_ptr<RZ_Clasp_Code_Block> current_block_;
 caon_ptr<RZ_Clasp_Code_Block> current_parent_block_;

 caon_ptr<RE_Call_Entry> current_labeled_call_entry_object_;

 enum class Embed_Branch_Junctions {
  N_A, Class, Leave_Logical_Scope, Access_Modifier
 };

 Embed_Branch_Junctions find_embed_branch_junction(QString str)
 {
  static QMap<QString, Embed_Branch_Junctions> static_map {{
   { "class", Embed_Branch_Junctions::Class },
   { ";;;;", Embed_Branch_Junctions::Leave_Logical_Scope },
   { ";;;;;", Embed_Branch_Junctions::Leave_Logical_Scope },
   { ";;;;;;", Embed_Branch_Junctions::Leave_Logical_Scope },

   { "public", Embed_Branch_Junctions::Access_Modifier },
   { "private", Embed_Branch_Junctions::Access_Modifier },
   { "protected", Embed_Branch_Junctions::Access_Modifier },

   }};
  return static_map.value(str, Embed_Branch_Junctions::N_A);
 }

 void check_reset_current_embed_branch();

 RZ_Lisp_Graph_Visitor& visitor()
 {
  return sre_.visitor();
 }

 RZ_Lisp_Graph_Visitor_Clasp& visitor_clasp()
 {
  return sre_.visitor_clasp();
 }

 RZ_Lisp_Graph_Visitor_Run_State& run_state()
 {
  return sre_.run_state();
 }

 RZ_Function_Def_Syntax function_def_syntax_;

 void init_function_def_syntax();
 caon_ptr<RZ_Clasp_Code_Lexmap> check_block_lexicals(QTextStream& qts, caon_ptr<RE_Block_Entry> rbe);


public:

 RE_Generate_Clasp(RZ_Lisp_Graph_Visitor& visitor);

 void write(QTextStream& qts);
 void write_cpp(QTextStream& qts);
 void check_advance(QTextStream& qts);
 void prepare_expression_entry(QTextStream& qts);
 void prepare_statement_entry(QTextStream& qts);
 void write_file_entry(QTextStream& qts);

 void init_project(RZ_File_List_Type& extra_files);
 void init_clasp_cpp_project();

 caon_ptr<RZ_Clasp_Code_Block> current_block_parent();

 void check_block_entry(QTextStream& qts);
 void check_block_end(QTextStream& qts);
 void reset_current_block_info();
 void check_if_block_leave(QTextStream& qts);

 void check_assignment_block_leave(QTextStream& qts);
 void check_assignment_block_entry(QTextStream& qts, RZ_Graph_Run_Token& rzt);


 //?void check_init_embed_branch(QTextStream& qts, RZ_Graph_Run_Token& rzt);
 void check_noop_embed_branch(QTextStream& qts);

 void check_pending_raw_lisp(QTextStream& qts, RZ_Clasp_Code_Lisp_Paste_Modes mode);

 void check_root_raw_lisp(QTextStream& qts, caon_ptr<RE_Node> node);
 void check_raw_lisp(QTextStream& qts, caon_ptr<RE_Node> node);

 void check_raw_lisp(QTextStream& qts);

//public:

// RE_Generate_Clasp(RZ_Lisp_Graph_Visitor& visitor);
// void init_project();
// void write(QTextStream& qts);


};

#ifdef HIDE

 // RZ_Lisp_Graph_Visitor& visitor_;
 // RZ_Lisp_Graph_Visitor_Run_State& run_state_;

 Basic_Token_Kinds get_current_token(RZ_SRE_Token& sre_token);

 caon_ptr<RZ_Tqns_Project> project_;

 QString held_signature_;

 void write_function_def_redirect(QTextStream& qts, QString function_name,
  RZ_Function_Def_Info& fdef);

 //void check_statement_noop(QTextStream& qts);


 QString get_function_name(const RZ_Graph_Run_Token& rzt);

 void check_noop_embed_branch(QTextStream& qts);
 void check_leave_tuple_embed_branch();

// QString held_infix_operator_;


// void write_function_name(QTextStream& qts, const RZ_Graph_Run_Token& rzt);
// void write_symbol_name(QTextStream& qts, const RZ_Graph_Run_Token& rzt);
// void write_string_literal(QTextStream& qts, const RZ_Graph_Run_Token& rzt);
// void check_write_held_infix_operator(QTextStream& qts);

 caon_ptr<RZ_Tqns_Embed_Branch> current_embed_branch_;
 caon_ptr<RZ_Tqns_Code_Block> current_block_;

 int block_count_;

 //?caon_ptr<RZ_Tqns_Embed_Branch> last_assign_from_preinit_embed_branch_;

 enum class Embed_Branch_Junctions {
  N_A, Class, Leave_Logical_Scope, Access_Modifier, Assign_From_Preinit,
  Assign_From_Init, Assign_From_Returns, Matching
 };

 Embed_Branch_Junctions find_embed_branch_junction(QString str)
 {
  static QMap<QString, Embed_Branch_Junctions> static_map {{
   { "class", Embed_Branch_Junctions::Class },
   { ";;;;", Embed_Branch_Junctions::Leave_Logical_Scope },
   { ";;;;;", Embed_Branch_Junctions::Leave_Logical_Scope },
   { ";;;;;;", Embed_Branch_Junctions::Leave_Logical_Scope },

   { "public", Embed_Branch_Junctions::Access_Modifier },
   { "private", Embed_Branch_Junctions::Access_Modifier },
   { "protected", Embed_Branch_Junctions::Access_Modifier },
   { "===", Embed_Branch_Junctions::Assign_From_Preinit },
   { "returns", Embed_Branch_Junctions::Assign_From_Returns },
   { "my", Embed_Branch_Junctions::Assign_From_Init },

   { "matching", Embed_Branch_Junctions::Matching },

   }};
  return static_map.value(str, Embed_Branch_Junctions::N_A);
 }

 void check_reset_current_embed_branch();

 RZ_Lisp_Graph_Visitor& visitor()
 {
  return sre_.visitor();
 }

 RZ_Lisp_Graph_Valuer& valuer();

 RZ_Lisp_Graph_Visitor_Run_State& run_state()
 {
  return sre_.run_state();
 }

 RZ_Tqns_Code& haskell_code_model();

 RZ_Function_Def_Syntax function_def_syntax_;
 RZ_Function_Def_Syntax function_signature_syntax_;

 void check_statement_mapkey(QTextStream& qts, RZ_Graph_Run_Token& rzt, caon_ptr<RE_Node> node);
 void check_if_block_leave(QTextStream& qts);
 caon_ptr<RZ_Tqns_Code_Block> current_block_parent();
 void check_block_entry(QTextStream& qts);
 void check_block_end(QTextStream& qts);
 void reset_current_block_info();

 void init_function_def_syntax();
 void check_block_lexicals(QTextStream& qts);
 void write_block_lexicals(QTextStream& qts,
  caon_ptr<RZ_Lisp_Graph_Lexical_Scope> scope, QString write_when_complete, QString last_key = QString());

 void init_expression_entry(caon_ptr<RE_Node> entry_node,
  caon_ptr<RZ_Lisp_Graph_Lexical_Scope> scope, QString last_key);

 void init_tuple_entry(caon_ptr<RE_Node> entry_node,
  caon_ptr<RZ_Lisp_Graph_Lexical_Scope> scope, QString last_key);


 QStack<QPair<caon_ptr<RZ_Lisp_Graph_Lexical_Scope>, QString>> lex_iterators_;
 void continue_lexical_declarations(QTextStream& qts);

 QStack<caon_ptr<RE_Node>> lex_iterator_entry_nodes_;
 //caon_ptr<>

 static QString translate_type(QString type)
 {
  static QMap<QString, QString> static_map {{
   {"int", "RZ_int"},
   }};
  return static_map.value(type, type);
 }

 caon_ptr<RZ_Lisp_Graph_Block_Info> current_block_info_;

public:

 RE_Generate_Tqns(RZ_Lisp_Graph_Visitor& visitor);

 void write(QTextStream& qts);
 void check_advance(QTextStream& qts);

 void prepare_expression_entry(QTextStream& qts, bool nested);

 void prepare_statement_entry(QTextStream& qts);
 void write_file_entry(QTextStream& qts);
 void init_project();

 void check_init_embed_branch(QTextStream& qts, RZ_Graph_Run_Token& rzt);
 void check_init_tuple_embed_branch(QTextStream& qts, RZ_Graph_Run_Token& rzt);

 void write_function_def_type_expression_redirect(QTextStream& qts,
  QString function_name, RZ_Function_Def_Info& fdi);

 void check_assignment_block_entry(QTextStream& qts, RZ_Graph_Run_Token& rzt);
 void check_assignment_block_leave(QTextStream& qts);


 void write_lex_tuple_entry(QTextStream& qts);

  // void init();
  // void begin();
  // void advance();
  // void load_sre_token(RZ_SRE_Token& sre_token);

  // RZ_Read_Table_State read_table_state();
  // RZ_Read_Table_Post_Advance_State post_advance_state();

};


#endif //HIDE


_RZNS(RECore)

#endif
