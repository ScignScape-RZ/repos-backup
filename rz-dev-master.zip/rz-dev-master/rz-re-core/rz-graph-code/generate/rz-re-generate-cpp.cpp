
//#include "rz-re-generate-cpp.h"

//#include "rz-graph-visit/rz-lisp-graph-visitor.h"
//#include "rz-graph-visit/rz-lisp-graph-visitor-run-state.h"
//#include "rz-graph-visit/rz-lisp-graph-visitor-run-plugin.h"

//#include "rz-code-generators/rz-function-def-info.h"

//#include "rz-graph-core/kernel/graph/rz-re-graph.h"

//#include "rz-graph-run/token/rz-graph-run-token.h"

//#include "rz-graph-embed/rz-graph-cpp/rz-graph-cpp-token.h"

//#include "rz-cpp-project/rz-cpp-project.h"

//#include "rz-cpp-project/rz-cpp-embed-normal.h"

//#include "rz-cpp-project/embed/rz-cpp-embed-branch.class.h"
//#include "rz-cpp-project/embed/rz-cpp-embed-branch.self-closing-statement.h"
//#include "rz-cpp-project/embed/rz-cpp-embed-branch.access-modifier.h"

//#include "rz-cpp-project/code/rz-cpp-code-block.h"

//#include "rz-graph-sre/rz-sre-token.h"


//USING_RZNS(RECore)
//USING_RZNS(GBuild)


//RE_Generate_Cpp::RE_Generate_Cpp(RZ_Lisp_Graph_Visitor& visitor)
// : sre_(visitor), project_(nullptr), current_block_(nullptr),
//   current_embed_branch_(nullptr)//, function_def_syntax_(RZ_Function_Def_Syntax(",", ""))
//{
//}

//void RE_Generate_Cpp::init_function_def_syntax()
//{
// function_def_syntax_.flags.type_before_symbol = true;
// function_def_syntax_.set_argument_default_type("auto");
//}

//void RE_Generate_Cpp::init_project()
//{
// project_ = new RZ_Cpp_Project;
// visitor().take_project(project_);
//}

//void RE_Generate_Cpp::write(QTextStream& qts)
//{
// sre_.init();
// //visitor().reset();

// current_embed_branch_ = new RZ_Cpp_Embed_Normal(qts, nullptr, 0);


// run_state().flags.cpp_mode = true;
// check_advance(qts);

// run_state().flags.cpp_mode = false;

// //qts << "xxx";
// //visitor().anticipate();
//}


//void RE_Generate_Cpp::prepare_expression_entry(QTextStream& qts)
//{

//}

//void RE_Generate_Cpp::prepare_statement_entry(QTextStream& qts)
//{

//}

//void RE_Generate_Cpp::write_file_entry(QTextStream& qts)
//{
// qts << "\n#include \"project-global-rz-include.h\"\n\n\n";
//}


//Basic_Token_Kinds RE_Generate_Cpp::get_current_token(RZ_SRE_Token& sre_token)
//{
// sre_.load_sre_token(sre_token);
// //visitor().get_current_token(rzt);
// Basic_Token_Kinds kind = sre_token.run_token()->kind();
// return kind;
//}


//void RE_Generate_Cpp::write_function_def_redirect(QTextStream& qts,
// QString function_name, RZ_Function_Def_Info& fdi)
//{
// QString return_channel = fdi.return_channel_string_cpp();
// QString lambda_channel = fdi.lambda_channel_string(function_def_syntax_);

// qts << return_channel << ' ' << function_name
//  << '(' << lambda_channel << ')';
//}



//void RE_Generate_Cpp::check_advance(QTextStream& qts)
//{
// RZ_Read_Table_Post_Advance_State padv_state;
// RZ_Read_Table_State rts;// = read_table_state();

// RZ_Graph_Run_Token rzt;
// caon_ptr<RE_Node> current_node = nullptr;
// RZ_SRE_Token sre_token(&rzt, current_node);

// Basic_Token_Kinds kind;


//read_table_state_loop:
// rts = sre_.read_table_state();
// switch(rts)
// {
// case RZ_Read_Table_State::Inactive:
//  return;

// case RZ_Read_Table_State::Graph_End:
//  return;

// case RZ_Read_Table_State::Root:
//  sre_.advance();
//  //rts = read_table_state();
//  break;

// case RZ_Read_Table_State::Cpp_File_Entry:
//  write_file_entry(qts);
//  current_block_ = new RZ_Cpp_Code_Block(nullptr);
//  sre_.advance();
//  //rts = read_table_state();
//  break;

// case RZ_Read_Table_State::Statement_Pre_Entry:
//  prepare_statement_entry(qts);
//  sre_.advance();
//  //rts = read_table_state();
//  break;

// case RZ_Read_Table_State::List_Pre_Entry:
//  prepare_expression_entry(qts);
//  sre_.advance();
//  //rts = read_table_state();
//  break;

// case RZ_Read_Table_State::Statement_Entry:
//  current_embed_branch_->write_line_indentation();
//  //qts << QString(current_indentation_depth_, ' ');
//  //  Fallthrough...

// case RZ_Read_Table_State::List_Entry:
//    // //  The token here (List_Entry) should hold a callable value;
//    //     opportunity to intercept

// case RZ_Read_Table_State::List_Embed_Sequence:
// case RZ_Read_Table_State::List_Sequence:
//  kind = get_current_token(sre_token);
//  sre_.advance();
//  //rts = read_table_state();
//  break;

// case RZ_Read_Table_State::Cpp_Block_Entry:
//  sre_.advance();
//  //rts = read_table_state();
//  break;

// case RZ_Read_Table_State::Block_Pre_Entry:
//  current_block_ = new RZ_Cpp_Code_Block(current_block_);
//  current_embed_branch_->write_line_standalone("{");
//  //qts << '\n' << QString(current_indentation_depth_, ' ') << "{\n";
//  ++current_embed_branch_->current_indentation_depth();
//  sre_.advance();
//  //rts = read_table_state();
//  goto rz_Bypass_Check_Kind;
//  break;

// case RZ_Read_Table_State::Cpp_Redirect_Leave:
//  sre_.advance();
//  //rts = read_table_state();
//  goto rz_Check_Kind;
//  break;

// case RZ_Read_Table_State::Cpp_Redirect_Final:
//  sre_.advance();
//  //rts = read_table_state();
//  goto rz_Bypass_Check_Kind;
//  break;

// case RZ_Read_Table_State::List_End:
//  sre_.advance();
//  //rts = read_table_state();
//  goto rz_Check_Kind;

// case RZ_Read_Table_State::List_Final:
//  if(visitor().current_call_entry_is_function_expression())
//   qts << ')';
//  sre_.advance();
//  //rts = read_table_state();
//  break;

// case RZ_Read_Table_State::Statement_Final:
//  if(visitor().current_call_entry_is_function_expression())
//   current_embed_branch_->write_function_expression_leave();
//    //qts << ')';
//  current_embed_branch_->write_statement_final();
//  check_reset_current_embed_branch();
//    //qts << ';' << '\n';

//  sre_.advance();
//  //rts = read_table_state();
//  break;

// case RZ_Read_Table_State::Statement_End:
//  sre_.advance();
//  //rts = read_table_state();
//  break;

// case RZ_Read_Table_State::Block_End:
//  --current_embed_branch_->current_indentation_depth();
//  if(caon_ptr<RZ_Cpp_Code_Block> parent = current_block_->parent_block())
//  {
//   current_embed_branch_->write_line_standalone("}");
//   current_block_ = parent;
//  }
//  sre_.advance();
//  break;

// default:
//  break;
// }

// padv_state = sre_.post_advance_state();

// switch(padv_state)
// {
// case RZ_Read_Table_Post_Advance_State::Reenter:
//  //rts = read_table_state();
//  goto read_table_state_loop;
// case RZ_Read_Table_Post_Advance_State::Holds_Token:
//   goto rz_Check_Kind;
// case RZ_Read_Table_Post_Advance_State::N_A:
// case RZ_Read_Table_Post_Advance_State::No_Token:
//  goto rz_Bypass_Check_Kind;
// case RZ_Read_Table_Post_Advance_State::Deactivate:
//  return;
// }

//rz_Check_Kind:
//// if(rzt.flags.has_cpp_redirect)
//// {
////  qts << rzt.string_value() << ' ';
//// }
//// else
//// {
//  switch(kind)
//  {
//  case Basic_Token_Kinds::Symbol_Token:
//   if(rzt.flags.is_function_expression_entry)
//   {
//    check_init_embed_branch(qts, rzt);
//    current_embed_branch_->write_function_name(sre_token);
//   }
//   else
//    current_embed_branch_->write_symbol_name(sre_token);
//   break;
//  case Basic_Token_Kinds::String_Token:
//    current_embed_branch_->write_string_literal(sre_token);
//   break;
//  case Basic_Token_Kinds::Function_Def_Redirect:
//   write_function_def_redirect(qts, rzt.string_value(),
//     *visitor().last_graph_cpp_token()->function_def_info());
//   break;
//  }
//// }
//rz_Bypass_Check_Kind:

// //rts = read_table_state();
// goto read_table_state_loop;
//}


//void RE_Generate_Cpp::check_init_embed_branch(QTextStream& qts, RZ_Graph_Run_Token& rzt)
//{
// Embed_Branch_Junctions j = find_embed_branch_junction(rzt.string_value());
// switch(j)
// {
// case Embed_Branch_Junctions::Class:
//  current_embed_branch_ = new RZ_Cpp_Embed_Branch__Class(qts,
//   current_embed_branch_,
//   current_embed_branch_->current_indentation_depth());
//  break;
// case Embed_Branch_Junctions::Leave_Logical_Scope:
//  current_embed_branch_ = new RZ_Cpp_Embed_Branch__Self_Closing_Statement("\n}",
//   qts, current_embed_branch_, current_embed_branch_->current_indentation_depth());
//  break;
// case Embed_Branch_Junctions::Access_Modifier:
//  current_embed_branch_ = new RZ_Cpp_Embed_Branch__Access_Modifier(qts,
//   current_embed_branch_, current_embed_branch_->current_indentation_depth());
// default: break;
// }
//}


//void RE_Generate_Cpp::check_reset_current_embed_branch()
//{
// // //   Normally the end of a statement means reverting
// //      current_embed_branch_ to its parent
// caon_ptr<RZ_Cpp_Embed_Branch> parent = current_embed_branch_->parent_branch();
// if(parent)
// {
//  parent->current_indentation_depth() = current_embed_branch_->current_indentation_depth();
//  current_embed_branch_ = parent;
// }
//}

















////void RE_Generate_Cpp::write_function_name(QTextStream& qts, const RZ_Graph_Run_Token& rzt)
////{
//// qts << get_function_name(rzt);
//// qts << '(';
////}

////void RE_Generate_Cpp::write_symbol_name(QTextStream& qts, const RZ_Graph_Run_Token& rzt)
////{
//// QString str = rzt.string_value();
//// if(rzt.flags.is_infix_operator_entry)
//// {
////  held_infix_operator_ = str;
//// }
//// else
//// {
////  qts << str << ' ';
////  check_write_held_infix_operator(qts);
//// }
////}

////void RE_Generate_Cpp::write_string_literal(QTextStream& qts, const RZ_Graph_Run_Token& rzt)
////{
//// qts << '"' << rzt.string_value() << '"' << ' ';
//// check_write_held_infix_operator(qts);
////}

////QString RE_Generate_Cpp::check_hold_infix_operator(const RZ_Graph_Run_Token& rzt,
//// QString str)
////{
//// if(rzt.flags.is_infix_operator_entry)
//// {
////  held_infix_operator_ = str;
////  return QString();
//// }
//// return str;
////}


////void RE_Generate_Cpp::check_write_held_infix_operator(QTextStream& qts)
////{
//// if(!held_infix_operator_.isEmpty())
////  qts << held_infix_operator_ << ' ';
//// held_infix_operator_.clear();;
////}


////caon_ptr<RZ_Lisp_Graph_Visitor> RE_Prerun_Normalize::scan()
////{
//// caon_ptr<RZ_Lisp_Graph_Visitor> result = new RZ_Lisp_Graph_Visitor(&graph_);
//// result->normalize();
//// return result;
////}




////#include "kernel/graph/rz-re-graph.h"
////#include "kernel/graph/rz-re-node.h"

////#include "kernel/rz-re-root.h"

////#include "token/rz-re-token.h"

////#include "tuple/rz-re-tuple-info.h"

////#include "rzns.h"

////USING_RZNS(RECore)

////RE_Pre_Normal_Lisp::RE_Pre_Normal_Lisp(caon_ptr<RE_Document> document)
//// : RE_Lisp_Output(document)
////{

////}


////void RE_Pre_Normal_Lisp::report_token(QTextStream& qts,
//// const RE_Token& token)
////{
//// if(token.flags.is_symbol_declaration)
//// {
////  qts << "(rz-decl " << token.raw_text() << ")";
//// }
//// else
////  qts << token.get_lisp_out();
////}

////void RE_Pre_Normal_Lisp::report_tuple_info_entry(QTextStream& qts,
//// const RE_Tuple_Info& rti)
////{
//// qts << '(' << rti.lisp_out() << ' ';
////}

////void RE_Pre_Normal_Lisp::report_tuple_info_leave(QTextStream& qts,
//// const RE_Tuple_Info& rti)
////{
//// qts << ')';
////}

//////void RE_Pre_Normal_Lisp::output_from_node(QTextStream& qts,
////// const RE_Node& node, int indent)
//////{
////// //CAON_PTR_DEBUG(RE_Node ,node)

////// QString padding(indent, ' ');
//////// qts << "\n" << padding;

////// if(caon_ptr<RE_Token> token = node.re_token())
////// {
//////  qts << get_lisp_out(*token);
////// }

////// if(caon_ptr<RE_Call_Entry> rce = node.re_call_entry())
////// {
//////  //  qts << get_lisp_out(*token);
////// }

////// if(caon_ptr<RE_Node> next_node = rq_.Run_Call_Sequence(&node))
////// {
//////  qts << ' ';
//////  output_from_node(qts, *next_node, indent + 1);
//////  //qts << ' ';
////// }

////// if(caon_ptr<RE_Node> next_node = rq_.Run_Call_Entry(&node))
////// {
//////  qts << "\n" << padding;
//////  qts << '(';
//////  output_from_node(qts, *next_node, indent + 1);
//////  qts << ')';
//////  if(caon_ptr<RE_Node> cross_node = rq_.Run_Cross_Continue(next_node))
//////  {
//////   output_from_node(qts, *cross_node, indent);
//////  }
////// }

////// if(caon_ptr<RE_Node> next_node = rq_.Run_Data_Entry(&node))
////// {
//////  if(caon_ptr<RE_Tuple_Info> rti = next_node->re_tuple_info())
//////  {
//////   qts << "\n" << padding << ' ';
//////   report_tuple_info_entry(qts, *rti);
//////   if(next_node = rq_.Run_Data_Entry(next_node))
//////    output_from_node(qts, *next_node, indent + 1);
//////   report_tuple_info_leave(qts, *rti);
//////  }
//////  if(caon_ptr<RE_Node> cross_node = rq_.Run_Cross_Continue(next_node))
//////  {
//////   output_from_node(qts, *cross_node, indent);
//////  }
////// }
//////}

