
//#ifndef RZ_RE_GENERATE_CPP__H
//#define RZ_RE_GENERATE_CPP__H

//#include "accessors.h"
//#include "flags.h"

//#include "rz-relae/relae-node-ptr.h"

//#include "digamma-pluviose/semantic-readtable-emulator.h"

//#include "output/rz-re-lisp-output.h"

//#include "rz-graph-core/kernel/graph/rz-re-graph.h"

//#include "rz-graph-token/token/token-kinds.h"

//#include "rz-graph-sre/rz-read-table-state.h"

//#include "rz-generator-sre/rz-generator-sre.h"
//#include "rz-code-generators/rz-function-def-syntax.h"

//#include <QString>
//#include <QTextStream>
//#include <QMap>

//#include <functional>

//#include "rzns.h"

//RZNS_(GBuild)

//class RZ_Lisp_Graph_Visitor;
//class RZ_Lisp_Graph_Visitor_Run_State;

//_RZNS(GBuild)

//RZNS_(GRun)

// class RZ_Graph_Run_Token;

//_RZNS(GRun)


//RZNS_(GVal)

//class RZ_Function_Def_Info;

//_RZNS(GVal)

//USING_RZNS(GVal)


//USING_RZNS(GBuild)
//USING_RZNS(GRun)


//RZNS_(RECore)


//class RE_Document;
//class RE_Node;
//class RE_Graph;
//class RZ_Cpp_Project;
//class RZ_Cpp_Embed_Branch;
//class RZ_Cpp_Code_Block;
//class RZ_SRE_Token;

//class RE_Generate_Cpp //: public Semantic_Readtable_Emulator<RE_Dominion>
//{

// RZ_Generator_Sre sre_;

// // RZ_Lisp_Graph_Visitor& visitor_;
// // RZ_Lisp_Graph_Visitor_Run_State& run_state_;

// Basic_Token_Kinds get_current_token(RZ_SRE_Token& sre_token);

// caon_ptr<RZ_Cpp_Project> project_;

// void write_function_def_redirect(QTextStream& qts, QString function_name,
//  RZ_Function_Def_Info& fdef);

// QString get_function_name(const RZ_Graph_Run_Token& rzt);

//// QString held_infix_operator_;


//// void write_function_name(QTextStream& qts, const RZ_Graph_Run_Token& rzt);
//// void write_symbol_name(QTextStream& qts, const RZ_Graph_Run_Token& rzt);
//// void write_string_literal(QTextStream& qts, const RZ_Graph_Run_Token& rzt);
//// void check_write_held_infix_operator(QTextStream& qts);

// caon_ptr<RZ_Cpp_Embed_Branch> current_embed_branch_;
// caon_ptr<RZ_Cpp_Code_Block> current_block_;

// enum class Embed_Branch_Junctions {
//  N_A, Class, Leave_Logical_Scope, Access_Modifier
// };

// Embed_Branch_Junctions find_embed_branch_junction(QString str)
// {
//  static QMap<QString, Embed_Branch_Junctions> static_map {{
//   { "class", Embed_Branch_Junctions::Class },
//   { ";;;;", Embed_Branch_Junctions::Leave_Logical_Scope },
//   { ";;;;;", Embed_Branch_Junctions::Leave_Logical_Scope },
//   { ";;;;;;", Embed_Branch_Junctions::Leave_Logical_Scope },

//   { "public", Embed_Branch_Junctions::Access_Modifier },
//   { "private", Embed_Branch_Junctions::Access_Modifier },
//   { "protected", Embed_Branch_Junctions::Access_Modifier },

//   }};
//  return static_map.value(str, Embed_Branch_Junctions::N_A);
// }

// void check_reset_current_embed_branch();

// RZ_Lisp_Graph_Visitor& visitor()
// {
//  return sre_.visitor();
// }

// RZ_Lisp_Graph_Visitor_Run_State& run_state()
// {
//  return sre_.run_state();
// }

// RZ_Function_Def_Syntax function_def_syntax_;

// void init_function_def_syntax();

//public:

// RE_Generate_Cpp(RZ_Lisp_Graph_Visitor& visitor);

// void write(QTextStream& qts);
// void check_advance(QTextStream& qts);
// void prepare_expression_entry(QTextStream& qts);
// void prepare_statement_entry(QTextStream& qts);
// void write_file_entry(QTextStream& qts);
// void init_project();

// void check_init_embed_branch(QTextStream& qts, RZ_Graph_Run_Token& rzt);

//  // void init();
//  // void begin();
//  // void advance();
//  // void load_sre_token(RZ_SRE_Token& sre_token);

//  // RZ_Read_Table_State read_table_state();
//  // RZ_Read_Table_Post_Advance_State post_advance_state();

//};

//_RZNS(RECore)

//#endif
