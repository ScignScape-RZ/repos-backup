
#ifndef RZ_RE_FUNCTION_DEF_ENTRY__H
#define RZ_RE_FUNCTION_DEF_ENTRY__H

#include "accessors.h"
#include "flags.h"


#include <QString>
#include <QMap>

#include "rz-relae/relae-caon-ptr.h"

#include "rz-re-function-def-kinds.h"

//#include <functional>

#include "rzns.h"
RZNS_(RECore)


class RE_Node;

class RE_Function_Def_Entry
{
 caon_ptr<RE_Node> prior_node_;
 caon_ptr<RE_Node> node_;
 caon_ptr<RE_Node> label_node_;

 RE_Function_Def_Kinds kind_;

public:

 ACCESSORS(caon_ptr<RE_Node> ,prior_node)
 ACCESSORS(caon_ptr<RE_Node> ,node)
 ACCESSORS(caon_ptr<RE_Node> ,label_node)
 ACCESSORS(RE_Function_Def_Kinds ,kind)

 RE_Function_Def_Entry(caon_ptr<RE_Node> prior_node, RE_Function_Def_Kinds kind, caon_ptr<RE_Node> label_node = nullptr);
 //?void mark_no_def();

};

_RZNS(RECore)

#endif
