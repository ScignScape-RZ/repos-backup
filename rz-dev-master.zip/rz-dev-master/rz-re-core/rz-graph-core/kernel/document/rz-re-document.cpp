
#include "rz-re-document.h"

#include "rz-relae/relae-parser.templates.h"

#include "kernel/grammar/rz-re-parser.h"
#include "kernel/grammar/rz-re-grammar.h"
#include "kernel/grammar/rz-re-graph-build.h"

#include "kernel/rz-re-root.h"

#include "kernel/graph/rz-re-graph.h"


#include "rzns.h"

#include <QFile>
#include <QFileInfo>
#include <QDir>

#include <QRegularExpression>

USING_RZNS(RECore)


RE_Document::RE_Document(QString path)
 : graph_(nullptr), grammar_(nullptr), number_of_lines_(0),
   nl_lexicon_(nullptr)
{
 if(!path.isEmpty())
  load_file(path);
}


void RE_Document::load_file(QString path)
{
 QFile file(path);
 if(file.open(QFile::ReadOnly | QIODevice::Text))
 {
  raw_text_ = file.readAll();
  local_path_ = path;
  QFileInfo qfi(local_path_);
  local_directory_ = qfi.absoluteDir().absolutePath();
 }

 // for csc -> rz
 //raw_text_.replace("my $", "my ,$");

#ifdef HIDE

 int pos = 0;

 QRegularExpression rx_ext("declare-external\\s+'([\\w-]+)\\s*;");

 QString vars;

 while(true)
 {
  QRegularExpressionMatch rx_extm = rx_ext.match(raw_text_, pos);
  if(rx_extm.hasMatch())
  {
   pos = rx_extm.capturedEnd() + 1;
   QString var = rx_extm.captured(1);
   vars += "\ndeclare variable $" + var + " external;";
  }
  else break;
 }

 xquery_text_ += vars + "\n";

 raw_text_.replace(QRegularExpression("begin\\s+xquery"), "QWN::callback :run-xquery xq_");
 raw_text_.replace(QRegularExpression("end\\s+xquery"), "_xq ;");


 QRegularExpression rx("xq_(.*)_xq", QRegularExpression::DotMatchesEverythingOption);
 QRegularExpressionMatch rxm = rx.match(raw_text_);
 if(rxm.hasMatch())
 {
  xquery_text_ += rxm.captured(1);
 }

 raw_text_.replace(QRegularExpression("var\\s+"), "our ,");
 raw_text_.replace(QRegularExpression("let\\s+"), "my ,");

 raw_text_.replace(QRegularExpression("defn\\s+(\\S+)\\s*\\(([^\\)]*)\\)"),
  "our ,\\1 = .(\\2) -> ");

 raw_text_.replace("endf", ";;");


// raw_text_.replace("xq_", QString("run-xq \"%1").arg(vars));
// raw_text_.replace("_xq", "\";\n");

 QFile outf(path + ".rz");
 if(outf.open(QFile::WriteOnly | QIODevice::Text))
 {
  QTextStream out(&outf);
  out << raw_text_;
 }

 QFile outf1(path + ".xq");
 if(outf1.open(QFile::WriteOnly | QIODevice::Text))
 {
  QTextStream out(&outf1);
  out << xquery_text_;
 }


 number_of_lines_ = raw_text_.count('\n') + 1;
 if(raw_text_.indexOf(QRegExp("\\n\\s*$")) == -1)
 {
  raw_text_ += '\n';
  ++number_of_lines_;
 }


#endif // HIDE

}


void RE_Document::resolve_report_path(QString& path)
{
 if(path.startsWith('.'))
 {
  path = path.mid(1);
  if(path.startsWith('.'))
  {
   path = local_path_ + path;
  }
  else
  {
//   QFileInfo qfi(local_path_);
  }
 }
}

void RE_Document::report_graph(QString path)
{
 resolve_report_path(path);
 QFile file(path);
 if(file.open(QFile::WriteOnly | QIODevice::Text))
 {
  QTextStream qts(&file);
  if(graph_)
   graph_->report(qts);
 }
}


void RE_Document::set_grammar(RE_Grammar* grammar)
{
 if(grammar)
  grammar_ = grammar;
 else
  grammar_ = new RE_Grammar();
}

void RE_Document::preprocess_raw_text()
{
 // //  currently the only modification is for do blocks sharing signature ...
 QRegularExpression rx("do(([^{;>]*\\s+)[@\\w]*->\\s+)\\{([^}]+)\\}");
 //QRegularExpression rx("do");

//?
// QList<int> positions_start;
// QList<int> positions_end;
// QStringList replacements;

 int pos = 0;
 while(true)
 {
  QRegularExpressionMatch rxm = rx.match(raw_text_, pos);
  if(rxm.hasMatch())
  {
   QString c1 = rxm.captured(1);

   QString c1a = rxm.captured(2);

   if(c1a.trimmed().isEmpty())
   {
    c1.prepend(" .() ");
   }

   QString c2 = rxm.captured(3);
   int pos1 = rxm.capturedStart(3);
   int pos2 = rxm.capturedEnd(3);
   QString replace = insert_block_map_signatures(c2, c1);
   raw_text_.replace(pos1, pos2 - pos1, replace);
   pos += replace.length();
   raw_text_.replace(rxm.capturedStart(1), rxm.capturedLength(1), " \n");
   pos -= rxm.capturedLength(1);
   pos += 2;
  }
  else
  {
   break;
  }
 }

 QFile outf(local_path_ + ".pre");
 if(outf.open(QFile::WriteOnly | QIODevice::Text))
 {
  QTextStream out(&outf);
  out << raw_text_;
 }
}


QString RE_Document::insert_block_map_signatures(QString original_source, QString sig)
{
 int sigl = sig.length();

 QList<int> positions;

 QRegularExpression rx("(-\\w+:)\\s+\\w");
 //QRegularExpression rx("-\\w+:\\s+(?=\\w)");
 int pos = 0;
 while(true)
 {
  QRegularExpressionMatch rxm = rx.match(original_source, pos);
  if(rxm.hasMatch())
  {
   int ce1 = rxm.capturedEnd(1);
   positions.append(ce1);
   int ce = rxm.capturedEnd();
   pos += ce;
  }
  else
  {
   break;
  }
 }
 QString result = original_source;
 for(int i = 0; i < positions.length(); ++i)
 {
  int pos = positions[i] + i*sigl;
  result.replace(pos, 0, sig);
 }
 return result;
}

void RE_Document::parse(int start_position, int end_position)
{
 preprocess_raw_text();



// caon_ptr<RE_Root> root = new RE_Root(this);
// caon_ptr<RE_Node> node = new RE_Node(root);
// RELAE_SET_NODE_LABEL(node, "<root>");
 graph_ = new RE_Graph();
// graph_->set_document(this);
 parser_ = new RE_Parser(graph_);
 parser_->set_raw_text(raw_text_);
// graph_build.reset_graph();

 graph_build_ = new RE_Graph_Build(this, *parser_, *graph_);
 graph_build_->init();

 grammar_ = new RE_Grammar;

 if(nl_lexicon_)
 {
  graph_build_->init_nl(nl_lexicon_);
 }

 grammar_->init(*parser_, *graph_, *graph_build_);



// grammar_->activate_context(print);

 grammar_->compile(*parser_, *graph_, raw_text_, start_position);
}

RE_Document::~RE_Document()
{

}


QString RE_Document::rz_path_handlers()
{
 return graph_build_->rz_path_handlers();
}


//void RE_Document::parse()
//{
// QFile infile(local_path_);
// if(!infile.open(QFile::ReadOnly | QFile::Text ))
//  return;
// raw_text_ = infile.readAll();

// re_graph_ = new RE_Graph();

// RE_Parser re_parser(re_graph_);
// RE_Grammar re_grammar;
// RE_Graph_Build re_graph_build(this, re_parser, *re_graph_);

// re_grammar.init(re_parser, *re_graph_, re_graph_build);
// // re_graph_->ini

// re_grammar.compile(re_parser, *re_graph_, raw_text_);

//}
