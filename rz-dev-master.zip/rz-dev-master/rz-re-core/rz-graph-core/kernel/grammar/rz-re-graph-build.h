
#ifndef RZ_RE_GRAPH_BUILD__H
#define RZ_RE_GRAPH_BUILD__H

//#include "graph/rz-text-relation.h"
#include "rz-re-parser.h"

#include "flags.h"

#include "accessors.h"

#include "rz-re-parse-context.h"

#include "kernel/graph/rz-re-markup-position.h"

#include "kernel/graph/rz-nl-graph-build.h"

#include "tuple/rz-re-tuple-info.h"

#include "code/rz-re-function-def-kinds.h"

//#include ""
//#include "rz-re-frame.h"


#include <QStack>
#include <QSet>

#include "rzns.h"


RZNS_CLASS_DECLARE(NL ,NL_Lexicon)
USING_RZNS(NL)

RZNS_(RECore)

class RE_Document;
class RE_Parser;
class RE_Graph;
class RE_Tag_Command;
class RE_Annotation_Tile;

class RE_Token;
class RE_Tile;
class RE_Node;
class RE_Sentence;
class RE_Sentence_Part;
class RE_Paralexeme;
class RE_Call_Entry;
class RE_Function_Def_Entry;
class RZ_String_Plex_Builder;

class RE_Graph_Build
{
 flags_(1)
  bool inside_text_map:1;
  bool ghost_in_closes_expression:1;
  bool next_token_closes_expression:1;
  bool inside_array_with_formation:1;
  bool pending_convert_to_type_symbol:1;
  bool pending_symbol_modify_to_method:1;
  bool arrow_pending_symbol_modify_to_method:1;
//  bool active_command_entry:1;
//  bool math_mode:1;
//  bool run_mode:1;
//  bool skip_command_node_insert:1;
//  bool chi_tile_context:1;
//  bool active_annotation_entry:1;
//  bool active_annotation_tile:1;
//  bool convert_attributes:1;
 _flags

 RE_Document* document_;
 RE_Parser& parser_;
 RE_Graph& graph_;

 QString math_acc_;

 QMap<QString, int>* user_highlights_;

 typedef QMap<QString, int> User_Highlights_type;

 caon_ptr<RE_Tile> current_tile_;
 RE_Annotation_Tile* current_annotation_tile_;

 typedef RE_Node RE_Node;

 //typedef RE_Binary_Relation_Token NBR;

 enum class Position_States {
//  Root_Position, Run_Sequence,
//  Statement_Sequence
  Root_Position, Sentence_Reset, Sentence_End, Sentence_Start,
  Word_Sequence, Word_Chain,
    Command_End, // Section_End,
    Math_Mode
 };

 Position_States current_position_state_;

 enum class Quoting_Formations {
  N_A, Single,
  Double_Single, Backtick, Double_Backtick
 };

 Quoting_Formations get_quoting_formation(QString s)
 {
  static QMap<QString, Quoting_Formations> static_map
  {{
    { "'", Quoting_Formations::Single },
    { "''", Quoting_Formations::Double_Single },
    { "`", Quoting_Formations::Backtick },
    { "``", Quoting_Formations::Double_Backtick },
  }};

  return static_map.value(s, Quoting_Formations::N_A);
 }


// caon_ptr<RE_Node> current_node_;
 caon_ptr<RE_Node> current_command_node_;
 caon_ptr<RE_Node> root_node_;
 caon_ptr<RE_Node> active_run_node_;
 caon_ptr<RE_Token> active_chief_token_;

 caon_ptr<RZ_String_Plex_Builder> current_string_plex_builder_;

 RE_Parse_Context parse_context_;


 int current_line_;
 int current_run_comment_left_;
 int current_run_comment_right_;

 QStack<caon_ptr<RE_Node>> parent_command_nodes_;

 QString run_acc_;
 QString text_map_acc_;
 QString expected_token_end_;
 QString extended_string_literal_acc_;

// QString string_literal_acc_;
// QString lara_acc_;
// QString lisp_acc_;
// QString chi_acc_;
// QString tile_acc_;

 RE_Frame& fr_;

 RE_Markup_Position markup_position_;
 NL_Graph_Build* nl_graph_build_;


 QSet<QString> automatic_statement_closing_tokens_;

 QString string_literal_acc_;
 QString match_literal_acc_;

 QString xq_literal_acc_;
 QString raw_lisp_acc_;

 int call_entry_count_;
 int block_entry_count_;
 int tuple_entry_count_;

 void set_expected_token_end(QString text);
 void check_line_increment(QString text);

 QString rz_path_handlers_;

 QString pending_symbol_modify_to_method_type_string_;

public:


 enum class Token_Formations {
  N_A, Normal, Cpp_Scoped, Do_Plus_Block, Strong_Do_Plus_Block
 };

 ACCESSORS(RE_Document* ,document)
// ACCESSORS(caon_ptr<RE_Node> ,current_node)
 ACCESSORS(caon_ptr<RE_Node> ,root_node)
 ACCESSORS(caon_ptr<RE_Node> ,active_run_node)
 ACCESSORS(caon_ptr<RE_Token>  ,active_chief_token)
 ACCESSORS__GET(RE_Graph& ,graph)

// ACCESSORS__RGET_DEREF(User_Highlights_type ,user_highlights)
// ACCESSORS__SET(User_Highlights_type* ,user_highlights)


// ACCESSORS(RZ_Run_Section* ,current_run_section)

 ACCESSORS__RGET(RE_Parse_Context ,parse_context)

 ACCESSORS(QString ,rz_path_handlers)

 RE_Graph_Build(RE_Document* d,
  RE_Parser& p, RE_Graph& g);

 caon_ptr<NL_Lexicon> get_nl_lexicon();


 void rz_path_handers_acc(QString text);
 void enter_rz_path_handers();
 void leave_rz_path_handers();

 void complete_function_declaration();

 void init();

 void init_nl(caon_ptr<NL_Lexicon> nll);

 void run_acc(QString raw_text);
 void text_map_acc(QString raw_text);
 void check_clear_text_map_acc();

 void add_nl_word(QString raw_text);
 void add_nl_punctuation(QString raw_text);


 void string_plex_switch(QString key);
 void string_plex_acc(QString text);

 void enter_tuple(QString prefix, QString entry, QString suffix);

 void extended_string_literal_start();
 void process_extended_string_literal();
 void add_to_extended_string_literal(QString text);

 void add_equalizer_to_type(QString raw_text);
 void pending_symbol_modify_to_method(QString raw_text);


 caon_ptr<RE_Node> new_run_call_entry_node(bool is_statement_entry,
   QString prefix = QString(), caon_ptr<RE_Call_Entry> parent_entry = nullptr);

 caon_ptr<RE_Node> new_run_block_entry_node();

 caon_ptr<RE_Node> new_autogenerated_token_node(QString raw_text);

 caon_ptr<RE_Node> close_string_plex();

 void add_to_string_literal(QString str)
 {
  string_literal_acc_ += str;
 }

 void add_to_match_literal(QString str)
 {
  match_literal_acc_ += str;
 }

 void string_literal_start();

 void xq_literal_start();
 void raw_lisp_start();

 void add_to_xq_literal(QString str);
 void add_to_raw_lisp(QString str);

 void process_xq_literal();

 void process_match_literal(bool automatically_close_statement);

 void process_string_literal();
 void process_raw_lisp();

 void add_run_token(RE_Token& token);
 void add_raw_lisp_token(RE_Token& token);

 void add_mvb_tokens(QString tokens, QString setter_token, QString core_fun);

 void add_type_indicator(QString raw_text);


 caon_ptr<RE_Node> create_tuple(RE_Tuple_Info::Tuple_Formations tf,
  RE_Tuple_Info::Tuple_Indicators ti, RE_Tuple_Info::Tuple_Formations sf, bool increment_id = true);

 caon_ptr<RE_Node> make_new_empty_tuple_node(caon_ptr<RE_Tuple_Info> rti);

 inline caon_ptr<RE_Node> current_node()
 {
  return markup_position_.current_node();
 }

 caon_ptr<RE_Node> make_re_node(caon_ptr<RE_Token> token);

// inline caon_ptr<RE_Node>& current_node_ref()
// {
//  return markup_position_.current_node();
// }

 void check_run_comment_begin(int left, int right);
 void check_run_comment_end(int left, int right);

 void line_increment();

 void add_run_token(QString raw_text);

 void add_run_token(QString prefix, QString raw_text,
  QString suffix, Token_Formations tf, QString space_to_end_of_line = QString());

 void check_run_acc(QString raw_text);
 void finalize_run_acc();

 caon_ptr<RE_Node> new_function_def_entry_node(RE_Node& prior_node,
   RE_Function_Def_Kinds kind, caon_ptr<RE_Node> label_node = nullptr);

 void terminate_read();
 void terminate_parse();

 caon_ptr<RE_Node> check_print_acc();
 void print_acc(QString text);

 caon_ptr<RE_Node> make_new_node(caon_ptr<RE_Token>  token);
 caon_ptr<RE_Node> make_new_node(caon_ptr<RE_Tag_Command> cmd);
 caon_ptr<RE_Node> make_new_node(caon_ptr<RE_Tile> tile);
 caon_ptr<RE_Node> make_new_node(caon_ptr<RE_Tile> tile, QString label);
 caon_ptr<RE_Node> make_new_node(RE_Annotation_Tile* tile);
 caon_ptr<RE_Node> make_new_node(RE_Annotation_Tile* tile, QString label);
 caon_ptr<RE_Node> make_new_node(caon_ptr<RE_Sentence> sentence);
 caon_ptr<RE_Node> make_new_node(caon_ptr<RE_Sentence_Part> ngsp);
 caon_ptr<RE_Node> make_new_node(caon_ptr<RE_Paralexeme> nglp);
 caon_ptr<RE_Node> make_new_node(caon_ptr<RE_Call_Entry> rce);
 caon_ptr<RE_Node> make_new_node(caon_ptr<RE_Block_Entry> rbe);
 caon_ptr<RE_Node> make_new_node(caon_ptr<RE_Function_Def_Entry> fdef);
 caon_ptr<RE_Node> make_new_node(caon_ptr<RZ_String_Plex_Builder> rzspb);

 caon_ptr<RE_Node> make_new_tile_node(QString label);

 void user_highlight(QString highlight, QString text);

 void tag_command_entry(QString command_name);

 void tag_command_annotation(QString annotation);

 void end_tag_body();
 void tag_command_closing_sequence(QString match_text, QString command_name);
 void check_tile_acc();
 caon_ptr<RE_Node> check_end_sentence();
 void absorb_whitespace();
 void add_paralexeme(QString match_text);
 void add_paralexical_segment(QString match_text);


// void add_punctuation(QString match_text);
 void add_sentence_end_punctuation(QString pre, QString main, QString post);
 void add_punctuation(QString pre, QString main, QString post);

 void annotation_entry(QString text, QString rel, QString follow);
 void command_entry(QString command_name, QString follow);
 void command_head(QString command_name, QString follow);
 void command_head_with_argument(QString command_name,
  QString argument, QString follow);

 void add_token_plus_block(QString token, QString block_entry);

 void add_semis(QString raw_text, QString space_to_end_of_line);

 void insert_command_primary_argument(QString argument);
 void add_run_token(QString raw_text, QString space_to_end_of_line);

 void command_exit();
 void block_command_exit(QString command_name);
 caon_ptr<RE_Node> make_sentence_node(caon_ptr<RE_Sentence> ngs);
 caon_ptr<RE_Node> make_sentence_part_node(caon_ptr<RE_Sentence_Part> ngsp);

 void acc(QString s);

};

_RZNS(RECore)

#endif
