
#ifndef RZ_RE_PARSER__H
#define RZ_RE_PARSER__H

#include "rz-relae/relae-parser.h"

#include "kernel/rz-re-dominion.h"

#include "rzns.h"
RZNS_(RECore)

//USING_RZNS(RECore)

class RE_Graph;

class RE_Parser : public Relae_Parser<RE_Galaxy>
{
 QString raw_text_;

public:

// // ACCESSORS(RE_Graph* ,graph)
 ACCESSORS(QString ,raw_text)

 //ACCESSORS(RE_Graph* ,graph)

 RE_Parser(caon_ptr<RE_Graph> g);

// QString get_remainder();


};

_RZNS(RECore)

//#include "rz-parser/rz-regex.h"
//#include "rz-parser/rz-parser.h"

//#include "rz-text-typedefs.h"

//class RZ_Text_Parser : public RZ_Parser<RZ_Text_Galaxy>
//{
//public:
// RZ_Text_Parser(RZ_Text_Graph* g);
// void set_raw_text(QString s);


//};

//typedef RZ_Parser<RZ_Text_Galaxy> RZ_Text_Parser;

#endif
