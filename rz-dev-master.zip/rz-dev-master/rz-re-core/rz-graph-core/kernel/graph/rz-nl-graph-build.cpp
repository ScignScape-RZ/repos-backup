
#include "rz-nl-graph-build.h"

#include "kernel/grammar/rz-re-graph-build.h"
#include "kernel/graph/rz-re-node.h"
#include "kernel/graph/rz-re-graph.h"
#include "token/rz-re-token.h"
#include "token/rz-nl-token.h"

#include "rz-nl/rz-nl-lexicon/rz-nl-lexicon.h"

#include "rz-text/rz-text-punctuation/rz-text-punctuation.h"

#include "rz-nl/rz-nl-lexicon/rz-nl-sentence.h"
#include "rz-nl/rz-nl-lexicon/rz-nl-lexentry.h"
#include "rz-nl/rz-nl-lexicon/rz-nl-link-pair.h"

#include "rz-nl/rz-nl-lexicon/rz-nl-link-pair-cluster.h"


#include <QVector>


#include "rzns.h"

USING_RZNS(RECore)
USING_RZNS(Text)


NL_Graph_Build::NL_Graph_Build
 (caon_ptr<RE_Graph_Build> graph_build, caon_ptr<NL_Lexicon> nl_lexicon)
 : //?Flags(0),
   graph_build_(graph_build),
   nl_lexicon_(nl_lexicon),
   fr_(RE_Frame::instance()),
   rq_(RE_Query::instance()),
   current_node_(nullptr),
   start_node_(nullptr)
{
}


void NL_Graph_Build::add_punctuation(caon_ptr<RE_Node> node)
{
 caon_ptr<RZ_Text_Punctuation> pun = node->text_punctuation();
 if(pun->marks_sentence_end())
 {
  parse_sentence(node);
 }
}

void NL_Graph_Build::parse_sentence(caon_ptr<RE_Node> punctuation_node)
{
 caon_ptr<NL_Sentence> nls = new NL_Sentence(punctuation_node);

 caon_ptr<RE_Node> sentence_root_node = new RE_Node(nls);

 QMapIterator<NL_Lexclass*, QVector<caon_ptr<RE_Node> > > it(nodes_by_lexclass_);

 QSet<NL_Link_Pair> link_pairs;
 int link_pair_index = 0;

 while(it.hasNext())
 {
  it.next();

  NL_Lexclass* nlc = it.key();

  QVector<caon_ptr<RE_Node> > nodes = it.value();


  for(caon_ptr<RE_Node> node : nodes)
  {
   caon_ptr<NL_Token> nlt = node->nl_token();

   CAON_PTR_DEBUG(NL_Token ,nlt)
   caon_ptr<NL_Lexentry> nle = nlt->lexentry();

   CAON_PTR_DEBUG(NL_Lexentry ,nle)

   CAON_DEBUG_NOOP

   check_forward_link_pairs(node, link_pairs, link_pair_index);

  }

 }

 prepare_graph_code_list(sentence_root_node, link_pairs);
}


void NL_Graph_Build::check_lamdba_matches(caon_ptr<RE_Node> potential_source_node, caon_ptr<RE_Node> potential_target_node,
  NL_Lexclass* source_lexclass_with_lambda, int offset, int profile_position, NL_Lexclass* potential_target_lexclass,
  QSet<NL_Link_Pair>& link_pairs, int& link_pair_index, int rewind)
{
 CAON_PTR_DEBUG(RE_Node ,potential_source_node)
 CAON_PTR_DEBUG(RE_Node ,potential_target_node)
 int pos = 0;
 for(NL_Lexclass* nlcl : source_lexclass_with_lambda->lambda_channel())
 {
  // // try snlc as dependent in different positions
  if(nlcl == potential_target_lexclass)
  {
   NL_Link_Pair pr(link_pair_index); // = new NL_Link_Pair;
   ++link_pair_index;



   pr.set_lambda_position(pos);
   pr.set_source_node(potential_source_node);
   pr.set_target_node(potential_target_node);
   pr.set_rewind_level(rewind);

   pr.set_label(QString("%1 -> %2 (%3)")
     .arg(potential_source_node->label())
     .arg(potential_target_node->label())
     .arg(pos) );

   pr.set_short_summary(QString("%1 %2")
     .arg(potential_source_node->label().mid(3))
     .arg(potential_target_node->label().mid(3)) );

   pr.set_shared_rewind_level(source_lexclass_with_lambda->expected_lambda_depth());

   pr.set_continue_offset(offset);
   pr.set_source_lexclass(source_lexclass_with_lambda);
   pr.set_target_lexclass(nlcl);
   pr.set_profile_position(profile_position);

   CAON_PTR_DEBUG(RE_Node ,potential_source_node)
   CAON_PTR_DEBUG(RE_Node ,potential_target_node)

   // //  Check duplicate ...
    //?const NL_Link_Pair* duplicate_pr = nullptr;
   bool duplicate_pr = false;
   for(const NL_Link_Pair& lpr : link_pairs)
   {
    if(lpr == pr) //?lpr->duplicates(pr))
    {
     duplicate_pr = true;
     //?duplicate_pr = lpr;
     break;
    }
   }

   if(!duplicate_pr)
    link_pairs.insert(pr);

  }
  ++pos;
 }
 // //  Next, try rewinding using source_lexclass_with_lambda profile channel

 for(NL_Lexclass* nlcl : source_lexclass_with_lambda->profile_channel())
 {
  check_lamdba_matches(potential_source_node, potential_target_node, nlcl, offset, profile_position,
    potential_target_lexclass, link_pairs, link_pair_index, rewind + 1);
 }
}


void NL_Graph_Build::check_forward_link_pairs(caon_ptr<RE_Node> start_node,
  QSet<NL_Link_Pair>& link_pairs, int& link_pair_index)
{
 CAON_PTR_DEBUG(RE_Node ,start_node)

 caon_ptr<NL_Token> snlt = start_node->nl_token();

 CAON_PTR_DEBUG(NL_Token ,snlt)
 caon_ptr<NL_Lexentry> snle = snlt->lexentry();

 CAON_PTR_DEBUG(NL_Lexentry ,snle)

 NL_Lexclass_Vector snlv = snle->lexclasses();

 int offset = 0;

 for(caon_ptr<RE_Node> node = rq_.NL_Continue(start_node); node; node = rq_.NL_Continue(node))
 {
  CAON_PTR_DEBUG(RE_Node ,node)

  ++offset;
  caon_ptr<NL_Token> nlt = node->nl_token();

  CAON_PTR_DEBUG(NL_Token ,nlt)
  caon_ptr<NL_Lexentry> nle = nlt->lexentry();

  CAON_PTR_DEBUG(NL_Lexentry ,nle)

  NL_Lexclass_Vector nlv = nle->lexclasses();

  for(NL_Lexclass* nlc : nlv)
  {
   for(NL_Lexclass* snlc : snlv)
   {
    if(snlc->lambda_channel().isEmpty())
    {
     // //  i.e., the snlc is not from a profile channel
     int profile_position = -1;
     // // snlc cannot be regent ...
     check_lamdba_matches(node, start_node, nlc, -offset, profile_position, snlc, link_pairs, link_pair_index);
    }
    else
    {
     // //  First try snlc as dependent, based on its profile channel
     int profile_position = 0;
     for(NL_Lexclass* snlcp : snlc->profile_channel())
     {
      check_lamdba_matches(node, start_node, nlc, -offset, profile_position, snlcp, link_pairs, link_pair_index);
      ++profile_position;
     }
     // //  Or directly for a compound chief
     check_lamdba_matches(node, start_node, nlc, -offset, -1, snlc, link_pairs, link_pair_index);

     // //  Next try snlc as regent
     profile_position = -1;
     check_lamdba_matches(start_node, node, snlc, offset, profile_position, nlc, link_pairs, link_pair_index);
     profile_position = 0;
     for(NL_Lexclass* nlcp : nlc->profile_channel())
     {
      check_lamdba_matches(start_node, node, snlc, offset, profile_position, nlcp, link_pairs, link_pair_index);
      ++profile_position;
     }
     check_lamdba_matches(start_node, node, snlc, -offset, -1, nlc, link_pairs, link_pair_index);

    }

   }
  }
 }

}


void NL_Graph_Build::prepare_graph_code_list(caon_ptr<RE_Node> sentence_root_node,
  const QSet<NL_Link_Pair>& link_pairs)
{

 QMap<int, const NL_Link_Pair*> pair_map;

 QSet<NL_Link_Pair_Cluster> link_pair_clusters;
 int link_pair_cluster_index = 0;
 int max_cluster_size = 1;


 for(const NL_Link_Pair& pr : link_pairs)
 {
  pair_map[pr.local_index()] = &pr;

  // // init the one-pair clusters
   //
  NL_Link_Pair_Cluster lpc(link_pair_cluster_index);
  ++link_pair_cluster_index;
   //?lpc.clone_from();

  lpc.append_link_pair(&pr);

  caon_ptr<RE_Node> prsn = pr.source_node();

  CAON_PTR_DEBUG(RE_Node ,prsn)

  QString s = pr.short_summary();

  lpc.increase_node_arity(prsn, pr.rewind_level());
  lpc.increase_node_arity__labels(prsn->label(), pr.rewind_level());

//?
//  bool duplicate = false;
//  for(const NL_Link_Pair_Cluster& slpc : link_pair_clusters)
//  {
//   if(lpc == slpc)
//   {
//    duplicate = true;
//    break;
//   }
//  }

//  if(!duplicate)

  link_pair_clusters.insert(lpc);

 }

 QVector<int> indices = QVector<int>::fromList(pair_map.keys());

 //QMapIterator<int, NL_Link_Pair*> it(&pair_map);

 int i = 0;
 int length = indices.length();


 for(int index : indices)
 {
  const NL_Link_Pair* pr = pair_map[index];
  caon_ptr<RE_Node> sn = pr->source_node();
  caon_ptr<RE_Node> tn = pr->target_node();

  CAON_PTR_DEBUG(RE_Node ,sn)
  CAON_PTR_DEBUG(RE_Node ,tn)


  QString sh = pr->short_summary();


  // //  Advance i now, since we want to start at the
   //    next index anyhow.
  ++i;
  for(int j = i; j < length; j++)
  {
   int jndex = indices[j];
   const NL_Link_Pair* jpr = pair_map[jndex];

   QString jsh = jpr->short_summary();
   QString sh = pr->short_summary();

   if(sh == "quickly His")
   {
    if(jsh == "quickly wins")
     CAON_DEBUG_NOOP
    if(jsh == "His team")
     CAON_DEBUG_NOOP
   }

   if(jsh == "quickly wins")
    CAON_DEBUG_NOOP

   if(sh == "quickly wins")
    CAON_DEBUG_NOOP

   if(jsh == "quickly His")
   {
    if(sh == "quickly wins")
     CAON_DEBUG_NOOP
    if(sh == "His team")
     CAON_DEBUG_NOOP
   }

   caon_ptr<RE_Node> jsn = jpr->source_node();
   caon_ptr<RE_Node> jtn = jpr->target_node();

   CAON_PTR_DEBUG(RE_Node ,jsn)
   CAON_PTR_DEBUG(RE_Node ,jtn)

   if(jsn == tn)
   {
    // //  If we're here, we're trying to find all clusters
     //    where pr can provide a target node, with the current
     //    jpr providing a source node.

    if(pr->profile_position() == -1)
    {
     // //  This means pr is not included in
      //    a containing lambda channel in such
      //    a way that it can be its own regent
     continue;
    }

    if(pr->rewind_level() > 0)
    {
     // //  This means jtn is blocked by a rewind
     continue;
    }


//?    if(jpr->lambda_position() == pr->lambda_position())
//    {
//     // //  They conflict, compating for the same lambda
//      //    position.
//     continue;
//    }


    //?QMap<const NL_Link_Pair_Cluster*, QPair<int, const NL_Link_Pair*> > temp_cluster_map;
    QMap<const NL_Link_Pair_Cluster*, int> temp_cluster_map;

    for(const NL_Link_Pair_Cluster& tnlc : link_pair_clusters)
    {
     //?QVector<QPair<int, const NL_Link_Pair*> > positions;
     //?tnlc.find_source_node_positions(tn, positions);
     //?tnlc.find_source_node_positions(tn, positions);

     int pos = tnlc.find_pair_position(pr);

     if(pos != -1)
     {
      if(pr->rewind_level() > 0)
      {
       const NL_Link_Pair* tpr = tnlc.match_pair_with_regent(tn);
       if(tpr)
        continue;
      }

      temp_cluster_map.insertMulti(&tnlc, pos + 1);

     }

//?     pos = tnlc.find_pair_position(jpr);
//     if(pos != -1)
//      temp_cluster_map.insertMulti(&tnlc, -(pos + 1));


//?     for(QPair<int, const NL_Link_Pair*> pos : positions)
//     {
//      temp_cluster_map.insertMulti(&tnlc, pos);
//     }
    }

    //?QMapIterator<const NL_Link_Pair_Cluster*, QPair<int, const NL_Link_Pair*> > it(temp_cluster_map);

    QMapIterator<const NL_Link_Pair_Cluster*, int> it(temp_cluster_map);
    while(it.hasNext())
    {
     it.next();
     const NL_Link_Pair_Cluster* key_lpc = it.key();
     int pos = it.value(); //.first;
     //?const NL_Link_Pair* vpr = it.value().second;

     bool pr_is_new;
     if(pos > 0)
     {
      pr_is_new = false;
      --pos;
     }
     if(pos < 0)
     {
      pr_is_new = true;
      pos = -(pos + 1);
     }



     bool blocked = false;

     // //  next see if the candidate key_lpc already
      //    uses sn or tn
     for(const NL_Link_Pair* key_lpc_pr : key_lpc->linkpairs())
     {
      if(pr_is_new)
      {
       if(key_lpc_pr->source_node() == sn)
       {
        blocked = true;
        break;
       }
       if(key_lpc_pr->target_node() == tn)
       {
        blocked = true;
        break;
       }
      }
      else
      {
       if(key_lpc_pr->source_node() == jsn)
       {
        blocked = true;
        break;
       }
       if(key_lpc_pr->target_node() == jtn)
       {
        blocked = true;
        break;
       }
      }
     }

     if(blocked)
      continue;

     // create a new cluster based on  ?
     NL_Link_Pair_Cluster lpc(link_pair_cluster_index);
     ++link_pair_cluster_index;
     lpc.clone_from(*key_lpc);

     if(pr_is_new)
     {
      lpc.append_link_pair_at_position(pr, pos + 1, 1);
      // //  The sn becomes a source node in lpc
       //    (before was just a target node)
      lpc.increase_node_arity(sn, pr->rewind_level());
      lpc.increase_node_arity__labels(sn->label(), pr->rewind_level());
     }
     else
     {
      lpc.append_link_pair_at_position(jpr, pos + 1, 1);
      // //  The jsn becomes a source node in lpc
       //    (before was just a target node)
      lpc.increase_node_arity(jsn, jpr->rewind_level());
      lpc.increase_node_arity__labels(jsn->label(), pr->rewind_level());
     }


     bool duplicate = false;
     for(const NL_Link_Pair_Cluster& slpc : link_pair_clusters)
     {
      if(lpc == slpc)
      {
       duplicate = true;
       break;
      }
     }

     if(!duplicate)
     {
      link_pair_clusters.insert(lpc);
      if(lpc.cluster_size() > max_cluster_size)
       max_cluster_size = lpc.cluster_size();
     }

    }
   }

   if(jtn == sn)
   {
    // //  If we're here, we're trying to find all clusters
     //    which match pr in terms of source node (viz., the
     //    local variable sn), and "add" jpr to them.

    if(jpr->profile_position() == -1)
    {
     // //  This means jpr is not included in
      //    a containing lambda channel in such
      //    a way that it can be its own regent
     continue;
    }

    if(jpr->shared_rewind_offset() > 0) //jpr->rewind_level() > 0)
    {
     // //  This means tn is blocked by a rewind
     continue;
    }

    //?QMap<const NL_Link_Pair_Cluster*, QPair<int, const NL_Link_Pair*> > temp_cluster_map;
    //?QMap<const NL_Link_Pair_Cluster*, QPair<int, const NL_Link_Pair*> > temp_cluster_map;
    QMap<const NL_Link_Pair_Cluster*, int> temp_cluster_map;

    for(const NL_Link_Pair_Cluster& tnlc : link_pair_clusters)
    {
     //QVector<QPair<int, const NL_Link_Pair*> > positions;



     int pos = tnlc.find_pair_position(pr);
     //?tnlc.find_source_node_positions(sn, positions);
     //tnlc.find_source_node_positions(sn, positions);

     if(pos != -1)
     {
      // //  Check whether jtn is regent in tnlc
       //    not compatible with being a dependent
       //    with respect to jpr

      // //  Is that already checked sufficiently with
       //    just the jpr/pr comparison?
      if(jpr->rewind_level() > 0)
      {
       const NL_Link_Pair* tpr = tnlc.match_pair_with_regent(jtn);
       if(tpr)
        continue;
      }

      temp_cluster_map.insertMulti(&tnlc, pos + 1);

     }

     pos = tnlc.find_pair_position(jpr);

     if(pos != -1)
     {
      if(pr->rewind_level() > 0)
      {
       const NL_Link_Pair* tpr = tnlc.match_pair_with_regent(tn);
       if(tpr)
        continue;
      }

      temp_cluster_map.insertMulti(&tnlc, -(pos + 1) );

     }

    }

//?     for(QPair<int, const NL_Link_Pair*> pos : positions)
//     {
//      if(tnlc.cluster_size() > 1)
//      {
//       int ks = tnlc.cluster_size();
//       QString s = "";
//      }

//      temp_cluster_map.insertMulti(&tnlc, pos);
//     }

    //?QMapIterator<const NL_Link_Pair_Cluster*, QPair<int, const NL_Link_Pair*> > it(temp_cluster_map);
    QMapIterator<const NL_Link_Pair_Cluster*, int> it(temp_cluster_map);
    while(it.hasNext())
    {
     it.next();
     const NL_Link_Pair_Cluster* key_lpc = it.key();
     int pos = it.value(); //.first;
     //?const NL_Link_Pair* vpr = it.value().second;

     bool pr_is_new;
     if(pos > 0)
     {
      pr_is_new = false;
      --pos;
     }
     if(pos < 0)
     {
      pr_is_new = true;
      pos = -(pos + 1);
     }

     bool blocked = false;

     // //  next see if the candidate key_lpc already
      //    uses tn
     for(const NL_Link_Pair* key_lpc_pr : key_lpc->linkpairs())
     {
      if(pr_is_new)
      {
       if(key_lpc_pr->source_node() == sn)
       {
        blocked = true;
        break;
       }
       if(key_lpc_pr->target_node() == tn)
       {
        blocked = true;
        break;
       }
      }
      else
      {
       if(key_lpc_pr->source_node() == jsn)
       {
        blocked = true;
        break;
       }
       if(key_lpc_pr->target_node() == jtn)
       {
        blocked = true;
        break;
       }
      }
     }

     if(blocked)
      continue;

     // create a new cluster based on key_lpc
     NL_Link_Pair_Cluster lpc(link_pair_cluster_index);
     ++link_pair_cluster_index;
     lpc.clone_from(*key_lpc);

     if(pr_is_new)
     {
      //?lpc.prepend_link_pair_at_position(pr, pos, 1);
      //?lpc.append_link_pair_at_position(pr, pos, 1);
      lpc.append_link_pair_at_position(pr, pos + 1, 1);

      // //  The sn becomes a source node in lpc
       //    with sn == jtn as target node
      lpc.increase_node_arity(sn, pr->rewind_level());
      lpc.increase_node_arity__labels(sn->label(), pr->rewind_level());
     }
     else
     {
      lpc.prepend_link_pair_at_position(jpr, pos, 1);

      // //  The jsn becomes a source node in lpc
       //    with sn == jtn as target node
      lpc.increase_node_arity(jsn, jpr->rewind_level());
      lpc.increase_node_arity__labels(jsn->label(), jpr->rewind_level());
     }

     bool duplicate = false;
     for(const NL_Link_Pair_Cluster& slpc : link_pair_clusters)
     {
      if(lpc == slpc)
      {
       duplicate = true;
       break;
      }
     }

     if(!duplicate)
     {
      link_pair_clusters.insert(lpc);

      if(lpc.cluster_size() > max_cluster_size)
       max_cluster_size = lpc.cluster_size();
     }
    }
   }
   // //  Continue ...
   if(jsn == sn)
   {

    // //  Check if pr and jpr are compatible

    if(jpr->source_lexclass() != pr->source_lexclass())
    {
     continue;
    }

    if(jtn == tn)
    {
     // //  This means two pairs which assign the same
      //    target node to two different lambda positions.
      //    Can we safely ignore this case?
     continue;
    }

    if(jpr->lambda_position() == pr->lambda_position())
    {
     if(jpr->rewind_level() == pr->rewind_level())
     {
      // //  They conflict, compating for the same lambda
       //    position.
      continue;
     }
     else
     {
      // //  Anything here?
     }
    }

    // //  Insertions for rewind should only occur
     //    between pairs with least difference in
     //    rewind level
    signed int rewind_offset = jpr->rewind_level() - pr->rewind_level();

    if(rewind_offset < -1 || rewind_offset > 1 )
     continue;

//
//    if(jpr->rewind_level() > pr->rewind_level())
//    {
//     if(jpr->rewind_level() > pr->rewind_level() + 1)
//     {
//      continue;
//     }
//    }

//    if(pr->rewind_level() > jpr->rewind_level())
//    {
//     if(pr->rewind_level() > jpr->rewind_level() + 1)
//     {
//      continue;
//     }
//    }


    // //  Once we're here, we're trying to find all clusters
     //    which match pr in terms of source node (viz., the
     //    local variable sn), and "add" jpr to them.

    //?QMap<const NL_Link_Pair_Cluster*, QPair<int, const NL_Link_Pair*> > temp_cluster_map;
    //?QMap<const NL_Link_Pair_Cluster*, int> temp_cluster_map;
    QMap<const NL_Link_Pair_Cluster*, int> temp_cluster_map;
    for(const NL_Link_Pair_Cluster& tnlc : link_pair_clusters)
    {
     const NL_Link_Pair* match_pr = tnlc.find_source_target_duplicate(jpr);
     if(match_pr)
     {
      // //  The candidate pair is already in the cluster
       //    with a different rewind level
      continue;
     }


     //?QVector<QPair<int, const NL_Link_Pair*> > positions;
     int pos = tnlc.find_pair_position(pr);
     //?tnlc.find_source_node_positions(sn, positions);

     if(pos != -1)
      temp_cluster_map.insertMulti(&tnlc, pos + 1);


     //?pos = tnlc.find_pair_position(jpr);
     //?tnlc.find_source_node_positions(sn, positions);


//?
//     if(pos != -1)
//      temp_cluster_map.insertMulti(&tnlc, -(pos + 1));


//?     for(QPair<int, const NL_Link_Pair*> pos : positions)
//     {
//      temp_cluster_map.insertMulti(&tnlc, pos);
//     }
    }

    // //  temp_cluster_map has all clusters where sn appears somewhere.
    //?QMapIterator<const NL_Link_Pair_Cluster*, QPair<int, const NL_Link_Pair*> > it(temp_cluster_map);
    QMapIterator<const NL_Link_Pair_Cluster*, int> it(temp_cluster_map);
    while(it.hasNext())
    {
     it.next();
     const NL_Link_Pair_Cluster* key_lpc = it.key();
     int pos = it.value(); //.first;

     bool pr_is_new;
     if(pos > 0)
     {
      pr_is_new = false;
      --pos;
     }
     if(pos < 0)
     {
      pr_is_new = true;
      pos = -(pos + 1);
     }


     //?const NL_Link_Pair* vpr = it.value().second;


     QString ksh = key_lpc->short_summary();


//?    Was this checked for?
//     // //  if key_lpc does not already have assigned
//      //    the same lambda position as jpr ...
//     if(jpr->lambda_position() == pr->lambda_position()) //vpr->lambda_position())
//      continue;


     // //  or repeat the same target node
      //    (check for occasions when in real NL
      //    a target node might duplicate?)
     if(jpr->target_node() == pr->target_node()) //vpr->target_node())
      continue;


     // //  pos holds position of sn in overall lexpair
      //    list; we want to insert at the position
      //    relative to pos for sn's own lambda
     int pos_offset = pr_is_new? pr->lambda_position() : jpr->lambda_position();


     bool lambda_blocked = false;

     // //  next see if the candidate key_lpc has the
      //    pr or jpr (whichever is new) lambda position "open"
     for(const NL_Link_Pair* kpr : key_lpc->linkpairs())
     {
      if(kpr->lambda_position() == pos_offset)
      {
       if(pr_is_new)
       {
        if(kpr->rewind_level() == pr->rewind_level())
        {
         lambda_blocked = true;
         break;
        }
       }
       else
       {
        if(kpr->rewind_level() == jpr->rewind_level())
        {
         lambda_blocked = true;
         break;
        }
       }
      }

//      if(pr_is_new)
//?      {
//?      }
//      else
//      {
//       if(jpr->lambda_position() == pos_offset)
//       {
//        lambda_blocked = true;
//        break;
//       }
//      }
     }

     if(lambda_blocked)
      continue;



     // //  create a new cluster based on key_lpc
     NL_Link_Pair_Cluster lpc(link_pair_cluster_index);
     ++link_pair_cluster_index;


     lpc.clone_from(*key_lpc);


     int dc = pos_offset == 0 ? 1 : 0;

     if(pr_is_new)
     {
      if(rewind_offset == 1)
       lpc.prepend_link_pair_at_position(pr, pos + pos_offset, dc);

      //?
      // //  Insert after pr
      else if(rewind_offset == -1)
       lpc.append_link_pair_at_position(pr, pos + pos_offset + 1, dc);

      else
      //?lpc.append_link_pair_at_position(pr, pos + pos_offset, dc);

       lpc.prepend_link_pair_at_position(pr, pos + pos_offset, dc);

      // //  The jsn as source node has another node in it lambda channel
      lpc.increase_node_arity(sn, pr->rewind_level());
      lpc.increase_node_arity__labels(sn->label(), pr->rewind_level());
     }
     else
     {
      if(rewind_offset == -1)
       lpc.prepend_link_pair_at_position(jpr, pos + pos_offset, dc);

      //?
      // //  Insert after pr
      else if(rewind_offset == 1)
       lpc.append_link_pair_at_position(jpr, pos + pos_offset + 1, dc);

      else
       lpc.append_link_pair_at_position(jpr, pos + pos_offset, dc);

      // //  The jsn as source node has another node in its lambda channel
      lpc.increase_node_arity(jsn, jpr->rewind_level());
      lpc.increase_node_arity__labels(jsn->label(), jpr->rewind_level());
     }

      //?lpc.mark_regent(pos);

     bool duplicate = false;
     for(const NL_Link_Pair_Cluster& slpc : link_pair_clusters)
     {
      if(slpc.cluster_size() == 3)
      {
       QString sh = slpc.short_summary();
       CAON_DEBUG_NOOP
      }
      if(lpc == slpc)
      {
       duplicate = true;
       break;
      }
     }

     if(!duplicate)
     {
      link_pair_clusters.insert(lpc);

      if(lpc.cluster_size() > max_cluster_size)
       max_cluster_size = lpc.cluster_size();
     }
    }
   }

  }
 }

 QStringList code_strings;

 QMap<NL_Link_Pair_Cluster, qreal> possible_clusters;

 for(NL_Link_Pair_Cluster lpc : link_pair_clusters)
 {
  if(lpc.cluster_size() == max_cluster_size)
  {
   possible_clusters.insert(lpc, 0);
   //link_pair_clusters.erase(lpc);
  }
 }

 for(NL_Link_Pair_Cluster lpc : possible_clusters.keys())
 {
  QString cs;
  const NL_Link_Pair* pr = prepare_code_string(lpc, cs);
  if(pr)
  {
   // //  The cluster is incomplete ...
  }
  else
  {
   code_strings.push_back(cs);
   qDebug() << cs;
  }
 }
 //QStringList code_strings;



}


const NL_Link_Pair* NL_Graph_Build::prepare_code_string(NL_Link_Pair_Cluster& lpc,
  QString& result_string)
{
 const NL_Link_Pair* result = nullptr;

 //?const NL_Link_Pair* ref_pr = nullptr;

 //?QMap<caon_ptr<RE_Node>, QMap<int, QString> > lambda_sequences;
 //?QMap<caon_ptr<RE_Node>, QString> lexc;

 QMap<const NL_Link_Pair*, QPair<int, QVector<caon_ptr<RE_Node> > > >  lambda_sequences;

 QVector<const NL_Link_Pair*> lp = QVector<const NL_Link_Pair*>::fromList(lpc.linkpairs());
 QVector<int> dcv = QVector<int>::fromList(lpc.depth_change());

 QMap<caon_ptr<RE_Node>,
   QPair<const NL_Link_Pair*, const NL_Link_Pair*> > source_node_to_link_pair;

 QMap<QString,
   QPair<const NL_Link_Pair*, const NL_Link_Pair*> > source_node_to_link_pair__debug;

 int depth = 0;
 int current_rewind_level = 0;

 //?caon_ptr<RE_Node> current_head_node = nullptr;
 const NL_Link_Pair* current_head_pair = nullptr;

 //current_head_pair
 QStack<const NL_Link_Pair*> head_pairs;

 //QStack<caon_ptr<RE_Node> > head_nodes;

 //?start_position
 for(int i = 0; i < lp.length(); ++i)
 {
  const NL_Link_Pair* pr = lp[i];

  const NL_Link_Pair* head_pr;

  if(current_head_pair)
  {
   if(current_head_pair->source_node() == pr->source_node())
   {
    head_pr = current_head_pair;
   }
   else
    head_pr = pr;
  }
  else
   head_pr = pr;

  caon_ptr<RE_Node> sn = pr->source_node();
  caon_ptr<RE_Node> tn = pr->target_node();

  CAON_PTR_DEBUG(RE_Node ,sn)
  CAON_PTR_DEBUG(RE_Node ,tn)

  if(pr->profile_position() != -1)
  {
   // //  I.e. the tn will be a head node at some point
   if(!source_node_to_link_pair.contains(tn))
   {
    // //  Keep track of which pr had tn as target node
     //    in case the head never shows up
    source_node_to_link_pair[tn] = {pr, nullptr};


    source_node_to_link_pair__debug[tn->label()] = {pr, nullptr};
    //?ref_pr = pr;
   }
  }

  if(!lambda_sequences.contains(head_pr))
  {
   //++lambda_sequences[pr].first;
   lambda_sequences[head_pr] = {0, QVector<caon_ptr<RE_Node> >(
      head_pr->source_lexclass()->lambda_channel().size(), nullptr
      )};

   source_node_to_link_pair[head_pr->source_node()].second = head_pr;


   source_node_to_link_pair__debug[head_pr->source_node()->label()].second = head_pr;
  }


  // //  pr->lambda_position(), not
   //    head_pr->lambda_position()
  int lambda_pos = pr->lambda_position();
  ++lambda_sequences[head_pr].first;
  lambda_sequences[head_pr].second[lambda_pos] = tn;


  int rl = pr->rewind_level();

  if(rl > current_rewind_level)
  {
   result_string += QString(rl - current_rewind_level, ')');
   result_string += " ";
   for(int j = current_rewind_level; j < rl; ++j)
   {
    //?
    current_head_pair = head_pairs.pop();
//    CAON_PTR_DEBUG(RE_Node ,current_head_node)
//    CAON_DEBUG_NOOP
   }
   depth -= (rl - current_rewind_level);
  }
  current_rewind_level = rl;


  int dc = dcv[i];
  int dc1 = 0;
  if(i < dcv.length() - 1)
  {
   dc1 = dcv[i + 1];
  }

  caon_ptr<NL_Token> snt = sn->nl_token();
  caon_ptr<NL_Token> tnt = tn->nl_token();

  current_head_pair = head_pr;

  if(dc == 1 && rl == 0)
  {
   //?current_head_node = sn;
       //?current_head_pair = pr;


   int sr = pr->shared_rewind_level();

   QString parens; //? = QString(sr, '(');

   NL_Lexclass* prs = pr->source_lexclass();
   for(int j = 0; j < sr; ++j)
   {
    prs = prs->profile_channel()[0];

    parens += "(";
    if(j < sr - 1)
     parens += QString("npc :%1 ").arg(prs->label());

    head_pairs.push(pr);
    //?head_nodes.push(sn);
   }

   result_string += QString("%1npc :%2 '%3 ").arg(parens).arg(pr->source_lexclass()->label()).arg(snt->raw_text());

   depth += sr;


   //?++depth;
  }
  else if(rl == 0)
  {
   if(lambda_sequences[current_head_pair].first < lambda_sequences[current_head_pair].second.length())
   {
    // //  Incomplete ...
     //?return current_head_pair;
   }
   else
   {


//?   CAON_PTR_DEBUG(RE_Node ,current_head_node)
    while(true)
    {
     current_head_pair = head_pairs.pop();
     //?current_head_node = head_nodes.pop();
     //?CAON_PTR_DEBUG(RE_Node ,current_head_node)
     if(current_head_pair->source_node() == sn)
      break;
     result_string += ") ";
     --depth;
    }
   }
  }
  //?
  if(lpc.get_node_arity(tn, current_rewind_level) == 0)
  //?if(!lpc.has_node_arity(tn))
  {
   if(lpc.has_node_arity(tn))
   {
    result_string += QString(":%1 ")
      .arg(pr->target_lexclass()->label());
   }
   else
   {
    result_string += QString(":%1 '%2 ")
      .arg(pr->target_lexclass()->label())
      .arg(tnt->raw_text());
   }
  }
//  if(dc1 == 0)
//  {
//   result += QString(":%1 '%2 ")
//     .arg(pr->target_lexclass()->label())
//     .arg(tnt->raw_text());
//  }

//  else if(dc == 0)
//  {
//   result += QString(":%1 '%2 ")
//     .arg(pr->target_lexclass()->label())
//     .arg(tnt->raw_text());
//  }


  //result += ")";
 }

 for(int i = 0; i < depth; ++i)
 {
  result_string += ")";
 }

 QMapIterator<const NL_Link_Pair*, QPair<int, QVector<caon_ptr<RE_Node> > > > it(lambda_sequences);

 while(it.hasNext())
 {
  it.next();
  const NL_Link_Pair* current_pr = it.key();
  for(caon_ptr<RE_Node> n : it.value().second)
  {
   if(n == nullptr)
   {
    result = current_pr;
   }
  }
 }

 QMapIterator<caon_ptr<RE_Node>,
   QPair<const NL_Link_Pair*, const NL_Link_Pair*> >
    it1(source_node_to_link_pair);

 while(it1.hasNext())
 {
  it1.next();
  if(it1.value().second == nullptr)
  {
   return it1.value().first;
  }
 }

 return result;

}


//QString NL_Graph_Build::prepare_code_string(NL_Link_Pair_Cluster& lpc,
//  int start_position)
//{
// QString result;

// QMap<caon_ptr<RE_Node>, QMap<int, QString> > lambda_sequences;

// QMap<caon_ptr<RE_Node>, QString> lexc;

// QVector<const NL_Link_Pair*> lp = QVector<const NL_Link_Pair*>::fromList(lpc.linkpairs());
// QVector<int> dcv = QVector<int>::fromList(lpc.depth_change());


// for(int i = start_position; i < lp.length(); ++i)
// {
//  const NL_Link_Pair* pr = lp[i];
//  int dc = dcv[i];

//  caon_ptr<RE_Node> sn = pr->source_node();
//  caon_ptr<RE_Node> tn = pr->target_node();

//  CAON_PTR_DEBUG(RE_Node ,sn)
//  CAON_PTR_DEBUG(RE_Node ,tn)

//  caon_ptr<NL_Token> snt = sn->nl_token();
//  caon_ptr<NL_Token> tnt = tn->nl_token();

//  lexc[sn] = pr->source_lexclass()->label();

//  QMap<int, QString>& qm = lambda_sequences[sn];

//  //qm[pr->lambda_position()] = QString();
////  caon_ptr<RE_Node> sn = pr->source_node();
////  caon_ptr<RE_Node> tn = pr->target_node();

////  CAON_PTR_DEBUG(RE_Node ,sn)
////  CAON_PTR_DEBUG(RE_Node ,tn)

////  QMap<int, QString>& qm = lambda_sequences[sn];

////  caon_ptr<NL_Token> snt = sn->nl_token();
////  caon_ptr<NL_Token> tnt = tn->nl_token();

////  if(lambda_sequences.contains(sn))
////  {

////  }
////  else
////  {
//   qm[pr->lambda_position()] = QString(":%1 '%2")
//    .arg(pr->target_lexclass()->label())
//    .arg(tnt->raw_text());
////  }
// }

// QMapIterator<caon_ptr<RE_Node>, QMap<int, QString> > it(lambda_sequences);
// while(it.hasNext())
// {
//  it.next();
//  caon_ptr<RE_Node> sn = it.key();
//  QMap<int, QString> sl = it.value();

//  caon_ptr<NL_Token> snt = sn->nl_token();

//  //result += QString("(nlc :%1 '%2 :%3 '%4)")

//  result += QString("(nlc :%1 '%2 %3)")
//    .arg(lexc[sn])
//    .arg(snt->raw_text())
//    .arg(sl.values().join(" "));

// }

// return result;
//}


void NL_Graph_Build::add_word(caon_ptr<RE_Node> node)
{
 caon_ptr<NL_Token> nlt = node->nl_token();

 QString rt = nlt->raw_text();

 NL_Lexclass_Vector nlcv;

 NL_Lexentry* nle = nl_lexicon_->match_lexclass(rt, nlcv);

 nlt->set_lexentry(nle);

 for(NL_Lexclass* nlc : nlcv)
 {
  nodes_by_lexclass_[nlc].push_back(node);
 }

 if(current_node_)
 {
  current_node_ << fr_/rq_.NL_Continue >> node;
 }
 else
 {
  start_node_ = node;
 }
 current_node_ = node;
}





