
#ifndef NL_GRAPH_BUILD__H
#define NL_GRAPH_BUILD__H

#include "accessors.h"
#include "flags.h"


#include "kernel/graph/rz-re-node.h"
#include "kernel/query/rz-re-query.h"

//?
#include "rz-nl/rz-nl-lexicon/rz-nl-link-pair.h"


#include <QList>
#include <QStack>
#include <QMap>
#include <QVector>

#include "rzns.h"


#include <QMap>

RZNS_CLASS_DECLARE(NL ,NL_Lexicon)
RZNS_CLASS_DECLARE(NL ,NL_Lexclass)
RZNS_CLASS_DECLARE(NL ,NL_Link_Pair_Cluster)
USING_RZNS(NL)


RZNS_(RECore)

class RE_Graph_Build;


class NL_Graph_Build
{
 RE_Frame& fr_;
 const RE_Query& rq_;

 caon_ptr<RE_Node> current_node_;
 caon_ptr<RE_Node> start_node_;

 caon_ptr<NL_Lexicon> nl_lexicon_;

 caon_ptr<RE_Graph_Build> graph_build_;

 //QSet<QString> graph_code_set_;

 QMap<NL_Lexclass*, QVector<caon_ptr<RE_Node> > > nodes_by_lexclass_;

 void check_forward_link_pairs(caon_ptr<RE_Node> start_node, QSet<NL_Link_Pair>& link_pairs, int& link_pair_index);

 void check_lamdba_matches(caon_ptr<RE_Node> potential_source_node, caon_ptr<RE_Node> potential_target_node,
   NL_Lexclass* source_lexclass_with_lambda,
   int offset, int profile_position, NL_Lexclass* potential_target_lexclass,
   QSet<NL_Link_Pair>& link_pairs, int& link_pair_index, int rewind = 0);

 void prepare_graph_code_list(caon_ptr<RE_Node> sentence_root_node, const QSet<NL_Link_Pair>& link_pairs);

 const NL_Link_Pair* prepare_code_string(NL_Link_Pair_Cluster& lpc, QString& result_string);

public:

 NL_Graph_Build(caon_ptr<RE_Graph_Build> graph_build, caon_ptr<NL_Lexicon> nl_lexicon);

 ACCESSORS(caon_ptr<RE_Node> ,current_node)
 ACCESSORS(caon_ptr<RE_Node> ,start_node)


 ACCESSORS(caon_ptr<NL_Lexicon> ,nl_lexicon)

 void add_word(caon_ptr<RE_Node> node);

 void add_punctuation(caon_ptr<RE_Node> node);
 void parse_sentence(caon_ptr<RE_Node> punctuation_node);


};


_RZNS(RECore)

#endif

