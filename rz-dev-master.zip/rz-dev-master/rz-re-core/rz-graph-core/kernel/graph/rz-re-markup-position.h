
#ifndef RZ_RE_MARKUP_POSITION__H
#define RZ_RE_MARKUP_POSITION__H

#include "accessors.h"
#include "flags.h"


#include "kernel/graph/rz-re-node.h"
#include "kernel/query/rz-re-query.h"

#include "tuple/rz-re-tuple-info.h"

#include "code/rz-re-function-def-kinds.h"

#include <QList>
#include <QStack>
#include <QMap>
#include <QVector>

#include "rzns.h"

RZNS_(RECore)


class RE_Token;
class RE_Graph_Build;
class RE_Sentence;
class RE_Sentence_Part;
class RE_Tile_Sentence_Handshake;
class RE_Paralexeme;
class RE_Connectors;

class RE_Markup_Position
{
public:
 flags_(1)
  bool mid_sentence:1;
  bool pending_equalizer_value:1;
  bool possible_pending_equalizer_nested_entry:1;
  bool currently_implied_call_entry:1;
  bool if_block_pending_follow:1;
  bool elsif_block_pending_follow:1;
  bool active_type_indicator_node:1;
  bool holding_retval_node:1;
 //  flag_(4, inside_string_literal);
//  flag_(1, awaiting_tag_);
//  flag_(2, arrow_context);
//  flag_(3, dot_tuple_context);
//  flag_(4, inside_string_literal);
//  flag_(5, inside_compact_regex);
//  flag_(6, inside_long_regex);
//  flag_(7, pre_arrow_context);
// _flags_
 _flags

private:

 enum class Position_States {
  Root, Active_Run_Token, Active_Run_Chief,
  End_Of_Logical_Scope, Data_Entry,
  Run_Cross_Sequence, Run_Pre_Entry, Cross_Run_Chief,
  Block_Entry, Cross_Block_Entry,

 };

 Position_States position_state_;

  //typedef RE_Binary_Relation_Token tRel;
  //typedef tRel::Relation_Labels rLabel;
  //typedef RE_Node RE_Node;


 RE_Graph_Build* graph_build_;
 caon_ptr<RE_Token>  active_run_token_;

 int current_depth_;

// QString acc;
// QStack<caon_ptr<RE_Node>> current_tag_commands_;

 QStack<caon_ptr<RE_Node>> block_chiefs_;
 QStack<caon_ptr<RE_Node>> chiefs_;
 QStack<caon_ptr<RE_Node>> over_chiefs_;
 QStack<caon_ptr<RE_Node>> block_chiefs_ifs_;

 caon_ptr<RE_Node> current_tag_entry_node_;
 caon_ptr<RE_Node> current_function_def_entry_node_;

 caon_ptr<RE_Node> last_pre_entry_node_;
 caon_ptr<RE_Node> last_statement_entry_node_;
 caon_ptr<RE_Node> last_do_map_block_statement_entry_node_;

 caon_ptr<RE_Node> type_indicator_node_;


 void check_append_chief(caon_ptr<RE_Node> new_chief);
 void check_pop_chief();

 void check_if_block_non_continue(caon_ptr<RE_Token> token);
 void reset_if_block_pending_follow();


 RE_Frame& fr_;
 const RE_Query& rq_;

 caon_ptr<RE_Node> current_node_;

 caon_ptr<RE_Node> check_insert_function_def_entry_node(const RE_Tuple_Info& tuple_info);
 caon_ptr<RE_Node> insert_entry_node(const RE_Connectors& connector, bool is_statement_entry,
  QString prefix = QString());
 caon_ptr<RE_Node> insert_block_entry_node(const RE_Connectors& connector);
 caon_ptr<RE_Node> held_equalizer_node_;
 caon_ptr<RE_Node> held_mapkey_node_;
 caon_ptr<RE_Node> held_do_mapkey_node_;

 caon_ptr<RE_Node> held_retval_node_;
 caon_ptr<RE_Node> held_retval_follow_node_;
 caon_ptr<RE_Node> current_do_map_block_entry_node_;
 caon_ptr<RE_Node> current_block_map_entry_node_;

 caon_ptr<RE_Node> last_do_map_inner_block_first_entry_node_;

 caon_ptr<RE_Node> last_function_definition_arrow_node_;

 void read_chiefs();
 void read_block_chiefs();
 void read_over_chiefs();
 void add_block_entry_node(caon_ptr<RE_Node> block_entry_node);
 void finalize_overall_if_block();


public:

 RE_Markup_Position(RE_Graph_Build* graph_build);

 ACCESSORS(caon_ptr<RE_Node> ,current_node)

 RE_Node& get_current_chief();

 //inline caon_ptr<RE_Node>& current_node()

 caon_ptr<RE_Node> check_implied_lambda_tuple(RE_Function_Def_Kinds kind);

 bool current_node_is_symbol_declaration();

 void add_equalizer_token_node(caon_ptr<RE_Node> token_node);

 void add_string_plex_node(caon_ptr<RE_Node> tinfo_node,
  caon_ptr<RE_Node> string_plex_node);

 void add_block_map_entry();
 void add_block_map_leave();

 void add_token_node(caon_ptr<RE_Node> token_node);
 void add_residual_node(caon_ptr<RE_Node> node);
 void add_textmap_key_token_node(caon_ptr<RE_Node> token_node);
 void add_textmap_value_token_node(caon_ptr<RE_Node> token_node);

 void add_arrow_node(caon_ptr<RE_Node> token_node, RE_Function_Def_Kinds kind);

 caon_ptr<RE_Node> current_entry_is_backquoted();
 caon_ptr<RE_Node> check_add_function_def_entry_node_with_label();

 void add_arrow_token_node(caon_ptr<RE_Node> token_node);

 void add_type_indicator(caon_ptr<RE_Node> token_node);

 void complete_function_declaration(caon_ptr<RE_Node> arrow_node,
                                    caon_ptr<RE_Node> proxy_body_node);


 void check_add_retval_nodes(caon_ptr<RE_Node> node);

 caon_ptr<RE_Node> check_add_retval_nodes();

 void add_data_entry(caon_ptr<RE_Node> tuple_info_node);
 void add_data_leave(caon_ptr<RE_Node> tuple_info_node);

 caon_ptr<RE_Tuple_Info> current_tuple_info();


 void add_raw_lisp_token(caon_ptr<RE_Node> token_node);

 void check_cancel_implied_call_entry();
 void check_add_implied_call_entry(); // caon_ptr<RE_Node> token_node = nullptr );

 void add_new_node_as_implied_call_entry();

 void add_call_entry(bool is_statement_entry, QString prefix = QString());
 void leave_expression();

 void close_statement();
 void leave_lexical_scope(int length);
 void leave_logical_scope(int length);

 RE_Tuple_Info::Tuple_Indicators data_chief_indicator();

 void hold_mapkey_node(caon_ptr<RE_Node> node);
 void check_held_mapkey_node(caon_ptr<RE_Node> new_node);
 void hold_do_mapkey_node(caon_ptr<RE_Node> node);


 void hold_retval_node(caon_ptr<RE_Node> node);

};


_RZNS(RECore)

#endif





//enum RE_Markup_States
//{
// Initial_Markup_State, Active_Token, Active_Cross_Token, Active_Continue_Token,
// Active_Cross_Block_Token, Open_Paren_Entry,

// Block2_Entry,

// Open_Brace_Entry, Open_Bracket_Entry,
// Dot_Open_Paren_Entry,
// Double_Dot_Open_Paren_Entry,
// Dot_Open_Brace_Entry,
// Double_Dot_Open_Brace_Entry,
// Dot_Open_Bracket_Entry,
// Double_Dot_Open_Bracket_Entry,
// Open_Semi, Syntax_Error
//};

//enum RZ_Lisp_Markup_Additions
//{
// Token, Open_Paren, Close_Paren, Open_Brace, Close_Brace,
// Open_Bracket, Close_Bracket, Open_Chi, Close_Chi,
// Single_Semi, Dot_Open_Paren, Double_Dot_Open_Paren,
// Dot_Open_Brace, Double_Dot_Open_Brace,
// Dot_Open_Bracket, Double_Dot_Open_Bracket
//};

//enum RZ_Lisp_Markup_Addition_Extra_Action
//{
// Do_Nothing, Push_Chief, Pop_Chief,

//  Push_Paren, Push_Empty_Paren_Pair,
//  Push_Bracket, Push_Empty_Bracket_Pair,
//  Push_Brace, Push_Empty_Brace_Pair,

// Push_Dot_Paren, Push_Empty_Dot_Paren_Pair,
// Push_Dot_Bracket, Push_Empty_Dot_Bracket_Pair,
// Push_Dot_Brace, Push_Empty_Dot_Brace_Pair,

// Push_Double_Dot_Paren, Push_Empty_Double_Dot_Paren_Pair,
// Push_Double_Dot_Bracket, Push_Empty_Double_Dot_Bracket_Pair,
// Push_Double_Dot_Brace, Push_Empty_Double_Dot_Brace_Pair,


//  Pop_Block_Chief, Raise_Error
//};

//struct State_Addition_Pair
//{
// RZ_Lisp_Markup_States state;
// RZ_Lisp_Markup_Additions addition;
// friend bool operator<(const State_Addition_Pair& lhs, const State_Addition_Pair& rhs)
// {
//  if(lhs.state == rhs.state)
//   return lhs.addition < rhs.addition;
//  return lhs.state < rhs.state;
// }
//};

//struct State_Connection_Pair
//{
// RZ_Lisp_Markup_States state;
// rLabel relation_label;
// int depth_offset;
// RZ_Lisp_Markup_Addition_Extra_Action extra_action;
//};


//RZ_Lisp_Markup_States current_markup_state_;

//typedef RZ_Lisp_Node RE_Node;

//rLabel active_relation_label_;

//// caon_ptr<RE_Node> active_run_node;
//// void add_data_text(caon_ptr<RE_Node> data_text_next, caon_ptr<RE_Node>& last_node);
//void add_dot_markup(QChar c);
//void add_double_dot_markup(QChar c);

//void add_inverted_arrow();

//void insert_empty_tuple_node(RZ_Lisp_Empty_Tuple::Empty_Tuple_Kinds k);

//void add_statement_closing_node(caon_ptr<RE_Node> node);

//void add_lara_node(caon_ptr<RE_Node> node);

//void handle_add_token_node(caon_ptr<RE_Node> ctn);
//void handle_add_token_node(caon_ptr<RE_Node> ctn, RZ_Lisp_Markup_States markup_state);

//void check_setter_token();
//void check_arrow_context();
//void check_dot_tuple_context();
//void check_dot_tuple_context(RZ_Lisp_Markup_States markup_state, caon_ptr<RE_Node> active_node);
//void check_chief(caon_ptr<RE_Node> previous_active_node);
//void check_block_chief();
//void add_token_node(caon_ptr<RE_Node> ctn);
//void mark_non_leaf(RZ_Lisp_Token* crt);

//void insert_arrow_node(caon_ptr<RE_Node> arrow_node_to_add,
// caon_ptr<RE_Node> pre_arrow_node,
// rLabel dot_relation, tRel::Relation_Labels dot_cross_relation);

//void insert_arrow_node(caon_ptr<RE_Node> arrow_node_to_add,
// caon_ptr<RE_Node> pre_arrow_node,
// rLabel dot_relation);


//void insert_arrow_node_non_dot_context(caon_ptr<RE_Node> arrow_node_to_add);

//RZ_Lisp_Markup_Position::caon_ptr<RE_Node> add_empty_tuple_node(RZ_Lisp_Empty_Tuple::Empty_Tuple_Kinds k, rLabel rt);

//caon_ptr<RE_Node> check_assignment_initialization_end(caon_ptr<RE_Node> node_to_add);
//void confirm_arrow_context();
//void mark_non_leaf();
//void push_block2_run_node();
//void pop_block2_run_node();
//void check_run_markup_stack();
//void set_active_run_token();
//void standard_add_markup(const State_Connection_Pair scp);
//void add_arrow_node(caon_ptr<RE_Node> ctn);
//inline void mark_non_leaf(caon_ptr<RE_Node> ctn);

//void check_chi_begin_accumulate();

//void add_chi_entry(caon_ptr<RE_Node> n, RZ_Chi_Object* rco, RZ_Chi_Tile* rct);

//void add_chi_entry(caon_ptr<RE_Node> n, RZ_Chi_Object* rco)
//{
// add_chi_entry(n, rco, nullptr);
//}

//void add_chi_entry(caon_ptr<RE_Node> n, RZ_Chi_Tile* rct)
//{
// add_chi_entry(n, nullptr, rct);
//}

//// void insert_arrow_node_non_dot_context(caon_ptr<RE_Node> arrow_node_to_add);

//template<RZ_Lisp_Markup_Additions New_Markup>
//void add_markup()
//{
// switch(current_markup_state_)
// {
// case Initial_Markup_State: add_markup<Initial_Markup_State, New_Markup>(); break;
// case Active_Token: add_markup<Active_Token, New_Markup>(); break;
// case Active_Cross_Token: add_markup<Active_Cross_Token, New_Markup>(); break;
// case Open_Semi: add_markup<Open_Semi, New_Markup>(); break;
// case Active_Cross_Block_Token: add_markup<Active_Cross_Block_Token, New_Markup>(); break;

//  // // An "Entry" markup here implies either a closed
//  //    empty tuple or a nested tuple as the first element
//  //    of its enclosing tuple
// case Open_Paren_Entry: add_markup<Open_Paren_Entry, New_Markup>(); break;
// case Open_Brace_Entry: add_markup<Open_Brace_Entry, New_Markup>(); break;
// case Open_Bracket_Entry: add_markup<Open_Bracket_Entry, New_Markup>(); break;
////  case Open_Block_Entry: add_markup<Open_Block_Entry, New_Markup>(); break;

// case Dot_Open_Paren_Entry: add_markup<Dot_Open_Paren_Entry, New_Markup>(); break;
// case Double_Dot_Open_Paren_Entry: add_markup<Double_Dot_Open_Paren_Entry, New_Markup>(); break;

// case Dot_Open_Bracket_Entry: add_markup<Dot_Open_Bracket_Entry, New_Markup>(); break;
// case Double_Dot_Open_Bracket_Entry: add_markup<Double_Dot_Open_Bracket_Entry, New_Markup>(); break;

// case Dot_Open_Brace_Entry: add_markup<Dot_Open_Brace_Entry, New_Markup>(); break;
// case Double_Dot_Open_Brace_Entry: add_markup<Double_Dot_Open_Brace_Entry, New_Markup>(); break;

// }

//}

//template<RZ_Lisp_Markup_States Current_State, RZ_Lisp_Markup_Additions New_Markup>
//void add_markup()
//{
// State_Addition_Pair sap{Current_State, New_Markup};
// if(connection_map.contains(sap))
// {
//  const State_Connection_Pair scp = connection_map[sap];
//  standard_add_markup( scp );
// }
//}

