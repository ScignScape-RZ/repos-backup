
#ifndef RZ_RE_ROOT__H
#define RZ_RE_ROOT__H


#include "rz-relae/relae-node-ptr.h"

#include "rz-re-dominion.h"

#include "rzns.h"

RZNS_(RECore)

class RE_Document;

class RE_Root
{
 RE_Document* document_;

public:

 RE_Root(RE_Document* document);

 QString document_path();
};

_RZNS(RECore)


#endif
