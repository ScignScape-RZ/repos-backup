
#include "rz-ngml-tile.h"

#include "rzns.h"

USING_RZNS(NGML)

NGML_Tile::NGML_Tile(QString raw_text,
  int starting_line_number, int ending_line_number)
 : Flags(0), starting_line_number_(starting_line_number),
   ending_line_number_(ending_line_number), raw_text_(raw_text)
{

}

QString NGML_Tile::thumbnail(int length, int ellipsis) const
{
 QString result = raw_text_.trimmed().left(length);
 if(ellipsis > 0 && raw_text_.size() > length)
  result += QString(ellipsis, '.');
 return result;
}


