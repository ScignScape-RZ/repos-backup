
#include "rz-graph-embed-run-valuer.h"

#include "rz-graph-valuer/valuer/rz-lisp-graph-valuer.h"

#include "rz-graph-valuer/scope/rz-lisp-graph-user-package.h"
#include "rz-graph-valuer/scope/rz-lisp-graph-user-class.h"

#include "rz-graph-valuer/vector/rz-lisp-vector.h"

//#include "rz-graph-nglp/document/rz-nglp-ngml-interface.h"
//#include "rz-graph-nglp/document/rz-nglp-lisp-interface.h"

#include <QDebug>

#include <QStringList>


USING_RZNS(GEmbed)

//USING_RZNS(NGLP)



RZ_Graph_Embed_Run_Valuer::RZ_Graph_Embed_Run_Valuer(RZ_Lisp_Graph_Valuer& valuer)
 : valuer_(valuer), current_user_package_(nullptr), default_user_package_(nullptr),
   current_user_class_(nullptr), default_user_class_(nullptr)
{
}

void RZ_Graph_Embed_Run_Valuer::enter_package(QString qs)
{
 if(qs.startsWith(':'))
  qs = qs.mid(1);

 caon_ptr<RZ_Lisp_Graph_User_Package> pkg = valuer_.get_user_package_by_name(qs);

 if(!pkg)
 {
  qs = qs.toLower();
  pkg = valuer_.get_user_package_by_name(qs);
 }
 if(pkg)
 {
  current_user_package_ = pkg;
  if(!default_user_package_)
   default_user_package_ = pkg;
 }
}



void RZ_Graph_Embed_Run_Valuer::enter_class(QString qs)
{
 if(qs.startsWith(':'))
  qs = qs.mid(1);

 caon_ptr<RZ_Lisp_Graph_User_Class> cls = valuer_.get_user_class_by_name(qs);

 if(!cls)
 {
  qs = qs.toLower();
  cls = valuer_.get_user_class_by_name(qs);
 }
 if(cls)
 {
  current_user_class_ = cls;
  if(!default_user_class_)
   default_user_class_ = cls;
 }
}




void RZ_Graph_Embed_Run_Valuer::valuer_deferred_callback(QString qs)
{
 valuer_.run_deferred_callback(qs);
}


//void RZ_Graph_Embed_Run_Valuer::nglp_analyze(QString source, RZ_Lisp_Graph_User_Package* pkg)
//{
// if(!pkg)
// {
//  if(default_user_package_)
//   pkg = default_user_package_;
//  else
//   // //  Or an error that there is no pkg for analysis?
//   return;
// }

// NGLP_Lisp_Interface rnli(this);
// NGLP_NGML_Interface rnni(rnli);
// rnni.analyze(source);
//}

