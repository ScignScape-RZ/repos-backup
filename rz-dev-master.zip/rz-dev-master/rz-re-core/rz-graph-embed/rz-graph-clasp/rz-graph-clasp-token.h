#ifndef RUN__RZ_GRAPH_CLASP_TOKEN__H
#define RUN__RZ_GRAPH_CLASP_TOKEN__H


#include <QMap>
#include <QString>

#include "rzns.h"

#include "accessors.h"

#include "rz-graph-token/token/token-kinds.h"

#include "rz-relae/relae-caon-ptr.h"

#include "rz-graph-embed/rz-graph-embed-token.h"


RZNS_(RZClasp)

 class RZ_Clasp_Source_Element;

_RZNS(RZClasp)

USING_RZNS(RZClasp)


RZNS_(GEmbed)

class RZ_Graph_Embed_Package;


class RZ_Graph_Clasp_Token : public RZ_Graph_Embed_Token
{
 caon_ptr<RZ_Clasp_Source_Element> source_element_;

public:

 RZ_Graph_Clasp_Token(QString raw_text, Basic_Token_Kinds kind);

 ACCESSORS(caon_ptr<RZ_Clasp_Source_Element> ,source_element)

};

_RZNS(GEmbed)


#endif
