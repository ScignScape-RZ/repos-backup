
#include "rz-graph-embed-check.h"

#include <QDebug>

USING_RZNS(GEmbed)


//void RZ_Graph_Embed_Check::docheck()
//{
// qDebug() << "docheck";
//}
