
#include "rz-graph-embed-package.h"

USING_RZNS(GEmbed)

RZ_Graph_Embed_Package::RZ_Graph_Embed_Package(QString name)
 : name_(name)
{

}
