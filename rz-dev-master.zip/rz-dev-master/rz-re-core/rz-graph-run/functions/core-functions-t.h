
//?RZ_LISP_GRAPH_FUNCTION_DECLARE(use-dominion, Use_Dominion, 1, Preempt)

//RZ_LISP_GRAPH_FUNCTION_DECLARE(import, Haskell_Import, 0, Preempt)
