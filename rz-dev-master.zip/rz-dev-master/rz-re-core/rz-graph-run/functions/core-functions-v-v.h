
RZ_LISP_GRAPH_FUNCTION_DECLARE(=, Set_Equal, 2, Preempt)

RZ_LISP_GRAPH_FUNCTION_DECLARE(==, Set_Equal_Via_Type, 2, Preempt)

RZ_LISP_GRAPH_FUNCTION_DECLARE(===, Set_Preinit_To_Equal, 2, Preempt)




  //RZ_LISP_GRAPH_FUNCTION_DECLARE(?=, Set_If_False),
