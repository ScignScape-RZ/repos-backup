//?//
//RZ_LISP_GRAPH_FUNCTION_DECLARE(upload-resource, Upload_Resource, 0, Valuer_N)
//?//

//RZ_LISP_GRAPH_FUNCTION_DECLARE(within, Within, 0, Valuer)

//RZ_LISP_GRAPH_FUNCTION_DECLARE(assume, Assume, 0, Valuer)

//?RZ_LISP_GRAPH_FUNCTION_DECLARE(nglp-analyze, NGLP_Analyze, 0, Valuer_N)

RZ_LISP_GRAPH_FUNCTION_DECLARE(-#, Haskell_Setting, 0, Valuer_CB)

RZ_LISP_GRAPH_FUNCTION_DECLARE(import, Haskell_Import, 0, Valuer_CB)

RZ_LISP_GRAPH_FUNCTION_DECLARE(enum, Enum, 0, Valuer_CB)

RZ_LISP_GRAPH_FUNCTION_DECLARE(else, Else, 0, Valuer_CB)

RZ_LISP_GRAPH_FUNCTION_DECLARE(caserun, Caserun, 0, Valuer_CB)

RZ_LISP_GRAPH_FUNCTION_DECLARE(producing, Set_Production_Mode, 0, Valuer_CB)
