
RZ_LISP_GRAPH_FUNCTION_DECLARE(rz:debug-hook, Debug_Hook, 0, Valuer_DC)
