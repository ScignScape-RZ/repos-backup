
//RZ_LISP_GRAPH_FUNCTION_DECLARE(pr, print, 0, Defer)

//?//
//RZ_LISP_GRAPH_FUNCTION_DECLARE(pr, print, 0, Defer)

//RZ_LISP_GRAPH_FUNCTION_DECLARE(grow-dominion, Grow_Dominion, 0, Valuer_N)

//RZ_LISP_GRAPH_FUNCTION_DECLARE(lara_, Enter_Lara, 0, Valuer_N)
//RZ_LISP_GRAPH_FUNCTION_DECLARE(_lara, Leave_Lara, 0, Valuer_N)

//RZ_LISP_GRAPH_FUNCTION_DECLARE(_lisp, Leave_Paste_Lisp, 0, Valuer_N)

//RZ_LISP_GRAPH_FUNCTION_DECLARE(get-lara, Get_Lara, 0, Valuer_N)

//RZ_LISP_GRAPH_FUNCTION_DECLARE(get-data-layer, Get_Data_Layer, 0, Valuer_N)


//RZ_LISP_GRAPH_FUNCTION_DECLARE(else, Else, 0, Valuer_N)

//RZ_LISP_GRAPH_FUNCTION_DECLARE(prs, Prs, 0, Valuer_N)
//?//


//RZ_LISP_GRAPH_FUNCTION_DECLARE(upload-resource, Upload_Resource, 0, Valuer_N)


//RZ_LISP_GRAPH_FUNCTION_DECLARE(within, Within, 0, Valuer_N)

//RZ_LISP_GRAPH_FUNCTION_DECLARE(assume, Assume, 0, Valuer_N)


//RZ_LISP_GRAPH_FUNCTION_DECLARE(gclos, Generate_Clos, 0, Paste)

//RZ_GCALL_CORE_FUNCTION_OUT(pr, print)

//RZ_LISP_GRAPH_FUNCTION_DECLARE(pr, Print_Line)
//RZ_LISP_GRAPH_FUNCTION_DECLARE(prs, Print_String)
//RZ_LISP_GRAPH_FUNCTION_DECLARE(---, Enter_Logical_Scope_3)
//RZ_LISP_GRAPH_FUNCTION_DECLARE(----, Enter_Logical_Scope_4)
//RZ_LISP_GRAPH_FUNCTION_DECLARE(-----, Enter_Logical_Scope_5)
//RZ_LISP_GRAPH_FUNCTION_DECLARE(------, Enter_Logical_Scope_6)
//RZ_LISP_GRAPH_FUNCTION_DECLARE(project, Set_Project)
//RZ_LISP_GRAPH_FUNCTION_DECLARE(db-save, DB_Save)
