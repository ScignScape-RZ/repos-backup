#ifndef RUN__CORE_CALL_C_C__H
#define RUN__CORE_CALL_C_C__H

#include "types/type-families.h"
//#include "types/ctq-core-extension-class.h"

struct RZ_Core_Symbol;

#include "rzns.h"

RZNS_(GRun)

RZ_LISP_GRAPH_FUNCTION_CODES_(RZ_Graph_Call_CC)
 null = 0,
 #include "core-functions-c-c.h"
_RZ_LISP_GRAPH_FUNCTION_CODES

//?
//RZ_GCALL_IMPLEMENT
//<RZ_GCALL_CC(Regex_Match, Core_Class__Core_Operative)>
//{
// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2)
// {
////  rh << t1 + t2;
// }
//};

//?
//RZ_GCALL_IMPLEMENT
//<RZ_GCALL_CC(Regex_Match, Core_Class__Core_Class)>
//{
// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2)
// {
////  t1.regex_match(t2);
////  rh << t1 + t2;
// }

////? template<typename T1, typename T2>
//// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_GCALL_Simplex& t1, RZ_GCALL_String& t2)
//// {
////  t1.regex_match(rh, t2);
//// }


//};


//?
//RZ_GCALL_IMPLEMENT
//<RZ_GCALL_CC(String_Match, Core_Class__Core_Operative)>
//{
// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2)
// {
////  rh << t1 - t2;
// }
//};





#define TEMP_IMPLEMENT(name, op) \
RZ_GCALL_IMPLEMENT \
<RZ_GCALL_CC(name, Core_Operative__Core_Operative)> \
{ \
 template<typename T1, typename T2> \
 static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2) \
 { \
  rh << t1 op t2; \
 } \
};

//?
//TEMP_IMPLEMENT(Add, +)
//TEMP_IMPLEMENT(Divide, /)
////TEMP_IMPLEMENT(Multiply, *)
//TEMP_IMPLEMENT(Subtract, -)

#undef TEMP_IMPLEMENT

//?
//RZ_GCALL_IMPLEMENT
//<RZ_GCALL_CC(Multiply, Core_Operative__Core_Operative)>
//{
// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2)
// {
//  rh << t1 * t2;
// }
//};


#define TEMP_IMPLEMENT(name, op) \
RZ_GCALL_IMPLEMENT \
<RZ_GCALL_CC(name, Core_Operative__Core_Operative)> \
{ \
 template<typename T1, typename T2> \
 static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2) \
 { \
  rh << RZ_Boolean::from_boolean(t1 op t2); \
 } \
};

//?
//TEMP_IMPLEMENT(Greater_Than, >)
//TEMP_IMPLEMENT(Greater_Than_Or_Equal, >=)
//TEMP_IMPLEMENT(Less_Than, <=)
//TEMP_IMPLEMENT(Less_Than_Or_Equal, <=)

#undef TEMP_IMPLEMENT

//?
//RZ_GCALL_IMPLEMENT
//<RZ_GCALL_CC(Exponent, Core_Operative__Core_Operative)>
//{
// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2)
// {
////  rh << (int)(t1 ^ t2);
// }
//};



//RZ_LISP_GRAPH_FUNCTION_DECLARE(+, Add)
//RZ_LISP_GRAPH_FUNCTION_DECLARE(^, Exponent)
//RZ_LISP_GRAPH_FUNCTION_DECLARE(/, Divide)
//RZ_LISP_GRAPH_FUNCTION_DECLARE(%, Integer_Divide)
//RZ_LISP_GRAPH_FUNCTION_DECLARE(>, Greater_Than)
//RZ_LISP_GRAPH_FUNCTION_DECLARE(>=, Greater_Than_Or_Equal)
//RZ_LISP_GRAPH_FUNCTION_DECLARE(<, Less_Than)
//RZ_LISP_GRAPH_FUNCTION_DECLARE(<=, Less_Than_Or_Equal)
//RZ_LISP_GRAPH_FUNCTION_DECLARE(=?, Is_Equal)
//RZ_LISP_GRAPH_FUNCTION_DECLARE(-, Subtract)



//RZ_GCALL_IMPLEMENT
//<RZ_GCALL_CC(Add, Core_Operative__Core_Operative)>
//{
// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2)
// {
//  rh << t1 + t2;
// }
//};


//RZ_GCALL_IMPLEMENT
//<RZ_GCALL_CC(Greater_Than, Core_Operative__Core_Operative)>
//{
// template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2)
// {
//  rh << RZ_Boolean::from_boolean(t1 > t2);
// }
//};

//RZ_GCALL_IMPLEMENT
//<RZ_GCALL_CC(Less_Than, Core_Operative__Core_Operative)>
//{
// template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2)
// {
//  rh << RZ_Boolean::from_boolean(t1 < t2);
// }
//};


//?
//RZ_GCALL_IMPLEMENT
//<RZ_GCALL_CC(Is_Equal, Core_Operative__Core_Operative)>
//{
// template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T1& t2)
// {
//  rh << RZ_Boolean::from_boolean(t1 == t2);
// }

// template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2)
// {
////?  rh << RZ_Boolean::from_boolean(false);
// }
//};


//RZ_GCALL_IMPLEMENT


//RZ_GCALL_IMPLEMENT
//<RZ_GCALL_CC(Subtract, Core_Operative__Core_Operative)>
//{
// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2)
// {
////  qDebug() << "Sub: ";
// }

// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, int& t1, int& t2)
// {
//  rh << t1 - t2;
// }
//};

_RZNS(GRun)

#endif
