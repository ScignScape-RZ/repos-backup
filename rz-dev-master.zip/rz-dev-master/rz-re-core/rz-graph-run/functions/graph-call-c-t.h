#ifndef RUN__CORE_CALL_C_T__H
#define RUN__CORE_CALL_C_T__H

#include "token/rz-lisp-token.h"

//#include "valuer/rz-lisp-core-valuer.h"
//#include "types/run-type-value.h"

#include "rz-graph-valuer/valuer/rz-lisp-graph-valuer.h"


#include "functions/rz-lisp-graph-function-families.h"

#include "rzns.h"

typedef RZ::RECore::RE_Node tNode;

RZNS_(GRun)

#define RZ_LISP_GRAPH_FUNCTION_DECLARE(str, name, arity, status) name,

RZ_LISP_GRAPH_FUNCTION_CODES_(RZ_Graph_Call_CT)
 null = 0,
 #include "core-functions-c-t.h"
_RZ_LISP_GRAPH_FUNCTION_CODES

#undef RZ_LISP_GRAPH_FUNCTION_DECLARE


RZ_GCALL_IMPLEMENT <RZ_GCALL_CT(Also, Core_Class)>
{
 template<typename T1, typename T2>//, typename RET_Type>
 static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, RZ_Lisp_Token& t2)
 {
 }

 template<typename T1, typename T2>//, typename RET_Type>
 static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Opaque_Type_Symbol& ots, RZ_Lisp_Token& t2)
 {
  rh.valuer().add_file_to_process(rh, ots);
 }

};



//RZ_GCALL_IMPLEMENT <RZ_GCALL_CT(If, Core_Class)>
//{
// template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, RZ_Lisp_Token& t2)
// {
// }

// template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Opaque_Call& t1, RZ_Lisp_Token& t2)
// {
// }

// template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Boolean& t1, RZ_Lisp_Token& t2)
// {
//  if(t1)
//  {
//// ?  rh.valuer->run_token(rh, t2);
//  }
//  else
//  {
//// ?   rh.valuer->run_else_token(rh, t2);
//  }
// }
//};



//?
//RZ_GCALL_IMPLEMENT <RZ_GCALL_CT(DB_Load, Core_Class)>
//{
////? template<typename T1, typename T2>//, typ ename RET_Type>
//// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Core_Symbol& sym, RZ_Lisp_Token& t2)
//// {
//////?  rh.valuer->db_load(rh, sym, t2);
//// }

////? template<typename T1, typename T2>//, typename RET_Type>
//// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_User_Object& uo, RZ_Lisp_Token& t2)
//// {
//////?  rh.valuer->db_load(rh, uo, t2);
//// }

// template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, RZ_Lisp_Token& t2)
// {

// }
//};


//?
//RZ_GCALL_IMPLEMENT
//<RZ_GCALL_CT(Scribe, Core_Class)>
//{
////? template<typename T1, typename T2>
//// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Keyword& t1, RZ_Lisp_Token& t2)
//// {
////  rh.valuer->scribe(rh, t1, t2);
//// }
// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, RZ_Lisp_Token& t2)
// {
// }

//};


//?
//RZ_GCALL_IMPLEMENT
//<RZ_GCALL_CT(Table_Id, Core_Class)>
//{
////? template<typename T1, typename T2>
//// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_User_Object& t1, RZ_Lisp_Token& t2)
//// {
////  rh.valuer->write_table_id(rh, t1, t2);
//////  rh.mark_continue_statement(t2.token_node);
//// }

// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2)
// {

////  rh << t1 + t2;
// }

//};




//?
//RZ_GCALL_IMPLEMENT
//<RZ_GCALL_CT(Resolve, Core_Class)>
//{
////? template<typename T1, typename T2>
//// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_User_Class& t1, RZ_Lisp_Token& t2)
//// {
////  rh.valuer->ref_resolve_logical_symbol(rh, t1, t2);
////  rh.mark_continue_statement(t2.token_node);
//////  rh.flags.continue_statement = true;
//////  rh << t1 + t2;
//// }

////? template<typename T1, typename T2>
//// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_User_Object& t1, RZ_Lisp_Token& t2)
//// {
////  rh.valuer->ref_resolve_logical_symbol(rh, t1, t2);
////  rh.mark_continue_statement(t2.token_node);
//////  rh.flags.continue_statement = true;
//////  rh << t1 + t2;
//// }


// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2)
// {

////  rh << t1 + t2;
// }

//};


//?
//RZ_GCALL_IMPLEMENT
//<RZ_GCALL_CT(Flags_Resolve, Core_Class)>
//{
////? template<typename T1, typename T2>
//// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_User_Class& t1, RZ_Lisp_Token& t2)
//// {
////  rh.valuer->flags_resolve_logical_symbol(rh, t1, t2);
////  rh.mark_continue_statement(t2.token_node);
//// }

////? template<typename T1, typename T2>
//// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_User_Object& t1, RZ_Lisp_Token& t2)
//// {
////  rh.valuer->flags_resolve_logical_symbol(rh, t1, t2);
////  rh.mark_continue_statement(t2.token_node);
//// }


// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2)
// {
// }

//};


//?
//RZ_GCALL_IMPLEMENT
//<RZ_GCALL_CT(Ref_Resolve, Core_Class)>
//{
////? template<typename T1, typename T2>
//// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_User_Class& t1, RZ_Lisp_Token& t2)
//// {
////  rh.valuer->ref_resolve_logical_symbol(rh, t1, t2);
////  rh.mark_continue_statement(t2.token_node);
//////  rh.flags.continue_statement = true;
//////  rh << t1 + t2;
//// }

////? template<typename T1, typename T2>
//// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_User_Object& t1, RZ_Lisp_Token& t2)
//// {
////  rh.valuer->ref_resolve_logical_symbol(rh, t1, t2);
////  rh.mark_continue_statement(t2.token_node);
//////  rh.flags.continue_statement = true;
//////  rh << t1 + t2;
//// }


// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2)
// {

////  rh << t1 + t2;
// }

//};




//?
//RZ_GCALL_IMPLEMENT <RZ_GCALL_CT(If, Core_Operative)>
//{
// template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, RZ_Lisp_Token& t2)
// {
// }

// template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Boolean& t1, RZ_Lisp_Token& t2)
// {
//  if(t1)
//  {
//// ?  rh.valuer->run_token(rh, t2);
//  }
//  else
//  {
//// ?   rh.valuer->run_else_token(rh, t2);
//  }
// }
//};

//?
//RZ_GCALL_IMPLEMENT <RZ_GCALL_CT(Elsif, Core_Operative)>
//{
// template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, RZ_Lisp_Token& t2)
// {
// }

// template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Boolean& t1, RZ_Lisp_Token& t2)
// {
//  if(t1)
//  {
//// ?   rh.valuer->run_token(rh, t2);
//  }
//  else
//  {
//// ?   rh.valuer->run_else_token(rh, t2);
//  }
// }
//};


//?
//RZ_GCALL_IMPLEMENT <RZ_GCALL_CT(While, Core_Operative)>
//{

// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, QString& t1, RZ_Lisp_Token& t2)
// {
// }

// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, RZ_Lisp_Token& t2)
// {
//  if(t1)
//  {
//// ?  rh.catch_break();
//// ?  rh.valuer->run_token(rh, t2);
//// ?  rh.flags.recur = !rh.flags.break_loop;
//  }


////  if(t1)
////  {
//////   rh.make_trueval();
////   rh.valuer->run_token(rh, t2);

////   if(rh.flags.break_loop)
////   {
////    qDebug() << "BREAK";
////   }
////  }

// }

//// template<typename T1, typename T2>//, typename RET_Type>
//// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Boolean& t1, RZ_Lisp_Token& t2)
//// {
////  if(t1)
////  {
////   rh.valuer->run_token(rh, t2);
////   qDebug() << " --- BREAK";
////      if(rh.flags.break_loop)
////      {
////       qDebug() << "BREAK";
////      }
////  }


////  if(t1)
////  {
//////   rh.make_trueval();
////   rh.valuer->run_token(rh, t2);

////   if(rh.flags.break_loop)
////   {
////    qDebug() << "BREAK";
////   }
////  }
//// }
//};


_RZNS(GRun)

#endif
