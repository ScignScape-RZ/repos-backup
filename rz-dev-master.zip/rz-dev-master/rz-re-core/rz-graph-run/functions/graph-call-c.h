#ifndef RUN__SINGLE_ARITY__H
#define RUN__SINGLE_ARITY__H

//#include "valuer/rz-symbol.h"

//#include "valuer/rz-lisp-core-valuer.h"

//#include "types/run-type-value.h"

#include "rz-graph-valuer/valuer/rz-lisp-graph-valuer.h"

#include "token/rz-lisp-token.h"

#include "rz-graph-valuer/string/rz-string.h"
#include "rz-graph-valuer/string/rz-keyword.h"


#include "rz-graph-token/rz-lisp-graph-core-function.h"

//#include "valuer/rz-vector.h"
//#include "valuer/rz-map.h"

//#include "user/rz-simplex.h"
//#include "user/rz-rule.h"

#include "functions/rz-lisp-graph-function-families.h"

#include "types/type-families.h"

#include "rzns.h"


RZNS_(GBuild)

class RZ_Lisp_Empty_Tuple;
class RZ_Lisp_Core_Function;
class RZ_Null_Value;

_RZNS(GBuild)


USING_RZNS(GBuild)

USING_RZNS(GVal)



RZNS_(GRun)


#define RZ_LISP_GRAPH_FUNCTION_DECLARE(str, name, arity, status) name,

RZ_LISP_GRAPH_FUNCTION_CODES_(RZ_Graph_Call_C)
 null = 0,
 #include "core-functions-c.h"
_RZ_LISP_GRAPH_FUNCTION_CODES



RZ_GCALL_IMPLEMENT <RZ_GCALL_C(Project_Info, Core_Class)>
{
 template<typename T1, typename T2>//, typename RET_Type>
 static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_String_Plex& t1, RZ_Lisp_Graph_Value_Holder& t2)
 {
  rh.valuer().parse_project_info(rh, t1);
 }

 template<typename T1, typename T2>//, typename RET_Type>
 static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, RZ_Lisp_Graph_Value_Holder& t2)
 {
 }

};



RZ_GCALL_IMPLEMENT <RZ_GCALL_C(Do, Core_Class)>
{
 template<typename T1, typename T2>//, typename RET_Type>
 static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2)
 {
 }
// //   It would be better to separate this into the RZ_Function_Def_Info and do-map cases...
 template<typename T1, typename T2>//, typename RET_Type>
 static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Function_Def_Info& rfdi, T2& t2)
 {
  rh.valuer().init_do_block(rh, rfdi);
 }

};


RZ_GCALL_IMPLEMENT <RZ_GCALL_C(Scan, Core_Class)>
{
 template<typename T1, typename T2>//, typename RET_Type>
 static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, RZ_Lisp_Graph_Value_Holder& t2)
 {
 }

 template<typename T1, typename T2>//, typename RET_Type>
 static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Opaque_Type_Symbol& t1, RZ_Lisp_Graph_Value_Holder& t2)
 {
  rh.valuer().init_scan_block(rh, t1);
 }

 template<typename T1, typename T2>//, typename RET_Type>
 static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Opaque_Call& t1, RZ_Lisp_Graph_Value_Holder& t2)
 {
  rh.valuer().init_scan_block(rh, t1);
 }
};



RZ_GCALL_IMPLEMENT <RZ_GCALL_C(If, Core_Class)>
{
 template<typename T1, typename T2>//, typename RET_Type>
 static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, RZ_Lisp_Graph_Value_Holder& t2)
 {
  //rh.valuer().init_if_block(rh, t1);
 }

 template<typename T1, typename T2>//, typename RET_Type>
 static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Graph_Core_Function& t1, RZ_Lisp_Graph_Value_Holder& t2)
 {
  rh.valuer().init_if_block(rh, t1);
 }

 template<typename T1, typename T2>//, typename RET_Type>
 static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Opaque_Type_Symbol& ots, RZ_Lisp_Graph_Value_Holder& t2)
 {
  rh.valuer().init_if_block(rh, ots);
 }

 template<typename T1, typename T2>//, typename RET_Type>
 static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Opaque_Call& t1, RZ_Lisp_Graph_Value_Holder& t2)
 {
  rh.valuer().init_if_block(rh, t1);
 }
};


RZ_GCALL_IMPLEMENT <RZ_GCALL_C(Elsif, Core_Class)>
{
 template<typename T1, typename T2>//, typename RET_Type>
 static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, RZ_Lisp_Graph_Value_Holder& t2)
 {
  //rh.valuer().init_if_block(rh, t1);
 }

 template<typename T1, typename T2>//, typename RET_Type>
 static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Graph_Core_Function& t1, RZ_Lisp_Graph_Value_Holder& t2)
 {
  rh.valuer().init_elsif_block(rh, t1);
 }

 template<typename T1, typename T2>//, typename RET_Type>
 static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Opaque_Call& t1, RZ_Lisp_Graph_Value_Holder& t2)
 {
  rh.valuer().init_elsif_block(rh, t1);
 }
};




//?
//RZ_GCALL_IMPLEMENT <RZ_GCALL_C(Preen, Core_Operative)>
//{
// template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2)
// {
//  qDebug() << t1;
// }

//};

//RZ_GCALL_IMPLEMENT <RZ_GCALL_C(Preen, Core_Class)>
//{
// template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2)
// {
//  qDebug() << t1;
// }

// template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Symbol& sym, T2& t2)
// {
////  qDebug() << t1;
// }

//};


//RZ_GCALL_IMPLEMENT <RZ_GCALL_C(Print_Line, Core_Operative)>
//{
// template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2)
// {
//  qDebug() << t1;
// }

//};


//RZ_GCALL_IMPLEMENT <RZ_GCALL_C(Set_Project, Core_Class)>
//{

////? template<typename T1, typename T2>
////? static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Symbol& t1, T2& t2)
//// {
////  rh.valuer->set_project(*t1.token);
//// }

// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2)
// {

// }


//};


//??RZ_GCALL_IMPLEMENT <RZ_GCALL_C(Print_Line, Core_Class)>
//{
// template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2)
// {
// // qDebug() << t1.to_string();
// }

// template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Boolean& t1, T2& t2)
// {
//  qDebug() << t1;
// }



//? template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_User_Object& t1, T2& t2)
// {
//  qDebug() << t1.uclass->name + "#";
// }

//? template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Match& t1, RZ_Value_Holder& t2)
// {
//  qDebug() << t1.to_string();
// }

//? template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_GCALL_String& t1, T2& t2)
// {
//  qDebug() << t1.to_string();
// }


//? template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_GCALL_Simplex& t1, T2& t2)
// {
//  qDebug() << t1.to_string();
// }

//? template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Vector& t1, T2& t2)
// {
//  qDebug() << t1.to_string();
// }

//? template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Symbol& t1, T2& t2)
// {
// }

//? template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_User_Function& t1, T2& t2)
// {
// }

//? template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh,
//  RZ_Run_Type_Value& rtv, T2& t2)
// {
//  qDebug() << " PR: " << rtv.name;
// }

//??};

//RZ_GCALL_IMPLEMENT <RZ_GCALL_C(Print_Line, Core_Extension)>
//{
////? template<typename T1, typename T2>//, typename RET_Type>
//// static void run(RZ_Lisp_Graph_Result_Holder& rh,
////  RZ_GCALL_Core_Extension_Object& t1, T2& t2)
//// {

////  qDebug() << t1.to_string();
//////  rh.clear();

//// // rh << t1;
//// }
//};

//RZ_GCALL_IMPLEMENT <RZ_GCALL_C(DB_Save, Core_Class)>
//{
////? template<typename T1, typename T2>//, typename RET_Type>
//// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_User_Object& uo, T2& t2)
//// {
////  rh.valuer->db_save(uo);
//// }

////? template<typename T1, typename T2>//, typename RET_Type>
//// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2)
//// {
//// }


//};



//RZ_GCALL_IMPLEMENT <RZ_GCALL_C(Print_String, Core_Operative)>
//{
// template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2)
// {

//  qDebug() << t1;
////  rh.clear();

//  // rh << t1;
// }

//? template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Symbol& t1, T2& t2)
// {
// }

//? template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_User_Function& t1, T2& t2)
// {
// }

//? template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Run_Type_Value& rtv, T2& t2)
// {
//  qDebug() << " PR: " << rtv.name;
// }


//};

#define RZ_GCALL_TEMP_DEFAULT_IMPLEMENTATION(count) \
RZ_GCALL_IMPLEMENT <RZ_GCALL_C(Enter_Logical_Scope_##count, Core_Class)> \
{ \
 template<typename T1, typename T2> \
 static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_User_Class& cl, RZ_Lisp_Graph_Value_Holder& vh) \
 { \
  rh.valuer().enter_logical_scope(count, rh, cl); \
 } \
 template<typename T1, typename T2> \
 static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_User_Resource& ur, RZ_Lisp_Graph_Value_Holder& vh) \
 { \
  rh.valuer().enter_logical_scope(count, rh, ur); \
 } \
 template<typename T1, typename T2> \
 static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_User_Package& upkg, RZ_Lisp_Graph_Value_Holder& vh) \
 { \
  rh.valuer().enter_logical_scope(count, rh, upkg); \
 } \
 template<typename T1, typename T2> \
 static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Opaque_Type_Symbol& ots, RZ_Lisp_Graph_Value_Holder& vh) \
 { \
  rh.valuer().enter_logical_scope(count, rh, ots); \
 } \
 template<typename T1, typename T2> \
 static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2) \
 { \
 } \
}; \

//?//
RZ_GCALL_IMPLEMENT <RZ_GCALL_C(Enter_Logical_Scope_4, Core_Class)>
{
 template<typename T1, typename T2>
 static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Graph_User_Package& upkg, RZ_Lisp_Graph_Value_Holder& vh)
 {
  rh.valuer().enter_logical_scope(4, rh, upkg);
//?  rh.redirect_to_noop();
//?  rh.embedder()->redirect_to_noop(rh.get_lead_function_node());
 }


 template<typename T1, typename T2>
 static void run(RZ_Lisp_Graph_Result_Holder& rh,
  RZ_Opaque_Type_Symbol& ots, RZ_Lisp_Graph_Value_Holder& vh)
 {
  rh.valuer().enter_logical_scope(4, rh, ots);
 }

// template<typename T1, typename T2>
// static void run(RZ::GVal::RZ_Lisp_Graph_Result_Holder& rh,
//  RZ::GVal::RZ_Opaque_Type_Symbol& ots, RZ::GBuild::RZ_Lisp_Graph_Value_Holder& vh)
// {
//  rh.valuer().enter_logical_scope(4, rh, ots);
// }

// template<typename T1, typename T2>
// static void run(RZ::GVal::RZ_Lisp_Graph_Result_Holder& rh,
//  RZ::GBuild::RZ_Lisp_Empty_Tuple& ots, RZ::GBuild::RZ_Lisp_Graph_Value_Holder& vh)
// {
// }


 template<typename T1, typename T2>
 static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, RZ_Lisp_Graph_Value_Holder& vh)
 {
 }

};

//?//
//RZ_GCALL_IMPLEMENT <RZ_GCALL_C(Enter_Logical_Scope_4, Core_Class)>
//{
// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_User_Class& cl, RZ_Lisp_Graph_Value_Holder& vh)
// {
//  rh.valuer().enter_logical_scope(4, rh, cl);
// }

// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_User_Resource& ur, RZ_Lisp_Graph_Value_Holder& vh)
// {
//  rh.valuer().enter_logical_scope(4, rh, ur);
// }

// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_User_Package& upkg, RZ_Lisp_Graph_Value_Holder& vh)
// {
//  rh.valuer().enter_logical_scope(4, rh, upkg);
// }

// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Opaque_Type_Symbol& ots, RZ_Lisp_Graph_Value_Holder& vh)
// {
//  rh.valuer().enter_logical_scope(4, rh, ots);
// }

// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2)
// {
// }
//};


//RZ_GCALL_IMPLEMENT <RZ_GCALL_C(Enter_Logical_Scope_5, Core_Class)>
//{
// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_User_Class& cl, RZ_Lisp_Graph_Value_Holder& vh)
// {
//  rh.valuer().enter_logical_scope(5, rh, cl);
// }

// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_User_Resource& ur, RZ_Lisp_Graph_Value_Holder& vh)
// {
//  rh.valuer().enter_logical_scope(5, rh, ur);
// }

// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_User_Package& upkg, RZ_Lisp_Graph_Value_Holder& vh)
// {
//  rh.valuer().enter_logical_scope(5, rh, upkg);
// }

// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Opaque_Type_Symbol& ots, RZ_Lisp_Graph_Value_Holder& vh)
// {
//  rh.valuer().enter_logical_scope(5, rh, ots);
// }

// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2)
// {
// }
//};


//?RZ_GCALL_TEMP_DEFAULT_IMPLEMENTATION(3)
//?RZ_GCALL_TEMP_DEFAULT_IMPLEMENTATION(4)
//?RZ_GCALL_TEMP_DEFAULT_IMPLEMENTATION(5)
//?RZ_GCALL_TEMP_DEFAULT_IMPLEMENTATION(6)

////RZ_GCALL_TEMP_DEFAULT_IMPLEMENTATION(3)
// RZ_GCALL_TEMP_DEFAULT_IMPLEMENTATION(4)
////RZ_GCALL_TEMP_DEFAULT_IMPLEMENTATION(5)
////RZ_GCALL_TEMP_DEFAULT_IMPLEMENTATION(6)

#undef RZ_GCALL_TEMP_DEFAULT_IMPLEMENTATION

_RZNS(GRun)


#endif
