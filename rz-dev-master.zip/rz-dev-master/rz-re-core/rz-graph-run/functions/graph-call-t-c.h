#ifndef RUN__CORE_CALL_T_C__H
#define RUN__CORE_CALL_T_C__H

#include "token/rz-lisp-token.h"

//#include "valuer/rz-lisp-core-valuer.h"
//#include "types/run-type-value.h"

#include "rz-graph-valuer/valuer/rz-lisp-graph-valuer.h"


#include "functions/rz-lisp-graph-function-families.h"

#include "rzns.h"

typedef RZ::RECore::RE_Node tNode;

RZNS_(GRun)

#define RZ_LISP_GRAPH_FUNCTION_DECLARE(str, name, arity, status) name,


RZ_LISP_GRAPH_FUNCTION_CODES_(RZ_Graph_Call_TC)
 null = 0,
 #include "core-functions-t-c.h"
_RZ_LISP_GRAPH_FUNCTION_CODES

#undef RZ_LISP_GRAPH_FUNCTION_DECLARE


#undef RZ_LISP_GRAPH_FUNCTION_DECLARE

//?
//RZ_GCALL_IMPLEMENT <RZ_GCALL_TC(Class, Core_Operative)>
//{
// template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Token& t1, T2& t2)
// {
//  tString str = t1.string_value();
//  qDebug() << str;
// }
//};

//?
//RZ_GCALL_IMPLEMENT <RZ_GCALL_TC(Class, Core_Class)>
//{
// template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Token& t1, T2& t2)
// {
//  tString str = t1.string_value();
//  rh.valuer().register_user_class(str);
//  rh.function_token()->redirect_paste(QString("#rz-class_ %1 ;").arg(str));
//  rh.mark_continue_statement(t1.pRestore<tNode>());
// }
//};



RZ_GCALL_IMPLEMENT <RZ_GCALL_TC(Class, Core_Class)>
{
 template<typename T1, typename T2>
 static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Token& t1, T2& t2)
 {
  tString str = t1.string_value();
  rh.valuer().register_user_class(str);
  rh.mark_continue_statement(t1.pRestore<tNode>());

//  tString str = t1.string_value();
//  rh.valuer().register_user_package(str);
//  rh.function_token()->redirect_paste(QString("#rz-package_ %1 ;").arg(str));
//  rh.mark_continue_statement(t1.pRestore<tNode>());
 }

 template<typename T1, typename T2>
 static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2)
 {

 };

};




RZ_GCALL_IMPLEMENT <RZ_GCALL_TC(Namespace, Core_Class)>
{
 template<typename T1, typename T2>
 static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Token& t1, T2& t2)
 {
  tString str = t1.string_value();
  rh.valuer().register_user_namespace(str);
  rh.mark_continue_statement(t1.pRestore<tNode>());
 }

 template<typename T1, typename T2>
 static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2)
 {
 };

};



RZ_GCALL_IMPLEMENT <RZ_GCALL_TC(Package, Core_Class)>
{
 template<typename T1, typename T2>
 static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Token& t1, T2& t2)
 {
  tString str = t1.string_value();
  rh.valuer().register_user_package(str);
//?  rh.function_token()->redirect_paste(QString("#rz-package_ %1 ;").arg(str));
  rh.mark_continue_statement(t1.pRestore<tNode>());

//  tString str = t1.string_value();
//  rh.valuer().register_user_package(str);
//  rh.function_token()->redirect_paste(QString("#rz-package_ %1 ;").arg(str));
//  rh.mark_continue_statement(t1.pRestore<tNode>());
 }

 template<typename T1, typename T2>
 static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2)
 {

 };

};


//?
//RZ_GCALL_IMPLEMENT <RZ_GCALL_TC(Resource, Core_Class)>
//{
// template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Token& t1, T2& t2)
// {
//  tString str = t1.string_value();
//  rh.valuer().register_user_resource(rh, str);

//// ? rh.valuer->declare_user_class(t1);

//  rh.function_token()->redirect_paste(QString("#rz-resource_ %1 ;").arg(str));
////  t1.redirect_lisp(QString("classdef_ ") + str);
////  rh.comment_lisp();
////  qDebug() << str;

//  rh.mark_continue_statement(t1.pRestore<tNode>());
////?  rh.valuer().run_token_as_first_argument(t1, rh);
// }
//};



//};


//RZ_GCALL_IMPLEMENT <RZ_GCALL_TC(Class, Core_Class)>
//{
// template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Token& t1, T2& t2)
// {
//  //RZ_User_Class* cl =
////?  rh.valuer->declare_user_class(t1);
////  tString str = t1.string_value;
////  qDebug() << str;
//  //rh << cl;
////?  rh.valuer->run_token_as_first_argument(t1, rh);
// }



//? template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Token& t1, RZ_Boolean& t2)
// {
//  if(&t2 == &RZ_Boolean::nullval())
//   qDebug() << "null";

//  //RZ_User_Class* cl =
//  rh.valuer->declare_user_class(t1);
//  tString str = t1.string_value;
//  qDebug() << str;
// }
//? };

//? RZ_GCALL_IMPLEMENT <RZ_GCALL_TC(Task, Core_Class)>
//{
// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Token& t1, T2& t2)
// {
////?  rh.valuer->declare_user_task_scope(t1);
////  rh.valuer->run_token_as_first_argument(t1, rh);
// }

// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2)
// {
////?  rh.valuer->declare_user_task_scope(t1);
// }
//};


_RZNS(GRun)

#endif
