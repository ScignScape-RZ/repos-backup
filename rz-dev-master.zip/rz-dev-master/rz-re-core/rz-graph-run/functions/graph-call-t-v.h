#ifndef RUN__CORE_CALL_T_V__H
#define RUN__CORE_CALL_T_V__H

//?#include "token/cdm-lisp-token.h"

//#include "valuer/cdm-lisp-core-valuer.h"

#include "rz-graph-valuer/valuer/rz-lisp-graph-valuer.h"

#include "rzns.h"

RZNS_(GRun)


RZ_LISP_GRAPH_FUNCTION_CODES_(RZ_Graph_Call_TV)
 null = 0,
 #include "core-functions-t-v.h"
_RZ_LISP_GRAPH_FUNCTION_CODES

//?
//RZ_GCALL_IMPLEMENT <RZ_GCALL_TV(Bool_Equal, Internal)>
//{
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Token& token, RZ_Value_Holder& vh)
// {
////?  rh.valuer->set_equal(token, vh);
////  rh.valuer->report_lexical_symbol(t1.string_value, "Reporting symbol");
// }
//};


//?
//RZ_GCALL_IMPLEMENT <RZ_GCALL_TV(Conceptual, Internal)>
//{
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Token& token, RZ_Value_Holder& vh)
// {
////?  tString str = token.string_value;
////?  qDebug() << str;
// }
//};


//?
//RZ_GCALL_IMPLEMENT <RZ_GCALL_TV(Else, Core_Operative)>
//{
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Token& token, RZ_Value_Holder& vh)
// {
////?  rh.valuer->run_token(rh, token);
// }

//// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Token& start_token, tNode* pass_node)
//// {
////  rh.valuer->run_token(rh, start_token);
//// }
//};





//RZ_GCALL_IMPLEMENT<RZ_GCALL_CC(Set_Equal)>
//{
// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2)
// {
//  qDebug() << "T1: ";
//  qDebug() << t1;
////  rh << t1 - t2;
// }

//// template<typename T1, typename T2>
//// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, int& t2)
//// {
////  qDebug() << "T1 !!!: ";
////  qDebug() << t2;
//////  rh << t1 - t2;
//// }

// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Core_Symbol& t1, T2& t2)
// {
//  qDebug() << "T1 !!! ===: ";
//  qDebug() << t2;
////  rh << t1 - t2;
// }

_RZNS(GRun)


#endif
