//#ifndef RUN__CORE_CALL_VT__H
//#define RUN__CORE_CALL_VT__H

//#include "graph/ctq-script-token.h"
//#include "valuer/ctq-core-valuer.h"


//CTQ_CORE_FUNCTION_CODES(Ctq_Core_Call_VT)
//  If = 1,
//_CTQ_CORE_FUNCTION_CODES

//CTQ_CORE_IMPLEMENT <CTQ_TV(If)>
//{
// static void run(Ctq_Result_Holder& rh, Ctq_Script_Token& token, Ctq_Value_Holder& vh)
// {
//  rh.valuer->set_equal(token, vh);
////  rh.valuer->report_lexical_symbol(t1.string_value, "Reporting symbol");
// }
//};






////CTQ_CORE_IMPLEMENT<CTQ_CC(Set_Equal)>
////{
//// template<typename T1, typename T2>
//// static void run(Ctq_Result_Holder& rh, T1& t1, T2& t2)
//// {
////  qDebug() << "T1: ";
////  qDebug() << t1;
//////  rh << t1 - t2;
//// }

////// template<typename T1, typename T2>
////// static void run(Ctq_Result_Holder& rh, T1& t1, int& t2)
////// {
//////  qDebug() << "T1 !!!: ";
//////  qDebug() << t2;
////////  rh << t1 - t2;
////// }

//// template<typename T1, typename T2>
//// static void run(Ctq_Result_Holder& rh, Ctq_Symbol& t1, T2& t2)
//// {
////  qDebug() << "T1 !!! ===: ";
////  qDebug() << t2;
//////  rh << t1 - t2;
//// }


//#endif
