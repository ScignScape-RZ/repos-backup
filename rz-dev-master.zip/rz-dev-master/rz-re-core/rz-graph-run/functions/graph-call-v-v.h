#ifndef RUN__CORE_CALL_V_V__H
#define RUN__CORE_CALL_V_V__H

#include "token/rz-lisp-token.h"

//#include "valuer/rz-lisp-core-valuer.h"
//#include "types/run-type-value.h"

#include "rz-graph-valuer/valuer/rz-lisp-graph-valuer.h"

#include "rz-relae/relae-caon-ptr.h"

#include "functions/rz-lisp-graph-function-families.h"

#include "rzns.h"

RZNS_(GRun)

#define RZ_LISP_GRAPH_FUNCTION_DECLARE(str, name, arity, status) name,

RZ_LISP_GRAPH_FUNCTION_CODES_(RZ_Graph_Call_VV)
 null = 0,
 #include "core-functions-v-v.h"
_RZ_LISP_GRAPH_FUNCTION_CODES

#undef RZ_LISP_GRAPH_FUNCTION_DECLARE

//?
RZ_GCALL_IMPLEMENT
<RZ_GCALL_VV(Set_Equal, Internal)>
{
// template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Core_Symbol& t1, T1& t2)
// {
////  rh << RZ_Boolean::from_boolean(t1 == t2);
// }

// template<typename T1, typename T2>//, typename RET_Type>
 static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Graph_Value_Holder& v1,
                 RZ_Lisp_Graph_Value_Holder& v2)
 {
  caon_ptr<RZ_Lisp_Token> ft = rh.get_lead_function_token();
  if(ft)
  {
   rh.valuer().set_equal(rh, *ft, v1, v2);
  }
 }

 //
// template<typename T1, typename T2>//, typename RET_Type>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2)
// {
// // rh.valuer().set_equal(t1, t2);
////  rh.value_holder = t2;
// }


};


RZ_GCALL_IMPLEMENT
<RZ_GCALL_VV(Set_Equal_Via_Type, Internal)>
{
 static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Graph_Value_Holder& v1,
                 RZ_Lisp_Graph_Value_Holder& v2)
 {
  caon_ptr<RZ_Lisp_Token> ft = rh.get_lead_function_token();
  if(ft)
  {
   rh.valuer().set_equal_via_type(rh, *ft, v1, v2);
  }
 }
};


RZ_GCALL_IMPLEMENT
<RZ_GCALL_VV(Set_Preinit_To_Equal, Internal)>
{
 static void run(RZ_Lisp_Graph_Result_Holder& rh, RZ_Lisp_Graph_Value_Holder& v1,
                 RZ_Lisp_Graph_Value_Holder& v2)
 {
  caon_ptr<RZ_Lisp_Token> ft = rh.get_lead_function_token();
  if(ft)
  {
   rh.valuer().set_preinit_to_equal(rh, *ft, v1, v2);
  }
 }
};


//RZ_GCALL_IMPLEMENT


//RZ_GCALL_IMPLEMENT
//<RZ_GCALL_CC(Subtract, Core_Operative__Core_Operative)>
//{
// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, T1& t1, T2& t2)
// {
////  qDebug() << "Sub: ";
// }

// template<typename T1, typename T2>
// static void run(RZ_Lisp_Graph_Result_Holder& rh, int& t1, int& t2)
// {
//  rh << t1 - t2;
// }
//};

_RZNS(GRun)

#endif
