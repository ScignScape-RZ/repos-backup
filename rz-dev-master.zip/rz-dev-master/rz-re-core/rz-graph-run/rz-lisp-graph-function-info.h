#ifndef RUN__RZ_LISP_GRAPH_FUNCTION_INFO__H
#define RUN__RZ_LISP_GRAPH_FUNCTION_INFO__H


#include <QMap>

#include "functions/rz-lisp-graph-function-families.h"

//?#include "rz/run/functions/rz-lisp-graph-function-family-enum.h"


//#include "core-types.h"


typedef int RZ_Lisp_Graph_Function_Code;

RZNS_(GRun)

struct RZ_Lisp_Graph_Function_Info
{
 RZ_Lisp_Graph_Function_Family Core_Function_Family;
 RZ_Lisp_Graph_Function_Code Core_Function_Code;
 void pre_init();
};

_RZNS(GRun)


#endif
