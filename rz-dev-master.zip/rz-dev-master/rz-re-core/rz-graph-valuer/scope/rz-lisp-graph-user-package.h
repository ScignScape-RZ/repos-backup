
#ifndef RZ_LISP_GRAPH_USER_PACKAGE__H
#define RZ_LISP_GRAPH_USER_PACKAGE__H

#include "accessors.h"
#include "flags.h"

//#include "rz-lisp-value-holder.h"

#include <QString>
#include <QMap>


#include "rz-lisp-graph-scope-token.h"
#include "rz-lisp-graph-logical-scope.h"

#include "rzns.h"
RZNS_(GVal)

class RZ_Lisp_Graph_Logical_Scope;

class RZ_Lisp_Graph_User_Package
{
 QString name_;
 caon_ptr<RZ_Lisp_Graph_Logical_Scope> scope_;

public:

 ACCESSORS(QString ,name)
 ACCESSORS(caon_ptr<RZ_Lisp_Graph_Logical_Scope> ,scope)

 RZ_Lisp_Graph_User_Package(QString name);

 template<typename T>
 caon_ptr<T> pSymbol_as(QString name)
 {
  return scope_->pSymbol_as<T>(name);
 }


 template<typename T>
 friend void operator<<(T& t, const RZ_Lisp_Graph_User_Package&)
 {
 }

 friend void operator<<(QDebug qd, RZ_Lisp_Graph_User_Package&)
 {
//  qd << "<fundef>";
 }


};

_RZNS(GVal)

#endif
