
#include "rz-lisp-graph-user-resource.h"
#include "rz-lisp-graph-logical-scope.h"

#include <QString>
#include <QMap>

USING_RZNS(GVal)

RZ_Lisp_Graph_User_Resource::RZ_Lisp_Graph_User_Resource(QString name)
 : name_(name)
{}

