
#include "rz-match-literal.h"

#include "token/rz-lisp-token.h"


USING_RZNS(GVal)

RZ_Match_Literal::operator tString() const
{
 return to_string();
}

tString RZ_Match_Literal::to_string() const
{
 //if(flags.has_raw_string)
 return tString("/-" + raw_string_ + "->");
 //return token_->string_value();
}

bool RZ_Match_Literal::operator>(const RZ_Match_Literal& rhs) const
{
 return to_string() > rhs.to_string();
}

bool RZ_Match_Literal::operator<(const RZ_Match_Literal& rhs) const
{
 return to_string() < rhs.to_string();
}
