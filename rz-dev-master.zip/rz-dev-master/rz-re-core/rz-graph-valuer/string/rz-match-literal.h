#ifndef RZ__RZ_CORE__STRING__RZ_MATCH_LITERAL__H
#define RZ__RZ_CORE__STRING__RZ_MATCH_LITERAL__H

#include "rz-typedefs.h"
#include "flags.h"

#include <QDebug>
#include <QString>

#include "accessors.h"

#include "rzns.h"

RZNS_(GBuild)

class RZ_Lisp_Token;
class RZ_Lisp_Graph_Result_Holder;

_RZNS(GBuild)

USING_RZNS(GBuild)


RZNS_(GVal)


class RZ_Match_Literal
{

private:
 //RZ_Lisp_Token* token_;
 tString raw_string_;


public:

 //ACCESSORS(RZ_Lisp_Token* ,token)
 ACCESSORS(tString ,raw_string)


 operator tString() const;

 tString to_string() const;

 friend void operator<<(QDebug lhs, const RZ_Match_Literal& rhs)
 {
  tString s = rhs.to_string();
  lhs << s;
 }

 //RZ_Match_Literal(RZ_Lisp_Token* t = nullptr):Flags(0),token_(t){}
 RZ_Match_Literal(tString s): //Flags(0),token_(nullptr),
   raw_string_(s)
 {
 }

 friend bool operator==(const RZ_Match_Literal& lhs, const RZ_Match_Literal& rhs)
 {
  return lhs.to_string() == rhs.to_string();
 }

 operator bool()
 {
  tString s = to_string();
  return s.isEmpty() || s.isNull();
 }

 bool operator>(const RZ_Match_Literal& rhs) const;
 bool operator<(const RZ_Match_Literal& rhs) const;

  template<typename T>
  friend T& operator<<(T& t, const RZ_Match_Literal& s)
  {
   return t << s.to_string();
  }

  friend RZ_Lisp_Graph_Result_Holder& operator<<(RZ_Lisp_Graph_Result_Holder& rh, const RZ_Match_Literal& s)
  {
   rh << s;
   return rh;
  }


  RZ_Match_Literal operator+(const RZ_Match_Literal& rhs )
  {
   return RZ_Match_Literal( to_string() + rhs.to_string() );
  }

  template<typename T>
  bool operator>(const T& rhs) const
  {
   return false;
  }

  template<typename T>
  bool operator<(const T& rhs) const
  {
   return false;
  }

  template<typename T>
  friend bool operator>(const T& lhs, const RZ_Match_Literal& rhs)
  {
   return false;
  }

  template<typename T>
  friend bool operator<(const T& lhs, const RZ_Match_Literal& rhs)
  {
   return false;
  }


// bool operator>(const RZ_Lisp_Symbol& rhs) const
// {
//  return false;
// }
// bool operator<(const RZ_Lisp_Symbol& rhs) const
// {
//  return false;
// }
// bool operator>(const RZ_Type_Not_Set& rhs) const
// {
//  return false;
// }
// bool operator<(const RZ_Type_Not_Set& rhs) const
// {
//  return false;
// }
// bool operator>(const RZ_User_Function& rhs) const
// {
//  return false;
// }
// bool operator<(const RZ_User_Function& rhs) const
// {
//  return false;
// }
// bool operator>(const RZ_Run_Type_Value& rhs) const
// {
//  return false;
// }
// bool operator<(const RZ_Run_Type_Value& rhs) const
// {
//  return false;
// }
// bool operator>(const RZ_Boolean& rhs) const
// {
//  return false;
// }
// bool operator<(const RZ_Boolean& rhs) const
// {
//  return false;
// }


};


_RZNS(GVal)

#endif
