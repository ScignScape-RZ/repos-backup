#ifndef RZ_LISP_MAP__H
#define RZ_LISP_MAP__H

#include "rz-typedefs.h"
#include "flags.h"
#include "accessors.h"

#include <QDebug>

#include "rzns.h"

RZNS_(GBuild)

class RZ_Lisp_Token;

_RZNS(GBuild)


RZNS_(GVal)

class RZ_String;


class RZ_Lisp_Map
{
public:
 RZ_Lisp_Map();


 template<typename T>
 friend T& operator<<(T& t, const RZ_Lisp_Map& rhs)
 {
//?  return t << rhs.to_string();
 }


 friend void operator<<(QDebug lhs, const RZ_Lisp_Map& rhs)
 {
//?  tString s = rhs.to_string();
//?  lhs << s;
 }

// operator RZ_String()
// {
//  return ctq_string;
// }

// template<typename T>
// friend T& operator<<(T& t, const RZ_Lisp_Map& rhs)
// {
//  t << rhs.
// }


// #include "types/type-operators.h"

// friend bool operator==(const RZ_String& lhs, const RZ_String& rhs)
// {
//  return lhs.to_string() == rhs.to_string();
// }

// operator bool()
// {
//  tString s = to_string();
//  return s.isEmpty() || s.isNull();
// }

// bool operator>(const RZ_String& rhs) const;
// bool operator<(const RZ_String& rhs) const;

//  template<typename T>
//  friend T& operator<<(T& t, const RZ_String& s)
//  {
//   return t << s.to_string();
//  }

//  friend RZ_Lisp_Graph_Result_Holder& operator<<(RZ_Lisp_Graph_Result_Holder& rh, const RZ_String& s)
//  {
//   rh << s;
//   return rh;
//  }


//  RZ_String operator+(const RZ_String& rhs )
//  {
//   return RZ_String( to_string() + rhs.to_string() );
//  }

//  template<typename T>
//  bool operator>(const T& rhs) const
//  {
//   return false;
//  }

//  template<typename T>
//  bool operator<(const T& rhs) const
//  {
//   return false;
//  }

//  template<typename T>
//  friend bool operator>(const T& lhs, const RZ_String& rhs)
//  {
//   return false;
//  }

//  template<typename T>
//  friend bool operator<(const T& lhs, const RZ_String& rhs)
//  {
//   return false;
//  }


// bool operator>(const RZ_Symbol& rhs) const
// {
//  return false;
// }
// bool operator<(const RZ_Symbol& rhs) const
// {
//  return false;
// }
// bool operator>(const RZ_Type_Not_Set& rhs) const
// {
//  return false;
// }
// bool operator<(const RZ_Type_Not_Set& rhs) const
// {
//  return false;
// }
// bool operator>(const RZ_User_Function& rhs) const
// {
//  return false;
// }
// bool operator<(const RZ_User_Function& rhs) const
// {
//  return false;
// }
// bool operator>(const RZ_Run_Type_Value& rhs) const
// {
//  return false;
// }
// bool operator<(const RZ_Run_Type_Value& rhs) const
// {
//  return false;
// }
// bool operator>(const RZ_Boolean& rhs) const
// {
//  return false;
// }
// bool operator<(const RZ_Boolean& rhs) const
// {
//  return false;
// }

};

_RZNS(GVal)

#endif
