
#include "rz-lisp-graph-visitor.h"

#include "rz-lisp-graph-visitor-clasp.h"

#include "rz-graph-run/token/rz-graph-run-token.h"
#include "rz-graph-token/token/rz-lisp-token.h"
#include "rz-graph-core/kernel/graph/rz-re-node.h"
#include "rz-code-generators/rz-function-def-info.h"
#include "rz-graph-token/rz-lisp-graph-core-function.h"
#include "rz-graph-core/token/rz-re-token.h"
#include "rz-graph-embed/rz-graph-embed-token.h"
#include "rz-graph-embed/rz-graph-cpp/rz-graph-cpp-token.h"
#include "rz-graph-embed/rz-graph-haskell/rz-graph-haskell-token.h"
#include "rz-graph-embed/rz-graph-cheerp/rz-graph-cheerp-token.h"
#include "rz-graph-embed/rz-graph-clasp/rz-graph-clasp-token.h"
#include "rz-block-entry-run-plugin.h"
#include "rz-graph-core/code/rz-re-function-def-entry.h"
#include "rz-graph-valuer/scope/rz-lisp-graph-lexical-scope.h"
#include "rz-graph-valuer/valuer/rz-lisp-graph-valuer.h"
#include "rz-graph-run/rz-lisp-graph-runner.h"
#include "rz-graph-build/rz-lisp-graph-result-holder.h"
#include "rz-graph-build/types/run-type-codes.h"
#include "rz-graph-embed/rz-graph-run-embedder.h"
#include "rz-graph-embed-run/rz-graph-embed-run-valuer.h"
#include "rz-graph-embed/rz-graph-embed-check.h"
#include "rz-graph-core/code/rz-re-call-entry.h"
#include "rz-graph-core/code/rz-re-block-entry.h"
#include "rz-embed-branch-run-plugin.h"
#include "rz-graph-core/tuple/rz-re-tuple-info.h"
#include "rz-graph-sre/rz-sre-token.h"

#include "rz-graph-valuer/scope/rz-lisp-graph-block-info.h"

#include <QRegularExpression>
#include <QRegularExpressionMatch>

#include "rzns.h"

USING_RZNS(GBuild)

USING_RZNS(GEmbed)

RZ_Lisp_Graph_Visitor_Clasp::RZ_Lisp_Graph_Visitor_Clasp(RZ_Lisp_Graph_Visitor& visitor)
 : visitor_(visitor)
  ,current_node_(nullptr)
  ,rewind_node_(nullptr)
  ,next_node_(nullptr)
  ,current_call_entry_object_(nullptr)
  ,current_call_entry_node_(nullptr)
  ,last_graph_clasp_token_(nullptr)
  ,current_run_plugin_(nullptr)
  ,current_block_node_(nullptr)
  ,current_pending_parent_block_node_(nullptr)
  ,tail_rewind_count_(0)
//run_state_;
{

}


bool RZ_Lisp_Graph_Visitor_Clasp::check_confirm_pending_parent_block_node()
{
 if(current_pending_parent_block_node_)
 {
  CAON_PTR_DEBUG(RE_Node ,current_pending_parent_block_node_)
  confirm_pending_parent_block_node();
  current_pending_parent_block_node_ = nullptr;
  return true;
 }
 return false;
}

void RZ_Lisp_Graph_Visitor_Clasp::cancel_pending_parent_block_node()
{
 current_pending_parent_block_node_ = nullptr;
}

void RZ_Lisp_Graph_Visitor_Clasp::confirm_pending_parent_block_node()
{
 current_block_node_ = current_pending_parent_block_node_;
}

void RZ_Lisp_Graph_Visitor_Clasp::reset()
{
 current_node_ = visitor_.graph_root_node();
 if(current_node_)
  run_state_.set_read_table_state(RZ_Read_Table_State::Root);
 else
  run_state_.set_read_table_state(RZ_Read_Table_State::Pre_Root);
}


caon_ptr<RZ_Clasp_Source_Element>
  RZ_Lisp_Graph_Visitor_Clasp::get_current_sre_token(RZ_SRE_Token& sre_token)
{
 //{
  caon_ptr<RZ_Clasp_Source_Element> result = nullptr;
  if(caon_ptr<RZ_Graph_Run_Token> rzt = sre_token.run_token())
  {
   result = get_current_token(*rzt);
   sre_token.set_node(current_node_);
  }
  return result;
 //}


// switch(run_state_.block_entry_branch_state())
// {
// case RZ_Block_Entry_Branch_State::Parameter_List_Pre_Entry:
//   if(lexical_scope_iterator_.hasNext())
//    rzt.set_symbol_string_value("let");
//   else
//    //rzt.set_symbol_string_value("let");
//    rzt.set_symbol_string_value("progn");
//   break;

// case RZ_Block_Entry_Branch_State::Parameter_Key:
//   lexical_scope_iterator_.next();
//   rzt.set_symbol_string_value(lexical_scope_iterator_.key());
//   break;

// case RZ_Block_Entry_Branch_State::Parameter_Value:
//   rzt.init_from_scope_token(lexical_scope_iterator_.value());
//   break;

// }
}


caon_ptr<RZ_Clasp_Source_Element>
 RZ_Lisp_Graph_Visitor_Clasp::get_current_token(RZ_Graph_Run_Token& rzt)
{
 //if(block_entry_branch_state_ != RZ_List_Pre_Entry_State::Normal)

 if(run_state_.flags.has_run_plugin)
 {
  current_run_plugin_->get_current_token(rzt);
  return //?
    nullptr;

 }

 switch(run_state_.read_table_state())
 {
 case RZ_Read_Table_State::Root:
//?  rzt.flags.is_list_entry = true;
//? read_table_state_ = Tokens;
  break;
 case RZ_Read_Table_State::Graph_End:
  rzt.flags.nothing = true;
 default:
  {
   return current_token_string(rzt);
  }
  break;
 }
 return nullptr;
}


bool RZ_Lisp_Graph_Visitor_Clasp::current_call_entry_is_function_expression()
{
 if(current_call_entry_object_)
 {
  CAON_PTR_DEBUG(RE_Call_Entry ,current_call_entry_object_)
  return
    current_call_entry_object_->flags.is_function_expression_entry
   ||
    current_call_entry_object_->flags.is_tuple_info_entry;
 }
 return false;
}

bool RZ_Lisp_Graph_Visitor_Clasp::current_call_entry_is_statement()
{
 if(current_call_entry_object_)
 {
  CAON_PTR_DEBUG(RE_Call_Entry ,current_call_entry_object_)
  return current_call_entry_object_->flags.is_statement_entry;
 }
 return false;
}

void RZ_Lisp_Graph_Visitor_Clasp::check_type_indicator(caon_ptr<tNode>& node)
{
 node = visitor_.check_type_indicator(current_node_);
}

caon_ptr<RZ_Graph_Embed_Token> RZ_Lisp_Graph_Visitor_Clasp::current_embed_rename_token()
{
 return visitor_.current_embed_rename_token(current_node_);
}

caon_ptr<RZ_Graph_Clasp_Token> RZ_Lisp_Graph_Visitor_Clasp::current_embed_clasp_token(caon_ptr<RZ_Clasp_Source_Element>& cse)
{
 if(current_node_)
 {
  CAON_PTR_DEBUG(tNode ,current_node_)
  //if()

  current_node_->debug_connections();

  if(caon_ptr<RZ_Graph_Clasp_Token> ct = current_node_->clasp_token())
  {
   CAON_PTR_DEBUG(RZ_Graph_Clasp_Token ,ct)
   CAON_DEBUG_NOOP
  }

  if(caon_ptr<RZ_Graph_Clasp_Token> result = visitor_.clasp_redirect_token(current_node_))
  {
   CAON_PTR_DEBUG(RZ_Graph_Clasp_Token, result)
   next_node_ = nullptr;
   cse = result->source_element();
   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
   //?run_state_.set_read_table_state(RZ_Read_Table_State::Clasp_Redirect_Token);
   if(caon_ptr<RZ_Function_Def_Info> function_def_info = result->function_def_info())
   {
    if(caon_ptr<tNode> pn = function_def_info->function_def_entry_prior_node())
    {
     next_node_ = visitor_.nested_block_entry_from_prior_node(pn);
     run_state_.set_read_table_state(RZ_Read_Table_State::Next_Node_Loaded__Block_Pre_Entry);
    }
   }
   return result;
  }
 }
 return nullptr;
}

caon_ptr<RZ_Lisp_Token> RZ_Lisp_Graph_Visitor_Clasp::current_lisp_token()
{
 if(current_node_)
 {
  return current_node_->lisp_token();
 }
 return nullptr;
}

caon_ptr<RZ_Lisp_Graph_Visitor::tNode>
 RZ_Lisp_Graph_Visitor_Clasp::embed_redirect_node()
{
 return visitor_.embed_redirect_node(current_node_);
}

caon_ptr<RZ_Graph_Embed_Token> RZ_Lisp_Graph_Visitor_Clasp::current_embed_token()
{
 //?
// if(tNode* n = embed_redirect_node())
// {
//  return n->embed_token();
// }
 if(run_state_.flags.on_embed_redirect_branch)
 {
  if(current_node_)
   return current_node_->embed_token();
 }
// else if(current_node_)
// {
//  CAON_PTR_DEBUG(tNode ,current_node_)
//  if(caon_ptr<tNode> n = rq_.Run_Embed_Rename(current_node_))
//  {
//   return n->embed_token();
//  }
// }
 return nullptr;
}

void RZ_Lisp_Graph_Visitor_Clasp::pop_embed_branch_node()
{
 current_node_ = embed_branch_nodes_.top();
 // //?
 next_node_ = embed_branch_nodes_.top();
 embed_branch_nodes_.pop();

 CAON_PTR_DEBUG(tNode ,current_node_)
 CAON_PTR_DEBUG(tNode ,next_node_)
}

caon_ptr<RZ_Clasp_Source_Element>
 RZ_Lisp_Graph_Visitor_Clasp::current_token_string(RZ_Graph_Run_Token& rzt)
{
 CAON_PTR_DEBUG(RE_Node ,current_node_)
 caon_ptr<RZ_Clasp_Source_Element> result = nullptr;
 if(caon_ptr<RZ_Graph_Embed_Token> rename_token = current_embed_rename_token())
 {
  rzt.init_from_embed_token(*rename_token);
 }
 else if(caon_ptr<RZ_Graph_Clasp_Token> clasp_token = current_embed_clasp_token(result))
 {
  last_graph_clasp_token_ = clasp_token;
  rzt.init_from_clasp_token(*clasp_token);
 }
 else if(caon_ptr<RZ_Lisp_Token> token = current_lisp_token())
 {
//  rzt.init_from(*token);

//  QString fn = valuer_->rename_function_name(*token);
//  if(fn.isEmpty())
  CAON_PTR_DEBUG(RZ_Lisp_Token ,token)
  rzt.init_from(*token);
//  else
//   rzt.set_string_value(fn);


//  if(token->run_state_.flags.is_keyword)
//   return QString(":%1").arg(token->string_value());
//  else if(token->run_state_.flags.is_string_literal)
//   return QString("\"%1\"").arg(token->string_value());
//  else
//   return token->string_value();
 }
 else if(current_node_) //caon_ptr<RZ_Lisp_Token> token = current_lisp_token())
 {
  CAON_PTR_DEBUG(RE_Node ,current_node_)
  if(caon_ptr<RE_Tuple_Info> rti = current_node_->re_tuple_info())
  {
   rzt.flags.is_inserted_tuple_info = true;
   rzt.set_string_value(rti->lisp_out());
  }
   //rzt.init_from(*token);
 }
 return result;
}


void RZ_Lisp_Graph_Visitor_Clasp::reset_call_entry_object(RZ_Read_Table_State state_on_unwind,
 RZ_Read_Table_Post_Advance_State post_state_on_unwind, RZ_Read_Table_State state_on_no_unwind,
  RZ_Read_Table_Post_Advance_State post_state_on_no_unwind)
{
#ifdef HIDE

 CAON_PTR_DEBUG(RE_Call_Entry ,current_call_entry_object_)

 if(caon_ptr<tNode> parent_node = current_call_entry_object_->get_parent_entry_node_unwind())
 {
  CAON_PTR_DEBUG(tNode ,parent_node)

  caon_ptr<tNode> current_block_chief_node = current_call_entry_object_->block_chief_node();
  current_call_entry_object_ = parent_node->re_call_entry();
  caon_ptr<tNode> parent_block_chief_node = current_call_entry_object_->block_chief_node();

  CAON_PTR_DEBUG(tNode ,current_block_chief_node)
  CAON_PTR_DEBUG(tNode ,parent_block_chief_node)

  CAON_PTR_DEBUG(RE_Call_Entry ,current_call_entry_object_)

  if(caon_ptr<RE_Node> n = rq_.Run_Cross_Continue(parent_node))
  {
   CAON_PTR_DEBUG(tNode ,n)
   next_node_ = n;
  }

  // current_call_entry_object_->debug_check_entry(rq_.Run_Call_Entry);

  //?current_node_ = parent_node;
  //current_node_ = nullptr;

  if(current_block_chief_node != parent_block_chief_node)
  {
   current_block_node_ = nullptr;
   run_state_.set_read_table_state(RZ_Read_Table_State::Block_End);
   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
  }
  else
  {
   current_node_ = nullptr;
   run_state_.set_read_table_state(state_on_unwind);
   run_state_.set_post_advance_state(post_state_on_unwind);
  }
 }
 else //if(caon_ptr<tNode> entry_node = current_call_entry_object_->get_next_entry_node())
 {
  int unwind_count;
  CAON_PTR_DEBUG(RE_Call_Entry ,current_call_entry_object_);
  caon_ptr<RE_Node> next_node = current_call_entry_object_->get_next_entry_node(current_call_entry_object_, unwind_count);

  if(unwind_count)
  {
   bool no_unwind = true;
   CAON_PTR_DEBUG(RE_Node ,next_node);
   if(caon_ptr<RE_Call_Entry> rce = next_node->re_call_entry())
   {
    next_node->debug_connections();
    CAON_PTR_DEBUG(RE_Call_Entry ,rce);
    if(caon_ptr<RE_Node> bc_node= rce->block_chief_node())
    {
     CAON_PTR_DEBUG(RE_Node ,bc_node);
     if(caon_ptr<RE_Node> cs_node = rq_.Run_Cross_Continue(bc_node))
     {
      no_unwind = false;
      current_node_ = bc_node;
      next_node_ = cs_node;
       // //  Do we know this is always a block ending?
      run_state_.set_read_table_state(RZ_Read_Table_State::Cross_Block_Pre_Entry);
      run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
     }
    }
   }
   //current_node_ = next_entry_node;
   if(no_unwind)
   {
    current_node_ = next_node;
    run_state_.set_read_table_state(state_on_no_unwind);
    run_state_.set_post_advance_state(post_state_on_no_unwind);
   }
  }
  else if(next_node && current_call_entry_object_) //?
  {
   if(!current_call_entry_object_)
   {

   }
   else
   {
    current_node_ = next_node;
    CAON_PTR_DEBUG(tNode ,current_node_)
    next_node_ = rq_.Run_Call_Entry(current_node_);
    CAON_PTR_DEBUG(tNode ,next_node_)
    if(run_state_.flags.cpp_mode)
    {
     CAON_PTR_DEBUG(RE_Call_Entry ,current_call_entry_object_)
     if(current_call_entry_object_->flags.is_statement_entry)
      run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Pre_Entry);
     else
      run_state_.set_read_table_state(RZ_Read_Table_State::List_Pre_Entry);
     run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
    }
    else
    {
     run_state_.set_read_table_state(RZ_Read_Table_State::List_Pre_Entry);
     run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
    }
   }
  }

  //??
  else if(current_block_node_)
  {
   current_block_node_ = nullptr;
   run_state_.set_read_table_state(RZ_Read_Table_State::Block_End);
   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
  }
  //??


  else
  {
   run_state_.set_read_table_state(state_on_no_unwind);
   run_state_.set_post_advance_state(post_state_on_no_unwind);
  }
 }
#endif
}

caon_ptr<RE_Block_Entry> RZ_Lisp_Graph_Visitor_Clasp::current_node_as_block_entry()
{
 CAON_PTR_DEBUG(RE_Node ,current_node_)
 if(current_node_)
 {
  return current_node_->re_block_entry();
 }
 return nullptr;
}


QString RZ_Lisp_Graph_Visitor_Clasp::current_call_entry_prefix()
{
 QString result;
 CAON_PTR_DEBUG(RE_Node ,current_node_)

 if(caon_ptr<RE_Call_Entry> rce = current_node_->re_call_entry()) //current_call_entry_object_)
 {
  CAON_PTR_DEBUG(RE_Call_Entry ,current_call_entry_object_)
  CAON_PTR_DEBUG(RE_Call_Entry ,rce)
  result = rce->prefix();
 }
 return result;
}


void RZ_Lisp_Graph_Visitor_Clasp::deactivate_run_state_plugin()
{
 current_run_plugin_->deactivate();
 run_state_.flags.has_run_plugin = false;
 switch(run_state_.read_table_state())
 {
 case RZ_Read_Table_State::Expression_Embed_Sequence:
  run_state_.set_read_table_state(RZ_Read_Table_State::Expression_Final);
  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
  break;

 case RZ_Read_Table_State::Expression_Final:
  {
   CAON_PTR_DEBUG(tNode ,current_node_)
   CAON_PTR_DEBUG(tNode ,next_node_)
   CAON_DEBUG_NOOP
//   run_state_.set_read_table_state(RZ_Read_Table_State::List_Entry);
//   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
  }
  break;
 default:
  break;

 }
}

caon_ptr<RZ_Lisp_Graph_Block_Info> RZ_Lisp_Graph_Visitor_Clasp::current_block_info()
{
 return visitor_.current_block_info(current_node_);
}

bool RZ_Lisp_Graph_Visitor_Clasp::quasi_statements()
{
 if(run_state_.flags.override_quasi_statements)
 {
  run_state_.flags.override_quasi_statements = false;
  return false;
 }
 if(current_block_node_)
 {
  if(caon_ptr<RE_Block_Entry> rbe = current_block_node_->re_block_entry())
  {
   return rbe->quasi_statements();
  }
 }
 return false;
}


void RZ_Lisp_Graph_Visitor_Clasp::push_call_entry_node(caon_ptr<RE_Node> node)
{
 CAON_PTR_DEBUG(RE_Node ,node)
 call_entry_nodes_.push(node);
}


void RZ_Lisp_Graph_Visitor_Clasp::find_next_token(RZ_SRE_Result_State& result_state,
 Find_Next_Token_Flags flag)
{
 if(caon_ptr<RE_Node> node = visitor_.find_next_token(current_node_, result_state,
  flag == Find_Next_Token_Flags::Expression_Flag))
 {
  //?current_call_entry_object_ = current_node_->re_call_entry();
  //?CAON_PTR_DEBUG(RE_Call_Entry ,current_call_entry_object_)
  CAON_PTR_DEBUG(RE_Node ,node)
  current_node_ = node;
  next_node_ = nullptr;
  switch(result_state.advance_graph_state)
  {
  case RZ_Read_Table_Advance_Graph_State::Call_Sequence:
   //?run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
   run_state_.set_read_table_state(result_state.read_table_state);
   break;
  case RZ_Read_Table_Advance_Graph_State::Call_Entry:
   //?run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
   //?push_call_entry_node(node);
   if(flag == Find_Next_Token_Flags::Block_Continue)
   {
    run_state_.set_read_table_state(RZ_Read_Table_State::Block_Continue_Call_Pre_Entry);
   }
   else
   {
    run_state_.set_read_table_state(result_state.read_table_state);
   }
   break;
  case RZ_Read_Table_Advance_Graph_State::Cross_Continue:
   //?run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
   run_state_.set_read_table_state(result_state.read_table_state);
   break;

  case RZ_Read_Table_Advance_Graph_State::Block_Entry:
   //?run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
   //?push_call_entry_node(node);
   //run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
   next_node_ = visitor_.find_run_call_entry(current_node_);
   run_state_.set_read_table_state(result_state.read_table_state);
   break;

  }
 }
 else
 {
  if(current_call_entry_is_statement())
   run_state_.set_read_table_state(RZ_Read_Table_State::Statement_End);
  else
   run_state_.set_read_table_state(RZ_Read_Table_State::Expression_End);
 }
}


void RZ_Lisp_Graph_Visitor_Clasp::rewind_call_entry_object()
{
 if(call_entry_nodes_.size() > 0)
 {
  caon_ptr<RE_Node> ce_node = call_entry_nodes_.top();
  if(caon_ptr<RE_Call_Entry> rce = ce_node->re_call_entry())
  {
   CAON_PTR_DEBUG(RE_Call_Entry ,rce)
   current_call_entry_object_ = rce;
  }
  else
  {
   //?
   current_call_entry_object_ = nullptr;
  }
 }
}


QString RZ_Lisp_Graph_Visitor_Clasp::call_entry_label()
{
 QString result;
 if(current_call_entry_object_)
 {
  CAON_PTR_DEBUG(RE_Call_Entry ,current_call_entry_object_)
  if(current_call_entry_object_->flags.has_label)
  {
   result = visitor_.call_entry_label(current_call_entry_node_);
  }
 }
 return result;
}


caon_ptr<RE_Node> RZ_Lisp_Graph_Visitor_Clasp::find_next_token_rewind(RZ_SRE_Result_State& result_state, bool expression_flag,
  int& count, caon_ptr<RE_Node>& rewind_entry_node)
{
 caon_ptr<RE_Node> result = nullptr;
 CAON_PTR_DEBUG(RE_Node ,current_node_)
 if(call_entry_nodes_.size() > 0)
 {
  caon_ptr<RE_Node> ce_node = call_entry_nodes_.pop();
  CAON_PTR_DEBUG(RE_Node ,ce_node)
  ++count;
  rewind_entry_node = ce_node;
  if(caon_ptr<RE_Node> next_node = visitor_.find_next_token(ce_node, result_state, expression_flag, true))
  {
   rewind_call_entry_object();
   CAON_PTR_DEBUG(RE_Node ,next_node)
   switch(result_state.advance_graph_state)
   {
   case RZ_Read_Table_Advance_Graph_State::Cross_Continue:
    next_node_ = next_node;
    result = next_node;
    break;

   case RZ_Read_Table_Advance_Graph_State::Cross_Entry:
    {
     if(caon_ptr<RE_Call_Entry> rce = next_node->re_call_entry())
     {
      CAON_PTR_DEBUG(RE_Call_Entry ,rce)
      //?push_call_entry_node(next_node);
      //
      result = next_node;
      if(run_state_.read_table_state() == RZ_Read_Table_State::Nested_Block_Leave_No_Continue)
      {
       // //  Here the statement did not have a chance to finalize...
       next_node_ = next_node;
       // //  Reset the result state...
       result_state.read_table_state = RZ_Read_Table_State::Nested_Block_Leave_Statement_Final;
      }
      else
      {
       current_node_ = next_node;
       next_node_ = nullptr;
       CAON_DEBUG_NOOP
      }
     }
    }
    break;

    case RZ_Read_Table_Advance_Graph_State::Block_Entry:
     {
      if(caon_ptr<RE_Block_Entry> rbe = next_node->re_block_entry())
      {
       CAON_PTR_DEBUG(RE_Block_Entry ,rbe)
       //?push_call_entry_node(next_node);
       //
       result = next_node;
       current_node_ = next_node;
       current_block_node_ = next_node;
       CAON_PTR_DEBUG(RE_Node ,current_node_)
       next_node_ = visitor_.find_run_call_entry(current_node_);
       //?
       // // is it ok to do this here?
       run_state_.set_read_table_state(result_state.read_table_state);
       run_state_.set_advance_token_state(result_state.advance_token_state);

       CAON_DEBUG_NOOP
      }
     }
     break;

   default:
     //?
    break;
   }
  }
 }
 return result;
}


//?
//void RZ_Lisp_Graph_Visitor_Clasp::find_next_node_from_entry(tNode& node)
//{
// node.debug_connections();

// caon_ptr<RE_Node> next_node;
// if(next_node = rq_.Run_Call_Entry(&node))
// {
//  CAON_PTR_DEBUG(tNode ,next_node)
//  next_node_ = next_node;
//  run_state_.flags.current_noop = check_embed_noop(next_node);
// }
// else if(caon_ptr<tNode> next_node = rq_.Run_Data_Entry(&node))
// {
//  next_node_ = next_node;
// }
//}

caon_ptr<RE_Node> RZ_Lisp_Graph_Visitor_Clasp::find_block_entry_as_sequence()
{
 CAON_PTR_DEBUG(RE_Node ,current_node_)
 CAON_PTR_DEBUG(RE_Call_Entry ,current_call_entry_object_)
 if(current_call_entry_object_)
 {
  return current_call_entry_object_->block_continue_node();
 }
 return nullptr;
}

void RZ_Lisp_Graph_Visitor_Clasp::advance()
{
 CAON_PTR_DEBUG(RE_Node ,current_node_)
 CAON_PTR_DEBUG(RE_Node ,current_block_node_)

 bool expression_flag = false;

 if(run_state_.flags.has_run_plugin)
 {
  bool still_plugin = current_run_plugin_->advance();
  if(!still_plugin)
   deactivate_run_state_plugin();
  return;
 }
 switch(run_state_.read_table_state())
 {
 case RZ_Read_Table_State::Root:
  find_run_entry(RZ_Read_Table_State::Graph_End, RZ_Read_Table_Post_Advance_State::Deactivate);
  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Reenter);
  break;

 case RZ_Read_Table_State::File_Block_Pre_Entry:
  //current_node_ = next_node_;
  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
  run_state_.set_read_table_state(RZ_Read_Table_State::Block_Pre_Entry);
  break;

 case RZ_Read_Table_State::Do_Map_Block_Continue:
  {
   CAON_PTR_DEBUG(RE_Node ,current_node_)
   CAON_PTR_DEBUG(RE_Node ,next_node_)

   // //  Next node is run call entry to start the block
   current_node_ = next_node_;
   next_node_ = nullptr;
   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
   run_state_.set_read_table_state(RZ_Read_Table_State::Block_Entry);
   run_state_.set_advance_token_state(RZ_Read_Table_Advance_Token_State::Node_Loaded);
  }
  break;


 case RZ_Read_Table_State::Block_Pre_Entry:
  {
   CAON_PTR_DEBUG(RE_Node ,current_node_)
   CAON_PTR_DEBUG(RE_Node ,next_node_)

   // //  Next node is run call entry to start the block
   current_node_ = next_node_;
   next_node_ = nullptr;
   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
   run_state_.set_read_table_state(RZ_Read_Table_State::Block_Entry);
   run_state_.set_advance_token_state(RZ_Read_Table_Advance_Token_State::Node_Loaded);
  }
  break;

// case RZ_Read_Table_State::Cross_Pre_Entry:
//  {
//   CAON_PTR_DEBUG(RE_Node ,current_node_)
//   CAON_PTR_DEBUG(RE_Node ,next_node_)

//   // //  Next node is run call entry to start the block
//   current_node_ = next_node_;
//   next_node_ = nullptr;
//   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//   run_state_.set_read_table_state(RZ_Read_Table_State::Block_Entry);
//   run_state_.set_advance_token_state(RZ_Read_Table_Advance_Token_State::Node_Loaded);
//  }
//  break;

 case RZ_Read_Table_State::Block_Entry:
  {
   current_node_->debug_connections();
   CAON_PTR_DEBUG(RE_Node ,current_node_)
   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
   run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Pre_Entry);
  }
  break;

 case RZ_Read_Table_State::Block_Continue_Call_Pre_Entry:
 case RZ_Read_Table_State::Expression_Pre_Entry:
  expression_flag = true;
   // fallthrough...
 case RZ_Read_Table_State::Statement_Pre_Entry:
  {
   CAON_PTR_DEBUG(RE_Node ,current_node_)
   CAON_PTR_DEBUG(RE_Node ,next_node_)
   if(run_state_.check_node_advance_state())
   {
    // current_node_ holds call entry object
    if(caon_ptr<RE_Node> node = visitor_.entry_from_call_entry(current_node_))
    {
     CAON_PTR_DEBUG(RE_Call_Entry ,current_call_entry_object_)
     CAON_PTR_DEBUG(RE_Node ,node)

     // //  For when current_node_ is a block entry; maybe clean this up?
     if(caon_ptr<RE_Block_Entry> rbe = current_node_->re_block_entry())
     {
      if(caon_ptr<RE_Node> node1 = visitor_.entry_from_call_entry(node))
      {
       CAON_PTR_DEBUG(RE_Node ,node1)
       push_call_entry_node(node);
       current_call_entry_object_ = node->re_call_entry();
       current_call_entry_node_ = node;
       current_node_ = node1;
      }
      else
      {
       //? syntax error...?
      }
     }
     else
     {
      push_call_entry_node(current_node_);
      current_call_entry_object_ = current_node_->re_call_entry();
      current_call_entry_node_ = current_node_;
      current_node_ = node;
     }
     next_node_ = nullptr;
     if(caon_ptr<RZ_Lisp_Graph_Block_Info> rbi = current_block_info())
     {
      CAON_PTR_DEBUG(RZ_Lisp_Graph_Block_Info ,rbi)
      //?block_info_stack_.push(rbi);
     }
     run_state_.set_advance_token_state(RZ_Read_Table_Advance_Token_State::Token_Loaded);
    }
    else if(caon_ptr<RE_Node> dnode = visitor_.data_entry_from_call_entry(current_node_))
    {
     CAON_PTR_DEBUG(RE_Node ,dnode)
     if(caon_ptr<RE_Tuple_Info> rti = dnode->re_tuple_info())
     {
      CAON_PTR_DEBUG(RE_Tuple_Info ,rti)
      CAON_DEBUG_NOOP
      push_call_entry_node(current_node_);
      current_call_entry_object_ = current_node_->re_call_entry();
      current_call_entry_node_ = current_node_;
      current_node_ = dnode;
     }
     next_node_ = nullptr;
     run_state_.set_advance_token_state(RZ_Read_Table_Advance_Token_State::Token_Loaded);
    }
    run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
    if(expression_flag)
     run_state_.set_read_table_state(RZ_Read_Table_State::Expression_Entry);
    else
     run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Entry);
   }
  }
  break;

 case RZ_Read_Table_State::Expression_Entry:
  expression_flag = true;
   // fallthrough...
 case RZ_Read_Table_State::Statement_Entry:
  {
   CAON_PTR_DEBUG(RE_Node ,current_node_)
   CAON_PTR_DEBUG(RE_Node ,next_node_)
   RZ_SRE_Result_State result_state;
   if(run_state_.check_node_advance_state())
    run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
   find_next_token(result_state, expression_flag?Find_Next_Token_Flags::Expression_Flag:Find_Next_Token_Flags::Normal);

  //   if(run_state_.advance_token_state() == RZ_Read_Table_Advance_Token_State::Token_Loaded)
  //   {
  //    run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
  //    run_state_.set_read_table_state(RZ_Read_Table_State::Expression_Sequence);
  //   }
  }
  break;

// {
//  current_call_entry_object_ = current_node_->re_call_entry();
//  CAON_PTR_DEBUG(RE_Call_Entry ,current_call_entry_object_)
//  CAON_PTR_DEBUG(RE_Node ,node)
//  current_node_ = node;
//  next_node_ = nullptr;
//  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
//  run_state_.set_read_table_state(result_state.read_table_state);
// }
// else
// {
//  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
//  if(current_call_entry_is_function_expression())
//   run_state_.set_read_table_state(RZ_Read_Table_State::Expression_Final);
//  else
//   run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Final);
// }

 case RZ_Read_Table_State::Cross_Continue:
  {
   CAON_PTR_DEBUG(RE_Node ,current_node_)
   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
  }
  // fallthrough...
 case RZ_Read_Table_State::Expression_Sequence:
  {
   CAON_PTR_DEBUG(RE_Node ,current_node_)
   CAON_PTR_DEBUG(RE_Node ,next_node_)
   RZ_SRE_Result_State result_state;
   find_next_token(result_state, Find_Next_Token_Flags::Expression_Flag);
  }
  break;

 case RZ_Read_Table_State::Expression_End:
  run_state_.set_read_table_state(RZ_Read_Table_State::Expression_Final);
  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
  break;

 case RZ_Read_Table_State::Expression_Final:
  {
//   CAON_PTR_DEBUG(RE_Node ,current_node_)
//   CAON_PTR_DEBUG(RE_Node ,next_node_)
//   RZ_SRE_Result_State result_state;
//   next_node = visitor_.find_expression_continue(current_node_, result_state, true);
   run_state_.set_read_table_state(RZ_Read_Table_State::Expression_Leave); //_Pre_Rewind);
   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//   if(next_node = visitor_.find_expression_continue(current_node_, result_state, token_state, true))
//   {
//    run_state_.set_read_table_state(RZ_Read_Table_State::Expression_Leave);
//    run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//    break;
//   }
  }
  break;

 case RZ_Read_Table_State::Rewind:
  {
   //  Assume statement rewind always means end of block,
   //   except for do blocks?
   if(current_node_)
   {
    if(caon_ptr<RE_Call_Entry> rce = current_node_->re_call_entry())
    {
     CAON_PTR_DEBUG(RE_Call_Entry ,rce)
     if(rce->flags.is_do_lambda)
     {
      goto case_Expression_Rewind;
     }
     if(rce->flags.was_added_as_implied)
     {
      goto case_Expression_Rewind;
     }
    }
   }
   ++tail_rewind_count_;
   run_state_.set_read_table_state(RZ_Read_Table_State::Block_End);
   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
  }
  break;

 case_Expression_Rewind:
 case RZ_Read_Table_State::Expression_Rewind:
  {
   expression_flag = true;
   CAON_PTR_DEBUG(RE_Node ,current_node_)
   ++tail_rewind_count_;
   if(call_entry_nodes_.size() > 0)
   {
    caon_ptr<RE_Node> top_node = call_entry_nodes_.top();
    CAON_PTR_DEBUG(RE_Node ,top_node)
    if(caon_ptr<RE_Call_Entry> rce = top_node->re_call_entry())
    {
     CAON_PTR_DEBUG(RE_Call_Entry ,rce)
     if(rce->flags.is_statement_entry)
      run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Final);
     else
      run_state_.set_read_table_state(RZ_Read_Table_State::Expression_Final);
     run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
    }
    else
    {
     //? goto general_rewind;
    }
   }
   else
   {
    goto general_rewind;
   }
  }
  break;

 case RZ_Read_Table_State::Do_Map_Block_Leave:
  {
   // //  assuming the block does end the enclosing statement ...
   run_state_.set_read_table_state(RZ_Read_Table_State::Do_Map_Block_Statement_Leave);
   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
   break;
  }

 case RZ_Read_Table_State::Do_Map_Block_Statement_Leave:
  {
   CAON_PTR_DEBUG(RE_Node ,current_node_)
   caon_ptr<RE_Node> n1 = call_entry_nodes_.top();
   CAON_PTR_DEBUG(RE_Node ,n1)

   // //  Is this right?
   run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Leave);
   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
   break;
  }

 case RZ_Read_Table_State::Expression_Leave:
   expression_flag = true;
  // fallthrough
general_rewind:
 case RZ_Read_Table_State::Statement_Leave:
  {
   int rewind_count = 0;
   RZ_SRE_Result_State result_state;
   caon_ptr<RE_Node> rewind_node;
   caon_ptr<RE_Node> prior_cbn = current_block_node_;
   CAON_PTR_DEBUG(RE_Node ,prior_cbn)


   caon_ptr<RE_Node> find_result = find_next_token_rewind(result_state, expression_flag, rewind_count, rewind_node);

   CAON_PTR_DEBUG(RE_Node ,rewind_node)
   CAON_PTR_DEBUG(RE_Node ,current_block_node_)

   if(find_result)
   {
    // //  for post write on the expression, e.g., lisp paste
    rewind_node_ = rewind_node;

    tail_rewind_count_ = 0;
    CAON_PTR_DEBUG(RE_Node ,next_node_)
    CAON_PTR_DEBUG(RE_Node ,current_node_)
    run_state_.set_read_table_state(result_state.read_table_state);
    run_state_.set_post_advance_state(result_state.post_advance_state);
   }
   else
   {
    rewind_node_ = rewind_node;
    current_node_ = rewind_node;
    CAON_PTR_DEBUG(RE_Node ,current_node_)
    if(current_node_)
    {
     if(expression_flag)
      run_state_.set_read_table_state(RZ_Read_Table_State::Expression_Rewind);
     else
      run_state_.set_read_table_state(RZ_Read_Table_State::Rewind);
    }
    else
     run_state_.set_read_table_state(RZ_Read_Table_State::Block_End);
    run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
   }
  }
  break;

 case RZ_Read_Table_State::Statement_End:
  run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Final);
  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
  break;

 case RZ_Read_Table_State::Statement_Final:
  current_node_ = nullptr;
  run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Leave);
  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
  break;

// case RZ_Read_Table_State::Statement_Leave:
//  run_state_.set_read_table_state(RZ_Read_Table_State::Block_End);
//  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//  break;

 case RZ_Read_Table_State::Nested_Block_Leave_Statement_Final:
  current_node_ = next_node_;
  run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Pre_Entry);
  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
  break;

 case RZ_Read_Table_State::Block_End:
  run_state_.set_read_table_state(RZ_Read_Table_State::Block_Final);
  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
  break;
 case RZ_Read_Table_State::Block_Final:
  run_state_.set_read_table_state(RZ_Read_Table_State::Block_Leave);
  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
  break;
 case RZ_Read_Table_State::Block_Leave:
  {
   CAON_PTR_DEBUG(RE_Node ,current_node_)
   CAON_PTR_DEBUG(RE_Node ,next_node_)

   CAON_PTR_DEBUG(RE_Node ,current_block_node_)

   //? here? ...
   //?
   //
   //?  visitor_clasp().
    //?check_confirm_pending_parent_block_node();


//   caon_ptr<RZ_Lisp_Graph_Block_Info> rbi = block_info_stack_.isEmpty()?
//     nullptr : block_info_stack_.pop();

//?
//   if(caon_ptr<RE_Node> n = visitor_.block_continue_node(current_node_))
//   {
//    CAON_PTR_DEBUG(RE_Node ,n)
//    CAON_DEBUG_NOOP
//   }
   caon_ptr<RE_Node> nn;
   QString explanation;
   if(caon_ptr<RE_Node> n = visitor_.find_do_map_block_continue_node(current_node_, nn, explanation))
   {
    CAON_PTR_DEBUG(RE_Node ,n)
    CAON_PTR_DEBUG(RE_Node ,nn)
    current_node_ = n;
    next_node_ = nn;
    run_state_.set_read_table_state(RZ_Read_Table_State::Do_Map_Block_Continue);
    run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
    break;
   }
   else if(nn)
   {
    if(caon_ptr<RE_Block_Entry> rbe = nn->re_block_entry())
    {
     CAON_PTR_DEBUG(RE_Block_Entry ,rbe)
     CAON_DEBUG_NOOP
    }

    // //  i.e., in this case nn refers to the parent do-map
// //?   this is all obsolete?
//    CAON_PTR_DEBUG(RE_Node ,nn)
//    if(caon_ptr<RE_Block_Entry> rbe = nn->re_block_entry())
//    {
//     CAON_PTR_DEBUG(RE_Block_Entry ,rbe)
//     if(caon_ptr<RE_Node> sen = rbe->statement_entry_node())
//     {
//      // //  rewinds to the "do" entry
//      CAON_PTR_DEBUG(RE_Node ,sen)
//      if(caon_ptr<RE_Call_Entry> rce = sen->re_call_entry())
//      {
//       CAON_PTR_DEBUG(RE_Call_Entry ,rce)
//       CAON_DEBUG_NOOP
//       current_node_ = sen;
//       next_node_ = nullptr;
//        // sen should == call_entry_nodes_ top
//       call_entry_nodes_.pop();
//       run_state_.set_read_table_state(RZ_Read_Table_State::Do_Map_Block_Leave);
//       run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//       break;
//      }
//     }
//    }
   }

   // //  using string explanation is surely not the best way to
    //    signal a rewind; but for now ...
   if(explanation == "Parent_Block_Map")
   {
    //   do we do the rewind now or after going through the
    //   Nested_Block_Rewind_Pre_Continue ...?
    //? ?!?
     //   maybe depends on whether there's a continue ...?
    check_confirm_pending_parent_block_node();
    CAON_DEBUG_NOOP
   }
   else if(explanation == "Parent_Block_Map__With_Cross")
   {

   }
   else
   {
    cancel_pending_parent_block_node();
   }

   if(caon_ptr<RE_Block_Entry> rbe = current_block_node_->re_block_entry())
   {
    CAON_PTR_DEBUG(RE_Block_Entry ,rbe)
    caon_ptr<RE_Node> sen = rbe->statement_entry_node();
    CAON_PTR_DEBUG(RE_Node ,sen)
    if(sen)
    {
     current_node_ = sen;
    }
    caon_ptr<RE_Node> ben = nullptr;
    if(caon_ptr<RE_Node> bcn = visitor_.find_block_continue_node(sen, ben))
    {
     tail_rewind_count_ = 0;
     CAON_PTR_DEBUG(RE_Node ,bcn)
     CAON_PTR_DEBUG(RE_Node ,ben)
     next_node_ = bcn;
     bcn->debug_connections();
     current_block_node_ = ben;

     // //  if coming from a nested block with no continue, first need to leave that
      //    block before continuing ...
      //    should that go through the state loop or just directly here? ...
     if(explanation == "Parent_Block_Map")
     {
       // // //?check_confirm_pending_parent_block_node();

      run_state_.set_read_table_state(RZ_Read_Table_State::Nested_Block_Rewind_Pre_Continue);
      run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
      //????/current_embed_branch_->ccg_unwind_expression_leave();
     }
     else
     {
      // obsolete; this is covered earlier ...
       // // //  does this cover all cases?  pending_parent_block_node_ should only be
       // //    used with the "Parent_Block_Map" explanation ...
       // //?cancel_pending_parent_block_node();
      run_state_.set_read_table_state(RZ_Read_Table_State::Block_Pre_Continue);
      run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
     }
     break;
    }
    else
    {
     if(call_entry_nodes_.size() == 0)
      run_state_.set_read_table_state(RZ_Read_Table_State::Block_Leave_No_Continue);
     else
     {
      //? here? ...
      if(false) // check_confirm_pending_parent_block_node() )
      {
       // keep current state ...
      }
      else
      {
       run_state_.set_read_table_state(RZ_Read_Table_State::Nested_Block_Leave_No_Continue);
       run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
      }
     }
     break;
    }
   }
   run_state_.set_read_table_state(RZ_Read_Table_State::Block_Leave_No_Continue);
   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
  }
  break;

 case RZ_Read_Table_State::Nested_Block_Leave_No_Continue:
  {
   CAON_PTR_DEBUG(RE_Node ,current_node_)
   if(call_entry_nodes_.size() > 0)
   {
    caon_ptr<RE_Node> top_node = call_entry_nodes_.top();
    CAON_PTR_DEBUG(RE_Node ,top_node)
    CAON_DEBUG_NOOP
   }
   goto general_rewind;
   //?run_state_.set_read_table_state(RZ_Read_Table_State::Graph_End);
   //?run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
  }
 break;

 case RZ_Read_Table_State::Block_Leave_No_Continue:
  {
   run_state_.set_read_table_state(RZ_Read_Table_State::Graph_End);
   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
  }
 break;

//

 case RZ_Read_Table_State::Nested_Block_Rewind_Pre_Continue:
  {
   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
   run_state_.set_read_table_state(RZ_Read_Table_State::Block_Pre_Continue);
  }
  break;

 case RZ_Read_Table_State::Block_Pre_Continue:
  {
   current_node_ = next_node_;
   CAON_PTR_DEBUG(RE_Node ,current_node_)
   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
   run_state_.set_read_table_state(RZ_Read_Table_State::Block_Continue);
  }
  break;

 case RZ_Read_Table_State::Block_Continue:
  {
   CAON_PTR_DEBUG(RE_Node ,current_node_)
   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
   caon_ptr<RZ_Lisp_Graph_Block_Info> rbi;
   caon_ptr<RE_Block_Entry> rbe = nullptr;
   if(caon_ptr<RE_Node> ben = visitor_.find_block_entry_node(current_node_, rbi))
   {
    rbe = ben->re_block_entry();
    CAON_PTR_DEBUG(RE_Block_Entry ,rbe)
    CAON_DEBUG_NOOP
   }
   RZ_SRE_Result_State result_state;
   find_next_token(result_state, Find_Next_Token_Flags::Block_Continue);
   if(current_node_)
   {
    CAON_PTR_DEBUG(RE_Node ,current_node_)
    CAON_PTR_DEBUG(RE_Node ,next_node_)
    CAON_DEBUG_NOOP
   }
   //?current_node_->debug_connections();
   //?run_state_.set_read_table_state(RZ_Read_Table_State::Graph_End);
  }
  break;

 case RZ_Read_Table_State::Cross_Pre_Continue:
  {
   current_node_ = next_node_;
   CAON_PTR_DEBUG(RE_Node ,current_node_)
   run_state_.set_read_table_state(RZ_Read_Table_State::Cross_Continue);
   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
  }
  break;

 case RZ_Read_Table_State::Next_Node_Loaded__Block_Pre_Entry:
  {
   CAON_PTR_DEBUG(RE_Node ,current_node_)
   CAON_PTR_DEBUG(RE_Node ,next_node_)
   current_node_ = next_node_;
   run_state_.set_read_table_state(RZ_Read_Table_State::Block_Pre_Entry);
   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
  }
  break;

 default:
  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
  run_state_.set_read_table_state(RZ_Read_Table_State::Graph_End);

 }
 {
  CAON_PTR_DEBUG(RE_Node ,current_node_)
  CAON_PTR_DEBUG(RE_Node ,next_node_)
  CAON_PTR_DEBUG(RE_Node ,current_block_node_)

  // //   Currently noop can only be used for statements...
   //
  if(current_node_)
  {
   if(run_state_.read_table_state() == RZ_Read_Table_State::Statement_Pre_Entry)
   {
    run_state_.flags.current_noop = visitor_.valuer()->check_embed_noop(current_node_);
   }
   else if(run_state_.read_table_state() == RZ_Read_Table_State::Block_Entry)
   {
    if(caon_ptr<RE_Node> en = visitor_.entry_from_call_entry(current_node_))
    {
     CAON_PTR_DEBUG(RE_Node ,en)
     run_state_.flags.current_noop = visitor_.valuer()->check_embed_noop(en);
    }
   }
  }
  if(run_state_.flags.current_noop)
  {
   // //  This is only to set a breakpoint when a noop starts
   CAON_DEBUG_NOOP
  }

  CAON_DEBUG_NOOP
 }

}
#ifdef HIDE

 case RZ_Read_Table_State::Cpp_File_Entry:
  current_node_ = next_node_;
  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
  run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Pre_Entry);
  break;

 case RZ_Read_Table_State::Statement_Pre_Entry:
  {
   caon_ptr<RE_Call_Entry> rce;
   // //  Should this be a different run state?
   if(run_state_.flags.current_noop)
   {
    rce = current_node_->re_call_entry();
    if(rce)
    {
     CAON_PTR_DEBUG(RE_Call_Entry ,rce)
     rce = current_node_->re_call_entry();
     current_call_entry_object_ = rce;
    }
    run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
    run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Entry_Indent);
     //?current_node_ = next_node_;
   }
   else
   if(caon_ptr<RE_Node> n = find_call_entry(*current_node_, rce))
   {
    current_call_entry_object_ = rce;
    run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
    run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Entry_Indent);
    current_node_ = n;
    //current_node_ = n;
    break;
   }
  }
  break;

 case RZ_Read_Table_State::Block_Statement_Entry:
  find_next_token(RZ_Read_Table_State::Statement_Final, RZ_Read_Table_Post_Advance_State::Holds_Token);

  //? Kludge!
  if(run_state_.read_table_state() == RZ_Read_Table_State::List_Pre_Entry)
  {
   run_state_.set_read_table_state(RZ_Read_Table_State::Block_Statement_List_Pre_Entry);
  }

  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
  //run_state_.set_read_table_state(RZ_Read_Table_State::List_Sequence);
  break;

 case RZ_Read_Table_State::Statement_Entry:
  find_next_token(RZ_Read_Table_State::Statement_Final, RZ_Read_Table_Post_Advance_State::Holds_Token);
  //run_state_.set_read_table_state(RZ_Read_Table_State::List_Sequence);
  break;

 case RZ_Read_Table_State::Block_End:
 {
  caon_ptr<tNode> bc_node = find_block_continue();
//  if(caon_ptr<RE_Block_Entry> rbe = bc_node->re_block_entry())
//  {
//   CAON_PTR_DEBUG(RE_Block_Entry ,rbe)
//   CAON_DEBUG_NOOP
//  }
  if(bc_node)
  {
   current_node_ = bc_node;
   run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Pre_Entry);
   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
  }
  else
  {
   run_state_.set_read_table_state(RZ_Read_Table_State::Block_Rewind);
   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
  }
  break;
 }
 case RZ_Read_Table_State::Block_Rewind:
 {
  run_state_.set_read_table_state(RZ_Read_Table_State::Graph_End);
  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Deactivate);
  break;
 }
//   find_next_token(RZ_Read_Table_State::Graph_End, RZ_Read_Table_Post_Advance_State::Deactivate);
   //   Find block continuation
//  run_state_.set_read_table_state(RZ_Read_Table_State::Graph_End);
//  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Deactivate);
//  break;
 case RZ_Read_Table_State::Block_Rewind_Reset:
 {
  current_node_ = next_node_;
  run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Pre_Entry);
  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
  break;
 }

 case RZ_Read_Table_State::Lexical_Expression_Pre_Entry:
  {
   CAON_PTR_DEBUG(tNode ,current_node_)
   if(caon_ptr<tNode> en = rq_.Run_Call_Entry(current_node_))
   {
    CAON_PTR_DEBUG(tNode ,en)
    if(caon_ptr<RE_Call_Entry> rce = current_node_->re_call_entry())
    {
     CAON_PTR_DEBUG(RE_Call_Entry ,rce)
     current_call_entry_object_ = rce;
     next_node_ = en;
     run_state_.set_read_table_state(RZ_Read_Table_State::List_Pre_Entry);
     lex_iterators_[rce] = current_lex_iterator_;
    }
   }

   else if(caon_ptr<tNode> dn = rq_.Run_Data_Entry(current_node_))
   {
    CAON_PTR_DEBUG(tNode ,dn)
    if(caon_ptr<RE_Call_Entry> rce = current_node_->re_call_entry())
    {
     CAON_PTR_DEBUG(RE_Call_Entry ,rce)
     current_call_entry_object_ = rce;
     if(caon_ptr<tNode> dsn = rq_.Run_Data_Entry(dn))
     {
      CAON_PTR_DEBUG(tNode ,dsn)
      next_node_ = dn;

      run_state_.set_read_table_state(RZ_Read_Table_State::Lex_Tuple_Pre_Entry);
      lex_iterators_[rce] = current_lex_iterator_;
     }
    }
   }

  }
  break;

 case RZ_Read_Table_State::Cross_Block_Pre_Entry:
 {
  CAON_PTR_DEBUG(RE_Node ,next_node_)
  CAON_PTR_DEBUG(tNode ,current_node_)
  current_node_ = next_node_;
  next_node_ = rq_.Run_Call_Entry(current_node_);

  run_state_.set_read_table_state(RZ_Read_Table_State::Cross_Block_Statement_Pre_Entry);

  //? This List_Pre_Entry appears to be Haskell-specific
  //? run_state_.set_read_table_state(RZ_Read_Table_State::List_Pre_Entry);
  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
  break;
 }
  // // fallthrough?

 case RZ_Read_Table_State::Cross_Block_Statement_Pre_Entry:
  {
   caon_ptr<RE_Call_Entry> rce;
   // //  Should this be a different run state?
   if(run_state_.flags.current_noop)
   {
    rce = current_node_->re_call_entry();
    if(rce)
    {
     CAON_PTR_DEBUG(RE_Call_Entry ,rce)
     rce = current_node_->re_call_entry();
     current_call_entry_object_ = rce;
    }
    run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
    run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Entry_Indent);
     //?current_node_ = next_node_;
   }
   else
   if(caon_ptr<RE_Node> n = find_call_entry(*current_node_, rce))
   {
    current_call_entry_object_ = rce;
    run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
    run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Entry_Indent);
    current_node_ = n;
    //current_node_ = n;
    break;
   }
  }
  break;

 case RZ_Read_Table_State::Block_Statement_List_Pre_Entry:
   // // fallthrough
 case RZ_Read_Table_State::List_Pre_Entry:
  current_node_ = next_node_;
  if(caon_ptr<tNode> n = embed_redirect_node())
  {
   if(valuer_->embedder()->match_noop_node(n))
   {
    run_state_.flags.current_noop = true;
   }
   else
   {
    CAON_PTR_DEBUG(tNode ,n)
    embed_branch_nodes_.push(current_node_);
    current_node_ = n;
    current_run_plugin_ = new RZ_Embed_Branch_Run_Plugin(*this);
    run_state_.flags.has_run_plugin = true;
    run_state_.flags.on_embed_redirect_branch = true;
   }
  }
  run_state_.set_read_table_state(RZ_Read_Table_State::List_Entry);
  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);

  break;

 case RZ_Read_Table_State::Lex_Tuple_Pre_Entry:
 {
  CAON_PTR_DEBUG(RE_Node ,current_node_)
  CAON_PTR_DEBUG(RE_Node ,next_node_)
  current_node_ = next_node_;

  if(caon_ptr<RE_Node> nn = rq_.Run_Data_Entry(current_node_))
  {
   CAON_PTR_DEBUG(RE_Node ,nn)
   next_node_ = nn;
  }

  run_state_.set_read_table_state(RZ_Read_Table_State::Lex_Tuple_Entry);
  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
  break;
 }

 case RZ_Read_Table_State::Lex_Tuple_Entry:
 {
  CAON_PTR_DEBUG(RE_Node ,current_node_)
  CAON_PTR_DEBUG(RE_Node ,next_node_)
  current_node_ = next_node_;
  run_state_.set_read_table_state(RZ_Read_Table_State::List_Sequence);
  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
  break;

 }
  // //?
 case RZ_Read_Table_State::List_Entry:
 case RZ_Read_Table_State::List_Sequence:
  {
   bool is_statement_final = false;
   if(current_call_entry_object_)
   {
    is_statement_final = current_call_entry_object_->flags.is_statement_entry;
   }
   if(is_statement_final)
    find_next_token(RZ_Read_Table_State::Statement_Final, RZ_Read_Table_Post_Advance_State::Holds_Token);
   else
    find_next_token(RZ_Read_Table_State::List_Final, RZ_Read_Table_Post_Advance_State::Holds_Token);
  }
  break;

// case RZ_Read_Table_State::List_Embed_Sequence:
//  advance_embed_sequence(RZ_Read_Table_State::List_Final, RZ_Read_Table_Post_Advance_State::Holds_Token);

//  read_table_state_ = List_Sequence;

//  if(position_index_ < max_position_index_)
//   ++position_index_;
//  else
//   read_table_state_ = Post_Tokens;
  break;

 case RZ_Read_Table_State::Block_Pre_Entry:
 {
  //run_state_.set_read_table_state(RZ_Read_Table_State::Block_Entry);
  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
  CAON_EVALUATE_DEBUG(tNode ,n1 ,current_node_)
  find_block_entry();
  CAON_EVALUATE_DEBUG(tNode ,n2 ,current_node_)
  CAON_PTR_DEBUG(tNode ,next_node_)
  break;
 }

 case RZ_Read_Table_State::Cpp_Block_Entry:
 {
  current_node_ = next_node_;
  // //?
  //run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Pre_Entry);


  //?run_state_.set_read_table_state(RZ_Read_Table_State::Block_Statement_Entry);
  run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Prepare_Entry);
  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
  //run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
  CAON_PTR_DEBUG(tNode ,current_node_)
  break;
 }

 case RZ_Read_Table_State::Statement_Prepare_Entry:
 {
  current_node_ = next_node_;
  // //?
  //run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Pre_Entry);

  run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Entry);
  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
  //run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
  CAON_PTR_DEBUG(tNode ,current_node_)
  break;
 }

 case RZ_Read_Table_State::Statement_Entry_Indent:
 {
  run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Entry);
  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
  //run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
  CAON_PTR_DEBUG(tNode ,current_node_)
  break;
 }
 case RZ_Read_Table_State::Cpp_Redirect_Leave:
  if(next_node_)
  {
   current_node_ = next_node_;
   CAON_PTR_DEBUG(RE_Node ,next_node_)

   run_state_.set_read_table_state(RZ_Read_Table_State::Cpp_Redirect_Leave_Block_Pre_Entry);
   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
  }
  else
  {
   run_state_.set_read_table_state(RZ_Read_Table_State::Cpp_Redirect_Final);
  }
  break;

 case RZ_Read_Table_State::Cpp_Redirect_Leave_Block_Pre_Entry:
  {
   CAON_PTR_DEBUG(RE_Node ,current_node_)

   run_state_.set_read_table_state(RZ_Read_Table_State::Block_Pre_Entry);
    //????
    //run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
    run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
  }
  break;

 case RZ_Read_Table_State::Statement_End:
  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
  run_state_.set_read_table_state(RZ_Read_Table_State::Block_End);
  break;

 case RZ_Read_Table_State::Cpp_Redirect_Final:
 case RZ_Read_Table_State::Statement_Final:

  //?
  //?entry_nodes_.pop();
  {
   // //   If the last entry node was in tail position,
   //      set current_call_entry_object_ but not current_node_.
   CAON_PTR_DEBUG(RE_Call_Entry ,current_call_entry_object_)
   // //   Note: when generating C++, statement_final does not mandate
   //      a post-advance holds-token, whereas for Lisp, given List_Final,
   //      there is still a token being held over.  This is because of
   //      of when, in the readtable loop, this advance() function is called.
   //      The R/Z "Semantic Readtable" is read from two different places
   //      inside Clasp, one to read a single token and one to read a list.
   reset_call_entry_object(RZ_Read_Table_State::Statement_End, RZ_Read_Table_Post_Advance_State::No_Token,
    RZ_Read_Table_State::Statement_End, RZ_Read_Table_Post_Advance_State::No_Token);
  }
  break;

 case RZ_Read_Table_State::Lexical_Declarations_Leave:
  {
   CAON_PTR_DEBUG(RE_Node ,current_node_)
   if(caon_ptr<RE_Node> entry_node = rq_.Run_Call_Entry(current_node_))
   {
    CAON_PTR_DEBUG(RE_Node ,entry_node)
    next_node_ = entry_node;
    run_state_.set_read_table_state(RZ_Read_Table_State::Lambda_Block_Statement_Pre_Entry);
    run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
   }
   break;
  }

 case RZ_Read_Table_State::Lambda_Block_Statement_Pre_Entry:
  {
   current_node_ = next_node_;
   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
   run_state_.set_read_table_state(RZ_Read_Table_State::Lambda_Block_Statement_Entry);
   CAON_PTR_DEBUG(RE_Node ,current_node_)
   break;
  }
 case RZ_Read_Table_State::Lambda_Block_Statement_Entry:
  {
   CAON_PTR_DEBUG(RE_Call_Entry ,current_call_entry_object_)
   CAON_PTR_DEBUG(RE_Node ,current_node_)

   if(caon_ptr<RE_Call_Entry> rce = current_node_->re_call_entry())
   {
    CAON_PTR_DEBUG(RE_Call_Entry ,rce)
    current_call_entry_object_ = rce;
   }
   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
   run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Entry_Indent);
   break;
  }

 case RZ_Read_Table_State::Block_Pre_Entry_As_Sequence:
  {
   CAON_PTR_DEBUG(RE_Call_Entry ,current_call_entry_object_)
   CAON_PTR_DEBUG(RE_Node ,current_node_)

   if(caon_ptr<RE_Call_Entry> rce = current_node_->re_call_entry())
   {
    CAON_PTR_DEBUG(RE_Call_Entry ,rce)
    current_call_entry_object_ = rce;
   }
   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
   run_state_.set_read_table_state(RZ_Read_Table_State::Block_Statement_Entry);
   break;
  }

 case RZ_Read_Table_State::Lexical_Expression_Leave:
  {
   break;
  }

 case RZ_Read_Table_State::List_Final:
//?  read_table_state_ = RZ_Read_Table_State::List_End;

//?
//?  current_node_ = entry_nodes_.top();
  //?
  //? entry_nodes_.pop();
  {
   // //   If the last entry node was in tail position,
   //      set current_call_entry_object_ but not current_node_.
   CAON_PTR_DEBUG(RE_Call_Entry ,current_call_entry_object_)

   if(run_state_.flags.cpp_mode)
   {
    current_lex_iterator_ = nullptr;
    if(lex_iterators_.contains(current_call_entry_object_))
    {
     run_state_.set_read_table_state(RZ_Read_Table_State::Lexical_Expression_Leave);
     run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
     break;
//     reset_call_entry_object(RZ_Read_Table_State::List_Final, RZ_Read_Table_Post_Advance_State::No_Token,
//      RZ_Read_Table_State::Lexical_Expression_Leave, RZ_Read_Table_Post_Advance_State::No_Token);
    }
    else if(caon_ptr<RE_Node> ben = find_block_entry_as_sequence())
    {
     CAON_PTR_DEBUG(RE_Node ,ben)
     next_node_ = ben;
     current_node_ = ben;
     run_state_.set_read_table_state(RZ_Read_Table_State::Block_Pre_Entry_As_Sequence);
     run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
     break;
    }
    else
    {
     reset_call_entry_object(RZ_Read_Table_State::List_Final, RZ_Read_Table_Post_Advance_State::No_Token,
      RZ_Read_Table_State::List_End, RZ_Read_Table_Post_Advance_State::No_Token);
    }

    if(run_state_.read_table_state() == RZ_Read_Table_State::List_Final)
     if(current_call_entry_object_)
      if(current_call_entry_object_->flags.is_statement_entry)
       run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Final);
   }
   else
   {
    reset_call_entry_object(RZ_Read_Table_State::List_Final, RZ_Read_Table_Post_Advance_State::Holds_Token,
     RZ_Read_Table_State::List_End, RZ_Read_Table_Post_Advance_State::No_Token);
   }

  }
  break;
 case RZ_Read_Table_State::List_End:
  {
   if(current_call_entry_object_)
   {
    CAON_PTR_DEBUG(RE_Call_Entry ,current_call_entry_object_)
    if(current_node_)
    {
     if(current_call_entry_object_->call_depth() > 0)
      find_continue_token(RZ_Read_Table_State::List_End, RZ_Read_Table_Post_Advance_State::No_Token);
     else
      find_continue_token(RZ_Read_Table_State::Graph_End, RZ_Read_Table_Post_Advance_State::Deactivate);
    }
    else
    {
     reset_call_entry_object(RZ_Read_Table_State::List_Final, RZ_Read_Table_Post_Advance_State::Holds_Token,
      RZ_Read_Table_State::Graph_End, RZ_Read_Table_Post_Advance_State::Deactivate);
    }
   }
   else
   {
    run_state_.set_read_table_state(RZ_Read_Table_State::Graph_End);
    run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Deactivate);
   }
  }
  break;
 default:
  break;
 }

 {
  CAON_PTR_DEBUG(RE_Node ,current_node_)
  CAON_PTR_DEBUG(RE_Node ,next_node_)

  if(current_node_)
   run_state_.flags.current_noop = check_embed_noop(current_node_);

  if(run_state_.flags.current_noop)
  {
   CAON_DEBUG_NOOP
  }

  CAON_DEBUG_NOOP
 }
}
#endif


void RZ_Lisp_Graph_Visitor_Clasp::find_block_entry() //RZ_Read_Table_State state_not_found)
{
 caon_ptr<RE_Call_Entry> rce;
 if(caon_ptr<RE_Node> n = visitor_.find_call_entry(*current_node_, rce))
 {
  CAON_PTR_DEBUG(tNode ,n)
//?  if(run_state_.flags.cpp_mode)
//   run_state_.set_read_table_state(RZ_Read_Table_State::Cpp_Block_Entry);
//  else
//  {
   run_state_.set_read_table_state(RZ_Read_Table_State::Expression_Pre_Entry);
   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
//?  }
  next_node_ = n;
  current_call_entry_object_ = rce;
  run_state_.flags.has_run_plugin = false;
   //run_state_.flags.on_block_entry_branch = false;
 }
}

//
void RZ_Lisp_Graph_Visitor_Clasp::find_run_entry(RZ_Read_Table_State state_not_found, RZ_Read_Table_Post_Advance_State post_state_not_found)
{
 current_node_->debug_connections();

 CAON_PTR_DEBUG(RE_Node ,current_node_)

 if(caon_ptr<tNode> n = visitor_.find_run_block_entry(current_node_, &next_node_))
 {
  CAON_PTR_DEBUG(tNode ,n)
    //? //?entry_nodes_.push(n);  //caon_ptr<RE_Call_Entry> rce;
  //?run_state_.set_block_entry_branch_state(RZ_Block_Entry_Branch_State::Pre_Block);

  current_node_ = n;
  current_block_node_ = n;
  //?find_next_node_from_entry(*n);
  if(run_state_.read_table_state() == RZ_Read_Table_State::Root)
   run_state_.set_read_table_state(RZ_Read_Table_State::File_Block_Pre_Entry);
  else
   run_state_.set_read_table_state(RZ_Read_Table_State::Block_Pre_Entry);
 }
 else
 {
  run_state_.set_read_table_state(state_not_found);
  run_state_.set_post_advance_state(post_state_not_found);
 }
}
////?
//// if(caon_ptr<tNode> n = rq_.Run_Call_Entry(current_node_))
//// {
////  entry_nodes_.push(n);
////  run_state_.set_read_table_state(RZ_Read_Table_State::List_Pre_Entry);
////  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
////  next_node_ = n;
//// //  Graph_End

//// //  normalize_run_call(start_node, n, rlq_.Run_Call_Entry);
//// }
//// else
// if(caon_ptr<tNode> n = rq_.Run_Block_Entry(current_node_))
// {
//  CAON_PTR_DEBUG(tNode ,n)

//  //?
//  //?entry_nodes_.push(n);

//  //caon_ptr<RE_Call_Entry> rce;

//  //read_table_state_ = RZ_Read_Table_State::Block_Entry;
//  //run_state_.set_block_entry_branch_state(RZ_Block_Entry_Branch_State::Pre_Block);

//  current_node_ = n;
//  current_block_node_ = n;

//  // lexical_scope_iterator_ = RZ_Lisp_Graph_Lexical_Scope::iterator_type(current_lexical_scope_.symbols());
//  if(run_state_.flags.cpp_mode)
//  {
//   find_next_node_from_entry(*n);
//   run_state_.set_read_table_state(RZ_Read_Table_State::File_Entry);
//  }
//  else
//  {
//   run_state_.flags.has_run_plugin = true;
//   current_run_plugin_ = new RZ_Block_Entry_Run_Plugin(*this,
//    RZ_Lisp_Graph_Lexical_Scope::iterator_type(current_lexical_scope_.symbols()));

//   current_run_plugin_->activate();
//  }
// }
// else
// {
//  run_state_.set_read_table_state(state_not_found);
//  run_state_.set_post_advance_state(post_state_not_found);
// }
//}

void RZ_Lisp_Graph_Visitor_Clasp::advance_embed_sequence(RZ_Read_Table_State state_not_found, RZ_Read_Table_Post_Advance_State post_state_not_found)
{
 bool still_on_branch = current_run_plugin_->advance();
 if(!still_on_branch)
 {
     run_state_.flags.on_embed_redirect_branch = false;
     run_state_.flags.has_run_plugin = false;
     current_node_ = embed_branch_nodes_.top();
     embed_branch_nodes_.pop();
     run_state_.set_read_table_state(state_not_found);
     run_state_.set_post_advance_state(post_state_not_found);
 }

// caon_ptr<RZ_Graph_Embed_Token> rget = current_embed_token();
// if(rget)
//  rget->advance_arg(current_embed_arg_position_);
// if(current_embed_arg_position_ == 0)
// {
//  if(rget->entry_node())
//  {
//   run_state_.flags.on_embed_redirect_branch = false;
//   run_state_.flags.on_embed_redirect_entry = true;
//   run_state_.set_read_table_state(RZ_Read_Table_State::List_Pre_Entry);
//   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
//   current_node_ = rget->entry_node();
//   next_node_ = rget->entry_node();
//  }
//  else
//  {
//   run_state_.flags.on_embed_redirect_branch = false;
//   current_node_ = embed_branch_nodes_.top();
//   embed_branch_nodes_.pop();
//   run_state_.set_read_table_state(state_not_found);
//   run_state_.set_post_advance_state(post_state_not_found);
//  }
// }
}


//caon_ptr<RZ_Lisp_Graph_Visitor::tNode>
// RZ_Lisp_Graph_Visitor_Clasp::find_call_entry(const tNode& node, caon_ptr<RE_Call_Entry>& rce)
//{
// if(rce = node.re_call_entry())
// {
//  return rq_.Run_Call_Entry(&node);
//   // //return &node;
// }
// else if(caon_ptr<tNode> next_node = rq_.Run_Call_Entry(&node))
// {
//  return find_call_entry(*next_node, rce);
// }
// return nullptr;
//}


//caon_ptr<RZ_Lisp_Graph_Visitor::tNode>
// RZ_Lisp_Graph_Visitor_Clasp::find_data_entry(const tNode& node, caon_ptr<RE_Call_Entry>& rce)
//{
// //caon_ptr<RE_Call_Entry> rce1 = rce;
// CAON_PTR_DEBUG(RE_Call_Entry ,rce)

// if(rce = node.re_call_entry())
// {
//  caon_ptr<tNode> ref = rce->ref_node();
//  caon_ptr<tNode> par = rce->parent_entry_node();
//  caon_ptr<tNode> sn = rce->self_node();

//  CAON_PTR_DEBUG(tNode ,ref)
//  CAON_PTR_DEBUG(tNode ,par)
//  CAON_PTR_DEBUG(tNode ,sn)

//  return rq_.Run_Data_Entry(&node);
//   // //return &node;
// }
// else if(caon_ptr<tNode> next_node = rq_.Run_Call_Entry(&node))
// {
//  return find_data_entry(*next_node, rce);
// }
// return nullptr;
//}


//?

//?
//caon_ptr<RZ_Lisp_Graph_Visitor::tNode> RZ_Lisp_Graph_Visitor_Clasp::find_next_token()
//{
// caon_ptr<tNode> result = nullptr;
// caon_ptr<RE_Call_Entry> rce;
// CAON_PTR_DEBUG(tNode ,current_node_)
// CAON_PTR_DEBUG(tNode ,next_node_)

// current_node_->debug_connections();

// // ...
// return result;
//}

// if(result = rq_.Run_Call_Sequence(current_node_))
// {
//  run_state_.set_read_table_state(RZ_Read_Table_State::Expression_Sequence);
//  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
//  set_current_node(result);
// }
// else if(result = find_call_entry(*current_node_, rce)) //rq_.Run_Call_Entry(current_node_))
// {
//  current_call_entry_object_ = rce;
//  run_state_.set_read_table_state(RZ_Read_Table_State::Expression_Pre_Entry);
//  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
//  next_node_ = result;
// }
// else if(result = find_data_entry(*current_node_, rce))
// {
//  current_call_entry_object_ = rce;

//  caon_ptr<tNode> ref = rce->ref_node();
//  caon_ptr<tNode> par = rce->parent_entry_node();

//  CAON_PTR_DEBUG(tNode ,ref)
//  CAON_PTR_DEBUG(tNode ,par)

//  CAON_PTR_DEBUG(tNode ,result)
//  rce->flags.is_data_branch_entry = true;
//  CAON_PTR_DEBUG(RE_Call_Entry ,rce)
//  caon_ptr<RE_Tuple_Info> rti = result->re_tuple_info();
//  CAON_PTR_DEBUG(RE_Tuple_Info ,rti)

//  // //? This should be handled sooner...
//  // rti->set_call_entry_node(current_node_);

//  run_state_.set_read_table_state(RZ_Read_Table_State::Expression_Sequence);
//  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
//  set_current_node(result);
// }
// else if(result = rq_.Run_Data_Sequence(current_node_))
// {
//  CAON_PTR_DEBUG(tNode ,result)
//  run_state_.set_read_table_state(RZ_Read_Table_State::Expression_Sequence);
//  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
//  set_current_node(result);
// }
// else if(data_continue_node_)
// {
//  reset_call_entry_object(run_state_.read_table_state(), run_state_.post_advance_state(),
//   run_state_.read_table_state(), run_state_.post_advance_state());
//  //current_call_entry_object_ =
//  result = data_continue_node_;
//  data_continue_node_ = nullptr;
//  CAON_PTR_DEBUG(tNode ,result)
//  run_state_.set_read_table_state(RZ_Read_Table_State::Expression_Sequence);
//  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//  set_current_node(result);
// }
// else if(result = find_data_leave(*current_node_))
// {
//  CAON_PTR_DEBUG(tNode ,result)
//  result->debug_connections();
//  if(result = rq_.Run_Cross_Continue(result))
//  {
//   data_continue_node_ = result;
//   //return result;
//  }
// }

// // //  Look out for the duplicate code ....
// else if(result = rq_.Run_Block_Entry(current_node_))
// {
//  caon_ptr<RE_Block_Entry> rbe = result->re_block_entry();
//  CAON_PTR_DEBUG(RE_Block_Entry ,rbe)
//  run_state_.set_read_table_state(RZ_Read_Table_State::Block_Pre_Entry);
//  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
//  set_current_node(result);
// }
// return result;
//}


//?
//void RZ_Lisp_Graph_Visitor_Clasp::find_next_token(RZ_Read_Table_State state_not_found,
// RZ_Read_Table_Post_Advance_State post_state_not_found)
//{
// if(run_state_.flags.current_noop)
// {
////  run_state_.flags.current_noop = false;
////  run_state_.flags.post_current_noop = true;

//  run_state_.set_read_table_state(state_not_found);
//  run_state_.set_post_advance_state(post_state_not_found);
//  return;
// }
// if(caon_ptr<tNode> n = find_next_token())
// {
//  CAON_PTR_DEBUG(tNode ,n)
//  CAON_PTR_DEBUG(tNode ,current_node_)
//  CAON_PTR_DEBUG(tNode ,next_node_)
//  CAON_DEBUG_NOOP
// }
// else
// {
//  run_state_.set_read_table_state(state_not_found);
//  run_state_.set_post_advance_state(post_state_not_found);
// }
//}
//#endif


caon_ptr<RZ_Lisp_Graph_Visitor::tNode> RZ_Lisp_Graph_Visitor_Clasp::find_block_continue()
{
 visitor_.find_block_continue(current_node_);
}


//void RZ_Lisp_Graph_Visitor_Clasp::find_continue_token(RZ_Read_Table_State state_not_found, RZ_Read_Table_Post_Advance_State post_state_not_found)
//{
// if(!current_node_)
// {
//  run_state_.set_read_table_state(state_not_found);
//  run_state_.set_post_advance_state(post_state_not_found);
//  return;
// }
// if(caon_ptr<tNode> n = rq_.Run_Cross_Continue(current_node_))
// {
//  if(caon_ptr<RE_Call_Entry> rce = n->re_call_entry())
//  {
//   current_call_entry_object_ = rce;
//   run_state_.set_read_table_state(RZ_Read_Table_State::Expression_Pre_Entry);
//   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
//   next_node_ = n;
//  }
//  else
//  {
//   run_state_.set_read_table_state(RZ_Read_Table_State::Expression_Sequence);
//   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
//   current_node_ = n;
//  }
// }
// else
//  run_state_.set_read_table_state(state_not_found);
//}


