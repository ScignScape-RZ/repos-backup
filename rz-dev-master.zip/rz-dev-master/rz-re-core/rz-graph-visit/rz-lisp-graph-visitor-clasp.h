
#ifndef RZ_LISP_GRAPH_VISITOR_CLASP__H
#define RZ_LISP_GRAPH_VISITOR_CLASP__H

#include "accessors.h"

#include "flags.h"

#include "rz-graph-sre/rz-read-table-state.h"

//#include "rz-graph-build/graph/rz-lisp-node.h"
//#include "rz-graph-build/query/rz-lisp-query.h"
//#include "rz-graph-build/rz-lisp-frame.h"

#include "rz-graph-core/kernel/rz-re-dominion.h"
#include "rz-graph-core/kernel/query/rz-re-query.h"
#include "rz-graph-core/kernel/frame/rz-re-frame.h"

#include "rz-relae/relae-caon-ptr.h"

#include "rz-graph-token/types/run-types.h"

#include "rz-graph-token/token/token-kinds.h"

#include "rz-graph-valuer/scope/rz-lisp-graph-lexical-scope.h"

#include "rz-lisp-graph-visitor-run-state.h"

#include <stack>
#include <QStack>

#include <map>

#include "rzns.h"
//#include "ctqns.h"

//?class RZ_Lisp_Graph;

RZNS_(RECore)

class RE_Graph;
class RE_Node;
class RE_Call_Entry;
class RZ_Cpp_Project;
class RZ_Haskell_Project;
class RZ_Clasp_Project;
class RZ_SRE_Token;

_RZNS(RECore)

USING_RZNS(RECore)


RZNS_(GRun)

class RZ_Graph_Run_Token;

_RZNS(GRun)


RZNS_(GBuild)

//class RZ_Lisp_Graph;
class RZ_Lisp_Graph_Core_Function;
class RZ_Lisp_Token;

//class RZ_Lisp_Core_Valuer;
//class RZ_Lisp_Core_Runner;

_RZNS(GBuild)

USING_RZNS(GBuild)


RZNS_(GEmbed)

class RZ_Graph_Run_Embedder;
class RZ_Graph_Embed_Token;
class RZ_Graph_Cpp_Token;
class RZ_Graph_Haskell_Token;
class RZ_Graph_Embed_Run_Valuer;
class RZ_Graph_Cheerp_Token;
class RZ_Graph_Clasp_Token;

_RZNS(GEmbed)

USING_RZNS(GEmbed)


RZNS_(GVal)

class RZ_Lisp_Graph_Valuer;

_RZNS(GVal)

USING_RZNS(GVal)


RZNS_(RZCheerp)

 class RZ_Cheerp_Source_Element;

_RZNS(RZCheerp)

RZNS_(RZClasp)

 class RZ_Clasp_Code_Generator;
 class RZ_Clasp_Source_Element;

_RZNS(RZClasp)

USING_RZNS(RZClasp)



RZNS_(GRun)

class RZ_Lisp_Graph_Runner;

_RZNS(GRun)

USING_RZNS(GRun)


RZNS_(RZCheerp)

class RZ_Cheerp_Code_Generator;

_RZNS(RZCheerp)

USING_RZNS(RZCheerp)


RZNS_(GBuild)


class RZ_Lisp_Graph_Visitor_Run_Plugin;
class RZ_Lisp_Graph_Visitor;


class RZ_Lisp_Graph_Visitor_Clasp
{
public:

 typedef RE_Node tNode;

private:

 enum class Find_Next_Token_Flags
 {
  Normal, Expression_Flag, Block_Continue
 };

 RZ_Lisp_Graph_Visitor& visitor_;

 caon_ptr<RE_Node> current_node_;
 caon_ptr<RE_Node> rewind_node_;
 caon_ptr<RE_Node> next_node_;
 caon_ptr<RE_Node> current_block_node_;
 caon_ptr<RE_Call_Entry> current_call_entry_object_;
 caon_ptr<RE_Node> current_call_entry_node_;
 caon_ptr<RE_Node> current_pending_parent_block_node_;

 caon_ptr<RZ_Graph_Clasp_Token> last_graph_clasp_token_;

 void find_next_token(RZ_SRE_Result_State& result_state, Find_Next_Token_Flags flag);

 caon_ptr<RE_Node> find_next_token_rewind(RZ_SRE_Result_State& result_state,
   bool expression_flag, int& count, caon_ptr<RE_Node>& rewind_entry_node);

 void rewind_call_entry_object();

 bool current_call_entry_is_statement();

 RZ_Lisp_Graph_Visitor_Run_State run_state_;
 caon_ptr<RZ_Lisp_Graph_Visitor_Run_Plugin> current_run_plugin_;

 std::stack<caon_ptr<tNode>> embed_branch_nodes_;

 caon_ptr<RE_Node> find_block_entry_as_sequence();

 QString document_directory_;


 QStack<caon_ptr<tNode>> call_entry_nodes_;
//? QStack<caon_ptr<RZ_Lisp_Graph_Block_Info>> block_info_stack_;

 void push_call_entry_node(caon_ptr<RE_Node> node);

 int tail_rewind_count_;

public:

 RZ_Lisp_Graph_Visitor_Clasp(RZ_Lisp_Graph_Visitor& visitor);

 ACCESSORS__RGET(RZ_Lisp_Graph_Visitor_Run_State ,run_state)

 ACCESSORS(caon_ptr<RE_Node> ,current_node)
 ACCESSORS(caon_ptr<RE_Node> ,rewind_node)
 ACCESSORS(caon_ptr<RE_Node> ,next_node)
 ACCESSORS(caon_ptr<RE_Call_Entry> ,current_call_entry_object)

 ACCESSORS(caon_ptr<RE_Node> ,current_block_node)

 ACCESSORS(caon_ptr<RZ_Graph_Clasp_Token> ,last_graph_clasp_token)
 ACCESSORS(caon_ptr<RE_Node> ,current_pending_parent_block_node)

 void cancel_pending_parent_block_node();
 void confirm_pending_parent_block_node();
 bool check_confirm_pending_parent_block_node();

 RZ_Lisp_Graph_Valuer& valuer()
 {
  return *visitor_.valuer();
 }

 //?ACCESSORS(caon_ptr<RZ_Graph_Clasp_Token> ,last_graph_clasp_token)

 caon_ptr<RZ_Clasp_Code_Generator> rz_clasp_code_generator();

 void deactivate();
 void activate();


 QString current_call_entry_prefix();
// void deactivate_run_state_plugin();

 void find_block_entry(); //RZ_Read_Table_State state_not_found);

 bool current_call_entry_is_function_expression();
 bool check_embed_noop(caon_ptr<tNode> n);

 caon_ptr<tNode> find_data_leave(tNode& n);

 void advance();
 void reset();

 void find_run_entry(RZ_Read_Table_State state_not_found, RZ_Read_Table_Post_Advance_State post_state_not_found);
 void find_next_token(RZ_Read_Table_State state_not_found, RZ_Read_Table_Post_Advance_State post_state_not_found);
 void find_continue_token(RZ_Read_Table_State state_not_found, RZ_Read_Table_Post_Advance_State post_state_not_found);


 caon_ptr<tNode> find_next_token();

 QString call_entry_label();

 void advance_embed_sequence(RZ_Read_Table_State state_not_found, RZ_Read_Table_Post_Advance_State post_state_not_found);

 void check_type_indicator(caon_ptr<tNode>& node);

 caon_ptr<RZ_Clasp_Source_Element>
  current_token_string(RZ_Graph_Run_Token& rzt);

 caon_ptr<RZ_Graph_Clasp_Token>
  current_embed_clasp_token(caon_ptr<RZ_Clasp_Source_Element>& cse);

 caon_ptr<tNode> find_block_continue();

 caon_ptr<RZ_Clasp_Source_Element>
  get_current_token(RZ_Graph_Run_Token& rzt);

 caon_ptr<RZ_Clasp_Source_Element>
  get_current_sre_token(RZ_SRE_Token& sre_token);

 caon_ptr<RZ_Graph_Embed_Token> current_embed_rename_token();
 void pop_embed_branch_node();

 caon_ptr<RZ_Lisp_Token> current_lisp_token();
 caon_ptr<tNode> embed_redirect_node();
 caon_ptr<RZ_Graph_Embed_Token> current_embed_token();

 void reset_call_entry_object(RZ_Read_Table_State state_on_unwind,
  RZ_Read_Table_Post_Advance_State post_state_on_unwind, RZ_Read_Table_State state_on_no_unwind,
   RZ_Read_Table_Post_Advance_State post_state_on_no_unwind);

 caon_ptr<RZ_Lisp_Graph_Block_Info> current_block_info();
 caon_ptr<RE_Block_Entry> current_node_as_block_entry();

 bool quasi_statements();
 void deactivate_run_state_plugin();

 //caon_ptr<RZ_Clasp_Source_Element>
 //  get_current_sre_token(RZ_SRE_Token& sre_token);

 //void advance();



// caon_ptr<RZ_Lisp_Graph_Visitor::tNode>
//  find_call_entry(const tNode& node, caon_ptr<RE_Call_Entry>& rce);

};

_RZNS(GBuild)




#endif
