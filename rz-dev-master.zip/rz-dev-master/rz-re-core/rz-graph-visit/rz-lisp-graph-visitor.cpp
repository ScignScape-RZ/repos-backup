
#include "rz-lisp-graph-visitor.h"

//?#include "rz-graph-build/graph/rz-lisp-graph.h"

#include "rz-graph-run/token/rz-graph-run-token.h"

#include "rz-graph-token/token/rz-lisp-token.h"

#include "rz-graph-core/kernel/graph/rz-re-node.h"

#include "rz-code-generators/rz-function-def-info.h"
//#include "rz-core/rz-lisp/valuer/rz-lisp-core-valuer.h"

//?#include "rz-core/rz-lisp/run/rz-lisp-core-function.h"

#include "rz-graph-token/rz-lisp-graph-core-function.h"

#include "rz-graph-core/token/rz-re-token.h"

#include "rz-graph-embed/rz-graph-embed-token.h"

#include "rz-graph-embed/rz-graph-cpp/rz-graph-cpp-token.h"
#include "rz-graph-embed/rz-graph-haskell/rz-graph-haskell-token.h"
#include "rz-graph-embed/rz-graph-cheerp/rz-graph-cheerp-token.h"
#include "rz-graph-embed/rz-graph-clasp/rz-graph-clasp-token.h"

#include "rz-block-entry-run-plugin.h"

#include "rz-graph-core/code/rz-re-function-def-entry.h"

#include "rz-graph-valuer/scope/rz-lisp-graph-lexical-scope.h"
//#include "rz-core/rz-lisp/run/rz-lisp-core-runner.h"

#include "rz-graph-valuer/valuer/rz-lisp-graph-valuer.h"
#include "rz-graph-run/rz-lisp-graph-runner.h"
#include "rz-graph-build/rz-lisp-graph-result-holder.h"

#include "rz-graph-build/types/run-type-codes.h"

#include "rz-graph-embed/rz-graph-run-embedder.h"

#include "rz-graph-embed-run/rz-graph-embed-run-valuer.h"

#include "rz-graph-embed/rz-graph-embed-check.h"

#include "rz-graph-core/code/rz-re-call-entry.h"
#include "rz-graph-core/code/rz-re-block-entry.h"

#include "rz-embed-branch-run-plugin.h"

#include "rz-graph-core/tuple/rz-re-tuple-info.h"

#include "rz-graph-sre/rz-sre-token.h"

#include <QRegularExpression>
#include <QRegularExpressionMatch>

#include "rz-clasp-code/rz-clasp-code-generator.h"

#include "rzns.h"

USING_RZNS(GBuild)

USING_RZNS(GEmbed)

RZ_Lisp_Graph_Visitor::RZ_Lisp_Graph_Visitor(caon_ptr<RE_Graph> graph)
 : graph_(graph),
   //?current_node_(nullptr), next_node_(nullptr),
   rq_(RE_Query::instance()),
   fr_(RE_Frame::instance()), lisp_graph_runner_(nullptr),
   current_block_node_(nullptr),
   valuer_(new RZ_Lisp_Graph_Valuer(*this)),
   current_lexical_scope_(*valuer_->root_lexical_scope()),
    //lexical_scope_iterator_(current_lexical_scope_.symbols()),
   //?current_call_entry_object_(nullptr),
   //current_embed_arg_position_(0),
   current_run_plugin_(nullptr),
   //?last_graph_cpp_token_(nullptr),
   data_continue_node_(nullptr),
   current_lex_iterator_(nullptr)
//?, pre_entry_nodes_(new QStack<RZ_Lisp_Node*>)
{
 init_core_functions();
 //?fr_.activate();
 //valuer_ = new RZ_Lisp_Graph_Valuer(*this);

 valuer_->rz_lisp_core_function_finder = [this](QString name)
 {
  return this->find_core_function(name);
 };

 run_valuer_ = new RZ_Graph_Embed_Run_Valuer(*valuer_);

 //valuer_->rz_clasp_code_generator()->set_initial_output_text(initial_output_text_);
}

void RZ_Lisp_Graph_Visitor::prepare_rz_path_handlers_output(QString handlers)
{
 if(!handlers.isEmpty())
 {
  handlers.replace(QRegularExpression("\\n"), "\n;");
  handlers.prepend(";;;; R/Z Handlers");
  handlers.append(";;;;\n");
  add_initial_output_text(handlers);
 }
}


void RZ_Lisp_Graph_Visitor::take_project(caon_ptr<RZ_Cpp_Project> project)
{
 check_lisp_graph_runner();
 if(valuer_->embedder())
  valuer_->embedder()->set_cpp_project(project);
}

void RZ_Lisp_Graph_Visitor::take_project(caon_ptr<RZ_Clasp_Project> project)
{
 check_lisp_graph_runner();
 if(valuer_->embedder())
  valuer_->embedder()->set_clasp_project(project);
}

caon_ptr<RZ_Clasp_Code_Generator> RZ_Lisp_Graph_Visitor::rz_clasp_code_generator()
{
 return valuer_->rz_clasp_code_generator();
}

void RZ_Lisp_Graph_Visitor::add_initial_output_text(QString text)
{
 rz_clasp_code_generator()->add_initial_output_text(text);
}


void RZ_Lisp_Graph_Visitor::take_project(caon_ptr<RZ_Haskell_Project> project)
{
 check_lisp_graph_runner();
 if(valuer_->embedder())
  valuer_->embedder()->set_haskell_project(project);
}


void RZ_Lisp_Graph_Visitor::insert_core_function(QString name,
 caon_ptr<RZ_Lisp_Graph_Core_Function> cf)
{
 core_function_map_.insert({name, cf});
}

void RZ_Lisp_Graph_Visitor::init_core_functions()
{
 #define RZ_LISP_GRAPH_FUNCTION_DECLARE(rz_name, cpp_fname, arity, status) \
  insert_core_function(QString(#rz_name), \
   new RZ_Lisp_Graph_Core_Function(#rz_name, #cpp_fname, arity, \
    RZ_Lisp_Graph_Core_Function::status));
 #include "rz-lisp-graph-visitor.core-function-list.h"
 #undef RZ_LISP_GRAPH_FUNCTION_DECLARE
}


void RZ_Lisp_Graph_Visitor::valuer_redirect(RZ_Lisp_Graph_Result_Holder& rh,
 caon_ptr<RZ_Lisp_Graph_Core_Function> cf, caon_ptr<tNode> start_node)
{
 valuer_->redirect_core_function(rh, cf->name(), *start_node);
}


void RZ_Lisp_Graph_Visitor::activate()
{
 run_state_.set_read_table_state(RZ_Read_Table_State::Pre_Root);
}
//?
//void RZ_Lisp_Graph_Visitor::reset()
//{
// // read_table_state_ = Pre_Tokens;
// if(graph_)
// {
//  current_node_ = graph_->root_node();
//  run_state_.set_read_table_state(RZ_Read_Table_State::Root);
// }
// else
//  run_state_.set_read_table_state(RZ_Read_Table_State::Pre_Root);
//}

caon_ptr<RZ_Lisp_Graph_Visitor::tNode> RZ_Lisp_Graph_Visitor::graph_root_node()
{
 if(graph_)
  return graph_->root_node();
 else
  return nullptr;
}


void RZ_Lisp_Graph_Visitor::deactivate()
{
 run_state_.set_read_table_state(RZ_Read_Table_State::Inactive);
 run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::N_A);
}


//void RZ_Lisp_Graph_Visitor::get_current_token_from_block_entry_branch(RZ_Graph_Run_Token& rzt)
//{
// switch(run_state_.block_entry_branch_state())
// {
// case RZ_Block_Entry_Branch_State::Parameter_List_Pre_Entry:
//  if(lexical_scope_iterator_.hasNext())
//   rzt.set_symbol_string_value("let");
//  else
//   //rzt.set_symbol_string_value("let");
//   rzt.set_symbol_string_value("progn");
//  break;

// case RZ_Block_Entry_Branch_State::Parameter_Key:
//  lexical_scope_iterator_.next();
//  rzt.set_symbol_string_value(lexical_scope_iterator_.key());
//  break;

// case RZ_Block_Entry_Branch_State::Parameter_Value:
//  rzt.init_from_scope_token(lexical_scope_iterator_.value());
//  break;

// }

//}

//?
//caon_ptr<RZ_Clasp_Source_Element>
// RZ_Lisp_Graph_Visitor::get_current_sre_token(RZ_SRE_Token& sre_token)
//{
// caon_ptr<RZ_Clasp_Source_Element> result = nullptr;
// if(caon_ptr<RZ_Graph_Run_Token> rzt = sre_token.run_token())
// {
//  result = get_current_token(*rzt);
//  sre_token.set_node(current_node_);
// }
// return result;
//}

QString RZ_Lisp_Graph_Visitor::get_mapkey_string(caon_ptr<RE_Node> node)
{
 CAON_PTR_DEBUG(RE_Node ,node)
 if(caon_ptr<tNode> mapkey_node = rq_.Run_Map_Key_Value(node))
 {
  CAON_PTR_DEBUG(RE_Node ,mapkey_node)
  if(caon_ptr<RZ_Lisp_Token> token = mapkey_node->lisp_token())
  {
   return token->lisp_string_value();
  }
  else if(caon_ptr<RE_Token> re_token = mapkey_node->re_token())
  {
   return re_token->raw_text();
  }
 }
 return QString();
}

//?
//caon_ptr<RZ_Clasp_Source_Element>
// RZ_Lisp_Graph_Visitor::get_current_token(RZ_Graph_Run_Token& rzt)
//{
// //if(block_entry_branch_state_ != RZ_List_Pre_Entry_State::Normal)

// if(run_state_.flags.has_run_plugin)
// {
//  current_run_plugin_->get_current_token(rzt);
//  return //?
//    nullptr;

// }

// switch(run_state_.read_table_state())
// {
// case RZ_Read_Table_State::Root:
////?  rzt.flags.is_list_entry = true;
////? read_table_state_ = Tokens;
//  break;
// case RZ_Read_Table_State::Graph_End:
//  rzt.flags.nothing = true;
// default:
//  {
//   return current_token_string(rzt);
//  }
//  break;
// }
// return nullptr;
//}


//bool RZ_Lisp_Graph_Visitor::current_call_entry_is_function_expression()
//{
// if(current_call_entry_object_)
// {
//  CAON_PTR_DEBUG(RE_Call_Entry ,current_call_entry_object_)
//  return
//    current_call_entry_object_->flags.is_function_expression_entry
//   ||
//    current_call_entry_object_->flags.is_tuple_info_entry;
// }
// return false;
//}

caon_ptr<RZ_Graph_Embed_Token> RZ_Lisp_Graph_Visitor::current_embed_rename_token(caon_ptr<tNode> node)
{
 if(node)
 {
  CAON_PTR_DEBUG(tNode ,node)
  if(caon_ptr<tNode> n = rq_.Run_Embed_Rename(node))
  {
   return n->embed_token();
  }
 }
 return nullptr;
}

caon_ptr<RZ_Lisp_Graph_Visitor::tNode> RZ_Lisp_Graph_Visitor::nested_block_entry_from_prior_node(caon_ptr<tNode> node)
{
 // // explain this...
 caon_ptr<tNode> en = rq_.Run_Call_Sequence(node);
 CAON_PTR_DEBUG(tNode ,en)
 return rq_.Run_Block_Entry(en);
}

caon_ptr<RZ_Graph_Clasp_Token> RZ_Lisp_Graph_Visitor::clasp_redirect_token(caon_ptr<tNode> node)
{
 CAON_PTR_DEBUG(tNode ,node) //?
 if(caon_ptr<tNode> n = rq_.Clasp_Generate_Redirect(node))//Run_Embed_Rename(node))
  return n->clasp_token();
 return nullptr;
}

caon_ptr<RZ_Lisp_Graph_Visitor::tNode> RZ_Lisp_Graph_Visitor::entry_from_call_entry(caon_ptr<tNode> node)
{
 if(node)
 {
  CAON_PTR_DEBUG(tNode ,node)
  node->debug_connections();
  return rq_.Run_Call_Entry(node);
 }
 return nullptr;
}


caon_ptr<RZ_Lisp_Graph_Visitor::tNode> RZ_Lisp_Graph_Visitor::data_entry_from_call_entry(caon_ptr<tNode> node)
{
 if(node)
 {
  CAON_PTR_DEBUG(tNode ,node)
  node->debug_connections();
  return rq_.Run_Data_Entry(node);
 }
 return nullptr;
}


caon_ptr<RZ_Lisp_Graph_Visitor::tNode> RZ_Lisp_Graph_Visitor::find_block_entry_node(caon_ptr<tNode> node, caon_ptr<RZ_Lisp_Graph_Block_Info>& rbi)
{
 if(node)
 {
  node->debug_connections();
  if(caon_ptr<RE_Node> binode = rq_.Block_Info(node))
  {
   rbi = binode->block_info();
  }
  return rq_.Run_Block_Entry(node);
 }
 return nullptr;
}


caon_ptr<RZ_Lisp_Graph_Visitor::tNode>
 RZ_Lisp_Graph_Visitor::embed_redirect_node(caon_ptr<tNode> node)
{
 if(node)
 {
  return rq_.Run_Embed_Redirect(node);
 }
 return nullptr;
}

caon_ptr<RZ_Lisp_Graph_Visitor::tNode>
  RZ_Lisp_Graph_Visitor::find_run_call_entry(caon_ptr<tNode> node)
{
 caon_ptr<tNode> result = nullptr;
 if(node)
 {
  result = rq_.Run_Call_Entry(node);
 }
 return result;
}



caon_ptr<RZ_Lisp_Graph_Visitor::tNode>
 RZ_Lisp_Graph_Visitor::find_run_block_entry(caon_ptr<tNode> node, caon_ptr<tNode>* call_entry_node)
{
 caon_ptr<tNode> result = nullptr;
 if(node)
 {
  result = rq_.Run_Block_Entry(node);
 }
 if(call_entry_node)
 {
  if(result)
  {
   *call_entry_node = rq_.Run_Call_Entry(result);
  }
  else
   *call_entry_node = nullptr;
 }
 return result;
}

//?
//caon_ptr<RZ_Graph_Embed_Token> RZ_Lisp_Graph_Visitor::current_embed_token()
//{
// //?
//// if(tNode* n = embed_redirect_node())
//// {
////  return n->embed_token();
//// }
// if(run_state_.flags.on_embed_redirect_branch)
// {
//  if(current_node_)
//   return current_node_->embed_token();
// }
//// else if(current_node_)
//// {
////  CAON_PTR_DEBUG(tNode ,current_node_)
////  if(caon_ptr<tNode> n = rq_.Run_Embed_Rename(current_node_))
////  {
////   return n->embed_token();
////  }
//// }
// return nullptr;
//}
//?
//void RZ_Lisp_Graph_Visitor::pop_embed_branch_node()
//{
// current_node_ = embed_branch_nodes_.top();
// // //?
// next_node_ = embed_branch_nodes_.top();
// embed_branch_nodes_.pop();

// CAON_PTR_DEBUG(tNode ,current_node_)
// CAON_PTR_DEBUG(tNode ,next_node_)

//}

//caon_ptr<RZ_Clasp_Source_Element>
// RZ_Lisp_Graph_Visitor::current_token_string(RZ_Graph_Run_Token& rzt)
//{
// caon_ptr<RZ_Clasp_Source_Element> result = nullptr;
// if(caon_ptr<RZ_Graph_Embed_Token> rename_token = current_embed_rename_token())
// {
//  rzt.init_from_embed_token(*rename_token);
// }
// else if(caon_ptr<RZ_Graph_Cpp_Token> cpp_token = current_embed_cpp_token())
// {
//  last_graph_cpp_token_ = cpp_token;
//  rzt.init_from_cpp_token(*cpp_token);
// }
// else if(caon_ptr<RZ_Graph_Clasp_Token> clasp_token = current_embed_clasp_token(result))
// {
//  last_graph_clasp_token_ = clasp_token;
//  rzt.init_from_clasp_token(*clasp_token);
// }
////? else if(caon_ptr<RZ_Graph_Cheerp_Token> cheerp_token = current_embed_cheerp_token(result))
//// {
////  last_graph_cheerp_token_ = cheerp_token;
////  rzt.init_from_cheerp_token(*cheerp_token);
//// }
// else if(caon_ptr<RZ_Graph_Haskell_Token> haskell_token = current_embed_haskell_token())
// {
//  last_graph_haskell_token_ = haskell_token;
//  rzt.init_from_haskell_token(*haskell_token);
// }
// else if(caon_ptr<RZ_Lisp_Token> token = current_lisp_token())
// {
////  rzt.init_from(*token);

////  QString fn = valuer_->rename_function_name(*token);
////  if(fn.isEmpty())
//  CAON_PTR_DEBUG(RZ_Lisp_Token ,token)
//  rzt.init_from(*token);
////  else
////   rzt.set_string_value(fn);


////  if(token->run_state_.flags.is_keyword)
////   return QString(":%1").arg(token->string_value());
////  else if(token->run_state_.flags.is_string_literal)
////   return QString("\"%1\"").arg(token->string_value());
////  else
////   return token->string_value();
// }
// else if(current_node_) //caon_ptr<RZ_Lisp_Token> token = current_lisp_token())
// {
//  CAON_PTR_DEBUG(RE_Node ,current_node_)
//  if(caon_ptr<RE_Tuple_Info> rti = current_node_->re_tuple_info())
//  {
//   rzt.flags.is_inserted_tuple_info = true;
//   rzt.set_string_value(rti->lisp_out());
//  }
//   //rzt.init_from(*token);
// }
// return result;
//}


//void RZ_Lisp_Graph_Visitor::reset_call_entry_object(RZ_Read_Table_State state_on_unwind,
// RZ_Read_Table_Post_Advance_State post_state_on_unwind, RZ_Read_Table_State state_on_no_unwind,
//  RZ_Read_Table_Post_Advance_State post_state_on_no_unwind)
//{
//#ifdef HIDE

// CAON_PTR_DEBUG(RE_Call_Entry ,current_call_entry_object_)

// if(caon_ptr<tNode> parent_node = current_call_entry_object_->get_parent_entry_node_unwind())
// {
//  CAON_PTR_DEBUG(tNode ,parent_node)

//  caon_ptr<tNode> current_block_chief_node = current_call_entry_object_->block_chief_node();
//  current_call_entry_object_ = parent_node->re_call_entry();
//  caon_ptr<tNode> parent_block_chief_node = current_call_entry_object_->block_chief_node();

//  CAON_PTR_DEBUG(tNode ,current_block_chief_node)
//  CAON_PTR_DEBUG(tNode ,parent_block_chief_node)

//  CAON_PTR_DEBUG(RE_Call_Entry ,current_call_entry_object_)

//  if(caon_ptr<RE_Node> n = rq_.Run_Cross_Sequence(parent_node))
//  {
//   CAON_PTR_DEBUG(tNode ,n)
//   next_node_ = n;
//  }

//  // current_call_entry_object_->debug_check_entry(rq_.Run_Call_Entry);

//  //?current_node_ = parent_node;
//  //current_node_ = nullptr;

//  if(current_block_chief_node != parent_block_chief_node)
//  {
//   current_block_node_ = nullptr;
//   run_state_.set_read_table_state(RZ_Read_Table_State::Block_End);
//   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//  }
//  else
//  {
//   current_node_ = nullptr;
//   run_state_.set_read_table_state(state_on_unwind);
//   run_state_.set_post_advance_state(post_state_on_unwind);
//  }
// }
// else //if(caon_ptr<tNode> entry_node = current_call_entry_object_->get_next_entry_node())
// {
//  int unwind_count;
//  CAON_PTR_DEBUG(RE_Call_Entry ,current_call_entry_object_);
//  caon_ptr<RE_Node> next_node = current_call_entry_object_->get_next_entry_node(current_call_entry_object_, unwind_count);

//  if(unwind_count)
//  {
//   bool no_unwind = true;
//   CAON_PTR_DEBUG(RE_Node ,next_node);
//   if(caon_ptr<RE_Call_Entry> rce = next_node->re_call_entry())
//   {
//    next_node->debug_connections();
//    CAON_PTR_DEBUG(RE_Call_Entry ,rce);
//    if(caon_ptr<RE_Node> bc_node= rce->block_chief_node())
//    {
//     CAON_PTR_DEBUG(RE_Node ,bc_node);
//     if(caon_ptr<RE_Node> cs_node = rq_.Run_Cross_Sequence(bc_node))
//     {
//      no_unwind = false;
//      current_node_ = bc_node;
//      next_node_ = cs_node;
//       // //  Do we know this is always a block ending?
//      run_state_.set_read_table_state(RZ_Read_Table_State::Cross_Block_Pre_Entry);
//      run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//     }
//    }
//   }
//   //current_node_ = next_entry_node;
//   if(no_unwind)
//   {
//    current_node_ = next_node;
//    run_state_.set_read_table_state(state_on_no_unwind);
//    run_state_.set_post_advance_state(post_state_on_no_unwind);
//   }
//  }
//  else if(next_node && current_call_entry_object_) //?
//  {
//   if(!current_call_entry_object_)
//   {

//   }
//   else
//   {
//    current_node_ = next_node;
//    CAON_PTR_DEBUG(tNode ,current_node_)
//    next_node_ = rq_.Run_Call_Entry(current_node_);
//    CAON_PTR_DEBUG(tNode ,next_node_)
//    if(run_state_.flags.cpp_mode)
//    {
//     CAON_PTR_DEBUG(RE_Call_Entry ,current_call_entry_object_)
//     if(current_call_entry_object_->flags.is_statement_entry)
//      run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Pre_Entry);
//     else
//      run_state_.set_read_table_state(RZ_Read_Table_State::List_Pre_Entry);
//     run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//    }
//    else
//    {
//     run_state_.set_read_table_state(RZ_Read_Table_State::List_Pre_Entry);
//     run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
//    }
//   }
//  }

//  //??
//  else if(current_block_node_)
//  {
//   current_block_node_ = nullptr;
//   run_state_.set_read_table_state(RZ_Read_Table_State::Block_End);
//   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//  }
//  //??


//  else
//  {
//   run_state_.set_read_table_state(state_on_no_unwind);
//   run_state_.set_post_advance_state(post_state_on_no_unwind);
//  }
// }
//#endif
//}

//caon_ptr<RE_Block_Entry> RZ_Lisp_Graph_Visitor::current_node_as_block_entry()
//{
// if(current_node_)
// {
//  return current_node_->re_block_entry();
// }
// return nullptr;
//}


//void RZ_Lisp_Graph_Visitor::deactivate_run_state_plugin()
//{
// current_run_plugin_->deactivate();
// run_state_.flags.has_run_plugin = false;
// switch(run_state_.read_table_state())
// {
// case RZ_Read_Table_State::Expression_Embed_Sequence:
//  run_state_.set_read_table_state(RZ_Read_Table_State::Expression_Final);
//  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
//  break;

// case RZ_Read_Table_State::Expression_Final:
//  {
//   CAON_PTR_DEBUG(tNode ,current_node_)
//   CAON_PTR_DEBUG(tNode ,next_node_)
//   CAON_DEBUG_NOOP
////   run_state_.set_read_table_state(RZ_Read_Table_State::List_Entry);
////   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
//  }
//  break;
// default:
//  break;

// }
//}

//caon_ptr<RZ_Lisp_Graph_Block_Info> RZ_Lisp_Graph_Visitor::current_block_info()
//{
// //CAON_PTR_DEBUG(RE_Block_Entry ,rbe)
// if(current_node_)
// {
//  if(caon_ptr<tNode> n = rq_.Block_Info(current_node_))
//  {
//   return n->block_info();
//  }
// }
// return nullptr;
//}

bool RZ_Lisp_Graph_Visitor::check_embed_noop(caon_ptr<tNode> n)
{
 return valuer_->check_embed_noop(n);
}

//bool RZ_Lisp_Graph_Visitor::quasi_statements()
//{
// if(run_state_.flags.override_quasi_statements)
// {
//  run_state_.flags.override_quasi_statements = false;
//  return false;
// }
// if(current_block_node_)
// {
//  if(caon_ptr<RE_Block_Entry> rbe = current_block_node_->re_block_entry())
//  {
//   return rbe->quasi_statements();
//  }
// }
// return false;
//}

//void RZ_Lisp_Graph_Visitor::find_next_node_from_entry(tNode& node)
//{
// node.debug_connections();

// caon_ptr<RE_Node> next_node;
// if(next_node = rq_.Run_Call_Entry(&node))
// {
//  CAON_PTR_DEBUG(tNode ,next_node)
//  next_node_ = next_node;
//  run_state_.flags.current_noop = check_embed_noop(next_node);
// }
// else if(caon_ptr<tNode> next_node = rq_.Run_Data_Entry(&node))
// {
//  next_node_ = next_node;
// }
//}

//caon_ptr<RE_Node> RZ_Lisp_Graph_Visitor::find_block_entry_as_sequence()
//{
// CAON_PTR_DEBUG(RE_Node ,current_node_)
// CAON_PTR_DEBUG(RE_Call_Entry ,current_call_entry_object_)
// if(current_call_entry_object_)
// {
//  return current_call_entry_object_->block_continue_node();
// }
// return nullptr;
//}

//void RZ_Lisp_Graph_Visitor::advance()
//{
// CAON_PTR_DEBUG(RE_Node ,current_node_)

// if(run_state_.flags.has_run_plugin)
// {
//  bool still_plugin = current_run_plugin_->advance();
//  if(!still_plugin)
//   deactivate_run_state_plugin();
//  return;
// }
// switch(run_state_.read_table_state())
// {
// case RZ_Read_Table_State::Root:
//  find_run_entry(RZ_Read_Table_State::Graph_End, RZ_Read_Table_Post_Advance_State::Deactivate);
//  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Reenter);
//  break;

// case RZ_Read_Table_State::File_Entry:
//  current_node_ = next_node_;
//  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//  run_state_.set_read_table_state(RZ_Read_Table_State::Block_Pre_Entry);
//  break;
// }
//}
//#ifdef HIDE

// case RZ_Read_Table_State::Cpp_File_Entry:
//  current_node_ = next_node_;
//  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//  run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Pre_Entry);
//  break;

// case RZ_Read_Table_State::Statement_Pre_Entry:
//  {
//   caon_ptr<RE_Call_Entry> rce;
//   // //  Should this be a different run state?
//   if(run_state_.flags.current_noop)
//   {
//    rce = current_node_->re_call_entry();
//    if(rce)
//    {
//     CAON_PTR_DEBUG(RE_Call_Entry ,rce)
//     rce = current_node_->re_call_entry();
//     current_call_entry_object_ = rce;
//    }
//    run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//    run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Entry_Indent);
//     //?current_node_ = next_node_;
//   }
//   else
//   if(caon_ptr<RE_Node> n = find_call_entry(*current_node_, rce))
//   {
//    current_call_entry_object_ = rce;
//    run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//    run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Entry_Indent);
//    current_node_ = n;
//    //current_node_ = n;
//    break;
//   }
//  }
//  break;

// case RZ_Read_Table_State::Block_Statement_Entry:
//  find_next_token(RZ_Read_Table_State::Statement_Final, RZ_Read_Table_Post_Advance_State::Holds_Token);

//  //? Kludge!
//  if(run_state_.read_table_state() == RZ_Read_Table_State::List_Pre_Entry)
//  {
//   run_state_.set_read_table_state(RZ_Read_Table_State::Block_Statement_List_Pre_Entry);
//  }

//  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//  //run_state_.set_read_table_state(RZ_Read_Table_State::List_Sequence);
//  break;

// case RZ_Read_Table_State::Statement_Entry:
//  find_next_token(RZ_Read_Table_State::Statement_Final, RZ_Read_Table_Post_Advance_State::Holds_Token);
//  //run_state_.set_read_table_state(RZ_Read_Table_State::List_Sequence);
//  break;

// case RZ_Read_Table_State::Block_End:
// {
//  caon_ptr<tNode> bc_node = find_block_continue();
////  if(caon_ptr<RE_Block_Entry> rbe = bc_node->re_block_entry())
////  {
////   CAON_PTR_DEBUG(RE_Block_Entry ,rbe)
////   CAON_DEBUG_NOOP
////  }
//  if(bc_node)
//  {
//   current_node_ = bc_node;
//   run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Pre_Entry);
//   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//  }
//  else
//  {
//   run_state_.set_read_table_state(RZ_Read_Table_State::Block_Rewind);
//   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//  }
//  break;
// }
// case RZ_Read_Table_State::Block_Rewind:
// {
//  run_state_.set_read_table_state(RZ_Read_Table_State::Graph_End);
//  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Deactivate);
//  break;
// }
////   find_next_token(RZ_Read_Table_State::Graph_End, RZ_Read_Table_Post_Advance_State::Deactivate);
//   //   Find block continuation
////  run_state_.set_read_table_state(RZ_Read_Table_State::Graph_End);
////  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Deactivate);
////  break;
// case RZ_Read_Table_State::Block_Rewind_Reset:
// {
//  current_node_ = next_node_;
//  run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Pre_Entry);
//  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//  break;
// }

// case RZ_Read_Table_State::Lexical_Expression_Pre_Entry:
//  {
//   CAON_PTR_DEBUG(tNode ,current_node_)
//   if(caon_ptr<tNode> en = rq_.Run_Call_Entry(current_node_))
//   {
//    CAON_PTR_DEBUG(tNode ,en)
//    if(caon_ptr<RE_Call_Entry> rce = current_node_->re_call_entry())
//    {
//     CAON_PTR_DEBUG(RE_Call_Entry ,rce)
//     current_call_entry_object_ = rce;
//     next_node_ = en;
//     run_state_.set_read_table_state(RZ_Read_Table_State::List_Pre_Entry);
//     lex_iterators_[rce] = current_lex_iterator_;
//    }
//   }

//   else if(caon_ptr<tNode> dn = rq_.Run_Data_Entry(current_node_))
//   {
//    CAON_PTR_DEBUG(tNode ,dn)
//    if(caon_ptr<RE_Call_Entry> rce = current_node_->re_call_entry())
//    {
//     CAON_PTR_DEBUG(RE_Call_Entry ,rce)
//     current_call_entry_object_ = rce;
//     if(caon_ptr<tNode> dsn = rq_.Run_Data_Entry(dn))
//     {
//      CAON_PTR_DEBUG(tNode ,dsn)
//      next_node_ = dn;

//      run_state_.set_read_table_state(RZ_Read_Table_State::Lex_Tuple_Pre_Entry);
//      lex_iterators_[rce] = current_lex_iterator_;
//     }
//    }
//   }

//  }
//  break;

// case RZ_Read_Table_State::Cross_Block_Pre_Entry:
// {
//  CAON_PTR_DEBUG(RE_Node ,next_node_)
//  CAON_PTR_DEBUG(tNode ,current_node_)
//  current_node_ = next_node_;
//  next_node_ = rq_.Run_Call_Entry(current_node_);

//  run_state_.set_read_table_state(RZ_Read_Table_State::Cross_Block_Statement_Pre_Entry);

//  //? This List_Pre_Entry appears to be Haskell-specific
//  //? run_state_.set_read_table_state(RZ_Read_Table_State::List_Pre_Entry);
//  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//  break;
// }
//  // // fallthrough?

// case RZ_Read_Table_State::Cross_Block_Statement_Pre_Entry:
//  {
//   caon_ptr<RE_Call_Entry> rce;
//   // //  Should this be a different run state?
//   if(run_state_.flags.current_noop)
//   {
//    rce = current_node_->re_call_entry();
//    if(rce)
//    {
//     CAON_PTR_DEBUG(RE_Call_Entry ,rce)
//     rce = current_node_->re_call_entry();
//     current_call_entry_object_ = rce;
//    }
//    run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//    run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Entry_Indent);
//     //?current_node_ = next_node_;
//   }
//   else
//   if(caon_ptr<RE_Node> n = find_call_entry(*current_node_, rce))
//   {
//    current_call_entry_object_ = rce;
//    run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//    run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Entry_Indent);
//    current_node_ = n;
//    //current_node_ = n;
//    break;
//   }
//  }
//  break;

// case RZ_Read_Table_State::Block_Statement_List_Pre_Entry:
//   // // fallthrough
// case RZ_Read_Table_State::List_Pre_Entry:
//  current_node_ = next_node_;
//  if(caon_ptr<tNode> n = embed_redirect_node())
//  {
//   if(valuer_->embedder()->match_noop_node(n))
//   {
//    run_state_.flags.current_noop = true;
//   }
//   else
//   {
//    CAON_PTR_DEBUG(tNode ,n)
//    embed_branch_nodes_.push(current_node_);
//    current_node_ = n;
//    current_run_plugin_ = new RZ_Embed_Branch_Run_Plugin(*this);
//    run_state_.flags.has_run_plugin = true;
//    run_state_.flags.on_embed_redirect_branch = true;
//   }
//  }
//  run_state_.set_read_table_state(RZ_Read_Table_State::List_Entry);
//  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);

//  break;

// case RZ_Read_Table_State::Lex_Tuple_Pre_Entry:
// {
//  CAON_PTR_DEBUG(RE_Node ,current_node_)
//  CAON_PTR_DEBUG(RE_Node ,next_node_)
//  current_node_ = next_node_;

//  if(caon_ptr<RE_Node> nn = rq_.Run_Data_Entry(current_node_))
//  {
//   CAON_PTR_DEBUG(RE_Node ,nn)
//   next_node_ = nn;
//  }

//  run_state_.set_read_table_state(RZ_Read_Table_State::Lex_Tuple_Entry);
//  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//  break;
// }

// case RZ_Read_Table_State::Lex_Tuple_Entry:
// {
//  CAON_PTR_DEBUG(RE_Node ,current_node_)
//  CAON_PTR_DEBUG(RE_Node ,next_node_)
//  current_node_ = next_node_;
//  run_state_.set_read_table_state(RZ_Read_Table_State::List_Sequence);
//  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//  break;

// }
//  // //?
// case RZ_Read_Table_State::List_Entry:
// case RZ_Read_Table_State::List_Sequence:
//  {
//   bool is_statement_final = false;
//   if(current_call_entry_object_)
//   {
//    is_statement_final = current_call_entry_object_->flags.is_statement_entry;
//   }
//   if(is_statement_final)
//    find_next_token(RZ_Read_Table_State::Statement_Final, RZ_Read_Table_Post_Advance_State::Holds_Token);
//   else
//    find_next_token(RZ_Read_Table_State::List_Final, RZ_Read_Table_Post_Advance_State::Holds_Token);
//  }
//  break;

//// case RZ_Read_Table_State::List_Embed_Sequence:
////  advance_embed_sequence(RZ_Read_Table_State::List_Final, RZ_Read_Table_Post_Advance_State::Holds_Token);

////  read_table_state_ = List_Sequence;

////  if(position_index_ < max_position_index_)
////   ++position_index_;
////  else
////   read_table_state_ = Post_Tokens;
//  break;

// case RZ_Read_Table_State::Block_Pre_Entry:
// {
//  //run_state_.set_read_table_state(RZ_Read_Table_State::Block_Entry);
//  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//  CAON_EVALUATE_DEBUG(tNode ,n1 ,current_node_)
//  find_block_entry();
//  CAON_EVALUATE_DEBUG(tNode ,n2 ,current_node_)
//  CAON_PTR_DEBUG(tNode ,next_node_)
//  break;
// }

// case RZ_Read_Table_State::Cpp_Block_Entry:
// {
//  current_node_ = next_node_;
//  // //?
//  //run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Pre_Entry);


//  //?run_state_.set_read_table_state(RZ_Read_Table_State::Block_Statement_Entry);
//  run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Prepare_Entry);
//  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//  //run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
//  CAON_PTR_DEBUG(tNode ,current_node_)
//  break;
// }

// case RZ_Read_Table_State::Statement_Prepare_Entry:
// {
//  current_node_ = next_node_;
//  // //?
//  //run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Pre_Entry);

//  run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Entry);
//  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//  //run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
//  CAON_PTR_DEBUG(tNode ,current_node_)
//  break;
// }

// case RZ_Read_Table_State::Statement_Entry_Indent:
// {
//  run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Entry);
//  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//  //run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
//  CAON_PTR_DEBUG(tNode ,current_node_)
//  break;
// }
// case RZ_Read_Table_State::Cpp_Redirect_Leave:
//  if(next_node_)
//  {
//   current_node_ = next_node_;
//   CAON_PTR_DEBUG(RE_Node ,next_node_)

//   run_state_.set_read_table_state(RZ_Read_Table_State::Cpp_Redirect_Leave_Block_Pre_Entry);
//   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
//  }
//  else
//  {
//   run_state_.set_read_table_state(RZ_Read_Table_State::Cpp_Redirect_Final);
//  }
//  break;

// case RZ_Read_Table_State::Cpp_Redirect_Leave_Block_Pre_Entry:
//  {
//   CAON_PTR_DEBUG(RE_Node ,current_node_)

//   run_state_.set_read_table_state(RZ_Read_Table_State::Block_Pre_Entry);
//    //????
//    //run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
//    run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//  }
//  break;

// case RZ_Read_Table_State::Statement_End:
//  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//  run_state_.set_read_table_state(RZ_Read_Table_State::Block_End);
//  break;

// case RZ_Read_Table_State::Cpp_Redirect_Final:
// case RZ_Read_Table_State::Statement_Final:

//  //?
//  //?entry_nodes_.pop();
//  {
//   // //   If the last entry node was in tail position,
//   //      set current_call_entry_object_ but not current_node_.
//   CAON_PTR_DEBUG(RE_Call_Entry ,current_call_entry_object_)
//   // //   Note: when generating C++, statement_final does not mandate
//   //      a post-advance holds-token, whereas for Lisp, given List_Final,
//   //      there is still a token being held over.  This is because of
//   //      of when, in the readtable loop, this advance() function is called.
//   //      The R/Z "Semantic Readtable" is read from two different places
//   //      inside Clasp, one to read a single token and one to read a list.
//   reset_call_entry_object(RZ_Read_Table_State::Statement_End, RZ_Read_Table_Post_Advance_State::No_Token,
//    RZ_Read_Table_State::Statement_End, RZ_Read_Table_Post_Advance_State::No_Token);
//  }
//  break;

// case RZ_Read_Table_State::Lexical_Declarations_Leave:
//  {
//   CAON_PTR_DEBUG(RE_Node ,current_node_)
//   if(caon_ptr<RE_Node> entry_node = rq_.Run_Call_Entry(current_node_))
//   {
//    CAON_PTR_DEBUG(RE_Node ,entry_node)
//    next_node_ = entry_node;
//    run_state_.set_read_table_state(RZ_Read_Table_State::Lambda_Block_Statement_Pre_Entry);
//    run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//   }
//   break;
//  }

// case RZ_Read_Table_State::Lambda_Block_Statement_Pre_Entry:
//  {
//   current_node_ = next_node_;
//   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//   run_state_.set_read_table_state(RZ_Read_Table_State::Lambda_Block_Statement_Entry);
//   CAON_PTR_DEBUG(RE_Node ,current_node_)
//   break;
//  }
// case RZ_Read_Table_State::Lambda_Block_Statement_Entry:
//  {
//   CAON_PTR_DEBUG(RE_Call_Entry ,current_call_entry_object_)
//   CAON_PTR_DEBUG(RE_Node ,current_node_)

//   if(caon_ptr<RE_Call_Entry> rce = current_node_->re_call_entry())
//   {
//    CAON_PTR_DEBUG(RE_Call_Entry ,rce)
//    current_call_entry_object_ = rce;
//   }
//   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//   run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Entry_Indent);
//   break;
//  }

// case RZ_Read_Table_State::Block_Pre_Entry_As_Sequence:
//  {
//   CAON_PTR_DEBUG(RE_Call_Entry ,current_call_entry_object_)
//   CAON_PTR_DEBUG(RE_Node ,current_node_)

//   if(caon_ptr<RE_Call_Entry> rce = current_node_->re_call_entry())
//   {
//    CAON_PTR_DEBUG(RE_Call_Entry ,rce)
//    current_call_entry_object_ = rce;
//   }
//   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//   run_state_.set_read_table_state(RZ_Read_Table_State::Block_Statement_Entry);
//   break;
//  }

// case RZ_Read_Table_State::Lexical_Expression_Leave:
//  {
//   break;
//  }

// case RZ_Read_Table_State::List_Final:
////?  read_table_state_ = RZ_Read_Table_State::List_End;

////?
////?  current_node_ = entry_nodes_.top();
//  //?
//  //? entry_nodes_.pop();
//  {
//   // //   If the last entry node was in tail position,
//   //      set current_call_entry_object_ but not current_node_.
//   CAON_PTR_DEBUG(RE_Call_Entry ,current_call_entry_object_)

//   if(run_state_.flags.cpp_mode)
//   {
//    current_lex_iterator_ = nullptr;
//    if(lex_iterators_.contains(current_call_entry_object_))
//    {
//     run_state_.set_read_table_state(RZ_Read_Table_State::Lexical_Expression_Leave);
//     run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//     break;
////     reset_call_entry_object(RZ_Read_Table_State::List_Final, RZ_Read_Table_Post_Advance_State::No_Token,
////      RZ_Read_Table_State::Lexical_Expression_Leave, RZ_Read_Table_Post_Advance_State::No_Token);
//    }
//    else if(caon_ptr<RE_Node> ben = find_block_entry_as_sequence())
//    {
//     CAON_PTR_DEBUG(RE_Node ,ben)
//     next_node_ = ben;
//     current_node_ = ben;
//     run_state_.set_read_table_state(RZ_Read_Table_State::Block_Pre_Entry_As_Sequence);
//     run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//     break;
//    }
//    else
//    {
//     reset_call_entry_object(RZ_Read_Table_State::List_Final, RZ_Read_Table_Post_Advance_State::No_Token,
//      RZ_Read_Table_State::List_End, RZ_Read_Table_Post_Advance_State::No_Token);
//    }

//    if(run_state_.read_table_state() == RZ_Read_Table_State::List_Final)
//     if(current_call_entry_object_)
//      if(current_call_entry_object_->flags.is_statement_entry)
//       run_state_.set_read_table_state(RZ_Read_Table_State::Statement_Final);
//   }
//   else
//   {
//    reset_call_entry_object(RZ_Read_Table_State::List_Final, RZ_Read_Table_Post_Advance_State::Holds_Token,
//     RZ_Read_Table_State::List_End, RZ_Read_Table_Post_Advance_State::No_Token);
//   }

//  }
//  break;
// case RZ_Read_Table_State::List_End:
//  {
//   if(current_call_entry_object_)
//   {
//    CAON_PTR_DEBUG(RE_Call_Entry ,current_call_entry_object_)
//    if(current_node_)
//    {
//     if(current_call_entry_object_->call_depth() > 0)
//      find_continue_token(RZ_Read_Table_State::List_End, RZ_Read_Table_Post_Advance_State::No_Token);
//     else
//      find_continue_token(RZ_Read_Table_State::Graph_End, RZ_Read_Table_Post_Advance_State::Deactivate);
//    }
//    else
//    {
//     reset_call_entry_object(RZ_Read_Table_State::List_Final, RZ_Read_Table_Post_Advance_State::Holds_Token,
//      RZ_Read_Table_State::Graph_End, RZ_Read_Table_Post_Advance_State::Deactivate);
//    }
//   }
//   else
//   {
//    run_state_.set_read_table_state(RZ_Read_Table_State::Graph_End);
//    run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Deactivate);
//   }
//  }
//  break;
// default:
//  break;
// }

// {
//  CAON_PTR_DEBUG(RE_Node ,current_node_)
//  CAON_PTR_DEBUG(RE_Node ,next_node_)

//  if(current_node_)
//   run_state_.flags.current_noop = check_embed_noop(current_node_);

//  if(run_state_.flags.current_noop)
//  {
//   CAON_DEBUG_NOOP
//  }

//  CAON_DEBUG_NOOP
// }
//}
//#endif


//void RZ_Lisp_Graph_Visitor::find_block_entry() //RZ_Read_Table_State state_not_found)
//{
// caon_ptr<RE_Call_Entry> rce;
// if(caon_ptr<RE_Node> n = find_call_entry(*current_node_, rce))
// {
//  CAON_PTR_DEBUG(tNode ,n)
////?  if(run_state_.flags.cpp_mode)
////   run_state_.set_read_table_state(RZ_Read_Table_State::Cpp_Block_Entry);
////  else
////  {
//   run_state_.set_read_table_state(RZ_Read_Table_State::Expression_Pre_Entry);
//   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
////?  }
//  next_node_ = n;
//  current_call_entry_object_ = rce;
//  run_state_.flags.has_run_plugin = false;
//   //run_state_.flags.on_block_entry_branch = false;
// }
//}

//void RZ_Lisp_Graph_Visitor::find_run_entry(RZ_Read_Table_State state_not_found, RZ_Read_Table_Post_Advance_State post_state_not_found)
//{
// current_node_->debug_connections();

// CAON_PTR_DEBUG(RE_Node ,current_node_)

////?
//// if(caon_ptr<tNode> n = rq_.Run_Call_Entry(current_node_))
//// {
////  entry_nodes_.push(n);
////  run_state_.set_read_table_state(RZ_Read_Table_State::List_Pre_Entry);
////  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
////  next_node_ = n;
//// //  Graph_End

//// //  normalize_run_call(start_node, n, rlq_.Run_Call_Entry);
//// }
//// else
// if(caon_ptr<tNode> n = rq_.Run_Block_Entry(current_node_))
// {
//  CAON_PTR_DEBUG(tNode ,n)

//  //?
//  //?entry_nodes_.push(n);

//  //caon_ptr<RE_Call_Entry> rce;

//  //read_table_state_ = RZ_Read_Table_State::Block_Entry;
//  //run_state_.set_block_entry_branch_state(RZ_Block_Entry_Branch_State::Pre_Block);

//  current_node_ = n;
//  current_block_node_ = n;

//  // lexical_scope_iterator_ = RZ_Lisp_Graph_Lexical_Scope::iterator_type(current_lexical_scope_.symbols());
//  if(run_state_.flags.cpp_mode)
//  {
//   find_next_node_from_entry(*n);
//   run_state_.set_read_table_state(RZ_Read_Table_State::File_Entry);
//  }
//  else
//  {
//   run_state_.flags.has_run_plugin = true;
//   current_run_plugin_ = new RZ_Block_Entry_Run_Plugin(*this,
//    RZ_Lisp_Graph_Lexical_Scope::iterator_type(current_lexical_scope_.symbols()));

//   current_run_plugin_->activate();
//  }
// }
// else
// {
//  run_state_.set_read_table_state(state_not_found);
//  run_state_.set_post_advance_state(post_state_not_found);
// }
//}

//void RZ_Lisp_Graph_Visitor::advance_embed_sequence(RZ_Read_Table_State state_not_found, RZ_Read_Table_Post_Advance_State post_state_not_found)
//{
// bool still_on_branch = current_run_plugin_->advance();
// if(!still_on_branch)
// {
//     run_state_.flags.on_embed_redirect_branch = false;
//     run_state_.flags.has_run_plugin = false;
//     current_node_ = embed_branch_nodes_.top();
//     embed_branch_nodes_.pop();
//     run_state_.set_read_table_state(state_not_found);
//     run_state_.set_post_advance_state(post_state_not_found);
// }

//// caon_ptr<RZ_Graph_Embed_Token> rget = current_embed_token();
//// if(rget)
////  rget->advance_arg(current_embed_arg_position_);
//// if(current_embed_arg_position_ == 0)
//// {
////  if(rget->entry_node())
////  {
////   run_state_.flags.on_embed_redirect_branch = false;
////   run_state_.flags.on_embed_redirect_entry = true;
////   run_state_.set_read_table_state(RZ_Read_Table_State::List_Pre_Entry);
////   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
////   current_node_ = rget->entry_node();
////   next_node_ = rget->entry_node();
////  }
////  else
////  {
////   run_state_.flags.on_embed_redirect_branch = false;
////   current_node_ = embed_branch_nodes_.top();
////   embed_branch_nodes_.pop();
////   run_state_.set_read_table_state(state_not_found);
////   run_state_.set_post_advance_state(post_state_not_found);
////  }
//// }
//}


caon_ptr<RZ_Lisp_Graph_Visitor::tNode>
 RZ_Lisp_Graph_Visitor::find_call_entry(const tNode& node, caon_ptr<RE_Call_Entry>& rce)
{
#ifdef NO_CAON
 caon_ptr<RE_Node> pnode = const_cast<caon_ptr<RE_Node> >( &node );
#else
 caon_ptr<RE_Node> pnode = &node;
#endif
 if(rce = node.re_call_entry())
 {
  return rq_.Run_Call_Entry(pnode);
   // //return &node;
 }
 else if(caon_ptr<tNode> next_node = rq_.Run_Call_Entry(pnode))
 {
  return find_call_entry(*next_node, rce);
 }
 return nullptr;
}


caon_ptr<RZ_Lisp_Graph_Visitor::tNode>
 RZ_Lisp_Graph_Visitor::find_data_entry(const tNode& node, caon_ptr<RE_Call_Entry>& rce)
{
 //caon_ptr<RE_Call_Entry> rce1 = rce;
 CAON_PTR_DEBUG(RE_Call_Entry ,rce)

  #ifdef NO_CAON
   caon_ptr<RE_Node> pnode = const_cast<caon_ptr<RE_Node> >( &node );
  #else
   caon_ptr<RE_Node> pnode = &node;
  #endif

 if(rce = node.re_call_entry())
 {
  caon_ptr<tNode> ref = rce->ref_node();
  caon_ptr<tNode> par = rce->parent_entry_node();
  caon_ptr<tNode> sn = rce->self_node();

  CAON_PTR_DEBUG(tNode ,ref)
  CAON_PTR_DEBUG(tNode ,par)
  CAON_PTR_DEBUG(tNode ,sn)

  return rq_.Run_Data_Entry(pnode);
   // //return &node;
 }
 else if(caon_ptr<tNode> next_node = rq_.Run_Call_Entry(pnode))
 {
  return find_data_entry(*next_node, rce);
 }
 return nullptr;
}


caon_ptr<RZ_Lisp_Graph_Visitor::tNode> RZ_Lisp_Graph_Visitor::find_next_token(caon_ptr<tNode> start_node,
 RZ_SRE_Result_State& result_state, bool expression_flag, bool non_sequence)
{
 caon_ptr<tNode> result = nullptr;
 //?caon_ptr<RE_Call_Entry> rce;
 CAON_PTR_DEBUG(tNode ,start_node)
 start_node->debug_connections();
 if(!non_sequence)
 {
  if(result = rq_.Run_Call_Sequence(start_node))
  {
   result_state.read_table_state = RZ_Read_Table_State::Expression_Sequence;
   result_state.advance_token_state = RZ_Read_Table_Advance_Token_State::Token_Loaded;
   result_state.advance_graph_state = RZ_Read_Table_Advance_Graph_State::Call_Sequence;
   return result;
  }
  else if(result = rq_.Run_Call_Entry(start_node))
  {
   if(caon_ptr<RE_Call_Entry> rce = result->re_call_entry())
   {
    CAON_PTR_DEBUG(RE_Call_Entry ,rce)
    result_state.advance_token_state = RZ_Read_Table_Advance_Token_State::Node_Loaded;
    result_state.advance_graph_state = RZ_Read_Table_Advance_Graph_State::Call_Entry;
    if(rce->flags.is_statement_entry)
     result_state.read_table_state = RZ_Read_Table_State::Statement_Pre_Entry;
    else
     result_state.read_table_state = RZ_Read_Table_State::Expression_Pre_Entry;
   }
   return result;
  }
  else if(result = rq_.Run_Data_Entry(start_node))
  {
   result_state.read_table_state = RZ_Read_Table_State::Expression_Sequence;
   result_state.advance_token_state = RZ_Read_Table_Advance_Token_State::Token_Loaded;
   result_state.advance_graph_state = RZ_Read_Table_Advance_Graph_State::Call_Sequence;
   return result;
  }

  else if(result = rq_.Run_Data_Leave(start_node))
  {
   CAON_PTR_DEBUG(RE_Node ,result)
   if(caon_ptr<RE_Tuple_Info> rti = result->re_tuple_info())
   {
    CAON_PTR_DEBUG(RE_Tuple_Info ,rti)
    CAON_DEBUG_NOOP
   }
   return result;
  }

 }
//?
//  else if(result = rq_.Run_Cross_Block(start_node))
//  {
//   if(caon_ptr<RE_Block_Entry> rbe = result->re_block_entry())
//   {
//    CAON_PTR_DEBUG(RE_Block_Entry ,rbe)
//    result_state.advance_token_state = RZ_Read_Table_Advance_Token_State::Node_Loaded;
//    result_state.advance_graph_state = RZ_Read_Table_Advance_Graph_State::Cross_Block;
//    result_state.read_table_state = RZ_Read_Table_State::Block_Pre_Entry;
//   }
//   return result;
//  }
 if(result = rq_.Run_Block_Entry(start_node))
 {
  if(caon_ptr<RE_Block_Entry> rbe = result->re_block_entry())
  {
   CAON_PTR_DEBUG(RE_Block_Entry ,rbe)
   result_state.advance_token_state = RZ_Read_Table_Advance_Token_State::Node_Loaded;
    // //? should this be Cross_Block on non_sequence?
   result_state.advance_graph_state = RZ_Read_Table_Advance_Graph_State::Block_Entry;
   result_state.read_table_state = RZ_Read_Table_State::Block_Pre_Entry;
  }
  return result;
 }
 if(result = rq_.Run_Cross_Sequence(start_node))
 {
  if(caon_ptr<RE_Call_Entry> rce = result->re_call_entry())
  {
   // //  This means cross-entry
   CAON_PTR_DEBUG(RE_Call_Entry ,rce)
   result_state.advance_token_state = RZ_Read_Table_Advance_Token_State::Node_Loaded;
   result_state.advance_graph_state = RZ_Read_Table_Advance_Graph_State::Cross_Entry;
   if(rce->flags.is_statement_entry)
    result_state.read_table_state = RZ_Read_Table_State::Statement_Pre_Entry;
   else
    result_state.read_table_state = RZ_Read_Table_State::Expression_Pre_Entry;
  }
  else
  {
   // //  This means cross-continue
   result_state.advance_token_state = RZ_Read_Table_Advance_Token_State::Token_Loaded;
   result_state.advance_graph_state = RZ_Read_Table_Advance_Graph_State::Cross_Continue;
   result_state.read_table_state = RZ_Read_Table_State::Cross_Pre_Continue;
  }
 }
 else
 {
  start_node->debug_connections();
 }
 return result;
}



//caon_ptr<RZ_Lisp_Graph_Visitor::tNode> RZ_Lisp_Graph_Visitor::find_next_token()
//{
// caon_ptr<tNode> result = nullptr;
// caon_ptr<RE_Call_Entry> rce;
// CAON_PTR_DEBUG(tNode ,current_node_)
// CAON_PTR_DEBUG(tNode ,next_node_)

// current_node_->debug_connections();

// if(result = rq_.Run_Call_Sequence(current_node_))
// {
//  run_state_.set_read_table_state(RZ_Read_Table_State::Expression_Sequence);
//  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
//  set_current_node(result);
// }
// else if(result = find_call_entry(*current_node_, rce)) //rq_.Run_Call_Entry(current_node_))
// {
//  current_call_entry_object_ = rce;
// //?  pre_entry_nodes_.push(current_node_);

//   //?
//   //?entry_nodes_.push(result);

//  run_state_.set_read_table_state(RZ_Read_Table_State::Expression_Pre_Entry);
//  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
//  next_node_ = result;
// }
// else if(result = find_data_entry(*current_node_, rce))
// {
//  current_call_entry_object_ = rce;

//  caon_ptr<tNode> ref = rce->ref_node();
//  caon_ptr<tNode> par = rce->parent_entry_node();

//  CAON_PTR_DEBUG(tNode ,ref)
//  CAON_PTR_DEBUG(tNode ,par)

//  CAON_PTR_DEBUG(tNode ,result)
//  rce->flags.is_data_branch_entry = true;
//  CAON_PTR_DEBUG(RE_Call_Entry ,rce)
//  caon_ptr<RE_Tuple_Info> rti = result->re_tuple_info();
//  CAON_PTR_DEBUG(RE_Tuple_Info ,rti)

//  // //? This should be handled sooner...
//  // rti->set_call_entry_node(current_node_);

//  run_state_.set_read_table_state(RZ_Read_Table_State::Expression_Sequence);
//  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
//  set_current_node(result);
// }
// else if(result = rq_.Run_Data_Sequence(current_node_))
// {
//  CAON_PTR_DEBUG(tNode ,result)
//  run_state_.set_read_table_state(RZ_Read_Table_State::Expression_Sequence);
//  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
//  set_current_node(result);
// }
// else if(data_continue_node_)
// {
//  reset_call_entry_object(run_state_.read_table_state(), run_state_.post_advance_state(),
//   run_state_.read_table_state(), run_state_.post_advance_state());
//  //current_call_entry_object_ =
//  result = data_continue_node_;
//  data_continue_node_ = nullptr;
//  CAON_PTR_DEBUG(tNode ,result)
//  run_state_.set_read_table_state(RZ_Read_Table_State::Expression_Sequence);
//  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//  set_current_node(result);
// }
// else if(result = find_data_leave(*current_node_))
// {
//  CAON_PTR_DEBUG(tNode ,result)
//  result->debug_connections();
//  if(result = rq_.Run_Cross_Sequence(result))
//  {
//   data_continue_node_ = result;
//   //return result;
//  }
//  //current_node_ = result;
//  //current_node_ = rq_.Run_Call_Sequence(ce_node);
//  //return find_next_token(result);
// }

// // //  Look out for the duplicate code ....
// else if(result = rq_.Run_Block_Entry(current_node_))
// {
//  caon_ptr<RE_Block_Entry> rbe = result->re_block_entry();
//  CAON_PTR_DEBUG(RE_Block_Entry ,rbe)
//  run_state_.set_read_table_state(RZ_Read_Table_State::Block_Pre_Entry);
//  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
//  set_current_node(result);
// }
//// {
////  CAON_PTR_DEBUG(RE_Node ,ben)
////  next_node_ = ben;
////  result = ben;
////  run_state_.set_read_table_state(RZ_Read_Table_State::Block_Pre_Entry_As_Sequence);
////  run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::No_Token);
//// }

// return result;
//}


caon_ptr<tNode> RZ_Lisp_Graph_Visitor::find_data_leave(tNode& n)
{
 if(caon_ptr<tNode> dl_node = rq_.Run_Data_Leave(&n) )
 {
  CAON_PTR_DEBUG(tNode ,dl_node)
  CAON_DEBUG_NOOP
  if(caon_ptr<RE_Tuple_Info> rti = dl_node->re_tuple_info())
  {
   CAON_PTR_DEBUG(RE_Tuple_Info ,rti)
   if(caon_ptr<tNode> ce_node = rti->call_entry_node())
   {
    CAON_PTR_DEBUG(tNode ,ce_node)
    //current_node_ = rq_.Run_Call_Sequence(ce_node);
    //return ce_node;
    if(caon_ptr<RE_Tuple_Info> ce_rti = ce_node->re_tuple_info())
    {
     if(caon_ptr<tNode> entry_node = ce_rti->call_entry_node())
     {
      CAON_PTR_DEBUG(tNode ,entry_node)
      return entry_node;
     }
    }
   }
  }
 }
 return nullptr;
}


//void RZ_Lisp_Graph_Visitor::find_next_token(RZ_Read_Table_State state_not_found,
// RZ_Read_Table_Post_Advance_State post_state_not_found)
//{
// if(run_state_.flags.current_noop)
// {
////  run_state_.flags.current_noop = false;
////  run_state_.flags.post_current_noop = true;

//  run_state_.set_read_table_state(state_not_found);
//  run_state_.set_post_advance_state(post_state_not_found);
//  return;
// }
// if(caon_ptr<tNode> n = find_next_token())
// {
//  CAON_PTR_DEBUG(tNode ,n)
//  CAON_PTR_DEBUG(tNode ,current_node_)
//  CAON_PTR_DEBUG(tNode ,next_node_)
//  CAON_DEBUG_NOOP
// }
// else
// {
//  run_state_.set_read_table_state(state_not_found);
//  run_state_.set_post_advance_state(post_state_not_found);
// }
//}
////#endif


caon_ptr<RZ_Lisp_Graph_Visitor::tNode>
  RZ_Lisp_Graph_Visitor::find_do_map_block_continue_node(caon_ptr<tNode> node, caon_ptr<tNode>& call_entry_node_or_parent_node,
  QString& explanation)
{
 CAON_PTR_DEBUG(tNode ,node)
 if(!node)
   return nullptr;
 node->debug_connections();

 //?caon_ptr<tNode> result = rq_.Run_Nested_Do_Map_Block_Entry(node);

 caon_ptr<tNode> result = rq_.Run_Nested_Do_Map_Block_Entry_Rewind(node);

 caon_ptr<RE_Call_Entry> rce = node->re_call_entry();
 CAON_PTR_DEBUG(RE_Call_Entry ,rce)


 if(result)
 {
  CAON_PTR_DEBUG(tNode ,result)
  caon_ptr<tNode> block_entry_node = rq_.Run_Block_Entry(result);
  CAON_PTR_DEBUG(tNode ,block_entry_node)
  if(caon_ptr<tNode> cen = rq_.Run_Call_Entry(result))
  {
   explanation = "Run_Call_Entry";
   call_entry_node_or_parent_node = cen;
  }
 }
 else if(rce)
 {
  if(caon_ptr<tNode> ben = rce->block_entry_node())
  {
   CAON_PTR_DEBUG(tNode ,ben)
   if(caon_ptr<tNode> parent_node = rq_.Parent_Do_Map_Block(ben))
   {
    // // in this case set call_entry_node_or_parent_node
    call_entry_node_or_parent_node = parent_node;
    explanation = "Parent_Do_Map_Block";
   }
   else if(parent_node = rq_.Parent_Block_Map(ben))
   {
    caon_ptr<tNode> cross_node = nullptr;
    CAON_PTR_DEBUG(tNode ,parent_node)
    if(caon_ptr<RE_Block_Entry> rbe = ben->re_block_entry())
    {
     CAON_PTR_DEBUG(RE_Block_Entry ,rbe)
     CAON_DEBUG_NOOP
     if(caon_ptr<tNode> sen = rbe->statement_entry_node())
     {
      CAON_PTR_DEBUG(tNode ,sen)
      CAON_DEBUG_NOOP
      cross_node = rq_.Run_Cross_Sequence(sen);
     }
    }


    if(caon_ptr<RE_Block_Entry> parent_rbe = parent_node->re_block_entry())
    {
     CAON_PTR_DEBUG(RE_Block_Entry ,parent_rbe)
     // //  Definitely rbe->flags.function_definition does not
      //    need to go through the rewind rigamarole.
      //    Definitely rbe->flags.if_block does.
      //    Any other block variants needing this?
     if(parent_rbe->flags.if_block)
     {
      if(cross_node)
      {
       explanation = "Parent_Block_Map__With_Cross";
      }
      else
      {
       explanation = "Parent_Block_Map";
      }
      call_entry_node_or_parent_node = parent_node;
     }
    }
   }
  }
 }
 return result;
}



caon_ptr<RZ_Lisp_Graph_Visitor::tNode>
  RZ_Lisp_Graph_Visitor::find_block_continue_node(caon_ptr<tNode> node, caon_ptr<tNode>& block_entry_node)
{
 CAON_PTR_DEBUG(tNode ,node)
 if(!node)
   return nullptr;
 node->debug_connections();
 caon_ptr<tNode> result = rq_.Run_Nested_Block_Continue(node);
 if(result)
 {
  block_entry_node = rq_.Run_Block_Entry(result);
 }
 return result;
}

caon_ptr<RZ_Lisp_Graph_Visitor::tNode> RZ_Lisp_Graph_Visitor::find_block_continue(caon_ptr<tNode> node)
{
 CAON_PTR_DEBUG(tNode ,node)
 if(!node)
   return nullptr;
 if(caon_ptr<RE_Call_Entry> rce = node->re_call_entry())
 {
  CAON_PTR_DEBUG(RE_Call_Entry ,rce)
  caon_ptr<tNode> ref = rce->ref_node();
  caon_ptr<tNode> par = rce->parent_entry_node();
  caon_ptr<tNode> bl_node = rce->block_entry_node();

  CAON_PTR_DEBUG(tNode ,ref)
  CAON_PTR_DEBUG(tNode ,par)

  if(bl_node)
  {
   CAON_PTR_DEBUG(tNode ,bl_node)
   if(caon_ptr<RE_Block_Entry> rbe = bl_node->re_block_entry())
   {
    CAON_PTR_DEBUG(RE_Block_Entry ,rbe)
    if(caon_ptr<tNode> sen = rbe->statement_entry_node())
    {
     CAON_PTR_DEBUG(tNode ,sen)
     if(caon_ptr<tNode> result = rq_.Run_Cross_Sequence(sen))
     {
      CAON_PTR_DEBUG(tNode ,result)
      return result;
     }
    }
   }  //if(caon_ptr<RE_Call_Entry> rce =
  }
  else if(par)
  {
   if(par != ref)
   {
    if(caon_ptr<RE_Node> next_node = rq_.Run_Cross_Sequence(par))
    {
     CAON_PTR_DEBUG(RE_Node ,next_node)
     return next_node;
    }
   }
  }
 }
 return nullptr;
}


caon_ptr<RZ_Lisp_Graph_Block_Info> RZ_Lisp_Graph_Visitor::current_block_info(caon_ptr<tNode> node)
{
 //CAON_PTR_DEBUG(RE_Block_Entry ,rbe)
 if(node)
 {
  CAON_PTR_DEBUG(RE_Node ,node)
  node->debug_connections();
  if(caon_ptr<tNode> n = rq_.Block_Info(node))
  {
   return n->block_info();
  }
 }
 return nullptr;
}

caon_ptr<tNode> find_block_continue();


QString RZ_Lisp_Graph_Visitor::identify_function(QString name,
 caon_ptr<RZ_Lisp_Graph_Core_Function>& cf)
{
 cf = find_core_function(name);
 if(cf)
 {
  return cf->name();
 }
 // //  If a symbol has only these characters assume it's a function
  //  Escape the dash?
 QRegularExpression rx("[^*<>&+#$@/%=?\\-^]");
 QRegularExpressionMatch rxm = rx.match(name);
 if(rxm.hasMatch())
  return QString();
 else
  return name;
 //return QString();
}


//caon_ptr<RZ_Lisp_Graph_Visitor::tNode> RZ_Lisp_Graph_Visitor::find_block_continue()
//{
// CAON_PTR_DEBUG(tNode ,current_node_)
// if(!current_node_)
//   return nullptr;
// if(caon_ptr<RE_Call_Entry> rce = current_node_->re_call_entry())
// {
//  CAON_PTR_DEBUG(RE_Call_Entry ,rce)
//  caon_ptr<tNode> ref = rce->ref_node();
//  caon_ptr<tNode> par = rce->parent_entry_node();
//  caon_ptr<tNode> bl_node = rce->block_entry_node();

//  CAON_PTR_DEBUG(tNode ,ref)
//  CAON_PTR_DEBUG(tNode ,par)

//  if(bl_node)
//  {
//   CAON_PTR_DEBUG(tNode ,bl_node)
//   if(caon_ptr<RE_Block_Entry> rbe = bl_node->re_block_entry())
//   {
//    CAON_PTR_DEBUG(RE_Block_Entry ,rbe)
//    if(caon_ptr<tNode> sen = rbe->statement_entry_node())
//    {
//     CAON_PTR_DEBUG(tNode ,sen)
//     if(caon_ptr<tNode> result = rq_.Run_Cross_Sequence(sen))
//     {
//      CAON_PTR_DEBUG(tNode ,result)
//      return result;
//     }
//    }
//   }  //if(caon_ptr<RE_Call_Entry> rce =
//  }
//  else if(par)
//  {
//   if(par != ref)
//   {
//    if(caon_ptr<RE_Node> next_node = rq_.Run_Cross_Sequence(par))
//    {
//     CAON_PTR_DEBUG(RE_Node ,next_node)
//     return next_node;
//    }
//   }
//  }
// }
// return nullptr;
//}

//void RZ_Lisp_Graph_Visitor::find_continue_token(RZ_Read_Table_State state_not_found, RZ_Read_Table_Post_Advance_State post_state_not_found)
//{
////?
//// if(caon_ptr<tNode> n = rq_.Run_Continue_Sequence(current_node_))
//// {
////  current_node_ = n;
////  read_table_state_ = RZ_Read_Table_State::List_Sequence;
//// }
//// else

// if(!current_node_)
// {
//  run_state_.set_read_table_state(state_not_found);
//  run_state_.set_post_advance_state(post_state_not_found);
//  return;
// }

////?
//// if(caon_ptr<RE_Call_Entry> rce = current_node_->re_call_entry())
//// {
////  current_call_entry_object_ = rce;
////  if(caon_ptr<tNode> n = find_call_entry(*current_node_, rce))
////  {
////   entry_nodes_.push(n);
////   read_table_state_ = RZ_Read_Table_State::List_Pre_Entry;
////   next_node_ = n;
////  }

//// }
//// //?
//// else

// if(caon_ptr<tNode> n = rq_.Run_Cross_Sequence(current_node_))
// {
//  if(caon_ptr<RE_Call_Entry> rce = n->re_call_entry())
//  {
//   current_call_entry_object_ = rce;
//   run_state_.set_read_table_state(RZ_Read_Table_State::Expression_Pre_Entry);
//   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
//   next_node_ = n;
//  }
//  else
//  {
//   run_state_.set_read_table_state(RZ_Read_Table_State::Expression_Sequence);
//   run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
//   current_node_ = n;
//  }

////  if(caon_ptr<RZ_Lisp_Token> rzt = n->lisp_token())
////  {
////   // //  Check for special tokens (like graph-end)
////   if(rzt->string_value() == "_#")
////   {
////    read_table_state_ = state_not_found;
////    return;
////   }
////  }

////  entry_nodes_.push(n);
////  read_table_state_ = RZ_Read_Table_State::List_Pre_Entry;

//  //??next_node_ = n;
// }
// else
//  run_state_.set_read_table_state(state_not_found);
//}


//void normalize_run_call(caon_ptr<tNode> pre_entry_node, tNode* start_node,
// RE_Connectors& qtok, caon_ptr<tNode>* node_to_change);


caon_ptr<tNode> RZ_Lisp_Graph_Visitor::check_raw_lisp(caon_ptr<tNode> node)
{
 if(caon_ptr<tNode> result = rq_.Raw_Lisp_Paste(node))
 {
  CAON_PTR_DEBUG(tNode ,result)
  return result;
 }
 return nullptr;
}


caon_ptr<tNode> RZ_Lisp_Graph_Visitor::normalize_run_call(tNode& pre_entry_node,
  tNode& start_node, const RE_Connectors& qtok,
  caon_ptr<RE_Call_Entry> current_call_entry,
  caon_ptr<tNode>* node_to_change)
{
 // //  This allows multiple Call_Entry guards to be strung together
 if(caon_ptr<RE_Call_Entry> rce = start_node.re_call_entry())
 {
  CAON_PTR_DEBUG(RE_Call_Entry ,rce)

    // //?
  if(caon_ptr<RE_Node> nn = rq_.Run_Nested_Do_Map_Block_Entry(&start_node))
  {
   normalize_nested_block(&start_node, nn, rq_.Run_Nested_Do_Map_Block_Entry);
  }

  if(rce->flags.no_normalize)
  {
   return nullptr;
  }
  if(caon_ptr<tNode> n = rq_.Run_Call_Entry(&start_node))
  {
   // //  Effectively a loop back to the start of the function
   n = normalize_run_call(start_node, *n, rq_.Run_Call_Entry, rce);
   if(n)
    return n;
   else
    return &start_node;
  }
  else if(n = rq_.Run_Data_Entry(&start_node))
  {
   // //  return &start_node because the holds the
   //     effective "rce" object
   //n =
   normalize_nested_data(start_node, *n, rq_.Run_Data_Entry);
   return &start_node;
  }
  return nullptr;
 }
 caon_ptr<tNode> function_node = &start_node;
 if(caon_ptr<RZ_Lisp_Token> tok = start_node.lisp_token())
 {
  CAON_PTR_DEBUG(RZ_Lisp_Token ,tok)

  //qDebug() << _tok.string_value();

  caon_ptr<RZ_Lisp_Graph_Core_Function> cf;

  QString function_name;

  if(!tok->flags.not_entry)
   function_name = identify_function(tok->literal_string_value(), cf);

  if(tok->flags.is_string_literal)
  {
   // //  Any significance to a string literal which matches
   //     a function name?
   function_node = check_normalize_infix_run_call(pre_entry_node, start_node, qtok);
   if(function_node && node_to_change)
    *node_to_change = function_node;
  }

  else if(function_name.isEmpty())
  {
   function_node = check_normalize_infix_run_call(pre_entry_node, start_node, qtok);
   if(function_node && node_to_change)
    *node_to_change = function_node;
   if(function_node)
   {
    CAON_PTR_DEBUG(tNode ,function_node)
    if(caon_ptr<RE_Token> re_t = function_node->re_token())
    {
     CAON_PTR_DEBUG(RE_Token ,re_t)
     CAON_DEBUG_NOOP
    }
    if(current_call_entry)
    {
     current_call_entry->flags.is_function_expression_entry = true;
     // //    This is for debug only ...
     current_call_entry->set_debug_text_hint(tok->string_value());
    }
   }
  }

  else if(cf)
  {
   CAON_PTR_DEBUG(tNode ,function_node)
   if(caon_ptr<RE_Token> re_t = function_node->re_token())
   {
    CAON_PTR_DEBUG(RE_Token ,re_t)
    CAON_DEBUG_NOOP
   }

   if(tok->flags.is_call_arrow)
   {
    tok->flags.is_nested_opaque_call = true;
   }
   else
   {
    if(current_call_entry)
    {
     current_call_entry->flags.is_function_expression_entry = true;
     // //    This is for debug only ...
     current_call_entry->set_debug_text_hint(function_name);
    }
    tok->flags.is_function_expression_entry = true;
    tok->flags.is_core_function_symbol = true;
    tok->set_value(cf);
    tok->set_type_object(*valuer_->type_variety().get_type_object(RZ_Run_Types::GraphCoreFun));
   }
  }
  else
  {
   tok->flags.is_function_expression_entry = true;
   tok->flags.is_likely_function_symbol = true;
  }
 }
 normalize_nested_run_call(*function_node);
 return nullptr;
}


void RZ_Lisp_Graph_Visitor::pre_interpret(caon_ptr<tNode> start_node)
{
 normalize(*start_node);
 anticipate(*start_node);
}

void RZ_Lisp_Graph_Visitor::normalize()
{
 if(graph_)
 {
  normalize(*graph_->root_node());
 }
}

void RZ_Lisp_Graph_Visitor::anticipate()
{
 if(graph_)
 {
  anticipate(*graph_->root_node());
 }
}


void RZ_Lisp_Graph_Visitor::normalize(tNode& start_node)
{
 if(caon_ptr<tNode> n = rq_.Run_Call_Entry(&start_node))
 {
  normalize_run_call(start_node, *n, rq_.Run_Call_Entry);
 }
 else if(n = rq_.Run_Block_Entry(&start_node))
 {
  normalize_block(start_node, *n, rq_.Run_Block_Entry);
 }
}

caon_ptr<RZ_Lisp_Graph_Visitor::tNode>
 RZ_Lisp_Graph_Visitor::check_normalize_infix_run_call
 (tNode& pre_entry_node, tNode& start_node,
  const RE_Connectors& qtok)
{
 // //   Checks to see if the current expression uses
 //     infix syntax.
 caon_ptr<tNode> current_node;
 if(current_node = rq_.Run_Call_Sequence(&start_node))
 {
  return check_normalize_infix_run_call(pre_entry_node,
   start_node, *current_node, qtok);
 }
 else
 {
  // //  If not, assume the start node is a function symbol
  caon_ptr<RZ_Lisp_Token> tok = start_node.lisp_token();
  CAON_PTR_DEBUG(RZ_Lisp_Token ,tok)
  tok->flags.is_likely_function_symbol = true;
  tok->flags.is_function_expression_entry = true;
  return &start_node;
 }
}



caon_ptr<RZ_Lisp_Graph_Visitor::tNode>
 RZ_Lisp_Graph_Visitor::check_normalize_infix_run_call(tNode& pre_entry_node,
  tNode& start_node, tNode& current_node,
  const RE_Connectors& qtok)
{
 // //  Arguably this function could be called recursively rather than with a loop.
 //     In its current form the loop could potentially just be written in the
 //     two-argument form of normalize_infix_run_call.  However, it seems
 //     clearer to separate the two functions to clarify that current_node
 //     is assumed different from start_node here and also to leave open
 //     the possibility of recursion.

 caon_ptr<tNode> previous_node = &start_node;
 // //  This loop does not allow for a Run_Call_Entry preceding
 //     the function token.
 for(caon_ptr<tNode> n = &current_node; n; n = rq_.Run_Call_Sequence(n))
 {
  if(caon_ptr<RZ_Lisp_Token> tok = n->lisp_token())
  {
   if(tok->flags.is_call_arrow)
   {
    return &start_node;
   }

   caon_ptr<RZ_Lisp_Graph_Core_Function> cf;

   if(tok->raw_text().startsWith(">-"))
   {
    tok->flags.is_function_expression_entry = true;
    tok->flags.is_likely_function_symbol = true;
    swap_function_nodes(pre_entry_node, start_node, *previous_node, *n, qtok);
    return &current_node;
   }

   QString function_name;

   if(!tok->flags.not_entry)
    function_name = identify_function(tok->literal_string_value(), cf);

   if(!function_name.isEmpty())
   {
    if(cf)
    {
     tok->flags.is_infix_operator_entry = true;
     // ok?
     tok->flags.is_function_expression_entry = true;

     tok->flags.is_core_function_symbol = true;
     tok->set_value(cf);
     tok->set_type_object(*valuer_->type_variety().get_type_object(RZ_Run_Types::GraphCoreFun));
    }
    else
    {
     tok->flags.is_infix_operator_entry = true;
     tok->flags.is_function_expression_entry = true;
     tok->flags.is_likely_function_symbol = true;
    }
    CAON_PTR_DEBUG(RZ_Lisp_Token ,tok)

    swap_function_nodes(pre_entry_node, start_node, *previous_node, *n, qtok);
    return &current_node;
   }
   else
   {
    previous_node = n;
   }
  }
 }
 // //   If we're here, it means the start_node is (assumed to be)
 //      a function symbol after all
 caon_ptr<RZ_Lisp_Token> stok = start_node.lisp_token();
 stok->flags.is_function_expression_entry = true;
 stok->flags.is_likely_function_symbol = true;
 return &start_node;
}

void RZ_Lisp_Graph_Visitor::normalize_block(tNode& pre_entry_node,
 tNode& start_node, const RE_Connectors& qtok, caon_ptr<tNode>* node_to_change)
{
 if(caon_ptr<RE_Block_Entry> rbe = start_node.re_block_entry())
 {
  if(caon_ptr<tNode> call_start_node = rq_.Run_Call_Entry(&start_node))
  {
   caon_ptr<tNode> node = normalize_run_call(start_node,
    *call_start_node, qtok, nullptr, node_to_change);
   //caon_ptr<tNode> node = &start_node;
   if(node)
   {
    CAON_PTR_DEBUG(tNode ,node)
    while(caon_ptr<tNode> next_node = rq_.Run_Cross_Sequence(node))
    {
     normalize_run_call(*node, *next_node, rq_.Run_Cross_Sequence, nullptr, &next_node);
     node = next_node;
   //   normalize(next_node);
    }
   }
  }
//  rq_.Run_Call_Entry(&start_node)
//  {

//  }
 }

// normalize_run_call(pre_entry_node, start_node, qtok, node_to_change);
// caon_ptr<tNode> node = &start_node;
// while(caon_ptr<tNode> next_node = rq_.Run_Cross_Sequence(node))
// {
//  normalize_run_call(*node, *next_node, rq_.Run_Cross_Sequence, &next_node);
//  node = next_node;
////   normalize(next_node);
// }

}

caon_ptr<RZ_Lisp_Graph_Core_Function> RZ_Lisp_Graph_Visitor::find_core_function(QString name)
{
 if(core_function_map_.find(name) != core_function_map_.end())
  return core_function_map_[name];
 return nullptr;
}

void RZ_Lisp_Graph_Visitor::swap_function_nodes(tNode& pre_entry_node,
 tNode&  head_node, tNode&  previous_node,
 tNode&  function_node, const RE_Connectors& qtok)
{
 pre_entry_node.swap_relation(qtok, &head_node, &function_node);

 if(caon_ptr<RE_Node> retval_node = rq_.Retval_Follow(&head_node) )
 {
  head_node.delete_relation(rq_.Retval_Follow, retval_node);
  if(retval_node == &function_node)
  {
   &function_node << fr_/rq_.Retval_Follow >> &head_node;
  }
  else
  {
   &function_node << fr_/rq_.Retval_Follow >> retval_node;
  }
 }

 previous_node.delete_relation(rq_.Run_Call_Sequence, &function_node);
 caon_ptr<tNode> next_node;
 if(next_node = rq_.Run_Call_Sequence(&function_node))
 {
  function_node.delete_relation(rq_.Run_Call_Sequence, next_node);
  &previous_node << fr_/rq_.Run_Call_Sequence >> next_node;
 }
 else if(next_node = rq_.Run_Call_Entry(&function_node))
 {
  function_node.delete_relation(rq_.Run_Call_Entry, next_node);
  &previous_node << fr_/rq_.Run_Call_Entry >> next_node;
 }

 if(caon_ptr<tNode> cross_node = rq_.Run_Cross_Sequence(&head_node))
 {
  head_node.delete_relation(rq_.Run_Cross_Sequence, cross_node);
  &function_node << fr_/rq_.Run_Cross_Sequence >> cross_node;
 }
 else if(cross_node = rq_.Run_Block_Entry(&head_node))
 {
  head_node.delete_relation(rq_.Run_Block_Entry, cross_node);
  &function_node << fr_/rq_.Run_Block_Entry >> cross_node;
 }

//?
// if(caon_ptr<tNode> continuation_node = rq_.Run_Continue_Sequence(head_node))
// {
//  head_node->delete_relation(rq_.Run_Continue_Sequence, continuation_node);
//  function_node << fr_/rq_.Run_Continue_Sequence >> continuation_node;
// }

 &function_node << fr_/rq_.Run_Call_Sequence >> &head_node;

}

void RZ_Lisp_Graph_Visitor::normalize_nested_run_call(tNode& function_node)
{
 // //  Check normalize nested calls
 caon_ptr<tNode> previous_node = &function_node;
 while(previous_node)
 {
  CAON_PTR_DEBUG(tNode ,previous_node)
  caon_ptr<tNode> next_node;
  if(next_node = rq_.Khi_Node_Value(previous_node))
  {
   //?   normalize_chi_form(previous_node);
  }
  if(next_node = rq_.Run_Call_Sequence(previous_node))
  {
   previous_node = next_node;
  }
  else if(next_node = rq_.Run_Call_Entry(previous_node))
  {
   normalize_run_call(*previous_node, *next_node, rq_.Run_Call_Entry, nullptr, &next_node);
   previous_node = next_node;
//?
//   if(previous_node = rq_.Run_Continue_Sequence(next_node))
//    ;
//   else
    previous_node = normalize_nested_run_call_continuation(previous_node, next_node);
  }
  else if(next_node = rq_.Run_Block_Entry(previous_node))
  {
   previous_node = normalize_nested_block(previous_node, next_node, rq_.Run_Block_Entry);
  }
  else
   break;
 }
}

caon_ptr<RZ_Lisp_Graph_Visitor::tNode>
 RZ_Lisp_Graph_Visitor::normalize_nested_run_call_continuation(
  caon_ptr<tNode> previous_node, caon_ptr<tNode> function_node)
{
 if(caon_ptr<tNode> next_node = rq_.Run_Cross_Sequence(function_node))
 {
  // //  Because of how Run_Cross_Sequence is used
   //     for both continuations in Lambda4 -- maybe separate them out?
  if(caon_ptr<RE_Call_Entry> rce = next_node->re_call_entry())
  {
   normalize_run_call(*function_node, *next_node, rq_.Run_Cross_Sequence, nullptr, &next_node);
   return normalize_nested_run_call_continuation(function_node, next_node);
  }
  else
  {
   //? // else if(next_node = rq_.Run_Continue_Sequence(function_node))
   return next_node;
  }
 }
//?
// else if(next_node = rq_.Run_Continue_Sequence(function_node))
// {
//  return next_node;
// }
 else if(next_node = rq_.Run_Block_Entry(function_node))
 {
  return normalize_nested_block(function_node, next_node, rq_.Run_Block_Entry);
 }
 else
  return nullptr;
}


QString RZ_Lisp_Graph_Visitor::call_entry_label(caon_ptr<RE_Call_Entry> rce)
{
 if(caon_ptr<RE_Node> n = rce->get_node())
  return call_entry_label(n);
 return QString();
}

QString RZ_Lisp_Graph_Visitor::call_entry_label(caon_ptr<RE_Node> n)
{
 QString result;
 CAON_PTR_DEBUG(RE_Node ,n)
 if(caon_ptr<RE_Node> ln = rq_.Run_Map_Key_Label(n))
 {
  if(caon_ptr<RE_Token> token = ln->re_token())
  {
   result = token->clasp_string_value();
  }
 }
 return result;
}


//normalize_nested_data


//caon_ptr<RZ_Lisp_Graph_Visitor::tNode>
void
 RZ_Lisp_Graph_Visitor::normalize_nested_data(tNode& previous_node,
  tNode&  data_node, const RE_Connectors& qtok)
{
 // //  The task here is to walk through a data structure
 //     normalizing nested calls if there are any.
// CAON_PTR_DEBUG(tNode ,previous_node)
// CAON_PTR_DEBUG(tNode ,data_node)
 if(caon_ptr<RE_Tuple_Info> tinfo = data_node.re_tuple_info())
 {
  CAON_PTR_DEBUG(RE_Tuple_Info ,tinfo)
   //?QString str = _tinfo.lisp_out();
  data_node.debug_connections();
  if(caon_ptr<tNode> start_node = rq_.Run_Data_Entry(&data_node))
  {
   CAON_PTR_DEBUG(RE_Node ,start_node)
   if(caon_ptr<RZ_Lisp_Token> tok = start_node->lisp_token())
   {
    QString str = tok->string_value();
    start_node->debug_connections();
   }
  }
 }
}


caon_ptr<RZ_Lisp_Graph_Visitor::tNode>
 RZ_Lisp_Graph_Visitor::normalize_nested_block(caon_ptr<tNode> previous_node,
  caon_ptr<tNode> function_node, const RE_Connectors& qtok)
{
 normalize_block(*previous_node, *function_node, qtok, &function_node);
 note_block_entry(function_node);

 CAON_PTR_DEBUG(tNode ,function_node)

   function_node->debug_connections();
 // alternative to Run_Cross_Block?
 if(caon_ptr<tNode> en_node = rq_.Run_Cross_Sequence(function_node))
 {
  CAON_PTR_DEBUG(tNode ,en_node)

  if(caon_ptr<RE_Call_Entry> rce = en_node->re_call_entry())
  {
   normalize_run_call(*function_node, *en_node, rq_.Run_Cross_Sequence);
  }
 }
//
// if(caon_ptr<tNode> next_node = rq_.Run_Cross_Block(function_node))
// {
//  //?  return next_node;
// }



//?
// else if(next_node = rq_.Run_Continue_Block(function_node))
// {
//  check_function_symbol(next_node);
//  return next_node;
// }
 return nullptr;
}

void RZ_Lisp_Graph_Visitor::check_function_symbol(caon_ptr<tNode> function_node)
{
 if(caon_ptr<RZ_Lisp_Token> tok = function_node->lisp_token())
 {
//  if(tok->flags.precedes_lara_argument)
//  {
//   return;
//  }
  caon_ptr<RZ_Lisp_Graph_Core_Function> cf;
  identify_function(tok->string_value(), cf);
  if(cf)
  {
   if(tok->flags.is_call_arrow)
   {
    tok->flags.is_nested_opaque_call = true;
   }
   else
   {
    tok->flags.is_core_function_symbol = true;
    tok->set_value(cf);
    set_token_type_object(tok, RZ_Run_Types::GraphCoreFun);
   }
  }
 }
}

void RZ_Lisp_Graph_Visitor::note_block_entry(caon_ptr<tNode> function_node)
{
 CAON_PTR_DEBUG(tNode ,function_node)
 caon_ptr<RZ_Lisp_Graph_Lexical_Scope> s = new RZ_Lisp_Graph_Lexical_Scope;
 caon_ptr<tNode> n = new tNode(s);
 function_node << fr_/rq_.Run_Lexical_Scope >> n;
}

void RZ_Lisp_Graph_Visitor::set_token_type_object(
  caon_ptr<RZ_Lisp_Token> token, RZ_Run_Types::Enum E)
{
 token->set_type_object(*valuer_->type_variety().get_type_object(E));
}

void RZ_Lisp_Graph_Visitor::anticipate(tNode& start_node)
{
 caon_ptr<tNode> n;
 if(n = rq_.Run_Call_Entry(&start_node))
 {
  anticipate_run_call(*n);
 }
 else if(n = rq_.Run_Block_Entry(&start_node))
 {
  anticipate_block(*n);
//?
//  while(n = rq_.Run_Cross_Sequence(n))
//  {
//   anticipate_run_call(*n);
//  }
 }
}



void RZ_Lisp_Graph_Visitor::check_lisp_graph_runner()
{
 if(!lisp_graph_runner_)
 {
  if(valuer_)
  {
   if(!valuer_->embedder())
   {
    valuer_->set_embedder(new RZ_Graph_Run_Embedder(valuer_));
   }
   lisp_graph_runner_ = new RZ_Lisp_Graph_Runner(valuer_);
  }
 }
}

void RZ_Lisp_Graph_Visitor::check_redirect(RZ_Lisp_Graph_Result_Holder& rh, caon_ptr<tNode> n)
{
 if(valuer_->embedder())
 {
  valuer_->embedder()->check_redirect(rh, *n);
 }
}

caon_ptr<tNode> RZ_Lisp_Graph_Visitor::check_type_indicator(caon_ptr<tNode> node)
{
 CAON_PTR_DEBUG(tNode ,node)
 //?node->debug_connections();
 return rq_.Type_Indicator(node);
}


void RZ_Lisp_Graph_Visitor::anticipate_block(tNode& start_node)
{
 if(caon_ptr<RE_Block_Entry> rbe = start_node.re_block_entry())
 {
  //?

  if(rbe->flags.file_default)
  {
   valuer_->enter_new_lexical_scope();
   CAON_PTR_DEBUG(RE_Block_Entry ,rbe)
   rbe->set_lexical_scope(valuer_->current_lexical_scope());
  }


  //?

  caon_ptr<tNode> call_entry_node;
  if(call_entry_node = rq_.Run_Call_Entry(&start_node))
  {
   CAON_PTR_DEBUG(tNode ,call_entry_node)

   anticipate_run_call(*call_entry_node);

   while(call_entry_node = rq_.Run_Cross_Sequence(call_entry_node))
   {
    anticipate_run_call(*call_entry_node);
   }
  }
  if(call_entry_node = rq_.Run_Cross_Sequence(&start_node))
  {
   anticipate_run_call(*call_entry_node);
  }
 }
}

QString RZ_Lisp_Graph_Visitor::type_expression_from_node(caon_ptr<tNode> node)
{
 QString result;

 CAON_PTR_DEBUG(RE_Node ,node)
 node->debug_connections();
 if(caon_ptr<RE_Node> ce_node = rq_.Run_Call_Entry(node))
 {
  CAON_PTR_DEBUG(RE_Node ,ce_node)
  ce_node->debug_connections();
  node = rq_.Run_Cross_Sequence(ce_node);
  CAON_PTR_DEBUG(RE_Node ,node)
  while(node)
  {
   if(caon_ptr<RZ_Lisp_Token> token = node->lisp_token() )
   {
    result += token->raw_text() + " ";
   }
   // //?
//   else if(caon_ptr<RE_Token> re_token = node->re_token())
//   {
//    CAON_PTR_DEBUG(RE_Token ,re_token)
//    result += re_token->raw_text() + " ";
//   }

   node = rq_.Run_Call_Sequence(node);
  }
 }
 if(result.endsWith(' '))
  result.chop(1);
 return result;
}


void RZ_Lisp_Graph_Visitor::check_token_node_type(caon_ptr<RZ_Lisp_Token> tok,
 caon_ptr<tNode> token_node)
{
 CAON_PTR_DEBUG(RZ_Lisp_Token ,tok)
 if(tok)
 {
  if(tok->type_object())
   return;
  valuer_->check_node_type(token_node);

 }

}

caon_ptr<tNode> RZ_Lisp_Graph_Visitor::get_data_entry(caon_ptr<tNode> node)
{
 CAON_PTR_DEBUG(tNode ,node)
 caon_ptr<tNode> result = rq_.Run_Data_Entry(node);
 return result;
}


caon_ptr<tNode> RZ_Lisp_Graph_Visitor::anticipate_run_call(tNode& start_node)
{
 if(caon_ptr<RE_Call_Entry> rce = start_node.re_call_entry())
 {
  CAON_PTR_DEBUG(RE_Call_Entry ,rce)
  if(caon_ptr<tNode> node = rq_.Run_Call_Entry(&start_node))
  {
   if(!rce->flags.no_anticipate)
   {
    anticipate_run_call(*node);
   }

   if(caon_ptr<tNode> block_entry_node = rq_.Run_Nested_Block_Entry(&start_node))
   {
    valuer_->enter_new_lexical_scope();
    if(caon_ptr<RE_Block_Entry> rbe = block_entry_node->re_block_entry())
    {
     CAON_PTR_DEBUG(RE_Block_Entry ,rbe)
     rbe->set_lexical_scope(valuer_->current_lexical_scope());
     {
      CAON_PTR_DEBUG(RE_Block_Entry ,rbe)
      CAON_DEBUG_NOOP
     }
    }

    anticipate_block(*block_entry_node);
    valuer_->leave_lexical_scope();
   }

   return &start_node;

  }
  else
   return nullptr;
 }
 check_lisp_graph_runner();

 RZ_Lisp_Graph_Result_Holder rh(*valuer_);
 caon_ptr<tNode> function_node = &start_node;
 do
 {
  rh.clear_continue_proceed();
  if(rh.arity_node())
   function_node = rh.arity_node();
  if(caon_ptr<RZ_Lisp_Token> tok = function_node->lisp_token())
  {
   CAON_PTR_DEBUG(RZ_Lisp_Token ,tok)
   check_token_node_type(tok, function_node);

   caon_ptr<RZ_Type_Object> rto = tok->vh().type_object();
   CAON_PTR_DEBUG(RZ_Type_Object ,rto)

   RZ_Run_Types::Enum rtc = RZ_Run_Type_Code<RZ::GBuild::RZ_Lisp_Graph_Core_Function>::Value;

   caon_ptr<RZ_Type_Object> vto =  valuer_->type_variety().get_type_object(RZ_Run_Type_Code<RZ_Lisp_Graph_Core_Function>::Value);
   CAON_PTR_DEBUG(RZ_Type_Object ,vto)

   if(tok->type_object() ==
    valuer_->type_variety().get_type_object(RZ_Run_Type_Code<RZ_Lisp_Graph_Core_Function>::Value))
   {
    caon_ptr<RZ_Lisp_Graph_Core_Function> cf =
     tok->pRestore<RZ_Lisp_Graph_Core_Function>();
    CAON_PTR_DEBUG(RZ_Lisp_Graph_Core_Function ,cf)
   }


   caon_ptr<RZ_Lisp_Graph_Core_Function> cf =
     tok->pRestore<RZ_Lisp_Graph_Core_Function>(valuer_->type_variety());

   if(cf)
   {
    lisp_graph_runner_->check_run_info(rh, *cf, *function_node);
    check_redirect(rh, function_node);
    if(rh.flags.proceed_anticipate_nested_run_call)
    {
     anticipate_nested_run_calls(start_node, rh);
     rh.flags.proceed_anticipate_nested_run_call = false;
    }
    else if(cf->flags.defer)
      anticipate_nested_run_calls(start_node, rh);
   }
   else if(rh.flags.continue_proceed)
   {
    // // This means that a series of tokens
    //   is revealed to be a continuation function call.
    cf = normalize_continue_run_call(rh.pass_node(), tok, function_node);
    if(cf)
    {
     rh.flags.continue_proceed = false;
     lisp_graph_runner_->check_run_info(rh, *cf, *function_node);
    }
   }
   else
   {
    anticipate_nested_run_calls(start_node, rh);
    rh.flags.continue_proceed = false;
   }
  }
 }
 while(rh.flags.continue_proceed);
 return nullptr;
}


void RZ_Lisp_Graph_Visitor::anticipate_nested_run_calls(tNode& start_node,
  RZ_Lisp_Graph_Result_Holder& rh)
{
 caon_ptr<tNode> n;
 if(n = rq_.Run_Call_Entry(&start_node))
 {
  CAON_PTR_DEBUG(tNode ,n)
  anticipate_run_call(*n);

  //? will this miss some nested?
//  if(rh.flags.skip_init_do_block)
//  {
//   rh.flags.skip_init_do_block = false;
//  }
//  else
//  {
    //????? anticipate_nested_run_calls(*n, rh);
//?  }
 }
 if(n = rq_.Run_Call_Sequence(&start_node))
 {
  CAON_PTR_DEBUG(tNode ,n)
  anticipate_nested_run_calls(*n, rh);
 }
 if(n = rq_.Run_Cross_Sequence(&start_node))
 {
  anticipate_nested_run_calls(*n, rh);
 }

 if(n = rq_.Run_Block_Entry(&start_node))
 {
  anticipate_run_call(*n);
 }
 else if(n = rq_.Run_Cross_Block(&start_node))
 {
  anticipate_run_call(*n);
 }
//?
// else if(n = rq_.Run_Continue_Block(start_node))
// {
//  anticipate_run_call(n);
// }
}

//normalize_block(start_node, *n, rq_.Run_Block_Entry);


caon_ptr<RZ_Lisp_Graph_Core_Function> RZ_Lisp_Graph_Visitor::normalize_continue_run_call
 (caon_ptr<tNode> pass_node, caon_ptr<RZ_Lisp_Token> tok, caon_ptr<tNode> function_node)
{
 caon_ptr<RZ_Lisp_Graph_Core_Function> cf;
 identify_function(tok->string_value(), cf);
 if(cf)
 {
  tok->flags.is_core_function_symbol = true;
  tok->set_value(cf);
 }
 return cf;
}


// //// //  from find_next_token
//else if(run_state_.flags.on_embed_redirect_branch)
//{
// current_run_plugin_->find_next_token(state_not_found, post_state_not_found);
//}
//else if(run_state_.flags.on_embed_redirect_entry)
//{
// run_state_.flags.on_embed_redirect_entry = false;
// run_state_.flags.on_embed_redirect_leave = true;
// run_state_.set_read_table_state(RZ_Read_Table_State::List_Final);
// run_state_.set_post_advance_state(RZ_Read_Table_Post_Advance_State::Holds_Token);
// next_node_ = embed_branch_nodes_.top();
// current_node_ = embed_branch_nodes_.top();
// embed_branch_nodes_.pop();
//}
