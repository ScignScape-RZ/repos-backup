
#include "rz-web-build-file-stack.h"
#include "rz-web-build-file.h"

#include "rzns.h"

USING_RZNS(RECore)

RZ_Web_Build_File_Stack::RZ_Web_Build_File_Stack() //QString path_type, QString file_type)
 : partials_count_(0) //, path_type_(path_type), file_type_(file_type)
{}


void RZ_Web_Build_File_Stack::write(QString& str, QString& raws_str)
{
 QListIterator<QString> it(files_);
 while(it.hasNext())
 {
  QString s = it.next();
  RZ_Web_Build_File f(s, path_type_, file_type_);
  f.write(str, raws_str, partials_count_, partials_map_);
 }
}



