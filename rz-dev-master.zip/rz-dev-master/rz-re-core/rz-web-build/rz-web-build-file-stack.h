
#ifndef RZ_WEB_BUILD_FILE_STACK__H
#define RZ_WEB_BUILD_FILE_STACK__H

#include "accessors.h"

#include <QList>
#include <QStringList>
#include <QMap>

#include "rzns.h"


RZNS_(RECore)

class RZ_Web_Build_File_Stack
{
 QStringList files_;

 int partials_count_;
 QMap<QString, int> partials_map_;

 QString path_type_;
 QString file_type_;

public:

 ACCESSORS__RGET(QStringList ,files)

 ACCESSORS(QString ,path_type)
 ACCESSORS(QString ,file_type)

 RZ_Web_Build_File_Stack(); //QString path_type, QString file_type);

 void write(QString& str, QString& raws_str);
// void write(QString& str);

};

_RZNS(RECore)

#endif
