
#include "rz-web-build-file.h"

#include <QFile>
#include <QFileInfo>
#include <QRegExp>
#include <QStringListIterator>

#include "rzns.h"
USING_RZNS(RECore)

//#define WEB_FILE_JAVA_CLASS_NAME "SCS_Web_File"

RZ_Web_Build_File::RZ_Web_Build_File(QString path, QString file_type, QString path_type)
 : Flags(0), path_(path), file_type_(file_type), path_type_(path_type)
{}

void RZ_Web_Build_File::write(QString& str, QString& raws_str, int& partials_count,
  QMap<QString, int>& partials_map)
{
 QFile infile(path_);
 QString contents;
 if(!infile.open(QIODevice::ReadOnly | QIODevice::Text))
  return;
 contents = infile.readAll();
 infile.close();
 QString key;

 QFileInfo fi(path_);

 if(fi.suffix() == "kf")
 {
  flags.is_raw = true;
  key = QString("/") + fi.fileName();
 }

 else if(fi.suffix() == "ngml")
 {
  flags.is_raw = true;
  key = QString("/") + fi.fileName();
 }

 else
 {
  QRegExp rx("<!--\\s*C\\+\\+");
  int index = contents.indexOf(rx);

  if(index == -1)
  {
   key = QString("/") + fi.fileName();
   if(key.endsWith("txt"))
   key.replace(".", "_");
  }
  else
  {
   QString cap = rx.cap();
   int eol_index = contents.indexOf("\n", index);
   key =  contents.mid(index + cap.length(),
    eol_index - index - cap.length());
   key.replace("-->", "");
   key = key.trimmed();
   QStringList strs = key.split(QRegExp("\\s+"));
   key = strs[0];
   QString role_code;
   if(strs.size() > 1)
    role_code = strs[1];
   parse_role_code(role_code);
   contents.replace(index, eol_index, "");
  }
 }
 if(flags.is_raw)
  write_raw(raws_str, key, contents);
 else if(flags.is_partial)
  write_partial(str, key, partials_count, partials_map, contents);
 else
  write_non_partial(str, key, partials_count, partials_map, contents);
// check_partials(contents);

}

void RZ_Web_Build_File::write_partial(QString& str, QString key, int& partials_count,
  QMap<QString, int>& partials_map, QString contents)
{
 ++partials_count;
 QString mapkey = key.mid(1);
 partials_map[mapkey] = partials_count;
 str += "\n  // Init a new partial string";
 //str += "\n  String partial_" + QString::number(partials_count) + ';';
 str += "\n// load " + path_;
 str += "\nss << R\"(";

 QStringList sl = contents.split("\n");
 QStringListIterator it(sl);
 while(it.hasNext())
 {
  QString line = it.next();
  write_line(str, line, partials_map);
 }
 str += "\n)\";";
 str += "\nstd::string partial_" + QString::number(partials_count) + " = ss.str();";
 // str += "\nadd_file(Static_Web_File_Path(\"" + key +
 //   "\"), new Static_Web_File(\"" + path_ + "\", ss.str()));";
 str += "\nss.str(\"\"); ss.clear();";
 str += "\n // finished " + path_;
// str += "\n   " + file_type_ + " f = new " WEB_FILE_JAVA_CLASS_NAME "(sb.toString());";
// str += mark_file_flags("\n   ", "f.flags");
// str += "\n   result.put(key, f);";
// str += "\n   // Now set the partial string";
// str += "\n   partial_" + QString::number(partials_count) + " = sb.toString();";
// str += "\n  } // finished " + path_;
}

void RZ_Web_Build_File::write_raw_line(QString& str, QString line)
{
 str += "\n   sb.append(\"\\n" + line + "\");";
}

void RZ_Web_Build_File::write_line(QString& str, QString line, QMap<QString, int>& partials_map)
{
 if(flags.is_raw)
 {
  str += "\n" + line;
  return;
 }
 QRegExp rx("^\\s*@@([^@]\\S*)");
 if(line.indexOf(rx) == 0)
 {
  QString key = rx.cap(1);
  QChar follow = 0;
  if(!key.isEmpty())
  {
   QChar c = key[key.length() - 1];
   switch(c.toLatin1())
   {
   case '.':
   case ',':
   case ':':
   case ';':
    follow = c;
    key.chop(1);
    break;
   default: break;
   }
  }
  if(partials_map.contains(key))
  {
   if(follow != 0)
   {
    str += "\n)\"<< load_partial(partial_"
      + QString::number(partials_map[key])
      + ", '" + QString(follow) + ")<< R\"(";
   }
   else
   {
    str += "\n)\"<< load_partial(partial_"
      + QString::number(partials_map[key]) + ")<< R\"(";
//    str += "\n   load_partial(sb, partial_" +
//     QString::number(partials_map[key]) + ");";
   }
  }
  else
  {
//   if(follow != 0)
//   {
//    str += "\n   load_partial_file(sb, \"" + key + "\");";
//   }
//   else
//   {
//    str += "\n   load_partial_file(sb, \"" + key + "\", '"
//     + QString(follow) + "');";
//   }
  }
 }
 else
 {
  line.replace("#{", "<span class='ccaps'>");
  line.replace("}#", "</span>");

  line.replace("\\", "\\\\");
  line.replace("\"", "\\\"");
  str += "\n" + line;
 }
}


void RZ_Web_Build_File::write_non_partial(QString& str, QString key, int& partials_count,
  QMap<QString, int>& partials_map, QString contents)
{
 str += "\n// load " + path_;
 str += "\nss << R\"(";
 //str += "\n String key = \"" + key + "\";";

 QStringList sl = contents.split("\n");
 QStringListIterator it(sl);
 while(it.hasNext())
 {
  QString line = it.next();
  write_line(str, line, partials_map);
 }
 str += "\n)\";";
 str += "\nadd_file(Static_Web_File_Path(\"" + key +
   "\"), new Static_Web_File(\"" + path_ + "\", ss.str()));";
 str += "\nss.str(\"\"); ss.clear();";
 str += "\n // finished " + path_;
}

void RZ_Web_Build_File::write_raw(QString& str, QString key, QString contents)
{
 str += "\n  { // load " + path_;
 str += "\n   StringBuffer sb = new StringBuffer();";
 str += "\n   String key = \"" + key + "\";";

 QStringList sl = contents.split("\n");
 QStringListIterator it(sl);
 while(it.hasNext())
 {
  QString line = it.next();
  write_raw_line(str, line);
 }
 str += "\n)\";";
 str += "\nadd_file(Static_Web_File_Path(\"" + key +
   "\"), new Static_Web_File(\"" + path_ + "\", ss.str()));";
 str += "\nss.str(\"\"); ss.clear();";
 str += "\n // finished " + path_;
}

QString RZ_Web_Build_File::mark_file_flags(QString line_intro, QString var_name)
{
 QString result;
 if(flags.is_static)
  result += line_intro + var_name + ".set_static();";
 if(flags.is_template)
  result += line_intro + var_name + ".set_template();";
 if(flags.is_partial)
  result += line_intro + var_name + ".set_partial();";
 return result;
}

void RZ_Web_Build_File::parse_role_code(QString str)
{
 if(str.contains('s'))
 {
  flags.is_static = true;
 }
 if(str.contains('t'))
 {
  flags.is_template = true;
 }
 if(str.contains('p'))
 {
  flags.is_partial = true;
 }
}



