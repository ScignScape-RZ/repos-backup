
#ifndef RZ_WEB_BUILD_FILE__H
#define RZ_WEB_BUILD_FILE__H

#include "accessors.h"

#include "flags.h"

#include <QString>
#include <QMap>

#include "rzns.h"


RZNS_(RECore)


class RZ_Web_Build_File
{
public:

 flags_(1)
  bool is_static:1;
  bool is_template:1;
  bool is_partial:1;
  bool is_raw:1;
 _flags

private:

 QString path_;
 QString file_type_;
 QString path_type_;

 void parse_role_code(QString str);
 QString mark_file_flags(QString line_intro, QString var_name);

// RZ_Web_Build_File_Stack* file_stack_;


public:

 ACCESSORS(QString ,path)

 RZ_Web_Build_File(QString path, QString file_type, QString path_type);

 void write_line(QString& str, QString line, QMap<QString, int>& partials_map);
 void write_raw_line(QString& str, QString line);


 void write(QString& str, QString& raws_str, int& partials_count,
  QMap<QString, int>& partials_map);

 void write_partial(QString& str, QString key, int& partials_count,
  QMap<QString, int>& partials_map, QString contents);

 void write_non_partial(QString& str, QString key, int& partials_count,
  QMap<QString, int>& partials_map, QString contents);

 void write_raw(QString& str, QString key, QString contents);

};

_RZNS(RECore)

#endif
