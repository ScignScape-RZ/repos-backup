
#include "rz-web-build-pattern.h"

#include <QStringList>

#include "rzns.h"
USING_RZNS(RECore)


RZ_Web_Build_Pattern::RZ_Web_Build_Pattern(QString line)
{
 QStringList strs = line.split(QRegExp("\\s+|(\\s*->\\s*)"), QString::SkipEmptyParts);
 request_method_ = strs[0];
 source_pattern_ = strs[1];
 target_pattern_ = strs[2];
}

