
#ifndef RZ_WEB_BUILD_PATTERN__H
#define RZ_WEB_BUILD_PATTERN__H

#include "accessors.h"

#include <QString>

#include "rzns.h"


RZNS_(RECore)

class RZ_Web_Build_Pattern
{
 QString request_method_;
 QString source_pattern_;
 QString target_pattern_;

public:

 ACCESSORS(QString ,request_method)
 ACCESSORS(QString ,source_pattern)
 ACCESSORS(QString ,target_pattern)

 explicit RZ_Web_Build_Pattern(QString line);

};

_RZNS(RECore)

#endif
