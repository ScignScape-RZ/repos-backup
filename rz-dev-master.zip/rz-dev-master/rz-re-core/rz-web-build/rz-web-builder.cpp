
#include "rz-web-builder.h"

#include <QFile>
#include <QRegularExpression>
#include <QStringListIterator>
#include <QListIterator>



USING_RZNS(RECore)

RZ_Web_Builder::RZ_Web_Builder()
{

}


RZ_Web_Builder::RZ_Web_Builder(QString path)
{
 QString contents = read_file(path);
 QRegExp rx("(\\w+)\\s+(\\S+)");
 int pos = 0;
 while ((pos = rx.indexIn(contents, pos)) != -1)
 {
  pos += rx.matchedLength();
  register_file(rx.cap(1), rx.cap(2));
 }
}


void RZ_Web_Builder::set_files(QString file_list)
{
 QStringList fs = file_list.split(QRegularExpression("\\n\\s*"), QString::SkipEmptyParts);
 files_.files().append(fs);
}

void RZ_Web_Builder::set_patterns(QString pattern_list)
{
 QStringList ps = pattern_list.split(QRegularExpression("\\n\\s*"), QString::SkipEmptyParts);
 QStringListIterator it(ps);
 while(it.hasNext())
 {
  QString s = it.next();
  patterns_.append(RZ_Web_Build_Pattern(s));
 }
}


QString RZ_Web_Builder::read_file(QString path)
{
 QFile infile(path);
 QString result;
 if(!infile.open(QIODevice::ReadOnly | QIODevice::Text))
  return "";
 result = infile.readAll();
 infile.close();
 return result;
}

// //   This is for using different files to maintain the list of info
void RZ_Web_Builder::register_file(QString role, QString location)
{
 if(!location.contains('.'))
 {
  location += ".txt";
 }
 if(role == "patterns")
 {
  QString p = read_file(location);
  QStringList ps = p.split("\n", QString::SkipEmptyParts);
  QStringListIterator it(ps);
  while(it.hasNext())
  {
   QString s = it.next();
   patterns_.append(RZ_Web_Build_Pattern(s));
  }
 }
 else if(role == "files")
 {
  QString f = read_file(location);
  files_.files() = f.split("\n", QString::SkipEmptyParts);
 }
 else if(role == "target")
 {
  target_ = location;
 }
 else if(role == "file-type")
 {
  files_.set_file_type(location);
 }
 else if(role == "path-type")
 {
  files_.set_path_type(location);
 }
 else if(role == "raws")
 {
  raws_target_ = location;
 }
}

void RZ_Web_Builder::generate()
{
 QFile infile(target_);
 QString contents;
 if(!infile.open(QIODevice::ReadOnly | QIODevice::Text))
  return;
 contents = infile.readAll();
 infile.close();

 QFile raws_infile(raws_target_);
 QString raws_contents;
 if(!raws_infile.open(QIODevice::ReadOnly | QIODevice::Text))
  return;
 raws_contents = raws_infile.readAll();
 raws_infile.close();


 int index1 = contents.indexOf("//C++_");
 int eol_index1 = contents.indexOf("\n", index1);

 int e_index1 = contents.indexOf("//_C++", eol_index1);

 if(e_index1 == -1)
  e_index1 = eol_index1;
 else
  e_index1 += 6; // length of "//_C++"

 QString rep = "//C++_";

 QListIterator<RZ_Web_Build_Pattern> it(patterns_);
 while(it.hasNext())
 {
  const RZ_Web_Build_Pattern& pat = it.next();
  rep += QString("\npaths_.insert({\"%1 %2\", \"%3\"});")
    .arg(pat.request_method())
    .arg(pat.source_pattern())
    .arg(pat.target_pattern());
 }
 rep += "\n//_C++";

 contents.replace(index1, e_index1 - index1, rep);

 int index2 = contents.indexOf("//C++_", e_index1);
 int eol_index2 = contents.indexOf("\n", index2);

 int e_index2 = contents.indexOf("//_C++", eol_index2);

 if(e_index2 == -1)
  e_index2 = eol_index2;
 else
  e_index2 += 6; // length of "//_C++"

 int raws_index = raws_contents.indexOf("//C++_");
 int raws_eol_index = raws_contents.indexOf("\n", raws_index);

 int e_raws_index = raws_contents.indexOf("//_C++", raws_eol_index);
 if(e_raws_index == -1)
  e_raws_index = raws_eol_index;
 else
  e_raws_index += 6; // length of "//_C++"

 QString raws_rep = "//C++_";

 rep = "//C++_";
 files_.write(rep, raws_rep);
 rep += "\n  //_C++";

 raws_rep += "\n  //_C++";

 contents.replace(index2, e_index2 - index2, rep);
 raws_contents.replace(raws_index, e_raws_index - raws_index, raws_rep);

// int index3 = contents.indexOf("//C++_", e_index2);
// int eol_index3 = contents.indexOf("\n", index3);

// int e_index3 = contents.indexOf("//_C++", eol_index3);

// if(e_index3 == -1)
//  e_index3 = eol_index3;
// else
//  e_index3 += 6; // length of "//_C++"

// rep = "//C++_";
// files_.write_files(rep);
// rep += "\n  //_C++";

// contents.replace(index3, e_index3 - index3, rep);


 if(!infile.open(QIODevice::WriteOnly | QIODevice::Text))
  return;

 infile.write(contents.toLatin1());
// contents.replace(index, eol_index - index, rep);

 infile.close();

 if(!raws_infile.open(QIODevice::WriteOnly | QIODevice::Text))
  return;

 raws_infile.write(raws_contents.toLatin1());
// contents.replace(index, eol_index - index, rep);

 raws_infile.close();

}
