
#ifndef RZ_WEB_BUILDER__H
#define RZ_WEB_BUILDER__H

#include "accessors.h"

#include "rz-web-build-file-stack.h"

#include <QString>

#include <QList>

#include "rz-web-build-pattern.h"

#include "accessors.h"

#include "rzns.h"


RZNS_(RECore)


class RZ_Web_Builder
{
// QString path_;
 RZ_Web_Build_File_Stack files_;

 QList<RZ_Web_Build_Pattern> patterns_;
 QString target_;
 QString raws_target_;
 QString file_type_;
 QString path_type_;

 void register_file(QString role, QString location);

 QString read_file(QString path);

public:

 RZ_Web_Builder(QString path);
 RZ_Web_Builder();

 ACCESSORS(QString ,target)
 ACCESSORS(QString ,raws_target)
 ACCESSORS(QString ,file_type)
 ACCESSORS(QString ,path_type)


 void set_files(QString file_list);
 void set_patterns(QString pattern_list);

 void generate();


// void write(QString& str);
};

_RZNS(RECore)


#endif
