
#include "rz-text-punctuation.h"

USING_RZNS(Text)


RZ_Text_Punctuation::RZ_Text_Punctuation(QString raw_text)
 : basic_symbol_(identify_symbol(raw_text))
{
 if(basic_symbol_ == Basic_Symbols::N_A)
 {
  basic_symbol_ = Basic_Symbols::Non_Standard;
  raw_text_ = raw_text;
 }
}


QString RZ_Text_Punctuation::get_raw_text()
{
 switch(basic_symbol_)
 {
 default: return QString();

 case Basic_Symbols::Period:
  return ".";

 case Basic_Symbols::Question_Mark:
  return "?";

 case Basic_Symbols::Exclamation_Point:
  return "!";
 }

}

bool RZ_Text_Punctuation::marks_sentence_end()
{
 switch(basic_symbol_)
 {
 default: return false;

 case Basic_Symbols::Period:
 case Basic_Symbols::Question_Mark:
 case Basic_Symbols::Exclamation_Point:
  return true;
 }
}


