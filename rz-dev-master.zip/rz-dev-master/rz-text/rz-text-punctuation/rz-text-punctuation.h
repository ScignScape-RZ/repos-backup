
#ifndef RZ_TEXT_PUNCTUATION__H
#define RZ_TEXT_PUNCTUATION__H

#include "rzns.h"

#include <functional>

#include <QString>

#include <QMap>
#include <QVector>

#include "accessors.h"


RZNS_(Text)



class RZ_Text_Punctuation
{
public:

 enum class Basic_Symbols {
  N_A, Non_Standard, Period, Question_Mark, Exclamation_Point
 };

 static Basic_Symbols identify_symbol(QString key)
 {
  static QMap<QString, Basic_Symbols> static_map {{
    { ".", Basic_Symbols::Period },
    { "!", Basic_Symbols::Exclamation_Point },
    { "?", Basic_Symbols::Question_Mark },

                                          }};

  return static_map.value(key, Basic_Symbols::N_A);
 }

private:


 Basic_Symbols basic_symbol_;

 QString raw_text_;

public:

 RZ_Text_Punctuation(QString raw_text);

 QString get_raw_text();

 bool marks_sentence_end();


};

_RZNS(Chat)



#endif

