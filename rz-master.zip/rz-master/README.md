# R/Z  Preliminaries

R/Z provides a high-level syntax for Lisp and allows preprocessing during Lisp generation to support, in particular, Lisp/C++ integration.  R/Z is designed in combination with the "ScignScape" libraries using the "RelaeGraph" parsing framewowk, and may hopefully be used to script tasks for managing ScignScape web sites.   

While some non-trivial code has been developed in R/Z, the project is not really ready for publication.  This repository for now however provides a few root-level files for use by other parts of ScignScape.


