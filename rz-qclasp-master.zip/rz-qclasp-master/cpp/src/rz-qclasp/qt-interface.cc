/*   COPYRIGHT NOTICE FROM CLASP  */

/*
Copyright (c) 2014, Christian E. Schafmeister
 
CLASP is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.
 
See directory 'clasp/licenses' for full details.
 
The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/
/* -^- */


/*   This file is adapted from Clasp as an example of how Qt can be used 
 *   in functions include in the Clasp core, so callbacks to a Qt environment 
 *   can be directly available in Clasp/Lisp code.
 */


#define DEBUG_LEVEL_FULL
//#include "core/foundation.h"
#include <clasp/core/common.h>
#include <clasp/core/corePackage.h>
#include <clasp/core/evaluator.h>
#include <clasp/core/iterator.h>
#include <clasp/core/metaClass.h>
#include <clasp/core/array.h>
#include <clasp/core/symbolTable.h>
#include <clasp/core/hashTable.h>
#include <clasp/core/specialForm.h>
//#i n c l u d e "setfExpander.h"
#include <clasp/core/environment.h>
#include <clasp/core/designators.h>
#include <clasp/core/builtInClass.h>
#include <clasp/core/lambdaListHandler.h>
#include <clasp/core/vectorObjects.h>
#include <clasp/core/predicates.h>
#include <clasp/core/standardClass.h>
#include <clasp/core/standardObject.h>
#include <clasp/core/predicates.h>
#include <clasp/core/lisp.h>
#include <clasp/core/backquote.h>
#include <clasp/core/sysprop.h>
#include <clasp/core/hashTableEq.h>
#include <clasp/core/conditions.h>
#include <clasp/core/multipleValues.h>
#include <clasp/core/primitives.h>
//#include "debugger.h"
#include <clasp/core/str.h>
#include <clasp/core/wrappers.h>

#include <clasp/core/cons.h>
#include <clasp/core/lispList.h>


#ifdef RZ_QCLASP

#include <clasp/core/qt-foreign-data.h>
#include <QString>
#include <QDebug>

#endif //RZ_QCLASP


#include <functional>

namespace core {

CL_LAMBDA();
CL_DECLARE();
CL_DOCSTRING("qtest");
CL_DEFUN core::T_sp core__qtest()
{
#ifdef RZ_QCLASP

 qDebug() << "Qt OK!";
 
#endif // RZ_QCLASP

 return _Nil<T_O>();
}




CL_LAMBDA(name arg);
CL_DECLARE();
CL_DOCSTRING("qDefun");
CL_DEFUN core::T_sp core__qDefun(T_sp name, T_sp arg)
{
 Str_sp name_str = name.asOrNull<Str_O>();
 if(name.nilp())
 {
  qDebug() << "Bad name...";
  return T_mv();
 }
 std::string name_string = name_str->get();
 Function_sp fun = arg.asOrNull<Function_O>();
 if(fun.nilp())
 {
  qDebug() << "Failed to eval function...";
  return T_mv();
 }
 core::Symbol_sp sym = core::lispify_intern(name_string, "CORE"); //?
 std::string sym_str = sym->fullName();
 sym->setf_symbolFunction(fun);
 return Values(fun);
}

CL_LAMBDA(&rest arguments);
CL_DECLARE();
CL_DOCSTRING("qCreate");
CL_DEFUN core::T_sp core__qCreate(core::List_sp arguments)
{
#ifdef RZ_QCLASP

 typedef std::function<void(void**, QString, void*)> fn_type;
 fn_type* fn = reinterpret_cast<fn_type*>(_lisp->rzq_callback());

 core::QtForeignData_sp qtf = QtForeignData_O::allocateQtForeignObject();
 core::Cons_sp _xargs = core::Cons_O::create(qtf, arguments.asCons());
 
 core::QtForeignData_sp qtf1 = _xargs->ocar();
 core::List_sp xargs = core::coerce_to_list(_xargs);
 
 core::QtForeignData_sp qtf2 = oCar(xargs);
 void* result = 0;
 QString n = ":MAKE-OBJECT";
 (*fn)(&result, n, &xargs);
 return qtf;

#else 
 return _Nil<T_O>();
#endif// RZ_QCLASP
 
}


CL_LAMBDA(name &rest argmnts);
CL_DECLARE();
CL_DOCSTRING("qCallback");
CL_DEFUN core::T_sp core__qCallback(core::Symbol_sp name, core::List_sp argmnts)
{
#ifdef RZ_QCLASP
    
 T_sp result = _Nil<T_O>();
 void** pr = reinterpret_cast<void**>(&result);

 typedef std::function<void(void**, QString, void*)> fn_type;
 fn_type* fn = reinterpret_cast<fn_type*>(_lisp->rzq_callback());
 
 QString n = QString::fromStdString(name->fullName());
 
 (*fn)(pr, n, &argmnts);

 return result;
#else 
 return _Nil<T_O>();
#endif// RZ_QCLASP
}



CL_LAMBDA(str);
CL_DECLARE();
CL_DOCSTRING("qpr");
CL_DEFUN core::T_sp core__qpr(core::T_sp tsp)
{
#ifdef RZ_QCLASP

 if(cl__numberp(tsp))
 {
  string s = _rep_(tsp);
  qDebug() << QString::fromStdString(s);
 }
 else
 {
  string s = _rep_(tsp); //?tsp->__repr__();
  qDebug() << QString::fromStdString(s);
 }
#endif // def RZ_QCLASP

 return _Nil<T_O>();
}

CL_LAMBDA(caption message);
CL_DECLARE();
CL_DOCSTRING("qDefineFunction");
CL_DEFUN core::T_sp core__qDefineFunction(core::Str_sp name, core::T_sp closure)
{
 std::string name_string = name->get();
 Function_sp fun = closure.asOrNull<Function_O>();
 if(fun.nilp())
 {
  qDebug() << "Failed to eval function...";
  return T_mv();
 }
 core::Symbol_sp sym = core::lispify_intern(name_string, "CORE");
 std::string sym_str = sym->fullName();
 sym->setf_symbolFunction(fun);
 return Values(fun);
}


SYMBOL_SC_(CorePkg, qtest);
SYMBOL_SC_(CorePkg, qpr);
SYMBOL_SC_(CorePkg, qMessageBox);
SYMBOL_SC_(CorePkg, qCreate);
SYMBOL_SC_(CorePkg, qDefineFunction);

    
} // end namespace core

