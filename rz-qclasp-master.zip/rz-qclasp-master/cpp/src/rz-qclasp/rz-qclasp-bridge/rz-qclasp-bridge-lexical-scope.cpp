

#include "rz-qclasp-bridge-lexical-scope.h"


#include "rzns.h"
USING_RZNS(RZClasp)


#define _ADDRESS_MODEL_64
#define X86
#define USE_BOEHM


#include <QList>
#include <QDebug>

#include <QRegularExpression>

#undef slots

#include "boehmdc/config.h"


#include <clasp/core/object.h>

#include <clasp/core/externalObject.h>
#include <clasp/core/primitives.h>
#include <clasp/core/str.h>

#include <clasp/core/qt-foreign-data.h>
#include <clasp/core/package.h>
#include <clasp/core/evaluator.h>


RZ_QClasp_Bridge_Lexical_Scope::RZ_QClasp_Bridge_Lexical_Scope(RZ_QClasp_Bridge_Lexical_Scope *parent_scope)
 : parent_scope_(parent_scope), held_retval_(nullptr)
{

}

void RZ_QClasp_Bridge_Lexical_Scope::review()
{
 QMapIterator<QString, void*> it(temp_symbols_);

 qDebug() << "\n\nScope review ... ";

 while(it.hasNext())
 {
  it.next();
  QString key = it.key();
  void* pv = it.value();

  if(key == "core::QtForeignData_O*")
  {
   core::QtForeignData_O* qtf = reinterpret_cast<core::QtForeignData_O*>(pv);
   qDebug() << "To delete: " << QString::fromStdString( qtf->__str__() );
  }
 }
 qDebug() << "\n ... \n ";
}


