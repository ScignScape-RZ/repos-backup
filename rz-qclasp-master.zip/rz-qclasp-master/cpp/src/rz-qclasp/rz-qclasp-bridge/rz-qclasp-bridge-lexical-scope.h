
#ifndef RZ_QCLASP_BRIDGE_LEXICAL_SCOPE__H
#define RZ_QCLASP_BRIDGE_LEXICAL_SCOPE__H

#include <QString>

#include <QMap>

#include "rzns.h"

#include "accessors.h"



RZNS_(RZClasp)


class RZ_QClasp_Eval;
//?class RZ_Clasp_Mainwindow;
class RZ_QClasp_Object_Bridge;


class RZ_QClasp_Bridge_Lexical_Scope
{
 QMultiMap<QString, void*> temp_symbols_;

 RZ_QClasp_Bridge_Lexical_Scope* parent_scope_;

 void* held_retval_;

public:


 RZ_QClasp_Bridge_Lexical_Scope(RZ_QClasp_Bridge_Lexical_Scope* parent_scope);

 ACCESSORS(RZ_QClasp_Bridge_Lexical_Scope* ,parent_scope)

 template<typename T>
 void add_track_value(QString class_name, T* value)
 {
  temp_symbols_.insert(class_name, reinterpret_cast<void*>(value));
 }

 void review();

 void hold_retval(void* pv)
 {
  held_retval_ = pv;
 }

 template<typename T>
 T* held_retval()
 {
  return reinterpret_cast<T*>(held_retval_);
 }
};


_RZNS(RZClasp)


#endif
