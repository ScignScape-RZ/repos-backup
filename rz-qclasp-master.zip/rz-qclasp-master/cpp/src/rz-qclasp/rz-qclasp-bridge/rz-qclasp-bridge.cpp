

#include "rz-qclasp-bridge.h"

#include "rz-qclasp-eval/rz-qclasp-eval.h"


#include <QDebug>

#include <QMessageBox>
#include <QApplication>

#include <QFileDialog>
#include <QTextStream>

#include "rzns.h"
USING_RZNS(RZClasp)

#include "rz-clasp-mainwindow/rz-clasp-mainwindow.h"
#include "rz-qclasp-object-bridge.h"

#include "rz-qclasp-invokable.h"
#include "rz-qclasp-router.h"


#ifdef HIDE
#include "rz-graph-core/kernel/document/rz-re-document.h"

#include "rz-graph-core/output/rz-re-pre-init-lisp.h"
#include "rz-graph-core/output/rz-re-pre-normal-lisp.h"

#include "rz-graph-code/prerun/rz-re-prerun-normalize.h"
#include "rz-graph-code/prerun/rz-re-prerun-tokens.h"
#include "rz-graph-code/prerun/rz-re-prerun-anticipate.h"

//#include "rz-graph-code/generate/rz-re-generate-cpp.h"
//#include "rz-graph-code/generate/rz-re-generate-haskell.h"
//#include "rz-graph-code/generate/rz-re-generate-tqns.h"
//#include "rz-graph-code/generate/rz-re-generate-cheerp.h"
#include "rz-graph-code/generate/rz-re-generate-clasp.h"


//#include "rz-graph-token/types/rz-type-variety.h"
#include "rz-graph-token/token/rz-lisp-token.h"

#include "rz-clasp-code/rz-clasp-code-generator.h"

#include "rz-graph-visit/rz-lisp-graph-visitor.h"
#endif // HIDE

#include "rz-clasp-qt/rz-clasp-qt-mainwindow.h"


//?#include "rz-webdb/rz-webdb-pvc/silo-types/artist/pvc-artist-list.h"
//?#include "rz-webdb/rz-webdb-pvc/silo-types/artist/pvc-artist.h"



#include "rz-qclasp-each/rz-qclasp-each.h"
#include "rz-qclasp-each/rz-qclasp-callback.h"
#include "rz-qclasp-each/rz-qclasp-callback-map.h"

#include <QList>

#include <QRegularExpression>


#define _ADDRESS_MODEL_64
#define X86
#define USE_BOEHM


#undef slots

#include "boehmdc/config.h"
//?#include "boehmdc/config.h"

#include <clasp/core/object.h>

#include <clasp/core/externalObject.h>
#include <clasp/core/primitives.h>
#include <clasp/core/str.h>

#include <clasp/core/qt-foreign-data.h>
#include <clasp/core/package.h>
#include <clasp/core/evaluator.h>



void RZ_QClasp_Bridge::reset_host_data(void* pv)
{
 _lisp->set_rzq_host_data(pv);
}

template<>
void RZ_QClasp_Bridge::mark_async(void** result, QList<core::General_sp>& args)
{
 core::General_sp a1 = args.takeFirst();
 core::FunctionClosure_sp fn = a1.asOrNull<core::FunctionClosure_O>();
 if(fn.notnilp())
 {
  core::FunctionClosure_O* cfn = fn.get();
  if(cfn)
  {
   RZ_QClasp_Callback* rcb = new RZ_QClasp_Callback(cfn);
   rcb->mark_async();
   core::QtForeignData_sp qtf = core::QtForeignData_O::allocateQtForeignObject();
   qtf->set_externalObject(rcb);
   qtf->set_type_description("RZ_QClasp_Callback*");
   core::General_sp* pr = reinterpret_cast<core::General_sp*>(result);
   *pr = qtf;
  }
 }
}

template<>
void RZ_QClasp_Bridge::make_do_map(void** result, QList<core::General_sp>& args)
{
 RZ_QClasp_Callback_Map* object_result = new RZ_QClasp_Callback_Map;
 QString key;
 for(core::General_sp arg : args)
 {
  if(key.isEmpty())
  {
   // arg should be a symbol ... but this is more general ...
   key = QString::fromStdString( arg->__str__() );
   if(key.startsWith(':'))
    key = key.mid(1);
  }
  else
  {
   std::string cns = arg->className();
   QString cn = QString::fromStdString(cns);

   if(cn == "QT-FOREIGN-DATA")
   {
    core::QtForeignData_sp qfd = arg.as<core::QtForeignData_O>();
    void* pv = qfd->_Data;
    QString cd = QString::fromStdString(qfd->type_description());
    if(cd == "RZ_QClasp_Callback*")
    {
     RZ_QClasp_Callback* cb = reinterpret_cast<RZ_QClasp_Callback*>(pv);
     if(key.startsWith('@'))
     {
      key = key.mid(1);
      cb->mark_async();
     }
     init_callback(cb);
     object_result->add_callback(key, *cb);
     key.clear();
    }
   }
   else
   {
    core::FunctionClosure_sp fn = arg.asOrNull<core::FunctionClosure_O>();
    if(fn.notnilp())
    {
     core::FunctionClosure_O* cfn = fn.get();
     if(cfn)
     {
      RZ_QClasp_Callback* rcb = new RZ_QClasp_Callback(cfn);
      if(key.startsWith('@'))
      {
       key = key.mid(1);
       rcb->mark_async();
      }
      init_callback(rcb);
      object_result->add_callback(key, *rcb);
      key.clear();
     }
    }
   }
  }
 }
 core::QtForeignData_sp qtf = core::QtForeignData_O::allocateQtForeignObject();
 qtf->set_externalObject(object_result);
 qtf->set_type_description("RZ_QClasp_Callback_Map*");
 core::General_sp* pr = reinterpret_cast<core::General_sp*>(result);
 *pr = qtf;
}

void RZ_QClasp_Bridge::init_callback(RZ_QClasp_Callback* cb)
{
 //  is there a chance cb could already be initialized?

 //?void* lfp = cb->lisp_function_pointer();
 cb->set_callback([this](void* __cfn, QString class_name, void* pv)
 {
  core::FunctionClosure_O* _cfn = reinterpret_cast<core::FunctionClosure_O*>(__cfn);
  core::FunctionClosure_sp fn_sp = _cfn->asSmartPtr();
  if(class_name == "QString")
  {
   QString qs = *reinterpret_cast<QString*>(pv);
   std::string strs = qs.toStdString();
   core::Str_sp csp = core::Str_O::create(strs);
   core::eval::funcall(fn_sp, csp);
  }
  else if(class_name == "int")
  {
   int i = *reinterpret_cast<int*>(pv);
   core::Fixnum_sp fi = core::clasp_make_fixnum(i);
   core::eval::funcall(fn_sp, fi);
  }
  else
  {
   core::QtForeignData_sp qfn = core::QtForeignData_O::create();
   qfn->set_externalObject(pv);
   qfn->set_type_description(class_name.toStdString());
   core::eval::funcall(fn_sp, qfn);
  }

 });
 cb->check_set_async();
}


template<>
void RZ_QClasp_Bridge::invoke(void** result, QList<core::General_sp>& args, void* static_or_sigma_first_arg, QString sigma_class)
{
 void* router_object;

 QString cn;

 core::General_sp a1 = args.takeFirst();
 core::General_sp a2 = args.takeFirst();
 std::string s2 = core::_rep_(a2);

 QString fname = QString::fromStdString(s2);

 if(static_or_sigma_first_arg)
 {
  if(sigma_class.isEmpty())
  {
   router_object = static_or_sigma_first_arg;
   core::Symbol_sp csp = a1.asOrNull<core::Symbol_O>();
   QString str = QString::fromStdString( csp->__str__() );
   if(str.startsWith(":"))
   {
    cn = str.mid(1);
   }
   else
   {
    cn = str;
   }
  }
  else
  {
   core::QtForeignData_sp qtf = a1.asOrNull<core::QtForeignData_O>();
   QString qtf_td = QString::fromStdString( qtf->type_description() );
   router_object = qtf->_Data;

   //?PVC::PVC_Artist* a = reinterpret_cast<PVC::PVC_Artist*>(router_object);

   cn = qtf_td;
  }
 }
 else
 {
  core::QtForeignData_O* qtf = reinterpret_cast<core::QtForeignData_O*>( a1.get() );

  QObject* qob = reinterpret_cast<QObject*>(qtf->_Data);
  cn = qob->metaObject()->className();
  router_object = qtf->_Data;
 }

 if(fname.startsWith(':'))
  fname.remove(0, 1);

 fname.replace('-', '_');

 core::General_sp clasp_result;
 QString string_result;
 void* object_result;

 RZ_QClasp_Router router(cn, router_object, string_result, object_result, &clasp_result);

 if(static_or_sigma_first_arg)
 {
  if(sigma_class.isEmpty())
  {
   router.set_static_class_name(cn);
  }
  else
  {
   router.set_static_class_name(sigma_class);
  }
 }

 QList<RZ_QClasp_Invoke_Argument> invoke_args;

 RZ_QClasp_Invoke_Argument ia(&a1);

 if(!sigma_class.isEmpty())
 {
  ia.mode = RZ_QClasp_Invoke_Argument::Sigma;
  ia.internal_type = cn;
  ia.object = router_object;
 }


 invoke_args.push_back(ia);

 QString ref_call_symbol_name;
 core::Symbol_sp current_ref_call_symbol;

 core::FunctionClosure_O* yield_fn;
 if(!args.isEmpty())
 {
  core::General_sp possible_fn_arg = args.last();
  core::FunctionClosure_sp possible_fn = possible_fn_arg.asOrNull<core::FunctionClosure_O>();
  if(possible_fn.notnilp())
  {
   yield_fn = possible_fn.get();
  }
 }

 if(fname == ".each")
 {
  core::General_sp arg = args.takeFirst();
  core::FunctionClosure_sp fn = arg.asOrNull<core::FunctionClosure_O>();

  if(fn.notnilp())
  {
   core::FunctionClosure_O* pfn = fn.get();

   RZ_QClasp_Each* rce = new RZ_QClasp_Each(pfn);

   rce->set_callback([this](void* __pfn, QString class_name, void* pv)
    {
     core::FunctionClosure_O* _pfn = reinterpret_cast<core::FunctionClosure_O*>(__pfn);
     core::FunctionClosure_sp fn_sp = _pfn->asSmartPtr();

     if(class_name == "QString")
     {
      QString qs = *reinterpret_cast<QString*>(pv);
      std::string strs = qs.toStdString();
      core::Str_sp csp = core::Str_O::create(strs);
      core::eval::funcall(fn_sp, csp);
     }
     else if(class_name == "int")
     {
      int i = *reinterpret_cast<int*>(pv);
      core::Fixnum_sp fi = core::clasp_make_fixnum(i);
      core::eval::funcall(fn_sp, fi);
     }
     else
     {
      core::QtForeignData_sp qfn = core::QtForeignData_O::create();
      qfn->set_externalObject(pv);
      qfn->set_type_description(class_name.toStdString());
      core::eval::funcall(fn_sp, qfn);
     }

    });

   RZ_QClasp_Invoke_Argument invoke_arg(&arg);
   invoke_arg.mode = RZ_QClasp_Invoke_Argument::Each_Callback;
   invoke_arg.object = rce;
   invoke_arg.internal_type = "RZ_QClasp_Each"; //?
   invoke_arg.declared_type = "RZ_QClasp_Each"; //?
   invoke_args.push_back(invoke_arg);
  }
 }
 else
 {
  for(core::General_sp& arg : args)
  {
   RZ_QClasp_Invoke_Argument invoke_arg(&arg);

   core::FunctionClosure_sp possible_fn = arg.asOrNull<core::FunctionClosure_O>();
     //? if(possible_fn.notnilp()) why is this returning true?
   core::FunctionClosure_O* cfn = possible_fn.get();
   if(cfn)
   {
    //?core::FunctionClosure_O* cfn = possible_fn.get();
    RZ_QClasp_Callback* rcb = new RZ_QClasp_Callback(cfn);

    rcb->set_callback([this](void* __cfn, QString class_name, void* pv)
     {
      core::FunctionClosure_O* _cfn = reinterpret_cast<core::FunctionClosure_O*>(__cfn);
      core::FunctionClosure_sp fn_sp = _cfn->asSmartPtr();
//      core::QtForeignData_sp qfn = core::QtForeignData_O::create();
//      qfn->set_externalObject(pv);
//      qfn->set_type_description(class_name.toStdString());

      if(class_name == "QString")
      {
       QString qs = *reinterpret_cast<QString*>(pv);
       std::string strs = qs.toStdString();
       core::Str_sp csp = core::Str_O::create(strs);
       core::eval::funcall(fn_sp, csp);
      }
      else if(class_name == "int")
      {
       int i = *reinterpret_cast<int*>(pv);
       core::Fixnum_sp fi = core::clasp_make_fixnum(i);
       core::eval::funcall(fn_sp, fi);
      }
      else
      {
       core::QtForeignData_sp qfn = core::QtForeignData_O::create();
       qfn->set_externalObject(pv);
       qfn->set_type_description(class_name.toStdString());
       core::eval::funcall(fn_sp, qfn);
      }

     });

    RZ_QClasp_Invoke_Argument invoke_arg(&arg);
    invoke_arg.mode = RZ_QClasp_Invoke_Argument::Yield_Callback;
    invoke_arg.object = rcb;
    invoke_arg.internal_type = "RZ_QClasp_Callback*"; //?
    invoke_arg.declared_type = "RZ_QClasp_Callback*"; //?
    invoke_args.push_back(invoke_arg);
    continue;
   }

   else if(core::cl__numberp(arg))
   {

    core::T_O* arg_raw = arg.get();

    //   QString rep = QString::fromStdString( _rep_(arg_raw->asSmartPtr()) );



    Ref_Call_Info* rci = reinterpret_cast<Ref_Call_Info*>( _lisp->rzq_eval_data() );

    QMap<core::T_O*, QString> rco = rci->ref_call_objects;
    QMap<QString, core::T_O*> rcm = rci->ref_call_map;

    QString symbol_name = rco.value(arg_raw);

    if(!symbol_name.isEmpty())
    {
     ref_call_symbol_name = symbol_name;
     core::Package_sp pkg = _lisp->getCurrentPackage();
     core::Symbol_sp update_symbol = pkg->findSymbol(symbol_name.mid(1).toStdString());
     current_ref_call_symbol = update_symbol;
    }

    switch(core::clasp_t_of(arg))
    {
    case core::number_Fixnum:
     {
      invoke_arg.internal_type = "Fixnum";
     }
     break;
    case core::number_DoubleFloat:
    case core::number_LongFloat:
    case core::number_SingleFloat:
     {
      invoke_arg.internal_type = "QReal";
     }
     break;
    }

   }
   else
   {
    core::T_O* arg_raw = arg.get();

    QString rep = QString::fromStdString( _rep_(arg_raw->asSmartPtr()) );

    QString symbol_name;

    Ref_Call_Info* rci = reinterpret_cast<Ref_Call_Info*>( _lisp->rzq_eval_data() );

    if(rci)
    {
     QMap<core::T_O*, QString> rco = rci->ref_call_objects;
     QMap<QString, core::T_O*> rcm = rci->ref_call_map;

     symbol_name = rco.value(arg_raw);
    }

    if(!symbol_name.isEmpty())
    {
     ref_call_symbol_name = symbol_name;
     core::Package_sp pkg = _lisp->getCurrentPackage();
     core::Symbol_sp update_symbol = pkg->findSymbol(symbol_name.mid(1).toStdString());
     current_ref_call_symbol = update_symbol;
    }

    core::General_sp aft = core::cl__type_of(arg);

    std::string cns = arg->className();
    QString cn = QString::fromStdString(cns);

    QString maybe_start = "COMMON-LISP";

    if(cn.startsWith(maybe_start))
    {
     cn = cn.mid(maybe_start.length());
    }

    //?if(cn == "COMMON-LISP:BASE-STRING")
    if(cn == "BASE-STRING")
    {
     invoke_arg.internal_type = "str";
     invoke_arg.str = QString::fromStdString( arg->__str__() );
    }
    else if(cn == "BASE-STRING-WITH-FILL-PTR")
    {
     invoke_arg.internal_type = "str";
     QString str = QString::fromStdString( arg->__str__() );
     invoke_arg.str = str.trimmed();
    }
    else if(cn == "QT-FOREIGN-DATA")
    {
     core::QtForeignData_sp qfd = arg.as<core::QtForeignData_O>();
     void* pv = qfd->_Data;
     QString cd = QString::fromStdString(qfd->type_description());
     invoke_arg.internal_type = cn + ":" + cd;
     invoke_arg.object = pv;

     if(cd == "RZ_QClasp_Callback*")
     {
      RZ_QClasp_Callback* cb = reinterpret_cast<RZ_QClasp_Callback*>(pv);
      if(cb->needs_init())
      {
       //?void* lfp = cb->lisp_function_pointer();
       cb->set_callback([this](void* __cfn, QString class_name, void* pv)
        {
         core::FunctionClosure_O* _cfn = reinterpret_cast<core::FunctionClosure_O*>(__cfn);
         core::FunctionClosure_sp fn_sp = _cfn->asSmartPtr();
         if(class_name == "QString")
         {
          QString qs = *reinterpret_cast<QString*>(pv);
          std::string strs = qs.toStdString();
          core::Str_sp csp = core::Str_O::create(strs);
          core::eval::funcall(fn_sp, csp);
         }
         else if(class_name == "int")
         {
          int i = *reinterpret_cast<int*>(pv);
          core::Fixnum_sp fi = core::clasp_make_fixnum(i);
          core::eval::funcall(fn_sp, fi);
         }
         else
         {
          core::QtForeignData_sp qfn = core::QtForeignData_O::create();
          qfn->set_externalObject(pv);
          qfn->set_type_description(class_name.toStdString());
          core::eval::funcall(fn_sp, qfn);
         }

        });

       cb->check_set_async();
       invoke_arg.mode = RZ_QClasp_Invoke_Argument::Yield_Callback;

      }

     }

    }
    else if(cn == "SYMBOL")
    {
     //  treat a symbol as just a QString ...
     invoke_arg.internal_type = "str";
     invoke_arg.str = QString::fromStdString( arg->__str__() );

     // //  This has hopefully become unnecessary
      //
     //    QString str = QString::fromStdString( arg->__str__() );
     //    if(str == "@")
     //    {
     //     awaiting_ref_call_symbol = true;
     //    }
     //    else if(awaiting_ref_call_symbol)
     //    {
     //     awaiting_ref_call_symbol = false;
     //     ref_call_symbol_name = str;
     //     current_ref_call_symbol = arg;
     //     //ref_call_flag = true;
     //    }
     //    continue;
    }
    else
    {
     std::string ss = core::_rep_(aft);
     QString ts = QString::fromStdString(ss);
     invoke_arg.internal_type = ts;
    }
   }

   if(!ref_call_symbol_name.isEmpty())
   {
    invoke_arg.mode = RZ_QClasp_Invoke_Argument::Ref;
    invoke_arg.call_symbol_name = ref_call_symbol_name;
    invoke_arg.call_symbol = &current_ref_call_symbol;
    ref_call_symbol_name.clear();
   }
   invoke_args.push_back(invoke_arg);

  }
 }




 router.set_method_name(fname);
 router.do_invoke_method(invoke_args);

 // for refs...

 int i = 0;

 for(RZ_QClasp_Invoke_Argument& ia : invoke_args)
 {
  if(ia.mode == RZ_QClasp_Invoke_Argument::Ref)
  {
   core::General_sp* invoke_gsp = reinterpret_cast<core::General_sp*>(ia.object);
   std::string invoke_ss = _rep_(*invoke_gsp);
   QString invoke_s = QString::fromStdString(invoke_ss);
   core::Symbol_sp* call_symbol_p = reinterpret_cast<core::Symbol_sp*>( ia.call_symbol );
   core::Symbol_sp call_symbol = *call_symbol_p;

   std::string cn = call_symbol->currentName();
   QString qcn = QString::fromStdString(cn);

   std::string fn = call_symbol->fullName();
   QString qfn = QString::fromStdString(cn);

   core::General_sp g_sp = call_symbol->_Value;

   std::string ss = _rep_(g_sp);

   QString qss = QString::fromStdString(ss);

   //? call_symbol->_Value = *invoke_gsp;

   QString csn = ia.call_symbol_name.mid(1);

   //?core::T_O* env1 = (core::T_O*) _lisp->rzq_host_data();

   Ref_Call_Info* rcd = reinterpret_cast<Ref_Call_Info*>( _lisp->rzq_eval_data() );

   QMap<QString, core::T_O*> qmap = rcd->ref_call_map;

   QMapIterator<QString, core::T_O*> it(qmap);

   while(it.hasNext())
   {
    it.next();

    QString symbol_name = it.key();
    core::Environment_O* env = reinterpret_cast<core::Environment_O*>( it.value() );
    core::T_sp envsp = env->asSmartPtr();
    core::Package_sp pkg = _lisp->getCurrentPackage();


    core::Symbol_sp update_symbol = pkg->findSymbol(symbol_name.mid(1).toStdString());
    af_updateValue(envsp, update_symbol, *invoke_gsp);

   }

  }
  ++i;

 }

 // // handle refs ...

 switch(router.return_convention())
 {
 case RZ_QClasp_Router::Return_Conventions::No_Return: break;
 case RZ_QClasp_Router::Return_Conventions::QString_Direct:
  {
   core::General_sp* pr = reinterpret_cast<core::General_sp*>(result);
   std::string ss = string_result.toStdString();
   core::Str_sp ns = core::Str_O::create(ss);
   *pr = ns;
   break;
  }
 case RZ_QClasp_Router::Return_Conventions::QObject_Cast:
  {
   core::General_sp* pr = reinterpret_cast<core::General_sp*>(result);
   core::QtForeignData_sp qtf = core::QtForeignData_O::create();
   qtf->set_externalObject(router.object_result());
   qtf->set_type_description(router.return_type_name().toStdString());
   *pr = qtf;
   break;
  }
 case RZ_QClasp_Router::Return_Conventions::Direct:
  {
   core::General_sp* pr = reinterpret_cast<core::General_sp*>(result);
   int* r = reinterpret_cast<int*>(object_result);
   *pr = clasp_result;
   break;
  }
 }
}

void RZ_QClasp_Bridge::print_to_callback(QString str)
{
 if(print_callback_)
 {
  print_callback_(str);
 }
 else
 {
  qDebug() << str;
 }
}


template<>
void RZ_QClasp_Bridge::static_invoke(void** result, QList<core::General_sp>& args)
{
 invoke(result, args, object_bridge_);
}

template<>
void RZ_QClasp_Bridge::static_invoke_sigma(void** result, QList<core::General_sp>& args)
{
 core::General_sp arg0 = args.at(0);
 core::QtForeignData_sp qtf = arg0.asOrNull<core::QtForeignData_O>();
 QString qtf_td = QString::fromStdString( qtf->type_description() );
 QString stasi_cn;
 invoke(result, args, object_bridge_, stasi_cn);
}


template<>
void RZ_QClasp_Bridge::eval_string(QString code, core::T_sp& result)
{
 clasp_eval_.eval_string(code, result);
}



RZ_QClasp_Bridge::RZ_QClasp_Bridge(RZ_QClasp_Eval& clasp_eval, void* host_data)
 : clasp_eval_(clasp_eval), object_bridge_(new RZ_QClasp_Object_Bridge(*this)),
   host_data_(host_data)
{
 RZ_QClasp_Eval::Callback_type* cb = new RZ_QClasp_Eval::Callback_type(
    [this](void** result, QString n, void* v)
 {
  core::List_sp* pargs = reinterpret_cast<core::List_sp*>(v);
  core::List_sp cargs = *pargs;
  QList<core::General_sp> arg_list;

  for (core::Cons_sp cur : cargs)
  {
   core::General_sp gsp = core::oCar(cur);
   arg_list << gsp;

   core::T_O* lt = _lisp->_true().get();

   std::string rep = _rep_(gsp);

   QString rs = QString::fromStdString(rep);
  }

  if(n == ":MAKE-OBJECT")
  {
   if(object_bridge_)
    object_bridge_->make_qobject(arg_list);
  }
  else if(n == ":CHECK-QFD")
  {
   core::General_sp a0 = arg_list.takeFirst();
   core::QtForeignData_O* qtf = reinterpret_cast<core::QtForeignData_O*>( a0.get() );

   void* pv = qtf->_Data;

   QObject* qobj = reinterpret_cast<QObject*>(pv);

   QString txt = qobj->metaObject()->className();
   QString ot = qobj->property("text").toString();

   qobj->setProperty("text", ot + txt);
  }
  else if(n == ":LEX-ENTRY")
  {
   if(object_bridge_)
    object_bridge_->lex_entry();
  }

  else if(n == ":DEFUN")
  {
   core::Package_sp pkg = _lisp->findPackage("CORE").asOrNull<core::Package_O>();
   core::Symbol_sp fn_symbol = pkg->findSymbol("Q-MESSAGE-BOX");
   core::Function_sp fn = fn_symbol->symbolFunction().asOrNull<core::Function_O>();
   core::T_sp fn_result = core::eval::funcall(fn, arg_list[0], arg_list[1]);
   core::T_sp& retval_tsp = reinterpret_cast<core::T_sp&>(*result);
   retval_tsp = fn_result;
  }

  else if(n == ":LEX-LEAVE")
  {
   QString qcgos;
   if(object_bridge_)
   {
    core::General_O* held_retval = object_bridge_->held_retval<core::General_O>();
    object_bridge_->lex_leave();

    core::General_O* cgo = reinterpret_cast<core::General_O*>(held_retval);

    if(cgo)
    {
     std::string cgos = cgo->__str__();
     qcgos = QString::fromStdString( cgos );

     core::T_sp& retval_tsp = reinterpret_cast<core::T_sp&>(*result);
     retval_tsp = held_retval->asSmartPtr();
    }
    else if(!arg_list.isEmpty())
    {
     core::General_sp a1 = arg_list.takeFirst();
     core::T_sp& retval_tsp = reinterpret_cast<core::T_sp&>(*result);
     retval_tsp = a1;
    }
   }
  }
  else if(n == ":HOLD-RETVAL")
  {
   core::General_sp a0 = arg_list.takeFirst();
   core::General_O* a00 = a0.get();
   if(object_bridge_)
    object_bridge_->hold_retval(a00);
   core::T_sp& retval_tsp = reinterpret_cast<core::T_sp&>(*result);
   retval_tsp = a0;
  }
  else if(n == ":SET-PROPERTY")
  {
   if(object_bridge_)
    object_bridge_->set_property(arg_list);
  }
  else if(n == ":NEXT-EVAL")
  {
   eval_string(next_eval_string_);
   next_eval_string_.clear();
  }
  else if(n == ":EVAL-STRING")
  {
   core::General_sp a0 = arg_list.takeFirst();
   QString ev = QString::fromStdString( a0->__str__() );
   core::T_sp& retval_tsp = reinterpret_cast<core::T_sp&>(*result);
   eval_string(ev, retval_tsp);
  }
  else if(n == ":PRINT-TO-CALLBACK")
  {
   core::General_sp a0 = arg_list.takeFirst();
   QString str = QString::fromStdString( a0->__str__() );
   print_to_callback(str);
  }
  else if(n == ":STATIC-INVOKE")
  {
   static_invoke(result, arg_list);
  }
  else if(n == ":STATIC-INVOKE-SIGMA")
  {
   static_invoke_sigma(result, arg_list);
  }
  else if(n == ":INVOKE")
  {
   invoke(result, arg_list);
  }
  else if(n == ":MARK-ASYNC")
  {
   mark_async(result, arg_list);
  }
  else if(n == ":MAKE-DO-MAP")
  {
   make_do_map(result, arg_list);
  }
  else
  {
   if(object_bridge_)
    object_bridge_->make_qobject(arg_list);
  }
 });
 clasp_eval_.set_clasp_callback(*cb);
 clasp_eval_.set_clasp_data(host_data_);
}


QString read_file(QString path)
{
 QFile in_file(path);
 if (in_file.open(QFile::ReadOnly | QFile::Text))
 {
  QTextStream in(&in_file);
  return in.readAll();
 }
 return QString();
}

QString RZ_QClasp_Bridge::eval_string(QString code)
{
 Ref_Call_Info rci;
 void* pv = reinterpret_cast<void*>(&rci);
 _lisp->set_rzq_eval_data( pv );
 QString result = clasp_eval_.eval_string(code);
 return result;
}


QString RZ_QClasp_Bridge::eval_file(QString file_name)
{
 QString code = read_file(file_name);
 QString result = eval_string(code);
 return result;
}

QString RZ_QClasp_Bridge::select_and_eval_file()
{
 QString path = QFileDialog::getOpenFileName(nullptr, "Open Lisp File");
 QString result = eval_file(path);
 return result;
}

void RZ_QClasp_Bridge::compile_rz(QString file_name, QString& result)
{
#ifdef HIDE
 RE_Document* doc = new RE_Document(file_name);
 doc->parse();

 doc->report_graph(file_name + ".txt");

 RE_Pre_Normal_Lisp prenorm(doc);
 prenorm.output("..prenorm.txt");

 RE_Prerun_Tokens tokens(doc); //, &RZ_Lisp_Token::init_lisp_token);
 tokens.output("..prenorm2.txt");


 RE_Prerun_Normalize normalize(*doc->graph());


 caon_ptr<RZ_Lisp_Graph_Visitor> visitor = normalize.scan();

 visitor->set_document_directory(doc->local_directory());

 QString handlers = doc->rz_path_handlers();
 if(!handlers.isEmpty())
 {
  visitor->prepare_rz_path_handlers_output(handlers);
 }


 doc->report_graph(file_name + ".re1.txt");

 RE_Pre_Normal_Lisp prenorm1(doc);
 prenorm1.output("..prenorm1.txt");


 RZ_Clasp_Code_Generator& ccg = *visitor->rz_clasp_code_generator();


 RE_Generate_Clasp gen(*visitor);


 RE_Prerun_Anticipate anticipate(*visitor);

 RZ_File_List_Type extra_files;

 gen.init_project(extra_files);
 anticipate.scan();

 QString output;
 QTextStream qts(&output);


 gen.write(qts);

 QString output1;


 QTextStream qts1(&output1);


 ccg.write(qts1);

 QString result_file = doc->local_path() + ".cl";
 QFile outfile(result_file);


 if(outfile.open(QIODevice::WriteOnly | QIODevice::Text))
 {
  QTextStream out(&outfile);
  out << output1;
 }
 result = output1;

#endif // HIDE

}


QString RZ_QClasp_Bridge::eval_rz_file(QString file_name)
{
 QString code;
 compile_rz(file_name, code);
 eval_string(code);
 return code;
}

