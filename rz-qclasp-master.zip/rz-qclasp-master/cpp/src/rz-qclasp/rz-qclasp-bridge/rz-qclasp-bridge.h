
#ifndef RZ_QCLASP_BRIDGE__H
#define RZ_QCLASP_BRIDGE__H

#include <QString>

#include "rzns.h"

#include "accessors.h"


RZNS_CLASS_DECLARE(NL ,NL_Lexicon)
USING_RZNS(NL)


RZNS_(RZClasp)


class RZ_QClasp_Eval;
class RZ_QClasp_Object_Bridge;
class RZ_QClasp_Callback;


class RZ_QClasp_Bridge
{
 RZ_QClasp_Eval& clasp_eval_;

 RZ_QClasp_Object_Bridge* object_bridge_;

 void* host_data_;

 QString next_eval_string_;

 typedef std::function<void(QString)> print_callback_type;

 print_callback_type print_callback_;

public:

 RZ_QClasp_Bridge(RZ_QClasp_Eval& clasp_eval, void* host_data = nullptr);

 ACCESSORS(RZ_QClasp_Object_Bridge* ,object_bridge)

 ACCESSORS(void* ,host_data)
 ACCESSORS(print_callback_type ,print_callback)


 QString eval_string(QString code);
 QString eval_file(QString file_name);
 QString select_and_eval_file();

 void init_callback(RZ_QClasp_Callback* cb);

 void print_to_callback(QString str);

 template<typename T>
 void eval_string(QString code, T& result);

 QString eval_rz_file(QString file_name);
 static void compile_rz(QString file_name, QString& result);

 template<typename T>
 void invoke(void** result, T& args,
   void* static_or_sigma_first_arg = nullptr, QString sigma_class = QString());

 template<typename T>
 void static_invoke(void** result, T& args);

 template<typename T>
 void static_invoke_sigma(void** result, T& args);

 void reset_host_data(void* pv);

 template<typename T>
 void reset_host_data(T* t)
 {
  return reset_host_data( reinterpret_cast<void*>(t) );
 }

 template<typename T>
 void mark_async(void** result, QList<T>& args);

 template<typename T>
 void make_do_map(void** result, QList<T>& args);

 template<typename T>
 void make_qobject(QList<T>& args);

 template<typename T>
 void set_property(QList<T>& args);
};


_RZNS(RZClasp)







//class Clasp_Bridge1
//{

//public:

// // static void select_and_eval_file_msg();
// // static QString select_and_eval_file();
// // static QString eval_file(QString file_name);
//};


#endif
