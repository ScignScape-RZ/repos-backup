
 TEMP_MACRO(t_fixnum, Fixnum, QMetaType_Name, Int)
 TEMP_MACRO(t_bignum, Bignum, QMetaType_Name, UnknownType)
 TEMP_MACRO(t_singlefloat, QReal, QMetaType_Name, QReal)


// TEMP_MACRO(t_list, "List", QMetaType_Name, UnknownType)
// TEMP_MACRO(t_character , "Character", QMetaType_Name, UnknownType)

// TEMP_MACRO(t_fixnum, "Fixnum", QMetaType_Name, Int)
// TEMP_MACRO(t_bignum, "Bignum", QMetaType_Name, UnknownType)
// TEMP_MACRO(t_ratio, "Ratio", QMetaType_Name, Float)
// TEMP_MACRO(t_singlefloat, "SingleFloat", QMetaType_Name, Float)
// TEMP_MACRO(t_doublefloat, "DoubleFloat", QMetaType_Name, Float)
//#ifdef ECL_LONG_FLOAT
// TEMP_MACRO(t_longfloat, "LongFloat", QMetaType_Name, UnknownType)
//#endif
// TEMP_MACRO(t_complex , "Complex", QMetaType_Name, UnknownType)
// TEMP_MACRO(t_symbol, "Symbol", QMetaType_Name, UnknownType)
// TEMP_MACRO(t_package, "Package", QMetaType_Name, UnknownType)
// TEMP_MACRO(t_hashtable, "Hashtable", QMetaType_Name, UnknownType)
// TEMP_MACRO(t_array, "Array", QMetaType_Name, UnknownType)
// TEMP_MACRO(t_vector, "Vector", QMetaType_Name, UnknownType)
//#ifdef ECL_UNICODE
// TEMP_MACRO(t_string, "String", QMetaType_Name, UnknownType)
//#endif
// TEMP_MACRO(t_base_string, "BaseString", QMetaType_Name, UnknownType)
// TEMP_MACRO(t_bitvector, "Bitvector", QMetaType_Name, UnknownType)
// TEMP_MACRO(t_stream, "Stream", QMetaType_Name, UnknownType)
// TEMP_MACRO(t_random, "Random", QMetaType_Name, UnknownType)
// TEMP_MACRO(t_pathname, "Pathname", QMetaType_Name, UnknownType)
// TEMP_MACRO(t_bytecodes, "Bytecodes", QMetaType_Name, UnknownType)
// TEMP_MACRO(t_bclosure, "BClosure", QMetaType_Name, UnknownType)
// TEMP_MACRO(t_cfun, "CFun", QMetaType_Name, UnknownType)
// TEMP_MACRO(t_cfunfixed, "CFunFixed", QMetaType_Name, UnknownType)
// TEMP_MACRO(t_cclosure, "CClosure", QMetaType_Name, UnknownType)
// TEMP_MACRO(t_instance, "Instance", QMetaType_Name, UnknownType)

////?
////    TEMP_MACRO(t_structure, "Instance", QMetaType_Name, UnknownType)
////   #ifdef CLOS
////    t_instance,
////    t_structure = t_instance,
////   #else
////    t_structure,
////   #endif /* CLOS */
////   #ifdef ECL_THREADS
////    t_process,
////    t_lock,
////    t_rwlock,
////    t_condition_variable,
////           t_semaphore,
////           t_barrier,
////           t_mailbox,
////   #endif

// TEMP_MACRO(t_codeblock, "CodeBlock", QMetaType_Name, UnknownType)

// TEMP_MACRO(t_foreign, "Foreign", QMetaType_Foreign, UnknownType)

// TEMP_MACRO(t_frame, "Frame", QMetaType_Name, UnknownType)
// TEMP_MACRO(t_weak_pointer, "WeakPointer", QMetaType_Name, UnknownType)
// TEMP_MACRO(t_end, "End", QMetaType_Name, UnknownType)
// TEMP_MACRO(t_other, "Other", QMetaType_Name, UnknownType)
////   #ifdef ECL_SSE2
////    t_sse_pack,
////   #endif
////?    t_contiguous,		/*  contiguous block  */

