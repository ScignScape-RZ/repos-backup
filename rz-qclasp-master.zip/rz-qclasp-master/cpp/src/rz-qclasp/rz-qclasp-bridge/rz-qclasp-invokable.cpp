
#include "rz-qclasp-invokable.h"

#include <QDebug>

#include <QVariant>

#include <QFile>

#include <QRegularExpression>
#include <QRegularExpressionMatch>

#include <QEventLoop>

#include "rzns.h"
USING_RZNS(RZClasp)


RZ_Clasp_Invokable::RZ_Clasp_Invokable()
 : QMessageBox(nullptr), router_(nullptr)
{

}

int RZ_Clasp_Invokable::sText(int arg, QVariant arg1, QString arg2) //,
{
 QString s = QString("%1: %2 %3").arg(arg).arg(arg1.toInt()).arg(arg2);
 this->QMessageBox::setText(s); //.arg(arg1)); //.arg(arg3));
 return arg + 2;
}

void RZ_Clasp_Invokable::doExec()
{
 this->QMessageBox::setWindowModality(Qt::WindowModal);
 this->QMessageBox::exec();
}


void RZ_Clasp_Invokable::need_handle_click()
{
 //?Q_EMIT(handle_click());
}





