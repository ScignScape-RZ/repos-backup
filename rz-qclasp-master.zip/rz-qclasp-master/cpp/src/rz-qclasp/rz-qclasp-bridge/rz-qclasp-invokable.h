
#ifndef RZ_CLASP_INVOKABLE__H
#define RZ_CLASP_INVOKABLE__H

#include <QtGlobal>


#include <functional>

#include <QMessageBox>

#include <QVariant>

#include "rzns.h"
#include "accessors.h"


class QNetworkAccessManager;

class QNetworkReply;

RZNS_(RZClasp)

class RZ_Clasp_Router;

class RZ_Clasp_Invokable : public QMessageBox
{
 Q_OBJECT


 RZ_Clasp_Router* router_;

 QString text_;

public:


 Q_INVOKABLE  RZ_Clasp_Invokable();

 Q_INVOKABLE  int  sText(int arg, QVariant arg1,  QString arg2);

 Q_INVOKABLE  void doExec();


Q_SIGNALS:
 void handle_click();

public
Q_SLOTS:
 void need_handle_click();


};

_RZNS(RZClasp)

Q_DECLARE_METATYPE(RZ::RZClasp::RZ_Clasp_Invokable*)

#endif
