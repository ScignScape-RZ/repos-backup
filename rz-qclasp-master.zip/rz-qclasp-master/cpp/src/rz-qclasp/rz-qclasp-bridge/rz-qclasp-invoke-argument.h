
#ifndef RZ_QCLASP_INVOKE_ARGUMENT__H
#define RZ_QCLASP_INVOKE_ARGUMENT__H


#include "rzns.h"

#include <QString>


RZNS_(RZClasp)


struct RZ_QClasp_Invoke_Argument
{
 enum Mode {
  N_A, Value, Ref, Ptr, Each_Callback, Sigma,
  Yield_Callback,
 };

 QString internal_type;
 QString str;
 void* object;
 QString declared_type;
 QString modifier;

 QString call_symbol_name;
 void* call_symbol;

 Mode mode;

 RZ_QClasp_Invoke_Argument(void* obj)
  : object(obj), mode(N_A)
 {


 }
};


_RZNS(RZClasp)

#endif
