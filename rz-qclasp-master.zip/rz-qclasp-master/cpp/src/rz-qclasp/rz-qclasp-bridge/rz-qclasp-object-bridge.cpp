
#include "rz-qclasp-object-bridge.h"

#include "rz-qclasp-bridge.h"

#include "rz-qclasp-invokable.h"

#include "rz-qclasp-router.h"

#include "rz-qclasp-bridge-lexical-scope.h"

#include <QRegularExpression>

#include <QMessageBox>
#include <QVBoxLayout>

#include <QDebug>

USING_RZNS(RZClasp)

#define _ADDRESS_MODEL_64
#define X86
#define USE_BOEHM
#undef slots

#include "boehmdc/config.h"

#include <clasp/core/object.h>

#include <clasp/core/externalObject.h>
#include <clasp/core/numbers.h>
#include <clasp/core/predicates.h>

#include <clasp/core/qt-foreign-data.h>


RZ_QClasp_Object_Bridge::RZ_QClasp_Object_Bridge(RZ_QClasp_Bridge& clasp_bridge)
 : clasp_bridge_(clasp_bridge),
   object_factory_meta_object_(RZ_QClasp_Object_Factory::staticMetaObject),
   current_lexical_scope_(nullptr)
{
 clasp_bridge_.set_object_bridge(this);


}


void RZ_QClasp_Object_Bridge::lex_entry()
{
 current_lexical_scope_ = new RZ_QClasp_Bridge_Lexical_Scope(current_lexical_scope_);
}

template<>
core::General_O* RZ_QClasp_Object_Bridge::held_retval()
{
 core::General_O* result = current_lexical_scope_->held_retval<core::General_O>();
 return result;
}

void RZ_QClasp_Object_Bridge::lex_leave()
{
 current_lexical_scope_->review();
 current_lexical_scope_ = current_lexical_scope_->parent_scope();
}

void RZ_QClasp_Object_Bridge::current_lexical_scope_hold_retval(void* pv)
{
 current_lexical_scope_->hold_retval(pv);
}


template<>
void RZ_QClasp_Object_Bridge::set_property(QList<core::General_sp>& args)
{

}

template<typename Key_type>
struct RZ_QClasp_Object_Bridge__make_value_map
{
 template<typename Value_type>
 static void both_types_known(core::QtForeignData_O* qtf,
   QList<core::General_sp>& args, Key_type default_key, Value_type default_value)
 {
 }

 static void key_type_known(core::QtForeignData_O* qtf,
   QList<core::General_sp>& args, Key_type default_key)
 {
  core::General_sp first_value = args.at(1);

  if(core::cl__numberp(first_value))
  {
  }
  else
  {
   std::string cns = first_value->className();
   QString cn = QString::fromStdString(cns);
   if(cn == "COMMON-LISP:BASE-STRING" || cn == "BASE-STRING")
   {
    both_types_known(qtf, args, default_key, QString());
   }
   else if(cn == "COMMON-LISP:SYMBOL" || cn == "SYMBOL")
   {
    both_types_known(qtf, args, default_key, QString());
   }
   else
   {
   }
  }
 }

};


template<>
template<>
void RZ_QClasp_Object_Bridge__make_value_map<QString>
  ::both_types_known<QString>(core::QtForeignData_O* qtf,
  QList<core::General_sp>& args, QString default_key, QString default_value)
{
 QMap<QString, QString>* result = new QMap<QString, QString>();

 QListIterator<core::General_sp> it(args);
 while(it.hasNext())
 {
  core::General_sp key_sp = it.next();
  core::General_sp value_sp = it.next();
  QString key = QString::fromStdString( key_sp->__str__() );
  QString value = QString::fromStdString( value_sp->__str__() );

  result->insert(key, value);

 }
 qtf->_Data = result;
 qtf->set_type_description("QMap<QString, QString>");

}


template<>
void RZ_QClasp_Object_Bridge::make_list_vector_type_known(core::QtForeignData_O* qtf,
QList<core::General_sp>& args, QString default_value)
{
 QList<QString>* result = new QList<QString>;
 QListIterator<core::General_sp> it(args);
 while(it.hasNext())
 {
  core::General_sp value_sp = it.next();
  QString value = QString::fromStdString( value_sp->__str__() );

  result->append(value);
 }
 qtf->_Data = result;
 qtf->set_type_description("QList<QString>");
}


template<>
void RZ_QClasp_Object_Bridge::make_list_vector(core::QtForeignData_O* qtf,
  QList<core::General_sp>& args)
{
 core::General_sp first_key = args.at(0);

 if(core::cl__numberp(first_key))
 {
 }
 else
 {
  std::string cns = first_key->className();
  QString cn = QString::fromStdString(cns);

  if(cn == "COMMON-LISP:BASE-STRING" || cn == "BASE-STRING")
  {
   make_list_vector_type_known(qtf, args, QString());
  }
  else if(cn == "COMMON-LISP:SYMBOL" || cn == "SYMBOL")
  {
   make_list_vector_type_known(qtf, args, QString());
  }
  else
  {
   //?   label = QString::fromStdString( _rep_(obj) );
  }
 }

}


template<>
void RZ_QClasp_Object_Bridge::make_value_map(core::QtForeignData_O* qtf,
  QList<core::General_sp>& args)
{
 core::General_sp first_key = args.at(0);
 if(core::cl__numberp(first_key))
 {
 }
 else
 {
  std::string cns = first_key->className();
  QString cn = QString::fromStdString(cns);

  if(cn == "COMMON-LISP:BASE-STRING" || cn == "BASE-STRING")
  {
   RZ_QClasp_Object_Bridge__make_value_map<QString>::key_type_known(qtf, args, QString());
  }
  else if(cn == "COMMON-LISP:SYMBOL" || cn == "SYMBOL")
  {
   RZ_QClasp_Object_Bridge__make_value_map<QString>::key_type_known(qtf, args, QString());
  }
  else
  {
   //?   label = QString::fromStdString( _rep_(obj) );
  }
 }
}




template<>
void RZ_QClasp_Object_Bridge::make_qobject(QList<core::General_sp>& args, bool long_lived)
{
 core::General_sp a1 = args.takeFirst();
 core::QtForeignData_O* qtf = reinterpret_cast<core::QtForeignData_O*>( a1.get() );
 core::General_sp a2 = args.takeFirst();
 std::string s2 = core::_rep_(a2);
 QString cl = QString::fromStdString(s2); //class_name.replace('\"', "");

 if(cl == ":MAKE-VMAP")
 {
  make_value_map(qtf, args);
  return;
 }

 if(cl == ":MAKE-VECTOR")
 {
  make_list_vector(qtf, args);
  return;
 }


 QString type = cl;

 if(type.startsWith(':'))
  type.remove(0, 1);


 if(type.startsWith("*:"))
 {
  type = type.mid(2);
  long_lived = true;
 }

 // unless non-temp ...
 if(!long_lived)
 {
  if(current_lexical_scope_)
  {
   current_lexical_scope_->add_track_value("core::QtForeignData_O*", qtf);
  }
 }

 int metatype_id = QMetaType::type(type.toLatin1());

 QString type_descriptor = type;

 QString type_ptr = type + "*";


 int pointer_metatype_id = QMetaType::type(type_ptr.toLatin1());


 type.prepend("new_");

 type.replace(':', '_');

 type_ptr.replace(QRegularExpression("[\\w:]+:"), "");

 QObject* result = nullptr;

 object_factory_meta_object_.invokeMethod(&object_factory_, type.toLatin1(),
   QReturnArgument<QObject*>( type_ptr.toLatin1(),
                             result)
                  );

 if(result)
 {
  qDebug() << "OK";
 }
 else if(metatype_id != QMetaType::UnknownType)
 {
  result = static_cast<QObject*>( QMetaType::create(metatype_id) );
 }

 QString label;
 for (auto obj : args)
 {
  if(core::cl__numberp(obj))
  {
  }
  else
  {
   std::string cns = obj->className();
   QString cn = QString::fromStdString(cns);
   if(cn == "COMMON-LISP:BASE-STRING")
   {
    label = QString::fromStdString(  //core::str_get(obj)
                                   _rep_(obj)
                                    );
   }
   else
   {
    label = QString::fromStdString( _rep_(obj) );
   }
  }
 }

 if(result)
 {
  result->setProperty("text", label);


  if(QWidget* qw = qobject_cast<QWidget*>(result) )
  {
   //?main_layout_->addWidget(qw);
  }
  qtf->_Data = result;

  qtf->set_type_description(type_descriptor.toStdString());

 }
}

