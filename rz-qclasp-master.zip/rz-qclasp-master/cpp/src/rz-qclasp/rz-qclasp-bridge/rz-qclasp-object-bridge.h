
#ifndef RZ_QCLASP_OBJECT_BRIDGE__H
#define RZ_QCLASP_OBJECT_BRIDGE__H

#include <QString>

#include <QMainWindow>

#include <QMetaObject>

#include "rzns.h"

#include <QWidget>
#include <QTextEdit>
#include <QPushButton>
#include <QVBoxLayout>

#include "rz-qclasp-object-factory.h"

RZNS_(RZClasp)


class RZ_QClasp_Mainwindow;
class RZ_QClasp_Bridge;

class RZ_QClasp_Bridge_Lexical_Scope;

class RZ_QClasp_Object_Bridge
{
 RZ_QClasp_Bridge& clasp_bridge_;

 RZ_QClasp_Object_Factory object_factory_;

 const QMetaObject object_factory_meta_object_; //(Object_Factory::staticMetaObject)

 RZ_QClasp_Bridge_Lexical_Scope* current_lexical_scope_;

 void current_lexical_scope_hold_retval(void* pv);


public:

 RZ_QClasp_Object_Bridge(RZ_QClasp_Bridge& clasp_bridge);

 void lex_entry();
 void lex_leave();

 template<typename T>
 T* held_retval();

 template<typename T>
 void make_qobject(QList<T>& args, bool long_lived = false);


 template<typename T>
 T* hold_retval(T* pt)
 {
  if(current_lexical_scope_)
  {
   void* pv = reinterpret_cast<void*>(pt);
   current_lexical_scope_hold_retval(pv);
   return nullptr;
  }
  else
  {
   return pt;
  }
 }


 template<typename Result_type, typename T>
 void make_value_map( Result_type* r, QList<T>& args);

 template<typename Result_type, typename T>
 void make_list_vector( Result_type* r, QList<T>& args);

 template<typename Result_type, typename T, typename Value_type>
 void make_list_vector_type_known( Result_type* r, QList<T>& args, Value_type default_value);


 template<typename T>
 void set_property(QList<T>& args);

};


_RZNS(RZClasp)







//class Clasp_Bridge1
//{

//public:

// // static void select_and_eval_file_msg();
// // static QString select_and_eval_file();
// // static QString eval_file(QString file_name);
//};


#endif
