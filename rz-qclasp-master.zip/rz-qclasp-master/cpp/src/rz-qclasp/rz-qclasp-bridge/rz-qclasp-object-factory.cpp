
#include "rz-qclasp-object-factory.h"

#include "rz-qclasp-invokable.h"

#include "rz-clasp-qt/rz-clasp-qt-mainwindow.h"


//?#include "rz-webdb/rz-webdb-client/http-bridge.h"


USING_RZNS(RZClasp)

RZ_QClasp_Object_Factory::RZ_QClasp_Object_Factory()
{
//? qRegisterMetaType<RZ::RZClasp::Qt_MainWindow*>();
//? qRegisterMetaType<RZ::RZWebDb::Http_Bridge*>();
 qRegisterMetaType<QPushButton*>();
 qRegisterMetaType<QTextEdit*>();

}

QEventLoop* RZ_QClasp_Object_Factory::new_QEventLoop()
{
 return new QEventLoop;
}

QMainWindow* RZ_QClasp_Object_Factory::new_QMainWindow()
{
 return new QMainWindow;
}

//?
//Qt_MainWindow* RZ_QClasp_Object_Factory::new_RZ__Clasp__Qt_MainWindow()
//{
// Qt_MainWindow* result = new Qt_MainWindow;
// return result;
//}

//?
//Http_Bridge* RZ_QClasp_Object_Factory::new_RZ__WebDb__Http_Bridge()
//{
// Http_Bridge* result = new Http_Bridge;
// return result;
//}


QPushButton* RZ_QClasp_Object_Factory::new_QPushButton()
{
 return new QPushButton;
}

RZ_Clasp_Invokable* RZ_QClasp_Object_Factory::new_RZ_Clasp_Invokable()
{
 return new RZ_Clasp_Invokable;
}

RZ_Clasp_Invokable* RZ_QClasp_Object_Factory::new_RZ__Clasp__RZ_Clasp_Invokable()
{
 return new RZ_Clasp_Invokable;
}

QLineEdit* RZ_QClasp_Object_Factory::new_QLineEdit()
{
 return new QLineEdit;
}

QVBoxLayout* RZ_QClasp_Object_Factory::new_QVBoxLayout()
{
 return new QVBoxLayout;
}

QHBoxLayout* RZ_QClasp_Object_Factory::new_QHBoxLayout()
{
 return new QHBoxLayout;
}

QGridLayout* RZ_QClasp_Object_Factory::new_QGridLayout()
{
 return new QGridLayout;
}

QWidget* RZ_QClasp_Object_Factory::new_QWidget()
{
 return new QWidget;
}

