
#ifndef RZ_QClasp_Object_Factory__H
#define RZ_QClasp_Object_Factory__H

#include <QString>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QMainWindow>
#include <QGridLayout>
#include <QLineEdit>
#include <QTextEdit>
#include <QEventLoop>

#include "rzns.h"

#include "accessors.h"

RZNS_(RZWebDb)

class Http_Bridge;

_RZNS(RZWebDb)


USING_RZNS(RZWebDb)


class PVC_Artist_Clasp_Interface;


// RZNS_(RZClasp)
namespace RZ { namespace RZClasp {

class RZ_Clasp_Eval;
class RZ_Clasp_Invokable;

//?class Qt_MainWindow;

class RZ_QClasp_Object_Factory  : public QObject
{
 Q_OBJECT


public:

 RZ_QClasp_Object_Factory();

 Q_INVOKABLE QMainWindow* new_QMainWindow();

//? Q_INVOKABLE Qt_MainWindow* new_RZ__Clasp__Qt_MainWindow();
//? Q_INVOKABLE Http_Bridge* new_RZ__WebDb__Http_Bridge();
//? Q_INVOKABLE PVC_Artist_Clasp_Interface* new_PVC_Artist_Clasp_Interface();

 Q_INVOKABLE QPushButton* new_QPushButton();
 Q_INVOKABLE QLineEdit* new_QLineEdit();
 Q_INVOKABLE QWidget* new_QWidget();

 Q_INVOKABLE QEventLoop* new_QEventLoop();

 Q_INVOKABLE QVBoxLayout* new_QVBoxLayout();
 Q_INVOKABLE QHBoxLayout* new_QHBoxLayout();
 Q_INVOKABLE QGridLayout* new_QGridLayout();

 Q_INVOKABLE RZ_Clasp_Invokable* new_RZ_Clasp_Invokable();

 Q_INVOKABLE RZ_Clasp_Invokable* new_RZ__Clasp__RZ_Clasp_Invokable();


};


_RZNS(RZClasp)



#endif
