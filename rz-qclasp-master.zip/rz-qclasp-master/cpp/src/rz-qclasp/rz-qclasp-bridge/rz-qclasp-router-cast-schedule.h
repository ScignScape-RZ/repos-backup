
#ifndef RZ_QCLASP_ROUTER_CAST_SCHEDULE__H
#define RZ_QCLASP_ROUTER_CAST_SCHEDULE__H


#define NO_CAST_ALL_VOID

#include <QtGlobal>

#include <QDebug>

#include <QDomDocument>

#include <functional>

#include "rz-qclasp-each/rz-qclasp-each.h"



#include "rzns.h"
#include "accessors.h"

#include "rz-qclasp-invoke-argument.h"
#include "rz-qclasp-router.h"


//?#include "rz-webdb/rz-webdb-pvc/silo-types/artist/pvc-artist-list.h"



USING_RZNS(RZClasp)


template<typename T>
void temp_test(T& tr);

template<>
void temp_test(void*& v)
{
 void* pv = v;
 RZ_QClasp_Each* rce = reinterpret_cast<RZ_QClasp_Each*>(pv);
 QString qs = rce->test_str();
 QString qs1 = rce->test_str();
}

template<typename T>
void temp_test_aa(T& tr);

template<>
void temp_test_aa(void*& v)
{
 void* pv = v;
 QMap<QString, QString>* qmm = reinterpret_cast<QMap<QString, QString>*>(pv);
 QMapIterator<QString, QString> it(*qmm);
 QString qs;
 QString qs1;
 while(it.hasNext())
 {
  it.next();
  qs = it.key();
  qs1 = it.value();
 }
}


RZNS_(RZClasp)


QObject* get_static_first_argument(const RZ_QClasp_Router::Argument_Info& ai,
   QString internal_type_name, QString& actual_method_name, const QMetaObject*& qmo)
{
 int metatype_id = ai.q_meta_type_id;
 qmo = QMetaType::metaObjectForType(metatype_id);
 QObject* result = qmo->newInstance();
 if(ai.mode == RZ_QClasp_Invoke_Argument::Sigma )
 {
  void* pv = ai.void_argument;
  QString method_signature = "hold_sigma(void*,QString)";
  int iom = qmo->indexOfMethod(method_signature.toLatin1());
  QMetaMethod qmm = qmo->method(iom);
  QString type_short_cut;
  qmm.invoke(result, QReturnArgument<QString>("QString", type_short_cut),
     QArgument<void*>("void*", pv), QArgument<QString>("QString", internal_type_name) );
  actual_method_name.prepend(type_short_cut);
 }
 return result;
}


struct Cast_Needed
{
};

struct No_Cast_Needed
{
};

template<typename T1>
struct Type_List__1
{
 typedef T1 Type1;
};

template<typename T1, typename T2>
struct Type_List__2
{
 typedef T1 Type1;
 typedef T2 Type2;
};

template<typename T1, typename T2, typename T3>
struct Type_List__3
{
 typedef T1 Type1;
 typedef T2 Type2;
 typedef T3 Type3;
};

template<typename T1, typename T2, typename T3, typename T4>
struct Type_List__4
{
 typedef T1 Type1;
 typedef T2 Type2;
 typedef T3 Type3;
 typedef T4 Type4;
};

template<typename T1, typename T2, typename T3, typename T4, typename T5>
struct Type_List__5
{
 typedef T1 Type1;
 typedef T2 Type2;
 typedef T3 Type3;
 typedef T4 Type4;
 typedef T5 Type5;
};

template<typename T1, typename T2, typename T3, typename T4, typename T5, typename T6>
struct Type_List__6
{
 typedef T1 Type1;
 typedef T2 Type2;
 typedef T3 Type3;
 typedef T4 Type4;
 typedef T5 Type5;
 typedef T6 Type6;
};

template<typename T1, typename T2, typename T3, typename T4,
         typename T5, typename T6, typename T7>
struct Type_List__7
{
 typedef T1 Type1;
 typedef T2 Type2;
 typedef T3 Type3;
 typedef T4 Type4;
 typedef T5 Type5;
 typedef T6 Type6;
 typedef T7 Type7;
};


template<typename Type_List_Type, int INTERCHANGE_Index, int TOTAL>
struct Interchange
{
};

template<typename Type_List_Type>
struct Interchange<Type_List_Type, 0, 1>
{
 template<typename INTERCHANGE_Type>
 struct With_Type
 {
  typedef Type_List__1<INTERCHANGE_Type> Result_Type;
 };
};


template<typename Type_List_Type>
struct Interchange<Type_List_Type, 0, 2>
{
 template<typename INTERCHANGE_Type>
 struct With_Type
 {
  typedef Type_List__2<INTERCHANGE_Type, typename Type_List_Type::Type2> Result_Type;
 };
};

template<typename Type_List_Type>
struct Interchange<Type_List_Type, 1, 2>
{
 template<typename INTERCHANGE_Type>
 struct With_Type
 {
  typedef Type_List__2<typename Type_List_Type::Type1, INTERCHANGE_Type> Result_Type;
 };
};

template<typename Type_List_Type>
struct Interchange<Type_List_Type, 0, 3>
{
 template<typename INTERCHANGE_Type>
 struct With_Type
 {
  typedef Type_List__3<INTERCHANGE_Type, typename Type_List_Type::Type2, typename Type_List_Type::Type3> Result_Type;
 };
};

template<typename Type_List_Type>
struct Interchange<Type_List_Type, 1, 3>
{
 template<typename INTERCHANGE_Type>
 struct With_Type
 {
  typedef Type_List__3<typename Type_List_Type::Type1, INTERCHANGE_Type, typename Type_List_Type::Type3> Result_Type;
 };
};

template<typename Type_List_Type>
struct Interchange<Type_List_Type, 2, 3>
{
 template<typename INTERCHANGE_Type>
 struct With_Type
 {
  typedef Type_List__3<typename Type_List_Type::Type1, typename Type_List_Type::Type2, INTERCHANGE_Type> Result_Type;
 };
};


template<typename Type_List_Type>
struct Interchange<Type_List_Type, 0, 4>
{
 template<typename INTERCHANGE_Type>
 struct With_Type
 {
  typedef Type_List__4<INTERCHANGE_Type, typename Type_List_Type::Type2,
    typename Type_List_Type::Type3, typename Type_List_Type::Type4> Result_Type;
 };
};

template<typename Type_List_Type>
struct Interchange<Type_List_Type, 1, 4>
{
 template<typename INTERCHANGE_Type>
 struct With_Type
 {
  typedef Type_List__4<typename Type_List_Type::Type1, INTERCHANGE_Type,
    typename Type_List_Type::Type3, typename Type_List_Type::Type4> Result_Type;
 };
};



template<typename Type_List_Type>
struct Interchange<Type_List_Type, 2, 4>
{
 template<typename INTERCHANGE_Type>
 struct With_Type
 {
  typedef Type_List__4<typename Type_List_Type::Type1, typename Type_List_Type::Type2,
    INTERCHANGE_Type, typename Type_List_Type::Type3> Result_Type;
 };
};

template<typename Type_List_Type>
struct Interchange<Type_List_Type, 3, 4>
{
 template<typename INTERCHANGE_Type>
 struct With_Type
 {
  typedef Type_List__4<typename Type_List_Type::Type1, typename Type_List_Type::Type2,
    typename Type_List_Type::Type3, INTERCHANGE_Type> Result_Type;
 };
};


// // 0 - 5

template<typename Type_List_Type>
struct Interchange<Type_List_Type, 0, 5>
{
 template<typename INTERCHANGE_Type>
 struct With_Type
{
  typedef Type_List__5<INTERCHANGE_Type, typename Type_List_Type::Type2,
    typename Type_List_Type::Type3, typename Type_List_Type::Type4,
    typename Type_List_Type::Type5> Result_Type;
 };
};

template<typename Type_List_Type>
struct Interchange<Type_List_Type, 1, 5>
{
 template<typename INTERCHANGE_Type>
 struct With_Type
 {
  typedef Type_List__5<typename Type_List_Type::Type1, INTERCHANGE_Type,
    typename Type_List_Type::Type3, typename Type_List_Type::Type4,
    typename Type_List_Type::Type5> Result_Type;
 };
};


template<typename Type_List_Type>
struct Interchange<Type_List_Type, 2, 5>
{
 template<typename INTERCHANGE_Type>
 struct With_Type
 {
  typedef Type_List__5<typename Type_List_Type::Type1,
    typename Type_List_Type::Type2, INTERCHANGE_Type,
    typename Type_List_Type::Type4, typename Type_List_Type::Type5> Result_Type;
 };
};

template<typename Type_List_Type>
struct Interchange<Type_List_Type, 3, 5>
{
 template<typename INTERCHANGE_Type>
 struct With_Type
 {
  typedef Type_List__5<typename Type_List_Type::Type1, typename Type_List_Type::Type2,
    typename Type_List_Type::Type3, INTERCHANGE_Type,
    typename Type_List_Type::Type5> Result_Type;
 };
};

template<typename Type_List_Type>
struct Interchange<Type_List_Type, 4, 5>
{
 template<typename INTERCHANGE_Type>
 struct With_Type
 {
  typedef Type_List__5<typename Type_List_Type::Type1,
    typename Type_List_Type::Type2,
    typename Type_List_Type::Type3, typename Type_List_Type::Type4, INTERCHANGE_Type> Result_Type;
 };
};



#define INTERCHANGE_0_TO_6
// 0 - 6
#ifdef INTERCHANGE_0_TO_6
template<typename Type_List_Type>
struct Interchange<Type_List_Type, 0, 6>
{
 template<typename INTERCHANGE_Type>
 struct With_Type
{
  typedef Type_List__6<INTERCHANGE_Type, typename Type_List_Type::Type2,
    typename Type_List_Type::Type3, typename Type_List_Type::Type4,
    typename Type_List_Type::Type5, typename Type_List_Type::Type6> Result_Type;
 };
};

template<typename Type_List_Type>
struct Interchange<Type_List_Type, 1, 6>
{
 template<typename INTERCHANGE_Type>
 struct With_Type
 {
  typedef Type_List__6<typename Type_List_Type::Type1, INTERCHANGE_Type,
    typename Type_List_Type::Type3, typename Type_List_Type::Type4,
    typename Type_List_Type::Type5, typename Type_List_Type::Type6> Result_Type;
 };
};


template<typename Type_List_Type>
struct Interchange<Type_List_Type, 2, 6>
{
 template<typename INTERCHANGE_Type>
 struct With_Type
 {
  typedef Type_List__6<typename Type_List_Type::Type1,
    typename Type_List_Type::Type2, INTERCHANGE_Type,
    typename Type_List_Type::Type4,
    typename Type_List_Type::Type5, typename Type_List_Type::Type6> Result_Type;
 };
};

template<typename Type_List_Type>
struct Interchange<Type_List_Type, 3, 6>
{
 template<typename INTERCHANGE_Type>
 struct With_Type
 {
  typedef Type_List__6<typename Type_List_Type::Type1,
    typename Type_List_Type::Type2,
    typename Type_List_Type::Type3,
    INTERCHANGE_Type,
    typename Type_List_Type::Type5,
    typename Type_List_Type::Type6

  > Result_Type;
 };
};

template<typename Type_List_Type>
struct Interchange<Type_List_Type, 4, 6>
{
 template<typename INTERCHANGE_Type>
 struct With_Type
 {
  typedef Type_List__6<typename Type_List_Type::Type1,
    typename Type_List_Type::Type2,
    typename Type_List_Type::Type3,
    typename Type_List_Type::Type4,
    INTERCHANGE_Type, typename Type_List_Type::Type6> Result_Type;
 };
};

template<typename Type_List_Type>
struct Interchange<Type_List_Type, 5, 6>
{
 template<typename INTERCHANGE_Type>
 struct With_Type
 {
  typedef Type_List__6<typename Type_List_Type::Type1,
    typename Type_List_Type::Type2,
    typename Type_List_Type::Type3,
    typename Type_List_Type::Type4, typename Type_List_Type::Type5,
    INTERCHANGE_Type> Result_Type;
 };
};

#endif //def INTERCHANGE_0_TO_6


#define INTERCHANGE_0_TO_7
// 0 - 7
#ifdef INTERCHANGE_0_TO_7

template<typename Type_List_Type>
struct Interchange<Type_List_Type, 0, 7>
{
 template<typename INTERCHANGE_Type>
 struct With_Type
{
  typedef Type_List__7<INTERCHANGE_Type, typename Type_List_Type::Type2,
    typename Type_List_Type::Type3, typename Type_List_Type::Type4,
    typename Type_List_Type::Type5,
    typename Type_List_Type::Type6, typename Type_List_Type::Type7> Result_Type;
 };
};

template<typename Type_List_Type>
struct Interchange<Type_List_Type, 1, 7>
{
 template<typename INTERCHANGE_Type>
 struct With_Type
 {
  typedef Type_List__7<typename Type_List_Type::Type1, INTERCHANGE_Type,
    typename Type_List_Type::Type3, typename Type_List_Type::Type4,
    typename Type_List_Type::Type5,
    typename Type_List_Type::Type6, typename Type_List_Type::Type7> Result_Type;
 };
};


template<typename Type_List_Type>
struct Interchange<Type_List_Type, 2, 7>
{
 template<typename INTERCHANGE_Type>
 struct With_Type
 {
  typedef Type_List__7<typename Type_List_Type::Type1,
    typename Type_List_Type::Type2, INTERCHANGE_Type,
    typename Type_List_Type::Type4,
    typename Type_List_Type::Type5,
    typename Type_List_Type::Type6, typename Type_List_Type::Type7> Result_Type;
 };
};

template<typename Type_List_Type>
struct Interchange<Type_List_Type, 3, 7>
{
 template<typename INTERCHANGE_Type>
 struct With_Type
 {
  typedef Type_List__7<typename Type_List_Type::Type1,
    typename Type_List_Type::Type2,
    typename Type_List_Type::Type3,
    INTERCHANGE_Type,
    typename Type_List_Type::Type5,
    typename Type_List_Type::Type6,
    typename Type_List_Type::Type7

  > Result_Type;
 };
};

template<typename Type_List_Type>
struct Interchange<Type_List_Type, 4, 7>
{
 template<typename INTERCHANGE_Type>
 struct With_Type
 {
  typedef Type_List__7<typename Type_List_Type::Type1,
    typename Type_List_Type::Type2,
    typename Type_List_Type::Type3,
    typename Type_List_Type::Type4,
     INTERCHANGE_Type,
    typename Type_List_Type::Type6, typename Type_List_Type::Type7
    > Result_Type;
 };
};


template<typename Type_List_Type>
struct Interchange<Type_List_Type, 5, 7>
{
 template<typename INTERCHANGE_Type>
 struct With_Type
 {
  typedef Type_List__7<typename Type_List_Type::Type1,
    typename Type_List_Type::Type2,
    typename Type_List_Type::Type3,
    typename Type_List_Type::Type4,
    typename Type_List_Type::Type5,
    INTERCHANGE_Type,
    typename Type_List_Type::Type7
    > Result_Type;
 };
};

template<typename Type_List_Type>
struct Interchange<Type_List_Type, 6, 7>
{
 template<typename INTERCHANGE_Type>
 struct With_Type
 {
  typedef Type_List__7<typename Type_List_Type::Type1,
    typename Type_List_Type::Type2,
    typename Type_List_Type::Type3,
    typename Type_List_Type::Type4, typename Type_List_Type::Type5,
    typename Type_List_Type::Type6,
    INTERCHANGE_Type> Result_Type;
 };
};
#endif // INTERCHANGE_0_TO_7




typedef Type_List__1<Cast_Needed> Type_List__1__All_Cast_Needed_Type;
typedef Type_List__2<Cast_Needed, Cast_Needed> Type_List__2__All_Cast_Needed_Type;
typedef Type_List__3<Cast_Needed, Cast_Needed, Cast_Needed> Type_List__3__All_Cast_Needed_Type;
typedef Type_List__4<Cast_Needed, Cast_Needed, Cast_Needed, Cast_Needed> Type_List__4__All_Cast_Needed_Type;

typedef Type_List__5<Cast_Needed,
  Cast_Needed, Cast_Needed, Cast_Needed, Cast_Needed> Type_List__5__All_Cast_Needed_Type;

typedef Type_List__6<Cast_Needed,
  Cast_Needed, Cast_Needed, Cast_Needed, Cast_Needed, Cast_Needed> Type_List__6__All_Cast_Needed_Type;

typedef Type_List__7<Cast_Needed,
  Cast_Needed, Cast_Needed, Cast_Needed, Cast_Needed, Cast_Needed, Cast_Needed>
  Type_List__7__All_Cast_Needed_Type;

template<int i>
struct Type_List__All_Cast_Needed
{

};

template<>
struct Type_List__All_Cast_Needed<0>
{
 typedef No_Cast_Needed Type;
};

template<>
struct Type_List__All_Cast_Needed<1>
{
 typedef Type_List__1__All_Cast_Needed_Type Type;
};

template<>
struct Type_List__All_Cast_Needed<2>
{
 typedef Type_List__2__All_Cast_Needed_Type Type;
};

template<>
struct Type_List__All_Cast_Needed<3>
{
 typedef Type_List__3__All_Cast_Needed_Type Type;
};

template<>
struct Type_List__All_Cast_Needed<4>
{
 typedef Type_List__4__All_Cast_Needed_Type Type;
};

template<>
struct Type_List__All_Cast_Needed<5>
{
 typedef Type_List__5__All_Cast_Needed_Type Type;
};

template<>
struct Type_List__All_Cast_Needed<6>
{
 typedef Type_List__6__All_Cast_Needed_Type Type;
};

template<>
struct Type_List__All_Cast_Needed<7>
{
 typedef Type_List__7__All_Cast_Needed_Type Type;
};

#ifdef NO_CAST_ALL_VOID
#define CASE_TEMP_MACRO_(INDEX, READY, INTERCHANGE_TYPE) \
 case INDEX: \
  Cast_##READY::run__av<OBJECT_Type> \
    (method_name, obj, next_cast_index, drr,  \
    argument_info, args);  \
  break;  \

#else
#define CASE_TEMP_MACRO_(INDEX, READY, INTERCHANGE_TYPE) \
 case INDEX: \
  Cast_##READY::run<OBJECT_Type, \
    typename Interchange<Type_List_Type, INDEX, READY>:: \
    template With_Type<INTERCHANGE_TYPE>::Result_Type>  \
    (method_name, obj, next_cast_index, drr,  \
    argument_info, args);  \
  break;  \

#endif


#ifdef NO_CAST_ALL_VOID

#define ARGS_TEMP_MACRO(INDEX) \
 void*& arg##INDEX = *reinterpret_cast<void**> \
  ( argument_info[INDEX].void_argument );

#define QARG_TEMP_MACRO(INDEX) QArgument<void*> \
  ( argument_info[INDEX].type_name_with_modifier(args[INDEX].modifier).toLatin1(), arg##INDEX) \

#define QARG_TEMP_MACRO_STRING_ACC(STR, INDEX) \
  STR += argument_info[INDEX].type_name_with_modifier(args[INDEX].modifier).toLatin1() + ","; \



#else

#define ARGS_TEMP_MACRO(INDEX) \
 typename Type_List_Type::Type##INDEX& arg##INDEX \
   = *reinterpret_cast<typename Type_List_Type::Type##INDEX*> \
    ( argument_info[INDEX].void_argument );

#define QARG_TEMP_MACRO(INDEX) QArgument<ARG##INDEX##_Type> \
  ( argument_info[INDEX].type_name_with_modifier(args[INDEX].modifier).toLatin1(), arg##INDEX) \

#define QARG_TEMP_MACRO_STRING_ACC(STR, INDEX) \
  STR += argument_info[INDEX].type_name_with_modifier(args[INDEX].modifier).toLatin1() + ","; \

#endif // NO_CAST_ALL_VOID



struct Do_Invoke_Method__Cast_Schedule
{
 // for testing expansions ...
#ifdef HIDE

#define CASE_TEMP_MACRO(INDEX, INTERCHANGE_TYPE) \
   CASE_TEMP_MACRO_(INDEX, 2, INTERCHANGE_TYPE)

#define CAST_INDEX_SWITCH(TYPE) \
   switch(cast_index) \
   { \
    CASE_TEMP_MACRO(0, TYPE) \
    CASE_TEMP_MACRO(1, TYPE) \
   } \

 struct Argument_Size_Too_Large{};

// template<int i>
// struct Cast_
// {
//  typedef Argument_Size_Too_Large Type;
// };

// #define CAST_TYPEDEF_MACRO(i)
//  template<> \
//  struct Cast_<1> \
//  { \
//   typedef Cast_1 Type; \
//  }; \



 struct Cast_2
 {
  static constexpr int ready_at_cast_index = 2;
  template<typename OBJECT_Type, typename Type_List_Type>
  static void run(QString method_name, OBJECT_Type obj,
    int cast_index, RZ_QClasp_Router& drr,
    QVector<RZ_QClasp_Router::Argument_Info>& argument_info,
    QList<RZ_QClasp_Invoke_Argument>& args)
  {
   if(cast_index == ready_at_cast_index)
   {
    switch(drr.return_type_code())
    {
    case RZ_QClasp_Router::Arg_Type_Codes::No_Return:
     {
      ARGS_TEMP_MACRO(1)
      ARGS_TEMP_MACRO(2)
      Cast_2_Ready::run(method_name, obj,
       args, arg1, arg2, argument_info);
     }
     break;
    case RZ_QClasp_Router::Arg_Type_Codes::Void_Pointer:
     {
      ARGS_TEMP_MACRO(1)
      ARGS_TEMP_MACRO(2)
      Cast_2_Ready::run(method_name, obj,
        drr.return_type_name_strip_namespace(),
        drr.object_result(),
        args, arg1, arg2, argument_info);
     }
     break;
    case RZ_QClasp_Router::Arg_Type_Codes::Int:
     {
      int& x = *reinterpret_cast<int*>(drr.object_result());
      ARGS_TEMP_MACRO(1)
      ARGS_TEMP_MACRO(2)
      Cast_2_Ready::run(method_name, obj,
        "int",
        x,
        args, arg1, arg2, argument_info);
     }
     break;
    case RZ_QClasp_Router::Arg_Type_Codes::QString_Return:
     {
      QString& qs = drr.string_result();
      ARGS_TEMP_MACRO(1)
      ARGS_TEMP_MACRO(2)
      Cast_2_Ready::run(method_name, obj,
       "QString", qs, args, arg1, arg2, argument_info);
     }
     break;
    }
   }
   else
   {
    int next_cast_index = cast_index + 1;
    RZ_QClasp_Router::Argument_Conventions ac =
      argument_info[next_cast_index].convention;
    switch(ac)
    {
    case RZ_QClasp_Router::Argument_Conventions::QString_Direct:
     {
      QString arg = args[next_cast_index].str;
      argument_info[next_cast_index].void_argument = &arg;
      argument_info[next_cast_index].type_name = "QString";
      CAST_INDEX_SWITCH(QString)
     }
     break;
    case RZ_QClasp_Router::Argument_Conventions::QMetaType_Confirmed:
     {
      const QMetaType* qmt = argument_info[next_cast_index].q_meta_type;
      int id = argument_info[next_cast_index].q_meta_type_id;
      QString type_name = QString::fromLatin1(QMetaType::typeName(id));
       //void* pv = qmt->create();
      void* pv = QMetaType::create(id);
      RZ_QClasp_Router::Arg_Type_Codes atc = RZ_QClasp_Router::lisp_to_q_meta_type(args[next_cast_index].object, pv);
      argument_info[next_cast_index].type_name = type_name;
      argument_info[next_cast_index].void_argument = pv;
      argument_info[next_cast_index].void_argument_for_delete = pv;
      switch(atc)
      {
      case RZ_QClasp_Router::Arg_Type_Codes::Int:
       CAST_INDEX_SWITCH(int)
       break;
      }
     }
     break;
    case RZ_QClasp_Router::Argument_Conventions::QVariant_Cast:
     {
      QVariant qvar = RZ_QClasp_Router::lisp_to_q_variant(args[next_cast_index].object);
      argument_info[next_cast_index].type_name = "QVariant";
      argument_info[next_cast_index].void_argument = &qvar;
      CAST_INDEX_SWITCH(QVariant)
     }
     break;
    case RZ_QClasp_Router::Argument_Conventions::QObject_Cast:
     {
      CAST_INDEX_SWITCH(QObject*)
     }
     break;
    }
   }
  }
 };

 struct Cast_2_Ready
 {
  template<typename OBJECT_Type, typename ARG1_Type, typename ARG2_Type>
  static void run(QString method_name, OBJECT_Type obj, QList<RZ_QClasp_Invoke_Argument>& args,
    ARG1_Type& arg1, ARG2_Type& arg2,
    const QVector<RZ_QClasp_Router::Argument_Info>& argument_info)
  {

   QString qs = argument_info[1].type_name_with_modifier(args[1].modifier).toLatin1();

   if(argument_info[0].convention == RZ_QClasp_Router::Argument_Conventions::Static_First_Argument)
   {
    int metatype_id = argument_info[0].q_meta_type_id;
    const QMetaObject* qmo = QMetaType::metaObjectForType(metatype_id);
    QString method_signature = method_name + '(';

    QARG_TEMP_MACRO_STRING_ACC(method_signature, 1)
    QARG_TEMP_MACRO_STRING_ACC(method_signature, 2)


     //?QARGUMENTS_STRING_ACC(method_signature);
    //QARG_TEMP_MACRO_STRING_ACC(method_signature, 1);
    if(method_signature.endsWith(','))
    {
     method_signature.chop(1);
    }
    method_signature += ')';
    int iom = qmo->indexOfMethod(method_signature.toLatin1());
    QMetaMethod qmm = qmo->method(iom);
    QObject* temp = qmo->newInstance();
    qmm.invoke(temp,
      QArgument<ARG1_Type>(argument_info[1].type_name_with_modifier(args[1].modifier).toLatin1(), arg1),
      QArgument<ARG2_Type>(argument_info[2].type_name_with_modifier(args[2].modifier).toLatin1(), arg2)
      );
    temp->deleteLater();
   }
   else
   {
    QMetaObject::invokeMethod(obj, method_name.toLatin1(),
      QArgument<ARG1_Type>(argument_info[1].type_name_with_modifier(args[1].modifier).toLatin1(), arg1),
      QArgument<ARG2_Type>(argument_info[2].type_name_with_modifier(args[2].modifier).toLatin1(), arg2));
   }
  }

  template<typename OBJECT_Type, typename RET_Type, typename ARG1_Type, typename ARG2_Type>
  static void run(QString method_name, OBJECT_Type obj,
    QString return_type, RET_Type& ret,
    QList<RZ_QClasp_Invoke_Argument>& args,
    ARG1_Type& arg1, ARG2_Type& arg2,
    const QVector<RZ_QClasp_Router::Argument_Info>& argument_info)
  {
   if(argument_info[0].convention == RZ_QClasp_Router::Argument_Conventions::Static_First_Argument)
   {
    int metatype_id = argument_info[0].q_meta_type_id;
    const QMetaObject* qmo = QMetaType::metaObjectForType(metatype_id);
    QString method_signature = method_name + '(';

    QARG_TEMP_MACRO_STRING_ACC(method_signature, 1)
    QARG_TEMP_MACRO_STRING_ACC(method_signature, 2)

     //?QARGUMENTS_STRING_ACC(method_signature);
    //QARG_TEMP_MACRO_STRING_ACC(method_signature, 1);
    if(method_signature.endsWith(','))
    {
     method_signature.chop(1);
    }
    method_signature += ')';
    int iom = qmo->indexOfMethod(method_signature.toLatin1());
    QMetaMethod qmm = qmo->method(iom);
    QObject* temp = qmo->newInstance();
    qmm.invoke(temp,
      QReturnArgument<RET_Type>(return_type.toLatin1(), ret),
      QArgument<ARG1_Type>(argument_info[1].type_name_with_modifier(args[1].modifier).toLatin1(), arg1),
      QArgument<ARG2_Type>(argument_info[2].type_name_with_modifier(args[2].modifier).toLatin1(), arg2)
      );
    temp->deleteLater();
   }
   else
   {
    QMetaObject::invokeMethod(obj, method_name.toLatin1(),
      QReturnArgument<RET_Type>(return_type.toLatin1(), ret),
      QArgument<ARG1_Type>(argument_info[1].type_name_with_modifier(args[1].modifier).toLatin1(), arg1),
      QArgument<ARG2_Type>(argument_info[2].type_name_with_modifier(args[2].modifier).toLatin1(), arg2));
   }
   qDebug() << "RET: " << ret;
  }
 };
//};
#endif //HIDE

 //CAST_TYPEDEF_MACRO(2)

#ifdef NO_CAST_ALL_VOID
#define CAST_READY_MACRO(ARG_COUNT) \
 struct Cast_##ARG_COUNT##_Ready \
 { \
  template<typename OBJECT_Type> \
  static void run(QString method_name, OBJECT_Type obj, QList<RZ_QClasp_Invoke_Argument>& args \
   TYPENAMES_arg,  const QVector<RZ_QClasp_Router::Argument_Info>& argument_info) \
  { \
   if(argument_info[0].convention == RZ_QClasp_Router::Argument_Conventions::Static_First_Argument) \
   { \
    QString actual_method_name = method_name; \
    QString ait = args[0].internal_type; \
    const QMetaObject* qmo; \
    QObject* temp = get_static_first_argument(argument_info[0],  \
      ait, actual_method_name, qmo);  \
    QString method_signature = actual_method_name + '('; \
    QARGUMENTS_STRING_ACC(method_signature); \
    if(method_signature.endsWith(',')) \
    { \
     method_signature.chop(1); \
    } \
    method_signature += ')'; \
    int iom = qmo->indexOfMethod(method_signature.toLatin1()); \
    QMetaMethod qmm = qmo->method(iom); \
    qmm.invoke(temp  QARGUMENTS); \
    temp->deleteLater(); \
   } \
   else \
   { \
    QMetaObject::invokeMethod(obj, method_name.toLatin1() \
     QARGUMENTS ); \
   } \
  } \
  template<typename OBJECT_Type, typename RET_Type> \
  static void run(QString method_name, OBJECT_Type obj, QString return_type, \
   RET_Type& ret, QList<RZ_QClasp_Invoke_Argument>& args \
   TYPENAMES_arg,  const QVector<RZ_QClasp_Router::Argument_Info>& argument_info) \
  { \
   if(argument_info[0].convention == RZ_QClasp_Router::Argument_Conventions::Static_First_Argument) \
   { \
    QString actual_method_name = method_name; \
    QString ait = args[0].internal_type; \
    const QMetaObject* qmo; \
    QObject* temp = get_static_first_argument(argument_info[0],  \
      ait, actual_method_name, qmo);  \
    QString method_signature = actual_method_name + '('; \
    QARGUMENTS_STRING_ACC(method_signature); \
    if(method_signature.endsWith(',')) \
    { \
     method_signature.chop(1); \
    } \
    method_signature += ')'; \
    int iom = qmo->indexOfMethod(method_signature.toLatin1()); \
    QMetaMethod qmm = qmo->method(iom); \
    qmm.invoke(temp ,QReturnArgument<RET_Type>(return_type.toLatin1(), ret)  QARGUMENTS); \
    temp->deleteLater(); \
   } \
   else \
   { \
    QMetaObject::invokeMethod(obj, method_name.toLatin1(), \
      QReturnArgument<RET_Type>(return_type.toLatin1(), ret) \
      QARGUMENTS  ); \
   } \
  } \
 }; \

#else
#define CAST_READY_MACRO(ARG_COUNT) \
 struct Cast_##ARG_COUNT##_Ready \
 { \
  template<typename OBJECT_Type  TYPENAMES_typename> \
  static void run(QString method_name, OBJECT_Type obj, QList<RZ_QClasp_Invoke_Argument>& args \
   TYPENAMES_arg,  const QVector<RZ_QClasp_Router::Argument_Info>& argument_info) \
  { \
   if(argument_info[0].convention == RZ_QClasp_Router::Argument_Conventions::Static_First_Argument) \
   { \
    int metatype_id = argument_info[0].q_meta_type_id; \
    const QMetaObject* qmo = QMetaType::metaObjectForType(metatype_id); \
    QString method_signature = method_name + '('; \
    QARGUMENTS_STRING_ACC(method_signature); \
    if(method_signature.endsWith(',')) \
    { \
     method_signature.chop(1); \
    } \
    method_signature += ')'; \
    int iom = qmo->indexOfMethod(method_signature.toLatin1()); \
    QMetaMethod qmm = qmo->method(iom); \
    QObject* temp = qmo->newInstance(); \
    qmm.invoke(temp  QARGUMENTS); \
    temp->deleteLater(); \
   } \
   else \
   { \
    QMetaObject::invokeMethod(obj, method_name.toLatin1() \
     QARGUMENTS ); \
   } \
  } \
  template<typename OBJECT_Type, typename RET_Type  TYPENAMES_typename> \
  static void run(QString method_name, OBJECT_Type obj, QString return_type, \
   RET_Type& ret, QList<RZ_QClasp_Invoke_Argument>& args \
   TYPENAMES_arg,  const QVector<RZ_QClasp_Router::Argument_Info>& argument_info) \
  { \
   if(argument_info[0].convention == RZ_QClasp_Router::Argument_Conventions::Static_First_Argument) \
   { \
    int metatype_id = argument_info[0].q_meta_type_id; \
    const QMetaObject* qmo = QMetaType::metaObjectForType(metatype_id); \
    QString method_signature = method_name + '('; \
    QARGUMENTS_STRING_ACC(method_signature); \
    if(method_signature.endsWith(',')) \
    { \
     method_signature.chop(1); \
    } \
    method_signature += ')'; \
    int iom = qmo->indexOfMethod(method_signature.toLatin1()); \
    QMetaMethod qmm = qmo->method(iom); \
    QObject* temp = qmo->newInstance(); \
    qmm.invoke(temp ,QReturnArgument<RET_Type>(return_type.toLatin1(), ret)  QARGUMENTS); \
    temp->deleteLater(); \
   } \
   else \
   { \
    QMetaObject::invokeMethod(obj, method_name.toLatin1(), \
      QReturnArgument<RET_Type>(return_type.toLatin1(), ret) \
      QARGUMENTS  ); \
   } \
  } \
 }; \

#endif // NO_CAST_ALL_VOID

#define CAST_STRUCT_START_MACRO(ARG_COUNT) \
 struct Cast_##ARG_COUNT \
 { \


#ifdef NO_CAST_ALL_VOID
#define CAST_STRUCT_RUN_MACRO(ARG_COUNT) \
  static constexpr int ready_at_cast_index = ARG_COUNT; \
  template<typename OBJECT_Type> \
  static void run__av(QString method_name, OBJECT_Type obj, \
    int cast_index, RZ_QClasp_Router& drr, \
    QVector<RZ_QClasp_Router::Argument_Info>& argument_info, \
    QList<RZ_QClasp_Invoke_Argument>& args) \
  { \

#else

#define CAST_STRUCT_RUN_MACRO(ARG_COUNT) \
  static constexpr int ready_at_cast_index = ARG_COUNT; \
  template<typename OBJECT_Type, typename Type_List_Type> \
  static void run(QString method_name, OBJECT_Type obj, \
    int cast_index, RZ_QClasp_Router& drr, \
    QVector<RZ_QClasp_Router::Argument_Info>& argument_info, \
    QList<RZ_QClasp_Invoke_Argument>& args) \
  { \

#endif // NO_CAST_ALL_VOID

#define CAST_READY_SWITCH_MACRO(ARG_COUNT) \
   switch(drr.return_type_code()) \
   { \
   case RZ_QClasp_Router::Arg_Type_Codes::No_Return: \
    { \
     ARGS_TEMP_MACROS \
     Cast_##ARG_COUNT##_Ready::run(method_name, obj, args  ARGUMENTS, argument_info); \
    } \
    break; \
   case RZ_QClasp_Router::Arg_Type_Codes::Void_Pointer: \
    { \
     ARGS_TEMP_MACROS \
     Cast_##ARG_COUNT##_Ready::run(method_name, obj, \
       drr.return_type_name_strip_namespace(), \
       drr.object_result(), \
       args  ARGUMENTS, argument_info); \
     } \
    break; \
   case RZ_QClasp_Router::Arg_Type_Codes::Int: \
    { \
     int& x = *reinterpret_cast<int*>(drr.object_result()); \
     ARGS_TEMP_MACROS \
     Cast_##ARG_COUNT##_Ready::run(method_name, obj, \
      "int", x, args  ARGUMENTS, argument_info); \
    } \
    break; \
   case RZ_QClasp_Router::Arg_Type_Codes::QReal: \
    { \
     qreal& x = *reinterpret_cast<qreal*>(drr.object_result()); \
     ARGS_TEMP_MACROS \
     Cast_##ARG_COUNT##_Ready::run(method_name, obj, \
      "qreal", x, args  ARGUMENTS, argument_info); \
    } \
    break; \
   case RZ_QClasp_Router::Arg_Type_Codes::QString_Return: \
    { \
     QString& qs = drr.string_result(); \
     ARGS_TEMP_MACROS \
     Cast_##ARG_COUNT##_Ready::run(method_name, obj, \
      "QString", qs, args  ARGUMENTS, argument_info); \
    } \
    break; \
   } \


//? or CAST_INDEX_SWITCH(QString) on  QString_Direct?
//? or CAST_INDEX_SWITCH(int) on  Arg_Type_Codes::Int?
//? or CAST_INDEX_SWITCH(QVariant) on  QVariant_Cast?
//? or CAST_INDEX_SWITCH(QObject*) on  QObject_Direct,
    // QObject_Cast, Void_Ptr_Ptr, Void_Ptr_To_Value?

#define CAST_SWITCH_MACRO(ARG_COUNT) \
   else \
   { \
    int next_cast_index = cast_index + 1; \
    RZ_QClasp_Router::Argument_Conventions ac = \
      argument_info[next_cast_index].convention; \
    switch(ac) \
    { \
    case RZ_QClasp_Router::Argument_Conventions::QString_Direct: \
     { \
      QString& arg = args[next_cast_index].str; \
      argument_info[next_cast_index].void_argument = &arg; \
      argument_info[next_cast_index].type_name = "QString"; \
      CAST_INDEX_SWITCH(void*) \
     } \
     break; \
    case RZ_QClasp_Router::Argument_Conventions::QMetaType_Confirmed: \
     { \
      const QMetaType* qmt = argument_info[next_cast_index].q_meta_type; \
      int id = argument_info[next_cast_index].q_meta_type_id; \
      QString type_name = QString::fromLatin1(QMetaType::typeName(id)); \
      void* pv = qmt->create(); \
      RZ_QClasp_Router::Arg_Type_Codes atc = \
       RZ_QClasp_Router::lisp_to_q_meta_type(args[next_cast_index].object, pv); \
      argument_info[next_cast_index].type_name = type_name; \
      argument_info[next_cast_index].void_argument = pv; \
      argument_info[next_cast_index].void_argument_for_delete = pv; \
      switch(atc) \
      { \
      case RZ_QClasp_Router::Arg_Type_Codes::Int: \
       CAST_INDEX_SWITCH(void*) \
       break; \
        \
      case RZ_QClasp_Router::Arg_Type_Codes::QReal: \
       CAST_INDEX_SWITCH(void*) \
       break; \
      } \
     } \
     break; \
    case RZ_QClasp_Router::Argument_Conventions::QVariant_Cast: \
     { \
      QVariant qvar = RZ_QClasp_Router::lisp_to_q_variant(args[next_cast_index].object); \
      argument_info[next_cast_index].type_name = "QVariant"; \
      argument_info[next_cast_index].void_argument = &qvar; \
      CAST_INDEX_SWITCH(void*) \
     } \
     break; \
    case RZ_QClasp_Router::Argument_Conventions::QObject_Cast: \
     { \
      CAST_INDEX_SWITCH(void*) \
     } \
     break; \
    case RZ_QClasp_Router::Argument_Conventions::QObject_Direct: \
     { \
      CAST_INDEX_SWITCH(void*) \
     } \
     break; \
    case RZ_QClasp_Router::Argument_Conventions::Void_Ptr_To_Value: \
     { \
      QString tn = args[next_cast_index].internal_type; \
      int index = tn.indexOf(':'); \
      if(index != -1) \
      { \
       tn = tn.mid(index + 1); \
      } \
      argument_info[next_cast_index].type_name = tn; \
      argument_info[next_cast_index].void_argument = args[next_cast_index].object; \
      CAST_INDEX_SWITCH(void*) \
     } \
     break; \
    case RZ_QClasp_Router::Argument_Conventions::Void_Ptr_Ptr: \
     { \
      QString tn = args[next_cast_index].internal_type; \
      int index = tn.indexOf(':'); \
      if(index != -1) \
      { \
       tn = tn.mid(index + 1); \
      } \
      argument_info[next_cast_index].type_name = tn; \
      argument_info[next_cast_index].void_argument = &args[next_cast_index].object; \
      CAST_INDEX_SWITCH(void*) \
     } \
     break; \
    } \
   }\



#define CAST_STRUCT_END_MACRO } };



#define TEMP_MACRO(ARG_COUNT) \
 CAST_READY_MACRO(ARG_COUNT) \
 CAST_STRUCT_START_MACRO(ARG_COUNT) \
 CAST_STRUCT_RUN_MACRO(ARG_COUNT) \
 if(cast_index == ready_at_cast_index) \
 { \
  CAST_READY_SWITCH_MACRO(ARG_COUNT) \
 } \
 CAST_SWITCH_MACRO(ARG_COUNT) \
 CAST_STRUCT_END_MACRO


// special case for ARG_COUNT = 0

#define TEMP_MACRO_0 \
 CAST_READY_MACRO(0) \
 CAST_STRUCT_START_MACRO(0) \
 CAST_STRUCT_RUN_MACRO(0) \
 \
  CAST_READY_SWITCH_MACRO(0) \
 \
 \
 CAST_STRUCT_END_MACRO









 // for arg count 0



 #define TYPENAMES_typename
 #define TYPENAMES_arg
 #define QARGUMENTS
 #define QARGUMENTS_STRING_ACC

 #define ARGUMENTS

 #define ARGS_TEMP_MACROS


// CAST_READY_MACRO(0)

// //   Again, for testing expansions ...
#ifdef HIDE
 struct Cast_0_Ready
 {
  template<typename OBJECT_Type>
  static void run(QString method_name, OBJECT_Type obj, QList<RZ_QClasp_Invoke_Argument>& args
   TYPENAMES_arg,  const QVector<RZ_QClasp_Router::Argument_Info>& argument_info)
  {
   if(argument_info[0].convention == RZ_QClasp_Router::Argument_Conventions::Static_First_Argument)
   {
    QString actual_method_name = method_name;
    QString ait = args[0].internal_type;
    const QMetaObject* qmo;
    QObject* temp = get_static_first_argument(argument_info[0],
      ait, actual_method_name, qmo);
    QString method_signature = actual_method_name + '(';
    QARGUMENTS_STRING_ACC(method_signature);
    if(method_signature.endsWith(','))
    {
     method_signature.chop(1);
    }
    method_signature += ')';
    int iom = qmo->indexOfMethod(method_signature.toLatin1());
    QMetaMethod qmm = qmo->method(iom);
    qmm.invoke(temp  QARGUMENTS);
    temp->deleteLater();

   }
   else
   {
    QMetaObject::invokeMethod(obj, method_name.toLatin1()
     QARGUMENTS );
   }
  }
  template<typename OBJECT_Type, typename RET_Type>
  static void run(QString method_name, OBJECT_Type obj, QString return_type,
   RET_Type& ret, QList<RZ_QClasp_Invoke_Argument>& args
   TYPENAMES_arg,  const QVector<RZ_QClasp_Router::Argument_Info>& argument_info)
  {
   if(argument_info[0].convention == RZ_QClasp_Router::Argument_Conventions::Static_First_Argument)
   {
    QString actual_method_name = method_name;
    QString ait = args[0].internal_type;
    const QMetaObject* qmo;
    QObject* temp = get_static_first_argument(argument_info[0],
      ait, actual_method_name, qmo);
    QString method_signature = actual_method_name + '(';
    QARGUMENTS_STRING_ACC(method_signature);
    if(method_signature.endsWith(','))
    {
     method_signature.chop(1);
    }
    method_signature += ')';
    int iom = qmo->indexOfMethod(method_signature.toLatin1());
    QMetaMethod qmm = qmo->method(iom);
    qmm.invoke(temp ,QReturnArgument<RET_Type>(return_type.toLatin1(), ret)  QARGUMENTS);
    temp->deleteLater();
   }
   else
   {
    QMetaObject::invokeMethod(obj, method_name.toLatin1(),
      QReturnArgument<RET_Type>(return_type.toLatin1(), ret)
      QARGUMENTS  );
   }
  }
 };
#endif

TEMP_MACRO_0


#ifdef HIDE
 // CAST_READY_MACRO(0)
 struct Cast_0_Ready
 {
  template<typename OBJECT_Type  TYPENAMES_typename>
    static void run(QString method_name, OBJECT_Type obj, QList<RZ_QClasp_Invoke_Argument>& args,
      TYPENAMES_arg  const QVector<RZ_QClasp_Router::Argument_Info>& argument_info)
  {
   QMetaObject::invokeMethod(obj, method_name.toLatin1()
       QARGUMENTS  );
  }

// CAST_STRUCT_START_MACRO(0)

  template<typename OBJECT_Type, typename RET_Type  TYPENAMES_typename>
  static void run(QString method_name, OBJECT_Type obj, QString return_type,
    RET_Type& ret, QList<RZ_QClasp_Invoke_Argument>& args
    TYPENAMES_arg,  const QVector<RZ_QClasp_Router::Argument_Info>& argument_info)
  {
   QMetaObject::invokeMethod(obj, method_name.toLatin1(),
        QReturnArgument<RET_Type>(return_type.toLatin1(), ret)
        QARGUMENTS );
  }
 };


 struct Cast_0
 {
  static constexpr int ready_at_cast_index = 0;
  template<typename OBJECT_Type, typename Type_List_Type>
  static void run(QString method_name, OBJECT_Type obj,
    int cast_index, RZ_QClasp_Router& drr,
    QVector<RZ_QClasp_Router::Argument_Info>& argument_info,
    QList<RZ_QClasp_Invoke_Argument>& args)
  {

// CAST_READY_SWITCH_MACRO(0)
   switch(drr.return_type_code())
   {
   case RZ_QClasp_Router::Arg_Type_Codes::No_Return:
    {
     ARGS_TEMP_MACROS
     Cast_0_Ready::run(method_name, obj, args  ARGUMENTS,  argument_info);
    }
    break;
   case RZ_QClasp_Router::Arg_Type_Codes::Void_Pointer:
    {
     ARGS_TEMP_MACROS
     Cast_0_Ready::run(method_name, obj,
       drr.return_type_name_strip_namespace(),
       drr.object_result(),
       args  ARGUMENTS, argument_info);
    }
    break;
   case RZ_QClasp_Router::Arg_Type_Codes::Int:
    {
     int& x = *reinterpret_cast<int*>(drr.object_result());
     ARGS_TEMP_MACROS
     Cast_0_Ready::run(method_name, obj,
      "int", x, args  ARGUMENTS, argument_info);
    }
    break;
   case RZ_QClasp_Router::Arg_Type_Codes::QString_Return:
    {
     QString& qs = drr.string_result();
     ARGS_TEMP_MACROS
     Cast_0_Ready::run(method_name, obj,
      "QString", qs, args  ARGUMENTS, argument_info);
    }
    break;
   }
// CAST_STRUCT_END_MACRO
  }};

#endif
 #undef TYPENAMES_typename
 #undef TYPENAMES_arg
 #undef ARGS_TEMP_MACROS
 #undef CASE_TEMP_MACROS
 #undef ARGUMENTS
 #undef QARGUMENTS

 // end arg count 0







// for arg count 1

#ifdef NO_CAST_ALL_VOID
#define TYPENAMES_typename
#define TYPENAMES_arg ,void*& arg1
#define QARGUMENTS  \
 ,QARG_TEMP_MACRO(1) \

#define QARGUMENTS_STRING_ACC(STR)  \
 QARG_TEMP_MACRO_STRING_ACC(STR, 1)


#define ARGUMENTS   ,arg1

#define CASE_TEMP_MACRO(INDEX, INTERCHANGE_TYPE) \
   CASE_TEMP_MACRO_(INDEX, 1, INTERCHANGE_TYPE)

#define CAST_INDEX_SWITCH(TYPE) \
   switch(cast_index) \
   { \
    CASE_TEMP_MACRO(0, TYPE) \
   } \

#define ARGS_TEMP_MACROS \
 ARGS_TEMP_MACRO(1) \


#else
#define TYPENAMES_typename ,typename ARG1_Type
#define TYPENAMES_arg ,ARG1_Type& arg1
#define QARGUMENTS  \
 ,QARG_TEMP_MACRO(1) \

#define QARGUMENTS_STRING_ACC(STR)  \
 QARG_TEMP_MACRO_STRING_ACC(STR, 1)


#define ARGUMENTS   ,arg1

#define CASE_TEMP_MACRO(INDEX, INTERCHANGE_TYPE) \
   CASE_TEMP_MACRO_(INDEX, 1, INTERCHANGE_TYPE)

#define CAST_INDEX_SWITCH(TYPE) \
   switch(cast_index) \
   { \
    CASE_TEMP_MACRO(0, TYPE) \
   } \


#define ARGS_TEMP_MACROS \
 ARGS_TEMP_MACRO(1) \

#endif

 TEMP_MACRO(1)

#ifdef HIDE
 struct Cast_1_Ready
 {
  template<typename OBJECT_Type  ,typename ARG1_Type>
  static void run(QString method_name, OBJECT_Type obj, QList<RZ_QClasp_Invoke_Argument>& args
   ,ARG1_Type& arg1,  const QVector<RZ_QClasp_Router::Argument_Info>& argument_info)
  {
   QString qs = argument_info[1].type_name_with_modifier(args[1].modifier).toLatin1();

   if(argument_info[0].convention == RZ_QClasp_Router::Argument_Conventions::Static_First_Argument)
   {
    int metatype_id = argument_info[0].q_meta_type_id;
    const QMetaObject* qmo = QMetaType::metaObjectForType(metatype_id);
    QString method_signature = method_name + '(';
    QARGUMENTS_STRING_ACC(method_signature);
    if(method_signature.endsWith(','))
    {
     method_signature.chop(1);
    }
    method_signature += ')';
    int iom = qmo->indexOfMethod(method_signature.toLatin1());
    QMetaMethod qmm = qmo->method(iom);
    QObject* temp = qmo->newInstance();
    qmm.invoke(temp  QARGUMENTS);
    temp->deleteLater();
   }
   else
   {
    QMetaObject::invokeMethod(obj, method_name.toLatin1()
     QARGUMENTS );
   }

  }
  template<typename OBJECT_Type, typename RET_Type, typename ARG1_Type>
  static void run(QString method_name, OBJECT_Type obj, QString return_type,
   RET_Type& ret, QList<RZ_QClasp_Invoke_Argument>& args
   ,ARG1_Type& arg1, const QVector<RZ_QClasp_Router::Argument_Info>& argument_info)
  {
   QByteArray qba = argument_info[1].type_name_with_modifier(args[1].modifier).toLatin1();

   QMetaObject::invokeMethod(obj, method_name.toLatin1(),
    QReturnArgument<RET_Type>(return_type.toLatin1(), ret),
    QArgument<ARG1_Type>
     (
      qba, arg1)
     );

  }
 };

 struct Cast_1
 {

//? CAST_STRUCT_START_MACRO(1)
//? CAST_STRUCT_RUN_MACRO(1)

 static constexpr int ready_at_cast_index = 1;
 template<typename OBJECT_Type, typename Type_List_Type>
 static void run(QString method_name, OBJECT_Type obj,
   int cast_index, RZ_QClasp_Router& drr,
   QVector<RZ_QClasp_Router::Argument_Info>& argument_info,
   QList<RZ_QClasp_Invoke_Argument>& args)
 {



 if(cast_index == ready_at_cast_index)
 {
  //?CAST_READY_SWITCH_MACRO(1)

  switch(drr.return_type_code())
  {
  case RZ_QClasp_Router::Arg_Type_Codes::No_Return:
   {
    ARGS_TEMP_MACROS
    Cast_1_Ready::run(method_name, obj, args  ARGUMENTS, argument_info);
   }
   break;
  case RZ_QClasp_Router::Arg_Type_Codes::Void_Pointer:
   {
    ARGS_TEMP_MACROS
    Cast_1_Ready::run(method_name, obj,
      drr.return_type_name_strip_namespace(),
      drr.object_result(),
      args  ARGUMENTS, argument_info);
    }
   break;
  case RZ_QClasp_Router::Arg_Type_Codes::Int:
   {
    int& x = *reinterpret_cast<int*>(drr.object_result());
    ARGS_TEMP_MACROS
    Cast_1_Ready::run(method_name, obj,
     "int", x, args  ARGUMENTS, argument_info);
   }
   break;
  case RZ_QClasp_Router::Arg_Type_Codes::QString_Return:
   {
    QString& qs = drr.string_result();
    typename Type_List_Type::Type1& arg1
      = *reinterpret_cast<typename Type_List_Type::Type1*>
       ( argument_info[1].void_argument );
    Cast_1_Ready::run(method_name, obj,
     "QString", qs, args  ,arg1, argument_info);

   }
   break;
  }
 }

 else
 {
  int next_cast_index = cast_index + 1;
  RZ_QClasp_Router::Argument_Conventions ac =
    argument_info[next_cast_index].convention;
  switch(ac)
  {
  case RZ_QClasp_Router::Argument_Conventions::QString_Direct:
   {
    QString& arg = args[next_cast_index].str;
    argument_info[next_cast_index].void_argument = &arg;
    argument_info[next_cast_index].type_name = "QString";
    CAST_INDEX_SWITCH(QString)
   }
   break;
  case RZ_QClasp_Router::Argument_Conventions::QMetaType_Confirmed:
   {
    const QMetaType* qmt = argument_info[next_cast_index].q_meta_type;
    int id = argument_info[next_cast_index].q_meta_type_id;
    QString type_name = QString::fromLatin1(QMetaType::typeName(id));
    void* pv = qmt->create();
    RZ_QClasp_Router::Arg_Type_Codes atc =
     RZ_QClasp_Router::lisp_to_q_meta_type(args[next_cast_index].object, pv);
    argument_info[next_cast_index].type_name = type_name;
    argument_info[next_cast_index].void_argument = pv;
    argument_info[next_cast_index].void_argument_for_delete = pv;
    switch(atc)
    {
    case RZ_QClasp_Router::Arg_Type_Codes::Int:
     CAST_INDEX_SWITCH(int)
     break;
    }
   }
   break;
  case RZ_QClasp_Router::Argument_Conventions::QVariant_Cast:
   {
    QVariant qvar = RZ_QClasp_Router::lisp_to_q_variant(args[next_cast_index].object);
    argument_info[next_cast_index].type_name = "QVariant";
    argument_info[next_cast_index].void_argument = &qvar;
    CAST_INDEX_SWITCH(QVariant)
   }
   break;
  case RZ_QClasp_Router::Argument_Conventions::QObject_Cast:
   {
    CAST_INDEX_SWITCH(QObject*)
   }
   break;
  case RZ_QClasp_Router::Argument_Conventions::QObject_Direct:
   {
    CAST_INDEX_SWITCH(QObject*)
   }
   break;
  case RZ_QClasp_Router::Argument_Conventions::Void_Ptr_To_Value:
   {
    QString tn = args[next_cast_index].internal_type;
    int index = tn.indexOf(':');
    if(index != -1)
    {
     tn = tn.mid(index + 1);
    }
    argument_info[next_cast_index].type_name = tn;
    argument_info[next_cast_index].void_argument = args[next_cast_index].object;
    switch(cast_index)
    {
    case 0:
     if(method_name == "each")
     {
      void* pv = argument_info[1].void_argument;
      temp_test(pv);
     }
     else if(method_name == "add_artist_from_qmap")
     {
      void* pv = argument_info[1].void_argument;
      temp_test_aa(pv);
     }


     Cast_1::run<QObject*,
       typename Interchange<Type_List_Type, 0, 1>::
       template With_Type<void*>::Result_Type>
       (method_name, obj, next_cast_index, drr,
       argument_info, args);
     break;

    }
//    CAST_INDEX_SWITCH(void*)
   }
   break;
  case RZ_QClasp_Router::Argument_Conventions::Void_Ptr_Ptr:
   {
    //?QString tn = argument_info[next_cast_index].type_name;
    QString tn = args[next_cast_index].internal_type;
    int index = tn.indexOf(':');
    if(index != -1)
    {
     tn = tn.mid(index + 1);
    }
    argument_info[next_cast_index].type_name = tn;
    argument_info[next_cast_index].void_argument = &args[next_cast_index].object;
    switch(cast_index)
    {
    case 0:
     if(method_name == "each")
     {
      void* pv = argument_info[1].void_argument;
     }
     else if(method_name == "add_artist_from_qmap")
     {
      void* pv = argument_info[1].void_argument;
     }

     Cast_1::run<QObject*,
       typename Interchange<Type_List_Type, 0, 1>::
       template With_Type<void*>::Result_Type>
       (method_name, obj, next_cast_index, drr,
       argument_info, args);
     break;

    }
//    CAST_INDEX_SWITCH(void*)
   }
   break;
  }
 }

 //?CAST_SWITCH_MACRO(1)
 CAST_STRUCT_END_MACRO

  #endif //def HIDE




#undef ARGS_TEMP_MACROS
#undef CASE_TEMP_MACROS
#undef ARGUMENTS
#undef QARGUMENTS

// end arg count 1




   // For ARG_COUNT 2
//#define CASE_TEMP_MACRO(INDEX, TYPE) CASE_TEMP_MACRO_(INDEX, 2, TYPE)

#ifdef NO_CAST_ALL_VOID

  #define TYPENAMES_typename
  #define TYPENAMES_arg ,void*& arg1 ,void*& arg2
  #define QARGUMENTS  \
   ,QARG_TEMP_MACRO(1) \
   ,QARG_TEMP_MACRO(2) \


  #define QARGUMENTS_STRING_ACC(STR)  \
     QARG_TEMP_MACRO_STRING_ACC(STR, 1) \
     QARG_TEMP_MACRO_STRING_ACC(STR, 2) \


  #define ARGUMENTS   ,arg1, arg2

  #define CASE_TEMP_MACRO(INDEX, INTERCHANGE_TYPE) \
     CASE_TEMP_MACRO_(INDEX, 2, INTERCHANGE_TYPE)

  #define CAST_INDEX_SWITCH(TYPE) \
     switch(cast_index) \
     { \
      CASE_TEMP_MACRO(0, TYPE) \
      CASE_TEMP_MACRO(1, TYPE) \
     } \

  #define ARGS_TEMP_MACROS \
   ARGS_TEMP_MACRO(1) \
   ARGS_TEMP_MACRO(2) \


#else

  #define TYPENAMES_typename ,typename ARG1_Type, typename ARG2_Type
  #define TYPENAMES_arg ,ARG1_Type& arg1, ARG2_Type& arg2
  #define QARGUMENTS  \
   ,QARG_TEMP_MACRO(1) \
   ,QARG_TEMP_MACRO(2) \


  #define QARGUMENTS_STRING_ACC(STR)  \
     QARG_TEMP_MACRO_STRING_ACC(STR, 1) \
     QARG_TEMP_MACRO_STRING_ACC(STR, 2) \


  #define ARGUMENTS   ,arg1, arg2

  #define CASE_TEMP_MACRO(INDEX, INTERCHANGE_TYPE) \
     CASE_TEMP_MACRO_(INDEX, 2, INTERCHANGE_TYPE)

  #define CAST_INDEX_SWITCH(TYPE) \
     switch(cast_index) \
     { \
      CASE_TEMP_MACRO(0, TYPE) \
      CASE_TEMP_MACRO(1, TYPE) \
     } \

  #define ARGS_TEMP_MACROS \
   ARGS_TEMP_MACRO(1) \
   ARGS_TEMP_MACRO(2) \

#endif // NO_CAST_ALL_VOID

   TEMP_MACRO(2)

#undef ARGS_TEMP_MACROS
#undef CASE_TEMP_MACROS
#undef ARGUMENTS
#undef QARGUMENTS


#ifdef NO_CAST_ALL_VOID

#define TYPENAMES_typename
#define TYPENAMES_arg ,void*& arg1, void*&  arg2, void*& arg3

#else

  #define TYPENAMES_typename ,typename ARG1_Type, typename ARG2_Type, typename ARG3_Type
  #define TYPENAMES_arg ,ARG1_Type& arg1, ARG2_Type& arg2, ARG3_Type& arg3

#endif

#define QARGUMENTS  \
 ,QARG_TEMP_MACRO(1) \
 ,QARG_TEMP_MACRO(2) \
 ,QARG_TEMP_MACRO(3) \


#define QARGUMENTS_STRING_ACC(STR)  \
   QARG_TEMP_MACRO_STRING_ACC(STR, 1) \
   QARG_TEMP_MACRO_STRING_ACC(STR, 2) \
   QARG_TEMP_MACRO_STRING_ACC(STR, 3) \


#define ARGUMENTS   ,arg1, arg2, arg3

#define CASE_TEMP_MACRO(INDEX, INTERCHANGE_TYPE) \
   CASE_TEMP_MACRO_(INDEX, 3, INTERCHANGE_TYPE)

#define CAST_INDEX_SWITCH(TYPE) \
   switch(cast_index) \
   { \
    CASE_TEMP_MACRO(0, TYPE) \
    CASE_TEMP_MACRO(1, TYPE) \
    CASE_TEMP_MACRO(2, TYPE) \
   } \



#define ARGS_TEMP_MACROS \
 ARGS_TEMP_MACRO(1) \
 ARGS_TEMP_MACRO(2) \
 ARGS_TEMP_MACRO(3) \

   TEMP_MACRO(3)


#ifdef HIDE
//CAST_READY_MACRO(3)

struct Cast_3_Ready
{
 template<typename OBJECT_Type  TYPENAMES_typename>
 static void run(QString method_name, OBJECT_Type obj, QList<RZ_QClasp_Invoke_Argument>& args
  ,ARG1_Type arg1, ARG2_Type arg2, ARG3_Type& arg3,  const QVector<RZ_QClasp_Router::Argument_Info>& argument_info)
 {
  QString tn3  = argument_info[3].type_name_with_modifier(args[3].modifier);

  QMetaObject::invokeMethod(obj, method_name.toLatin1()
   ,QARG_TEMP_MACRO(1),
    QARG_TEMP_MACRO(2),

    QArgument<ARG3_Type>
    ( tn3.toLatin1(), arg3)
                       );

  ARG3_Type a3 = arg3;
  ARG2_Type a2 = arg2;
  ARG1_Type a1 = arg1;


 }
 template<typename OBJECT_Type, typename RET_Type  TYPENAMES_typename>
 static void run(QString method_name, OBJECT_Type obj, QString return_type,
  RET_Type& ret, QList<RZ_QClasp_Invoke_Argument>& args
  TYPENAMES_arg,  const QVector<RZ_QClasp_Router::Argument_Info>& argument_info)
 {
  QMetaObject::invokeMethod(obj, method_name.toLatin1(),
   QReturnArgument<RET_Type>(return_type.toLatin1(), ret)
   QARGUMENTS  );
 }
};

CAST_STRUCT_START_MACRO(3)
CAST_STRUCT_RUN_MACRO(3)
if(cast_index == ready_at_cast_index)
{
 //?CAST_READY_SWITCH_MACRO(3)

   switch(drr.return_type_code())
   {
   case RZ_QClasp_Router::Arg_Type_Codes::No_Return:
    {
     ARGS_TEMP_MACRO(1)
     ARGS_TEMP_MACRO(2)

    typename Type_List_Type::Type3& arg3
      = *reinterpret_cast<typename Type_List_Type::Type3*>
       ( argument_info[3].void_argument );

     Cast_3_Ready::run(method_name, obj, args  ,arg1, arg2, arg3, argument_info);

     typename Type_List_Type::Type3& arg3a
       = *reinterpret_cast<typename Type_List_Type::Type3*>
        ( argument_info[3].void_argument );

     typename Type_List_Type::Type3& arg3b = arg3;

     typename Type_List_Type::Type3 arg3aa = arg3a;
     typename Type_List_Type::Type3 arg3ab = arg3;

    }
    break;
   case RZ_QClasp_Router::Arg_Type_Codes::Void_Pointer:
    {
     ARGS_TEMP_MACROS
     Cast_3_Ready::run(method_name, obj,
       drr.return_type_name_strip_namespace(),
       drr.object_result(),
       args  ,arg1, arg2, arg3,  argument_info);
     }
    break;
   case RZ_QClasp_Router::Arg_Type_Codes::Int:
    { \
     int& x = *reinterpret_cast<int*>(drr.object_result());
     ARGS_TEMP_MACROS
     Cast_3_Ready::run(method_name, obj,
      "int", x, args  ,arg1, arg2, arg3,  argument_info);
    }
    break;
   case RZ_QClasp_Router::Arg_Type_Codes::QString_Return:
    {
     QString& qs = drr.string_result();
     ARGS_TEMP_MACROS
     Cast_3_Ready::run(method_name, obj,
      "QString", qs, args  ,arg1, arg2, arg3,  argument_info);
    }
    break;
   }

}
else
{
 int next_cast_index = cast_index + 1;
 RZ_QClasp_Router::Argument_Conventions ac =
   argument_info[next_cast_index].convention;
 switch(ac)
 {
 case RZ_QClasp_Router::Argument_Conventions::QString_Direct:
  {
   QString& arg = args[next_cast_index].str;
   argument_info[next_cast_index].void_argument = &arg;
   argument_info[next_cast_index].type_name = "QString";
   switch(cast_index)
   {
    CASE_TEMP_MACRO_(0, 3, QString)
    CASE_TEMP_MACRO_(1, 3, QString)
   case 2:
    Cast_3::run<OBJECT_Type,
      typename Interchange<Type_List_Type, 2, 3>::
      template With_Type<QString>::Result_Type>
      (method_name, obj, next_cast_index, drr,
      argument_info, args);
    break;


   }
  }
  break;
 case RZ_QClasp_Router::Argument_Conventions::QMetaType_Confirmed:
  {
   const QMetaType* qmt = argument_info[next_cast_index].q_meta_type;
   int id = argument_info[next_cast_index].q_meta_type_id;
   QString type_name = QString::fromLatin1(QMetaType::typeName(id));
   void* pv = qmt->create();
   RZ_QClasp_Router::Arg_Type_Codes atc =
    RZ_QClasp_Router::lisp_to_q_meta_type(args[next_cast_index].object, pv);
   argument_info[next_cast_index].type_name = type_name;
   argument_info[next_cast_index].void_argument = pv;
   argument_info[next_cast_index].void_argument_for_delete = pv;
   switch(atc)
   {
   case RZ_QClasp_Router::Arg_Type_Codes::Int:
    CAST_INDEX_SWITCH(int)
    break;
   }
  }
  break;
 case RZ_QClasp_Router::Argument_Conventions::QVariant_Cast:
  {
   QVariant qvar = RZ_QClasp_Router::lisp_to_q_variant(args[next_cast_index].object);
   argument_info[next_cast_index].type_name = "QVariant";
   argument_info[next_cast_index].void_argument = &qvar;
   CAST_INDEX_SWITCH(QVariant)
  }
  break;
 case RZ_QClasp_Router::Argument_Conventions::QObject_Cast:
  {
   CAST_INDEX_SWITCH(QObject*)
  }
 }
}
//?CAST_SWITCH_MACRO(3)
CAST_STRUCT_END_MACRO



#ifdef HIDE
 struct Cast_3_Ready
 {
  template<typename OBJECT_Type, TYPENAMES_typename>
  static void run(QString method_name, OBJECT_Type obj,
   TYPENAMES_arg, const QVector<RZ_QClasp_Router::Argument_Info>& argument_info)
  {
   QMetaObject::invokeMethod(obj, method_name.toLatin1(),
    QARGUMENTS );
  }
 };

 struct Cast_3
 {
  static constexpr int ready_at_cast_index = 3;
  template<typename OBJECT_Type, typename Type_List_Type>
  static void run(QString method_name, OBJECT_Type obj,
    int cast_index,
    QVector<RZ_QClasp_Router::Argument_Info>& argument_info,
    QList<RZ_QClasp_Invoke_Argument>& args)
  {
   if(cast_index == ready_at_cast_index)
   {
    ARGS_TEMP_MACROS
    Cast_3_Ready::run(method_name, obj, ARGUMENTS, argument_info);
   }
   else
   {
    int next_cast_index = cast_index + 1;
    RZ_QClasp_Router::Argument_Conventions ac =
      argument_info[next_cast_index].convention;
    switch(ac)
    {
    case RZ_QClasp_Router::Argument_Conventions::QString_Direct:
     {
      QString arg = args[next_cast_index].str;
      argument_info[next_cast_index].void_argument = &arg;
      argument_info[next_cast_index].type_name = "QString";
      CAST_INDEX_SWITCH(QString)
     }
     break;
    case RZ_QClasp_Router::Argument_Conventions::QMetaType_Confirmed:
     {
      const QMetaType* qmt = argument_info[next_cast_index].q_meta_type;
      int id = argument_info[next_cast_index].q_meta_type_id;
      QString type_name = QString::fromLatin1(QMetaType::typeName(id));
      void* pv = qmt->create();
      RZ_QClasp_Router::Arg_Type_Codes atc =
        RZ_QClasp_Router::lisp_to_q_meta_type(args[next_cast_index].object, pv);
      argument_info[next_cast_index].type_name = type_name;
      argument_info[next_cast_index].void_argument = pv;
      argument_info[next_cast_index].void_argument_for_delete = pv;
      switch(atc)
      {
      case RZ_QClasp_Router::Arg_Type_Codes::Int:
       CAST_INDEX_SWITCH(int)
       break;
      }
     }
     break;
    }
   }
  }
 };
#endif
#endif HIDE




#undef ARGS_TEMP_MACROS

//#undef CASE_TEMP_MACROS
#undef ARGUMENTS
#undef QARGUMENTS
#undef CAST_INDEX_SWITCH
#undef CASE_TEMP_MACRO


// For ARG_COUNT 4

#ifdef NO_CAST_ALL_VOID

#define TYPENAMES_typename
#define TYPENAMES_arg ,void*& arg1, void*&  arg2, void*& arg3, void*& arg4

#else

#define TYPENAMES_typename ,typename ARG1_Type, typename ARG2_Type, typename ARG3_Type, typename ARG4_Type
#define TYPENAMES_arg ,ARG1_Type& arg1, ARG2_Type& arg2, ARG3_Type& arg3, ARG4_Type& arg4

#endif  // NO_CAST_ALL_VOID


#define QARGUMENTS  \
 ,QARG_TEMP_MACRO(1) \
 ,QARG_TEMP_MACRO(2) \
 ,QARG_TEMP_MACRO(3) \
 ,QARG_TEMP_MACRO(4) \


#define QARGUMENTS_STRING_ACC(STR)  \
   QARG_TEMP_MACRO_STRING_ACC(STR, 1) \
   QARG_TEMP_MACRO_STRING_ACC(STR, 2) \
   QARG_TEMP_MACRO_STRING_ACC(STR, 3) \
   QARG_TEMP_MACRO_STRING_ACC(STR, 4) \



#define ARGUMENTS   ,arg1, arg2, arg3, arg4


#define CAST_INDEX_SWITCH(TYPE) \
   switch(cast_index) \
   { \
    CASE_TEMP_MACRO(0, TYPE) \
    CASE_TEMP_MACRO(1, TYPE) \
    CASE_TEMP_MACRO(2, TYPE) \
    CASE_TEMP_MACRO(3, TYPE) \
   } \



#define CASE_TEMP_MACRO(INDEX, INTERCHANGE_TYPE) \
   CASE_TEMP_MACRO_(INDEX, 4, INTERCHANGE_TYPE)


#define ARGS_TEMP_MACROS \
 ARGS_TEMP_MACRO(1) \
 ARGS_TEMP_MACRO(2) \
 ARGS_TEMP_MACRO(3) \
 ARGS_TEMP_MACRO(4) \

 //?
 TEMP_MACRO(4)

#undef ARGS_TEMP_MACROS
#undef CASE_TEMP_MACROS
#undef ARGUMENTS
#undef QARGUMENTS

#ifdef NO_CAST_ALL_VOID

  #define TYPENAMES_typename
  #define TYPENAMES_arg ,void*& arg1, void*&  arg2, void*& arg3, void*& arg4, void*& arg5

#else

 #define TYPENAMES_typename ,typename ARG1_Type, typename ARG2_Type, \
  typename ARG3_Type, typename ARG4_Type, typename ARG5_Type
 #define TYPENAMES_arg ,ARG1_Type& arg1, ARG2_Type& arg2, \
  ARG3_Type& arg3, ARG4_Type& arg4, ARG5_Type& arg5

#endif    // NO_CAST_ALL_VOID


#define QARGUMENTS  \
  ,QARG_TEMP_MACRO(1) \
  ,QARG_TEMP_MACRO(2) \
  ,QARG_TEMP_MACRO(3) \
  ,QARG_TEMP_MACRO(4) \
  ,QARG_TEMP_MACRO(5) \

 #define QARGUMENTS_STRING_ACC(STR)  \
   QARG_TEMP_MACRO_STRING_ACC(STR, 1) \
   QARG_TEMP_MACRO_STRING_ACC(STR, 2) \
   QARG_TEMP_MACRO_STRING_ACC(STR, 3) \
   QARG_TEMP_MACRO_STRING_ACC(STR, 4) \
   QARG_TEMP_MACRO_STRING_ACC(STR, 5) \

 #define ARGUMENTS   ,arg1, arg2, arg3, arg4, arg5

 #define CAST_INDEX_SWITCH(TYPE) \
    switch(cast_index) \
    { \
     CASE_TEMP_MACRO(0, TYPE) \
     CASE_TEMP_MACRO(1, TYPE) \
     CASE_TEMP_MACRO(2, TYPE) \
     CASE_TEMP_MACRO(3, TYPE) \
     CASE_TEMP_MACRO(4, TYPE) \
    } \



 #define CASE_TEMP_MACRO(INDEX, INTERCHANGE_TYPE) \
    CASE_TEMP_MACRO_(INDEX, 5, INTERCHANGE_TYPE)

 #define CAST_INDEX_SWITCH(TYPE) \
    switch(cast_index) \
    { \
     CASE_TEMP_MACRO(0, TYPE) \
     CASE_TEMP_MACRO(1, TYPE) \
     CASE_TEMP_MACRO(2, TYPE) \
     CASE_TEMP_MACRO(3, TYPE) \
     CASE_TEMP_MACRO(4, TYPE) \
    } \


 #define ARGS_TEMP_MACROS \
  ARGS_TEMP_MACRO(1) \
  ARGS_TEMP_MACRO(2) \
  ARGS_TEMP_MACRO(3) \
  ARGS_TEMP_MACRO(4) \
  ARGS_TEMP_MACRO(5) \

   //?
   TEMP_MACRO(5)

 #undef ARGS_TEMP_MACROS
 #undef CASE_TEMP_MACROS
 #undef ARGUMENTS
 #undef QARGUMENTS





 // For ARG_COUNT 6

  #ifdef NO_CAST_ALL_VOID

    #define TYPENAMES_typename
    #define TYPENAMES_arg ,void*& arg1, void*&  arg2, void*& arg3, void*& arg4, void*& arg5, void*& arg6

  #else

 #define TYPENAMES_typename ,typename ARG1_Type, typename ARG2_Type, \
  typename ARG3_Type, typename ARG4_Type, typename ARG5_Type, typename ARG6_Type
 #define TYPENAMES_arg ,ARG1_Type& arg1, ARG2_Type& arg2, \
  ARG3_Type& arg3, ARG4_Type& arg4, ARG5_Type& arg5, ARG6_Type& arg6

#endif // NO_CAST_ALL_VOID


#define QARGUMENTS  \
  ,QARG_TEMP_MACRO(1) \
  ,QARG_TEMP_MACRO(2) \
  ,QARG_TEMP_MACRO(3) \
  ,QARG_TEMP_MACRO(4) \
  ,QARG_TEMP_MACRO(5) \
  ,QARG_TEMP_MACRO(6) \


 #define QARGUMENTS_STRING_ACC(STR)  \
  QARG_TEMP_MACRO_STRING_ACC(STR, 1) \
  QARG_TEMP_MACRO_STRING_ACC(STR, 2) \
  QARG_TEMP_MACRO_STRING_ACC(STR, 3) \
  QARG_TEMP_MACRO_STRING_ACC(STR, 4) \
  QARG_TEMP_MACRO_STRING_ACC(STR, 5) \
  QARG_TEMP_MACRO_STRING_ACC(STR, 6) \


 #define ARGUMENTS   ,arg1, arg2, arg3, arg4, arg5, arg6

 #define CAST_INDEX_SWITCH(TYPE) \
    switch(cast_index) \
    { \
     CASE_TEMP_MACRO(0, TYPE) \
     CASE_TEMP_MACRO(1, TYPE) \
     CASE_TEMP_MACRO(2, TYPE) \
     CASE_TEMP_MACRO(3, TYPE) \
     CASE_TEMP_MACRO(4, TYPE) \
     CASE_TEMP_MACRO(5, TYPE) \
    } \



 #define CASE_TEMP_MACRO(INDEX, INTERCHANGE_TYPE) \
    CASE_TEMP_MACRO_(INDEX, 6, INTERCHANGE_TYPE)

 #define CAST_INDEX_SWITCH(TYPE) \
    switch(cast_index) \
    { \
     CASE_TEMP_MACRO(0, TYPE) \
     CASE_TEMP_MACRO(1, TYPE) \
     CASE_TEMP_MACRO(2, TYPE) \
     CASE_TEMP_MACRO(3, TYPE) \
     CASE_TEMP_MACRO(4, TYPE) \
     CASE_TEMP_MACRO(5, TYPE) \
    } \


 #define ARGS_TEMP_MACROS \
  ARGS_TEMP_MACRO(1) \
  ARGS_TEMP_MACRO(2) \
  ARGS_TEMP_MACRO(3) \
  ARGS_TEMP_MACRO(4) \
  ARGS_TEMP_MACRO(5) \
  ARGS_TEMP_MACRO(6) \

   TEMP_MACRO(6)

 #undef ARGS_TEMP_MACROS
 #undef CASE_TEMP_MACROS
 #undef ARGUMENTS
 #undef QARGUMENTS
 #undef QARGUMENTS_STRING_ACC


 // For ARG_COUNT 7

  #ifdef NO_CAST_ALL_VOID

    #define TYPENAMES_typename
    #define TYPENAMES_arg ,void*& arg1, void*&  arg2, void*& arg3, void*& arg4, void*& arg5, void*& arg6, void*& arg7

  #else

 #define TYPENAMES_typename ,typename ARG1_Type, typename ARG2_Type, \
  typename ARG3_Type, typename ARG4_Type, typename ARG5_Type, typename ARG6_Type, typename ARG7_Type
 #define TYPENAMES_arg ,ARG1_Type& arg1, ARG2_Type& arg2, \
  ARG3_Type& arg3, ARG4_Type& arg4, ARG5_Type& arg5, ARG6_Type& arg6, ARG7_Type& arg7

#endif


#define QARGUMENTS  \
  ,QARG_TEMP_MACRO(1), \
  QARG_TEMP_MACRO(2), \
  QARG_TEMP_MACRO(3), \
  QARG_TEMP_MACRO(4), \
  QARG_TEMP_MACRO(5), \
  QARG_TEMP_MACRO(6), \
  QARG_TEMP_MACRO(7) \

 #define QARGUMENTS_STRING_ACC(STR)  \
  QARG_TEMP_MACRO_STRING_ACC(STR, 1) \
  QARG_TEMP_MACRO_STRING_ACC(STR, 2) \
  QARG_TEMP_MACRO_STRING_ACC(STR, 3) \
  QARG_TEMP_MACRO_STRING_ACC(STR, 4) \
  QARG_TEMP_MACRO_STRING_ACC(STR, 5) \
  QARG_TEMP_MACRO_STRING_ACC(STR, 6) \
  QARG_TEMP_MACRO_STRING_ACC(STR, 7) \


 #define ARGUMENTS   ,arg1, arg2, arg3, arg4, arg5, arg6, arg7

 #define CAST_INDEX_SWITCH(TYPE) \
    switch(cast_index) \
    { \
     CASE_TEMP_MACRO(0, TYPE) \
     CASE_TEMP_MACRO(1, TYPE) \
     CASE_TEMP_MACRO(2, TYPE) \
     CASE_TEMP_MACRO(3, TYPE) \
     CASE_TEMP_MACRO(4, TYPE) \
     CASE_TEMP_MACRO(5, TYPE) \
     CASE_TEMP_MACRO(6, TYPE) \
    } \



 #define CASE_TEMP_MACRO(INDEX, INTERCHANGE_TYPE) \
    CASE_TEMP_MACRO_(INDEX, 7, INTERCHANGE_TYPE)

 #define CAST_INDEX_SWITCH(TYPE) \
    switch(cast_index) \
    { \
     CASE_TEMP_MACRO(0, TYPE) \
     CASE_TEMP_MACRO(1, TYPE) \
     CASE_TEMP_MACRO(2, TYPE) \
     CASE_TEMP_MACRO(3, TYPE) \
     CASE_TEMP_MACRO(4, TYPE) \
     CASE_TEMP_MACRO(5, TYPE) \
     CASE_TEMP_MACRO(6, TYPE) \
    } \


 #define ARGS_TEMP_MACROS \
  ARGS_TEMP_MACRO(1) \
  ARGS_TEMP_MACRO(2) \
  ARGS_TEMP_MACRO(3) \
  ARGS_TEMP_MACRO(4) \
  ARGS_TEMP_MACRO(5) \
  ARGS_TEMP_MACRO(6) \
  ARGS_TEMP_MACRO(7) \

   //?
   TEMP_MACRO(7)

 #undef ARGS_TEMP_MACROS
 #undef CASE_TEMP_MACROS
 #undef ARGUMENTS
 #undef QARGUMENTS

//?#endif HIDE



};




template<int i>
struct Do_Invoke_Method__Cast_Schedule__Cast_
{
};

#define TEMP_MACRO(i) \
template<> \
struct Do_Invoke_Method__Cast_Schedule__Cast_<i> \
{ \
 typedef typename Do_Invoke_Method__Cast_Schedule::Cast_##i Type; \
}; \


TEMP_MACRO(0)
TEMP_MACRO(1)
TEMP_MACRO(2)
TEMP_MACRO(3)
TEMP_MACRO(4)
TEMP_MACRO(5)
TEMP_MACRO(6)
TEMP_MACRO(7)

_RZNS(DigammaCl)

#endif

