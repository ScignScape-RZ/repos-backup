﻿
#include "rz-qclasp-router.h"

#include "rz-qclasp-invoke-argument.h"

#include <QFile>

#include <QRegularExpression>
#include <QRegularExpressionMatch>

#include <QEventLoop>

#include <QMetaMethod>

#include "rz-qclasp-router.h"

#include "rz-qclasp-router-cast-schedule.h"


#define _ADDRESS_MODEL_64
#define X86
#define USE_BOEHM

#undef slots

//?
#include "boehmdc/config.h"

#include <clasp/core/object.h>

#include <clasp/core/externalObject.h>
#include <clasp/core/primitives.h>
#include <clasp/core/numbers.h>
#include <clasp/core/str.h>



USING_RZNS(RZClasp)

RZ_QClasp_Router::RZ_QClasp_Router(QString type_name, void* this_data,
  QString& string_result, void*& object_result, void* clasp_result)
 : type_name_(type_name), this_data_(this_data), clasp_result_(clasp_result),
   return_convention_(Return_Conventions::No_Return),
   return_type_code_(Arg_Type_Codes::No_Return),
   string_result_(string_result), object_result_(object_result),
   this_object_(nullptr), this_meta_object_(nullptr)
{

}


RZ_QClasp_Router::Arg_Type_Codes RZ_QClasp_Router::lisp_to_q_meta_type(void* obj,
  void*& pv)
{
 core::T_sp* tsp = reinterpret_cast<core::T_sp*>(obj);

 if(core::cl__numberp(*tsp))
 {
  switch(core::clasp_t_of(*tsp))
  {
  case core::number_Fixnum:
   {
    int* arg = reinterpret_cast<int*>(pv);
    *arg = (*tsp).asFixnum();
    return Arg_Type_Codes::Int;
   }
  case core::number_DoubleFloat:
  case core::number_LongFloat:
  case core::number_SingleFloat:
   {
    //double* arb = reinterpret_cast<qreal*>(pv);
    qreal* arg = reinterpret_cast<qreal*>(pv);
    *arg = (*tsp).unsafe_single_float();
    return Arg_Type_Codes::QReal;
   }
  }
 }
 return RZ_QClasp_Router::Arg_Type_Codes::N_A;
}

QVariant RZ_QClasp_Router::lisp_to_q_variant(void* obj)
{
 core::T_sp* tsp = reinterpret_cast<core::T_sp*>(obj);

 if(core::cl__numberp(*tsp))
 {
  switch(core::clasp_t_of(*tsp))
  {
  case core::number_Fixnum:
   {
    return QVariant::fromValue((*tsp).asFixnum());
   }
  case core::number_DoubleFloat:
  case core::number_LongFloat:
  case core::number_SingleFloat:
   {
    return QVariant::fromValue((*tsp).unsafe_single_float());
   }
  }
 }
 return QVariant::fromValue(0);
}



void RZ_QClasp_Router::set_method_name(QString code)
{
 method_name_code_ = code;
 int f;

 if((f = method_name_code_.indexOf("..")) != -1)
 {
  return_type_name_ = method_name_code_.mid(f + 2);
  method_name_ = method_name_code_.mid(0, f);
 }
 else
 {
  method_name_ = method_name_code_;
 }
 if(method_name_.startsWith('.'))
 {
  method_name_.remove(0, 1);
 }

 QRegularExpression rx("([\\w-]+)<([^>]+)>");
 QRegularExpressionMatch rxm = rx.match(return_type_name_);
 if(rxm.hasMatch())
 {
  return_type_name_ = rxm.captured(2);
  return_type_template_ = rxm.captured(1);
 }

}

void RZ_QClasp_Router::init_method_signatures()
{
 if(this_meta_object_)
 {
  for(int i = this_meta_object_->methodOffset(); i < this_meta_object_->methodCount(); ++i)
  {
   QMetaMethod qmm = this_meta_object_->method(i);
   QString sig = QString::fromLatin1(qmm.methodSignature());

   int paren_index = sig.indexOf('(');
   if(paren_index != -1)
   {
    QString name = sig.mid(0, paren_index);
    if(name == method_name_)
    {
     QString arg_sig = sig.mid(paren_index + 1, sig.size() - paren_index - 2);
     QStringList args = arg_sig.split(',');
     method_signatures_ << args;
     method_signature_status_vector_ << Method_Signature_Status::Possible;
    }
   }
  }
 }
}

QString RZ_QClasp_Router::return_type_name_strip_namespace()
{
 int li = return_type_name_.lastIndexOf("::");
 if(li != -1)
 {
  return return_type_name_.mid(li + 2);
 }
 else
 {
  return return_type_name_;
 }
}

QString RZ_QClasp_Router::check_call_type_for_argument(int index,
  const QMetaType* qmt, int meta_type_id, QMap<int, QString>& result)
{
 if(this_meta_object_)
 {
  if(method_signatures_.isEmpty())
  {
   init_method_signatures();
  }
  for(int i = 0; i < method_signature_status_vector_.size(); ++i)
  {
   if(method_signature_status_vector_[i] != Method_Signature_Status::Ruled_Out)
   {
    QStringList signature = method_signatures_[i];
    if(signature.size() < index - 1)
    {
     method_signature_status_vector_[i] = Method_Signature_Status::Ruled_Out;
    }
    else
    {
     QString field_type = signature.at(index - 1);
     if(field_type == "QVariant")
     {
      if(QMetaType::typeName(meta_type_id) == "QVariant")
      {
       argument_info_[index].convention = Argument_Conventions::QVariant_Direct;
       return "QVariant";
      }
      else
      {
       argument_info_[index].convention = Argument_Conventions::QVariant_Cast;
       return "QVariant";
      }
     }
     else if(field_type == QMetaType::typeName(meta_type_id))
     {
      argument_info_[index].convention = Argument_Conventions::QMetaType_Confirmed;
      argument_info_[index].q_meta_type = qmt;
      argument_info_[index].q_meta_type_id = meta_type_id;
      return field_type;
     }
    }
   }
  }
 }
 return QString();
}


QString RZ_QClasp_Router::check_meta_object(int index, QString type_name)
{
 QString result;
 int type_id = QMetaType::type(type_name.toLatin1());
 if(type_id == QMetaType::UnknownType)
 {
  QString try_type_name = type_name + "*";
  type_id = QMetaType::type(try_type_name.toLatin1());
  if(type_id == QMetaType::UnknownType)
  {
   try_type_name.replace(QRegularExpression("[\\w:]+:"), "");
   type_id = QMetaType::type(try_type_name.toLatin1());
   if(type_id == QMetaType::UnknownType)
   {
    if(try_type_name.endsWith('*'))
    {
     try_type_name.chop(1);
     type_id = QMetaType::type(try_type_name.toLatin1());
    }
   }
  }
 }

 if(type_id != QMetaType::UnknownType)
 {
  const QMetaObject* qmo = QMetaType::metaObjectForType(type_id);

  if(!qmo)
  {
   QString try_type_name = type_name + "*";
   type_id = QMetaType::type(try_type_name.toLatin1());
   if(type_id == QMetaType::UnknownType)
   {
    try_type_name.replace(QRegularExpression("[\\w:]+:"), "");
    type_id = QMetaType::type(try_type_name.toLatin1());
   }
   if(type_id != QMetaType::UnknownType)
   {
    qmo = QMetaType::metaObjectForType(type_id);
   }

  }

  if(qmo)
  {
   result = qmo->className();
   argument_info_[index].convention = Argument_Conventions::QObject_Cast;
   if(index == 0)
   {
    this_object_ = reinterpret_cast<QObject*>(this_data_);
    this_meta_object_ = qmo;

    QString possible_property_name = method_name_.toLower();

    if(possible_property_name.startsWith("set"))
    {
     possible_property_name.remove(0, 3);
     if(possible_property_name.startsWith("-"))
      possible_property_name.remove(1);
    }

    int count = qmo->propertyCount();
    for (int i=0; i<count; ++i)
    {
     QMetaProperty metaproperty = qmo->property(i);
     QString cn = QString::fromLatin1(qmo->className());
     QString prop_name = QString::fromLatin1(metaproperty.name());
     if(prop_name.toLower() == possible_property_name)
     {
      metaproperty_ = metaproperty;
      break;
     }
    }
   }
   else
   {
    QString clean_result = result;
    int rli = clean_result.lastIndexOf("::");
    if(rli != -1)
    {
     clean_result = result.mid(rli + 2);
    }
    clean_result += "*";
    argument_info_[index].type_name = clean_result;
   }

  }
 }
 return result;
}


void RZ_QClasp_Router::do_invoke_method(QList<RZ_QClasp_Invoke_Argument>& args)
{
 argument_info_.resize(args.size());
 if(!static_class_name_.isEmpty())
 {
  argument_info_[0].convention = Argument_Conventions::Static_First_Argument;
  argument_info_[0].type_name = static_class_name_;
  argument_info_[0].void_argument = args[0].object;

  int metatype_id = QMetaType::type(static_class_name_.toLatin1());
  if(metatype_id == QMetaType::UnknownType)
  {
   metatype_id = QMetaType::type((static_class_name_ + "*").toLatin1());
  }
  argument_info_[0].q_meta_type_id = metatype_id;
  argument_info_[0].mode = args[0].mode;
 }
 else if(type_name_ == "QDomDocument")
 {
  argument_info_[0].convention = Argument_Conventions::QDomDocument_Direct;
 }
 else if(type_name_ == "QString")
 {
  argument_info_[0].convention = Argument_Conventions::QString_Direct;
 }

 else
 {
  QString ty = check_meta_object(0, type_name_);
  if(ty.isEmpty())
  {
   argument_info_[0].convention = Argument_Conventions::QVariant_Cast;
  }
 }

 for(int i = 1; i < args.size(); ++i)
 {
  const RZ_QClasp_Invoke_Argument& arg = args[i];

  argument_info_[i].mode = arg.mode;

  QString internal_type_string = arg.internal_type;

  Argument_Conventions ac;
  if(arg.mode == RZ_QClasp_Invoke_Argument::Each_Callback)
  {
   ac = Argument_Conventions::Void_Ptr_Ptr;
  }
  else if(arg.mode == RZ_QClasp_Invoke_Argument::Yield_Callback)
  {
   ac = Argument_Conventions::Void_Ptr_Ptr;
  }
  else
  {
   ac = argument_convention_from_type_name(internal_type_string);
  }


  switch(ac)
  {
  case Argument_Conventions::QMetaType_Name:
   {
    const QMetaType* qmt = nullptr;
    QPair<const QMetaType*, int>
     qp =
      meta_type_from_lisp_derived_type_name(internal_type_string);
    if(qmt = qp.first)
    {
     QMap<int, QString> possible_call_types;
     QString confirmed_call_type;
     if(this_object_)
      confirmed_call_type = check_call_type_for_argument(i, qmt, qp.second, possible_call_types);
     if(!confirmed_call_type.isEmpty())
     {

     }
     else if(possible_call_types.isEmpty())
     {
      argument_info_[i].convention = Argument_Conventions::QMetaType_Confirmed;
      argument_info_[i].q_meta_type = qmt;
      argument_info_[i].q_meta_type_id = qp.second;
     }
     else
     {
      //? ...
     }
    }
   }
   break;
  case Argument_Conventions::QMetaType_Foreign:
   {
    void* pair_object = args[i].object;
    void* object;
    QString type_name_from_pair; //? = convert_type_object_pair(pair_object, object);
    if(type_name_from_pair.isEmpty())
    {
     //?
    }
    else
    {
     QString type_name_confirmed = check_meta_object(i, type_name_from_pair);
     if(type_name_confirmed.isEmpty())
     {

     }
     else
     {
      // ok?
      argument_info_[i].void_argument = object;
     }
    }
   }
   break;
  default:
   argument_info_[i].convention = ac;
   break;
  }

 }

 // check return convention
 if(!return_type_name_.isEmpty())
 {
  return_type_code_ = parse_return_type_code(return_type_name_);
  switch(return_type_code_)
  {
  case Arg_Type_Codes::Void_Pointer:
   if(return_type_template_ == "type-object-pair")
   {
    return_convention_ = RZ_QClasp_Router::Return_Conventions::QObject_Cast_Type_Object_Pair;
   }
   else
   {
    return_convention_ = RZ_QClasp_Router::Return_Conventions::QObject_Cast;
   }
   break;
  case Arg_Type_Codes::No_Return:
   break;
  case Arg_Type_Codes::QString_Return:
   return_convention_ = RZ_QClasp_Router::Return_Conventions::QString_Direct;
   break;
  default:
   return_convention_ = RZ_QClasp_Router::Return_Conventions::Direct;
   object_result_ = new int;
   break;
  }
 }

 if(metaproperty_.isValid())
 {
  if(method_name_.startsWith("set") && args.size() > 1)
  {
   if(args[1].internal_type == "str")
   {
    QVariant qvar = args[1].str;
    metaproperty_.write(this_object_, qvar);
   }
   else
   {
    QVariant qvar = RZ_QClasp_Router::lisp_to_q_variant(args[1].object);
    metaproperty_.write(this_object_, qvar);
   }
  }
  else
  {
   QVariant qvar = metaproperty_.read(this_object_);
   switch(return_convention_)
   {
   case Return_Conventions::No_Return: break;
   case Return_Conventions::QString_Direct:
    string_result_ = qvar.toString();
    break;
   }
  }
  return;
 }

 switch(args.size())
 {
 case 1: Do_Invoke_Method_<0>::run(this, args); break;
 case 2: Do_Invoke_Method_<1>::run(this, args); break;

 case 3: Do_Invoke_Method_<2>::run(this, args); break;
 case 4: Do_Invoke_Method_<3>::run(this, args); break;
 case 5: Do_Invoke_Method_<4>::run(this, args); break;

 case 6: Do_Invoke_Method_<5>::run(this, args); break;
 case 7: Do_Invoke_Method_<6>::run(this, args); break;
 case 8: Do_Invoke_Method_<7>::run(this, args); break;
 }

 // for refs...

 int i = 0;

 for(RZ_QClasp_Invoke_Argument& ia : args)
 {
  if(ia.mode == RZ_QClasp_Invoke_Argument::Ref)
  {

   const Argument_Info& ai = argument_info_[i];

   QString* qs = reinterpret_cast<QString*>( ai.void_argument );

   core::General_sp* gsp = reinterpret_cast<core::General_sp*>(ia.object);
   std::string sstr = qs->toStdString();

   std::string ss1 = _rep_(*gsp);

   std::string cns = (*gsp)->className();
   QString cn = QString::fromStdString(cns);
   QString label1;
   QString label2;
   if(cn == "COMMON-LISP:BASE-STRING" || cn == "BASE-STRING")
   {
    label1 = QString::fromStdString(  //core::str_get(obj)
                                   _rep_(*gsp)
                                    );
   }


   QString qs1 = QString::fromStdString(ss1);

   core::Str_sp ssp = core::Str_O::create(sstr);
   *gsp = ssp;

   qDebug() << "QS1: " << qs1;
   qDebug() << "*QS: " << *qs;

   if(cn == "COMMON-LISP:BASE-STRING" || cn == "BASE-STRING")
   {
    label2 = QString::fromStdString(  //core::str_get(obj)
                                   _rep_(*gsp)
                                    );
   }
  }
  ++i;

 }


 // for return...
 switch(return_convention_)
 {
 case Return_Conventions::No_Return: break;
 case Return_Conventions::QString_Direct:
  {

  }
  break;
 case Return_Conventions::QObject_Cast:
  {
  }
  break;

 case Return_Conventions::QObject_Cast_Type_Object_Pair:
  {
   string_result_ = return_type_name_;
  }
  break;

 case Return_Conventions::Direct:
  {
   switch(return_type_code_)
   {
   case Arg_Type_Codes::Int:
    {
     int* r = reinterpret_cast<int*>(object_result_);
     core::T_sp& pr = reinterpret_cast<core::T_sp&>(*clasp_result_);
     pr = core::clasp_make_fixnum(*r);
    }
    break;
   case Arg_Type_Codes::QReal:
    {
     qreal* r = reinterpret_cast<qreal*>(object_result_);
     core::T_sp& pr = reinterpret_cast<core::T_sp&>(*clasp_result_);
     pr = core::clasp_make_double_float(*r);
    }
    break;
   }
  }
 }

}

RZNS_(RZClasp)

template<int Arg_Count>
void RZ_QClasp_Router::Do_Invoke_Method<Arg_Count>//, RC>
 ::run(RZ_QClasp_Router* this_, QList<RZ_QClasp_Invoke_Argument>& args)
{
#ifdef NO_CAST_ALL_VOID
 Do_Invoke_Method__Cast_Schedule__Cast_<Arg_Count>
   ::Type::template run__av<QObject*>(this_->method_name(),
    this_->this_object(), 0, *this_,
    this_->argument_info(), args);

#else
   Do_Invoke_Method__Cast_Schedule__Cast_<Arg_Count>
     ::Type::template run<QObject*, typename Type_List__All_Cast_Needed<Arg_Count>::Type>(this_->method_name(),
      this_->this_object(), 0, *this_,
      this_->argument_info(), args);
#endif //  NO_CAST_ALL_VOID
}


#define TEMP_MACRO(ARG_COUNT) \
template<> \
void RZ_QClasp_Router::Do_Invoke_Method<ARG_COUNT, RZ_QClasp_Router::Return_Conventions::No_Return>::run(RZ_QClasp_Router* this_, QList<RZ_QClasp_Invoke_Argument>& args) \
{ \
 QVector<void*> void_arguments = QVector<void*>(ARG_COUNT, nullptr); \
 QVector<QString> type_names(ARG_COUNT); \
 switch(this_->argument_info()[0].convention) \
 { \
 case Argument_Conventions::QObject_Cast: \
  { \
   QObject* qob = reinterpret_cast<QObject*>(this_->this_data()); \
   Do_Invoke_Method__Cast_Schedule<Return_Conventions::No_Return> \
     ::Cast_##ARG_COUNT::run<QObject*, \
     Type_List__##ARG_COUNT##__All_Cast_Needed_Type>(this_->method_name(), \
      this_->this_object(), 0, *this_, this_->argument_info(), args); \
  } \
  break; \
  default: break; \
 } \
} \

#undef TEMP_MACRO


_RZNS(RZClasp)


