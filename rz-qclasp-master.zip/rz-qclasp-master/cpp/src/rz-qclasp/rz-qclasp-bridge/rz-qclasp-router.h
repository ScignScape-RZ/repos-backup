
#ifndef RZ_QCLASP_ROUTER__H
#define RZ_QCLASP_ROUTER__H

#include <QtGlobal>

#include <functional>

#include <QMetaProperty>

#include <QVector>

#include "rzns.h"
#include "accessors.h"

#include "rz-qclasp-invoke-argument.h"



RZNS_(RZClasp)

class Digamma_Request_Runtime;
class RZ_QClasp_Router_Invokable;

class RZ_QClasp_Router
{
 QString type_name_;
 void* this_data_;

 QString method_name_code_;
 QString method_name_;
 QString return_type_name_;
 QString return_type_template_;


public:


 enum class Return_Conventions {
  No_Return, QVariant_Cast,
  QObject_Cast,
  Direct, QString_Direct,
  QVariant_Cast_Type_Object_Pair,
  QObject_Cast_Type_Object_Pair,
  Direct_Type_Object_Pair,
 };

 enum class Argument_Conventions {
  N_A, QMetaType_Name, QMetaType_Confirmed,
  QMetaType_Foreign, QString_Direct,
  QString_Cast, QObject_Direct, QObject_Cast,
  Void_Ptr_To_Value, Void_Ptr_Ptr,
  QVariant_Direct, QVariant_Cast,
  QDomDocument_Direct, Static_First_Argument
 };


 Argument_Conventions argument_convention_from_type_name(QString type_name)
 {
  if(type_name.startsWith("QT-FOREIGN-DATA:"))
  {
   if(type_name.endsWith('*'))
    return Argument_Conventions::Void_Ptr_Ptr;
   else
    return Argument_Conventions::Void_Ptr_To_Value;
  }

  static const QMap<QString, Argument_Conventions> static_map {{
   #define TEMP_MACRO(LISP_TYPE, NAME, ARGUMENT_CONVENTION, METATYPE_ID) \
    {#NAME, Argument_Conventions::ARGUMENT_CONVENTION},
    #include "rz-qclasp-bridge.typelist.h"
   #undef TEMP_MACRO
    {"str", Argument_Conventions::QString_Direct},
  }};

  return static_map.value(type_name, Argument_Conventions::N_A);
 }

 QPair<const QMetaType*, int> meta_type_from_lisp_derived_type_name(QString type_name)
 {
  static const QMap<QString, QPair<const QMetaType*, int>> static_map {{
   #define TEMP_MACRO(LISP_TYPE, NAME, ARGUMENT_CONVENTION, METATYPE_ID) \
    {#NAME, {new QMetaType(QMetaType::METATYPE_ID), QMetaType::METATYPE_ID}},
    #include "rz-qclasp-bridge.typelist.h"
    //? #include "lisp/digamma-ecl-bridge.typelist.h"
   #undef TEMP_MACRO
  }};
  return static_map.value(type_name, {nullptr, 0});
 }

 enum class Arg_Type_Codes {
   N_A, No_Return, QString_Return, Void_Pointer, Int, Float, QReal,
 };


 static Arg_Type_Codes parse_return_type_code(QString key)
 {
  if(key.endsWith("*"))
   return Arg_Type_Codes::Void_Pointer;
  static QMap<QString, Arg_Type_Codes> static_map {{
   {"int", Arg_Type_Codes::Int},
   {"qreal", Arg_Type_Codes::QReal},
   {"QString", Arg_Type_Codes::QString_Return},
  }};
  return static_map.value(key, Arg_Type_Codes::No_Return);
 }

 static Arg_Type_Codes lisp_to_q_meta_type(void* obj,
   void*& pv);
 static QVariant lisp_to_q_variant(void* obj);
 struct Argument_Info
 {
  void* void_argument;
  void* void_argument_for_delete;


  QString type_name;
  const QMetaType* q_meta_type;

  int q_meta_type_id;

  Argument_Conventions convention;

  RZ_QClasp_Invoke_Argument::Mode mode;

  Argument_Info(): q_meta_type_id(QMetaType::UnknownType),
    void_argument(nullptr), void_argument_for_delete(nullptr),
    q_meta_type(nullptr), mode(RZ_QClasp_Invoke_Argument::N_A) {}

  QString type_name_with_modifier(QString modifier) const
  {
   QString result;
   if(modifier.isEmpty())
   {
    result = type_name;
   }
   else
   {
    QString m = modifier.replace('.', ' ') + ' ';
    result = m.simplified() + ' ' + type_name;
   }

   switch(mode)
   {
   case RZ_QClasp_Invoke_Argument::Ref:
    result += "&";
    break;
   //?
   case RZ_QClasp_Invoke_Argument::Each_Callback:
    result += "*";
    break;
   default:
    break;
   }
   return result;
  }

 };

 template<int Arg_Count>
 struct Do_Invoke_Method
 {
  static void run(RZ_QClasp_Router* this_, QList<RZ_QClasp_Invoke_Argument>& args);
 };

 template<int Arg_Count>
 struct Do_Invoke_Method_
 {
  template<Return_Conventions RC>
  struct With_Return_Convention
  {
   static void run(RZ_QClasp_Router* this_,
     QList<RZ_QClasp_Invoke_Argument>& args)
   {
    Do_Invoke_Method<Arg_Count//, RC
      >::run(this_, args);
   }
  };

  static void run(RZ_QClasp_Router* this_, QList<RZ_QClasp_Invoke_Argument>& args)
  {
    Do_Invoke_Method<Arg_Count>::run(this_, args);

  }
 };


private:

 Return_Conventions return_convention_;

 QString& string_result_;
 void*& object_result_;
 void* clasp_result_;
 QVector<Argument_Info> argument_info_;

 QObject* this_object_;

 QString static_class_name_;

 const QMetaObject* this_meta_object_;

 QList<QStringList> method_signatures_;

 Arg_Type_Codes return_type_code_;

 QString check_call_type_for_argument(int index,
   const QMetaType* qmt, int meta_type_id, QMap<int, QString>& result);
 void init_method_signatures();

 enum class Method_Signature_Status {
   N_A, Possible, Confirmed, Ruled_Out
 };

 QVector<Method_Signature_Status> method_signature_status_vector_;

 QString check_meta_object(int index, QString type_name);

 QMetaProperty metaproperty_;

public:
 ACCESSORS(Return_Conventions ,return_convention)

 ACCESSORS(QString ,method_name_code)
 ACCESSORS__GET(QString ,method_name)
 ACCESSORS(void* ,this_data)
 ACCESSORS__RGET(void* ,object_result)
 ACCESSORS__RGET(QString ,string_result)

 ACCESSORS(Arg_Type_Codes ,return_type_code)
 ACCESSORS(QString ,return_type_name)
 ACCESSORS(QString ,static_class_name)



 ACCESSORS(QObject* ,this_object)

 ACCESSORS__RGET(QVector<Argument_Info> ,argument_info)

 RZ_QClasp_Router(QString type_name, void* this_data,
   QString& string_result, void*& object_result, void* clasp_result);

 void set_method_name(QString code);

 void do_invoke_method(QList<RZ_QClasp_Invoke_Argument>& args);

 QString return_type_name_strip_namespace();


#ifdef HIDE
#endif

};

_RZNS(DigammaCl)


#endif
