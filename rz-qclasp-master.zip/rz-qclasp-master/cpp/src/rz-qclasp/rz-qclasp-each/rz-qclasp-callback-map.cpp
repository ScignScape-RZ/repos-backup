
#include "rz-qclasp-callback-map.h"

#include "rzns.h"

USING_RZNS(RZClasp)

RZ_QClasp_Callback_Map::RZ_QClasp_Callback_Map()
{

}

void RZ_QClasp_Callback_Map::add_callback(QString key, RZ_QClasp_Callback& cb)
{
 callbacks_.insert(key, cb);
}

RZ_QClasp_Callback* RZ_QClasp_Callback_Map::get_callback(QString key)
{
 auto it = callbacks_.find(key);
 return it.operator ->();
 //RZ_QClasp_Callback* result = callbacks_.find(key);
}
