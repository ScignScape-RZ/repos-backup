
#ifndef RZ_QCLASP_CALLBACK_MAP__H
#define RZ_QCLASP_CALLBACK_MAP__H

#include "rzns.h"

#include "accessors.h"

#include "rz-qclasp-callback.h"

#include <functional>

#include <QString>
#include <QMap>

RZNS_(RZClasp)


class RZ_QClasp_Callback_Map
{
 QMap<QString, RZ_QClasp_Callback> callbacks_;

public:

 RZ_QClasp_Callback_Map();

 void add_callback(QString key, RZ_QClasp_Callback& cb);

 RZ_QClasp_Callback* get_callback(QString key);
};


_RZNS(RZClasp)


#endif
