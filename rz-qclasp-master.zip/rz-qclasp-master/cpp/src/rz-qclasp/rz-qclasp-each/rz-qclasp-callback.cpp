
#include "rz-qclasp-callback.h"

#include "rzns.h"


//#define _ADDRESS_MODEL_64
//#define X86
//#define USE_BOEHM


//#undef slots

//#include "boehmdc/config.h"


//#include <clasp/core/object.h>

//#include <clasp/core/externalObject.h>
//#include <clasp/core/primitives.h>
//#include <clasp/core/str.h>

//#include <clasp/core/qt-foreign-data.h>
//#include <clasp/core/package.h>
//#include <clasp/core/evaluator.h>



USING_RZNS(RZClasp)


//RZ_QClasp_Callback* RZ_QClasp_Callback::clone()
//{
// return new RZ_QClasp_Callback(lisp_function_pointer_);
//}

RZ_QClasp_Callback::RZ_QClasp_Callback(void* lisp_function_pointer)
 : lisp_function_pointer_(lisp_function_pointer), status_(Status::N_A)
{

// core::Function_sp fn = fn_symbol->symbolFunction().asOrNull<core::Function_O>();
// //?core::General_sp a1 = arg_list.takeFirst();
// core::T_sp fn_result = core::eval::funcall(fn, arg_list[0], arg_list[1]);
// core::T_sp& retval_tsp = reinterpret_cast<core::T_sp&>(*result);
// retval_tsp = fn_result;


}

bool RZ_QClasp_Callback::needs_init()
{
 return status_ == Status::Marked_Async;
}

bool RZ_QClasp_Callback::async()
{
 return status_ == Status::Async;
}

void RZ_QClasp_Callback::check_set_async()
{
 if(status_ == Status::Marked_Async)
 {
  status_ = Status::Async;
 }
}


void RZ_QClasp_Callback::run_function(QString class_name, void* pv)
{
 callback_(lisp_function_pointer_, class_name, pv);
}

void RZ_QClasp_Callback::mark_async()
{
 status_ = Status::Marked_Async;
}


