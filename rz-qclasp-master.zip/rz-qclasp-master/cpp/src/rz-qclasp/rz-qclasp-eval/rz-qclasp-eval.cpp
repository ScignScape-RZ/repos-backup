
#include "rz-qclasp-eval.h"

#undef slots


#include "boehmdc/config.h"

#include "lisp.h"

#include "clasp/core/core_globals.h"

#include <functional>

#include <QMessageBox>

#include <QDebug>

#include <QDir>


int lib_main(//? QString& messager,
               int argc, char *argv[], void* cb);


int lib_main(//? QString& messager,
               int argc, char *argv[], std::function<void()> cb)
{
 return lib_main(argc, argv, &cb);
}

int lib_main(//? QString& messager,
               int argc, char *argv[])

{
 return lib_main(argc, argv, nullptr);
}


USING_RZNS(RZClasp)

std::string program_name()
{
 return "QClasp";
}


RZ_QClasp_Eval::RZ_QClasp_Eval()
{

}

void* RZ_QClasp_Eval::get_clasp_data()
{
 return _lisp->rzq_host_data();
}

void RZ_QClasp_Eval::set_clasp_data(void* pv)
{
 _lisp->set_rzq_host_data(pv);
}

void RZ_QClasp_Eval::set_clasp_callback(Callback_type& cb)
{
 _lisp->set_rzq_callback(&cb);
}

template<>
void RZ_QClasp_Eval::eval_string(QString qcode, core::T_sp& result)
{
 core::MultipleValues &me = core::lisp_multipleValues();
 std::string code = qcode.toStdString();

 core::T_mv result_mv = _lisp->eval_string(code);

 core::T_sp obj = result_mv;

 QString qo;

 if(obj.notnilp())
 {
  std::string rep = _rep_(obj);
  qo = QString::fromStdString(rep);
 }

 result = obj;
}


QString RZ_QClasp_Eval::eval_string(QString qcode)
{
 core::MultipleValues &me = core::lisp_multipleValues();
 std::string code = qcode.toStdString();

 core::T_mv result_mv = _lisp->eval_string(code);
 core::T_sp obj = result_mv;

 if(obj.notnilp())
 {
  std::string rep = _rep_(obj);
  return QString::fromStdString(rep);
 }
 return "Nil";
}



QString RZ_QClasp_Eval::eval_string(QString qcode, void* eval_data)
{
 core::MultipleValues &me = core::lisp_multipleValues();
 std::string code = qcode.toStdString();

 core::T_mv result_mv = _lisp->eval_string(code, eval_data);
 core::T_sp obj = result_mv;

 if(obj.notnilp())
 {
  std::string rep = _rep_(obj);
  return QString::fromStdString(rep);
 }
 return "Nil";
}


void RZ_QClasp_Eval::start_clasp(char argc, char* argv [])
{
 QString messager;

 char* argv_[3];

 QDir::setCurrent("__THESE NEEDS TO BE A CLASP BUILD__");

 argv_[0] = "cclasp-boehmdc";

  argv_[1] = "-I";
  argv_[2] = "-n";


 char argc_ = 3;

 lib_main(argc_, argv_);
 held_bindings_ = my_thread->_Bindings._Bindings._Vector._Contents.raw_();

}




void RZ_QClasp_Eval::start_clasp_from_dir(char argc, char* argv [], QString dir)
{
 QDir::setCurrent(dir);
 lib_main(argc, argv);
 held_bindings_ = my_thread->_Bindings._Bindings._Vector._Contents.raw_(); // held_bindings_
}


void RZ_QClasp_Eval::start_clasp(char argc, char* argv [], Void_Callback_type cb)
{
 QString messager;

 char* argv_[3];

 argv_[0] = "__THESE NEEDS TO BE A CLASP BUILD__";

 argv_[1] = "-I";

 argv_[2] = "-n";


 char argc_ = 3;

 lib_main(argc_, argv_, cb);
 held_bindings_ = my_thread->_Bindings._Bindings._Vector._Contents.raw_(); // held_bindings_

}

