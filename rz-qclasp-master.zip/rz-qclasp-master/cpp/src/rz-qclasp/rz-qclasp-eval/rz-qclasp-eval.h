
#ifndef RZ_QCLASP_EVAL__H
#define RZ_QCLASP_EVAL__H

#include <QString>

#include "accessors.h"

//namespace core
//{
// class LispHolder;
//}


#include "rzns.h"

//class Clasp_Qt_RZ_Bridge;

RZNS_(RZClasp)

class RZ_QClasp_Eval
{
// core::LispHolder* lisp_holder_;
//// Clasp_QtWeb_Bridge* clasp_qtweb_bridge_;
// //?clasp_qtweb_bridge_->install_in_lisp();
// Clasp_Qt_RZ_Bridge* clasp_qt_rz_bridge_;

 void* held_bindings_;

public:

 typedef std::function<void(void**, QString, void*)> Callback_type;

 typedef std::function<void(void)> Void_Callback_type;


// static core::LispHolder* global_lisp_holder;

 RZ_QClasp_Eval();

 QString eval_string(QString qcode, void* eval_data);
 QString eval_string(QString qcode);



 void start_aclasp(char argc, char* argv []);
 void start_bclasp(char argc, char* argv []);
 void start_iclasp(char argc, char* argv []);


 void start_clasp_from_dir(char argc, char* argv [], QString dir);



 void start_clasp(char argc, char* argv []);

  void start_clasp(char argc, char* argv [], Void_Callback_type cb);

  void start_cclasp(char argc, char* argv []);


 void set_clasp_callback(Callback_type& cb);

 void set_clasp_data(void* pv);

 static void* get_clasp_data();


 template<typename T>
 void eval_string(QString qcode, T& result);

 template<typename T>
 static T* get_host_data()
 {
  return reinterpret_cast<T*>(get_clasp_data());
 }

};


_RZNS(RZClasp)

#endif
