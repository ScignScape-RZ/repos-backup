

#include "rz-qclasp-generator.h"

#include "rz-qclasp-eval/rz-qclasp-eval.h"


#include <QDebug>

#include <QMessageBox>
#include <QApplication>

#include <QFileDialog>
#include <QTextStream>

#include "rzns.h"
USING_RZNS(RZClasp)

//?#include "rz-clasp-mainwindow/rz-clasp-mainwindow.h"


#include "rz-graph-core/kernel/document/rz-re-document.h"

#include "rz-graph-core/output/rz-re-pre-init-lisp.h"
#include "rz-graph-core/output/rz-re-pre-normal-lisp.h"

#include "rz-graph-code/prerun/rz-re-prerun-normalize.h"
#include "rz-graph-code/prerun/rz-re-prerun-tokens.h"
#include "rz-graph-code/prerun/rz-re-prerun-anticipate.h"

//#include "rz-graph-code/generate/rz-re-generate-cpp.h"
//#include "rz-graph-code/generate/rz-re-generate-haskell.h"
//#include "rz-graph-code/generate/rz-re-generate-tqns.h"
//#include "rz-graph-code/generate/rz-re-generate-cheerp.h"
#include "rz-graph-code/generate/rz-re-generate-clasp.h"


//#include "rz-graph-token/types/rz-type-variety.h"
#include "rz-graph-token/token/rz-lisp-token.h"

#include "rz-clasp-code/rz-clasp-code-generator.h"

#include "rz-graph-visit/rz-lisp-graph-visitor.h"

//?
//#include "rz-clasp-qt/rz-clasp-qt-mainwindow.h"
//#include "rz-qclasp-each/rz-qclasp-each.h"

#include <QList>

#include <QRegularExpression>


QString read_file(QString path)
{
 QFile in_file(path);
 if (in_file.open(QFile::ReadOnly | QFile::Text))
 {
  QTextStream in(&in_file);
  return in.readAll();
 }
 return QString();
}

void RZ_QClasp_Generator::compile_rz(QString file_name, QString& result)
{
 RE_Document* doc = new RE_Document(file_name);
 doc->parse();

 doc->report_graph(file_name + ".txt");

 RE_Pre_Normal_Lisp prenorm(doc);
 prenorm.output("..prenorm.txt");

 RE_Prerun_Tokens tokens(doc); //, &RZ_Lisp_Token::init_lisp_token);
 tokens.output("..prenorm2.txt");


 RE_Prerun_Normalize normalize(*doc->graph());


 caon_ptr<RZ_Lisp_Graph_Visitor> visitor = normalize.scan();

 visitor->set_document_directory(doc->local_directory());

 QString handlers = doc->rz_path_handlers();
 if(!handlers.isEmpty())
 {
  visitor->prepare_rz_path_handlers_output(handlers);
 }


 doc->report_graph(file_name + ".re1.txt");

 RE_Pre_Normal_Lisp prenorm1(doc);
 prenorm1.output("..prenorm1.txt");


 RZ_Clasp_Code_Generator& ccg = *visitor->rz_clasp_code_generator();


 RE_Generate_Clasp gen(*visitor);


 RE_Prerun_Anticipate anticipate(*visitor);

 RZ_File_List_Type extra_files;

 gen.init_project(extra_files);
 anticipate.scan();

 QString output;
 QTextStream qts(&output);


 gen.write(qts);

 QString output1;


 QTextStream qts1(&output1);


 ccg.write(qts1);

 QString result_file = doc->local_path() + ".cl";
 QFile outfile(result_file);


 if(outfile.open(QIODevice::WriteOnly | QIODevice::Text))
 {
  QTextStream out(&outfile);
  out << output1;
 }
 result = output1;
}

//?
//QString RZ_QClasp_Bridge::eval_rz_file(QString file_name)
//{
// QString code;
// compile_rz(file_name, code);
// eval_string(code);
// return code;
//}

