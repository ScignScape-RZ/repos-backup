
#include "rz-qclasp-qt-mainwindow.h"

#include "rz-qclasp-bridge/rz-qclasp-bridge.h"

#include "rz-qclasp-bridge/rz-qclasp-invokable.h"

#include "rz-qclasp-bridge/rz-qclasp-router.h"

#include <QRegularExpression>

#include <QMessageBox>
#include <QVBoxLayout>

#include <QDebug>

USING_RZNS(RZClasp)

#define _ADDRESS_MODEL_64
#define X86
#define USE_BOEHM
#undef slots

#include "boehmdc/config.h"

#include <clasp/core/object.h>

#include <clasp/core/externalObject.h>
#include <clasp/core/numbers.h>
#include <clasp/core/predicates.h>


Qt_MainWindow::Qt_MainWindow() 
 : QMainWindow(nullptr) 
{
 //?this->setWindowTitle( ... );
}

void Qt_MainWindow::show()
{
 this->QMainWindow::show();
}
