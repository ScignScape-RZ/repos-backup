
#ifndef RZ_CLASP_QT_MAINWINDOW__H
#define RZ_CLASP_QT_MAINWINDOW__H

#include <QString>

#include <QMainWindow>

#include <QMetaObject>

#include "rzns.h"

#include <QWidget>
#include <QTextEdit>
#include <QPushButton>
#include <QVBoxLayout>

#include "rz-clasp-bridge/rz-clasp-object-factory.h"

RZNS_(RZClasp)


class RZ_QClasp_Bridge;


class Qt_MainWindow : public QMainWindow
{
 Q_OBJECT

public:

 Qt_MainWindow();

 Q_INVOKABLE void show();

};


_RZNS(RZClasp)





Q_DECLARE_METATYPE(RZ::RZClasp::Qt_MainWindow*)



#endif
