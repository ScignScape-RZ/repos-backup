trap 'echo "# $BASH_COMMAND"' DEBUG
docker build --no-cache=true -t #project-name# ./ptn-docker-image 
 
