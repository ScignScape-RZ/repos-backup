 
docker rm `docker ps --no-trunc -aq`