trap 'echo "# $BASH_COMMAND"' DEBUG 
docker push #docker-hub-username#/#project-name#
