trap 'echo "# $BASH_COMMAND"' DEBUG 
docker rmi -f $(docker images -f "dangling=true" -q)