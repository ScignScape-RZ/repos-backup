trap 'echo "# $BASH_COMMAND"' DEBUG 
docker rmi $(docker images -f "dangling=true" -q)