trap 'echo "# $BASH_COMMAND"' DEBUG 
docker run -p 127.0.0.1:#docker-port#:#local-port# -it -v #local-path#/app-deploy-data:/usr/src/app-deploy-data -u root #project-name# /bin/sh
