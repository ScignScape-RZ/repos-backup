trap 'echo "# $BASH_COMMAND"' DEBUG 
docker run -p 127.0.0.1:8080:8080 -p 127.0.0.1:#host-port#:#local-port#  -it -v #local-path#/app-deploy-data:/usr/src/app-deploy-data #project-name#
