trap 'echo "# $BASH_COMMAND"' DEBUG 
docker tag #project-name# #docker-hub-username#/#project-name#
