 
#include "ptn-data-manager.h"

#include "qunqlite-callback-parser.h"

#include <QDebug>

#include <QString>

#ifdef OPENSHIFT_DEPLOY
#define nullptr 0
#endif



PTN_Data_Manager::PTN_Data_Manager() : current_type_id_count_(0)
{

}

int PTN_Data_Manager::init_db(QString database_directory, QString database_file_name)
{
 QString* args[2] {&database_directory, &database_file_name};
 return callback("DB_Create_Or_Open", 2, args);
}

QString PTN_Data_Manager::get_last_error_code()
{
 return error_callback_();
}

QString PTN_Data_Manager::get_db_string_value(QString key)
{
 QString string_result;
 int call_result = callback("Retrieve_Str_Str", key, QString(), &string_result);
 return string_result;
}

QString PTN_Data_Manager::get_db_path_value()
{
 QString result = get_db_string_value("DBPath");
 if(result.isEmpty())
 {
  return QString("<ERROR: %1>").arg(get_last_error_code());
 }
 return result;
}

QString PTN_Data_Manager::get_db_last_open_value()
{
 QString result = get_db_string_value("LastOpen");
 if(result.isEmpty())
 {
  return QString("<ERROR: %1>").arg(get_last_error_code());
 }
 return result;
}


int PTN_Data_Manager::callback(QString message, int arglength, void* data)
{
 return allobase_callback_(message, arglength, data);
}

int PTN_Data_Manager::callback(QString message, QString key, QString value)
{
 return index_callback_(message, key, value, nullptr);
}

int PTN_Data_Manager::callback(QString message, QString key, QString value, QString* ref)
{
 return index_callback_(message, key, value, ref);
}


int PTN_Data_Manager::init_type_id_count()
{
 QString key = "Global:Type_Id_Count";
 QString string_result;
 int call_result = callback("Retrieve_Str_Str", key, QString(), &string_result);
 if(call_result == QUnQLite_Callback_Parser::All_Ok)
 {
  current_type_id_count_ = string_result.toInt();
  qDebug() << "Current type id count: " << current_type_id_count_;
  qDebug() << "Get error (should be none): " << get_last_error_code();
 }
 else if(call_result == QUnQLite_Callback_Parser::Retrieve_Problem)
 {
  current_type_id_count_ = 0;
  qDebug() << "Problem getting type id count; set to " << current_type_id_count_;
  qDebug() << "Error code: " << get_last_error_code();
 }
 return call_result;
}

int PTN_Data_Manager::save_type_id_count()
{
 QString key = "Global:Type_Id_Count";
 QString value = QString::number(current_type_id_count_);
 int call_result = callback("Save_Str_Str", key, value);
 return call_result;
}

int PTN_Data_Manager::get_silo_record_count(QString type_name)
{
 int result = 0;
 QString key = QString("Silo_Record_Count:%1").arg(type_name);

 QString string_result;
 int call_result = callback("Retrieve_Str_Str", key, QString(), &string_result);
 if(call_result == QUnQLite_Callback_Parser::All_Ok)
 {
  result = string_result.toInt();
 }
 else if(call_result == QUnQLite_Callback_Parser::Retrieve_Problem)
 {
  result = 0;
 }
 else
 {
  //?
 }
 return result;
}


int PTN_Data_Manager::save_silo_record_count(QString type_name, int value)
{
 QString key = QString("Silo_Record_Count:%1").arg(type_name);
 int result = callback("Save_Str_Str", key, QString::number(value));
 return result;
}



int PTN_Data_Manager::get_type_id(QString type_name)
{
 int result = 0;
 QString key = QString("Type_Id:%1").arg(type_name);

 QString string_result;
 int call_result = callback("Retrieve_Str_Str", key, QString(), &string_result);
 if(call_result == QUnQLite_Callback_Parser::All_Ok)
 {
  result = string_result.toInt();
 }
 else if(call_result == QUnQLite_Callback_Parser::Retrieve_Problem)
 {
  result = ++current_type_id_count_;
  save_type_id_count();
  save_type_id(type_name, result);
 }
 else
 {
  //?
 }
 return result;
}


int PTN_Data_Manager::save_type_id(QString type_name, int value)
{
 QString key = QString("Type_Id:%1").arg(type_name);
 int result = callback("Save_Str_Str", key, QString::number(value));
 return result;
}


void PTN_Data_Manager::init_silos()
{
 init_type_id_count();

 // //  for example ...
  //  test_silo_ = new Test_Silo
  //   (get_silo_record_count("Test_Silo"),
  //   get_type_id("Test_Silo"), "Test_Silo" );

}


