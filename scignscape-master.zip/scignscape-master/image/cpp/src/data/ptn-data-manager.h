
#ifndef PTN_DATA_MANAGER__H
#define PTN_DATA_MANAGER__H

#include <QString>

#include <QSharedPointer>
#include <QByteArray>

#include "../accessors.h"

#include "qunqlite-callback-parser.h"

#include <functional>

class PTN_Contact_Suggestion_Silo;


class PTN_Data_Manager
{

 //?typedef std::function<int(QString message, int arglength, void* data)> allobase_callback_type;


// typedef int(*allobase_callback_type)(QString message, int arglength, void* data);
// typedef int(*index_callback_type)(QString message, QString key, QString value, QString* ref);

 typedef std::function<int(QString message, int arglength, void* data)> allobase_callback_type;
 typedef std::function<int(QString message, QString key, QString value, QString* ref)> index_callback_type;
 typedef std::function<QString()> error_callback_type;


 PTN_Contact_Suggestion_Silo* ptn_contact_suggestion_silo_;

 int current_type_id_count_;

public:

 PTN_Data_Manager();

 allobase_callback_type allobase_callback_;

 index_callback_type index_callback_;

 error_callback_type error_callback_;

 //?int index1_callback_;
  //?
 //?index1_callback_type index1_callback_;

 ACCESSORS(allobase_callback_type ,allobase_callback)
 ACCESSORS(index_callback_type ,index_callback)
 ACCESSORS(error_callback_type ,error_callback)

 ACCESSORS(PTN_Contact_Suggestion_Silo* ,ptn_contact_suggestion_silo)


 int init_db(QString database_directory, QString database_file_name);

 int callback(QString message, int arglength, void* data);

 int callback(QString message, QString key, QString value);

 int callback(QString message, QString key, QString value, QString* ref);

 QString get_last_error_code();

 int init_type_id_count();

 int get_silo_record_count(QString type_name);
 int save_silo_record_count(QString type_name, int value);

 int get_type_id(QString type_name);
 int save_type_id(QString type_name, int value);

 void init_silos();
 int save_type_id_count();

 QString get_db_string_value(QString key);
 QString get_db_path_value();
 QString get_db_last_open_value();

 template<typename Silo_type>
 int check_save_silo_record_count(Silo_type& st)
 {
  if(int new_record_count = st.check_save_record_count() )
  {
   return save_silo_record_count(st.type_name(), new_record_count);
  }
  else
  {
   return QUnQLite_Callback_Parser::All_Up_To_Date;
  }
 }

// template<typename Silo_type>
// typename Silo_type::Joinee_type* get_joinee(Silo_type& st, int record_id)
// {
// }

 template<typename Silo_type, typename Joinee_type, typename Record_type>
 int save_new_silo_joinee(Silo_type& st, Joinee_type& jt, Record_type& rt)
 {
  QSharedPointer<QByteArray> qba(new QByteArray);
  rt.supply_data(*qba);
  QString key = QString("%1-%2").arg(st.type_id()).arg(rt.uid());
  void* args[2] = {&key, &qba};
  return callback("DB_Save_Generic_Data", 2, args);
 }

 template<typename Silo_type, typename Record_type>
 int load_silo_joinee(Silo_type& st, Record_type& rt)
 {
  QSharedPointer<QByteArray> qba(new QByteArray);
  QString key = QString("%1-%2").arg(st.type_id()).arg(rt.uid());
  void* args[2] = {&key, &qba};
  int call_result = callback("DB_Load_Generic_Data", 2, args);
  if(call_result == QUnQLite_Callback_Parser::All_Ok)
  {
   rt.absorb_data(*qba);
  }
  return call_result;
 }

 // template<typename Silo_type, typename Joinee_type>
 // void save_new_silo_joinee(Silo_type& st, Joinee_type& jt)
 // {
 // }



};




#endif
