#ifndef SERVER_HTTP_HPP
#define	SERVER_HTTP_HPP


#include <boost/asio.hpp>
#include <boost/regex.hpp>
#include <boost/algorithm/string/predicate.hpp>
#include <boost/functional/hash.hpp>

#include <boost/filesystem.hpp>


#include <unordered_map>
#include <thread>
#include <functional>
#include <iostream>
#include <sstream>


// // // added_
#include "../http_parser.h"
#include "../accessors.h"
#include "../data/ptn-data-manager.h"

#include <QUrlQuery>

#include <QDebug>


typedef std::map<std::string, std::string> string_map;
typedef std::list<std::string> string_list;

string_list split(const std::string & s, const std::string & delim,
  bool keep_empty = true);

namespace ParseWebData {

/*!
 * Map string -> string
 */
typedef std::map<std::string, std::string> string_map;

/*!
 * Passed variable structure
 */
struct WebData {
 WebData() {
 }
 WebData(QString _value) : //const std::string& _value) :
   value(_value) {
 }
 /*!
  * Value of variable
  */
 //?std::string
 QString value;
 /*!
  * Additional attributes of variable
  */
 QMultiMap<QString, QString> attributes;
};

/*!
 * Map Variable name to variable structure
 */
typedef std::map<QString, WebData> WebDataMap;
}

void map_pairs(const std::string& s, const std::string& elemDelim,
  const std::string& pairDelim, QMultiMap<QString, QString>& result);

namespace ParseWebData {
namespace ParseMultipartFormData {

class ParseData {
public:
 ParseData(WebDataMap& _dataMap) :
   dataMap(_dataMap) {
 }
 void operator()(std::string data) {
  WebData outData;
  std::istringstream dataStream(data);
  std::string header;
  while (true) {
   std::string line;
   std::getline(dataStream, line);
   if (line.rfind('\r') == line.length() - 1)
    line.erase(line.rfind('\r'), 1);
   if (line.empty())
    break;
   header += line + "\n";
  }
  //QMultiMap<QString, QString>
  //outData.attributes =
  map_pairs(header, "\n", ": ", outData.attributes);
   //if(outData.attributes.contains("Content-Disposition"))
  //?string_map::iterator
  QMultiMap<QString, QString>::Iterator iter = outData.attributes.find("Content-Disposition");
  if (iter != outData.attributes.end())
  {
   QMultiMap<QString, QString> extraParam;

   QString teq = QString("type=%1").arg(iter.value());

   //?string_map extraParam =
   map_pairs(
     teq.toStdString(), "; ", "=", extraParam);
   //?outData.attributes.erase(iter);
   //?

   QMapIterator<QString, QString> it(extraParam);

   while(it.hasNext())
   {
    it.next();

    QString k = it.key();
    QString v = it.value();

    outData.attributes.insertMulti(it.key(), it.value());
    //outData.attributes.insert(extraParam.begin(), extraParam.end());

    //outData.attributes.

   }
  }

  //?for (iter = outData.attributes.begin();
  //?  iter != outData.attributes.end(); ++iter)

  QString new_v;

  QMutableMapIterator<QString, QString> it(outData.attributes);
  while(it.hasNext())
  {
   it.next();

   QString qk = it.key();
   QString& qv = it.value();


   std::string k = it.key().toStdString();
   std::string v = qv.toStdString();

   std::string::size_type start = v.find_first_not_of(
     "\"");
   std::string::size_type stop = v.find_last_not_of("\"");
   if (start == std::string::npos)
    v.clear();
   else
    v = v.substr(start, stop - start + 1);

   qv = QString::fromStdString(v);

  }

  std::ostringstream valueStream;
  std::copy(std::istreambuf_iterator<char>(dataStream),
    std::istreambuf_iterator<char>(),
    std::ostreambuf_iterator<char>(valueStream));

  outData.value = QString::fromStdString( valueStream.str() );
  dataMap.insert(std::make_pair(outData.attributes.value("name"), outData));
 }

private:
 WebDataMap& dataMap;
};

void sanitize_parts(string_list& parts);
//{
// string_list::iterator iter = parts.begin();
// while (iter != parts.end()) {

//  if ((*iter).find("--\r\n") == 0) { // If part starts with --\r\n - it is last boundary. remove
//   iter = parts.erase(iter);
//   continue;
//  }

//  if ((*iter).find("\r\n") == 0) { // Due to split command all parts starts with empty line. Remove it
//   (*iter).erase(0, 2);
//  }
//  if ((*iter).rfind("\r\n") == (*iter).length() - 2) { // Due to split command all parts ends with CRLF. Remove it
//   (*iter).erase((*iter).rfind("\r\n"), 2);
//  }
//  ++iter;
// }
//}

template<typename T>
bool parse_data(const std::string& data, const T& content_type, //const std::unordered_multimap<std::string, std::string>& content_type, //?const string_map& content_type,
  WebDataMap& dataMap)
{

 typename T::const_iterator bndIter = content_type.find("boundary");
 if (content_type.end() == bndIter) // No boundary indicator!
  return false;
 string_list parts = split(data, std::string("--") + bndIter.value().toStdString(),  //bndIter->second,
                           false);
 sanitize_parts(parts);

 string_list::iterator iter = parts.begin();
 while (iter != parts.end())
 {

  QString p = QString::fromStdString(*iter);

    //?  std::cout << p.toStdString() << std::endl;
  ++iter;
 }


 std::for_each(parts.begin(), parts.end(), ParseData(dataMap));
 return true;
}

} // namespace ParseMultipartFormData
} // namespace ParseWebData




namespace map_pairs_helper {

class ParsePairsFunc
{
public:
 ParsePairsFunc(const std::string& _pairDelim, QMultiMap<QString, QString>& _result) :
   pairDelim(_pairDelim), result(_result) {
 }
 void operator ()(const std::string& value) {
  string_list list = split(value, pairDelim);
  std::pair<QString, QString> pair;
  string_list::const_iterator iter = list.begin();
  if (iter != list.end()) {
   pair.first = QString::fromStdString(*iter);
   iter++;
   if (iter != list.end()) {
    pair.second = QString::fromStdString(*iter);
   }
  }

  result.insert(pair.first, pair.second);
 }

private:
 const std::string& pairDelim;
 QMultiMap<QString, QString>& result;
};
} // namespace map_pairs_helper


// // // _added



namespace SimpleWeb {

template <class socket_type>
class ServerBase
{

protected:
 PTN_Data_Manager* data_manager_;

public:
 virtual ~ServerBase() {}

 class Response : public std::ostream
 {
  friend class ServerBase<socket_type>;

  boost::asio::streambuf streambuf;

  std::shared_ptr<socket_type> socket;

  Response(std::shared_ptr<socket_type> socket): std::ostream(&streambuf), socket(socket) {}

 public:
  size_t size() {
   return streambuf.size();
  }
 };

 class Content : public std::istream
 {
  friend class ServerBase<socket_type>;
 public:
  size_t size() {
   return streambuf.size();
  }
  std::string string() {
   std::stringstream ss;
   ss << rdbuf();
   return ss.str();
  }
 private:
  boost::asio::streambuf &streambuf;
  Content(boost::asio::streambuf &streambuf): std::istream(&streambuf), streambuf(streambuf) {}
 };

 class Request
 {
  friend class ServerBase<socket_type>;

  // // // added_


#define STATIC_DEF(N) \
 static int Static_On_ ## N(http_parser* parser, const char* str, size_t size) \
 { \
  Request* this_ = static_cast<Request*>(parser->data); \
  return this_->On_ ## N(parser, str, size); \
 } \


#define STATIC_DEF_SH(N) \
 static int Static_On_ ## N(http_parser* parser) \
 { \
  Request* this_ = static_cast<Request*>(parser->data); \
  return this_->On_ ## N(parser); \
 } \


  STATIC_DEF(Url)
  STATIC_DEF_SH(Message_Begin)
  STATIC_DEF(Header_Value)
  STATIC_DEF(Body)
  STATIC_DEF_SH(Chunk_Complete)
  STATIC_DEF_SH(Chunk_Header)
  STATIC_DEF_SH(Message_Complete)
  STATIC_DEF_SH(Headers_Complete)
  STATIC_DEF(Header_Field)
  STATIC_DEF(Status)


  int On_Url(http_parser* parser, const char* str, size_t size)
  {
   //?path = str;
   //?url = str;

   path = std::string(str, size);

   QString qp = QString::fromStdString(path);

   QUrl url(qp);

  #ifdef OPENSHIFT_DEPLOY
   qurl_ = url;
  #else
   qurl_query_.setQuery(url.query());
  #endif
   return 0;
  }

  int On_Message_Begin(http_parser* parser)
  {
   method = http_method_str( (http_method) parser->method);

#ifdef LINUX_LOCAL
 QString rm = QString::fromStdString(method);
#endif


   //       request->header.insert(std::make_pair(line.substr(0, param_end), line.substr(value_start, line.size()-value_start-1)));
   return 0;
  }

  int On_Header_Value(http_parser* parser, const char* str, size_t size)
  {
#ifdef LINUX_LOCAL
 QString hf = QString::fromStdString(current_header_field);
 QString hv = QString::fromStdString(std::string(str, size));


#endif

   header.insert(std::make_pair(current_header_field, std::string(str, size)));
   return 0;
  }

  int On_Body(http_parser* parser, const char* str, size_t size)
  {
   body_qba_.insert(content_read_so_far_, str, size);

   content_read_so_far_ += size;

   //? qDebug() << "On body (1) ...";

   //? qDebug() << "crsf: ..." << content_read_so_far_ << " cl: " << content_length_;


   if(content_read_so_far_ < content_length_)
   {
    //? qDebug() << "Looking for content...";
    return 0;
   }
   else
   {
    //? qDebug() << "Parse body...";

    parse_body();
    return 0;
   }
  }

  void parse_body()
  {
   //? qDebug() << "Parse body (2) ..." << body_qba_;



   std::string data (body_qba_.constData());
     //?= body_qba_.toStdString();

   //? std::cout << std::endl << "Data: " << data;
   //? std::cout.flush();

   ParseWebData::WebDataMap wdm;
   auto it = header.find("Content-Type");

   if(it != header.end())
   {
    std::string contentType = (*it).second;

    QString qct = QString::fromStdString(contentType);


    if(qct.startsWith("multipart/form-data"))
    {
//     if(num_additional_bytes_ > 0)
//      return 0;

     QMultiMap<QString, QString> ct;

     map_pairs(
       std::string("content-type=") + contentType, "; ", "=", ct);

     ParseWebData::ParseMultipartFormData::parse_data(data, ct, wdm);

     for(ParseWebData::WebDataMap::const_iterator it = wdm.begin();
       it != wdm.end(); ++it)
     {
      QString k = it->first;
      QString v = it->second.value;

      form_data_.insertMulti(k, v);
     }
    }
    else
    {
     map_pairs(data, "&", "=", form_data_);
    }
   }
  }

  int On_Chunk_Complete(http_parser* parser)
  {
   return 0;
  }

  int On_Headers_Complete(http_parser* parser)
  {
   auto it = header.find("Content-Length");
   if(it != header.end())
   {
    content_length_ = stoull(it->second);
    if(content_length_ > 0)
    {
     //?body_qba_.reserve(content_length_);
     body_qba_.resize(content_length_);
    }
   }
   return 0;
  }

  int On_Header_Field(http_parser* parser, const char* str, size_t size)
  {
   current_header_field = std::string(str, size);
   return 0;
  }

  int On_Chunk_Header(http_parser* parser)
  {
   return 0;
  }

  int On_Message_Complete(http_parser* parser)
  {
   return 0;
  }

  int On_Status(http_parser* parser, const char* str, size_t size)
  {
    //?QString s = QString::fromStdString(str);
   return 0;
  }

   // // // _added


  //Based on http://www.boost.org/doc/libs/1_60_0/doc/html/unordered/hash_equality.html
  class iequal_to
  {
  public:
   bool operator()(const std::string &key1, const std::string &key2) const {
    return boost::algorithm::iequals(key1, key2);
   }
  };
  class ihash
  {
  public:
   size_t operator()(const std::string &key) const
   {
    std::size_t seed=0;
    for(auto &c: key)
     boost::hash_combine(seed, std::tolower(c));
    return seed;
   }
  };
 public:
  std::string method, path, http_version;

  // // added
  std::string current_header_field;

  typedef QMultiMap<QString, QString> form_data_type;

  ACCESSORS(size_t ,num_additional_bytes)

  ACCESSORS(unsigned long long  ,content_length)
  ACCESSORS(unsigned long long  ,content_read_so_far)

  ACCESSORS__RGET(form_data_type ,form_data)


  PTN_Data_Manager* data_manager_;

  int num_additional_bytes_;
  unsigned long long content_length_;
  unsigned long long content_read_so_far_;


  unsigned long long  check_append_body()
  {
   if(content_read_so_far_ < content_length_)
   {
    int rem = content_length_ - content_read_so_far_;
    //size_t len = 80*1024;
    char buf[rem];

    for(int i = 0; i < rem; ++i)
    {
     buf[i] = 0;
    }

    ssize_t recved = 0;
    std::istream& stream = content;
    recved = stream.readsome(buf, rem);

    body_qba_.insert(content_read_so_far_, buf, recved);

    content_read_so_far_ += recved;
    return content_length_ - content_read_so_far_;

   }
   return 0;
  }

  ACCESSORS(PTN_Data_Manager* ,data_manager)

  ACCESSORS(QUrlQuery ,qurl_query)

  Content content;

  std::unordered_multimap<std::string, std::string, ihash, iequal_to> header;

  boost::smatch path_match;

  std::string remote_endpoint_address;
  unsigned short remote_endpoint_port;


 private:

  Request(PTN_Data_Manager* data_manager): content(streambuf), num_additional_bytes_(0),
    content_length_(0), content_read_so_far_(0),
    data_manager_(data_manager)
  {}

  boost::asio::streambuf streambuf;

  QMultiMap<QString, QString> form_data_;


  QUrlQuery qurl_query_;

  QByteArray body_qba_;


 //? Request(): content(streambuf) {}

 };

 class Config
 {
  friend class ServerBase<socket_type>;

  Config(unsigned short port, size_t num_threads): num_threads(num_threads), port(port), reuse_address(true) {}
  size_t num_threads;
 public:
  unsigned short port;
  ///IPv4 address in dotted decimal form or IPv6 address in hexadecimal notation.
  ///If empty, the address will be any address.
  std::string address;
  ///Set to false to avoid binding the socket to an address that is already in use.
  bool reuse_address;
 };
 ///Set before calling start().
 Config config;

 std::unordered_map<std::string, std::unordered_map<std::string,
 std::function<void(std::shared_ptr<typename ServerBase<socket_type>::Response>, std::shared_ptr<typename ServerBase<socket_type>::Request>)> > >  resource;

 std::unordered_map<std::string,
 std::function<void(std::shared_ptr<typename ServerBase<socket_type>::Response>, std::shared_ptr<typename ServerBase<socket_type>::Request>)> > default_resource;

 std::function<void(const std::exception&)> exception_handler;

private:
 std::vector<std::pair<std::string, std::vector<std::pair<boost::regex,
 std::function<void(std::shared_ptr<typename ServerBase<socket_type>::Response>, std::shared_ptr<typename ServerBase<socket_type>::Request>)> > > > > opt_resource;

public:
 void start()
 {
  //Copy the resources to opt_resource for more efficient request processing
  opt_resource.clear();
  for(auto& res: resource)
  {
   for(auto& res_method: res.second)
   {
    auto it=opt_resource.end();
    for(auto opt_it=opt_resource.begin();opt_it!=opt_resource.end();opt_it++)
    {
     if(res_method.first==opt_it->first)
     {
      it=opt_it;
      break;
     }
    }
    if(it==opt_resource.end())
    {
     opt_resource.emplace_back();
     it=opt_resource.begin()+(opt_resource.size()-1);
     it->first=res_method.first;
    }
    it->second.emplace_back(boost::regex(res.first), res_method.second);
   }
  }

  if(io_service.stopped())
   io_service.reset();

  boost::asio::ip::tcp::endpoint endpoint;
  if(config.address.size()>0)
   endpoint=boost::asio::ip::tcp::endpoint(boost::asio::ip::address::from_string(config.address), config.port);
  else
   endpoint=boost::asio::ip::tcp::endpoint(boost::asio::ip::tcp::v4(), config.port);
  acceptor.open(endpoint.protocol());
  acceptor.set_option(boost::asio::socket_base::reuse_address(config.reuse_address));
  acceptor.bind(endpoint);
  acceptor.listen();

  accept();

  //If num_threads>1, start m_io_service.run() in (num_threads-1) threads for thread-pooling
  threads.clear();
  for(size_t c=1;c<config.num_threads;c++)
  {
   threads.emplace_back([this](){
    io_service.run();
   });
  }

  //Main thread
  io_service.run();

  //Wait for the rest of the threads, if any, to finish as well
  for(auto& t: threads)
  {
   t.join();
  }
 }

 void stop()
 {
  acceptor.close();
  io_service.stop();
 }

 ///Use this function if you need to recursively send parts of a longer message
 void send(std::shared_ptr<Response> response, const std::function<void(const boost::system::error_code&)>& callback=nullptr) const {
  boost::asio::async_write(*response->socket, response->streambuf, [this, response, callback](const boost::system::error_code& ec, size_t /*bytes_transferred*/) {
   if(callback)
    callback(ec);
  });
 }

protected:
 boost::asio::io_service io_service;
 boost::asio::ip::tcp::acceptor acceptor;
 std::vector<std::thread> threads;

 long timeout_request;
 long timeout_content;

 ServerBase(unsigned short port, size_t num_threads, long timeout_request, long timeout_send_or_receive) :
   config(port, num_threads), acceptor(io_service),
   timeout_request(timeout_request), timeout_content(timeout_send_or_receive) {}

 virtual void accept()=0;

 std::shared_ptr<boost::asio::deadline_timer> set_timeout_on_socket(std::shared_ptr<socket_type> socket, long seconds) {
  std::shared_ptr<boost::asio::deadline_timer> timer(new boost::asio::deadline_timer(io_service));
  timer->expires_from_now(boost::posix_time::seconds(seconds));
  timer->async_wait([socket](const boost::system::error_code& ec){
   if(!ec) {
    boost::system::error_code ec;
    socket->lowest_layer().shutdown(boost::asio::ip::tcp::socket::shutdown_both, ec);
    socket->lowest_layer().close();
   }
  });
  return timer;
 }

 void read_request_and_content(std::shared_ptr<socket_type> socket)
 {

  //Create new streambuf (Request::streambuf) for async_read_until()
  //shared_ptr is used to pass temporary objects to the asynchronous functions
  std::shared_ptr<Request> request(new Request(data_manager_));
  try
  {
   request->remote_endpoint_address=socket->lowest_layer().remote_endpoint().address().to_string();
   request->remote_endpoint_port=socket->lowest_layer().remote_endpoint().port();
  }
  catch(const std::exception &e)
  {
   if(exception_handler)
    exception_handler(e);
  }

  //Set timeout on the following boost::asio::async-read or write function
  std::shared_ptr<boost::asio::deadline_timer> timer;
  if(timeout_request>0)
   timer=set_timeout_on_socket(socket, timeout_request);

  boost::asio::async_read_until(*socket, request->streambuf, "\r\n\r\n",
                                [this, socket, request, timer](const boost::system::error_code& ec, size_t bytes_transferred) {
   if(timeout_request>0)
    timer->cancel();
   if(!ec)
   {
    //?   qDebug() << "RRAC: no ec ...";

    //request->streambuf.size() is not necessarily the same as bytes_transferred, from Boost-docs:
    //"After a successful async_read_until operation, the streambuf may contain additional data beyond the delimiter"
    //The chosen solution is to extract lines from the stream directly when parsing the header. What is left of the
    //streambuf (maybe some bytes of the content) is appended to in the async_read-function below (for retrieving content).
    size_t num_additional_bytes=request->streambuf.size()-bytes_transferred;

    if(!parse_request(request, request->content))
     return;

    //If content, read that as well
    auto it=request->header.find("Content-Length");
    if(it!=request->header.end())
    {
     //Set timeout on the following boost::asio::async-read or write function
     std::shared_ptr<boost::asio::deadline_timer> timer;
     if(timeout_content>0)
      timer=set_timeout_on_socket(socket, timeout_content);
     unsigned long long content_length;
     try
     {
      content_length=stoull(it->second);
     }
     catch(const std::exception &e)
     {
      if(exception_handler)
       exception_handler(e);
      return;
     }
     if(content_length>num_additional_bytes)
     {
      boost::asio::async_read(*socket, request->streambuf,
                              boost::asio::transfer_exactly(content_length-num_additional_bytes),
                              [this, socket, request, timer]
                              (const boost::system::error_code& ec, size_t /*bytes_transferred*/)
      {

       int rem = request->check_append_body();
       //if(request->content_read_so_far() < request->content_length())
       if(rem > 0)
       {
       }
       else
       {
        request->parse_body();
       }


       if(timeout_content>0)
        timer->cancel();
       if(!ec)
        find_resource(socket, request);
      });
     }
     else
     {
      if(timeout_content>0)
       timer->cancel();
      find_resource(socket, request);
     }
    }
    else
    {
     find_resource(socket, request);
    }
   }
  });
 }

 bool parse_request(std::shared_ptr<Request> request, std::istream& stream) const
 {

  http_parser parser;
  parser.data = request.get();
  //http_parser* parser = (http_parser*) malloc(sizeof(http_parser));
  http_parser_init(&parser, HTTP_REQUEST);

  http_parser_settings settings;
  //?parser->data = &req;
  //http_data_cb* hdcb = url_cb->target<http_data_cb>();

  settings.on_url = Request::Static_On_Url;
  settings.on_message_begin = Request::Static_On_Message_Begin;
  settings.on_header_value = Request::Static_On_Header_Value;
  settings.on_body = Request::Static_On_Body;
  settings.on_chunk_complete = Request::Static_On_Chunk_Complete;
  settings.on_chunk_header = Request::Static_On_Chunk_Header;
  settings.on_headers_complete = Request::Static_On_Headers_Complete;
  settings.on_header_field = Request::Static_On_Header_Field;
  settings.on_message_begin = Request::Static_On_Message_Begin;
  settings.on_message_complete = Request::Static_On_Message_Complete;
  settings.on_status = Request::Static_On_Status;

  //
  //QByteArray received = stream.read(); //stream.readAll();

  size_t nparsed;
  size_t len = 80*1024;
  char buf[len];

  ssize_t recved = 0;



  // loop ok?

  recved = stream.readsome(buf, len);

//?
//  ssize_t recved1;
//  recved1 = stream.readsome(buf, len);
//  std::cout << "\n\n\nBUF1: \n\n";
//  std::cout << buf;


  nparsed = http_parser_execute(&parser, &settings, buf, recved);

//                               #ifdef QT_LOCAL
//                                received.data()
//                               #else
//                                received
//                               #endif
//                                , received_length);


  return true;


  std::string line;
  getline(stream, line);
  size_t method_end;
  if((method_end=line.find(' '))!=std::string::npos)
  {
   size_t path_end;
   if((path_end=line.find(' ', method_end+1))!=std::string::npos)
   {
    request->method=line.substr(0, method_end);
    request->path=line.substr(method_end+1, path_end-method_end-1);

    size_t protocol_end;
    if((protocol_end=line.find('/', path_end+1))!=std::string::npos)
    {
     if(line.substr(path_end+1, protocol_end-path_end-1)!="HTTP")
      return false;
     request->http_version=line.substr(protocol_end+1, line.size()-protocol_end-2);
    }
    else
     return false;

    getline(stream, line);
    size_t param_end;
    while((param_end=line.find(':'))!=std::string::npos)
    {
     size_t value_start=param_end+1;
     if((value_start)<line.size())
     {
      if(line[value_start]==' ')
       value_start++;
      if(value_start<line.size())
       request->header.insert(std::make_pair(line.substr(0, param_end), line.substr(value_start, line.size()-value_start-1)));
     }

     getline(stream, line);
    }
   }
   else
    return false;
  }
  else
   return false;
  return true;
 }

 void find_resource(std::shared_ptr<socket_type> socket, std::shared_ptr<Request> request)
 {
  //Find path- and method-match, and call write_response
  for(auto& res: opt_resource)
  {
   if(request->method==res.first)
   {
    for(auto& res_path: res.second)
    {
     boost::smatch sm_res;
     if(boost::regex_match(request->path, sm_res, res_path.first))
     {
      request->path_match=std::move(sm_res);
      write_response(socket, request, res_path.second);
      return;
     }
    }
   }
  }
  auto it_method=default_resource.find(request->method);
  if(it_method!=default_resource.end())
  {
   write_response(socket, request, it_method->second);
  }
 }

 void write_response(std::shared_ptr<socket_type> socket, std::shared_ptr<Request> request,
                     std::function<void(std::shared_ptr<typename ServerBase<socket_type>::Response>,
                                        std::shared_ptr<typename ServerBase<socket_type>::Request>)>& resource_function) {
  //Set timeout on the following boost::asio::async-read or write function
  std::shared_ptr<boost::asio::deadline_timer> timer;
  if(timeout_content>0)
   timer=set_timeout_on_socket(socket, timeout_content);

  auto response=std::shared_ptr<Response>(new Response(socket), [this, request, timer](Response *response_ptr) {
   auto response=std::shared_ptr<Response>(response_ptr);
   send(response, [this, response, request, timer](const boost::system::error_code& ec) {
    if(!ec) {
     if(timeout_content>0)
      timer->cancel();
     float http_version;
     try {
      http_version=stof(request->http_version);
     }
     catch(const std::exception &e){
      if(exception_handler)
       exception_handler(e);
      return;
     }

     auto range=request->header.equal_range("Connection");
     for(auto it=range.first;it!=range.second;it++)
     {
      if(boost::iequals(it->second, "close"))
       return;
     }
     if(http_version>1.05)
      read_request_and_content(response->socket);
    }
   });
  });

  try
  {
   resource_function(response, request);
  }
  catch(const std::exception &e) {
   if(exception_handler)
    exception_handler(e);
   return;
  }
 }
};

template<class socket_type>
class Server : public ServerBase<socket_type> {};

typedef boost::asio::ip::tcp::socket HTTP;

template<>
class Server<HTTP> : public ServerBase<HTTP>
{

private:

 QString default_data_directory_;

 boost::filesystem::path web_root_path_;
 boost::filesystem::path data_root_path_;




public:
 Server(unsigned short port, size_t num_threads=1, long timeout_request=5, long timeout_content=300) :
   ServerBase<HTTP>::ServerBase(port, num_threads, timeout_request, timeout_content)
 {
  data_manager_ = new PTN_Data_Manager;

//#ifdef TESTING_LOCAL
//  web_root_path_ = "/home/nlevisrael/docker/ptn/ptn-docker-image/web/ptn/public";
//  data_root_path_ = "/home/nlevisrael/docker/ptn/ptn-docker-image/cpp/app/src/data";
//#else
//  web_root_path_ = "/usr/src/myapp/web/ptn/public";
//  data_root_path_ = "/usr/src/myapp/cpp/app/src/data";
//#endif  // TESTING_LOCAL



//#ifdef QT_LOCAL
//  web_root_path_ = "/home/nlevisrael/rz-dev/ptn/web/ptn/public";
//  data_root_path_ = "/home/nlevisrael/rz-dev/ptn/web/ptn/app/data";
//#else
// #ifdef LINUX_LOCAL
//  web_root_path_ = "/home/nlevisrael/rz-dev/ptn/web/ptn/public";
//  data_root_path_ = "/home/nlevisrael/rz-dev/ptn/web/ptn/app/data";
// #else
//  std::stringstream file_ss;
//  file_ss << getenv("OPENSHIFT_HOMEDIR") << "app-root" ;// /repo/public";
//  web_root_path_ = file_ss.str();// "/home/nlevisrael/rz-dev/ptn/web/ptn/public";
//  web_root_path_ /= "repo/public";

//  data_root_path_ = file_ss.str();
//  data_root_path_ /= "data/app/data";
//#endif
//#endif

 }

 ACCESSORS(PTN_Data_Manager* ,data_manager)
 ACCESSORS(QString ,default_data_directory)

 ACCESSORS(boost::filesystem::path ,web_root_path)
 ACCESSORS(boost::filesystem::path ,data_root_path)

 std::string data_root_std_string()
 {
  return data_root_path_.string();
 }

 std::string web_root_std_string()
 {
  return data_root_path_.string();
 }

 QString data_root_string()
 {
  return QString::fromStdString(data_root_std_string());
 }

 QString web_root_string()
 {
  return QString::fromStdString(web_root_std_string());
 }

 typedef std::function<int(QString message, int arglength, void* data)> allobase_callback_type;
 typedef std::function<int(QString message, QString key, QString value, QString* ref)> index_callback_type;
 typedef std::function<QString()> error_callback_type;

 void allobase_init(QString default_data_directory,
  QString default_database_name,
  allobase_callback_type act, index_callback_type ict, error_callback_type ect)
 {
  set_default_data_directory(default_data_directory);
  data_manager_->set_allobase_callback(act);
  data_manager_->set_index_callback(ict);
  data_manager_->set_error_callback(ect);

  int init_db_result = data_manager_->init_db(default_data_directory_, default_database_name);

  std::cout.flush();

  if(init_db_result == QUnQLite_Callback_Parser::All_Ok)
  {
   std::cout << std::endl << "DB Open ...";

   QString ec = data_manager_->get_last_error_code();
   QString dp = data_manager_->get_db_path_value();
   QString lo = data_manager_->get_db_last_open_value();

   std::cout << std::endl << "EC: " << ec.toStdString()
             << std::endl << "DP: " << dp.toStdString()
             << std::endl << "LO: " << lo.toStdString()
             << std::endl;

  }
  else
  {
   std::cout << std::endl << "DB was not opened...";

   QString ec = data_manager_->get_last_error_code();
   QString dp = data_manager_->get_db_path_value();
   QString lo = data_manager_->get_db_last_open_value();

   std::cout << std::endl << "EC: " << ec.toStdString()
             << std::endl << "DP: " << dp.toStdString()
             << std::endl << "LO: " << lo.toStdString()
             << std::endl;

  }

  std::cout.flush();

  data_manager_->init_silos();


 }


private:



protected:
 void accept()
 {
  //Create new socket for this connection
  //Shared_ptr is used to pass temporary objects to the asynchronous functions
  std::shared_ptr<HTTP> socket(new HTTP(io_service));

  acceptor.async_accept(*socket, [this, socket](const boost::system::error_code& ec)
  {
   //Immediately start accepting a new connection
   accept();

   if(!ec)
   {
    boost::asio::ip::tcp::no_delay option(true);
    socket->set_option(option);

    read_request_and_content(socket);
   }
  });
 }
};

}

#endif	/* SERVER_HTTP_HPP */
