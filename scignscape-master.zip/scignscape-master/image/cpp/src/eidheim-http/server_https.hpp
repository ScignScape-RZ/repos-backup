#ifndef SERVER_HTTPS_HPP
#define	SERVER_HTTPS_HPP

#include "server_http.hpp"
#include <boost/asio/ssl.hpp>

namespace SimpleWeb {

typedef boost::asio::ssl::stream<boost::asio::ip::tcp::socket> HTTPS;

template<>
class Server<HTTPS> : public ServerBase<HTTPS>
{
public:

 ACCESSORS(PTN_Data_Manager* ,data_manager)

 Server(unsigned short port, size_t num_threads, const std::string& cert_file,
        const std::string& private_key_file,
        long timeout_request=5, long timeout_content=300,
        const std::string& verify_file = std::string()) :
   ServerBase<HTTPS>::ServerBase(port, num_threads, timeout_request, timeout_content),

    cert_file_(QString::fromStdString(cert_file) ),
    private_key_file_(QString::fromStdString(private_key_file) ),
    verify_file_(QString::fromStdString(verify_file) ),
    context   ( io_service, boost::asio::ssl::context::tlsv12 )

 { // 2016/08/13 only use tls12, see https://www.ssllabs.com/ssltest


  context.use_certificate_chain_file(cert_file);
  context.use_private_key_file(private_key_file, boost::asio::ssl::context::pem);

  if(verify_file.size() > 0)
   context.load_verify_file(verify_file);

 }


protected:
 boost::asio::ssl::context context;
 QString verify_file_;
 QString cert_file_;
 QString private_key_file_;


 void accept()
 {



//?
//?  QString con = QString("ssl context: %1 %2 %3").arg(context.no_tlsv1).arg(context.no_sslv3).arg(context.no_sslv2);
//?    QString con = QString("ssl context: %1 %2 %3").arg(context->no_tlsv1).arg(context->no_sslv3).arg(context->no_sslv2);

//? qDebug() << "Con ..." << con;


  //Create new socket for this connection
  //Shared_ptr is used to pass objects to the asynchronous functions

 //? std::shared_ptr<HTTPS> socket(new HTTPS(io_service, *context));

  std::shared_ptr<HTTPS> socket(new HTTPS(io_service, context));

   //? qDebug() << "https created socket ...";

  acceptor.async_accept((*socket).lowest_layer(), [this, socket](const boost::system::error_code& ec)
  {
   //Immediately start accepting a new connection

   //?qDebug() << "https pre accept ...";
   accept();

   //?qDebug() << "post accept ...";

   if(!ec)
   {
    //? qDebug() << "no ec ...";

    boost::asio::ip::tcp::no_delay option(true);
    socket->lowest_layer().set_option(option);

    //Set timeout on the following boost::asio::ssl::stream::async_handshake
    std::shared_ptr<boost::asio::deadline_timer> timer;
    if(timeout_request>0)
     timer=set_timeout_on_socket(socket, timeout_request);

    (*socket).async_handshake(boost::asio::ssl::stream_base::server, [this, socket, timer]
                              (const boost::system::error_code& ec)
    {


     if(timeout_request>0)
      timer->cancel();
     if(!ec)
     {
      //? qDebug() << "RR and content ...";
      read_request_and_content(socket);
     }
     else
     {
      qDebug() << " Https error: " << QString::fromStdString( ec.message() );
      qDebug() << "  (Details) " << QString::fromStdString( ec.category().name() ) << ": " << ec.value();

//      if(ec.value() == 336130315)
//      {
//       qDebug() << "trying anyhow ...";
//       read_request_and_content(socket);
//      }

      //? read_request_and_content(socket);

     }

    });
   }
  });
 }
};
}


#endif	/* SERVER_HTTPS_HPP */

