
#ifndef HANDLER_BASE__H
#define HANDLER_BASE__H

#include "../accessors.h"


#include <QDebug>


#include "../eidheim-http/server_http.hpp"
#include "../eidheim-http/server_https.hpp"

#include <string>
#include <memory>


typedef SimpleWeb::Server<SimpleWeb::HTTP> HttpServer;

typedef SimpleWeb::Server<SimpleWeb::HTTPS> HttpsServer;


class Handler_Base
{
protected:
 std::string file_root_;

public:

 Handler_Base();

 virtual void operator()(std::shared_ptr<HttpServer::Response> response, std::shared_ptr<HttpServer::Request> request) = 0;


 ACCESSORS(std::string ,file_root)

};





#endif
