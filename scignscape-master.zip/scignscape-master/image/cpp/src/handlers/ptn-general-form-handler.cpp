 
#include "ptn-general-form-handler.h"

#include <QString>

#include <QRegExp>
#include <QMetaType>

PTN_General_Form_Handler::PTN_General_Form_Handler() : Handler_Base()
{

}

void PTN_General_Form_Handler::operator()(std::shared_ptr<HttpsServer::Response> response, std::shared_ptr<HttpsServer::Request> request)
{
 boost::smatch request_regex_match = request->path_match;

 PTN_Data_Manager* pdm = request->data_manager();

 const QMultiMap<QString, QString>& form_data = request->form_data();

 QString resp;
 process(request_regex_match, pdm, form_data, resp);

 *response << "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=UTF-8; Content-Length: "
   << resp.length() << ";\r\n\r\n" << resp.toStdString();


}


void PTN_General_Form_Handler::operator()(std::shared_ptr<HttpServer::Response> response,
  std::shared_ptr<HttpServer::Request> request)
{
 boost::smatch request_regex_match = request->path_match;

 PTN_Data_Manager* pdm = request->data_manager();

 const QMultiMap<QString, QString>& form_data = request->form_data();

 QString resp;

 process(request_regex_match, pdm, form_data, resp);

 *response << "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=UTF-8; Content-Length: "
   << resp.length() << ";\r\n\r\n" << resp.toStdString();


}

void PTN_General_Form_Handler::process(boost::smatch& request_regex_match,
  PTN_Data_Manager* pdm,
  const QMultiMap<QString, QString>& form_data, QString& response)
{
 std::string m1 = request_regex_match[1];

 QString qm1 = QString::fromStdString(m1);


 QRegExp rx ("((?:\\W+)|^)(\\w+)");
 rx.setMinimal(true);

 int s = -1;
 while((s = rx.indexIn(qm1, s+1)) >= 0)
 {
  QString r0 = rx.cap(0);
  QString r1 = rx.cap(1);
  QString r2 = rx.cap(2);

  QString r = QString(rx.cap(1).length(), '_');
  r += rx.cap(2).toUpper();
  qm1.replace(s, rx.cap(0).length(), r);
  s+= rx.cap(1).length();
 }

 qm1 += "_Form_Handler";


 int id = QMetaType::type(qm1.toLatin1());

 if(id != QMetaType::UnknownType)
 {
  // //  qDebug() << "Matched type: " << qm1 << " -- with id " << id;
  QString resp;

  QString invoke_result;
  void* pv = QMetaType::create(id);

  if(pv)
  {
   QObject* o = static_cast<QObject*>(pv);

   const QMetaObject* qmo = o->metaObject();
   bool ok1 = qmo->invokeMethod(o, "absorb_form_data",
    QArgument<const QMultiMap<QString, QString>&>("const QMultiMap<QString, QString>&", form_data)
   );

   bool ok = qmo->invokeMethod(o, "get_web_response",
    Q_RETURN_ARG(QString, invoke_result),
    QArgument<PTN_Data_Manager*>("PTN_Data_Manager*", pdm));
  }
  resp += invoke_result;
  response += resp;
 }
}

