
#ifndef PTN_GENERAL_FORM_HANDLER__H
#define PTN_GENERAL_FORM_HANDLER__H

#include "handler-base.h"


class PTN_General_Form_Handler : public Handler_Base
{

public:

 PTN_General_Form_Handler();

 void operator()(std::shared_ptr<HttpServer::Response> response, std::shared_ptr<HttpServer::Request> request); //  override;

 void operator()(std::shared_ptr<HttpsServer::Response> response, std::shared_ptr<HttpsServer::Request> request);

 void process(boost::smatch& request_regex_match, PTN_Data_Manager* pdm,
              const QMultiMap<QString, QString>& form_data, QString& response);

};



#endif
