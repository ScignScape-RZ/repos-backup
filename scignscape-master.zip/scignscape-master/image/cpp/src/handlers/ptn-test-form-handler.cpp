 
#include "ptn-test-form-handler.h"

#include <QString>

//#include "~/app-root/data/qt-everywhere-opensource-src-4.6.4/include/QString"


PVC_Test_Form_Handler::PVC_Test_Form_Handler() : Handler_Base()
{

}

void PVC_Test_Form_Handler::operator()(std::shared_ptr<HttpServer::Response> response,
  std::shared_ptr<HttpServer::Request> request)
{

// auto& cc = request->content;
// std::string c = request->content.string();
// //?request->content >> c;
// QString qs = QString::fromStdString(c);

 std::stringstream ss;

// for(auto it = request->form_data.begin(); it != request->form_data.end(); ++it)
// {
//  ss << "Key: " << it->first << " = " << it->second << "<br>";
// }

 QMapIterator<QString, QString> it(request->form_data());
 while(it.hasNext())
 {
  it.next();

  QString s = QString("\n<br>Key %1, Value: %2").arg(it.key()).arg(it.value());

  ss << s.toStdString();
 }


 std::string rc = ss.str();

 //?
 QString qrc = QString::fromStdString(rc);

 *response << "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=UTF-8; Content-Length: "
   << rc.length() << ";\r\n\r\n" << rc;

//? auto content=request->content.string();
 //request->content.string() is a convenience function for:
 //stringstream ss;
 //ss << request->content.rdbuf();
 //string content=ss.str();

//? *response << "HTTP/1.1 200 OK\r\nContent-Length: " << content.length() << "\r\n\r\n" << content;


}

