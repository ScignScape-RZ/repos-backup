
#ifndef PTN_TEST_FORM_HANDLER__H
#define PTN_TEST_FORM_HANDLER__H

#include "handler-base.h"


class PTN_Test_Form_Handler : public Handler_Base
{

public:

 PTN_Test_Form_Handler();

 void operator()(std::shared_ptr<HttpServer::Response> response, std::shared_ptr<HttpServer::Request> request); //  override;

};



#endif
