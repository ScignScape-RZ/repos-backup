 
#include "qclient-query-request-handler.h"

#include <QString>

#include <QMetaType>

#ifdef OPENSHIFT_DEPLOY
 #include <iostream>
#endif

QString uc_first(QString str)
{
 QString result = str;

 QRegExp rx ("((?:\\W+)|^)(\\w+)");
 rx.setMinimal(true);

 int s = -1;
 while((s = rx.indexIn(result, s+1)) >= 0)
 {
  QString r0 = rx.cap(0);
  QString r1 = rx.cap(1);
  QString r2 = rx.cap(2);

  QString r = QString(rx.cap(1).length(), '_');
  r += rx.cap(2).toUpper();
  result.replace(s, rx.cap(0).length(), r);
  s+= rx.cap(1).length();
 }

 return result;
}




QClient_Query_Request_Handler::QClient_Query_Request_Handler() : Handler_Base()
{

}


void QClient_Query_Request_Handler::operator()(std::shared_ptr<HttpServer::Response> response,
  std::shared_ptr<HttpServer::Request> request)
{
 std::stringstream ss;
#ifdef OPENSHIFT_DEPLOY
 QUrl qurl = request->qurl();
 QString v = uc_first(qurl.queryItemValue("silo"));
 std::cout << "v = " << v.toStdString() << std::endl;
#else
 QUrlQuery qurl_query = request->qurl_query();
 QString v = uc_first(qurl_query.queryItemValue("silo"));
#endif

 v += "_Request_Handler";

 QString cl = v + "*";

 int id = QMetaType::type(v.toLatin1());
 QString resp;

 QString invoke_result;
#ifdef OPENSHIFT_DEPLOY
  void* pv = QMetaType::construct(id);
#else
  void* pv = QMetaType::create(id);
#endif

 if(pv)
 {
  QObject* o = static_cast<QObject*>(pv);

  const QMetaObject* qmo = o->metaObject();

#ifdef OPENSHIFT_DEPLOY
  bool ok = qmo->invokeMethod(o, "absorb_url_query",
   Q_ARG(QUrl, qurl));
#else
  bool ok = qmo->invokeMethod(o, "absorb_url_query",
   Q_ARG(QUrlQuery, qurl_query));
#endif

  bool ok1 = qmo->invokeMethod(o, "get_web_response",
   Q_RETURN_ARG(QString, invoke_result),
   QArgument<PTN_Data_Manager*>("PTN_Data_Manager*", request->data_manager()));

 }


 resp += invoke_result;


 ss << resp.toStdString();


 std::string rc = ss.str();

 QString qrc = QString::fromStdString(rc);

 *response << "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=UTF-8; Content-Length: "
   << rc.length() << ";\r\n\r\n" << rc;

}

