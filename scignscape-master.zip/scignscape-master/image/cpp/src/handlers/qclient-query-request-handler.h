
#ifndef QCLIENT_QUERY_REQUEST_HANDLER__H
#define QCLIENT_QUERY_REQUEST_HANDLER__H

#include "handler-base.h"


class QClient_Query_Request_Handler : public Handler_Base
{

public:

 QClient_Query_Request_Handler();

 void operator()(std::shared_ptr<HttpServer::Response> response, std::shared_ptr<HttpServer::Request> request); //  override;

};



#endif
