
#include "eidheim-http/server_http.hpp"

//Added for the json-example
#define BOOST_SPIRIT_THREADSAFE
#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/json_parser.hpp>

//Added for the default_resource example
#include <fstream>
#include <boost/filesystem.hpp>
#include <vector>
#include <algorithm>


#include <QDebug>
#include <QFile>
#include <QDir>

#include "http_parser.h"

#include "eidheim-http/server_http.hpp"



#include "handlers/qclient-query-request-handler.h"
#include "handlers/ptn-general-form-handler.h"
#include "handlers/handler-base.h"

#include "qunqlite-callback-parser.h"

#include <QMetaType>




using namespace std;
//Added for the json-example:
using namespace boost::property_tree;

typedef SimpleWeb::Server<SimpleWeb::HTTP> HttpServer;

//Added for the default_resource example
void default_resource_send(const HttpServer &server, shared_ptr<HttpServer::Response> response,
                           shared_ptr<ifstream> ifs, shared_ptr<vector<char> > buffer);


string_list split(const std::string & s, const std::string & delim,
                  bool keep_empty)
{
 string_list result;
 std::string::const_iterator substart = s.begin(), subend = substart;
 while (true)
 {
  subend = std::search(substart, s.end(), delim.begin(), delim.end());
  std::string temp(substart, subend);
  if (keep_empty || !temp.empty())
  {
   result.push_back(temp);
  }
  if (subend == s.end())
  {
   break;
  }
  substart = subend + delim.size();
 }
 return result;
}

void map_pairs(const std::string& s, const std::string& elemDelim,
               const std::string& pairDelim, QMultiMap<QString, QString>& result)
{
 using namespace map_pairs_helper;

 string_list words;
 words = split(s, elemDelim, false);
 std::for_each(words.begin(), words.end(),
               ParsePairsFunc(pairDelim, result));
}

namespace ParseWebData {
namespace ParseMultipartFormData {

void sanitize_parts(string_list& parts)
{
 string_list::iterator iter = parts.begin();
 while (iter != parts.end()) {

  QString p = QString::fromStdString(*iter);

  if ((*iter).find("--\r\n") == 0) { // If part starts with --\r\n - it is last boundary. remove
   iter = parts.erase(iter);
   continue;
  }

  if ((*iter).find("\r\n") == 0) { // Due to split command all parts starts with empty line. Remove it
   (*iter).erase(0, 2);
  }
  if ((*iter).rfind("\r\n") == (*iter).length() - 2) { // Due to split command all parts ends with CRLF. Remove it
   (*iter).erase((*iter).rfind("\r\n"), 2);
  }
  ++iter;
 }
}

} }


QString home_file(QString s)
{
 if(s.startsWith ("~/"))
 {
  s.replace (0, 1, QDir::homePath());
 }
 return s;
}


std::string get_content_type(const std::string& key)
{
 static std::map<std::string, std::string> static_map {
  {".htm", "text/html"},
  {".html", "text/html"},
  {".png", "image/png"},
  {".gif", "image/gif"},
  {".jpg", "image/jpg"},
  {".jpeg", "image/jpeg"},
  {".wmv", "audio/x-ms-wmv"},

  {"htm", "text/html"},
  {"html", "text/html"},
  {"png", "image/png"},
  {"gif", "image/gif"},
  {"jpg", "image/jpg"},
  {"jpeg", "image/jpeg"},
  {"wmv", "audio/x-ms-wmv"},

 };

 if(static_map.find(key) != static_map.end())
 {
  return static_map[key];
 }
 return "text/html";
}


thread* init_https_server_thread(HttpsServer* https_server)
{
 thread* result = new thread([https_server](){
  https_server->start();
  qDebug() << "Started https_server";
 });
 return result;
}

HttpsServer* init_https_server(int port_number, QString crt_file, QString key_file)
{
 qDebug() << "https_server using port" << port_number;
 HttpsServer* result = new HttpsServer(port_number, 1,
   crt_file.toStdString(), key_file.toStdString());
 return result;
}



QMap<QString, QString> read_partials_map()
{
 // //  It may be desirable to read these from a file, but by way of illustration ...
 QMap<QString, QString> result;
 return result;
}

void write_raws(QString file, shared_ptr<HttpServer::Response> response, QString raw_text_link = QString())
{
 QFile infile(file);
 QString contents;
 if(infile.open(QIODevice::ReadOnly))
 {
  QTextStream qts(&infile);
  contents = qts.readAll();
 }

 if(raw_text_link.isEmpty())
 {
  *response << "HTTP/1.1 200 OK\r\nContent-Disposition: attachment; Content-Type: text/plain; charset=UTF-8; Content-Length: " << contents.length() << "\r\n\r\n" << contents.toStdString();
 }
 else
 {
  QString qr = QString("<html><body>You may want to download this as raw <a href='%1'>text</a>.").arg(raw_text_link);
  qr += QString("<pre><code><xmp>\n%1\n</xmp></code></pre></body></html>").arg(contents);
  *response << "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=UTF-8; Content-Length: " << qr.length() << "\r\n\r\n" << qr.toStdString();
 }

}

QString complete_partials(QString path, QString default_path)
{
 static QMap<QString, QString> partials_map = read_partials_map();
 QString write_path = path + ".completed";
 QString result;
 QFile infile(path);

 if(infile.open(QIODevice::ReadOnly))
 {
  QTextStream in(&infile);
  while (!in.atEnd())
  {
   QString line = in.readLine();
   if(line.startsWith("@@"))
   {
    QString code = line.mid(2).trimmed();
    QString partial_path = partials_map.value(code);
    if(partial_path.isEmpty())
    {
     QString dp = default_path;

     // //
     if(code.contains("top-links"))
      dp += "/top-nav";
     else if(code.contains("style"))
      dp += "/styles";

     if(!default_path.isEmpty())
     {
      partial_path = QString("%1/%2.htm").arg(dp).arg(code);
     }
    }
    if(!partial_path.isEmpty())
    {
     QFile pinfile(partial_path);

     if(pinfile.open(QIODevice::ReadOnly))
     {
      QTextStream pin(&pinfile);
      QString ra = pin.readAll();
      ra.replace("<!--.[", "<!--[");
      ra.replace("<!.[", "<![");
      result += ra;
     }
    }
   }
   else
   {
    line.replace("#{", "<span class='scaps'>");
    line.replace("}#", "</span>");
    result += line + "\n";
   }
  }
  infile.close();
 }
 QFile outfile(write_path);
 if(outfile.open(QIODevice::WriteOnly))
 {
  QTextStream out(&outfile);
  out << result;
  outfile.close();
 }
 return write_path;
}


int main(int argc, char* argv[])
{
 // //  For form handlers etc.
  //    qRegisterMetaType<...>();
  //    qRegisterMetaType<...*>();


 //HTTP-server at port 8080 using 1 thread
 //Unless you do more heavy non-threaded processing in the resources,
 //1 thread is usually faster than several threads
 HttpServer server(PORT_NUMBER, 1);

 QString crt_file;
 QString key_file;
 int https_port_number;

 if(argc > 1)
 {
  std::cout << std::endl << "Setting Web Root Path: /usr/src/app-deploy-root/web/ptn/public" << std::endl;
  server.set_web_root_path("/usr/src/app-deploy-root/web/ptn/public");

  QString volume = "/usr/src/persistent-deploy-volume";
  QFile file(volume);
  if(file.exists())
  {
   server.set_data_root_path(volume.toStdString());
   crt_file = "/usr/src/app-deploy-root/ssl-keys/server.crt";
   key_file = "/usr/src/app-deploy-root/ssl-keys/server.key";
  }
  else
  {
   server.set_data_root_path("/usr/src/app-deploy-data");
   crt_file = "/usr/src/app-deploy-root/ssl-keys/server.crt";
   key_file = "/usr/src/app-deploy-root/ssl-keys/server.key";
  }
  https_port_number = 1727;
 }
 else
 {
  server.set_web_root_path(home_file(LOCAL_WEB_ROOT_PATH).toStdString());
  server.set_data_root_path(home_file(LOCAL_DATA_ROOT_PATH).toStdString());

  crt_file = home_file(CRT_FILE_PATH);
  key_file = home_file(KEY_FILE_PATH);

  https_port_number = 1727;

 }

 HttpsServer* https_server = init_https_server(https_port_number, crt_file, key_file);


 qDebug() << "Listening on port " << PORT_NUMBER;


 QUnQLite_Callback_Parser callback_parser;

 std::function<int(QString message, int arglength, void* data)>
   allobase_callback = [&callback_parser](QString message, int arglength, void* data) -> int
 {
  return callback_parser.run_query(message, arglength, data);
 };

 std::function<int(QString message, QString key, QString value, QString* ref)>
   index_callback = [&callback_parser](QString message, QString key, QString value, QString* ref = nullptr) -> int
 {
  if(ref)
  {
   void* data[2] = {&key, ref};
   return callback_parser.run_query(message, 2, data);
  }
  else
  {
   void* data[2] = {&key, &value};
   return callback_parser.run_query(message, 2, data);
  }
 };

 std::function<QString()>
   error_callback = [&callback_parser]() -> QString
 {
   return callback_parser.last_error_code();
 };

 qDebug() << "Allobase init ...";

 server.allobase_init(server.data_root_string(), "all-ptn",
                      allobase_callback, index_callback, error_callback);


 //Add resources using path-regex and method-string, and an anonymous function
 //POST-example for the path /string, responds the posted string
 server.resource["^/string$"]["POST"]=[](shared_ptr<HttpServer::Response> response, shared_ptr<HttpServer::Request> request) {
  //Retrieve string:
  auto content=request->content.string();
  //request->content.string() is a convenience function for:
  //stringstream ss;
  //ss << request->content.rdbuf();
  //string content=ss.str();

  *response << "HTTP/1.1 200 OK\r\nContent-Length: " << content.length() << "\r\n\r\n" << content;
 };

 //POST-example for the path /json, responds firstName+" "+lastName from the posted json
 //Responds with an appropriate error message if the posted json is not valid, or if firstName or lastName is missing
 //Example posted json:
 //{
 //  "firstName": "John",
 //  "lastName": "Smith",
 //  "age": 25
 //}
 server.resource["^/json$"]["POST"]=[](shared_ptr<HttpServer::Response> response, shared_ptr<HttpServer::Request> request) {
  try {
   ptree pt;
   read_json(request->content, pt);

   string name=pt.get<string>("firstName")+" "+pt.get<string>("lastName");

   *response << "HTTP/1.1 200 OK\r\n"
             << "Content-Type: application/json\r\n"
             << "Content-Length: " << name.length() << "\r\n\r\n"
             << name;
  }
  catch(exception& e) {
   *response << "HTTP/1.1 400 Bad Request\r\nContent-Length: " << strlen(e.what()) << "\r\n\r\n" << e.what();
  }
 };

 //GET-example for the path /info
 //Responds with request-information
 server.resource["^/info$"]["GET"]=[](shared_ptr<HttpServer::Response> response, shared_ptr<HttpServer::Request> request) {
  stringstream content_stream;
  content_stream << "<h1>Request from " << request->remote_endpoint_address << " (" << request->remote_endpoint_port << ")</h1>";
  content_stream << request->method << " " << request->path << " HTTP/" << request->http_version << "<br>";
  for(auto& header: request->header) {
   content_stream << header.first << ": " << header.second << "<br>";
  }

  //find length of content_stream (length received using content_stream.tellp())
  content_stream.seekp(0, ios::end);

  *response <<  "HTTP/1.1 200 OK\r\nContent-Length: " << content_stream.tellp() << "\r\n\r\n" << content_stream.rdbuf();
 };



 server.resource["^/qt-test$"]["GET"]=[](shared_ptr<HttpServer::Response> response, shared_ptr<HttpServer::Request> request) {

  QString resp = "<b>Testing Qt: OK</b>";
  std::stringstream content_stream;

  content_stream << resp.toStdString();
  //find length of content_stream (length received using content_stream.tellp())
  content_stream.seekp(0, ios::end);

  *response <<  "HTTP/1.1 200 OK\r\nContent-Length: " << content_stream.tellp() << "\r\n\r\n" << content_stream.rdbuf();
 };


 server.resource["^/sr__ngml/([\\w.-]+)$"]["GET"]=[&server](shared_ptr<HttpServer::Response> response, shared_ptr<HttpServer::Request> request)
 {
  string pm = request->path_match[1];
  QString qpm = QString::fromStdString(pm);

  QString hr = QString("/txt__ngml/%1").arg(qpm);

  auto web_root_path = server.web_root_path();
  QString qwrp = QString::fromStdString(web_root_path.string());
  QString qf = qwrp + "/main-info-pages/ngml/" + qpm;
  write_raws(qf, response, hr);
 };

 server.resource["^/kf__n2k/([\\w.-]+)$"]["GET"]=[&server](shared_ptr<HttpServer::Response> response, shared_ptr<HttpServer::Request> request)
 {
  string pm = request->path_match[1];
  QString qpm = QString::fromStdString(pm);
  QString hr = QString("/txt__ngml/%1").arg(qpm);
  auto web_root_path = server.web_root_path();
  QString qwrp = QString::fromStdString(web_root_path.string());
  QString qf = qwrp + "/main-info-pages/khif/" + qpm;
  write_raws(qf, response, hr);
 };

 server.resource["^/txt__ngml/([\\w.-]+)$"]["GET"]=[&server](shared_ptr<HttpServer::Response> response, shared_ptr<HttpServer::Request> request)
 {
  string pm = request->path_match[1];
  QString qpm = QString::fromStdString(pm);
  auto web_root_path = server.web_root_path();
  QString qwrp = QString::fromStdString(web_root_path.string());
  QString qf = qwrp + "/main-info-pages/khif/" + qpm;
  write_raws(qf, response);
 };

 server.resource["^/txt__n2k/([\\w.-]+)$"]["GET"]=[&server](shared_ptr<HttpServer::Response> response, shared_ptr<HttpServer::Request> request)
 {
  string pm = request->path_match[1];
  QString qpm = QString::fromStdString(pm);
  auto web_root_path = server.web_root_path();
  QString qwrp = QString::fromStdString(web_root_path.string());
  QString qf = qwrp + "/main-info-pages/khif/" + qpm;
  write_raws(qf, response);
 };

 //GET-example for the path /match/[number], responds with the matched string in path (number)
 //For instance a request GET /match/123 will receive: 123
 server.resource["^/match/([0-9]+)$"]["GET"]=[&server](shared_ptr<HttpServer::Response> response, shared_ptr<HttpServer::Request> request)
 {
  string number=request->path_match[1];
  *response << "HTTP/1.1 200 OK\r\nContent-Length: " << number.length() << "\r\n\r\n" << number;
 };

 //Get example simulating heavy work in a separate thread
 server.resource["^/work$"]["GET"]=[&server](shared_ptr<HttpServer::Response> response, shared_ptr<HttpServer::Request> /*request*/) {
  thread work_thread([response] {
   this_thread::sleep_for(chrono::seconds(5));
   string message="Work done";
   *response << "HTTP/1.1 200 OK\r\nContent-Length: " << message.length() << "\r\n\r\n" << message;
  });
  work_thread.detach();
 };



 PTN_General_Form_Handler ptn_general_form_handler;
 ptn_general_form_handler.set_file_root(server.web_root_std_string());
 server.resource["^/form/([\\w-]+)$"]["POST"] = ptn_general_form_handler;

 https_server->resource["^/form/([\\w-]+)$"]["POST"] = ptn_general_form_handler;

 https_server->resource["^/$"]["GET"] = [](shared_ptr<HttpsServer::Response> response, shared_ptr<HttpsServer::Request> request)
 {
  QString deb = "Matched empty HTTPS Route...";
  qDebug() << "D= " << deb;
  *response << "HTTP/1.1 200 OK\r\nContent-Length: " << deb.length() << "\r\n\r\n" << deb.toStdString();
 };


 https_server->resource["^/test$"]["GET"] = [](shared_ptr<HttpsServer::Response> response, shared_ptr<HttpsServer::Request> request)
 {
  QString deb = "HTTPS Test OK...";
  *response << "HTTP/1.1 200 OK\r\nContent-Length: " << deb.length() << "\r\n\r\n" << deb.toStdString();
 };


 https_server->set_data_manager(server.data_manager());
 thread* https_thread = init_https_server_thread(https_server);

 https_thread->detach();


 QClient_Query_Request_Handler qclient_query_request_handler;
 qclient_query_request_handler.set_file_root(server.web_root_std_string());
 server.resource["^/qt-client\\?.*"]["GET"] = qclient_query_request_handler;

 //Default GET-example. If no other matches, this anonymous function will be called.
 //Will respond with content in the web/-directory, and its subdirectories.
 //Default file: index.html
 //Can for instance be used to retrieve an HTML 5 client that uses REST-resources on this server
 server.default_resource["GET"]=[&server](shared_ptr<HttpServer::Response> response, shared_ptr<HttpServer::Request> request) {
  try {

   auto web_root_path = server.web_root_path();
   QString wrp = QString::fromStdString(web_root_path.string());

   std::string req_path = request->path;
   QString qrp = QString::fromStdString(req_path);

   if(qrp.endsWith('?'))
   {
    qrp.chop(1);
    req_path = qrp.toStdString();
   }

   auto path = boost::filesystem::canonical(web_root_path/req_path);


   std::string pd = path.string();
   QString qpd = QString::fromStdString(pd);

   if(qpd.endsWith(".html"))
   {
    QString temp_path = complete_partials(qpd, wrp + "/partials");
    pd = temp_path.toStdString();
    path = boost::filesystem::canonical(pd);
   }

   std::string web_root_p = web_root_path.string();
   QString web_root_q = QString::fromStdString(web_root_p);

   //Check if path is within web_root_path
   if(distance(web_root_path.begin(), web_root_path.end())>distance(path.begin(), path.end()) ||
      !equal(web_root_path.begin(), web_root_path.end(), path.begin()))
   {
    throw invalid_argument("path must be within root path");
   }
   if(boost::filesystem::is_directory(path))
    path/="index.html";
   if(!(boost::filesystem::exists(path) && boost::filesystem::is_regular_file(path)))
    throw invalid_argument("file does not exist");

   auto ifs=make_shared<ifstream>();
   ifs->open(path.string(), ifstream::in | ios::binary);

   if(*ifs) {
    //read and send 128 KB at a time
    streamsize buffer_size=131072;
    auto buffer=make_shared<vector<char> >(buffer_size);

    ifs->seekg(0, ios::end);
    auto length=ifs->tellg();

    ifs->seekg(0, ios::beg);

    *response << "HTTP/1.1 200 OK\r\nContent-Length: " << length << "\r\n\r\n";
    default_resource_send(server, response, ifs, buffer);
   }
   else
    throw invalid_argument("could not read file");
  }
  catch(const exception &e) {
   string content="Could not open path "+request->path+": "+e.what();
   *response << "HTTP/1.1 400 Bad Request\r\nContent-Length: " << content.length() << "\r\n\r\n" << content;
  }
 };

 thread server_thread([&server](){
  //Start server
  server.start();
 });

 server_thread.join();

 return 0;
}

void default_resource_send(const HttpServer &server, shared_ptr<HttpServer::Response> response,
                           shared_ptr<ifstream> ifs, shared_ptr<vector<char> > buffer)
{
 streamsize read_length;
 if((read_length=ifs->read(&(*buffer)[0], buffer->size()).gcount())>0)
 {
  response->write(&(*buffer)[0], read_length);
  if(read_length==static_cast<streamsize>(buffer->size()))
  {
   server.send(response, [&server, response, ifs, buffer](const boost::system::error_code &ec) {
    if(!ec)
     default_resource_send(server, response, ifs, buffer);
    else
     cerr << "Connection interrupted" << endl;
   });
  }
 }
}
