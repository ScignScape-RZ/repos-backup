
#include "qunqlite-callback-parser.h"

#include <QDebug>
#include <QUrl>
#include <QSharedPointer>

#include <QStringList>

//#include <QRegularExpression>

#include <QDateTime>

QUnQLite_Callback_Parser::QUnQLite_Callback_Parser()
{

}


//unqlite.open("test.db", QUnQLite::Create);
//unqlite.store("record2", "hello, world");
//unqlite.store("demo2", "fine");
//unqlite.store("hi2", "there?");

//QUnQLiteCursor *cursor = unqlite.cursor();
//for (cursor->first(); cursor->isValid(); cursor->next()) {
//    qDebug() << cursor->key() << ": " << cursor->value();
//}

//unqlite.close();



int QUnQLite_Callback_Parser::run_query(QString message, int arglength, void* data)
{
 switch( parse_query(message) )
 {
  #define TEMP_MACRO(name) \
   case name: return run_##name(message, arglength, data); break;
  #include "qunqlite-callback-parser.queries.h"
  #undef TEMP_MACRO

 default:  return 0;

 }

}


#define EXTRACT_STRING_ARGS_2(pVoid, arg1, arg2) \
 arg1 = *reinterpret_cast<QString*>( \
  reinterpret_cast<void**>(pVoid)[0]); \
 arg2 = *reinterpret_cast<QString*>( \
  reinterpret_cast<void**>(pVoid)[1]); \

#define EXTRACT_TYPED_ARGS_2__vr(pVoid, type1 ,arg1, type2 ,arg2) \
 type1 arg1 = *reinterpret_cast<type1*>( \
  reinterpret_cast<void**>(pVoid)[0]); \
 type2& arg2 = *reinterpret_cast<type2*>( \
  reinterpret_cast<void**>(pVoid)[0]); \


#define EXTRACT_TYPED_ARGS_1(pVoid, type1 ,arg1) \
 type1 arg1 = *reinterpret_cast<type1*>( \
  reinterpret_cast<void**>(pVoid)[0]); \


#define EXTRACT_TYPED_ARGS_2(pVoid, type1 ,arg1, type2, arg2) \
 type1& arg1 = *reinterpret_cast<type1*>( \
  reinterpret_cast<void**>(pVoid)[0]); \
 type2& arg2 = *reinterpret_cast<type2*>( \
  reinterpret_cast<void**>(pVoid)[1]); \

#ifdef HIDE
#define EXTRACT_TYPED_ARGS_3(pVoid, type1 ,arg1, type2, arg2, type3, arg2) \
 type1& arg1 = *reinterpret_cast<type1*>( \
  reinterpret_cast<void**>(pVoid)[0]); \
 type2& arg2 = *reinterpret_cast<type2*>( \
  reinterpret_cast<void**>(pVoid)[1]); \
 type3& arg3 = *reinterpret_cast<type3*>( \
  reinterpret_cast<void**>(pVoid)[1]); \

#endif


QString QUnQLite_Callback_Parser::last_error_code()
{
 switch(qunqlite_.lastErrorCode())
 {
  case QUnQLite::Ok: return "UNQLITE_OK"; //break;
  case QUnQLite::NoMemory: return "UNQLITE_NOMEM";  //break;
  case QUnQLite::Abort: return "UNQLITE_ABORT"; //break;
  case QUnQLite::IoError: return "UNQLITE_IOERR";
  case QUnQLite::CorruptPointer: return "UNQLITE_CORRUPT";
  case QUnQLite::Locked: return "UNQLITE_LOCKED";
  case QUnQLite::Busy: return "UNQLITE_BUSY";
  case QUnQLite::Done: return "UNQLITE_DONE";
  case QUnQLite::PermissionError: return "UNQLITE_PERM";
  case QUnQLite::NotImplemented: return "UNQLITE_NOTIMPLEMENTED";
  case QUnQLite::NotFound: return "UNQLITE_NOTFOUND";
  case QUnQLite::NoSuchFunction: return "UNQLITE_NOOP";
  case QUnQLite::Invalid: return "UNQLITE_INVALID";
  case QUnQLite::EndOfInput: return "UNQLITE_EOF";
  case QUnQLite::UnknownError: return "UNQLITE_UNKNOWN";
  case QUnQLite::Limit: return "UNQLITE_LIMIT";
  case QUnQLite::Exists: return "UNQLITE_EXISTS";
  case QUnQLite::Empty: return "UNQLITE_EMPTY";
  case QUnQLite::CompileError: return "UNQLITE_COMPILE_ERR";
  case QUnQLite::VMError: return "UNQLITE_VM_ERR";
  case QUnQLite::Full: return "UNQLITE_FULL";
  case QUnQLite::CannotOpen: return "UNQLITE_CANTOPEN";
  case QUnQLite::IsReadOnly: return "UNQLITE_READ_ONLY";
  case QUnQLite::LockingError: return "UNQLITE_LOCKERR";


 }
}



int QUnQLite_Callback_Parser::run_DB_Check_Key_Exists(QString message, int arglength, void* data)
{
 EXTRACT_TYPED_ARGS_2(data, QString ,uid,
  bool ,result)
 result = qunqlite_.check_fetch(uid);

  // .fetch(uid, qba);
 return 0;

}

int QUnQLite_Callback_Parser::load_generic_data(void* data)
{
 EXTRACT_TYPED_ARGS_2(data, QString ,uid,
  QSharedPointer<QByteArray> ,qba)
 qunqlite_.fetch(uid, qba);
 return 0;
}



int QUnQLite_Callback_Parser::run_DB_Save_Last_Email(QString message, int arglength, void* data)
{
 return save_generic_data(data);
}

int QUnQLite_Callback_Parser::run_DB_Load_Last_Email(QString message, int arglength, void* data)
{
 return load_generic_data(data);
}



int QUnQLite_Callback_Parser::run_DB_Save_Document_XML(QString message, int arglength, void* data)
{
 return save_generic_data(data);
}

int QUnQLite_Callback_Parser::run_DB_Load_Document_XML(QString message, int arglength, void* data)
{
 return load_generic_data(data);
}


int QUnQLite_Callback_Parser::run_DB_Save_Artist(QString message, int arglength, void* data)
{
 return save_generic_data(data);
}

int QUnQLite_Callback_Parser::run_DB_Load_Artist(QString message, int arglength, void* data)
{
 return load_generic_data(data);
}


int QUnQLite_Callback_Parser::run_DB_Save_Author(QString message, int arglength, void* data)
{
 return save_generic_data(data);
}

int QUnQLite_Callback_Parser::run_DB_Load_Author(QString message, int arglength, void* data)
{
 return load_generic_data(data);
}



int QUnQLite_Callback_Parser::run_DB_Save_Concert(QString message, int arglength, void* data)
{
 return save_generic_data(data);
}

int QUnQLite_Callback_Parser::run_DB_Load_Concert(QString message, int arglength, void* data)
{
 return load_generic_data(data);
}

//int QUnQLite_Callback_Parser::run_DB_Load_Artist_Code_From_Artist_Name(QString message, int arglength, void* data)
//{
// return load_generic_data(data);
//}

int QUnQLite_Callback_Parser::run_DB_Load_Application_State(QString message, int arglength, void* data)
{
 return load_generic_data(data);
}

int QUnQLite_Callback_Parser::run_DB_Load_Application_Comment_State(QString message, int arglength, void* data)
{
 return load_generic_data(data);
}

int QUnQLite_Callback_Parser::run_DB_Load_Dialog_Data(QString message, int arglength, void* data)
{
 return load_generic_data(data);
}

int QUnQLite_Callback_Parser::run_DB_Load_Comment_Data(QString message, int arglength, void* data)
{
 return load_generic_data(data);
}

int QUnQLite_Callback_Parser::run_DB_Load_User_Data(QString message, int arglength, void* data)
{
 return load_generic_data(data);
}


int QUnQLite_Callback_Parser::run_DB_Load_Stored_Web_State_Date_Time(QString message, int arglength, void* data)
{
 return load_generic_data(data);
}

int QUnQLite_Callback_Parser::run_DB_Load_Stored_Web_State(QString message, int arglength, void* data)
{
 return load_generic_data(data);
}


int QUnQLite_Callback_Parser::run_DB_Load_Document_Container_State(QString message, int arglength, void* data)
{
 return load_generic_data(data);
}

int QUnQLite_Callback_Parser::run_DB_Save_Document_Container_State(QString message, int arglength, void* data)
{
 return save_generic_data(data);
}


int QUnQLite_Callback_Parser::run_DB_Load_Stored_Web_Page(QString message, int arglength, void* data)
{
 return load_generic_data(data);
}

int QUnQLite_Callback_Parser::run_DB_Save_Web_State_Date_Time(QString message, int arglength, void* data)
{
 return save_generic_data(data);
}

int QUnQLite_Callback_Parser::run_DB_Save_Web_State(QString message, int arglength, void* data)
{
 return save_generic_data(data);
}

int QUnQLite_Callback_Parser::run_DB_Save_Stored_Web_Page(QString message, int arglength, void* data)
{
 return save_generic_data(data);
}

int QUnQLite_Callback_Parser::run_DB_Save_Application_State(QString message, int arglength, void* data)
{
 return save_generic_data(data);
}

int QUnQLite_Callback_Parser::run_DB_Save_Application_Comment_State(QString message, int arglength, void* data)
{
 return save_generic_data(data);
}

int QUnQLite_Callback_Parser::run_DB_Save_Dialog_Data(QString message, int arglength, void* data)
{
 return save_generic_data(data);
}

int QUnQLite_Callback_Parser::run_DB_Save_Comment_Data(QString message, int arglength, void* data)
{
 return save_generic_data(data);
}

int QUnQLite_Callback_Parser::run_DB_Save_User_Data(QString message, int arglength, void* data)
{
 return save_generic_data(data);
}


int QUnQLite_Callback_Parser::run_DB_Commit(QString, int, void*)
{
 if(qunqlite_.commit())
  return 0;
 return 1;
}

int QUnQLite_Callback_Parser::save_generic_data(void* data)
{
 EXTRACT_TYPED_ARGS_2(data, QString ,unique_id, QSharedPointer<QByteArray> ,qba)
// QByteArray* test = qba.data();
 bool store_result = qunqlite_.store(unique_id, qba);

 if(store_result)
 {
  if(qunqlite_.commit())
   return 0;
  return 1;
 }
 else
  qDebug() << "Store failed";
 return 1;

}


int QUnQLite_Callback_Parser::run_DB_Save_Generic_Data(QString message, int arglength, void* data)
{
 if(arglength == 2)
 {
  return save_generic_data(data);
 }
 else
 {
  return Malformed_Arguments_Problem;
 }
}

int QUnQLite_Callback_Parser::run_DB_Load_Generic_Data(QString message, int arglength, void* data)
{
 if(arglength == 2)
 {
  return load_generic_data(data);
 }
 else
 {
  return Malformed_Arguments_Problem;
 }
}

int QUnQLite_Callback_Parser::run_Index_Str_Str(QString message, int arglength, void* data)
{
 EXTRACT_TYPED_ARGS_2(data, const QString ,s1, const QString ,s2)
 bool store_result = qunqlite_.store(s1, s2);

 if(store_result)
 {
  if(qunqlite_.commit())
   return All_Ok;
  return Commit_Problem;
 }
 else
  return Store_Problem;
}

int QUnQLite_Callback_Parser::run_Save_Str_Str(QString message, int arglength, void* data)
{
 EXTRACT_TYPED_ARGS_2(data, const QString ,s1, const QString ,s2)
 bool store_result = qunqlite_.store(s1, s2);

 if(store_result)
 {
  if(qunqlite_.commit())
   return All_Ok;
  return Commit_Problem;
 }
 else
  return Store_Problem;
}



int QUnQLite_Callback_Parser::run_Retrieve_Str_Str(QString message, int arglength, void* data)
{
 EXTRACT_TYPED_ARGS_2(data, const QString ,s1, QString ,s2)
 bool retrieve_result = qunqlite_.fetch(s1, s2);

 if(retrieve_result)
  return All_Ok;
 else
  return Retrieve_Problem;
}

int QUnQLite_Callback_Parser::run_Load_Str_Str(QString message, int arglength, void* data)
{
 EXTRACT_TYPED_ARGS_2(data, const QString ,s1, QString ,s2)
 bool retrieve_result = qunqlite_.fetch(s1, s2);

 if(retrieve_result)
  return All_Ok;
 else
  return Retrieve_Problem;
}


int QUnQLite_Callback_Parser::run_DB_Save_Resource(QString message, int arglength, void* data)
{
// EXTRACT_TYPED_ARGS_1(data, QSharedPointer<QByteArray> ,qba)
// QByteArray* test = qba.data();

 return Not_Implemented;
}



int QUnQLite_Callback_Parser::run_Test_Cursor(QString message, int arglength, void* data)
{
 QUnQLiteCursor* cr = qunqlite_.cursor();

// if(cr->first()) do

 if(cr->first()) do
 {
  QByteArray k = cr->key();
  QByteArray v = cr->value();
  qDebug() << "Key: " << k << "Value: " << v;
 }
 while(cr->next());
 return All_Ok;
}

int QUnQLite_Callback_Parser::run_Index_List(QString message, int arglength, void* data)
{
 typedef QMap<QString, QString> result_type;

 EXTRACT_TYPED_ARGS_2(data,
  QString ,key_prefix,  result_type ,result)

 QUnQLiteCursor* cr = qunqlite_.cursor();

 int len = key_prefix.length();

 if(cr->first()) do
 {
  QByteArray k = cr->key();

  if(k.startsWith(key_prefix.toLatin1()))
  {
   k.remove(0, len);
   QByteArray v = cr->value();
   result[k] = v;
  }

 }
 while(cr->next());
 return All_Ok;
}


int QUnQLite_Callback_Parser::run_Key_Cursor(QString message, int arglength, void* data)
{
 EXTRACT_TYPED_ARGS_2(data,
  QString ,key_prefix,  QStringList ,result)

 QUnQLiteCursor* cr = qunqlite_.cursor();

 int len = key_prefix.length();

 if(cr->first()) do
 {
  QByteArray k = cr->key();

  if(k.startsWith(key_prefix.toLatin1()))
  {
   k.remove(0, len);
   result.push_back(k);
  }
 }
 while(cr->next());
 return All_Ok;
}

int QUnQLite_Callback_Parser::run_Regex_Key_Cursor(QString message, int arglength, void* data)
{
#ifdef HIDE
 EXTRACT_TYPED_ARGS_2(data,
  QRegularExpression ,key_regex,  QStringList ,result)

 QUnQLiteCursor* cr = qunqlite_.cursor();

 if(cr->first()) do
 {
  QByteArray k = cr->key();

  QRegularExpressionMatch rxm = key_regex.match(k);

  if(rxm.hasMatch())
  {
   result.push_back(k);
  }
 }
 while(cr->next());
 return All_Ok;
#endif
 return All_Ok;
}



int QUnQLite_Callback_Parser::run_DB_Create_Or_Open(QString message, int arglength, void* data)
{
 EXTRACT_STRING_ARGS_2(data, data_root_path_, database_file_name_)

 qDebug() << data_root_path_;
 qDebug() << database_file_name_;

 QString database_path = data_root_path_ + "/" + database_file_name_; // + ".txt";

 qDebug() << "DB Path: " << database_path;

 if(qunqlite_.open(database_path, QUnQLite::Create))
 {
  qunqlite_.store("DBPath", database_path);
  if(qunqlite_.commit())
  {
   qunqlite_.store("LastOpen", QDateTime::currentDateTime().toString());
   if(qunqlite_.commit())
    return All_Ok;
  }
 }
 return Database_Create_Problem;
}



int QUnQLite_Callback_Parser::run_DB_Create(QString message, int arglength, void* data)
{
 return Not_Implemented;
}

int QUnQLite_Callback_Parser::run_DB_Open(QString message, int arglength, void* data)
{
 return Not_Implemented;
}

//int QUnQLite_Callback_Parser::run_DB_Load_Dialog(QString message, int arglength, void* data)
//{
//return 0;
//}

int QUnQLite_Callback_Parser::run_DB_Load_Resource(QString message, int arglength, void* data)
{
 return Not_Implemented;
}

