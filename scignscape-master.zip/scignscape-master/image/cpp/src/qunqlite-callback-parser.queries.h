
// //   This is not a top-level header.
//     This file is included several times,
//     setting TEMP_MACRO as needed.

TEMP_MACRO(DB_Create_Or_Open)
TEMP_MACRO(DB_Create)
TEMP_MACRO(DB_Open)
TEMP_MACRO(DB_Load_Application_State)

TEMP_MACRO(DB_Commit)


TEMP_MACRO(DB_Save_Last_Email)
TEMP_MACRO(DB_Load_Last_Email)


TEMP_MACRO(DB_Save_Generic_Data)
TEMP_MACRO(DB_Load_Generic_Data)

TEMP_MACRO(DB_Save_Artist)
TEMP_MACRO(DB_Load_Artist)


TEMP_MACRO(DB_Save_Author)
TEMP_MACRO(DB_Load_Author)


TEMP_MACRO(DB_Save_Concert)
TEMP_MACRO(DB_Load_Concert)

TEMP_MACRO(DB_Check_Key_Exists)

//?TEMP_MACRO(DB_Load_Artist_Code_From_Artist_Name)


TEMP_MACRO(DB_Load_Application_Comment_State)
TEMP_MACRO(DB_Load_Dialog_Data)
TEMP_MACRO(DB_Load_Comment_Data)
TEMP_MACRO(DB_Load_User_Data)
TEMP_MACRO(DB_Load_Resource)

TEMP_MACRO(Index_Str_Str)
TEMP_MACRO(Retrieve_Str_Str)

TEMP_MACRO(Save_Str_Str)
TEMP_MACRO(Load_Str_Str)

TEMP_MACRO(DB_Save_Application_State)

TEMP_MACRO(Key_Cursor)
TEMP_MACRO(Regex_Key_Cursor)

TEMP_MACRO(DB_Save_Web_State_Date_Time)
TEMP_MACRO(DB_Save_Web_State)

TEMP_MACRO(DB_Load_Stored_Web_State_Date_Time)
TEMP_MACRO(DB_Load_Stored_Web_State)

TEMP_MACRO(DB_Save_Stored_Web_Page)
TEMP_MACRO(DB_Load_Stored_Web_Page)

TEMP_MACRO(DB_Save_Document_XML)
TEMP_MACRO(DB_Load_Document_XML)


TEMP_MACRO(DB_Save_Document_Container_State)
TEMP_MACRO(DB_Load_Document_Container_State)


TEMP_MACRO(DB_Save_Application_Comment_State)
TEMP_MACRO(DB_Save_Dialog_Data)
TEMP_MACRO(DB_Save_Comment_Data)
TEMP_MACRO(DB_Save_User_Data)
TEMP_MACRO(DB_Save_Resource)
TEMP_MACRO(Test_Cursor)


TEMP_MACRO(Index_List)
