trap 'echo "# $BASH_COMMAND"' DEBUG 
oc expose dc/#project-name# --port=1726 
