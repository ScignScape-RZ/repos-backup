trap 'echo "# $BASH_COMMAND"' DEBUG 
oc import-image docker.io/#docker-hub-username#/#project-name#
