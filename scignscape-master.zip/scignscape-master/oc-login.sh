trap 'echo "# $BASH_COMMAND"' DEBUG  
oc login --token=3_ScW4TlcbAcekNc9FA07EEJROgfDZn-QET0AHs2-io --server=https://api.preview.openshift.com
