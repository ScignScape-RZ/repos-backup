trap 'echo "# $BASH_COMMAND"' DEBUG 
oc new-app docker.io/#docker-hub-username#/#project-name#
 
