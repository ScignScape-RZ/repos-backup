trap 'echo "# $BASH_COMMAND"' DEBUG 
oc volume dc/#project-name# --add --name=ptn-d-prime --type=persistentVolumeClaim --overwrite --claim-size=200M --mount-path=/usr/src/persistent-deploy-volume
